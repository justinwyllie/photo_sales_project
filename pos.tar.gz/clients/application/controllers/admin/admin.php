<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends CI_Controller {



	public function __construct()
	{
		parent::__construct();
		$this->load->model('admin_model');
	}

	/**
	 *	Controls display of Admin Home  page
	 */
	public function index()
	{

		$leftMenuItems = $this->admin_model->left_menu();

		$client_title = "Print Ordering System";

		$navItems = $this->admin_model->nav_menu();
                
		$this->load->view('admin/templates/header', array('c_title'=>$client_title));
		$this->load->view('admin/templates/top_menu', array('navItems'=>$navItems));
		$this->load->view('admin/templates/left_menu', array('menuItems' => $leftMenuItems));
		$this->load->view('admin/pages/home');
		$this->load->view('admin/templates/footer');
	}






}

