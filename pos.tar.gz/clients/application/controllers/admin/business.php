<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Business  extends CI_Controller {



	public function __construct()
	{
		parent::__construct();
		$this->load->model('admin_model');
		$this->load->model('business_model');
	}


	/**
	 *	Loads the screen which allows the user to configure the business params
	 */
	public function index()
	{
		
		$this->load->helper('form');

		$site_menu = $this->admin_model->site_menu();
		$client_menu = $this->admin_model->client_menu();
		$navItems = $this->admin_model->nav_menu();
		$siteOwner = $this->business_model->get_site_owner();

		$salutations = $this->admin_model->salutations();
		$currencies = $this->admin_model->currencies();

		$client_title = "Print Ordering System";

		$this->load->view('admin/templates/header', array('c_title'=>$client_title));
		$this->load->view('admin/templates/top_menu', array('navItems' => $navItems));
		$this->load->view('admin/templates/left_menu', array('site_menu'=>$site_menu, 'client_menu'=>$client_menu));
		$this->load->view('admin/pages/business/business', array('siteOwner' => $siteOwner, 'salutations' => $salutations, 'currencies'=> $currencies));
		$this->load->view('admin/templates/footer');

	}

	/**
	 *	Loads the screen which allows the user to configure the business params
	 */
	public function account()
	{
		
		$this->load->helper('form');

		$site_menu = $this->admin_model->site_menu();
		$client_menu = $this->admin_model->client_menu();
		$navItems = $this->admin_model->nav_menu();
		$siteOwner = $this->business_model->get_site_owner();

		$salutations = $this->admin_model->salutations();
		$currencies = $this->admin_model->currencies();

		$client_title = "Print Ordering System";

		$this->load->view('admin/templates/header', array('c_title'=>$client_title));
		$this->load->view('admin/templates/top_menu', array('navItems' => $navItems));
		$this->load->view('admin/templates/left_menu', array('site_menu'=>$site_menu, 'client_menu'=>$client_menu));
		$this->load->view('admin/pages/business/account', array('siteOwner' => $siteOwner));
		$this->load->view('admin/templates/footer');

	}

	/**
	 *	Loads the screen which allows the user to upload their logo 
	 */
	public function logo($result = null)
	{
		
		$this->load->helper(array('language', 'html', 'form'));
		$this->lang->load('message');	

		$site_menu = $this->admin_model->site_menu();
		$client_menu = $this->admin_model->client_menu();
		$navItems = $this->admin_model->nav_menu();
		$siteOwner = $this->business_model->get_site_owner();
		$logo = null;
		//TODO - this is relative to the CI index.php script dir? 
		if (! is_null($siteOwner->own_logo) && file_exists('uploads/'.$siteOwner->own_logo) )
		{
			$logo = array(
				'src' => 'uploads/'.$siteOwner->own_logo,
				'alt' => $siteOwner->business_name, //TODO what if this is null?
				'class' =>'logo',
				'width' => '120',
				'height' => '90'
				
			);
		}
		if (is_null($result))
		{
			$msg['class'] = "hide";
			$msg['text'] = "";
		}
		else
		{
			if ($result) 
			{
				$msg['class'] = "success";
				$msg['text'] =  lang('message_logo_success');
			}
			else
			{
				$msg['class'] = "error";
				$msg['text'] = lang('message_logo_failed');
			}

		}
	

		$salutations = $this->admin_model->salutations();
		$currencies = $this->admin_model->currencies();

		$client_title = "Print Ordering System";

		$this->load->view('admin/templates/header', array('c_title'=>$client_title));
		$this->load->view('admin/templates/top_menu', array('navItems' => $navItems));
		$this->load->view('admin/templates/left_menu', array('site_menu'=>$site_menu, 'client_menu'=>$client_menu));
		$this->load->view('admin/pages/business/logo', array('siteOwner' => $siteOwner, 'logo'=>$logo, 'msg'=>$msg));
		$this->load->view('admin/templates/footer');

	}



	/**
	* handle post of logo upload
	*
	*/
	public function post_account_logo()
	{

		$config['upload_path'] = './uploads';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size']	= '200';
		$config['max_width']  = '120';
		$config['max_height']  = '90';

//TODO any image processing eg. resizing

		$this->load->library('upload', $config);

		if ( ! $this->upload->do_upload('logo'))
		{
			$error = array('error' => $this->upload->display_errors());
			$this->logo(0);
		}
		else
		{
			$data = array('upload_data' => $this->upload->data());
			//TODO - probably want to control the file name in the config
			//TODO DB CHECK
			$result = $this->business_model->update_own_logo($data['upload_data']['file_name']);
			if ($result)
			{
				$this->logo(1);	
			}
			else
			{
				$this->logo(0);
			}
		}

	}


	/*
	* Process Ajax post from business details form
	*
	*/

	public function ajax_business()
	{

		$this->load->helper(array('language', 'form', 'url'));
		$this->load->library('form_validation');	
		$this->lang->load('message');	

		$this->form_validation->set_rules('first_name', 'First Name', 'required');
		$this->form_validation->set_rules('last_name', 'Last Name', 'required');			
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email');			
		$this->form_validation->set_rules('business_name', 'Business Name', 'required');			
		$this->form_validation->set_rules('description', 'Description', 'required');			
		$this->form_validation->set_rules('currency', 'Currency', 'callback_select_selected');			


		$response = new stdClass();


		if ($this->form_validation->run() == FALSE) 
		{
			$response->result = false;
			$response->errors =  validation_errors();
		}
		else
		{
			$result = $this->business_model->set_site_owner();	
			$response->result = $result;
			if ($result == FALSE)
			{
				$response->errors = lang('database_error');
			}
		}
		header("Content-Type: application/json");
		echo json_encode($response);


	}

	/*
	* Process Ajax post to update account name 
	*
	*/

	public function ajax_account_name()
	{

		$this->load->helper(array('language', 'form'));
		$this->load->library('form_validation');	
		$this->lang->load('message');	

		$this->form_validation->set_rules('user', 'Account Name', 'required|min_length[5]|max_length[12]|alpha_numeric');
		
		$response = new stdClass();


		if ($this->form_validation->run() == FALSE) 
		{
			$response->result = false;
			$response->errors =  validation_errors();
	
			
		}
		else
		{
			$result = $this->business_model->update_user();	
			$response->result = $result;
		}
		header("Content-Type: application/json");
		echo json_encode($response);

	}

	/*
	* Process Ajax post to update password 
	*
	*/

	public function ajax_account_password()
	{

		$this->load->helper(array('form'));
		$this->load->library('form_validation');	

		$this->form_validation->set_rules('password1', 'Password 1', 'required|min_length[5]|max_length[12]|alpha_numeric|matches[password2]');
		$this->form_validation->set_rules('password2', 'Password 2', 'required|min_length[5]|max_length[12]|alpha_numeric|matches[password1]');
		$response = new stdClass();


		if ($this->form_validation->run() == FALSE) 
		{
			$response->result = false;
			$response->errors =  validation_errors();
		}
		else
		{
			$result = $this->business_model->update_password();	
			$response->result = $result;
		}
		header("Content-Type: application/json");
		echo json_encode($response);

	}




	public function select_selected($str)
	{
		if ($str != "..")
		{
			return TRUE;
			
		}
		else
		{

			$this->form_validation->set_message('select_selected', lang('currency_required'));
			return FALSE;
		}	
		

	}

}

