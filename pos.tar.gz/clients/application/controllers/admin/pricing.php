<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pricing  extends CI_Controller {



	public function __construct()
	{
		parent::__construct();
		$this->load->model('admin_model');
		$this->load->model('pricing_model');
	}


	/**
	 *	Loads the screen which allows the user to configure the print  params
	 */
	public function prints()
	{
		
		$this->load->helper('form');
		$this->load->model('business_model');

		$site_menu = $this->admin_model->site_menu();
		$client_menu = $this->admin_model->client_menu();

		//TODO if not set up? curr. we issue a warning 
		$currency = $this->business_model->get_current_currency();
		$unit = $this->business_model->get_set_unit();
	 
		$print_prices = $this->pricing_model->get_print_sizes();
		$mount_types = $this->pricing_model->get_mount_types();
		$frame_types = $this->pricing_model->get_frame_types();


		$client_title = "Print Ordering System";

		$this->load->view('admin/templates/header', array('c_title'=>$client_title));
		$this->load->view('admin/templates/left_menu', array('site_menu'=>$site_menu, 'client_menu'=>$client_menu));
		$this->load->view('admin/pages/pricing/prints', array('currency'=>$currency, 'print_prices'=>$print_prices,
				 'unit'=>$unit  ));
		$this->load->view('admin/templates/footer');

	}

	/**
	 *	Loads the screen which allows the user to configure the mount  params
	 */
	public function mount_types()
	{
		
		$this->load->helper('form');

		$site_menu = $this->admin_model->site_menu();


		$mounts = $this->pricing_model->get_mount_types();


		$client_title = "Print Ordering System";

		$this->load->view('admin/templates/header', array('c_title'=>$client_title));
		$this->load->view('admin/templates/left_menu', array('site_menu'=>$site_menu));
		$this->load->view('admin/pages/pricing/mount_types', array( 'mount_types'=>$mounts));
		$this->load->view('admin/templates/footer');

	}

	/**
	 *	Loads the screen which allows the user to configure the units 
	 */
	public function units()
	{
		
		$this->load->helper('form');
		$this->load->model('business_model');
		$site_menu = $this->admin_model->site_menu();

		$units = $this->pricing_model->get_units_name();
		$select = array('..'=>'Select..');
		$units = $select + $units;
			
		$set_unit = $this->business_model->get_set_unit_id();
		$client_title = "Print Ordering System";

		$this->load->view('admin/templates/header', array('c_title'=>$client_title));
		$this->load->view('admin/templates/left_menu', array('site_menu'=>$site_menu));
		$this->load->view('admin/pages/pricing/units', array( 'units'=>$units, 'set_unit'=>$set_unit));
		$this->load->view('admin/templates/footer');

	}



	/**
	 *	Loads the screen which allows the user to configure the frame types 
	 */
	public function frame_types()
	{
		$this->load->helper('form');

		$site_menu = $this->admin_model->site_menu();
		$client_menu = $this->admin_model->client_menu();


		$frame_types = $this->pricing_model->get_frame_types();


		$client_title = "Print Ordering System";

		$this->load->view('admin/templates/header', array('c_title'=>$client_title));
		$this->load->view('admin/templates/left_menu', array('site_menu'=>$site_menu, 'client_menu'=>$client_menu));
		$this->load->view('admin/pages/pricing/frame_types', array( 'frame_types'=>$frame_types));
		$this->load->view('admin/templates/footer');

	}



	/**
	* Handle the call to get the data to populate the print configure dialog
	*
	* Return all the data needed to populate the print configure screen
	* 
	*
	*/
	public function ajax_print_configure()
	{

		$this->load->helper(array('language'));
		$this->lang->load('message');
		$this->load->model('business_model');
// print dimensions
//unit symbol
//currency symbol
//frame types
//current price for this print size
//current price for this print size mounted and unmounted per frame type

		
                $response = new stdClass();
		$print = $this->pricing_model->get_print_size();

		//TODO - ? shld never be null because of wizard
		$currency = $this->business_model->get_current_currency();
		$unit = $this->business_model->get_set_unit();

		$response->currency_symbol = $currency->currency_symbol;
		$response->unit = $unit->symbol;

		//$print_prices = $this->pricing_model->get_print_prices();
		if (is_null($print))
		{
			$response->result = false;
			$response->errors = lang('print_deleted');
			$response->system_error = true;
                	header("Content-Type: application/json");
                	echo json_encode($response);
			exit;
		}
		$response->print = $print;

		//TODO test case with no frames should be null 
		$print_with_frames_unmounted = $this->pricing_model->get_print_frames_and_prices_unmounted();	
		$print_with_frames_mounted = $this->pricing_model->get_print_frames_and_prices_mounted();	

		$response->frames_unmounted = $print_with_frames_unmounted;
		$response->frames_mounted = $print_with_frames_mounted;
		$response->result = true;

	
                header("Content-Type: application/json");
                echo json_encode($response);
	}



	/**
	/* Handle the Ajax post of the print configuration  data
	*/
	public function ajax_print_configure_update()
	{
		$this->load->helper(array('form', 'url'));
                $this->load->library('form_validation');
                $response = new stdClass();

		//TODO form validation esp. on decimals 
		$update_result = $this->pricing_model->update_print_configuration();
		echo $update_result;exit; 



		//TODO VALIDATION - 
/*
                $response = new stdClass();
		$sorted_data = $this->prices->sort_print_sizes($this->input->post());


		if (is_null($sorted_data))
		{
			$response->result = false;
                	header("Content-Type: application/json");
                	echo json_encode($response);
			exit;
		}


		$update_result = true;

		if (! empty($sorted_data) )
		{
			$update_result=	$this->pricing_model->update_print_sizes($sorted_data );
		}

		$response->result = $update_result;
*/
                header("Content-Type: application/json");
                echo json_encode($response);
	}







	/**
	/* Handle the Ajax post of the print size/price data
	*/
	public function ajax_prints_update()
	{
	//TODO not sure this is used
		$this->load->helper(array('form', 'url'));
                $this->load->library('form_validation');
		$this->load->library('prices');

		//TODO VALIDATION - 

                $response = new stdClass();
		$sorted_data = $this->prices->sort_print_sizes($this->input->post());


		if (is_null($sorted_data))
		{
			$response->result = false;
                	header("Content-Type: application/json");
                	echo json_encode($response);
			exit;
		}


		$update_result = true;

		if (! empty($sorted_data) )
		{
			$update_result=	$this->pricing_model->update_print_sizes($sorted_data );
		}

		$response->result = $update_result;

                header("Content-Type: application/json");
                echo json_encode($response);
	}

	/**
	* Handle the delete of a print size/price entry
	*/
	public function ajax_prints_delete()
	{
		$result = $this->pricing_model->delete_print_sizes();
                $response = new stdClass();
		$response->result = $result;
		if ($result == false) 
		{
//TODO lang
			$response->errors = "Database error: record not deleted";
		}
                header("Content-Type: application/json");
                echo json_encode($response);
	}


	/**
	* Handle the insert of a print size/price entry
	*/
	public function ajax_prints_insert()
	{
		//TODO VALIDATION
		$result = $this->pricing_model->insert_print_sizes();
                $response = new stdClass();
		if (is_null($result))
		{
			$response->result = false;
			
		}	
		else
		{
			$response->result = true;
			$response->site_print_sizes_id = $result;

		}
                header("Content-Type: application/json");
                echo json_encode($response);
	}

	/**
	* Handle the insert of a mount type 
	*/
	public function ajax_mount_types_insert()
	{

		$this->load->helper(array('form', 'url', 'language'));
                $this->load->library('form_validation');
		$this->lang->load('message');
		$this->form_validation->set_rules('mount_type_name', 'Name', 'required');
	
                $response = new stdClass();

                if ($this->form_validation->run() == FALSE)
                {
                        $response->result = false;
			$response->errors = validation_errors();
                	header("Content-Type: application/json");
                	echo json_encode($response);
			exit;
                }

		$result = $this->pricing_model->insert_mount_type();
		if (is_null($result))
		{
			$response->result = false;
			$response->errors = lang('database_error');
			
		}	
		else
		{
			$response->result = true;
			$response->site_mounting_types_id = $result;

		}
                header("Content-Type: application/json");
                echo json_encode($response);
	}


	/**
	* Handle the delete of a mount type
	*/
	public function ajax_mount_types_delete()
	{
		$result = $this->pricing_model->delete_mount_type();
                $response = new stdClass();
		$response->result = $result;
		if ($result == false) 
		{
			$response->errors = "Database error: record not deleted";
		}
                header("Content-Type: application/json");
                echo json_encode($response);
	}


	/**
	/* Handle the Ajax post of the mount types update 
	*/
	public function ajax_mount_update()
	{
		$this->load->helper(array('form', 'url', 'language'));
                $this->load->library('form_validation');
		$this->load->library('prices');
		$this->lang->load('message');

		//TODO VALIDATION - do it in the prcoessing code in the library 

                $response = new stdClass();
		$sorted_data = $this->prices->sort_mount_types($this->input->post());

		if (is_null($sorted_data))
		{
			$response->result = false;
			$response->errors = lang('database_error');
                	header("Content-Type: application/json");
                	echo json_encode($response);
			exit;
		}

		$update_result = true;

		if (! empty($sorted_data) )
		{
			$update_result=	$this->pricing_model->update_mount_types($sorted_data );
		}

		$response->result = $update_result;

                header("Content-Type: application/json");
                echo json_encode($response);
	}


	/**
	* Handle the post for a new frame type which may have an image with it
	*
	* Use this for IE alternative to FormData API
	* 
	*/

	function post_new_frame_type() 
	{	
	echo 'A';

                $config['upload_path'] = './uploads';
                $config['allowed_types'] = 'gif|jpg|png';
                $config['max_size']     = '200';
                $config['max_width']  = '120';
                $config['max_height']  = '90';

//TODO any image processing eg. resizing

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('logo'))
                {
                        $error = array('error' => $this->upload->display_errors());
                        $this->logo(0);
                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());
                        //TODO - probably want to control the file name in the config
                        //TODO DB CHECK
                        $result = $this->business_model->update_own_logo($data['upload_data']['file_name']);
                        if ($result)
                        {
                                $this->logo(1);
                        }
                        else
                        {
                                $this->logo(0);
                        }
                }


	}

	/**
	* Get one frame type record
	*
	*/
 	
	public function ajax_frame_type_get()
	{
		$this->load->helper(array('language'));
		$this->lang->load('message');

		$frame = $this->pricing_model->get_frame_type();

                $response = new stdClass();

		if ($frame == false)
		{
			$response->result = false;
			$response->system_error = true;
			$response->errors = lang('no_record');
                	header("Content-Type: application/json");
                	echo json_encode($response);
			exit;
			
		} 
		else
		{
			$response->result = true;
			$response->data = $frame;	
                	header("Content-Type: application/json");
                	echo json_encode($response);
			exit;

		}
	}

	/**
	* Handle the insert of a frame  type 
	*/

	public function ajax_frame_types_insert()
	{


		$this->load->helper(array('form', 'url', 'language'));
                $this->load->library('form_validation');
		$this->lang->load('message');
                $config['upload_path'] = './uploads';
                $config['allowed_types'] = 'gif|jpg|png';
                $config['max_size']     = '200';
                $config['max_width']  = '200';
                $config['max_height']  = '200';
                $this->load->library('upload', $config);

                $response = new stdClass();
		$filename = null;


		$this->form_validation->set_rules('frame_type_name', 'Name', 'required');
	

                if ($this->form_validation->run() == FALSE)
                {
                        $response->result = false;
			$response->errors = validation_errors();
                	header("Content-Type: application/json");
                	echo json_encode($response);
			exit;
                }

		//TODO any image processing eg. resizing
		$thumbs = './uploads/thumbs';
		if (! is_dir($thumbs))
		{
			$ret = 	@mkdir($thumbs);
			if ($ret === false)
			{
				$response->result = false;
				$response->errors = sprintf($this->lang->line('not_create_directory'), $thumbs) ;
				$response->system_error = true; 
                		header("Content-Type: application/json");
                		echo json_encode($response);
				exit;
			}
		}

		if ( ! empty($_FILES['frame_image']['name']))
		{
			if ( ! $this->upload->do_upload('frame_image'))
                	{
				$response->result = false;
				$response->errors = $this->upload->display_errors() ;
                		header("Content-Type: application/json");
                		echo json_encode($response);
				exit;
               		 }
               		 else
               		 {
                	        $data = array('upload_data' => $this->upload->data());
                        	$filename = $data['upload_data']['file_name'];
				$config['image_library'] = 'gd2';
				$config['source_image']	= './uploads/'.$filename;
				$config['maintain_ratio'] = TRUE;
				$config['width']	 = 100;
				$config['height']	= 100;
				$config['new_image'] = './uploads/thumbs/'; 
				$this->load->library('image_lib',$config);
				$ret2 = $this->image_lib->resize();
			}
		}


		$result = $this->pricing_model->insert_frame_type($filename);
		if (is_null($result))
		{
			if (! is_null($filename)) 
			{
				$path = './uploads/'.$filename;
				@unlink($path);
				$path2 = './uploads/thumbs/'.$filename;
				@unlink($path2);
			}	
			$response->result = false;
			$response->errors = lang('database_error');
			
		}	
		else
		{
			$response->result = true;
			$response->filename = $filename;
			$response->site_framing_types_id = $result;
			//if there is an image save it. TODO could put this in a transaction and roll back the database if the image was not saved?
	

		}
                header("Content-Type: application/json");
                echo json_encode($response);
	}


	/**
	* Handle the update of a frame  type 
	*/

	public function ajax_frame_type_save_edit()
	{

		$this->load->helper(array('form', 'url', 'language'));
                $this->load->library('form_validation');
		$this->lang->load('message');
                $config['upload_path'] = './uploads';
                $config['allowed_types'] = 'gif|jpg|png';
                $config['max_size']     = '200';
                $config['max_width']  = '200';
                $config['max_height']  = '200';
                $this->load->library('upload', $config);

                $response = new stdClass();
		$filename = null;


		$this->form_validation->set_rules('frame_type_name', 'Name', 'required');
	

                if ($this->form_validation->run() == FALSE)
                {
                        $response->result = false;
			$response->errors = validation_errors();
                	header("Content-Type: application/json");
                	echo json_encode($response);
			exit;
                }

		$thumbs = './uploads/thumbs';
		if (! is_dir($thumbs))
		{
			$ret = 	@mkdir($thumbs);
			if ($ret === false)
			{
				$response->result = false;
				$response->errors = sprintf($this->lang->line('not_create_directory'), $thumbs) ;
				$response->system_error = true; 
                		header("Content-Type: application/json");
                		echo json_encode($response);
				exit;
			}
		}

		if ( ! empty($_FILES['frame_image']['name']))
		{

			if ( ! $this->upload->do_upload('frame_image'))
        	        {
				$response->result = false;
				$response->errors = $this->upload->display_errors() ;
                		header("Content-Type: application/json");
                		echo json_encode($response);
				exit;
               		 }
               		 else
               		 {
                        	$data = array('upload_data' => $this->upload->data());
                       		$filename = $data['upload_data']['file_name'];
				$config['image_library'] = 'gd2';
				$config['source_image']	= './uploads/'.$filename;
				$config['maintain_ratio'] = TRUE;
				$config['width']	 = 100;
				$config['height']	= 100;
				$config['new_image'] = './uploads/thumbs/'; 
				$this->load->library('image_lib',$config);
				$ret2 = $this->image_lib->resize();
			}
		}

		$result = $this->pricing_model->update_frame_type($filename);
		if (is_null($result))
		{
			if (! is_null($filename)) 
			{
				$path = './uploads/'.$filename;
				@unlink($path);
				$path2 = './uploads/thumbs/'.$filename;
				@unlink($path2);
			}	
			$response->result = false;
			$response->errors = lang('database_error');
			
		}	
		else
		{
			$response->result = true;
			$data = array('filename'=>$filename);
			$response->data = $data;

		}
                header("Content-Type: application/json");
                echo json_encode($response);
	}




	/**
	* Handle the delete of a frame type
	*/
	public function ajax_frame_types_delete()
	{
		$result = $this->pricing_model->delete_frame_type();
                $response = new stdClass();
		$response->result = $result;
		if ($result == false) 
		{
			$response->errors = "Database error: record not deleted";
		}
                header("Content-Type: application/json");
                echo json_encode($response);
	}


	/**
	/*  Handle the ajax post to set the Units 
	*/
	public function ajax_unit_set()
	{
		$this->load->helper(array( 'language'));
		$this->lang->load('message');
		$this->load->model('business_model');


                $response = new stdClass();
		$result = $this->business_model->set_unit( );
		if ($result == false) 
		{
			$response->errors = lang("database_error");
		}
                header("Content-Type: application/json");

		$response->result = $result;

                header("Content-Type: application/json");
                echo json_encode($response);
	}


	/**
	/* Handle the Ajax post of the frame types update 
	/*
	/* Reduntant - updates set of row
	*/
	/*
	public function ajax_frame_update()
	{
		$this->load->helper(array('form', 'url', 'language'));
                $this->load->library('form_validation');
		$this->load->library('prices');
		$this->lang->load('message');

		//TODO VALIDATION - do it in the prcoessing code in the library 

                $response = new stdClass();
		$sorted_data = $this->prices->sort_frame_types($this->input->post());

		if (is_null($sorted_data))
		{
			$response->result = false;
			$response->errors = lang('database_error');
                	header("Content-Type: application/json");
                	echo json_encode($response);
			exit;
		}

		$update_result = true;

		if (! empty($sorted_data) )
		{
			$update_result=	$this->pricing_model->update_frame_types($sorted_data );
		}

		$response->result = $update_result;

                header("Content-Type: application/json");
                echo json_encode($response);
	}

	*/ 

}

