<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Test  extends CI_Controller {



	public function __construct()
	{
		parent::__construct();
		$this->load->model('admin_model');
		$this->load->model('business_model');
	}

	/**
	 *	Loads the screen which allows the user to configure the business params
	 */
	public function index()
	{
		
		$this->load->helper('form');
		$this->load->helper('html');


		$client_title = "Working title, well done me :D!";
    
    $imageProperties = array(
          'src' => 'images/picture2.png',
          'alt' => 'Print Ordering System Logo',
          'class' => 'pos_logo',
          'width' => '75 ',
          'height' => '90',
          'title' => 'Print Ordering System Logo',
          'rel' => 'lightbox',);



		/* this code gets the left menus 
		*
		* tip: do var_dump on the return value to see what you are getting
		*/

		$site_menu = $this->admin_model->site_menu();
		$client_menu = $this->admin_model->client_menu();		
		$site_owner = $this->business_model->get_site_owner();

		/*
		* see how these files correspond to ones in the /application/views folder
		* and see how you can pass in variables e.g. c_title which you can then access in the template with $c_title
		* or menuItems which is itself an array 
		*
		*/


		$this->load->view('test/templates/header', array('c_title'=>$client_title, 'c_imageProperties'=>$imageProperties));
		$this->load->view('test/templates/left_menu', array('site_menu' => $site_menu, 'client_menu'=>$client_menu));
		$this->load->view('test/pages/business', array('siteOwner'=>$site_owner));
		$this->load->view('test/templates/footer');


	}



}

