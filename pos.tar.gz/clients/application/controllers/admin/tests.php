<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tests extends CI_Controller {



	public function __construct()
	{
		parent::__construct();
		$this->load->library('unit_test');
		$this->unit->use_strict(TRUE);
		$this->load->model('admin_model');
		$this->load->model('business_model');
	}

	/**
	 *	Runs tests 
	 */
	public function index()
	{

		echo '<html><head><title>Tests</title></head><body style="font-family:arial,helvetica,sans-serif;"><h1>Admin System Tests </h1>';

		

		/* test we have some base data in the system */
		$this->unit->run($this->test1(), TRUE, 'Get site menu', 'Tests for at least one element in the databse');
		$this->unit->run($this->test2(), TRUE, 'Get client menu', 'Tests for at least one element in the database');
		$this->unit->run($this->test3(), TRUE, 'Get salutations', 'Tests for at least one element in the database');
		$this->unit->run($this->test4(), TRUE, 'Get currencies', 'Tests for at least one element in the databae');



		echo $this->unit->report();



		echo '</body></html>';
	}


	/**
	* Test getting site_menu
	*
	*/
	private function test1()
	{
		$site_menu = $this->admin_model->site_menu();
		 if (is_array($site_menu) && ! empty( $site_menu )) 
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}

	/**
	* Test getting client_menu
	*
	*/
	private function test2()
	{
		$client_menu = $this->admin_model->client_menu();
		 if (is_array($client_menu) && ! empty( $client_menu )) 
		{
			return true;
		}
		else
		{
			return false;
		}
		
		
	}

	/**
	* Test getting salutations
	*
	*/
	private function test3()
	{
		$salutations = $this->admin_model->salutations();
		 if (is_array($salutations) && ! empty( $salutations )) 
		{
			return true;
		}
		else
		{
			return false;
		}
		
		
	}

	/**
	* Test getting currencies
	*
	*/
	private function test4()
	{
		$currencies = $this->admin_model->currencies();
		 if (is_array($currencies) && ! empty( $currencies )) 
		{
			return true;
		}
		else
		{
			return false;
		}
		
		
	}




}

