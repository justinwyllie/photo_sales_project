<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Prints extends CI_Controller {

	/**
	 *	Controls display of client login page
	 */
	public function index()
	{

		$client_title = "Print Ordering System";
		$contacts = array('Justin Wyllie');

		$this->load->view('frontend/templates/header', array('c_title'=>$client_title));
		$this->load->view('frontend/prints' , array('contacts'=>$contacts));
		$this->load->view('frontend/templates/footer');
	}
}

