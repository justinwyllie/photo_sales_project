<?php
$lang['message_logo_success'] = "Logo Uploaded Succesfully";
$lang['message_logo_failed'] = "Error Uploading Logo";
$lang['invalid_username'] = "The username entered is invalid";
$lang['username_changed'] = "Your username has been changed";
$lang['currency_required'] = "Currency must be selected";
$lang['database_error'] = "An unknown database error occured";
$lang['not_create_directory'] = 'Could not create directory %s'; 
$lang['no_record'] = "Record does not exist";
$lang['print_deleted'] = "This print is not in the system"; 




?>
