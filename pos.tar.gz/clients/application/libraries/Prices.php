<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

class Prices {

    public function test()
    {
    }

	/** 
	/* takes the post data from the print sizes form and sorts out the rows for updating
	/*
	/* @param array $post_data 
	/* @return array|null 
	*/

	public function sort_print_sizes($post_data)
	{

		$result = array();
	
		$patt1 = '/^printsize_w_(\d+)$/';

		try
		{		
               		foreach ($post_data as $field_name => $field_data)
                	{
				//sort out the updates
				preg_match($patt1, $field_name, $matches);
				if (! empty($matches) )
				{
					$pk = $matches[1];	
					$result[]= array('site_print_sizes_id'=>$pk, 'size_w' => $post_data[$field_name],
						 'size_h'=> $post_data['printsize_h_'.$pk], 
						'price'=>$post_data['printprice_'.$pk]);	
				}

				//sort out the inserts
				/*preg_match($patt2, $field_name, $matches);
				if (! empty($matches) )
				{
					$row_id = $matches[1];	
					$result['insert'][]= array('size_w' => $post_data[$field_name],
						 'size_h'=> $post_data['insert_printsize_h_'.$row_id], 
						'price'=>$post_data['printprice_'.$row_id]);	
				}
				*/
			

        	        }
		}
		catch (Exception $e)
		{
			$result = null;	
		}

		return $result;
	}

	/** 
	/* takes the post data from the mount types update  form and sorts out the rows for updating
	/*
	/* @param array $post_data 
	/* @return array|null 
	*/

	public function sort_mount_types($post_data)
	{

		$result = array();
	
		$patt1 = '/^mount_type_name_(\d+)$/';

		try
		{		
               		foreach ($post_data as $field_name => $field_data)
                	{
				//sort out the updates
				preg_match($patt1, $field_name, $matches);
				if (! empty($matches) )
				{
					$pk = $matches[1];	
					$result[]= array('site_mounting_types_id'=>$pk, 'mount_type_name' => $post_data[$field_name]);
				}

        	        }
		}
		catch (Exception $e)
		{
			$result = null;	
		}

		return $result;
	}

	/** 
	/* takes the post data from the frame types update  form and sorts out the rows for updating
	/*
	/* @param array $post_data 
	/* @return array|null 
	*/
//TODO custom validation
	public function sort_frame_types($post_data)
	{
		$result = array();
	
		$patt1 = '/^frame_type_name_(\d+)$/';

		try
		{		
               		foreach ($post_data as $field_name => $field_data)
                	{
				//sort out the updates
				preg_match($patt1, $field_name, $matches);
				if (! empty($matches) )
				{
					$pk = $matches[1];	
					$result[]= array('site_framing_types_id'=>$pk, 'frame_type_name' => $post_data[$field_name], 'description'=>$post_data['frame_type_description_'.$pk]);
				}

        	        }
		}
		catch (Exception $e)
		{
			$result = null;	
		}

		return $result;
	}

}

