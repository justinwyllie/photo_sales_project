<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-07-18 16:40:01 --> Config Class Initialized
DEBUG - 2012-07-18 16:40:01 --> Hooks Class Initialized
DEBUG - 2012-07-18 16:40:01 --> Utf8 Class Initialized
DEBUG - 2012-07-18 16:40:01 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 16:40:01 --> URI Class Initialized
DEBUG - 2012-07-18 16:40:01 --> Router Class Initialized
DEBUG - 2012-07-18 16:40:01 --> Output Class Initialized
DEBUG - 2012-07-18 16:40:01 --> Security Class Initialized
DEBUG - 2012-07-18 16:40:01 --> Input Class Initialized
DEBUG - 2012-07-18 16:40:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 16:40:01 --> Language Class Initialized
DEBUG - 2012-07-18 16:43:31 --> Config Class Initialized
DEBUG - 2012-07-18 16:43:31 --> Hooks Class Initialized
DEBUG - 2012-07-18 16:43:31 --> Utf8 Class Initialized
DEBUG - 2012-07-18 16:43:31 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 16:43:31 --> URI Class Initialized
DEBUG - 2012-07-18 16:43:31 --> Router Class Initialized
DEBUG - 2012-07-18 16:43:31 --> Output Class Initialized
DEBUG - 2012-07-18 16:43:31 --> Security Class Initialized
DEBUG - 2012-07-18 16:43:31 --> Input Class Initialized
DEBUG - 2012-07-18 16:43:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 16:43:31 --> Language Class Initialized
DEBUG - 2012-07-18 16:43:31 --> Loader Class Initialized
DEBUG - 2012-07-18 16:43:31 --> Helper loaded: url_helper
DEBUG - 2012-07-18 16:43:31 --> Controller Class Initialized
DEBUG - 2012-07-18 16:43:31 --> Model Class Initialized
DEBUG - 2012-07-18 16:43:31 --> Database Driver Class Initialized
DEBUG - 2012-07-18 16:43:31 --> Upload Class Initialized
DEBUG - 2012-07-18 16:43:31 --> Language file loaded: language/english/upload_lang.php
ERROR - 2012-07-18 16:43:31 --> You did not select a file to upload.
DEBUG - 2012-07-18 16:43:31 --> Helper loaded: form_helper
DEBUG - 2012-07-18 16:43:31 --> Helper loaded: language_helper
DEBUG - 2012-07-18 16:43:31 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-18 16:43:31 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-18 16:43:31 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-18 16:43:31 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-18 16:43:31 --> File loaded: application/views/admin/pages/logo.php
DEBUG - 2012-07-18 16:43:31 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-18 16:43:31 --> Final output sent to browser
DEBUG - 2012-07-18 16:43:31 --> Total execution time: 0.0439
DEBUG - 2012-07-18 16:46:53 --> Config Class Initialized
DEBUG - 2012-07-18 16:46:53 --> Hooks Class Initialized
DEBUG - 2012-07-18 16:46:53 --> Utf8 Class Initialized
DEBUG - 2012-07-18 16:46:53 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 16:46:53 --> URI Class Initialized
DEBUG - 2012-07-18 16:46:53 --> Router Class Initialized
DEBUG - 2012-07-18 16:46:53 --> Output Class Initialized
DEBUG - 2012-07-18 16:46:53 --> Security Class Initialized
DEBUG - 2012-07-18 16:46:53 --> Input Class Initialized
DEBUG - 2012-07-18 16:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 16:46:53 --> Language Class Initialized
DEBUG - 2012-07-18 16:46:53 --> Loader Class Initialized
DEBUG - 2012-07-18 16:46:53 --> Helper loaded: url_helper
DEBUG - 2012-07-18 16:46:53 --> Controller Class Initialized
DEBUG - 2012-07-18 16:46:53 --> Model Class Initialized
DEBUG - 2012-07-18 16:46:53 --> Database Driver Class Initialized
DEBUG - 2012-07-18 16:46:53 --> Helper loaded: form_helper
DEBUG - 2012-07-18 16:46:53 --> Helper loaded: language_helper
DEBUG - 2012-07-18 16:46:53 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-18 16:46:53 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-18 16:46:53 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-18 16:46:53 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-18 16:46:53 --> File loaded: application/views/admin/pages/logo.php
DEBUG - 2012-07-18 16:46:53 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-18 16:46:53 --> Final output sent to browser
DEBUG - 2012-07-18 16:46:53 --> Total execution time: 0.0404
DEBUG - 2012-07-18 16:47:48 --> Config Class Initialized
DEBUG - 2012-07-18 16:47:48 --> Hooks Class Initialized
DEBUG - 2012-07-18 16:47:48 --> Utf8 Class Initialized
DEBUG - 2012-07-18 16:47:48 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 16:47:48 --> URI Class Initialized
DEBUG - 2012-07-18 16:47:48 --> Router Class Initialized
DEBUG - 2012-07-18 16:47:48 --> Output Class Initialized
DEBUG - 2012-07-18 16:47:48 --> Security Class Initialized
DEBUG - 2012-07-18 16:47:48 --> Input Class Initialized
DEBUG - 2012-07-18 16:47:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 16:47:48 --> Language Class Initialized
DEBUG - 2012-07-18 16:47:48 --> Loader Class Initialized
DEBUG - 2012-07-18 16:47:48 --> Helper loaded: url_helper
DEBUG - 2012-07-18 16:47:48 --> Controller Class Initialized
DEBUG - 2012-07-18 16:47:48 --> Model Class Initialized
DEBUG - 2012-07-18 16:47:48 --> Database Driver Class Initialized
DEBUG - 2012-07-18 16:47:49 --> Upload Class Initialized
DEBUG - 2012-07-18 16:47:49 --> Language file loaded: language/english/upload_lang.php
ERROR - 2012-07-18 16:47:49 --> The upload destination folder does not appear to be writable.
DEBUG - 2012-07-18 16:47:49 --> Helper loaded: form_helper
DEBUG - 2012-07-18 16:47:49 --> Helper loaded: language_helper
DEBUG - 2012-07-18 16:47:49 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-18 16:47:49 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-18 16:47:49 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-18 16:47:49 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-18 16:47:49 --> File loaded: application/views/admin/pages/logo.php
DEBUG - 2012-07-18 16:47:49 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-18 16:47:49 --> Final output sent to browser
DEBUG - 2012-07-18 16:47:49 --> Total execution time: 0.2482
DEBUG - 2012-07-18 16:50:26 --> Config Class Initialized
DEBUG - 2012-07-18 16:50:26 --> Hooks Class Initialized
DEBUG - 2012-07-18 16:50:26 --> Utf8 Class Initialized
DEBUG - 2012-07-18 16:50:26 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 16:50:26 --> URI Class Initialized
DEBUG - 2012-07-18 16:50:26 --> Router Class Initialized
DEBUG - 2012-07-18 16:50:26 --> Output Class Initialized
DEBUG - 2012-07-18 16:50:26 --> Security Class Initialized
DEBUG - 2012-07-18 16:50:26 --> Input Class Initialized
DEBUG - 2012-07-18 16:50:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 16:50:26 --> Language Class Initialized
DEBUG - 2012-07-18 16:50:26 --> Loader Class Initialized
DEBUG - 2012-07-18 16:50:26 --> Helper loaded: url_helper
DEBUG - 2012-07-18 16:50:26 --> Controller Class Initialized
DEBUG - 2012-07-18 16:50:26 --> Model Class Initialized
DEBUG - 2012-07-18 16:50:26 --> Database Driver Class Initialized
DEBUG - 2012-07-18 16:50:26 --> Helper loaded: form_helper
DEBUG - 2012-07-18 16:50:26 --> Helper loaded: language_helper
DEBUG - 2012-07-18 16:50:26 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-18 16:50:26 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-18 16:50:26 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-18 16:50:26 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-18 16:50:26 --> File loaded: application/views/admin/pages/logo.php
DEBUG - 2012-07-18 16:50:26 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-18 16:50:26 --> Final output sent to browser
DEBUG - 2012-07-18 16:50:26 --> Total execution time: 0.0393
DEBUG - 2012-07-18 16:50:32 --> Config Class Initialized
DEBUG - 2012-07-18 16:50:32 --> Hooks Class Initialized
DEBUG - 2012-07-18 16:50:32 --> Utf8 Class Initialized
DEBUG - 2012-07-18 16:50:32 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 16:50:32 --> URI Class Initialized
DEBUG - 2012-07-18 16:50:32 --> Router Class Initialized
DEBUG - 2012-07-18 16:50:32 --> Output Class Initialized
DEBUG - 2012-07-18 16:50:32 --> Security Class Initialized
DEBUG - 2012-07-18 16:50:32 --> Input Class Initialized
DEBUG - 2012-07-18 16:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 16:50:32 --> Language Class Initialized
DEBUG - 2012-07-18 16:50:32 --> Loader Class Initialized
DEBUG - 2012-07-18 16:50:32 --> Helper loaded: url_helper
DEBUG - 2012-07-18 16:50:32 --> Controller Class Initialized
DEBUG - 2012-07-18 16:50:32 --> Model Class Initialized
DEBUG - 2012-07-18 16:50:32 --> Database Driver Class Initialized
DEBUG - 2012-07-18 16:50:32 --> Upload Class Initialized
ERROR - 2012-07-18 16:50:32 --> Severity: Notice  --> Undefined index: file_name /home/jwp/www/justinwylliephotography.com/clients/application/controllers/admin/business.php 156
DEBUG - 2012-07-18 16:53:46 --> Config Class Initialized
DEBUG - 2012-07-18 16:53:46 --> Hooks Class Initialized
DEBUG - 2012-07-18 16:53:46 --> Utf8 Class Initialized
DEBUG - 2012-07-18 16:53:46 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 16:53:46 --> URI Class Initialized
DEBUG - 2012-07-18 16:53:46 --> Router Class Initialized
DEBUG - 2012-07-18 16:53:46 --> Output Class Initialized
DEBUG - 2012-07-18 16:53:46 --> Security Class Initialized
DEBUG - 2012-07-18 16:53:46 --> Input Class Initialized
DEBUG - 2012-07-18 16:53:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 16:53:46 --> Language Class Initialized
DEBUG - 2012-07-18 16:53:46 --> Loader Class Initialized
DEBUG - 2012-07-18 16:53:46 --> Helper loaded: url_helper
DEBUG - 2012-07-18 16:53:46 --> Controller Class Initialized
DEBUG - 2012-07-18 16:53:46 --> Model Class Initialized
DEBUG - 2012-07-18 16:53:46 --> Database Driver Class Initialized
DEBUG - 2012-07-18 16:53:46 --> Upload Class Initialized
DEBUG - 2012-07-18 16:55:00 --> Config Class Initialized
DEBUG - 2012-07-18 16:55:00 --> Hooks Class Initialized
DEBUG - 2012-07-18 16:55:00 --> Utf8 Class Initialized
DEBUG - 2012-07-18 16:55:00 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 16:55:00 --> URI Class Initialized
DEBUG - 2012-07-18 16:55:00 --> Router Class Initialized
DEBUG - 2012-07-18 16:55:00 --> Output Class Initialized
DEBUG - 2012-07-18 16:55:00 --> Security Class Initialized
DEBUG - 2012-07-18 16:55:00 --> Input Class Initialized
DEBUG - 2012-07-18 16:55:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 16:55:00 --> Language Class Initialized
DEBUG - 2012-07-18 16:55:00 --> Loader Class Initialized
DEBUG - 2012-07-18 16:55:00 --> Helper loaded: url_helper
DEBUG - 2012-07-18 16:55:00 --> Controller Class Initialized
DEBUG - 2012-07-18 16:55:00 --> Model Class Initialized
DEBUG - 2012-07-18 16:55:00 --> Database Driver Class Initialized
DEBUG - 2012-07-18 16:55:00 --> Upload Class Initialized
ERROR - 2012-07-18 16:55:00 --> Severity: Notice  --> Undefined offset: 0 /home/jwp/www/justinwylliephotography.com/clients/application/controllers/admin/business.php 157
DEBUG - 2012-07-18 16:55:59 --> Config Class Initialized
DEBUG - 2012-07-18 16:55:59 --> Hooks Class Initialized
DEBUG - 2012-07-18 16:55:59 --> Utf8 Class Initialized
DEBUG - 2012-07-18 16:55:59 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 16:55:59 --> URI Class Initialized
DEBUG - 2012-07-18 16:55:59 --> Router Class Initialized
DEBUG - 2012-07-18 16:55:59 --> Output Class Initialized
DEBUG - 2012-07-18 16:55:59 --> Security Class Initialized
DEBUG - 2012-07-18 16:55:59 --> Input Class Initialized
DEBUG - 2012-07-18 16:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 16:55:59 --> Language Class Initialized
DEBUG - 2012-07-18 16:55:59 --> Loader Class Initialized
DEBUG - 2012-07-18 16:55:59 --> Helper loaded: url_helper
DEBUG - 2012-07-18 16:55:59 --> Controller Class Initialized
DEBUG - 2012-07-18 16:55:59 --> Model Class Initialized
DEBUG - 2012-07-18 16:55:59 --> Database Driver Class Initialized
DEBUG - 2012-07-18 16:55:59 --> Upload Class Initialized
DEBUG - 2012-07-18 16:58:12 --> Config Class Initialized
DEBUG - 2012-07-18 16:58:12 --> Hooks Class Initialized
DEBUG - 2012-07-18 16:58:12 --> Utf8 Class Initialized
DEBUG - 2012-07-18 16:58:12 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 16:58:12 --> URI Class Initialized
DEBUG - 2012-07-18 16:58:12 --> Router Class Initialized
DEBUG - 2012-07-18 16:58:12 --> Output Class Initialized
DEBUG - 2012-07-18 16:58:12 --> Security Class Initialized
DEBUG - 2012-07-18 16:58:12 --> Input Class Initialized
DEBUG - 2012-07-18 16:58:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 16:58:12 --> Language Class Initialized
DEBUG - 2012-07-18 16:58:12 --> Loader Class Initialized
DEBUG - 2012-07-18 16:58:12 --> Helper loaded: url_helper
DEBUG - 2012-07-18 16:58:12 --> Controller Class Initialized
DEBUG - 2012-07-18 16:58:12 --> Model Class Initialized
DEBUG - 2012-07-18 16:58:12 --> Database Driver Class Initialized
DEBUG - 2012-07-18 16:58:12 --> Upload Class Initialized
DEBUG - 2012-07-18 16:59:03 --> Config Class Initialized
DEBUG - 2012-07-18 16:59:03 --> Hooks Class Initialized
DEBUG - 2012-07-18 16:59:03 --> Utf8 Class Initialized
DEBUG - 2012-07-18 16:59:03 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 16:59:03 --> URI Class Initialized
DEBUG - 2012-07-18 16:59:03 --> Router Class Initialized
DEBUG - 2012-07-18 16:59:03 --> Output Class Initialized
DEBUG - 2012-07-18 16:59:03 --> Security Class Initialized
DEBUG - 2012-07-18 16:59:03 --> Input Class Initialized
DEBUG - 2012-07-18 16:59:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 16:59:03 --> Language Class Initialized
DEBUG - 2012-07-18 16:59:03 --> Loader Class Initialized
DEBUG - 2012-07-18 16:59:03 --> Helper loaded: url_helper
DEBUG - 2012-07-18 16:59:03 --> Controller Class Initialized
DEBUG - 2012-07-18 16:59:03 --> Model Class Initialized
DEBUG - 2012-07-18 16:59:03 --> Database Driver Class Initialized
DEBUG - 2012-07-18 16:59:03 --> Helper loaded: form_helper
DEBUG - 2012-07-18 16:59:03 --> Helper loaded: language_helper
DEBUG - 2012-07-18 16:59:03 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-18 16:59:03 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-18 16:59:03 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-18 16:59:03 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-18 16:59:03 --> File loaded: application/views/admin/pages/logo.php
DEBUG - 2012-07-18 16:59:03 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-18 16:59:03 --> Final output sent to browser
DEBUG - 2012-07-18 16:59:03 --> Total execution time: 0.0390
DEBUG - 2012-07-18 16:59:16 --> Config Class Initialized
DEBUG - 2012-07-18 16:59:16 --> Hooks Class Initialized
DEBUG - 2012-07-18 16:59:16 --> Utf8 Class Initialized
DEBUG - 2012-07-18 16:59:16 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 16:59:16 --> URI Class Initialized
DEBUG - 2012-07-18 16:59:16 --> Router Class Initialized
DEBUG - 2012-07-18 16:59:16 --> Output Class Initialized
DEBUG - 2012-07-18 16:59:16 --> Security Class Initialized
DEBUG - 2012-07-18 16:59:16 --> Input Class Initialized
DEBUG - 2012-07-18 16:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 16:59:16 --> Language Class Initialized
DEBUG - 2012-07-18 16:59:16 --> Loader Class Initialized
DEBUG - 2012-07-18 16:59:16 --> Helper loaded: url_helper
DEBUG - 2012-07-18 16:59:16 --> Controller Class Initialized
DEBUG - 2012-07-18 16:59:16 --> Model Class Initialized
DEBUG - 2012-07-18 16:59:16 --> Database Driver Class Initialized
DEBUG - 2012-07-18 16:59:16 --> Upload Class Initialized
DEBUG - 2012-07-18 17:01:12 --> Config Class Initialized
DEBUG - 2012-07-18 17:01:12 --> Hooks Class Initialized
DEBUG - 2012-07-18 17:01:12 --> Utf8 Class Initialized
DEBUG - 2012-07-18 17:01:12 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 17:01:12 --> URI Class Initialized
DEBUG - 2012-07-18 17:01:12 --> Router Class Initialized
DEBUG - 2012-07-18 17:01:12 --> Output Class Initialized
DEBUG - 2012-07-18 17:01:12 --> Security Class Initialized
DEBUG - 2012-07-18 17:01:12 --> Input Class Initialized
DEBUG - 2012-07-18 17:01:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 17:01:12 --> Language Class Initialized
DEBUG - 2012-07-18 17:01:12 --> Loader Class Initialized
DEBUG - 2012-07-18 17:01:12 --> Helper loaded: url_helper
DEBUG - 2012-07-18 17:01:12 --> Controller Class Initialized
DEBUG - 2012-07-18 17:01:12 --> Model Class Initialized
DEBUG - 2012-07-18 17:01:12 --> Database Driver Class Initialized
DEBUG - 2012-07-18 17:01:12 --> Upload Class Initialized
DEBUG - 2012-07-18 17:01:12 --> Helper loaded: form_helper
DEBUG - 2012-07-18 17:01:12 --> Helper loaded: language_helper
DEBUG - 2012-07-18 17:01:12 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-18 17:01:12 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-18 17:01:12 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-18 17:01:12 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-18 17:01:12 --> File loaded: application/views/admin/pages/logo.php
DEBUG - 2012-07-18 17:01:12 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-18 17:01:12 --> Final output sent to browser
DEBUG - 2012-07-18 17:01:12 --> Total execution time: 0.0950
DEBUG - 2012-07-18 17:04:35 --> Config Class Initialized
DEBUG - 2012-07-18 17:04:35 --> Hooks Class Initialized
DEBUG - 2012-07-18 17:04:35 --> Utf8 Class Initialized
DEBUG - 2012-07-18 17:04:35 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 17:04:35 --> URI Class Initialized
DEBUG - 2012-07-18 17:04:35 --> Router Class Initialized
DEBUG - 2012-07-18 17:04:35 --> Output Class Initialized
DEBUG - 2012-07-18 17:04:35 --> Security Class Initialized
DEBUG - 2012-07-18 17:04:35 --> Input Class Initialized
DEBUG - 2012-07-18 17:04:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 17:04:35 --> Language Class Initialized
DEBUG - 2012-07-18 17:04:35 --> Loader Class Initialized
DEBUG - 2012-07-18 17:04:35 --> Helper loaded: url_helper
DEBUG - 2012-07-18 17:04:35 --> Controller Class Initialized
DEBUG - 2012-07-18 17:04:35 --> Model Class Initialized
DEBUG - 2012-07-18 17:04:35 --> Database Driver Class Initialized
DEBUG - 2012-07-18 17:04:35 --> Upload Class Initialized
DEBUG - 2012-07-18 17:05:12 --> Config Class Initialized
DEBUG - 2012-07-18 17:05:12 --> Hooks Class Initialized
DEBUG - 2012-07-18 17:05:12 --> Utf8 Class Initialized
DEBUG - 2012-07-18 17:05:12 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 17:05:12 --> URI Class Initialized
DEBUG - 2012-07-18 17:05:12 --> Router Class Initialized
DEBUG - 2012-07-18 17:05:12 --> Output Class Initialized
DEBUG - 2012-07-18 17:05:12 --> Security Class Initialized
DEBUG - 2012-07-18 17:05:12 --> Input Class Initialized
DEBUG - 2012-07-18 17:05:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 17:05:12 --> Language Class Initialized
DEBUG - 2012-07-18 17:05:12 --> Loader Class Initialized
DEBUG - 2012-07-18 17:05:12 --> Helper loaded: url_helper
DEBUG - 2012-07-18 17:05:12 --> Controller Class Initialized
DEBUG - 2012-07-18 17:05:12 --> Model Class Initialized
DEBUG - 2012-07-18 17:05:12 --> Database Driver Class Initialized
DEBUG - 2012-07-18 17:05:12 --> Upload Class Initialized
DEBUG - 2012-07-18 17:08:53 --> Config Class Initialized
DEBUG - 2012-07-18 17:08:53 --> Hooks Class Initialized
DEBUG - 2012-07-18 17:08:53 --> Utf8 Class Initialized
DEBUG - 2012-07-18 17:08:53 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 17:08:53 --> URI Class Initialized
DEBUG - 2012-07-18 17:08:53 --> Router Class Initialized
DEBUG - 2012-07-18 17:08:53 --> Output Class Initialized
DEBUG - 2012-07-18 17:08:53 --> Security Class Initialized
DEBUG - 2012-07-18 17:08:53 --> Input Class Initialized
DEBUG - 2012-07-18 17:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 17:08:53 --> Language Class Initialized
DEBUG - 2012-07-18 17:08:53 --> Loader Class Initialized
DEBUG - 2012-07-18 17:08:53 --> Helper loaded: url_helper
DEBUG - 2012-07-18 17:08:53 --> Controller Class Initialized
DEBUG - 2012-07-18 17:08:53 --> Model Class Initialized
DEBUG - 2012-07-18 17:08:53 --> Database Driver Class Initialized
DEBUG - 2012-07-18 17:08:53 --> Upload Class Initialized
ERROR - 2012-07-18 17:08:53 --> Severity: Notice  --> Undefined variable: db /home/jwp/www/justinwylliephotography.com/clients/application/models/business_model.php 81
DEBUG - 2012-07-18 17:09:45 --> Config Class Initialized
DEBUG - 2012-07-18 17:09:45 --> Hooks Class Initialized
DEBUG - 2012-07-18 17:09:45 --> Utf8 Class Initialized
DEBUG - 2012-07-18 17:09:45 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 17:09:45 --> URI Class Initialized
DEBUG - 2012-07-18 17:09:45 --> Router Class Initialized
DEBUG - 2012-07-18 17:09:45 --> Output Class Initialized
DEBUG - 2012-07-18 17:09:45 --> Security Class Initialized
DEBUG - 2012-07-18 17:09:45 --> Input Class Initialized
DEBUG - 2012-07-18 17:09:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 17:09:45 --> Language Class Initialized
DEBUG - 2012-07-18 17:09:45 --> Loader Class Initialized
DEBUG - 2012-07-18 17:09:45 --> Helper loaded: url_helper
DEBUG - 2012-07-18 17:09:45 --> Controller Class Initialized
DEBUG - 2012-07-18 17:09:45 --> Model Class Initialized
DEBUG - 2012-07-18 17:09:45 --> Database Driver Class Initialized
DEBUG - 2012-07-18 17:09:45 --> Upload Class Initialized
DEBUG - 2012-07-18 17:10:40 --> Config Class Initialized
DEBUG - 2012-07-18 17:10:40 --> Hooks Class Initialized
DEBUG - 2012-07-18 17:10:40 --> Utf8 Class Initialized
DEBUG - 2012-07-18 17:10:40 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 17:10:40 --> URI Class Initialized
DEBUG - 2012-07-18 17:10:40 --> Router Class Initialized
DEBUG - 2012-07-18 17:10:40 --> Output Class Initialized
DEBUG - 2012-07-18 17:10:40 --> Security Class Initialized
DEBUG - 2012-07-18 17:10:40 --> Input Class Initialized
DEBUG - 2012-07-18 17:10:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 17:10:40 --> Language Class Initialized
DEBUG - 2012-07-18 17:10:40 --> Loader Class Initialized
DEBUG - 2012-07-18 17:10:40 --> Helper loaded: url_helper
DEBUG - 2012-07-18 17:10:40 --> Controller Class Initialized
DEBUG - 2012-07-18 17:10:40 --> Model Class Initialized
DEBUG - 2012-07-18 17:10:40 --> Database Driver Class Initialized
DEBUG - 2012-07-18 17:10:40 --> Upload Class Initialized
DEBUG - 2012-07-18 17:10:40 --> Helper loaded: form_helper
DEBUG - 2012-07-18 17:10:40 --> Helper loaded: language_helper
DEBUG - 2012-07-18 17:10:40 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-18 17:10:40 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-18 17:10:40 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-18 17:10:40 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-18 17:13:08 --> Config Class Initialized
DEBUG - 2012-07-18 17:13:08 --> Hooks Class Initialized
DEBUG - 2012-07-18 17:13:08 --> Utf8 Class Initialized
DEBUG - 2012-07-18 17:13:08 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 17:13:08 --> URI Class Initialized
DEBUG - 2012-07-18 17:13:08 --> Router Class Initialized
DEBUG - 2012-07-18 17:13:08 --> Output Class Initialized
DEBUG - 2012-07-18 17:13:08 --> Security Class Initialized
DEBUG - 2012-07-18 17:13:08 --> Input Class Initialized
DEBUG - 2012-07-18 17:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 17:13:08 --> Language Class Initialized
DEBUG - 2012-07-18 17:13:08 --> Loader Class Initialized
DEBUG - 2012-07-18 17:13:08 --> Helper loaded: url_helper
DEBUG - 2012-07-18 17:13:08 --> Controller Class Initialized
DEBUG - 2012-07-18 17:13:08 --> Model Class Initialized
DEBUG - 2012-07-18 17:13:08 --> Database Driver Class Initialized
DEBUG - 2012-07-18 17:13:08 --> Upload Class Initialized
DEBUG - 2012-07-18 17:13:08 --> Helper loaded: language_helper
DEBUG - 2012-07-18 17:13:08 --> Helper loaded: html_helper
DEBUG - 2012-07-18 17:13:08 --> Helper loaded: form_helper
DEBUG - 2012-07-18 17:13:08 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-18 17:13:08 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-18 17:13:08 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-18 17:13:08 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-18 17:13:08 --> File loaded: application/views/admin/pages/logo.php
DEBUG - 2012-07-18 17:13:08 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-18 17:13:08 --> Final output sent to browser
DEBUG - 2012-07-18 17:13:08 --> Total execution time: 0.1805
DEBUG - 2012-07-18 17:13:09 --> Config Class Initialized
DEBUG - 2012-07-18 17:13:09 --> Hooks Class Initialized
DEBUG - 2012-07-18 17:13:09 --> Utf8 Class Initialized
DEBUG - 2012-07-18 17:13:09 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 17:13:09 --> URI Class Initialized
DEBUG - 2012-07-18 17:13:09 --> Router Class Initialized
ERROR - 2012-07-18 17:13:09 --> 404 Page Not Found --> images
DEBUG - 2012-07-18 17:13:59 --> Config Class Initialized
DEBUG - 2012-07-18 17:13:59 --> Hooks Class Initialized
DEBUG - 2012-07-18 17:13:59 --> Utf8 Class Initialized
DEBUG - 2012-07-18 17:13:59 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 17:13:59 --> URI Class Initialized
DEBUG - 2012-07-18 17:13:59 --> Router Class Initialized
DEBUG - 2012-07-18 17:13:59 --> Output Class Initialized
DEBUG - 2012-07-18 17:13:59 --> Security Class Initialized
DEBUG - 2012-07-18 17:13:59 --> Input Class Initialized
DEBUG - 2012-07-18 17:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 17:13:59 --> Language Class Initialized
DEBUG - 2012-07-18 17:13:59 --> Loader Class Initialized
DEBUG - 2012-07-18 17:13:59 --> Helper loaded: url_helper
DEBUG - 2012-07-18 17:13:59 --> Controller Class Initialized
DEBUG - 2012-07-18 17:13:59 --> Model Class Initialized
DEBUG - 2012-07-18 17:13:59 --> Database Driver Class Initialized
DEBUG - 2012-07-18 17:13:59 --> Helper loaded: language_helper
DEBUG - 2012-07-18 17:13:59 --> Helper loaded: html_helper
DEBUG - 2012-07-18 17:13:59 --> Helper loaded: form_helper
DEBUG - 2012-07-18 17:13:59 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-18 17:13:59 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-18 17:13:59 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-18 17:13:59 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-18 17:13:59 --> File loaded: application/views/admin/pages/logo.php
DEBUG - 2012-07-18 17:13:59 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-18 17:13:59 --> Final output sent to browser
DEBUG - 2012-07-18 17:13:59 --> Total execution time: 0.0412
DEBUG - 2012-07-18 17:15:01 --> Config Class Initialized
DEBUG - 2012-07-18 17:15:01 --> Hooks Class Initialized
DEBUG - 2012-07-18 17:15:01 --> Utf8 Class Initialized
DEBUG - 2012-07-18 17:15:01 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 17:15:01 --> URI Class Initialized
DEBUG - 2012-07-18 17:15:01 --> Router Class Initialized
DEBUG - 2012-07-18 17:15:01 --> Output Class Initialized
DEBUG - 2012-07-18 17:15:01 --> Security Class Initialized
DEBUG - 2012-07-18 17:15:01 --> Input Class Initialized
DEBUG - 2012-07-18 17:15:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 17:15:01 --> Language Class Initialized
DEBUG - 2012-07-18 17:15:01 --> Loader Class Initialized
DEBUG - 2012-07-18 17:15:01 --> Helper loaded: url_helper
DEBUG - 2012-07-18 17:15:01 --> Controller Class Initialized
DEBUG - 2012-07-18 17:15:01 --> Model Class Initialized
DEBUG - 2012-07-18 17:15:01 --> Database Driver Class Initialized
DEBUG - 2012-07-18 17:15:01 --> Helper loaded: language_helper
DEBUG - 2012-07-18 17:15:01 --> Helper loaded: html_helper
DEBUG - 2012-07-18 17:15:01 --> Helper loaded: form_helper
DEBUG - 2012-07-18 17:15:01 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-18 17:15:01 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-18 17:15:01 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-18 17:15:01 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-18 17:15:01 --> File loaded: application/views/admin/pages/logo.php
DEBUG - 2012-07-18 17:15:01 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-18 17:15:01 --> Final output sent to browser
DEBUG - 2012-07-18 17:15:01 --> Total execution time: 0.0437
DEBUG - 2012-07-18 20:44:32 --> Config Class Initialized
DEBUG - 2012-07-18 20:44:32 --> Hooks Class Initialized
DEBUG - 2012-07-18 20:44:32 --> Utf8 Class Initialized
DEBUG - 2012-07-18 20:44:32 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 20:44:32 --> URI Class Initialized
DEBUG - 2012-07-18 20:44:32 --> Router Class Initialized
DEBUG - 2012-07-18 20:44:32 --> Output Class Initialized
DEBUG - 2012-07-18 20:44:32 --> Security Class Initialized
DEBUG - 2012-07-18 20:44:32 --> Input Class Initialized
DEBUG - 2012-07-18 20:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 20:44:32 --> Language Class Initialized
DEBUG - 2012-07-18 20:44:32 --> Loader Class Initialized
DEBUG - 2012-07-18 20:44:32 --> Helper loaded: url_helper
DEBUG - 2012-07-18 20:44:32 --> Controller Class Initialized
DEBUG - 2012-07-18 20:44:32 --> Model Class Initialized
DEBUG - 2012-07-18 20:44:32 --> Database Driver Class Initialized
DEBUG - 2012-07-18 20:44:32 --> Helper loaded: form_helper
DEBUG - 2012-07-18 20:44:32 --> Helper loaded: html_helper
DEBUG - 2012-07-18 20:44:32 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-18 20:44:32 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-18 20:44:32 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 20:44:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 20:44:32 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-18 20:44:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-18 20:44:32 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-18 20:44:32 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-18 20:44:32 --> Final output sent to browser
DEBUG - 2012-07-18 20:44:32 --> Total execution time: 0.0627
DEBUG - 2012-07-18 21:36:57 --> Config Class Initialized
DEBUG - 2012-07-18 21:36:57 --> Hooks Class Initialized
DEBUG - 2012-07-18 21:36:57 --> Utf8 Class Initialized
DEBUG - 2012-07-18 21:36:57 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 21:36:57 --> URI Class Initialized
DEBUG - 2012-07-18 21:36:57 --> Router Class Initialized
DEBUG - 2012-07-18 21:36:57 --> Output Class Initialized
DEBUG - 2012-07-18 21:36:57 --> Security Class Initialized
DEBUG - 2012-07-18 21:36:57 --> Input Class Initialized
DEBUG - 2012-07-18 21:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 21:36:57 --> Language Class Initialized
DEBUG - 2012-07-18 21:36:57 --> Loader Class Initialized
DEBUG - 2012-07-18 21:36:57 --> Helper loaded: url_helper
DEBUG - 2012-07-18 21:36:57 --> Controller Class Initialized
DEBUG - 2012-07-18 21:36:57 --> Model Class Initialized
DEBUG - 2012-07-18 21:36:57 --> Database Driver Class Initialized
DEBUG - 2012-07-18 21:36:57 --> Helper loaded: form_helper
DEBUG - 2012-07-18 21:36:57 --> Helper loaded: html_helper
DEBUG - 2012-07-18 21:36:57 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-18 21:36:57 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-18 21:36:57 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 21:36:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 21:36:57 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-18 21:36:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-18 21:36:57 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-18 21:36:57 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-18 21:36:57 --> Final output sent to browser
DEBUG - 2012-07-18 21:36:57 --> Total execution time: 0.0395
DEBUG - 2012-07-18 22:07:02 --> Config Class Initialized
DEBUG - 2012-07-18 22:07:02 --> Hooks Class Initialized
DEBUG - 2012-07-18 22:07:02 --> Utf8 Class Initialized
DEBUG - 2012-07-18 22:07:02 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 22:07:02 --> URI Class Initialized
DEBUG - 2012-07-18 22:07:02 --> Router Class Initialized
DEBUG - 2012-07-18 22:07:02 --> Output Class Initialized
DEBUG - 2012-07-18 22:07:02 --> Security Class Initialized
DEBUG - 2012-07-18 22:07:02 --> Input Class Initialized
DEBUG - 2012-07-18 22:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 22:07:02 --> Language Class Initialized
DEBUG - 2012-07-18 22:07:02 --> Loader Class Initialized
DEBUG - 2012-07-18 22:07:02 --> Helper loaded: url_helper
DEBUG - 2012-07-18 22:07:02 --> Controller Class Initialized
DEBUG - 2012-07-18 22:07:02 --> Model Class Initialized
DEBUG - 2012-07-18 22:07:02 --> Database Driver Class Initialized
DEBUG - 2012-07-18 22:07:02 --> Helper loaded: language_helper
DEBUG - 2012-07-18 22:07:02 --> Helper loaded: html_helper
DEBUG - 2012-07-18 22:07:02 --> Helper loaded: form_helper
DEBUG - 2012-07-18 22:07:02 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-18 22:07:02 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-18 22:07:02 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-18 22:07:02 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-18 22:07:02 --> File loaded: application/views/admin/pages/logo.php
DEBUG - 2012-07-18 22:07:02 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-18 22:07:02 --> Final output sent to browser
DEBUG - 2012-07-18 22:07:02 --> Total execution time: 0.0451
DEBUG - 2012-07-18 22:07:06 --> Config Class Initialized
DEBUG - 2012-07-18 22:07:06 --> Hooks Class Initialized
DEBUG - 2012-07-18 22:07:06 --> Utf8 Class Initialized
DEBUG - 2012-07-18 22:07:06 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 22:07:06 --> URI Class Initialized
DEBUG - 2012-07-18 22:07:06 --> Router Class Initialized
DEBUG - 2012-07-18 22:07:06 --> Output Class Initialized
DEBUG - 2012-07-18 22:07:06 --> Security Class Initialized
DEBUG - 2012-07-18 22:07:06 --> Input Class Initialized
DEBUG - 2012-07-18 22:07:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 22:07:06 --> Language Class Initialized
DEBUG - 2012-07-18 22:07:06 --> Loader Class Initialized
DEBUG - 2012-07-18 22:07:06 --> Helper loaded: url_helper
DEBUG - 2012-07-18 22:07:06 --> Controller Class Initialized
DEBUG - 2012-07-18 22:07:06 --> Model Class Initialized
DEBUG - 2012-07-18 22:07:06 --> Database Driver Class Initialized
DEBUG - 2012-07-18 22:07:06 --> Helper loaded: form_helper
DEBUG - 2012-07-18 22:07:06 --> Helper loaded: html_helper
DEBUG - 2012-07-18 22:07:06 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-18 22:07:06 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-18 22:07:06 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 22:07:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 22:07:06 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-18 22:07:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-18 22:07:06 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-18 22:07:06 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-18 22:07:06 --> Final output sent to browser
DEBUG - 2012-07-18 22:07:06 --> Total execution time: 0.0397
DEBUG - 2012-07-18 22:46:05 --> Config Class Initialized
DEBUG - 2012-07-18 22:46:05 --> Hooks Class Initialized
DEBUG - 2012-07-18 22:46:05 --> Utf8 Class Initialized
DEBUG - 2012-07-18 22:46:05 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 22:46:05 --> URI Class Initialized
DEBUG - 2012-07-18 22:46:05 --> Router Class Initialized
DEBUG - 2012-07-18 22:46:05 --> Output Class Initialized
DEBUG - 2012-07-18 22:46:05 --> Security Class Initialized
DEBUG - 2012-07-18 22:46:05 --> Input Class Initialized
DEBUG - 2012-07-18 22:46:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 22:46:05 --> Language Class Initialized
DEBUG - 2012-07-18 22:46:05 --> Loader Class Initialized
DEBUG - 2012-07-18 22:46:05 --> Helper loaded: url_helper
DEBUG - 2012-07-18 22:46:05 --> Controller Class Initialized
DEBUG - 2012-07-18 22:46:05 --> Model Class Initialized
DEBUG - 2012-07-18 22:46:05 --> Database Driver Class Initialized
DEBUG - 2012-07-18 22:46:05 --> Helper loaded: form_helper
DEBUG - 2012-07-18 22:46:05 --> Helper loaded: html_helper
DEBUG - 2012-07-18 22:46:05 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-18 22:46:05 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-18 22:46:05 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 22:46:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 22:46:05 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-18 22:46:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-18 22:46:05 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-18 22:46:05 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-18 22:46:05 --> Final output sent to browser
DEBUG - 2012-07-18 22:46:05 --> Total execution time: 0.0402
DEBUG - 2012-07-18 22:47:03 --> Config Class Initialized
DEBUG - 2012-07-18 22:47:03 --> Hooks Class Initialized
DEBUG - 2012-07-18 22:47:03 --> Utf8 Class Initialized
DEBUG - 2012-07-18 22:47:03 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 22:47:03 --> URI Class Initialized
DEBUG - 2012-07-18 22:47:03 --> Router Class Initialized
DEBUG - 2012-07-18 22:47:03 --> Output Class Initialized
DEBUG - 2012-07-18 22:47:03 --> Security Class Initialized
DEBUG - 2012-07-18 22:47:03 --> Input Class Initialized
DEBUG - 2012-07-18 22:47:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 22:47:03 --> Language Class Initialized
DEBUG - 2012-07-18 22:47:03 --> Loader Class Initialized
DEBUG - 2012-07-18 22:47:03 --> Helper loaded: url_helper
DEBUG - 2012-07-18 22:47:03 --> Controller Class Initialized
DEBUG - 2012-07-18 22:47:03 --> Model Class Initialized
DEBUG - 2012-07-18 22:47:03 --> Database Driver Class Initialized
DEBUG - 2012-07-18 22:47:03 --> Helper loaded: form_helper
DEBUG - 2012-07-18 22:47:03 --> Helper loaded: html_helper
DEBUG - 2012-07-18 22:47:03 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-18 22:47:03 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-18 22:47:03 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 22:47:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 22:47:03 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-18 22:47:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-18 22:47:03 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-18 22:47:03 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-18 22:47:03 --> Final output sent to browser
DEBUG - 2012-07-18 22:47:03 --> Total execution time: 0.0476
DEBUG - 2012-07-18 22:47:06 --> Config Class Initialized
DEBUG - 2012-07-18 22:47:06 --> Hooks Class Initialized
DEBUG - 2012-07-18 22:47:06 --> Utf8 Class Initialized
DEBUG - 2012-07-18 22:47:06 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 22:47:06 --> URI Class Initialized
DEBUG - 2012-07-18 22:47:06 --> Router Class Initialized
DEBUG - 2012-07-18 22:47:06 --> Output Class Initialized
DEBUG - 2012-07-18 22:47:06 --> Security Class Initialized
DEBUG - 2012-07-18 22:47:06 --> Input Class Initialized
DEBUG - 2012-07-18 22:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 22:47:06 --> Language Class Initialized
DEBUG - 2012-07-18 22:47:06 --> Loader Class Initialized
DEBUG - 2012-07-18 22:47:06 --> Helper loaded: url_helper
DEBUG - 2012-07-18 22:47:06 --> Controller Class Initialized
DEBUG - 2012-07-18 22:47:06 --> Model Class Initialized
DEBUG - 2012-07-18 22:47:06 --> Database Driver Class Initialized
DEBUG - 2012-07-18 22:47:06 --> Helper loaded: form_helper
DEBUG - 2012-07-18 22:47:06 --> Helper loaded: html_helper
DEBUG - 2012-07-18 22:47:06 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-18 22:47:06 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-18 22:47:06 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 22:47:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 22:47:06 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-18 22:47:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-18 22:47:06 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-18 22:47:06 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-18 22:47:06 --> Final output sent to browser
DEBUG - 2012-07-18 22:47:06 --> Total execution time: 0.0399
DEBUG - 2012-07-18 23:40:02 --> Config Class Initialized
DEBUG - 2012-07-18 23:40:02 --> Hooks Class Initialized
DEBUG - 2012-07-18 23:40:02 --> Utf8 Class Initialized
DEBUG - 2012-07-18 23:40:02 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 23:40:02 --> URI Class Initialized
DEBUG - 2012-07-18 23:40:02 --> Router Class Initialized
DEBUG - 2012-07-18 23:40:02 --> Output Class Initialized
DEBUG - 2012-07-18 23:40:02 --> Security Class Initialized
DEBUG - 2012-07-18 23:40:02 --> Input Class Initialized
DEBUG - 2012-07-18 23:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 23:40:02 --> Language Class Initialized
DEBUG - 2012-07-18 23:40:02 --> Loader Class Initialized
DEBUG - 2012-07-18 23:40:02 --> Helper loaded: url_helper
DEBUG - 2012-07-18 23:40:02 --> Controller Class Initialized
DEBUG - 2012-07-18 23:40:02 --> Model Class Initialized
DEBUG - 2012-07-18 23:40:02 --> Database Driver Class Initialized
DEBUG - 2012-07-18 23:40:02 --> Helper loaded: form_helper
DEBUG - 2012-07-18 23:40:02 --> Helper loaded: html_helper
DEBUG - 2012-07-18 23:40:02 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-18 23:40:02 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-18 23:40:02 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 23:40:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 23:40:02 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-18 23:40:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-18 23:40:02 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-18 23:40:02 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-18 23:40:02 --> Final output sent to browser
DEBUG - 2012-07-18 23:40:02 --> Total execution time: 0.0413
DEBUG - 2012-07-18 23:41:23 --> Config Class Initialized
DEBUG - 2012-07-18 23:41:23 --> Hooks Class Initialized
DEBUG - 2012-07-18 23:41:23 --> Utf8 Class Initialized
DEBUG - 2012-07-18 23:41:23 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 23:41:23 --> URI Class Initialized
DEBUG - 2012-07-18 23:41:23 --> Router Class Initialized
DEBUG - 2012-07-18 23:41:23 --> Output Class Initialized
DEBUG - 2012-07-18 23:41:23 --> Security Class Initialized
DEBUG - 2012-07-18 23:41:23 --> Input Class Initialized
DEBUG - 2012-07-18 23:41:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 23:41:23 --> Language Class Initialized
DEBUG - 2012-07-18 23:41:23 --> Loader Class Initialized
DEBUG - 2012-07-18 23:41:23 --> Helper loaded: url_helper
DEBUG - 2012-07-18 23:41:23 --> Controller Class Initialized
DEBUG - 2012-07-18 23:41:23 --> Model Class Initialized
DEBUG - 2012-07-18 23:41:23 --> Database Driver Class Initialized
DEBUG - 2012-07-18 23:41:23 --> Helper loaded: form_helper
DEBUG - 2012-07-18 23:41:23 --> Helper loaded: html_helper
DEBUG - 2012-07-18 23:41:23 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-18 23:41:23 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-18 23:41:23 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 23:41:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 23:41:23 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-18 23:41:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-18 23:41:23 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-18 23:41:23 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-18 23:41:23 --> Final output sent to browser
DEBUG - 2012-07-18 23:41:23 --> Total execution time: 0.0404
DEBUG - 2012-07-18 23:41:50 --> Config Class Initialized
DEBUG - 2012-07-18 23:41:50 --> Hooks Class Initialized
DEBUG - 2012-07-18 23:41:50 --> Utf8 Class Initialized
DEBUG - 2012-07-18 23:41:50 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 23:41:50 --> URI Class Initialized
DEBUG - 2012-07-18 23:41:50 --> Router Class Initialized
DEBUG - 2012-07-18 23:41:50 --> Output Class Initialized
DEBUG - 2012-07-18 23:41:50 --> Security Class Initialized
DEBUG - 2012-07-18 23:41:50 --> Input Class Initialized
DEBUG - 2012-07-18 23:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 23:41:50 --> Language Class Initialized
DEBUG - 2012-07-18 23:41:50 --> Loader Class Initialized
DEBUG - 2012-07-18 23:41:50 --> Helper loaded: url_helper
DEBUG - 2012-07-18 23:41:50 --> Controller Class Initialized
DEBUG - 2012-07-18 23:41:50 --> Model Class Initialized
DEBUG - 2012-07-18 23:41:50 --> Database Driver Class Initialized
DEBUG - 2012-07-18 23:41:50 --> Helper loaded: form_helper
DEBUG - 2012-07-18 23:41:50 --> Helper loaded: html_helper
DEBUG - 2012-07-18 23:41:50 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-18 23:41:50 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-18 23:41:50 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 23:41:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 23:41:50 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-18 23:41:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-18 23:41:50 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-18 23:41:50 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-18 23:41:50 --> Final output sent to browser
DEBUG - 2012-07-18 23:41:50 --> Total execution time: 0.0399
DEBUG - 2012-07-18 23:42:06 --> Config Class Initialized
DEBUG - 2012-07-18 23:42:06 --> Hooks Class Initialized
DEBUG - 2012-07-18 23:42:06 --> Utf8 Class Initialized
DEBUG - 2012-07-18 23:42:06 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 23:42:06 --> URI Class Initialized
DEBUG - 2012-07-18 23:42:06 --> Router Class Initialized
DEBUG - 2012-07-18 23:42:06 --> Output Class Initialized
DEBUG - 2012-07-18 23:42:06 --> Security Class Initialized
DEBUG - 2012-07-18 23:42:06 --> Input Class Initialized
DEBUG - 2012-07-18 23:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 23:42:06 --> Language Class Initialized
DEBUG - 2012-07-18 23:42:06 --> Loader Class Initialized
DEBUG - 2012-07-18 23:42:06 --> Helper loaded: url_helper
DEBUG - 2012-07-18 23:42:06 --> Controller Class Initialized
DEBUG - 2012-07-18 23:42:06 --> Model Class Initialized
DEBUG - 2012-07-18 23:42:07 --> Database Driver Class Initialized
DEBUG - 2012-07-18 23:42:07 --> Helper loaded: form_helper
DEBUG - 2012-07-18 23:42:07 --> Helper loaded: html_helper
DEBUG - 2012-07-18 23:42:07 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-18 23:42:07 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-18 23:42:07 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 23:42:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 23:42:07 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-18 23:42:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-18 23:42:07 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-18 23:42:07 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-18 23:42:07 --> Final output sent to browser
DEBUG - 2012-07-18 23:42:07 --> Total execution time: 0.0395
DEBUG - 2012-07-18 23:42:32 --> Config Class Initialized
DEBUG - 2012-07-18 23:42:32 --> Hooks Class Initialized
DEBUG - 2012-07-18 23:42:32 --> Utf8 Class Initialized
DEBUG - 2012-07-18 23:42:32 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 23:42:32 --> URI Class Initialized
DEBUG - 2012-07-18 23:42:32 --> Router Class Initialized
DEBUG - 2012-07-18 23:42:32 --> Output Class Initialized
DEBUG - 2012-07-18 23:42:32 --> Security Class Initialized
DEBUG - 2012-07-18 23:42:32 --> Input Class Initialized
DEBUG - 2012-07-18 23:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 23:42:32 --> Language Class Initialized
DEBUG - 2012-07-18 23:42:32 --> Loader Class Initialized
DEBUG - 2012-07-18 23:42:32 --> Helper loaded: url_helper
DEBUG - 2012-07-18 23:42:32 --> Controller Class Initialized
DEBUG - 2012-07-18 23:42:32 --> Model Class Initialized
DEBUG - 2012-07-18 23:42:32 --> Database Driver Class Initialized
DEBUG - 2012-07-18 23:42:32 --> Helper loaded: form_helper
DEBUG - 2012-07-18 23:42:32 --> Helper loaded: html_helper
DEBUG - 2012-07-18 23:42:32 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-18 23:42:32 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-18 23:42:32 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 23:42:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 23:42:32 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-18 23:42:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-18 23:42:32 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-18 23:42:32 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-18 23:42:32 --> Final output sent to browser
DEBUG - 2012-07-18 23:42:32 --> Total execution time: 0.0401
DEBUG - 2012-07-18 23:42:42 --> Config Class Initialized
DEBUG - 2012-07-18 23:42:42 --> Hooks Class Initialized
DEBUG - 2012-07-18 23:42:42 --> Utf8 Class Initialized
DEBUG - 2012-07-18 23:42:42 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 23:42:42 --> URI Class Initialized
DEBUG - 2012-07-18 23:42:42 --> Router Class Initialized
DEBUG - 2012-07-18 23:42:42 --> Output Class Initialized
DEBUG - 2012-07-18 23:42:42 --> Security Class Initialized
DEBUG - 2012-07-18 23:42:42 --> Input Class Initialized
DEBUG - 2012-07-18 23:42:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 23:42:42 --> Language Class Initialized
DEBUG - 2012-07-18 23:42:42 --> Loader Class Initialized
DEBUG - 2012-07-18 23:42:42 --> Helper loaded: url_helper
DEBUG - 2012-07-18 23:42:42 --> Controller Class Initialized
DEBUG - 2012-07-18 23:42:42 --> Model Class Initialized
DEBUG - 2012-07-18 23:42:42 --> Database Driver Class Initialized
DEBUG - 2012-07-18 23:42:42 --> Helper loaded: form_helper
DEBUG - 2012-07-18 23:42:42 --> Helper loaded: html_helper
DEBUG - 2012-07-18 23:42:42 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-18 23:42:42 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-18 23:42:42 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 23:42:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 23:42:42 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-18 23:42:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-18 23:42:42 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-18 23:42:42 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-18 23:42:42 --> Final output sent to browser
DEBUG - 2012-07-18 23:42:42 --> Total execution time: 0.0407
DEBUG - 2012-07-18 23:44:34 --> Config Class Initialized
DEBUG - 2012-07-18 23:44:34 --> Hooks Class Initialized
DEBUG - 2012-07-18 23:44:34 --> Utf8 Class Initialized
DEBUG - 2012-07-18 23:44:34 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 23:44:34 --> URI Class Initialized
DEBUG - 2012-07-18 23:44:34 --> Router Class Initialized
DEBUG - 2012-07-18 23:44:34 --> Output Class Initialized
DEBUG - 2012-07-18 23:44:34 --> Security Class Initialized
DEBUG - 2012-07-18 23:44:34 --> Input Class Initialized
DEBUG - 2012-07-18 23:44:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 23:44:34 --> Language Class Initialized
DEBUG - 2012-07-18 23:44:34 --> Loader Class Initialized
DEBUG - 2012-07-18 23:44:34 --> Helper loaded: url_helper
DEBUG - 2012-07-18 23:44:34 --> Controller Class Initialized
DEBUG - 2012-07-18 23:44:34 --> Model Class Initialized
DEBUG - 2012-07-18 23:44:34 --> Database Driver Class Initialized
DEBUG - 2012-07-18 23:44:34 --> Helper loaded: form_helper
DEBUG - 2012-07-18 23:44:34 --> Helper loaded: html_helper
DEBUG - 2012-07-18 23:44:34 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-18 23:44:34 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-18 23:44:34 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 23:44:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 23:44:34 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-18 23:44:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-18 23:44:34 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-18 23:44:34 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-18 23:44:34 --> Final output sent to browser
DEBUG - 2012-07-18 23:44:34 --> Total execution time: 0.0476
DEBUG - 2012-07-18 23:44:52 --> Config Class Initialized
DEBUG - 2012-07-18 23:44:52 --> Hooks Class Initialized
DEBUG - 2012-07-18 23:44:52 --> Utf8 Class Initialized
DEBUG - 2012-07-18 23:44:52 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 23:44:52 --> URI Class Initialized
DEBUG - 2012-07-18 23:44:52 --> Router Class Initialized
DEBUG - 2012-07-18 23:44:52 --> Output Class Initialized
DEBUG - 2012-07-18 23:44:52 --> Security Class Initialized
DEBUG - 2012-07-18 23:44:52 --> Input Class Initialized
DEBUG - 2012-07-18 23:44:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 23:44:52 --> Language Class Initialized
DEBUG - 2012-07-18 23:44:52 --> Loader Class Initialized
DEBUG - 2012-07-18 23:44:52 --> Helper loaded: url_helper
DEBUG - 2012-07-18 23:44:52 --> Controller Class Initialized
DEBUG - 2012-07-18 23:44:52 --> Model Class Initialized
DEBUG - 2012-07-18 23:44:52 --> Database Driver Class Initialized
DEBUG - 2012-07-18 23:44:52 --> Helper loaded: form_helper
DEBUG - 2012-07-18 23:44:52 --> Helper loaded: html_helper
DEBUG - 2012-07-18 23:44:52 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-18 23:44:52 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-18 23:44:52 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 23:44:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 23:44:52 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-18 23:44:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-18 23:44:52 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-18 23:44:52 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-18 23:44:52 --> Final output sent to browser
DEBUG - 2012-07-18 23:44:52 --> Total execution time: 0.0483
DEBUG - 2012-07-18 23:45:29 --> Config Class Initialized
DEBUG - 2012-07-18 23:45:29 --> Hooks Class Initialized
DEBUG - 2012-07-18 23:45:29 --> Utf8 Class Initialized
DEBUG - 2012-07-18 23:45:29 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 23:45:29 --> URI Class Initialized
DEBUG - 2012-07-18 23:45:29 --> Router Class Initialized
DEBUG - 2012-07-18 23:45:29 --> Output Class Initialized
DEBUG - 2012-07-18 23:45:29 --> Security Class Initialized
DEBUG - 2012-07-18 23:45:29 --> Input Class Initialized
DEBUG - 2012-07-18 23:45:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 23:45:29 --> Language Class Initialized
DEBUG - 2012-07-18 23:45:29 --> Loader Class Initialized
DEBUG - 2012-07-18 23:45:29 --> Helper loaded: url_helper
DEBUG - 2012-07-18 23:45:29 --> Controller Class Initialized
DEBUG - 2012-07-18 23:45:29 --> Model Class Initialized
DEBUG - 2012-07-18 23:45:29 --> Database Driver Class Initialized
DEBUG - 2012-07-18 23:45:29 --> Helper loaded: form_helper
DEBUG - 2012-07-18 23:45:29 --> Helper loaded: html_helper
DEBUG - 2012-07-18 23:45:29 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-18 23:45:29 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-18 23:45:29 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 23:45:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 23:45:29 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-18 23:45:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-18 23:45:29 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-18 23:45:29 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-18 23:45:29 --> Final output sent to browser
DEBUG - 2012-07-18 23:45:29 --> Total execution time: 0.0395
DEBUG - 2012-07-18 23:45:47 --> Config Class Initialized
DEBUG - 2012-07-18 23:45:47 --> Hooks Class Initialized
DEBUG - 2012-07-18 23:45:47 --> Utf8 Class Initialized
DEBUG - 2012-07-18 23:45:47 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 23:45:47 --> URI Class Initialized
DEBUG - 2012-07-18 23:45:47 --> Router Class Initialized
DEBUG - 2012-07-18 23:45:47 --> Output Class Initialized
DEBUG - 2012-07-18 23:45:47 --> Security Class Initialized
DEBUG - 2012-07-18 23:45:47 --> Input Class Initialized
DEBUG - 2012-07-18 23:45:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 23:45:47 --> Language Class Initialized
DEBUG - 2012-07-18 23:45:47 --> Loader Class Initialized
DEBUG - 2012-07-18 23:45:47 --> Helper loaded: url_helper
DEBUG - 2012-07-18 23:45:47 --> Controller Class Initialized
DEBUG - 2012-07-18 23:45:47 --> Model Class Initialized
DEBUG - 2012-07-18 23:45:47 --> Database Driver Class Initialized
DEBUG - 2012-07-18 23:45:47 --> Helper loaded: form_helper
DEBUG - 2012-07-18 23:45:47 --> Helper loaded: html_helper
DEBUG - 2012-07-18 23:45:47 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-18 23:45:47 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-18 23:45:47 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 23:45:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 23:45:47 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-18 23:45:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-18 23:45:47 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-18 23:45:47 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-18 23:45:47 --> Final output sent to browser
DEBUG - 2012-07-18 23:45:47 --> Total execution time: 0.0396
DEBUG - 2012-07-18 23:46:40 --> Config Class Initialized
DEBUG - 2012-07-18 23:46:40 --> Hooks Class Initialized
DEBUG - 2012-07-18 23:46:40 --> Utf8 Class Initialized
DEBUG - 2012-07-18 23:46:40 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 23:46:40 --> URI Class Initialized
DEBUG - 2012-07-18 23:46:40 --> Router Class Initialized
DEBUG - 2012-07-18 23:46:40 --> Output Class Initialized
DEBUG - 2012-07-18 23:46:40 --> Security Class Initialized
DEBUG - 2012-07-18 23:46:40 --> Input Class Initialized
DEBUG - 2012-07-18 23:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 23:46:40 --> Language Class Initialized
DEBUG - 2012-07-18 23:46:40 --> Loader Class Initialized
DEBUG - 2012-07-18 23:46:40 --> Helper loaded: url_helper
DEBUG - 2012-07-18 23:46:40 --> Controller Class Initialized
DEBUG - 2012-07-18 23:46:40 --> Model Class Initialized
DEBUG - 2012-07-18 23:46:40 --> Database Driver Class Initialized
DEBUG - 2012-07-18 23:46:40 --> Helper loaded: form_helper
DEBUG - 2012-07-18 23:46:40 --> Helper loaded: html_helper
DEBUG - 2012-07-18 23:46:40 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-18 23:46:40 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-18 23:46:40 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 23:46:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 23:46:40 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-18 23:46:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-18 23:46:40 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-18 23:46:40 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-18 23:46:40 --> Final output sent to browser
DEBUG - 2012-07-18 23:46:40 --> Total execution time: 0.0406
DEBUG - 2012-07-18 23:47:01 --> Config Class Initialized
DEBUG - 2012-07-18 23:47:01 --> Hooks Class Initialized
DEBUG - 2012-07-18 23:47:01 --> Utf8 Class Initialized
DEBUG - 2012-07-18 23:47:01 --> UTF-8 Support Disabled
DEBUG - 2012-07-18 23:47:01 --> URI Class Initialized
DEBUG - 2012-07-18 23:47:01 --> Router Class Initialized
DEBUG - 2012-07-18 23:47:01 --> Output Class Initialized
DEBUG - 2012-07-18 23:47:01 --> Security Class Initialized
DEBUG - 2012-07-18 23:47:01 --> Input Class Initialized
DEBUG - 2012-07-18 23:47:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-18 23:47:01 --> Language Class Initialized
DEBUG - 2012-07-18 23:47:01 --> Loader Class Initialized
DEBUG - 2012-07-18 23:47:01 --> Helper loaded: url_helper
DEBUG - 2012-07-18 23:47:01 --> Controller Class Initialized
DEBUG - 2012-07-18 23:47:01 --> Model Class Initialized
DEBUG - 2012-07-18 23:47:01 --> Database Driver Class Initialized
DEBUG - 2012-07-18 23:47:01 --> Helper loaded: form_helper
DEBUG - 2012-07-18 23:47:01 --> Helper loaded: html_helper
DEBUG - 2012-07-18 23:47:01 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-18 23:47:01 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-18 23:47:01 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 23:47:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-18 23:47:01 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-18 23:47:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-18 23:47:01 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-18 23:47:01 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-18 23:47:01 --> Final output sent to browser
DEBUG - 2012-07-18 23:47:01 --> Total execution time: 0.0443
