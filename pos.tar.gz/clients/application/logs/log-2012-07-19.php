<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-07-19 00:36:04 --> Config Class Initialized
DEBUG - 2012-07-19 00:36:04 --> Hooks Class Initialized
DEBUG - 2012-07-19 00:36:04 --> Utf8 Class Initialized
DEBUG - 2012-07-19 00:36:04 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 00:36:04 --> URI Class Initialized
DEBUG - 2012-07-19 00:36:04 --> Router Class Initialized
DEBUG - 2012-07-19 00:36:04 --> Output Class Initialized
DEBUG - 2012-07-19 00:36:04 --> Security Class Initialized
DEBUG - 2012-07-19 00:36:04 --> Input Class Initialized
DEBUG - 2012-07-19 00:36:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 00:36:04 --> Language Class Initialized
DEBUG - 2012-07-19 00:36:04 --> Loader Class Initialized
DEBUG - 2012-07-19 00:36:04 --> Helper loaded: url_helper
DEBUG - 2012-07-19 00:36:04 --> Controller Class Initialized
DEBUG - 2012-07-19 00:36:04 --> Model Class Initialized
DEBUG - 2012-07-19 00:36:04 --> Database Driver Class Initialized
DEBUG - 2012-07-19 00:36:04 --> Helper loaded: form_helper
DEBUG - 2012-07-19 00:36:04 --> Helper loaded: html_helper
DEBUG - 2012-07-19 00:36:04 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 00:36:04 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 00:36:04 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 00:36:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 00:36:04 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 00:36:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 00:36:04 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 00:36:04 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 00:36:04 --> Final output sent to browser
DEBUG - 2012-07-19 00:36:04 --> Total execution time: 0.0486
DEBUG - 2012-07-19 00:36:34 --> Config Class Initialized
DEBUG - 2012-07-19 00:36:34 --> Hooks Class Initialized
DEBUG - 2012-07-19 00:36:34 --> Utf8 Class Initialized
DEBUG - 2012-07-19 00:36:34 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 00:36:34 --> URI Class Initialized
DEBUG - 2012-07-19 00:36:34 --> Router Class Initialized
DEBUG - 2012-07-19 00:36:34 --> Output Class Initialized
DEBUG - 2012-07-19 00:36:34 --> Security Class Initialized
DEBUG - 2012-07-19 00:36:34 --> Input Class Initialized
DEBUG - 2012-07-19 00:36:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 00:36:34 --> Language Class Initialized
DEBUG - 2012-07-19 00:36:34 --> Loader Class Initialized
DEBUG - 2012-07-19 00:36:34 --> Helper loaded: url_helper
DEBUG - 2012-07-19 00:36:34 --> Controller Class Initialized
DEBUG - 2012-07-19 00:36:34 --> Model Class Initialized
DEBUG - 2012-07-19 00:36:35 --> Database Driver Class Initialized
DEBUG - 2012-07-19 00:36:35 --> Helper loaded: form_helper
DEBUG - 2012-07-19 00:36:35 --> Helper loaded: html_helper
DEBUG - 2012-07-19 00:36:35 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 00:36:35 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 00:36:35 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 00:36:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 00:36:35 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 00:36:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 00:36:35 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 00:36:35 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 00:36:35 --> Final output sent to browser
DEBUG - 2012-07-19 00:36:35 --> Total execution time: 0.0468
DEBUG - 2012-07-19 00:45:53 --> Config Class Initialized
DEBUG - 2012-07-19 00:45:53 --> Hooks Class Initialized
DEBUG - 2012-07-19 00:45:53 --> Utf8 Class Initialized
DEBUG - 2012-07-19 00:45:53 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 00:45:53 --> URI Class Initialized
DEBUG - 2012-07-19 00:45:53 --> Router Class Initialized
DEBUG - 2012-07-19 00:45:53 --> Output Class Initialized
DEBUG - 2012-07-19 00:45:53 --> Security Class Initialized
DEBUG - 2012-07-19 00:45:53 --> Input Class Initialized
DEBUG - 2012-07-19 00:45:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 00:45:53 --> Language Class Initialized
DEBUG - 2012-07-19 00:45:53 --> Loader Class Initialized
DEBUG - 2012-07-19 00:45:53 --> Helper loaded: url_helper
DEBUG - 2012-07-19 00:45:53 --> Controller Class Initialized
DEBUG - 2012-07-19 00:45:53 --> Model Class Initialized
DEBUG - 2012-07-19 00:45:53 --> Database Driver Class Initialized
DEBUG - 2012-07-19 00:45:53 --> Helper loaded: form_helper
DEBUG - 2012-07-19 00:45:53 --> Helper loaded: html_helper
DEBUG - 2012-07-19 00:45:53 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 00:45:53 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 00:45:53 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 00:45:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 00:45:53 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 00:45:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 00:45:53 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 00:45:53 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 00:45:53 --> Final output sent to browser
DEBUG - 2012-07-19 00:45:53 --> Total execution time: 0.0449
DEBUG - 2012-07-19 00:45:53 --> Config Class Initialized
DEBUG - 2012-07-19 00:45:53 --> Hooks Class Initialized
DEBUG - 2012-07-19 00:45:53 --> Utf8 Class Initialized
DEBUG - 2012-07-19 00:45:53 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 00:45:53 --> URI Class Initialized
DEBUG - 2012-07-19 00:45:53 --> Router Class Initialized
ERROR - 2012-07-19 00:45:53 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:00:13 --> Config Class Initialized
DEBUG - 2012-07-19 01:00:13 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:00:13 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:00:13 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:00:13 --> URI Class Initialized
DEBUG - 2012-07-19 01:00:13 --> Router Class Initialized
DEBUG - 2012-07-19 01:00:13 --> Output Class Initialized
DEBUG - 2012-07-19 01:00:13 --> Security Class Initialized
DEBUG - 2012-07-19 01:00:13 --> Input Class Initialized
DEBUG - 2012-07-19 01:00:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:00:13 --> Language Class Initialized
DEBUG - 2012-07-19 01:00:13 --> Loader Class Initialized
DEBUG - 2012-07-19 01:00:13 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:00:13 --> Controller Class Initialized
DEBUG - 2012-07-19 01:00:13 --> Model Class Initialized
DEBUG - 2012-07-19 01:00:13 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:00:13 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:00:13 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:00:13 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:00:13 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:00:13 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:00:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:00:13 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:00:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:00:13 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:00:13 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:00:13 --> Final output sent to browser
DEBUG - 2012-07-19 01:00:13 --> Total execution time: 0.0482
DEBUG - 2012-07-19 01:00:14 --> Config Class Initialized
DEBUG - 2012-07-19 01:00:14 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:00:14 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:00:14 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:00:14 --> URI Class Initialized
DEBUG - 2012-07-19 01:00:14 --> Router Class Initialized
ERROR - 2012-07-19 01:00:14 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:02:01 --> Config Class Initialized
DEBUG - 2012-07-19 01:02:01 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:02:01 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:02:01 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:02:01 --> URI Class Initialized
DEBUG - 2012-07-19 01:02:01 --> Router Class Initialized
DEBUG - 2012-07-19 01:02:01 --> Output Class Initialized
DEBUG - 2012-07-19 01:02:01 --> Security Class Initialized
DEBUG - 2012-07-19 01:02:01 --> Input Class Initialized
DEBUG - 2012-07-19 01:02:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:02:01 --> Language Class Initialized
DEBUG - 2012-07-19 01:02:01 --> Loader Class Initialized
DEBUG - 2012-07-19 01:02:01 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:02:01 --> Controller Class Initialized
DEBUG - 2012-07-19 01:02:01 --> Model Class Initialized
DEBUG - 2012-07-19 01:02:01 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:02:01 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:02:01 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:02:01 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:02:01 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:02:01 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:02:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:02:01 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:02:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:02:01 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:02:01 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:02:01 --> Final output sent to browser
DEBUG - 2012-07-19 01:02:01 --> Total execution time: 0.0447
DEBUG - 2012-07-19 01:02:02 --> Config Class Initialized
DEBUG - 2012-07-19 01:02:02 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:02:02 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:02:02 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:02:02 --> URI Class Initialized
DEBUG - 2012-07-19 01:02:02 --> Router Class Initialized
ERROR - 2012-07-19 01:02:02 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:02:38 --> Config Class Initialized
DEBUG - 2012-07-19 01:02:38 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:02:38 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:02:38 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:02:38 --> URI Class Initialized
DEBUG - 2012-07-19 01:02:38 --> Router Class Initialized
DEBUG - 2012-07-19 01:02:38 --> Output Class Initialized
DEBUG - 2012-07-19 01:02:38 --> Security Class Initialized
DEBUG - 2012-07-19 01:02:38 --> Input Class Initialized
DEBUG - 2012-07-19 01:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:02:38 --> Language Class Initialized
DEBUG - 2012-07-19 01:02:38 --> Loader Class Initialized
DEBUG - 2012-07-19 01:02:38 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:02:38 --> Controller Class Initialized
DEBUG - 2012-07-19 01:02:38 --> Model Class Initialized
DEBUG - 2012-07-19 01:02:38 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:02:38 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:02:38 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:02:38 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:02:38 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:02:38 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:02:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:02:38 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:02:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:02:38 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:02:38 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:02:38 --> Final output sent to browser
DEBUG - 2012-07-19 01:02:38 --> Total execution time: 0.0448
DEBUG - 2012-07-19 01:02:38 --> Config Class Initialized
DEBUG - 2012-07-19 01:02:38 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:02:38 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:02:38 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:02:38 --> URI Class Initialized
DEBUG - 2012-07-19 01:02:38 --> Router Class Initialized
ERROR - 2012-07-19 01:02:38 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:07:01 --> Config Class Initialized
DEBUG - 2012-07-19 01:07:01 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:07:01 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:07:01 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:07:01 --> URI Class Initialized
DEBUG - 2012-07-19 01:07:01 --> Router Class Initialized
DEBUG - 2012-07-19 01:07:01 --> Output Class Initialized
DEBUG - 2012-07-19 01:07:01 --> Security Class Initialized
DEBUG - 2012-07-19 01:07:01 --> Input Class Initialized
DEBUG - 2012-07-19 01:07:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:07:01 --> Language Class Initialized
DEBUG - 2012-07-19 01:07:01 --> Loader Class Initialized
DEBUG - 2012-07-19 01:07:01 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:07:01 --> Controller Class Initialized
DEBUG - 2012-07-19 01:07:01 --> Model Class Initialized
DEBUG - 2012-07-19 01:07:01 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:07:01 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:07:01 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:07:01 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:07:01 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:07:01 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:07:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:07:01 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:07:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:07:01 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:07:01 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:07:01 --> Final output sent to browser
DEBUG - 2012-07-19 01:07:01 --> Total execution time: 0.0441
DEBUG - 2012-07-19 01:07:01 --> Config Class Initialized
DEBUG - 2012-07-19 01:07:01 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:07:01 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:07:01 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:07:01 --> URI Class Initialized
DEBUG - 2012-07-19 01:07:01 --> Router Class Initialized
ERROR - 2012-07-19 01:07:01 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:08:31 --> Config Class Initialized
DEBUG - 2012-07-19 01:08:31 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:08:31 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:08:31 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:08:31 --> URI Class Initialized
DEBUG - 2012-07-19 01:08:31 --> Router Class Initialized
DEBUG - 2012-07-19 01:08:31 --> Output Class Initialized
DEBUG - 2012-07-19 01:08:31 --> Security Class Initialized
DEBUG - 2012-07-19 01:08:31 --> Input Class Initialized
DEBUG - 2012-07-19 01:08:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:08:31 --> Language Class Initialized
DEBUG - 2012-07-19 01:08:31 --> Loader Class Initialized
DEBUG - 2012-07-19 01:08:31 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:08:31 --> Controller Class Initialized
DEBUG - 2012-07-19 01:08:31 --> Model Class Initialized
DEBUG - 2012-07-19 01:08:31 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:08:31 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:08:31 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:08:31 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:08:31 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:08:31 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:08:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:08:31 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:08:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:08:31 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:08:31 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:08:31 --> Final output sent to browser
DEBUG - 2012-07-19 01:08:31 --> Total execution time: 0.0405
DEBUG - 2012-07-19 01:08:31 --> Config Class Initialized
DEBUG - 2012-07-19 01:08:31 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:08:31 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:08:31 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:08:31 --> URI Class Initialized
DEBUG - 2012-07-19 01:08:31 --> Router Class Initialized
ERROR - 2012-07-19 01:08:31 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:10:43 --> Config Class Initialized
DEBUG - 2012-07-19 01:10:43 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:10:43 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:10:43 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:10:43 --> URI Class Initialized
DEBUG - 2012-07-19 01:10:43 --> Router Class Initialized
DEBUG - 2012-07-19 01:10:43 --> Output Class Initialized
DEBUG - 2012-07-19 01:10:43 --> Security Class Initialized
DEBUG - 2012-07-19 01:10:43 --> Input Class Initialized
DEBUG - 2012-07-19 01:10:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:10:43 --> Language Class Initialized
DEBUG - 2012-07-19 01:10:43 --> Loader Class Initialized
DEBUG - 2012-07-19 01:10:43 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:10:43 --> Controller Class Initialized
DEBUG - 2012-07-19 01:10:43 --> Model Class Initialized
DEBUG - 2012-07-19 01:10:43 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:10:43 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:10:43 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:10:43 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:10:43 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:10:43 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:10:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:10:43 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:10:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:10:43 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:10:43 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:10:43 --> Final output sent to browser
DEBUG - 2012-07-19 01:10:43 --> Total execution time: 0.0396
DEBUG - 2012-07-19 01:10:44 --> Config Class Initialized
DEBUG - 2012-07-19 01:10:44 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:10:44 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:10:44 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:10:44 --> URI Class Initialized
DEBUG - 2012-07-19 01:10:44 --> Router Class Initialized
ERROR - 2012-07-19 01:10:44 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:16:27 --> Config Class Initialized
DEBUG - 2012-07-19 01:16:27 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:16:27 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:16:27 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:16:27 --> URI Class Initialized
DEBUG - 2012-07-19 01:16:27 --> Router Class Initialized
DEBUG - 2012-07-19 01:16:27 --> Output Class Initialized
DEBUG - 2012-07-19 01:16:27 --> Security Class Initialized
DEBUG - 2012-07-19 01:16:27 --> Input Class Initialized
DEBUG - 2012-07-19 01:16:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:16:27 --> Language Class Initialized
DEBUG - 2012-07-19 01:16:27 --> Loader Class Initialized
DEBUG - 2012-07-19 01:16:27 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:16:27 --> Controller Class Initialized
DEBUG - 2012-07-19 01:16:27 --> Model Class Initialized
DEBUG - 2012-07-19 01:16:27 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:16:27 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:16:27 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:16:27 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:16:27 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:16:27 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:16:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:16:27 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:16:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:16:27 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:16:27 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:16:27 --> Final output sent to browser
DEBUG - 2012-07-19 01:16:27 --> Total execution time: 0.0399
DEBUG - 2012-07-19 01:16:28 --> Config Class Initialized
DEBUG - 2012-07-19 01:16:28 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:16:28 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:16:28 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:16:28 --> URI Class Initialized
DEBUG - 2012-07-19 01:16:28 --> Router Class Initialized
ERROR - 2012-07-19 01:16:28 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:16:28 --> Config Class Initialized
DEBUG - 2012-07-19 01:16:28 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:16:28 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:16:28 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:16:28 --> URI Class Initialized
DEBUG - 2012-07-19 01:16:28 --> Router Class Initialized
ERROR - 2012-07-19 01:16:28 --> 404 Page Not Found --> ui
DEBUG - 2012-07-19 01:16:28 --> Config Class Initialized
DEBUG - 2012-07-19 01:16:28 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:16:28 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:16:28 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:16:28 --> URI Class Initialized
DEBUG - 2012-07-19 01:16:28 --> Router Class Initialized
ERROR - 2012-07-19 01:16:28 --> 404 Page Not Found --> ui
DEBUG - 2012-07-19 01:16:28 --> Config Class Initialized
DEBUG - 2012-07-19 01:16:28 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:16:28 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:16:28 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:16:28 --> URI Class Initialized
DEBUG - 2012-07-19 01:16:28 --> Router Class Initialized
ERROR - 2012-07-19 01:16:28 --> 404 Page Not Found --> ui
DEBUG - 2012-07-19 01:19:28 --> Config Class Initialized
DEBUG - 2012-07-19 01:19:28 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:19:28 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:19:28 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:19:28 --> URI Class Initialized
DEBUG - 2012-07-19 01:19:28 --> Router Class Initialized
DEBUG - 2012-07-19 01:19:28 --> Output Class Initialized
DEBUG - 2012-07-19 01:19:28 --> Security Class Initialized
DEBUG - 2012-07-19 01:19:28 --> Input Class Initialized
DEBUG - 2012-07-19 01:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:19:28 --> Language Class Initialized
DEBUG - 2012-07-19 01:19:28 --> Loader Class Initialized
DEBUG - 2012-07-19 01:19:28 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:19:28 --> Controller Class Initialized
DEBUG - 2012-07-19 01:19:28 --> Model Class Initialized
DEBUG - 2012-07-19 01:19:28 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:19:28 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:19:28 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:19:28 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:19:28 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:19:28 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:19:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:19:28 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:19:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:19:28 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:19:28 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:19:28 --> Final output sent to browser
DEBUG - 2012-07-19 01:19:28 --> Total execution time: 0.1689
DEBUG - 2012-07-19 01:19:29 --> Config Class Initialized
DEBUG - 2012-07-19 01:19:29 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:19:29 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:19:29 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:19:29 --> URI Class Initialized
DEBUG - 2012-07-19 01:19:29 --> Router Class Initialized
ERROR - 2012-07-19 01:19:29 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:19:29 --> Config Class Initialized
DEBUG - 2012-07-19 01:19:29 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:19:29 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:19:29 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:19:29 --> URI Class Initialized
DEBUG - 2012-07-19 01:19:29 --> Router Class Initialized
ERROR - 2012-07-19 01:19:29 --> 404 Page Not Found --> ui
DEBUG - 2012-07-19 01:19:29 --> Config Class Initialized
DEBUG - 2012-07-19 01:19:29 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:19:29 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:19:29 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:19:29 --> URI Class Initialized
DEBUG - 2012-07-19 01:19:29 --> Router Class Initialized
ERROR - 2012-07-19 01:19:29 --> 404 Page Not Found --> ui
DEBUG - 2012-07-19 01:19:29 --> Config Class Initialized
DEBUG - 2012-07-19 01:19:29 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:19:29 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:19:29 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:19:29 --> URI Class Initialized
DEBUG - 2012-07-19 01:19:29 --> Router Class Initialized
ERROR - 2012-07-19 01:19:29 --> 404 Page Not Found --> ui
DEBUG - 2012-07-19 01:21:19 --> Config Class Initialized
DEBUG - 2012-07-19 01:21:19 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:21:19 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:21:19 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:21:19 --> URI Class Initialized
DEBUG - 2012-07-19 01:21:19 --> Router Class Initialized
DEBUG - 2012-07-19 01:21:19 --> Output Class Initialized
DEBUG - 2012-07-19 01:21:19 --> Security Class Initialized
DEBUG - 2012-07-19 01:21:19 --> Input Class Initialized
DEBUG - 2012-07-19 01:21:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:21:19 --> Language Class Initialized
DEBUG - 2012-07-19 01:21:19 --> Loader Class Initialized
DEBUG - 2012-07-19 01:21:19 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:21:19 --> Controller Class Initialized
DEBUG - 2012-07-19 01:21:19 --> Model Class Initialized
DEBUG - 2012-07-19 01:21:19 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:21:19 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:21:19 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:21:19 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:21:19 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:21:19 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:21:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:21:19 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:21:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:21:19 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:21:19 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:21:19 --> Final output sent to browser
DEBUG - 2012-07-19 01:21:19 --> Total execution time: 0.0400
DEBUG - 2012-07-19 01:21:19 --> Config Class Initialized
DEBUG - 2012-07-19 01:21:19 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:21:19 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:21:19 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:21:19 --> URI Class Initialized
DEBUG - 2012-07-19 01:21:19 --> Router Class Initialized
ERROR - 2012-07-19 01:21:19 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:21:19 --> Config Class Initialized
DEBUG - 2012-07-19 01:21:19 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:21:19 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:21:19 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:21:19 --> URI Class Initialized
DEBUG - 2012-07-19 01:21:19 --> Router Class Initialized
ERROR - 2012-07-19 01:21:19 --> 404 Page Not Found --> ui
DEBUG - 2012-07-19 01:21:19 --> Config Class Initialized
DEBUG - 2012-07-19 01:21:19 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:21:19 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:21:19 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:21:19 --> URI Class Initialized
DEBUG - 2012-07-19 01:21:19 --> Router Class Initialized
ERROR - 2012-07-19 01:21:19 --> 404 Page Not Found --> ui
DEBUG - 2012-07-19 01:21:19 --> Config Class Initialized
DEBUG - 2012-07-19 01:21:19 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:21:19 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:21:19 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:21:19 --> URI Class Initialized
DEBUG - 2012-07-19 01:21:19 --> Router Class Initialized
ERROR - 2012-07-19 01:21:19 --> 404 Page Not Found --> ui
DEBUG - 2012-07-19 01:31:13 --> Config Class Initialized
DEBUG - 2012-07-19 01:31:13 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:31:13 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:31:13 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:31:13 --> URI Class Initialized
DEBUG - 2012-07-19 01:31:13 --> Router Class Initialized
DEBUG - 2012-07-19 01:31:13 --> Output Class Initialized
DEBUG - 2012-07-19 01:31:13 --> Security Class Initialized
DEBUG - 2012-07-19 01:31:13 --> Input Class Initialized
DEBUG - 2012-07-19 01:31:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:31:13 --> Language Class Initialized
DEBUG - 2012-07-19 01:31:13 --> Loader Class Initialized
DEBUG - 2012-07-19 01:31:13 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:31:13 --> Controller Class Initialized
DEBUG - 2012-07-19 01:31:13 --> Model Class Initialized
DEBUG - 2012-07-19 01:31:13 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:31:13 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:31:13 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:31:13 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:31:13 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:31:13 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:31:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:31:13 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:31:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:31:13 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:31:13 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:31:13 --> Final output sent to browser
DEBUG - 2012-07-19 01:31:13 --> Total execution time: 0.0812
DEBUG - 2012-07-19 01:31:13 --> Config Class Initialized
DEBUG - 2012-07-19 01:31:13 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:31:13 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:31:13 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:31:13 --> URI Class Initialized
DEBUG - 2012-07-19 01:31:13 --> Router Class Initialized
ERROR - 2012-07-19 01:31:13 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:31:13 --> Config Class Initialized
DEBUG - 2012-07-19 01:31:13 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:31:13 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:31:13 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:31:13 --> URI Class Initialized
DEBUG - 2012-07-19 01:31:13 --> Router Class Initialized
ERROR - 2012-07-19 01:31:13 --> 404 Page Not Found --> ui
DEBUG - 2012-07-19 01:31:13 --> Config Class Initialized
DEBUG - 2012-07-19 01:31:13 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:31:13 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:31:13 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:31:13 --> URI Class Initialized
DEBUG - 2012-07-19 01:31:13 --> Router Class Initialized
ERROR - 2012-07-19 01:31:13 --> 404 Page Not Found --> ui
DEBUG - 2012-07-19 01:31:13 --> Config Class Initialized
DEBUG - 2012-07-19 01:31:13 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:31:13 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:31:13 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:31:13 --> URI Class Initialized
DEBUG - 2012-07-19 01:31:13 --> Router Class Initialized
ERROR - 2012-07-19 01:31:13 --> 404 Page Not Found --> ui
DEBUG - 2012-07-19 01:31:40 --> Config Class Initialized
DEBUG - 2012-07-19 01:31:40 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:31:40 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:31:40 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:31:40 --> URI Class Initialized
DEBUG - 2012-07-19 01:31:40 --> Router Class Initialized
DEBUG - 2012-07-19 01:31:40 --> Output Class Initialized
DEBUG - 2012-07-19 01:31:40 --> Security Class Initialized
DEBUG - 2012-07-19 01:31:40 --> Input Class Initialized
DEBUG - 2012-07-19 01:31:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:31:40 --> Language Class Initialized
DEBUG - 2012-07-19 01:31:40 --> Loader Class Initialized
DEBUG - 2012-07-19 01:31:40 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:31:40 --> Controller Class Initialized
DEBUG - 2012-07-19 01:31:40 --> Model Class Initialized
DEBUG - 2012-07-19 01:31:40 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:31:40 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:31:40 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:31:40 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:31:40 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:31:40 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:31:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:31:40 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:31:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:31:40 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:31:40 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:31:40 --> Final output sent to browser
DEBUG - 2012-07-19 01:31:40 --> Total execution time: 0.0849
DEBUG - 2012-07-19 01:31:40 --> Config Class Initialized
DEBUG - 2012-07-19 01:31:40 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:31:40 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:31:40 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:31:40 --> URI Class Initialized
DEBUG - 2012-07-19 01:31:40 --> Config Class Initialized
DEBUG - 2012-07-19 01:31:40 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:31:40 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:31:40 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:31:40 --> URI Class Initialized
DEBUG - 2012-07-19 01:31:40 --> Router Class Initialized
ERROR - 2012-07-19 01:31:40 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:31:40 --> Router Class Initialized
ERROR - 2012-07-19 01:31:40 --> 404 Page Not Found --> ui
DEBUG - 2012-07-19 01:31:41 --> Config Class Initialized
DEBUG - 2012-07-19 01:31:41 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:31:41 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:31:41 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:31:41 --> URI Class Initialized
DEBUG - 2012-07-19 01:31:41 --> Router Class Initialized
ERROR - 2012-07-19 01:31:41 --> 404 Page Not Found --> ui
DEBUG - 2012-07-19 01:31:41 --> Config Class Initialized
DEBUG - 2012-07-19 01:31:41 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:31:41 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:31:41 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:31:41 --> URI Class Initialized
DEBUG - 2012-07-19 01:31:41 --> Router Class Initialized
ERROR - 2012-07-19 01:31:41 --> 404 Page Not Found --> ui
DEBUG - 2012-07-19 01:34:29 --> Config Class Initialized
DEBUG - 2012-07-19 01:34:29 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:34:29 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:34:29 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:34:29 --> URI Class Initialized
DEBUG - 2012-07-19 01:34:29 --> Router Class Initialized
DEBUG - 2012-07-19 01:34:29 --> Output Class Initialized
DEBUG - 2012-07-19 01:34:29 --> Security Class Initialized
DEBUG - 2012-07-19 01:34:29 --> Input Class Initialized
DEBUG - 2012-07-19 01:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:34:29 --> Language Class Initialized
DEBUG - 2012-07-19 01:34:29 --> Loader Class Initialized
DEBUG - 2012-07-19 01:34:29 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:34:29 --> Controller Class Initialized
DEBUG - 2012-07-19 01:34:29 --> Model Class Initialized
DEBUG - 2012-07-19 01:34:29 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:34:29 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:34:29 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:34:29 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:34:29 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:34:29 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:34:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:34:29 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:34:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:34:29 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:34:29 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:34:29 --> Final output sent to browser
DEBUG - 2012-07-19 01:34:29 --> Total execution time: 0.0408
DEBUG - 2012-07-19 01:34:29 --> Config Class Initialized
DEBUG - 2012-07-19 01:34:29 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:34:29 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:34:29 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:34:29 --> URI Class Initialized
DEBUG - 2012-07-19 01:34:29 --> Config Class Initialized
DEBUG - 2012-07-19 01:34:29 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:34:29 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:34:29 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:34:29 --> URI Class Initialized
DEBUG - 2012-07-19 01:34:29 --> Router Class Initialized
ERROR - 2012-07-19 01:34:29 --> 404 Page Not Found --> ui
DEBUG - 2012-07-19 01:34:29 --> Router Class Initialized
ERROR - 2012-07-19 01:34:29 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:34:29 --> Config Class Initialized
DEBUG - 2012-07-19 01:34:29 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:34:29 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:34:29 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:34:29 --> URI Class Initialized
DEBUG - 2012-07-19 01:34:29 --> Router Class Initialized
ERROR - 2012-07-19 01:34:29 --> 404 Page Not Found --> ui
DEBUG - 2012-07-19 01:34:29 --> Config Class Initialized
DEBUG - 2012-07-19 01:34:29 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:34:29 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:34:29 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:34:29 --> URI Class Initialized
DEBUG - 2012-07-19 01:34:29 --> Router Class Initialized
ERROR - 2012-07-19 01:34:29 --> 404 Page Not Found --> ui
DEBUG - 2012-07-19 01:34:48 --> Config Class Initialized
DEBUG - 2012-07-19 01:34:48 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:34:48 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:34:48 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:34:48 --> URI Class Initialized
DEBUG - 2012-07-19 01:34:48 --> Router Class Initialized
DEBUG - 2012-07-19 01:34:48 --> Output Class Initialized
DEBUG - 2012-07-19 01:34:48 --> Security Class Initialized
DEBUG - 2012-07-19 01:34:48 --> Input Class Initialized
DEBUG - 2012-07-19 01:34:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:34:48 --> Language Class Initialized
DEBUG - 2012-07-19 01:34:48 --> Loader Class Initialized
DEBUG - 2012-07-19 01:34:48 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:34:48 --> Controller Class Initialized
DEBUG - 2012-07-19 01:34:48 --> Model Class Initialized
DEBUG - 2012-07-19 01:34:48 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:34:48 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:34:48 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:34:48 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:34:48 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:34:48 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:34:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:34:48 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:34:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:34:48 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:34:48 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:34:48 --> Final output sent to browser
DEBUG - 2012-07-19 01:34:48 --> Total execution time: 0.0434
DEBUG - 2012-07-19 01:34:48 --> Config Class Initialized
DEBUG - 2012-07-19 01:34:48 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:34:48 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:34:48 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:34:48 --> URI Class Initialized
DEBUG - 2012-07-19 01:34:48 --> Router Class Initialized
ERROR - 2012-07-19 01:34:48 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:34:48 --> Config Class Initialized
DEBUG - 2012-07-19 01:34:48 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:34:48 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:34:48 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:34:48 --> URI Class Initialized
DEBUG - 2012-07-19 01:34:48 --> Router Class Initialized
ERROR - 2012-07-19 01:34:48 --> 404 Page Not Found --> ui
DEBUG - 2012-07-19 01:34:49 --> Config Class Initialized
DEBUG - 2012-07-19 01:34:49 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:34:49 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:34:49 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:34:49 --> URI Class Initialized
DEBUG - 2012-07-19 01:34:49 --> Router Class Initialized
ERROR - 2012-07-19 01:34:49 --> 404 Page Not Found --> ui
DEBUG - 2012-07-19 01:34:49 --> Config Class Initialized
DEBUG - 2012-07-19 01:34:49 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:34:49 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:34:49 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:34:49 --> URI Class Initialized
DEBUG - 2012-07-19 01:34:49 --> Router Class Initialized
ERROR - 2012-07-19 01:34:49 --> 404 Page Not Found --> ui
DEBUG - 2012-07-19 01:36:09 --> Config Class Initialized
DEBUG - 2012-07-19 01:36:09 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:36:09 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:36:09 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:36:09 --> URI Class Initialized
DEBUG - 2012-07-19 01:36:09 --> Router Class Initialized
DEBUG - 2012-07-19 01:36:09 --> Output Class Initialized
DEBUG - 2012-07-19 01:36:09 --> Security Class Initialized
DEBUG - 2012-07-19 01:36:09 --> Input Class Initialized
DEBUG - 2012-07-19 01:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:36:09 --> Language Class Initialized
DEBUG - 2012-07-19 01:36:09 --> Loader Class Initialized
DEBUG - 2012-07-19 01:36:09 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:36:09 --> Controller Class Initialized
DEBUG - 2012-07-19 01:36:09 --> Model Class Initialized
DEBUG - 2012-07-19 01:36:09 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:36:09 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:36:09 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:36:09 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:36:09 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:36:09 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:36:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:36:09 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:36:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:36:09 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:36:09 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:36:09 --> Final output sent to browser
DEBUG - 2012-07-19 01:36:09 --> Total execution time: 0.0396
DEBUG - 2012-07-19 01:36:09 --> Config Class Initialized
DEBUG - 2012-07-19 01:36:09 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:36:09 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:36:09 --> Config Class Initialized
DEBUG - 2012-07-19 01:36:09 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:36:09 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:36:09 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:36:09 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:36:09 --> URI Class Initialized
DEBUG - 2012-07-19 01:36:09 --> URI Class Initialized
DEBUG - 2012-07-19 01:36:09 --> Router Class Initialized
DEBUG - 2012-07-19 01:36:09 --> Router Class Initialized
ERROR - 2012-07-19 01:36:09 --> 404 Page Not Found --> js
ERROR - 2012-07-19 01:36:09 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:36:09 --> Config Class Initialized
DEBUG - 2012-07-19 01:36:09 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:36:09 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:36:09 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:36:09 --> URI Class Initialized
DEBUG - 2012-07-19 01:36:09 --> Router Class Initialized
ERROR - 2012-07-19 01:36:09 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:36:10 --> Config Class Initialized
DEBUG - 2012-07-19 01:36:10 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:36:10 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:36:10 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:36:10 --> URI Class Initialized
DEBUG - 2012-07-19 01:36:10 --> Router Class Initialized
ERROR - 2012-07-19 01:36:10 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:39:03 --> Config Class Initialized
DEBUG - 2012-07-19 01:39:03 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:39:03 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:39:03 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:39:03 --> URI Class Initialized
DEBUG - 2012-07-19 01:39:03 --> Router Class Initialized
DEBUG - 2012-07-19 01:39:03 --> Output Class Initialized
DEBUG - 2012-07-19 01:39:03 --> Security Class Initialized
DEBUG - 2012-07-19 01:39:03 --> Input Class Initialized
DEBUG - 2012-07-19 01:39:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:39:03 --> Language Class Initialized
DEBUG - 2012-07-19 01:39:03 --> Loader Class Initialized
DEBUG - 2012-07-19 01:39:03 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:39:03 --> Controller Class Initialized
DEBUG - 2012-07-19 01:39:03 --> Model Class Initialized
DEBUG - 2012-07-19 01:39:04 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:39:04 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:39:04 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:39:04 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:39:04 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:39:04 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:39:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:39:04 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:39:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:39:04 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:39:04 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:39:04 --> Final output sent to browser
DEBUG - 2012-07-19 01:39:04 --> Total execution time: 0.0401
DEBUG - 2012-07-19 01:39:04 --> Config Class Initialized
DEBUG - 2012-07-19 01:39:04 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:39:04 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:39:04 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:39:04 --> URI Class Initialized
DEBUG - 2012-07-19 01:39:04 --> Router Class Initialized
ERROR - 2012-07-19 01:39:04 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:42:28 --> Config Class Initialized
DEBUG - 2012-07-19 01:42:28 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:42:28 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:42:28 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:42:28 --> URI Class Initialized
DEBUG - 2012-07-19 01:42:28 --> Router Class Initialized
DEBUG - 2012-07-19 01:42:28 --> Output Class Initialized
DEBUG - 2012-07-19 01:42:28 --> Security Class Initialized
DEBUG - 2012-07-19 01:42:28 --> Input Class Initialized
DEBUG - 2012-07-19 01:42:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:42:28 --> Language Class Initialized
DEBUG - 2012-07-19 01:42:28 --> Loader Class Initialized
DEBUG - 2012-07-19 01:42:28 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:42:28 --> Controller Class Initialized
DEBUG - 2012-07-19 01:42:28 --> Model Class Initialized
DEBUG - 2012-07-19 01:42:28 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:42:28 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:42:28 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:42:28 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:42:28 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:42:28 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:42:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:42:28 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:42:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:42:28 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:42:28 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:42:28 --> Final output sent to browser
DEBUG - 2012-07-19 01:42:28 --> Total execution time: 0.0401
DEBUG - 2012-07-19 01:42:28 --> Config Class Initialized
DEBUG - 2012-07-19 01:42:28 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:42:28 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:42:28 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:42:28 --> URI Class Initialized
DEBUG - 2012-07-19 01:42:28 --> Router Class Initialized
ERROR - 2012-07-19 01:42:28 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:43:52 --> Config Class Initialized
DEBUG - 2012-07-19 01:43:52 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:43:52 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:43:52 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:43:52 --> URI Class Initialized
DEBUG - 2012-07-19 01:43:52 --> Router Class Initialized
DEBUG - 2012-07-19 01:43:52 --> Output Class Initialized
DEBUG - 2012-07-19 01:43:52 --> Security Class Initialized
DEBUG - 2012-07-19 01:43:52 --> Input Class Initialized
DEBUG - 2012-07-19 01:43:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:43:52 --> Language Class Initialized
DEBUG - 2012-07-19 01:43:52 --> Loader Class Initialized
DEBUG - 2012-07-19 01:43:52 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:43:52 --> Controller Class Initialized
DEBUG - 2012-07-19 01:43:52 --> Model Class Initialized
DEBUG - 2012-07-19 01:43:52 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:43:52 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:43:52 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:43:52 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:43:52 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:43:52 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:43:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:43:52 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:43:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:43:52 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:43:52 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:43:52 --> Final output sent to browser
DEBUG - 2012-07-19 01:43:52 --> Total execution time: 0.0400
DEBUG - 2012-07-19 01:43:53 --> Config Class Initialized
DEBUG - 2012-07-19 01:43:53 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:43:53 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:43:53 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:43:53 --> URI Class Initialized
DEBUG - 2012-07-19 01:43:53 --> Router Class Initialized
ERROR - 2012-07-19 01:43:53 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:46:02 --> Config Class Initialized
DEBUG - 2012-07-19 01:46:02 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:46:02 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:46:02 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:46:02 --> URI Class Initialized
DEBUG - 2012-07-19 01:46:02 --> Router Class Initialized
DEBUG - 2012-07-19 01:46:02 --> Output Class Initialized
DEBUG - 2012-07-19 01:46:02 --> Security Class Initialized
DEBUG - 2012-07-19 01:46:02 --> Input Class Initialized
DEBUG - 2012-07-19 01:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:46:02 --> Language Class Initialized
DEBUG - 2012-07-19 01:46:02 --> Loader Class Initialized
DEBUG - 2012-07-19 01:46:02 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:46:02 --> Controller Class Initialized
DEBUG - 2012-07-19 01:46:02 --> Model Class Initialized
DEBUG - 2012-07-19 01:46:02 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:46:02 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:46:02 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:46:02 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:46:02 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:46:02 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:46:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:46:02 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:46:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:46:02 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:46:02 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:46:02 --> Final output sent to browser
DEBUG - 2012-07-19 01:46:02 --> Total execution time: 0.0415
DEBUG - 2012-07-19 01:46:02 --> Config Class Initialized
DEBUG - 2012-07-19 01:46:02 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:46:02 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:46:02 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:46:02 --> URI Class Initialized
DEBUG - 2012-07-19 01:46:02 --> Router Class Initialized
ERROR - 2012-07-19 01:46:02 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:47:32 --> Config Class Initialized
DEBUG - 2012-07-19 01:47:32 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:47:32 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:47:32 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:47:32 --> URI Class Initialized
DEBUG - 2012-07-19 01:47:32 --> Router Class Initialized
DEBUG - 2012-07-19 01:47:32 --> Output Class Initialized
DEBUG - 2012-07-19 01:47:32 --> Security Class Initialized
DEBUG - 2012-07-19 01:47:32 --> Input Class Initialized
DEBUG - 2012-07-19 01:47:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:47:32 --> Language Class Initialized
DEBUG - 2012-07-19 01:47:32 --> Loader Class Initialized
DEBUG - 2012-07-19 01:47:32 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:47:32 --> Controller Class Initialized
DEBUG - 2012-07-19 01:47:32 --> Model Class Initialized
DEBUG - 2012-07-19 01:47:32 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:47:32 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:47:32 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:47:32 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:47:32 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:47:32 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:47:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:47:32 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:47:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:47:32 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:47:32 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:47:32 --> Final output sent to browser
DEBUG - 2012-07-19 01:47:32 --> Total execution time: 0.0401
DEBUG - 2012-07-19 01:47:32 --> Config Class Initialized
DEBUG - 2012-07-19 01:47:32 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:47:32 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:47:32 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:47:32 --> URI Class Initialized
DEBUG - 2012-07-19 01:47:32 --> Router Class Initialized
ERROR - 2012-07-19 01:47:32 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:47:56 --> Config Class Initialized
DEBUG - 2012-07-19 01:47:56 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:47:56 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:47:56 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:47:56 --> URI Class Initialized
DEBUG - 2012-07-19 01:47:56 --> Router Class Initialized
DEBUG - 2012-07-19 01:47:56 --> Output Class Initialized
DEBUG - 2012-07-19 01:47:56 --> Security Class Initialized
DEBUG - 2012-07-19 01:47:56 --> Input Class Initialized
DEBUG - 2012-07-19 01:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:47:56 --> Language Class Initialized
DEBUG - 2012-07-19 01:47:56 --> Loader Class Initialized
DEBUG - 2012-07-19 01:47:56 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:47:56 --> Controller Class Initialized
DEBUG - 2012-07-19 01:47:56 --> Model Class Initialized
DEBUG - 2012-07-19 01:47:56 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:47:56 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:47:56 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:47:56 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:47:56 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:47:56 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:47:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:47:56 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:47:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:47:56 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:47:56 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:47:56 --> Final output sent to browser
DEBUG - 2012-07-19 01:47:56 --> Total execution time: 0.0404
DEBUG - 2012-07-19 01:47:57 --> Config Class Initialized
DEBUG - 2012-07-19 01:47:57 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:47:57 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:47:57 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:47:57 --> URI Class Initialized
DEBUG - 2012-07-19 01:47:57 --> Router Class Initialized
ERROR - 2012-07-19 01:47:57 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:52:21 --> Config Class Initialized
DEBUG - 2012-07-19 01:52:21 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:52:21 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:52:21 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:52:21 --> URI Class Initialized
DEBUG - 2012-07-19 01:52:21 --> Router Class Initialized
DEBUG - 2012-07-19 01:52:21 --> Output Class Initialized
DEBUG - 2012-07-19 01:52:21 --> Security Class Initialized
DEBUG - 2012-07-19 01:52:21 --> Input Class Initialized
DEBUG - 2012-07-19 01:52:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:52:21 --> Language Class Initialized
DEBUG - 2012-07-19 01:52:21 --> Loader Class Initialized
DEBUG - 2012-07-19 01:52:21 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:52:21 --> Controller Class Initialized
DEBUG - 2012-07-19 01:52:21 --> Model Class Initialized
DEBUG - 2012-07-19 01:52:21 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:52:21 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:52:21 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:52:21 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:52:21 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:52:21 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:52:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:52:21 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:52:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:52:21 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:52:21 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:52:21 --> Final output sent to browser
DEBUG - 2012-07-19 01:52:21 --> Total execution time: 0.0517
DEBUG - 2012-07-19 01:52:22 --> Config Class Initialized
DEBUG - 2012-07-19 01:52:22 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:52:22 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:52:22 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:52:22 --> URI Class Initialized
DEBUG - 2012-07-19 01:52:22 --> Router Class Initialized
ERROR - 2012-07-19 01:52:22 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:53:05 --> Config Class Initialized
DEBUG - 2012-07-19 01:53:05 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:53:05 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:53:05 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:53:05 --> URI Class Initialized
DEBUG - 2012-07-19 01:53:05 --> Router Class Initialized
DEBUG - 2012-07-19 01:53:05 --> Output Class Initialized
DEBUG - 2012-07-19 01:53:05 --> Security Class Initialized
DEBUG - 2012-07-19 01:53:05 --> Input Class Initialized
DEBUG - 2012-07-19 01:53:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:53:05 --> Language Class Initialized
DEBUG - 2012-07-19 01:53:05 --> Loader Class Initialized
DEBUG - 2012-07-19 01:53:05 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:53:05 --> Controller Class Initialized
DEBUG - 2012-07-19 01:53:05 --> Model Class Initialized
DEBUG - 2012-07-19 01:53:05 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:53:05 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:53:05 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:53:05 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:53:05 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:53:05 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:53:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:53:05 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:53:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:53:05 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:53:05 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:53:05 --> Final output sent to browser
DEBUG - 2012-07-19 01:53:05 --> Total execution time: 0.0427
DEBUG - 2012-07-19 01:53:05 --> Config Class Initialized
DEBUG - 2012-07-19 01:53:05 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:53:05 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:53:05 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:53:05 --> URI Class Initialized
DEBUG - 2012-07-19 01:53:05 --> Router Class Initialized
ERROR - 2012-07-19 01:53:05 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:54:21 --> Config Class Initialized
DEBUG - 2012-07-19 01:54:21 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:54:21 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:54:21 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:54:21 --> URI Class Initialized
DEBUG - 2012-07-19 01:54:21 --> Router Class Initialized
DEBUG - 2012-07-19 01:54:21 --> Output Class Initialized
DEBUG - 2012-07-19 01:54:21 --> Security Class Initialized
DEBUG - 2012-07-19 01:54:21 --> Input Class Initialized
DEBUG - 2012-07-19 01:54:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:54:21 --> Language Class Initialized
DEBUG - 2012-07-19 01:54:21 --> Loader Class Initialized
DEBUG - 2012-07-19 01:54:21 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:54:21 --> Controller Class Initialized
DEBUG - 2012-07-19 01:54:21 --> Model Class Initialized
DEBUG - 2012-07-19 01:54:21 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:54:21 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:54:21 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:54:21 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:54:21 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:54:21 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:54:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:54:21 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:54:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:54:21 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:54:21 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:54:21 --> Final output sent to browser
DEBUG - 2012-07-19 01:54:21 --> Total execution time: 0.0408
DEBUG - 2012-07-19 01:54:22 --> Config Class Initialized
DEBUG - 2012-07-19 01:54:22 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:54:22 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:54:22 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:54:22 --> URI Class Initialized
DEBUG - 2012-07-19 01:54:22 --> Router Class Initialized
ERROR - 2012-07-19 01:54:22 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:57:08 --> Config Class Initialized
DEBUG - 2012-07-19 01:57:08 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:57:08 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:57:08 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:57:08 --> URI Class Initialized
DEBUG - 2012-07-19 01:57:08 --> Router Class Initialized
DEBUG - 2012-07-19 01:57:08 --> Output Class Initialized
DEBUG - 2012-07-19 01:57:08 --> Security Class Initialized
DEBUG - 2012-07-19 01:57:08 --> Input Class Initialized
DEBUG - 2012-07-19 01:57:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:57:08 --> Language Class Initialized
DEBUG - 2012-07-19 01:57:08 --> Loader Class Initialized
DEBUG - 2012-07-19 01:57:08 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:57:08 --> Controller Class Initialized
DEBUG - 2012-07-19 01:57:08 --> Model Class Initialized
DEBUG - 2012-07-19 01:57:08 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:57:08 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:57:08 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:57:08 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:57:08 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:57:08 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:57:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:57:08 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:57:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:57:08 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:57:08 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:57:08 --> Final output sent to browser
DEBUG - 2012-07-19 01:57:08 --> Total execution time: 0.0499
DEBUG - 2012-07-19 01:57:09 --> Config Class Initialized
DEBUG - 2012-07-19 01:57:09 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:57:09 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:57:09 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:57:09 --> URI Class Initialized
DEBUG - 2012-07-19 01:57:09 --> Router Class Initialized
ERROR - 2012-07-19 01:57:09 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:57:48 --> Config Class Initialized
DEBUG - 2012-07-19 01:57:48 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:57:48 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:57:48 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:57:48 --> URI Class Initialized
DEBUG - 2012-07-19 01:57:48 --> Router Class Initialized
DEBUG - 2012-07-19 01:57:48 --> Output Class Initialized
DEBUG - 2012-07-19 01:57:48 --> Security Class Initialized
DEBUG - 2012-07-19 01:57:48 --> Input Class Initialized
DEBUG - 2012-07-19 01:57:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:57:48 --> Language Class Initialized
DEBUG - 2012-07-19 01:57:48 --> Loader Class Initialized
DEBUG - 2012-07-19 01:57:48 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:57:48 --> Controller Class Initialized
DEBUG - 2012-07-19 01:57:48 --> Model Class Initialized
DEBUG - 2012-07-19 01:57:48 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:57:48 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:57:48 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:57:48 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:57:48 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:57:48 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:57:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:57:48 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:57:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:57:48 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:57:48 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:57:48 --> Final output sent to browser
DEBUG - 2012-07-19 01:57:48 --> Total execution time: 0.0405
DEBUG - 2012-07-19 01:57:49 --> Config Class Initialized
DEBUG - 2012-07-19 01:57:49 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:57:49 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:57:49 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:57:49 --> URI Class Initialized
DEBUG - 2012-07-19 01:57:49 --> Router Class Initialized
ERROR - 2012-07-19 01:57:49 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 01:58:51 --> Config Class Initialized
DEBUG - 2012-07-19 01:58:51 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:58:51 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:58:51 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:58:51 --> URI Class Initialized
DEBUG - 2012-07-19 01:58:51 --> Router Class Initialized
DEBUG - 2012-07-19 01:58:51 --> Output Class Initialized
DEBUG - 2012-07-19 01:58:51 --> Security Class Initialized
DEBUG - 2012-07-19 01:58:51 --> Input Class Initialized
DEBUG - 2012-07-19 01:58:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 01:58:51 --> Language Class Initialized
DEBUG - 2012-07-19 01:58:51 --> Loader Class Initialized
DEBUG - 2012-07-19 01:58:51 --> Helper loaded: url_helper
DEBUG - 2012-07-19 01:58:51 --> Controller Class Initialized
DEBUG - 2012-07-19 01:58:51 --> Model Class Initialized
DEBUG - 2012-07-19 01:58:51 --> Database Driver Class Initialized
DEBUG - 2012-07-19 01:58:51 --> Helper loaded: form_helper
DEBUG - 2012-07-19 01:58:51 --> Helper loaded: html_helper
DEBUG - 2012-07-19 01:58:51 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 01:58:51 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 01:58:51 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:58:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 01:58:51 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 01:58:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 01:58:51 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 01:58:51 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 01:58:51 --> Final output sent to browser
DEBUG - 2012-07-19 01:58:51 --> Total execution time: 0.0412
DEBUG - 2012-07-19 01:58:52 --> Config Class Initialized
DEBUG - 2012-07-19 01:58:52 --> Hooks Class Initialized
DEBUG - 2012-07-19 01:58:52 --> Utf8 Class Initialized
DEBUG - 2012-07-19 01:58:52 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 01:58:52 --> URI Class Initialized
DEBUG - 2012-07-19 01:58:52 --> Router Class Initialized
ERROR - 2012-07-19 01:58:52 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 02:00:08 --> Config Class Initialized
DEBUG - 2012-07-19 02:00:08 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:00:08 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:00:08 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:00:08 --> URI Class Initialized
DEBUG - 2012-07-19 02:00:08 --> Router Class Initialized
DEBUG - 2012-07-19 02:00:08 --> Output Class Initialized
DEBUG - 2012-07-19 02:00:08 --> Security Class Initialized
DEBUG - 2012-07-19 02:00:08 --> Input Class Initialized
DEBUG - 2012-07-19 02:00:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 02:00:08 --> Language Class Initialized
DEBUG - 2012-07-19 02:00:08 --> Loader Class Initialized
DEBUG - 2012-07-19 02:00:08 --> Helper loaded: url_helper
DEBUG - 2012-07-19 02:00:08 --> Controller Class Initialized
DEBUG - 2012-07-19 02:00:08 --> Model Class Initialized
DEBUG - 2012-07-19 02:00:08 --> Database Driver Class Initialized
DEBUG - 2012-07-19 02:00:08 --> Helper loaded: form_helper
DEBUG - 2012-07-19 02:00:08 --> Helper loaded: html_helper
DEBUG - 2012-07-19 02:00:08 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 02:00:08 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 02:00:08 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:00:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:00:08 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 02:00:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 02:00:08 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 02:00:08 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 02:00:08 --> Final output sent to browser
DEBUG - 2012-07-19 02:00:08 --> Total execution time: 0.0394
DEBUG - 2012-07-19 02:00:08 --> Config Class Initialized
DEBUG - 2012-07-19 02:00:08 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:00:08 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:00:08 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:00:08 --> URI Class Initialized
DEBUG - 2012-07-19 02:00:08 --> Router Class Initialized
ERROR - 2012-07-19 02:00:08 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 02:02:55 --> Config Class Initialized
DEBUG - 2012-07-19 02:02:55 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:02:55 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:02:55 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:02:55 --> URI Class Initialized
DEBUG - 2012-07-19 02:02:55 --> Router Class Initialized
DEBUG - 2012-07-19 02:02:55 --> Output Class Initialized
DEBUG - 2012-07-19 02:02:55 --> Security Class Initialized
DEBUG - 2012-07-19 02:02:55 --> Input Class Initialized
DEBUG - 2012-07-19 02:02:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 02:02:55 --> Language Class Initialized
DEBUG - 2012-07-19 02:02:55 --> Loader Class Initialized
DEBUG - 2012-07-19 02:02:55 --> Helper loaded: url_helper
DEBUG - 2012-07-19 02:02:55 --> Controller Class Initialized
DEBUG - 2012-07-19 02:02:55 --> Model Class Initialized
DEBUG - 2012-07-19 02:02:55 --> Database Driver Class Initialized
DEBUG - 2012-07-19 02:02:55 --> Helper loaded: form_helper
DEBUG - 2012-07-19 02:02:55 --> Helper loaded: html_helper
DEBUG - 2012-07-19 02:02:55 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 02:02:55 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 02:02:55 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:02:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:02:55 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 02:02:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 02:02:55 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 02:02:55 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 02:02:55 --> Final output sent to browser
DEBUG - 2012-07-19 02:02:55 --> Total execution time: 0.0399
DEBUG - 2012-07-19 02:02:56 --> Config Class Initialized
DEBUG - 2012-07-19 02:02:56 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:02:56 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:02:56 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:02:56 --> URI Class Initialized
DEBUG - 2012-07-19 02:02:56 --> Router Class Initialized
ERROR - 2012-07-19 02:02:56 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 02:06:18 --> Config Class Initialized
DEBUG - 2012-07-19 02:06:18 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:06:18 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:06:18 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:06:18 --> URI Class Initialized
DEBUG - 2012-07-19 02:06:18 --> Router Class Initialized
DEBUG - 2012-07-19 02:06:18 --> Output Class Initialized
DEBUG - 2012-07-19 02:06:18 --> Security Class Initialized
DEBUG - 2012-07-19 02:06:18 --> Input Class Initialized
DEBUG - 2012-07-19 02:06:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 02:06:18 --> Language Class Initialized
DEBUG - 2012-07-19 02:06:18 --> Loader Class Initialized
DEBUG - 2012-07-19 02:06:18 --> Helper loaded: url_helper
DEBUG - 2012-07-19 02:06:18 --> Controller Class Initialized
DEBUG - 2012-07-19 02:06:18 --> Model Class Initialized
DEBUG - 2012-07-19 02:06:18 --> Database Driver Class Initialized
DEBUG - 2012-07-19 02:06:18 --> Helper loaded: form_helper
DEBUG - 2012-07-19 02:06:18 --> Helper loaded: html_helper
DEBUG - 2012-07-19 02:06:18 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 02:06:18 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 02:06:18 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:06:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:06:18 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 02:06:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 02:06:18 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 02:06:18 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 02:06:18 --> Final output sent to browser
DEBUG - 2012-07-19 02:06:18 --> Total execution time: 0.0443
DEBUG - 2012-07-19 02:06:18 --> Config Class Initialized
DEBUG - 2012-07-19 02:06:18 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:06:18 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:06:18 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:06:18 --> URI Class Initialized
DEBUG - 2012-07-19 02:06:18 --> Router Class Initialized
ERROR - 2012-07-19 02:06:18 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 02:08:29 --> Config Class Initialized
DEBUG - 2012-07-19 02:08:29 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:08:29 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:08:29 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:08:29 --> URI Class Initialized
DEBUG - 2012-07-19 02:08:29 --> Router Class Initialized
DEBUG - 2012-07-19 02:08:29 --> Output Class Initialized
DEBUG - 2012-07-19 02:08:29 --> Security Class Initialized
DEBUG - 2012-07-19 02:08:29 --> Input Class Initialized
DEBUG - 2012-07-19 02:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 02:08:29 --> Language Class Initialized
DEBUG - 2012-07-19 02:08:29 --> Loader Class Initialized
DEBUG - 2012-07-19 02:08:29 --> Helper loaded: url_helper
DEBUG - 2012-07-19 02:08:29 --> Controller Class Initialized
DEBUG - 2012-07-19 02:08:29 --> Model Class Initialized
DEBUG - 2012-07-19 02:08:29 --> Database Driver Class Initialized
DEBUG - 2012-07-19 02:08:29 --> Helper loaded: form_helper
DEBUG - 2012-07-19 02:08:29 --> Helper loaded: html_helper
DEBUG - 2012-07-19 02:08:29 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 02:08:29 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 02:08:29 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:08:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:08:29 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 02:08:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 02:08:29 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 02:08:29 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 02:08:29 --> Final output sent to browser
DEBUG - 2012-07-19 02:08:29 --> Total execution time: 0.0398
DEBUG - 2012-07-19 02:08:30 --> Config Class Initialized
DEBUG - 2012-07-19 02:08:30 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:08:30 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:08:30 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:08:30 --> URI Class Initialized
DEBUG - 2012-07-19 02:08:30 --> Router Class Initialized
ERROR - 2012-07-19 02:08:30 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 02:09:12 --> Config Class Initialized
DEBUG - 2012-07-19 02:09:12 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:09:12 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:09:12 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:09:12 --> URI Class Initialized
DEBUG - 2012-07-19 02:09:12 --> Router Class Initialized
DEBUG - 2012-07-19 02:09:12 --> Output Class Initialized
DEBUG - 2012-07-19 02:09:12 --> Security Class Initialized
DEBUG - 2012-07-19 02:09:12 --> Input Class Initialized
DEBUG - 2012-07-19 02:09:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 02:09:12 --> Language Class Initialized
DEBUG - 2012-07-19 02:09:12 --> Loader Class Initialized
DEBUG - 2012-07-19 02:09:12 --> Helper loaded: url_helper
DEBUG - 2012-07-19 02:09:12 --> Controller Class Initialized
DEBUG - 2012-07-19 02:09:12 --> Model Class Initialized
DEBUG - 2012-07-19 02:09:12 --> Database Driver Class Initialized
DEBUG - 2012-07-19 02:09:12 --> Helper loaded: form_helper
DEBUG - 2012-07-19 02:09:12 --> Helper loaded: html_helper
DEBUG - 2012-07-19 02:09:12 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 02:09:12 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 02:09:12 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:09:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:09:12 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 02:09:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 02:09:12 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 02:09:12 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 02:09:12 --> Final output sent to browser
DEBUG - 2012-07-19 02:09:12 --> Total execution time: 0.0402
DEBUG - 2012-07-19 02:09:12 --> Config Class Initialized
DEBUG - 2012-07-19 02:09:12 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:09:12 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:09:12 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:09:12 --> URI Class Initialized
DEBUG - 2012-07-19 02:09:12 --> Router Class Initialized
ERROR - 2012-07-19 02:09:12 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 02:10:44 --> Config Class Initialized
DEBUG - 2012-07-19 02:10:44 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:10:44 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:10:44 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:10:44 --> URI Class Initialized
DEBUG - 2012-07-19 02:10:44 --> Router Class Initialized
DEBUG - 2012-07-19 02:10:44 --> Output Class Initialized
DEBUG - 2012-07-19 02:10:44 --> Security Class Initialized
DEBUG - 2012-07-19 02:10:44 --> Input Class Initialized
DEBUG - 2012-07-19 02:10:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 02:10:44 --> Language Class Initialized
DEBUG - 2012-07-19 02:10:44 --> Loader Class Initialized
DEBUG - 2012-07-19 02:10:44 --> Helper loaded: url_helper
DEBUG - 2012-07-19 02:10:44 --> Controller Class Initialized
DEBUG - 2012-07-19 02:10:44 --> Model Class Initialized
DEBUG - 2012-07-19 02:10:44 --> Database Driver Class Initialized
DEBUG - 2012-07-19 02:10:44 --> Helper loaded: form_helper
DEBUG - 2012-07-19 02:10:44 --> Helper loaded: html_helper
DEBUG - 2012-07-19 02:10:44 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 02:10:44 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 02:10:44 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:10:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:10:44 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 02:10:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 02:10:44 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 02:10:44 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 02:10:44 --> Final output sent to browser
DEBUG - 2012-07-19 02:10:44 --> Total execution time: 0.0398
DEBUG - 2012-07-19 02:10:44 --> Config Class Initialized
DEBUG - 2012-07-19 02:10:44 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:10:44 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:10:44 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:10:44 --> URI Class Initialized
DEBUG - 2012-07-19 02:10:44 --> Router Class Initialized
ERROR - 2012-07-19 02:10:44 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 02:11:20 --> Config Class Initialized
DEBUG - 2012-07-19 02:11:20 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:11:20 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:11:20 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:11:20 --> URI Class Initialized
DEBUG - 2012-07-19 02:11:20 --> Router Class Initialized
DEBUG - 2012-07-19 02:11:20 --> Output Class Initialized
DEBUG - 2012-07-19 02:11:20 --> Security Class Initialized
DEBUG - 2012-07-19 02:11:20 --> Input Class Initialized
DEBUG - 2012-07-19 02:11:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 02:11:20 --> Language Class Initialized
DEBUG - 2012-07-19 02:11:20 --> Loader Class Initialized
DEBUG - 2012-07-19 02:11:20 --> Helper loaded: url_helper
DEBUG - 2012-07-19 02:11:20 --> Controller Class Initialized
DEBUG - 2012-07-19 02:11:20 --> Model Class Initialized
DEBUG - 2012-07-19 02:11:20 --> Database Driver Class Initialized
DEBUG - 2012-07-19 02:11:20 --> Helper loaded: form_helper
DEBUG - 2012-07-19 02:11:20 --> Helper loaded: html_helper
DEBUG - 2012-07-19 02:11:20 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 02:11:20 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 02:11:20 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:11:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:11:20 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 02:11:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 02:11:20 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 02:11:20 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 02:11:20 --> Final output sent to browser
DEBUG - 2012-07-19 02:11:20 --> Total execution time: 0.0402
DEBUG - 2012-07-19 02:11:20 --> Config Class Initialized
DEBUG - 2012-07-19 02:11:20 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:11:20 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:11:20 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:11:20 --> URI Class Initialized
DEBUG - 2012-07-19 02:11:20 --> Router Class Initialized
ERROR - 2012-07-19 02:11:20 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 02:13:08 --> Config Class Initialized
DEBUG - 2012-07-19 02:13:08 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:13:08 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:13:08 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:13:08 --> URI Class Initialized
DEBUG - 2012-07-19 02:13:08 --> Router Class Initialized
DEBUG - 2012-07-19 02:13:08 --> Output Class Initialized
DEBUG - 2012-07-19 02:13:08 --> Security Class Initialized
DEBUG - 2012-07-19 02:13:08 --> Input Class Initialized
DEBUG - 2012-07-19 02:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 02:13:08 --> Language Class Initialized
DEBUG - 2012-07-19 02:13:08 --> Loader Class Initialized
DEBUG - 2012-07-19 02:13:08 --> Helper loaded: url_helper
DEBUG - 2012-07-19 02:13:08 --> Controller Class Initialized
DEBUG - 2012-07-19 02:13:08 --> Model Class Initialized
DEBUG - 2012-07-19 02:13:08 --> Database Driver Class Initialized
DEBUG - 2012-07-19 02:13:08 --> Helper loaded: form_helper
DEBUG - 2012-07-19 02:13:08 --> Helper loaded: html_helper
DEBUG - 2012-07-19 02:13:08 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 02:13:08 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 02:13:08 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:13:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:13:08 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 02:13:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 02:13:08 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 02:13:08 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 02:13:08 --> Final output sent to browser
DEBUG - 2012-07-19 02:13:08 --> Total execution time: 0.0404
DEBUG - 2012-07-19 02:13:09 --> Config Class Initialized
DEBUG - 2012-07-19 02:13:09 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:13:09 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:13:09 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:13:09 --> URI Class Initialized
DEBUG - 2012-07-19 02:13:09 --> Router Class Initialized
ERROR - 2012-07-19 02:13:09 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 02:13:45 --> Config Class Initialized
DEBUG - 2012-07-19 02:13:45 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:13:45 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:13:45 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:13:45 --> URI Class Initialized
DEBUG - 2012-07-19 02:13:45 --> Router Class Initialized
DEBUG - 2012-07-19 02:13:45 --> Output Class Initialized
DEBUG - 2012-07-19 02:13:45 --> Security Class Initialized
DEBUG - 2012-07-19 02:13:45 --> Input Class Initialized
DEBUG - 2012-07-19 02:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 02:13:45 --> Language Class Initialized
DEBUG - 2012-07-19 02:13:45 --> Loader Class Initialized
DEBUG - 2012-07-19 02:13:45 --> Helper loaded: url_helper
DEBUG - 2012-07-19 02:13:45 --> Controller Class Initialized
DEBUG - 2012-07-19 02:13:45 --> Model Class Initialized
DEBUG - 2012-07-19 02:13:45 --> Database Driver Class Initialized
DEBUG - 2012-07-19 02:13:45 --> Helper loaded: form_helper
DEBUG - 2012-07-19 02:13:45 --> Helper loaded: html_helper
DEBUG - 2012-07-19 02:13:45 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 02:13:45 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 02:13:45 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:13:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:13:45 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 02:13:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 02:13:45 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 02:13:45 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 02:13:45 --> Final output sent to browser
DEBUG - 2012-07-19 02:13:45 --> Total execution time: 0.0509
DEBUG - 2012-07-19 02:13:46 --> Config Class Initialized
DEBUG - 2012-07-19 02:13:46 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:13:46 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:13:46 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:13:46 --> URI Class Initialized
DEBUG - 2012-07-19 02:13:46 --> Router Class Initialized
ERROR - 2012-07-19 02:13:46 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 02:15:26 --> Config Class Initialized
DEBUG - 2012-07-19 02:15:26 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:15:26 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:15:26 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:15:26 --> URI Class Initialized
DEBUG - 2012-07-19 02:15:26 --> Router Class Initialized
DEBUG - 2012-07-19 02:15:26 --> Output Class Initialized
DEBUG - 2012-07-19 02:15:26 --> Security Class Initialized
DEBUG - 2012-07-19 02:15:26 --> Input Class Initialized
DEBUG - 2012-07-19 02:15:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 02:15:26 --> Language Class Initialized
DEBUG - 2012-07-19 02:15:26 --> Loader Class Initialized
DEBUG - 2012-07-19 02:15:26 --> Helper loaded: url_helper
DEBUG - 2012-07-19 02:15:26 --> Controller Class Initialized
DEBUG - 2012-07-19 02:15:26 --> Model Class Initialized
DEBUG - 2012-07-19 02:15:26 --> Database Driver Class Initialized
DEBUG - 2012-07-19 02:15:26 --> Helper loaded: form_helper
DEBUG - 2012-07-19 02:15:26 --> Helper loaded: html_helper
DEBUG - 2012-07-19 02:15:26 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 02:15:26 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 02:15:26 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:15:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:15:26 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 02:15:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 02:15:26 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 02:15:26 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 02:15:26 --> Final output sent to browser
DEBUG - 2012-07-19 02:15:26 --> Total execution time: 0.0395
DEBUG - 2012-07-19 02:15:27 --> Config Class Initialized
DEBUG - 2012-07-19 02:15:27 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:15:27 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:15:27 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:15:27 --> URI Class Initialized
DEBUG - 2012-07-19 02:15:27 --> Router Class Initialized
ERROR - 2012-07-19 02:15:27 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 02:24:05 --> Config Class Initialized
DEBUG - 2012-07-19 02:24:05 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:24:05 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:24:05 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:24:05 --> URI Class Initialized
DEBUG - 2012-07-19 02:24:05 --> Router Class Initialized
DEBUG - 2012-07-19 02:24:05 --> Output Class Initialized
DEBUG - 2012-07-19 02:24:05 --> Security Class Initialized
DEBUG - 2012-07-19 02:24:05 --> Input Class Initialized
DEBUG - 2012-07-19 02:24:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 02:24:05 --> Language Class Initialized
DEBUG - 2012-07-19 02:24:05 --> Loader Class Initialized
DEBUG - 2012-07-19 02:24:05 --> Helper loaded: url_helper
DEBUG - 2012-07-19 02:24:05 --> Controller Class Initialized
DEBUG - 2012-07-19 02:24:05 --> Model Class Initialized
DEBUG - 2012-07-19 02:24:05 --> Database Driver Class Initialized
DEBUG - 2012-07-19 02:24:05 --> Helper loaded: form_helper
DEBUG - 2012-07-19 02:24:05 --> Helper loaded: html_helper
DEBUG - 2012-07-19 02:24:05 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 02:24:05 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 02:24:05 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:24:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:24:05 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 02:24:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 02:24:05 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 02:24:05 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 02:24:05 --> Final output sent to browser
DEBUG - 2012-07-19 02:24:05 --> Total execution time: 0.0407
DEBUG - 2012-07-19 02:24:06 --> Config Class Initialized
DEBUG - 2012-07-19 02:24:06 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:24:06 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:24:06 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:24:06 --> URI Class Initialized
DEBUG - 2012-07-19 02:24:06 --> Router Class Initialized
ERROR - 2012-07-19 02:24:06 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 02:24:45 --> Config Class Initialized
DEBUG - 2012-07-19 02:24:45 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:24:45 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:24:45 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:24:45 --> URI Class Initialized
DEBUG - 2012-07-19 02:24:45 --> Router Class Initialized
DEBUG - 2012-07-19 02:24:45 --> Output Class Initialized
DEBUG - 2012-07-19 02:24:45 --> Security Class Initialized
DEBUG - 2012-07-19 02:24:45 --> Input Class Initialized
DEBUG - 2012-07-19 02:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 02:24:45 --> Language Class Initialized
DEBUG - 2012-07-19 02:24:45 --> Loader Class Initialized
DEBUG - 2012-07-19 02:24:45 --> Helper loaded: url_helper
DEBUG - 2012-07-19 02:24:45 --> Controller Class Initialized
DEBUG - 2012-07-19 02:24:45 --> Model Class Initialized
DEBUG - 2012-07-19 02:24:45 --> Database Driver Class Initialized
DEBUG - 2012-07-19 02:24:45 --> Helper loaded: form_helper
DEBUG - 2012-07-19 02:24:45 --> Helper loaded: html_helper
DEBUG - 2012-07-19 02:24:45 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 02:24:45 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 02:24:45 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:24:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:24:45 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 02:24:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 02:24:45 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 02:24:45 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 02:24:45 --> Final output sent to browser
DEBUG - 2012-07-19 02:24:45 --> Total execution time: 0.0461
DEBUG - 2012-07-19 02:24:46 --> Config Class Initialized
DEBUG - 2012-07-19 02:24:46 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:24:46 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:24:46 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:24:46 --> URI Class Initialized
DEBUG - 2012-07-19 02:24:46 --> Router Class Initialized
ERROR - 2012-07-19 02:24:46 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 02:25:58 --> Config Class Initialized
DEBUG - 2012-07-19 02:25:58 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:25:58 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:25:58 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:25:58 --> URI Class Initialized
DEBUG - 2012-07-19 02:25:58 --> Router Class Initialized
DEBUG - 2012-07-19 02:25:58 --> Output Class Initialized
DEBUG - 2012-07-19 02:25:58 --> Security Class Initialized
DEBUG - 2012-07-19 02:25:58 --> Input Class Initialized
DEBUG - 2012-07-19 02:25:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 02:25:58 --> Language Class Initialized
DEBUG - 2012-07-19 02:25:58 --> Loader Class Initialized
DEBUG - 2012-07-19 02:25:58 --> Helper loaded: url_helper
DEBUG - 2012-07-19 02:25:58 --> Controller Class Initialized
DEBUG - 2012-07-19 02:25:58 --> Model Class Initialized
DEBUG - 2012-07-19 02:25:58 --> Database Driver Class Initialized
DEBUG - 2012-07-19 02:25:58 --> Helper loaded: form_helper
DEBUG - 2012-07-19 02:25:58 --> Helper loaded: html_helper
DEBUG - 2012-07-19 02:25:58 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 02:25:58 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 02:25:58 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:25:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:25:58 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 02:25:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 02:25:58 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 02:25:58 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 02:25:58 --> Final output sent to browser
DEBUG - 2012-07-19 02:25:58 --> Total execution time: 0.0459
DEBUG - 2012-07-19 02:25:58 --> Config Class Initialized
DEBUG - 2012-07-19 02:25:58 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:25:58 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:25:58 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:25:58 --> URI Class Initialized
DEBUG - 2012-07-19 02:25:58 --> Router Class Initialized
ERROR - 2012-07-19 02:25:58 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 02:26:22 --> Config Class Initialized
DEBUG - 2012-07-19 02:26:22 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:26:22 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:26:22 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:26:22 --> URI Class Initialized
DEBUG - 2012-07-19 02:26:22 --> Router Class Initialized
DEBUG - 2012-07-19 02:26:22 --> Output Class Initialized
DEBUG - 2012-07-19 02:26:22 --> Security Class Initialized
DEBUG - 2012-07-19 02:26:22 --> Input Class Initialized
DEBUG - 2012-07-19 02:26:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 02:26:22 --> Language Class Initialized
DEBUG - 2012-07-19 02:26:22 --> Loader Class Initialized
DEBUG - 2012-07-19 02:26:22 --> Helper loaded: url_helper
DEBUG - 2012-07-19 02:26:22 --> Controller Class Initialized
DEBUG - 2012-07-19 02:26:22 --> Model Class Initialized
DEBUG - 2012-07-19 02:26:22 --> Database Driver Class Initialized
DEBUG - 2012-07-19 02:26:22 --> Helper loaded: form_helper
DEBUG - 2012-07-19 02:26:22 --> Helper loaded: html_helper
DEBUG - 2012-07-19 02:26:22 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 02:26:22 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 02:26:22 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:26:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:26:22 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 02:26:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 02:26:22 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 02:26:22 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 02:26:22 --> Final output sent to browser
DEBUG - 2012-07-19 02:26:22 --> Total execution time: 0.0553
DEBUG - 2012-07-19 02:26:22 --> Config Class Initialized
DEBUG - 2012-07-19 02:26:22 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:26:22 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:26:22 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:26:22 --> URI Class Initialized
DEBUG - 2012-07-19 02:26:22 --> Router Class Initialized
ERROR - 2012-07-19 02:26:22 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 02:26:43 --> Config Class Initialized
DEBUG - 2012-07-19 02:26:43 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:26:43 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:26:43 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:26:43 --> URI Class Initialized
DEBUG - 2012-07-19 02:26:43 --> Router Class Initialized
DEBUG - 2012-07-19 02:26:43 --> Output Class Initialized
DEBUG - 2012-07-19 02:26:43 --> Security Class Initialized
DEBUG - 2012-07-19 02:26:43 --> Input Class Initialized
DEBUG - 2012-07-19 02:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 02:26:43 --> Language Class Initialized
DEBUG - 2012-07-19 02:26:43 --> Loader Class Initialized
DEBUG - 2012-07-19 02:26:43 --> Helper loaded: url_helper
DEBUG - 2012-07-19 02:26:43 --> Controller Class Initialized
DEBUG - 2012-07-19 02:26:43 --> Model Class Initialized
DEBUG - 2012-07-19 02:26:43 --> Database Driver Class Initialized
DEBUG - 2012-07-19 02:26:43 --> Helper loaded: form_helper
DEBUG - 2012-07-19 02:26:43 --> Helper loaded: html_helper
DEBUG - 2012-07-19 02:26:43 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 02:26:43 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 02:26:43 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:26:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:26:43 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 02:26:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 02:26:43 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 02:26:43 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 02:26:43 --> Final output sent to browser
DEBUG - 2012-07-19 02:26:43 --> Total execution time: 0.0419
DEBUG - 2012-07-19 02:26:43 --> Config Class Initialized
DEBUG - 2012-07-19 02:26:43 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:26:43 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:26:43 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:26:43 --> URI Class Initialized
DEBUG - 2012-07-19 02:26:43 --> Router Class Initialized
ERROR - 2012-07-19 02:26:43 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 02:26:55 --> Config Class Initialized
DEBUG - 2012-07-19 02:26:55 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:26:55 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:26:55 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:26:55 --> URI Class Initialized
DEBUG - 2012-07-19 02:26:55 --> Router Class Initialized
DEBUG - 2012-07-19 02:26:55 --> Output Class Initialized
DEBUG - 2012-07-19 02:26:55 --> Security Class Initialized
DEBUG - 2012-07-19 02:26:55 --> Input Class Initialized
DEBUG - 2012-07-19 02:26:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 02:26:55 --> Language Class Initialized
DEBUG - 2012-07-19 02:26:55 --> Loader Class Initialized
DEBUG - 2012-07-19 02:26:55 --> Helper loaded: url_helper
DEBUG - 2012-07-19 02:26:55 --> Controller Class Initialized
DEBUG - 2012-07-19 02:26:55 --> Model Class Initialized
DEBUG - 2012-07-19 02:26:55 --> Database Driver Class Initialized
DEBUG - 2012-07-19 02:26:55 --> Helper loaded: form_helper
DEBUG - 2012-07-19 02:26:55 --> Helper loaded: html_helper
DEBUG - 2012-07-19 02:26:55 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 02:26:55 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 02:26:55 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:26:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:26:55 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 02:26:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 02:26:55 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 02:26:55 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 02:26:55 --> Final output sent to browser
DEBUG - 2012-07-19 02:26:55 --> Total execution time: 0.0403
DEBUG - 2012-07-19 02:26:55 --> Config Class Initialized
DEBUG - 2012-07-19 02:26:55 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:26:55 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:26:55 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:26:55 --> URI Class Initialized
DEBUG - 2012-07-19 02:26:55 --> Router Class Initialized
ERROR - 2012-07-19 02:26:55 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 02:27:35 --> Config Class Initialized
DEBUG - 2012-07-19 02:27:35 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:27:35 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:27:35 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:27:35 --> URI Class Initialized
DEBUG - 2012-07-19 02:27:35 --> Router Class Initialized
DEBUG - 2012-07-19 02:27:35 --> Output Class Initialized
DEBUG - 2012-07-19 02:27:35 --> Security Class Initialized
DEBUG - 2012-07-19 02:27:35 --> Input Class Initialized
DEBUG - 2012-07-19 02:27:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 02:27:35 --> Language Class Initialized
DEBUG - 2012-07-19 02:27:35 --> Loader Class Initialized
DEBUG - 2012-07-19 02:27:35 --> Helper loaded: url_helper
DEBUG - 2012-07-19 02:27:35 --> Controller Class Initialized
DEBUG - 2012-07-19 02:27:35 --> Model Class Initialized
DEBUG - 2012-07-19 02:27:35 --> Database Driver Class Initialized
DEBUG - 2012-07-19 02:27:35 --> Helper loaded: form_helper
DEBUG - 2012-07-19 02:27:35 --> Helper loaded: html_helper
DEBUG - 2012-07-19 02:27:35 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 02:27:35 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 02:27:35 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:27:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:27:35 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 02:27:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 02:27:35 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 02:27:35 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 02:27:35 --> Final output sent to browser
DEBUG - 2012-07-19 02:27:35 --> Total execution time: 0.0396
DEBUG - 2012-07-19 02:27:35 --> Config Class Initialized
DEBUG - 2012-07-19 02:27:35 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:27:35 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:27:35 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:27:35 --> URI Class Initialized
DEBUG - 2012-07-19 02:27:35 --> Router Class Initialized
ERROR - 2012-07-19 02:27:35 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 02:28:38 --> Config Class Initialized
DEBUG - 2012-07-19 02:28:38 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:28:38 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:28:38 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:28:38 --> URI Class Initialized
DEBUG - 2012-07-19 02:28:38 --> Router Class Initialized
DEBUG - 2012-07-19 02:28:38 --> Output Class Initialized
DEBUG - 2012-07-19 02:28:38 --> Security Class Initialized
DEBUG - 2012-07-19 02:28:38 --> Input Class Initialized
DEBUG - 2012-07-19 02:28:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 02:28:38 --> Language Class Initialized
DEBUG - 2012-07-19 02:28:38 --> Loader Class Initialized
DEBUG - 2012-07-19 02:28:38 --> Helper loaded: url_helper
DEBUG - 2012-07-19 02:28:38 --> Controller Class Initialized
DEBUG - 2012-07-19 02:28:38 --> Model Class Initialized
DEBUG - 2012-07-19 02:28:38 --> Database Driver Class Initialized
DEBUG - 2012-07-19 02:28:38 --> Helper loaded: form_helper
DEBUG - 2012-07-19 02:28:38 --> Helper loaded: html_helper
DEBUG - 2012-07-19 02:28:38 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 02:28:38 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 02:28:38 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:28:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:28:38 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 02:28:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 02:28:38 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 02:28:38 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 02:28:38 --> Final output sent to browser
DEBUG - 2012-07-19 02:28:38 --> Total execution time: 0.0405
DEBUG - 2012-07-19 02:28:38 --> Config Class Initialized
DEBUG - 2012-07-19 02:28:38 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:28:38 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:28:38 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:28:38 --> URI Class Initialized
DEBUG - 2012-07-19 02:28:38 --> Router Class Initialized
ERROR - 2012-07-19 02:28:38 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 02:33:10 --> Config Class Initialized
DEBUG - 2012-07-19 02:33:10 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:33:10 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:33:10 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:33:10 --> URI Class Initialized
DEBUG - 2012-07-19 02:33:10 --> Router Class Initialized
DEBUG - 2012-07-19 02:33:10 --> Output Class Initialized
DEBUG - 2012-07-19 02:33:10 --> Security Class Initialized
DEBUG - 2012-07-19 02:33:10 --> Input Class Initialized
DEBUG - 2012-07-19 02:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 02:33:10 --> Language Class Initialized
DEBUG - 2012-07-19 02:33:10 --> Loader Class Initialized
DEBUG - 2012-07-19 02:33:10 --> Helper loaded: url_helper
DEBUG - 2012-07-19 02:33:10 --> Controller Class Initialized
DEBUG - 2012-07-19 02:33:10 --> Model Class Initialized
DEBUG - 2012-07-19 02:33:10 --> Database Driver Class Initialized
DEBUG - 2012-07-19 02:33:10 --> Helper loaded: form_helper
DEBUG - 2012-07-19 02:33:10 --> Helper loaded: html_helper
DEBUG - 2012-07-19 02:33:10 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 02:33:10 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 02:33:10 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:33:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:33:10 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 02:33:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 02:33:10 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 02:33:10 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 02:33:10 --> Final output sent to browser
DEBUG - 2012-07-19 02:33:10 --> Total execution time: 0.0399
DEBUG - 2012-07-19 02:33:10 --> Config Class Initialized
DEBUG - 2012-07-19 02:33:10 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:33:10 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:33:10 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:33:10 --> URI Class Initialized
DEBUG - 2012-07-19 02:33:10 --> Router Class Initialized
ERROR - 2012-07-19 02:33:10 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 02:57:29 --> Config Class Initialized
DEBUG - 2012-07-19 02:57:29 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:57:29 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:57:29 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:57:29 --> URI Class Initialized
DEBUG - 2012-07-19 02:57:29 --> Router Class Initialized
DEBUG - 2012-07-19 02:57:29 --> Output Class Initialized
DEBUG - 2012-07-19 02:57:29 --> Security Class Initialized
DEBUG - 2012-07-19 02:57:29 --> Input Class Initialized
DEBUG - 2012-07-19 02:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 02:57:29 --> Language Class Initialized
DEBUG - 2012-07-19 02:57:29 --> Loader Class Initialized
DEBUG - 2012-07-19 02:57:29 --> Helper loaded: url_helper
DEBUG - 2012-07-19 02:57:29 --> Controller Class Initialized
DEBUG - 2012-07-19 02:57:29 --> Model Class Initialized
DEBUG - 2012-07-19 02:57:29 --> Database Driver Class Initialized
DEBUG - 2012-07-19 02:57:29 --> Helper loaded: form_helper
DEBUG - 2012-07-19 02:57:29 --> Helper loaded: html_helper
DEBUG - 2012-07-19 02:57:29 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 02:57:29 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 02:57:29 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:57:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 02:57:29 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 02:57:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 02:57:29 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 02:57:29 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 02:57:29 --> Final output sent to browser
DEBUG - 2012-07-19 02:57:29 --> Total execution time: 0.0402
DEBUG - 2012-07-19 02:57:29 --> Config Class Initialized
DEBUG - 2012-07-19 02:57:29 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:57:29 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:57:29 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:57:29 --> URI Class Initialized
DEBUG - 2012-07-19 02:57:29 --> Router Class Initialized
ERROR - 2012-07-19 02:57:29 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 02:57:30 --> Config Class Initialized
DEBUG - 2012-07-19 02:57:30 --> Hooks Class Initialized
DEBUG - 2012-07-19 02:57:30 --> Utf8 Class Initialized
DEBUG - 2012-07-19 02:57:30 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 02:57:30 --> URI Class Initialized
DEBUG - 2012-07-19 02:57:30 --> Router Class Initialized
ERROR - 2012-07-19 02:57:30 --> 404 Page Not Found --> css
DEBUG - 2012-07-19 07:31:28 --> Config Class Initialized
DEBUG - 2012-07-19 07:31:28 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:31:28 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:31:28 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:31:28 --> URI Class Initialized
DEBUG - 2012-07-19 07:31:28 --> Router Class Initialized
DEBUG - 2012-07-19 07:31:28 --> Output Class Initialized
DEBUG - 2012-07-19 07:31:28 --> Security Class Initialized
DEBUG - 2012-07-19 07:31:28 --> Input Class Initialized
DEBUG - 2012-07-19 07:31:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 07:31:28 --> Language Class Initialized
DEBUG - 2012-07-19 07:31:28 --> Loader Class Initialized
DEBUG - 2012-07-19 07:31:28 --> Helper loaded: url_helper
DEBUG - 2012-07-19 07:31:28 --> Controller Class Initialized
DEBUG - 2012-07-19 07:31:28 --> Model Class Initialized
DEBUG - 2012-07-19 07:31:28 --> Database Driver Class Initialized
DEBUG - 2012-07-19 07:31:28 --> Helper loaded: form_helper
DEBUG - 2012-07-19 07:31:28 --> Helper loaded: html_helper
DEBUG - 2012-07-19 07:31:28 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 07:31:28 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 07:31:28 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:31:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:31:28 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 07:31:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 07:31:28 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 07:31:28 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 07:31:28 --> Final output sent to browser
DEBUG - 2012-07-19 07:31:28 --> Total execution time: 0.0511
DEBUG - 2012-07-19 07:31:28 --> Config Class Initialized
DEBUG - 2012-07-19 07:31:28 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:31:28 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:31:28 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:31:28 --> URI Class Initialized
DEBUG - 2012-07-19 07:31:28 --> Router Class Initialized
ERROR - 2012-07-19 07:31:28 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 07:32:10 --> Config Class Initialized
DEBUG - 2012-07-19 07:32:10 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:32:10 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:32:10 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:32:10 --> URI Class Initialized
DEBUG - 2012-07-19 07:32:10 --> Router Class Initialized
DEBUG - 2012-07-19 07:32:10 --> Output Class Initialized
DEBUG - 2012-07-19 07:32:10 --> Security Class Initialized
DEBUG - 2012-07-19 07:32:10 --> Input Class Initialized
DEBUG - 2012-07-19 07:32:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 07:32:10 --> Language Class Initialized
DEBUG - 2012-07-19 07:32:10 --> Loader Class Initialized
DEBUG - 2012-07-19 07:32:10 --> Helper loaded: url_helper
DEBUG - 2012-07-19 07:32:10 --> Controller Class Initialized
DEBUG - 2012-07-19 07:32:10 --> Model Class Initialized
DEBUG - 2012-07-19 07:32:10 --> Database Driver Class Initialized
DEBUG - 2012-07-19 07:32:10 --> Helper loaded: form_helper
DEBUG - 2012-07-19 07:32:10 --> Helper loaded: html_helper
DEBUG - 2012-07-19 07:32:10 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 07:32:10 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 07:32:10 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:32:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:32:10 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 07:32:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 07:32:10 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 07:32:10 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 07:32:10 --> Final output sent to browser
DEBUG - 2012-07-19 07:32:10 --> Total execution time: 0.0443
DEBUG - 2012-07-19 07:32:10 --> Config Class Initialized
DEBUG - 2012-07-19 07:32:10 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:32:10 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:32:10 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:32:10 --> URI Class Initialized
DEBUG - 2012-07-19 07:32:10 --> Router Class Initialized
ERROR - 2012-07-19 07:32:10 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 07:32:11 --> Config Class Initialized
DEBUG - 2012-07-19 07:32:11 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:32:11 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:32:11 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:32:11 --> URI Class Initialized
DEBUG - 2012-07-19 07:32:11 --> Router Class Initialized
ERROR - 2012-07-19 07:32:11 --> 404 Page Not Found --> css
DEBUG - 2012-07-19 07:32:36 --> Config Class Initialized
DEBUG - 2012-07-19 07:32:36 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:32:36 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:32:36 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:32:36 --> URI Class Initialized
DEBUG - 2012-07-19 07:32:36 --> Router Class Initialized
DEBUG - 2012-07-19 07:32:36 --> Output Class Initialized
DEBUG - 2012-07-19 07:32:36 --> Security Class Initialized
DEBUG - 2012-07-19 07:32:36 --> Input Class Initialized
DEBUG - 2012-07-19 07:32:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 07:32:36 --> Language Class Initialized
DEBUG - 2012-07-19 07:32:36 --> Loader Class Initialized
DEBUG - 2012-07-19 07:32:36 --> Helper loaded: url_helper
DEBUG - 2012-07-19 07:32:36 --> Controller Class Initialized
DEBUG - 2012-07-19 07:32:36 --> Model Class Initialized
DEBUG - 2012-07-19 07:32:36 --> Database Driver Class Initialized
DEBUG - 2012-07-19 07:32:36 --> Helper loaded: form_helper
DEBUG - 2012-07-19 07:32:36 --> Helper loaded: html_helper
DEBUG - 2012-07-19 07:32:36 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 07:32:36 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 07:32:36 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:32:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:32:36 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 07:32:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 07:32:36 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 07:32:36 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 07:32:36 --> Final output sent to browser
DEBUG - 2012-07-19 07:32:36 --> Total execution time: 0.0444
DEBUG - 2012-07-19 07:32:37 --> Config Class Initialized
DEBUG - 2012-07-19 07:32:37 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:32:37 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:32:37 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:32:37 --> URI Class Initialized
DEBUG - 2012-07-19 07:32:37 --> Router Class Initialized
ERROR - 2012-07-19 07:32:37 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 07:32:38 --> Config Class Initialized
DEBUG - 2012-07-19 07:32:38 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:32:38 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:32:38 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:32:38 --> URI Class Initialized
DEBUG - 2012-07-19 07:32:38 --> Router Class Initialized
ERROR - 2012-07-19 07:32:38 --> 404 Page Not Found --> css
DEBUG - 2012-07-19 07:33:17 --> Config Class Initialized
DEBUG - 2012-07-19 07:33:17 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:33:17 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:33:17 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:33:17 --> URI Class Initialized
DEBUG - 2012-07-19 07:33:17 --> Router Class Initialized
DEBUG - 2012-07-19 07:33:17 --> Output Class Initialized
DEBUG - 2012-07-19 07:33:17 --> Security Class Initialized
DEBUG - 2012-07-19 07:33:17 --> Input Class Initialized
DEBUG - 2012-07-19 07:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 07:33:17 --> Language Class Initialized
DEBUG - 2012-07-19 07:33:17 --> Loader Class Initialized
DEBUG - 2012-07-19 07:33:17 --> Helper loaded: url_helper
DEBUG - 2012-07-19 07:33:17 --> Controller Class Initialized
DEBUG - 2012-07-19 07:33:17 --> Model Class Initialized
DEBUG - 2012-07-19 07:33:17 --> Database Driver Class Initialized
DEBUG - 2012-07-19 07:33:17 --> Helper loaded: form_helper
DEBUG - 2012-07-19 07:33:17 --> Helper loaded: html_helper
DEBUG - 2012-07-19 07:33:17 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 07:33:17 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 07:33:17 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:33:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:33:17 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 07:33:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 07:33:17 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 07:33:17 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 07:33:17 --> Final output sent to browser
DEBUG - 2012-07-19 07:33:17 --> Total execution time: 0.0440
DEBUG - 2012-07-19 07:33:17 --> Config Class Initialized
DEBUG - 2012-07-19 07:33:17 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:33:17 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:33:17 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:33:17 --> URI Class Initialized
DEBUG - 2012-07-19 07:33:17 --> Router Class Initialized
ERROR - 2012-07-19 07:33:17 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 07:33:20 --> Config Class Initialized
DEBUG - 2012-07-19 07:33:20 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:33:20 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:33:20 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:33:20 --> URI Class Initialized
DEBUG - 2012-07-19 07:33:20 --> Router Class Initialized
ERROR - 2012-07-19 07:33:20 --> 404 Page Not Found --> css
DEBUG - 2012-07-19 07:33:23 --> Config Class Initialized
DEBUG - 2012-07-19 07:33:23 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:33:23 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:33:23 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:33:23 --> URI Class Initialized
DEBUG - 2012-07-19 07:33:23 --> Router Class Initialized
DEBUG - 2012-07-19 07:33:23 --> Output Class Initialized
DEBUG - 2012-07-19 07:33:23 --> Security Class Initialized
DEBUG - 2012-07-19 07:33:23 --> Input Class Initialized
DEBUG - 2012-07-19 07:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 07:33:23 --> Language Class Initialized
DEBUG - 2012-07-19 07:33:23 --> Loader Class Initialized
DEBUG - 2012-07-19 07:33:23 --> Helper loaded: url_helper
DEBUG - 2012-07-19 07:33:23 --> Controller Class Initialized
DEBUG - 2012-07-19 07:33:23 --> Model Class Initialized
DEBUG - 2012-07-19 07:33:23 --> Database Driver Class Initialized
DEBUG - 2012-07-19 07:33:23 --> Helper loaded: form_helper
DEBUG - 2012-07-19 07:33:23 --> Helper loaded: html_helper
DEBUG - 2012-07-19 07:33:23 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 07:33:23 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 07:33:23 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:33:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:33:23 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 07:33:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 07:33:23 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 07:33:23 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 07:33:23 --> Final output sent to browser
DEBUG - 2012-07-19 07:33:23 --> Total execution time: 0.0569
DEBUG - 2012-07-19 07:33:23 --> Config Class Initialized
DEBUG - 2012-07-19 07:33:23 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:33:23 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:33:23 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:33:23 --> URI Class Initialized
DEBUG - 2012-07-19 07:33:23 --> Router Class Initialized
ERROR - 2012-07-19 07:33:23 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 07:34:04 --> Config Class Initialized
DEBUG - 2012-07-19 07:34:04 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:34:04 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:34:04 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:34:04 --> URI Class Initialized
DEBUG - 2012-07-19 07:34:04 --> Router Class Initialized
DEBUG - 2012-07-19 07:34:04 --> Output Class Initialized
DEBUG - 2012-07-19 07:34:04 --> Security Class Initialized
DEBUG - 2012-07-19 07:34:04 --> Input Class Initialized
DEBUG - 2012-07-19 07:34:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 07:34:04 --> Language Class Initialized
DEBUG - 2012-07-19 07:34:04 --> Loader Class Initialized
DEBUG - 2012-07-19 07:34:04 --> Helper loaded: url_helper
DEBUG - 2012-07-19 07:34:04 --> Controller Class Initialized
DEBUG - 2012-07-19 07:34:04 --> Model Class Initialized
DEBUG - 2012-07-19 07:34:04 --> Database Driver Class Initialized
DEBUG - 2012-07-19 07:34:04 --> Helper loaded: form_helper
DEBUG - 2012-07-19 07:34:04 --> Helper loaded: html_helper
DEBUG - 2012-07-19 07:34:04 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 07:34:04 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 07:34:04 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:34:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:34:04 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 07:34:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 07:34:04 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 07:34:04 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 07:34:04 --> Final output sent to browser
DEBUG - 2012-07-19 07:34:04 --> Total execution time: 0.0400
DEBUG - 2012-07-19 07:34:05 --> Config Class Initialized
DEBUG - 2012-07-19 07:34:05 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:34:05 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:34:05 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:34:05 --> URI Class Initialized
DEBUG - 2012-07-19 07:34:05 --> Router Class Initialized
ERROR - 2012-07-19 07:34:05 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 07:34:07 --> Config Class Initialized
DEBUG - 2012-07-19 07:34:07 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:34:07 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:34:07 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:34:07 --> URI Class Initialized
DEBUG - 2012-07-19 07:34:07 --> Router Class Initialized
ERROR - 2012-07-19 07:34:07 --> 404 Page Not Found --> css
DEBUG - 2012-07-19 07:41:46 --> Config Class Initialized
DEBUG - 2012-07-19 07:41:46 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:41:46 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:41:46 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:41:46 --> URI Class Initialized
DEBUG - 2012-07-19 07:41:46 --> Router Class Initialized
DEBUG - 2012-07-19 07:41:46 --> Output Class Initialized
DEBUG - 2012-07-19 07:41:46 --> Security Class Initialized
DEBUG - 2012-07-19 07:41:46 --> Input Class Initialized
DEBUG - 2012-07-19 07:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 07:41:46 --> Language Class Initialized
DEBUG - 2012-07-19 07:41:46 --> Loader Class Initialized
DEBUG - 2012-07-19 07:41:46 --> Helper loaded: url_helper
DEBUG - 2012-07-19 07:41:46 --> Controller Class Initialized
DEBUG - 2012-07-19 07:41:46 --> Model Class Initialized
DEBUG - 2012-07-19 07:41:46 --> Database Driver Class Initialized
DEBUG - 2012-07-19 07:41:46 --> Helper loaded: form_helper
DEBUG - 2012-07-19 07:41:46 --> Helper loaded: html_helper
DEBUG - 2012-07-19 07:41:46 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 07:41:46 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 07:41:46 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:41:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:41:46 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 07:41:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 07:41:46 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 07:41:46 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 07:41:46 --> Final output sent to browser
DEBUG - 2012-07-19 07:41:46 --> Total execution time: 0.0513
DEBUG - 2012-07-19 07:41:47 --> Config Class Initialized
DEBUG - 2012-07-19 07:41:47 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:41:47 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:41:47 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:41:47 --> URI Class Initialized
DEBUG - 2012-07-19 07:41:47 --> Router Class Initialized
ERROR - 2012-07-19 07:41:47 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 07:41:49 --> Config Class Initialized
DEBUG - 2012-07-19 07:41:49 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:41:49 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:41:49 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:41:49 --> URI Class Initialized
DEBUG - 2012-07-19 07:41:49 --> Router Class Initialized
ERROR - 2012-07-19 07:41:49 --> 404 Page Not Found --> css
DEBUG - 2012-07-19 07:43:42 --> Config Class Initialized
DEBUG - 2012-07-19 07:43:42 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:43:42 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:43:42 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:43:42 --> URI Class Initialized
DEBUG - 2012-07-19 07:43:42 --> Router Class Initialized
DEBUG - 2012-07-19 07:43:42 --> Output Class Initialized
DEBUG - 2012-07-19 07:43:42 --> Security Class Initialized
DEBUG - 2012-07-19 07:43:42 --> Input Class Initialized
DEBUG - 2012-07-19 07:43:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 07:43:42 --> Language Class Initialized
DEBUG - 2012-07-19 07:43:42 --> Loader Class Initialized
DEBUG - 2012-07-19 07:43:42 --> Helper loaded: url_helper
DEBUG - 2012-07-19 07:43:42 --> Controller Class Initialized
DEBUG - 2012-07-19 07:43:42 --> Model Class Initialized
DEBUG - 2012-07-19 07:43:42 --> Database Driver Class Initialized
DEBUG - 2012-07-19 07:43:42 --> Helper loaded: form_helper
DEBUG - 2012-07-19 07:43:42 --> Helper loaded: html_helper
DEBUG - 2012-07-19 07:43:42 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 07:43:42 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 07:43:42 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:43:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:43:42 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 07:43:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 07:43:42 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 07:43:42 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 07:43:42 --> Final output sent to browser
DEBUG - 2012-07-19 07:43:42 --> Total execution time: 0.0543
DEBUG - 2012-07-19 07:43:43 --> Config Class Initialized
DEBUG - 2012-07-19 07:43:43 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:43:43 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:43:43 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:43:43 --> URI Class Initialized
DEBUG - 2012-07-19 07:43:43 --> Router Class Initialized
ERROR - 2012-07-19 07:43:43 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 07:44:06 --> Config Class Initialized
DEBUG - 2012-07-19 07:44:06 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:44:06 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:44:06 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:44:06 --> URI Class Initialized
DEBUG - 2012-07-19 07:44:06 --> Router Class Initialized
DEBUG - 2012-07-19 07:44:06 --> Output Class Initialized
DEBUG - 2012-07-19 07:44:06 --> Security Class Initialized
DEBUG - 2012-07-19 07:44:06 --> Input Class Initialized
DEBUG - 2012-07-19 07:44:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 07:44:06 --> Language Class Initialized
DEBUG - 2012-07-19 07:44:06 --> Loader Class Initialized
DEBUG - 2012-07-19 07:44:06 --> Helper loaded: url_helper
DEBUG - 2012-07-19 07:44:06 --> Controller Class Initialized
DEBUG - 2012-07-19 07:44:06 --> Model Class Initialized
DEBUG - 2012-07-19 07:44:06 --> Database Driver Class Initialized
DEBUG - 2012-07-19 07:44:06 --> Helper loaded: form_helper
DEBUG - 2012-07-19 07:44:06 --> Helper loaded: html_helper
DEBUG - 2012-07-19 07:44:06 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 07:44:06 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 07:44:06 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:44:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:44:06 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 07:44:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 07:44:06 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 07:44:06 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 07:44:06 --> Final output sent to browser
DEBUG - 2012-07-19 07:44:06 --> Total execution time: 0.0441
DEBUG - 2012-07-19 07:44:07 --> Config Class Initialized
DEBUG - 2012-07-19 07:44:07 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:44:07 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:44:07 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:44:07 --> URI Class Initialized
DEBUG - 2012-07-19 07:44:07 --> Router Class Initialized
ERROR - 2012-07-19 07:44:07 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 07:44:46 --> Config Class Initialized
DEBUG - 2012-07-19 07:44:46 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:44:46 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:44:46 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:44:46 --> URI Class Initialized
DEBUG - 2012-07-19 07:44:46 --> Router Class Initialized
DEBUG - 2012-07-19 07:44:46 --> Output Class Initialized
DEBUG - 2012-07-19 07:44:46 --> Security Class Initialized
DEBUG - 2012-07-19 07:44:46 --> Input Class Initialized
DEBUG - 2012-07-19 07:44:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 07:44:46 --> Language Class Initialized
DEBUG - 2012-07-19 07:44:46 --> Loader Class Initialized
DEBUG - 2012-07-19 07:44:46 --> Helper loaded: url_helper
DEBUG - 2012-07-19 07:44:46 --> Controller Class Initialized
DEBUG - 2012-07-19 07:44:46 --> Model Class Initialized
DEBUG - 2012-07-19 07:44:46 --> Database Driver Class Initialized
DEBUG - 2012-07-19 07:44:46 --> Helper loaded: form_helper
DEBUG - 2012-07-19 07:44:46 --> Helper loaded: html_helper
DEBUG - 2012-07-19 07:44:46 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 07:44:46 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 07:44:46 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:44:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:44:46 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 07:44:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 07:44:46 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 07:44:46 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 07:44:46 --> Final output sent to browser
DEBUG - 2012-07-19 07:44:46 --> Total execution time: 0.0399
DEBUG - 2012-07-19 07:44:47 --> Config Class Initialized
DEBUG - 2012-07-19 07:44:47 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:44:47 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:44:47 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:44:47 --> URI Class Initialized
DEBUG - 2012-07-19 07:44:47 --> Router Class Initialized
ERROR - 2012-07-19 07:44:47 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 07:44:48 --> Config Class Initialized
DEBUG - 2012-07-19 07:44:48 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:44:48 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:44:48 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:44:48 --> URI Class Initialized
DEBUG - 2012-07-19 07:44:48 --> Router Class Initialized
DEBUG - 2012-07-19 07:44:48 --> Output Class Initialized
DEBUG - 2012-07-19 07:44:48 --> Security Class Initialized
DEBUG - 2012-07-19 07:44:48 --> Input Class Initialized
DEBUG - 2012-07-19 07:44:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 07:44:48 --> Language Class Initialized
DEBUG - 2012-07-19 07:44:48 --> Loader Class Initialized
DEBUG - 2012-07-19 07:44:48 --> Helper loaded: url_helper
DEBUG - 2012-07-19 07:44:48 --> Controller Class Initialized
DEBUG - 2012-07-19 07:44:48 --> Model Class Initialized
DEBUG - 2012-07-19 07:44:48 --> Database Driver Class Initialized
DEBUG - 2012-07-19 07:44:48 --> Helper loaded: form_helper
DEBUG - 2012-07-19 07:44:48 --> Helper loaded: html_helper
DEBUG - 2012-07-19 07:44:48 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 07:44:48 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 07:44:48 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:44:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:44:48 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 07:44:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 07:44:48 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 07:44:48 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 07:44:48 --> Final output sent to browser
DEBUG - 2012-07-19 07:44:48 --> Total execution time: 0.0406
DEBUG - 2012-07-19 07:44:48 --> Config Class Initialized
DEBUG - 2012-07-19 07:44:48 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:44:48 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:44:48 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:44:48 --> URI Class Initialized
DEBUG - 2012-07-19 07:44:48 --> Router Class Initialized
ERROR - 2012-07-19 07:44:48 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 07:45:39 --> Config Class Initialized
DEBUG - 2012-07-19 07:45:39 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:45:39 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:45:39 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:45:39 --> URI Class Initialized
DEBUG - 2012-07-19 07:45:39 --> Router Class Initialized
DEBUG - 2012-07-19 07:45:39 --> Output Class Initialized
DEBUG - 2012-07-19 07:45:39 --> Security Class Initialized
DEBUG - 2012-07-19 07:45:39 --> Input Class Initialized
DEBUG - 2012-07-19 07:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 07:45:39 --> Language Class Initialized
DEBUG - 2012-07-19 07:45:39 --> Loader Class Initialized
DEBUG - 2012-07-19 07:45:39 --> Helper loaded: url_helper
DEBUG - 2012-07-19 07:45:39 --> Controller Class Initialized
DEBUG - 2012-07-19 07:45:39 --> Model Class Initialized
DEBUG - 2012-07-19 07:45:39 --> Database Driver Class Initialized
DEBUG - 2012-07-19 07:45:39 --> Helper loaded: form_helper
DEBUG - 2012-07-19 07:45:39 --> Helper loaded: html_helper
DEBUG - 2012-07-19 07:45:39 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 07:45:39 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 07:45:39 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:45:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:45:39 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 07:45:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 07:45:39 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 07:45:39 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 07:45:39 --> Final output sent to browser
DEBUG - 2012-07-19 07:45:39 --> Total execution time: 0.0527
DEBUG - 2012-07-19 07:45:39 --> Config Class Initialized
DEBUG - 2012-07-19 07:45:39 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:45:39 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:45:39 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:45:39 --> URI Class Initialized
DEBUG - 2012-07-19 07:45:39 --> Router Class Initialized
ERROR - 2012-07-19 07:45:39 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 07:45:41 --> Config Class Initialized
DEBUG - 2012-07-19 07:45:41 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:45:41 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:45:41 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:45:41 --> URI Class Initialized
DEBUG - 2012-07-19 07:45:41 --> Router Class Initialized
DEBUG - 2012-07-19 07:45:41 --> Output Class Initialized
DEBUG - 2012-07-19 07:45:41 --> Security Class Initialized
DEBUG - 2012-07-19 07:45:41 --> Input Class Initialized
DEBUG - 2012-07-19 07:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 07:45:41 --> Language Class Initialized
DEBUG - 2012-07-19 07:45:41 --> Loader Class Initialized
DEBUG - 2012-07-19 07:45:41 --> Helper loaded: url_helper
DEBUG - 2012-07-19 07:45:41 --> Controller Class Initialized
DEBUG - 2012-07-19 07:45:41 --> Model Class Initialized
DEBUG - 2012-07-19 07:45:41 --> Database Driver Class Initialized
DEBUG - 2012-07-19 07:45:41 --> Helper loaded: form_helper
DEBUG - 2012-07-19 07:45:41 --> Helper loaded: html_helper
DEBUG - 2012-07-19 07:45:41 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 07:45:41 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 07:45:41 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:45:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:45:41 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 07:45:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 07:45:41 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 07:45:41 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 07:45:41 --> Final output sent to browser
DEBUG - 2012-07-19 07:45:41 --> Total execution time: 0.0400
DEBUG - 2012-07-19 07:45:42 --> Config Class Initialized
DEBUG - 2012-07-19 07:45:42 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:45:42 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:45:42 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:45:42 --> URI Class Initialized
DEBUG - 2012-07-19 07:45:42 --> Router Class Initialized
ERROR - 2012-07-19 07:45:42 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 07:46:35 --> Config Class Initialized
DEBUG - 2012-07-19 07:46:35 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:46:35 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:46:35 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:46:35 --> URI Class Initialized
DEBUG - 2012-07-19 07:46:35 --> Router Class Initialized
DEBUG - 2012-07-19 07:46:35 --> Output Class Initialized
DEBUG - 2012-07-19 07:46:35 --> Security Class Initialized
DEBUG - 2012-07-19 07:46:35 --> Input Class Initialized
DEBUG - 2012-07-19 07:46:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 07:46:35 --> Language Class Initialized
DEBUG - 2012-07-19 07:46:35 --> Loader Class Initialized
DEBUG - 2012-07-19 07:46:35 --> Helper loaded: url_helper
DEBUG - 2012-07-19 07:46:35 --> Controller Class Initialized
DEBUG - 2012-07-19 07:46:35 --> Model Class Initialized
DEBUG - 2012-07-19 07:46:35 --> Database Driver Class Initialized
DEBUG - 2012-07-19 07:46:35 --> Helper loaded: form_helper
DEBUG - 2012-07-19 07:46:35 --> Helper loaded: html_helper
DEBUG - 2012-07-19 07:46:35 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 07:46:35 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 07:46:35 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:46:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 07:46:35 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 07:46:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 07:46:35 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 07:46:35 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 07:46:35 --> Final output sent to browser
DEBUG - 2012-07-19 07:46:35 --> Total execution time: 0.0403
DEBUG - 2012-07-19 07:46:35 --> Config Class Initialized
DEBUG - 2012-07-19 07:46:35 --> Hooks Class Initialized
DEBUG - 2012-07-19 07:46:35 --> Utf8 Class Initialized
DEBUG - 2012-07-19 07:46:35 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 07:46:35 --> URI Class Initialized
DEBUG - 2012-07-19 07:46:35 --> Router Class Initialized
ERROR - 2012-07-19 07:46:35 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 08:55:25 --> Config Class Initialized
DEBUG - 2012-07-19 08:55:25 --> Hooks Class Initialized
DEBUG - 2012-07-19 08:55:25 --> Utf8 Class Initialized
DEBUG - 2012-07-19 08:55:25 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 08:55:25 --> URI Class Initialized
DEBUG - 2012-07-19 08:55:25 --> Router Class Initialized
DEBUG - 2012-07-19 08:55:25 --> Output Class Initialized
DEBUG - 2012-07-19 08:55:25 --> Security Class Initialized
DEBUG - 2012-07-19 08:55:25 --> Input Class Initialized
DEBUG - 2012-07-19 08:55:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 08:55:25 --> Language Class Initialized
DEBUG - 2012-07-19 08:55:25 --> Loader Class Initialized
DEBUG - 2012-07-19 08:55:25 --> Helper loaded: url_helper
DEBUG - 2012-07-19 08:55:25 --> Controller Class Initialized
DEBUG - 2012-07-19 08:55:25 --> Model Class Initialized
DEBUG - 2012-07-19 08:55:25 --> Database Driver Class Initialized
DEBUG - 2012-07-19 08:55:25 --> Helper loaded: form_helper
DEBUG - 2012-07-19 08:55:25 --> Helper loaded: html_helper
DEBUG - 2012-07-19 08:55:25 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 08:55:25 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 08:55:25 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 08:55:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 08:55:25 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 08:55:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 08:55:25 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 08:55:25 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 08:55:25 --> Final output sent to browser
DEBUG - 2012-07-19 08:55:25 --> Total execution time: 0.3297
DEBUG - 2012-07-19 08:55:25 --> Config Class Initialized
DEBUG - 2012-07-19 08:55:25 --> Hooks Class Initialized
DEBUG - 2012-07-19 08:55:25 --> Utf8 Class Initialized
DEBUG - 2012-07-19 08:55:25 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 08:55:25 --> URI Class Initialized
DEBUG - 2012-07-19 08:55:25 --> Router Class Initialized
ERROR - 2012-07-19 08:55:25 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 08:56:37 --> Config Class Initialized
DEBUG - 2012-07-19 08:56:37 --> Hooks Class Initialized
DEBUG - 2012-07-19 08:56:37 --> Utf8 Class Initialized
DEBUG - 2012-07-19 08:56:37 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 08:56:37 --> URI Class Initialized
DEBUG - 2012-07-19 08:56:37 --> Router Class Initialized
DEBUG - 2012-07-19 08:56:37 --> Output Class Initialized
DEBUG - 2012-07-19 08:56:37 --> Security Class Initialized
DEBUG - 2012-07-19 08:56:37 --> Input Class Initialized
DEBUG - 2012-07-19 08:56:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 08:56:37 --> Language Class Initialized
DEBUG - 2012-07-19 08:56:37 --> Loader Class Initialized
DEBUG - 2012-07-19 08:56:37 --> Helper loaded: url_helper
DEBUG - 2012-07-19 08:56:37 --> Controller Class Initialized
DEBUG - 2012-07-19 08:56:37 --> Model Class Initialized
DEBUG - 2012-07-19 08:56:37 --> Database Driver Class Initialized
DEBUG - 2012-07-19 08:56:37 --> Helper loaded: form_helper
DEBUG - 2012-07-19 08:56:37 --> Helper loaded: html_helper
DEBUG - 2012-07-19 08:56:37 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 08:56:37 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 08:56:37 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 08:56:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 08:56:37 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 08:56:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 08:56:37 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 08:56:37 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 08:56:37 --> Final output sent to browser
DEBUG - 2012-07-19 08:56:37 --> Total execution time: 0.0415
DEBUG - 2012-07-19 08:56:37 --> Config Class Initialized
DEBUG - 2012-07-19 08:56:37 --> Hooks Class Initialized
DEBUG - 2012-07-19 08:56:37 --> Utf8 Class Initialized
DEBUG - 2012-07-19 08:56:37 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 08:56:37 --> URI Class Initialized
DEBUG - 2012-07-19 08:56:37 --> Router Class Initialized
ERROR - 2012-07-19 08:56:37 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 08:56:55 --> Config Class Initialized
DEBUG - 2012-07-19 08:56:55 --> Hooks Class Initialized
DEBUG - 2012-07-19 08:56:55 --> Utf8 Class Initialized
DEBUG - 2012-07-19 08:56:55 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 08:56:55 --> URI Class Initialized
DEBUG - 2012-07-19 08:56:55 --> Router Class Initialized
DEBUG - 2012-07-19 08:56:55 --> Output Class Initialized
DEBUG - 2012-07-19 08:56:55 --> Security Class Initialized
DEBUG - 2012-07-19 08:56:55 --> Input Class Initialized
DEBUG - 2012-07-19 08:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 08:56:55 --> Language Class Initialized
DEBUG - 2012-07-19 08:56:55 --> Loader Class Initialized
DEBUG - 2012-07-19 08:56:55 --> Helper loaded: url_helper
DEBUG - 2012-07-19 08:56:55 --> Controller Class Initialized
DEBUG - 2012-07-19 08:56:55 --> Model Class Initialized
DEBUG - 2012-07-19 08:56:55 --> Database Driver Class Initialized
DEBUG - 2012-07-19 08:56:55 --> Helper loaded: form_helper
DEBUG - 2012-07-19 08:56:55 --> Helper loaded: html_helper
DEBUG - 2012-07-19 08:56:55 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 08:56:55 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 08:56:55 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 08:56:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 08:56:55 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 08:56:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 08:56:55 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 08:56:55 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 08:56:55 --> Final output sent to browser
DEBUG - 2012-07-19 08:56:55 --> Total execution time: 0.0397
DEBUG - 2012-07-19 08:56:55 --> Config Class Initialized
DEBUG - 2012-07-19 08:56:55 --> Hooks Class Initialized
DEBUG - 2012-07-19 08:56:55 --> Utf8 Class Initialized
DEBUG - 2012-07-19 08:56:55 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 08:56:55 --> URI Class Initialized
DEBUG - 2012-07-19 08:56:55 --> Router Class Initialized
ERROR - 2012-07-19 08:56:55 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 08:58:35 --> Config Class Initialized
DEBUG - 2012-07-19 08:58:35 --> Hooks Class Initialized
DEBUG - 2012-07-19 08:58:35 --> Utf8 Class Initialized
DEBUG - 2012-07-19 08:58:35 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 08:58:35 --> URI Class Initialized
DEBUG - 2012-07-19 08:58:35 --> Router Class Initialized
DEBUG - 2012-07-19 08:58:35 --> Output Class Initialized
DEBUG - 2012-07-19 08:58:35 --> Security Class Initialized
DEBUG - 2012-07-19 08:58:35 --> Input Class Initialized
DEBUG - 2012-07-19 08:58:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 08:58:35 --> Language Class Initialized
DEBUG - 2012-07-19 08:58:35 --> Loader Class Initialized
DEBUG - 2012-07-19 08:58:35 --> Helper loaded: url_helper
DEBUG - 2012-07-19 08:58:35 --> Controller Class Initialized
DEBUG - 2012-07-19 08:58:35 --> Model Class Initialized
DEBUG - 2012-07-19 08:58:35 --> Database Driver Class Initialized
DEBUG - 2012-07-19 08:58:35 --> Helper loaded: form_helper
DEBUG - 2012-07-19 08:58:35 --> Helper loaded: html_helper
DEBUG - 2012-07-19 08:58:35 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 08:58:35 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 08:58:35 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 08:58:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 08:58:35 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 08:58:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 08:58:35 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 08:58:35 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 08:58:35 --> Final output sent to browser
DEBUG - 2012-07-19 08:58:35 --> Total execution time: 0.0768
DEBUG - 2012-07-19 08:58:35 --> Config Class Initialized
DEBUG - 2012-07-19 08:58:35 --> Hooks Class Initialized
DEBUG - 2012-07-19 08:58:35 --> Utf8 Class Initialized
DEBUG - 2012-07-19 08:58:35 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 08:58:35 --> URI Class Initialized
DEBUG - 2012-07-19 08:58:35 --> Router Class Initialized
ERROR - 2012-07-19 08:58:35 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 08:59:14 --> Config Class Initialized
DEBUG - 2012-07-19 08:59:14 --> Hooks Class Initialized
DEBUG - 2012-07-19 08:59:14 --> Utf8 Class Initialized
DEBUG - 2012-07-19 08:59:14 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 08:59:14 --> URI Class Initialized
DEBUG - 2012-07-19 08:59:14 --> Router Class Initialized
DEBUG - 2012-07-19 08:59:14 --> Output Class Initialized
DEBUG - 2012-07-19 08:59:14 --> Security Class Initialized
DEBUG - 2012-07-19 08:59:14 --> Input Class Initialized
DEBUG - 2012-07-19 08:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 08:59:14 --> Language Class Initialized
DEBUG - 2012-07-19 08:59:14 --> Loader Class Initialized
DEBUG - 2012-07-19 08:59:14 --> Helper loaded: url_helper
DEBUG - 2012-07-19 08:59:14 --> Controller Class Initialized
DEBUG - 2012-07-19 08:59:14 --> Model Class Initialized
DEBUG - 2012-07-19 08:59:14 --> Database Driver Class Initialized
DEBUG - 2012-07-19 08:59:14 --> Helper loaded: form_helper
DEBUG - 2012-07-19 08:59:14 --> Helper loaded: html_helper
DEBUG - 2012-07-19 08:59:14 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 08:59:14 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 08:59:14 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 08:59:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 08:59:14 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 08:59:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 08:59:14 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 08:59:14 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 08:59:14 --> Final output sent to browser
DEBUG - 2012-07-19 08:59:14 --> Total execution time: 0.0400
DEBUG - 2012-07-19 08:59:37 --> Config Class Initialized
DEBUG - 2012-07-19 08:59:37 --> Hooks Class Initialized
DEBUG - 2012-07-19 08:59:37 --> Utf8 Class Initialized
DEBUG - 2012-07-19 08:59:37 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 08:59:37 --> URI Class Initialized
DEBUG - 2012-07-19 08:59:37 --> Router Class Initialized
DEBUG - 2012-07-19 08:59:37 --> Output Class Initialized
DEBUG - 2012-07-19 08:59:37 --> Security Class Initialized
DEBUG - 2012-07-19 08:59:37 --> Input Class Initialized
DEBUG - 2012-07-19 08:59:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 08:59:37 --> Language Class Initialized
DEBUG - 2012-07-19 08:59:37 --> Loader Class Initialized
DEBUG - 2012-07-19 08:59:37 --> Helper loaded: url_helper
DEBUG - 2012-07-19 08:59:37 --> Controller Class Initialized
DEBUG - 2012-07-19 08:59:37 --> Model Class Initialized
DEBUG - 2012-07-19 08:59:37 --> Database Driver Class Initialized
DEBUG - 2012-07-19 08:59:37 --> Helper loaded: form_helper
DEBUG - 2012-07-19 08:59:37 --> Helper loaded: html_helper
DEBUG - 2012-07-19 08:59:37 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 08:59:37 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 08:59:37 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 08:59:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 08:59:37 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 08:59:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 08:59:37 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 08:59:37 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 08:59:37 --> Final output sent to browser
DEBUG - 2012-07-19 08:59:37 --> Total execution time: 0.0397
DEBUG - 2012-07-19 08:59:37 --> Config Class Initialized
DEBUG - 2012-07-19 08:59:37 --> Hooks Class Initialized
DEBUG - 2012-07-19 08:59:37 --> Utf8 Class Initialized
DEBUG - 2012-07-19 08:59:37 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 08:59:37 --> URI Class Initialized
DEBUG - 2012-07-19 08:59:37 --> Router Class Initialized
ERROR - 2012-07-19 08:59:37 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 09:00:27 --> Config Class Initialized
DEBUG - 2012-07-19 09:00:27 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:00:27 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:00:27 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:00:27 --> URI Class Initialized
DEBUG - 2012-07-19 09:00:27 --> Router Class Initialized
DEBUG - 2012-07-19 09:00:27 --> Output Class Initialized
DEBUG - 2012-07-19 09:00:27 --> Security Class Initialized
DEBUG - 2012-07-19 09:00:27 --> Input Class Initialized
DEBUG - 2012-07-19 09:00:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 09:00:27 --> Language Class Initialized
DEBUG - 2012-07-19 09:00:27 --> Loader Class Initialized
DEBUG - 2012-07-19 09:00:27 --> Helper loaded: url_helper
DEBUG - 2012-07-19 09:00:27 --> Controller Class Initialized
DEBUG - 2012-07-19 09:00:27 --> Model Class Initialized
DEBUG - 2012-07-19 09:00:27 --> Database Driver Class Initialized
DEBUG - 2012-07-19 09:00:27 --> Helper loaded: form_helper
DEBUG - 2012-07-19 09:00:27 --> Helper loaded: html_helper
DEBUG - 2012-07-19 09:00:27 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 09:00:27 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 09:00:27 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:00:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:00:27 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 09:00:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 09:00:27 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 09:00:27 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 09:00:27 --> Final output sent to browser
DEBUG - 2012-07-19 09:00:27 --> Total execution time: 0.0448
DEBUG - 2012-07-19 09:00:28 --> Config Class Initialized
DEBUG - 2012-07-19 09:00:28 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:00:28 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:00:28 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:00:28 --> URI Class Initialized
DEBUG - 2012-07-19 09:00:28 --> Router Class Initialized
ERROR - 2012-07-19 09:00:28 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 09:02:31 --> Config Class Initialized
DEBUG - 2012-07-19 09:02:31 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:02:31 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:02:31 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:02:31 --> URI Class Initialized
DEBUG - 2012-07-19 09:02:31 --> Router Class Initialized
DEBUG - 2012-07-19 09:02:31 --> Output Class Initialized
DEBUG - 2012-07-19 09:02:31 --> Security Class Initialized
DEBUG - 2012-07-19 09:02:31 --> Input Class Initialized
DEBUG - 2012-07-19 09:02:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 09:02:31 --> Language Class Initialized
DEBUG - 2012-07-19 09:02:31 --> Loader Class Initialized
DEBUG - 2012-07-19 09:02:31 --> Helper loaded: url_helper
DEBUG - 2012-07-19 09:02:31 --> Controller Class Initialized
DEBUG - 2012-07-19 09:02:31 --> Model Class Initialized
DEBUG - 2012-07-19 09:02:31 --> Database Driver Class Initialized
DEBUG - 2012-07-19 09:02:31 --> Helper loaded: form_helper
DEBUG - 2012-07-19 09:02:31 --> Helper loaded: html_helper
DEBUG - 2012-07-19 09:02:31 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 09:02:31 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 09:02:31 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:02:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:02:31 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 09:02:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 09:02:31 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 09:02:31 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 09:02:31 --> Final output sent to browser
DEBUG - 2012-07-19 09:02:31 --> Total execution time: 0.0411
DEBUG - 2012-07-19 09:02:32 --> Config Class Initialized
DEBUG - 2012-07-19 09:02:32 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:02:32 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:02:32 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:02:32 --> URI Class Initialized
DEBUG - 2012-07-19 09:02:32 --> Router Class Initialized
ERROR - 2012-07-19 09:02:32 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 09:03:31 --> Config Class Initialized
DEBUG - 2012-07-19 09:03:31 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:03:31 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:03:31 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:03:31 --> URI Class Initialized
DEBUG - 2012-07-19 09:03:31 --> Router Class Initialized
DEBUG - 2012-07-19 09:03:31 --> Output Class Initialized
DEBUG - 2012-07-19 09:03:31 --> Security Class Initialized
DEBUG - 2012-07-19 09:03:31 --> Input Class Initialized
DEBUG - 2012-07-19 09:03:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 09:03:31 --> Language Class Initialized
DEBUG - 2012-07-19 09:03:31 --> Loader Class Initialized
DEBUG - 2012-07-19 09:03:31 --> Helper loaded: url_helper
DEBUG - 2012-07-19 09:03:31 --> Controller Class Initialized
DEBUG - 2012-07-19 09:03:31 --> Model Class Initialized
DEBUG - 2012-07-19 09:03:31 --> Database Driver Class Initialized
DEBUG - 2012-07-19 09:03:31 --> Helper loaded: form_helper
DEBUG - 2012-07-19 09:03:31 --> Helper loaded: html_helper
DEBUG - 2012-07-19 09:03:31 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 09:03:31 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 09:03:31 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:03:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:03:31 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 09:03:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 09:03:31 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 09:03:31 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 09:03:31 --> Final output sent to browser
DEBUG - 2012-07-19 09:03:31 --> Total execution time: 0.0425
DEBUG - 2012-07-19 09:03:31 --> Config Class Initialized
DEBUG - 2012-07-19 09:03:31 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:03:31 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:03:31 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:03:31 --> URI Class Initialized
DEBUG - 2012-07-19 09:03:31 --> Router Class Initialized
ERROR - 2012-07-19 09:03:31 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 09:03:48 --> Config Class Initialized
DEBUG - 2012-07-19 09:03:48 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:03:48 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:03:48 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:03:48 --> URI Class Initialized
DEBUG - 2012-07-19 09:03:48 --> Router Class Initialized
DEBUG - 2012-07-19 09:03:48 --> Output Class Initialized
DEBUG - 2012-07-19 09:03:48 --> Security Class Initialized
DEBUG - 2012-07-19 09:03:48 --> Input Class Initialized
DEBUG - 2012-07-19 09:03:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 09:03:48 --> Language Class Initialized
DEBUG - 2012-07-19 09:03:48 --> Loader Class Initialized
DEBUG - 2012-07-19 09:03:48 --> Helper loaded: url_helper
DEBUG - 2012-07-19 09:03:48 --> Controller Class Initialized
DEBUG - 2012-07-19 09:03:48 --> Model Class Initialized
DEBUG - 2012-07-19 09:03:48 --> Database Driver Class Initialized
DEBUG - 2012-07-19 09:03:48 --> Helper loaded: form_helper
DEBUG - 2012-07-19 09:03:48 --> Helper loaded: html_helper
DEBUG - 2012-07-19 09:03:48 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 09:03:48 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 09:03:48 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:03:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:03:48 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 09:03:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 09:03:48 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 09:03:48 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 09:03:48 --> Final output sent to browser
DEBUG - 2012-07-19 09:03:48 --> Total execution time: 0.0398
DEBUG - 2012-07-19 09:03:49 --> Config Class Initialized
DEBUG - 2012-07-19 09:03:49 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:03:49 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:03:49 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:03:49 --> URI Class Initialized
DEBUG - 2012-07-19 09:03:49 --> Router Class Initialized
ERROR - 2012-07-19 09:03:49 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 09:04:05 --> Config Class Initialized
DEBUG - 2012-07-19 09:04:05 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:04:05 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:04:05 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:04:05 --> URI Class Initialized
DEBUG - 2012-07-19 09:04:05 --> Router Class Initialized
DEBUG - 2012-07-19 09:04:05 --> Output Class Initialized
DEBUG - 2012-07-19 09:04:05 --> Security Class Initialized
DEBUG - 2012-07-19 09:04:05 --> Input Class Initialized
DEBUG - 2012-07-19 09:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 09:04:05 --> Language Class Initialized
DEBUG - 2012-07-19 09:04:05 --> Loader Class Initialized
DEBUG - 2012-07-19 09:04:05 --> Helper loaded: url_helper
DEBUG - 2012-07-19 09:04:05 --> Controller Class Initialized
DEBUG - 2012-07-19 09:04:05 --> Model Class Initialized
DEBUG - 2012-07-19 09:04:05 --> Database Driver Class Initialized
DEBUG - 2012-07-19 09:04:05 --> Helper loaded: form_helper
DEBUG - 2012-07-19 09:04:05 --> Helper loaded: html_helper
DEBUG - 2012-07-19 09:04:05 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 09:04:05 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 09:04:05 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:04:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:04:05 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 09:04:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 09:04:05 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 09:04:05 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 09:04:05 --> Final output sent to browser
DEBUG - 2012-07-19 09:04:05 --> Total execution time: 0.0407
DEBUG - 2012-07-19 09:04:06 --> Config Class Initialized
DEBUG - 2012-07-19 09:04:06 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:04:06 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:04:06 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:04:06 --> URI Class Initialized
DEBUG - 2012-07-19 09:04:06 --> Router Class Initialized
ERROR - 2012-07-19 09:04:06 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 09:05:04 --> Config Class Initialized
DEBUG - 2012-07-19 09:05:04 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:05:04 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:05:04 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:05:04 --> URI Class Initialized
DEBUG - 2012-07-19 09:05:04 --> Router Class Initialized
DEBUG - 2012-07-19 09:05:04 --> Output Class Initialized
DEBUG - 2012-07-19 09:05:04 --> Security Class Initialized
DEBUG - 2012-07-19 09:05:04 --> Input Class Initialized
DEBUG - 2012-07-19 09:05:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 09:05:04 --> Language Class Initialized
DEBUG - 2012-07-19 09:05:04 --> Loader Class Initialized
DEBUG - 2012-07-19 09:05:04 --> Helper loaded: url_helper
DEBUG - 2012-07-19 09:05:04 --> Controller Class Initialized
DEBUG - 2012-07-19 09:05:04 --> Model Class Initialized
DEBUG - 2012-07-19 09:05:04 --> Database Driver Class Initialized
DEBUG - 2012-07-19 09:05:04 --> Helper loaded: form_helper
DEBUG - 2012-07-19 09:05:04 --> Helper loaded: html_helper
DEBUG - 2012-07-19 09:05:04 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 09:05:04 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 09:05:04 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:05:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:05:04 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 09:05:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 09:05:04 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 09:05:04 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 09:05:04 --> Final output sent to browser
DEBUG - 2012-07-19 09:05:04 --> Total execution time: 0.0905
DEBUG - 2012-07-19 09:05:05 --> Config Class Initialized
DEBUG - 2012-07-19 09:05:05 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:05:05 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:05:05 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:05:05 --> URI Class Initialized
DEBUG - 2012-07-19 09:05:05 --> Router Class Initialized
ERROR - 2012-07-19 09:05:05 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 09:05:36 --> Config Class Initialized
DEBUG - 2012-07-19 09:05:36 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:05:36 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:05:36 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:05:36 --> URI Class Initialized
DEBUG - 2012-07-19 09:05:36 --> Router Class Initialized
DEBUG - 2012-07-19 09:05:36 --> Output Class Initialized
DEBUG - 2012-07-19 09:05:36 --> Security Class Initialized
DEBUG - 2012-07-19 09:05:36 --> Input Class Initialized
DEBUG - 2012-07-19 09:05:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 09:05:36 --> Language Class Initialized
DEBUG - 2012-07-19 09:05:36 --> Loader Class Initialized
DEBUG - 2012-07-19 09:05:36 --> Helper loaded: url_helper
DEBUG - 2012-07-19 09:05:36 --> Controller Class Initialized
DEBUG - 2012-07-19 09:05:36 --> Model Class Initialized
DEBUG - 2012-07-19 09:05:36 --> Database Driver Class Initialized
DEBUG - 2012-07-19 09:05:36 --> Helper loaded: form_helper
DEBUG - 2012-07-19 09:05:36 --> Helper loaded: html_helper
DEBUG - 2012-07-19 09:05:36 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 09:05:36 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 09:05:36 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:05:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:05:36 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 09:05:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 09:05:36 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 09:05:36 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 09:05:36 --> Final output sent to browser
DEBUG - 2012-07-19 09:05:36 --> Total execution time: 0.0411
DEBUG - 2012-07-19 09:05:36 --> Config Class Initialized
DEBUG - 2012-07-19 09:05:36 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:05:36 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:05:36 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:05:36 --> URI Class Initialized
DEBUG - 2012-07-19 09:05:36 --> Router Class Initialized
ERROR - 2012-07-19 09:05:36 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 09:09:08 --> Config Class Initialized
DEBUG - 2012-07-19 09:09:08 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:09:08 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:09:08 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:09:08 --> URI Class Initialized
DEBUG - 2012-07-19 09:09:08 --> Router Class Initialized
DEBUG - 2012-07-19 09:09:08 --> Output Class Initialized
DEBUG - 2012-07-19 09:09:08 --> Security Class Initialized
DEBUG - 2012-07-19 09:09:08 --> Input Class Initialized
DEBUG - 2012-07-19 09:09:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 09:09:08 --> Language Class Initialized
DEBUG - 2012-07-19 09:09:08 --> Loader Class Initialized
DEBUG - 2012-07-19 09:09:08 --> Helper loaded: url_helper
DEBUG - 2012-07-19 09:09:08 --> Controller Class Initialized
DEBUG - 2012-07-19 09:09:08 --> Model Class Initialized
DEBUG - 2012-07-19 09:09:08 --> Database Driver Class Initialized
DEBUG - 2012-07-19 09:09:08 --> Helper loaded: form_helper
DEBUG - 2012-07-19 09:09:08 --> Helper loaded: html_helper
DEBUG - 2012-07-19 09:09:08 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 09:09:08 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 09:09:08 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:09:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:09:08 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 09:09:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 09:09:08 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 09:09:08 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 09:09:08 --> Final output sent to browser
DEBUG - 2012-07-19 09:09:08 --> Total execution time: 0.0914
DEBUG - 2012-07-19 09:09:09 --> Config Class Initialized
DEBUG - 2012-07-19 09:09:09 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:09:09 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:09:09 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:09:09 --> URI Class Initialized
DEBUG - 2012-07-19 09:09:09 --> Router Class Initialized
ERROR - 2012-07-19 09:09:09 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 09:11:26 --> Config Class Initialized
DEBUG - 2012-07-19 09:11:26 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:11:26 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:11:26 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:11:26 --> URI Class Initialized
DEBUG - 2012-07-19 09:11:26 --> Router Class Initialized
DEBUG - 2012-07-19 09:11:26 --> Output Class Initialized
DEBUG - 2012-07-19 09:11:26 --> Security Class Initialized
DEBUG - 2012-07-19 09:11:26 --> Input Class Initialized
DEBUG - 2012-07-19 09:11:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 09:11:26 --> Language Class Initialized
DEBUG - 2012-07-19 09:11:26 --> Loader Class Initialized
DEBUG - 2012-07-19 09:11:26 --> Helper loaded: url_helper
DEBUG - 2012-07-19 09:11:26 --> Controller Class Initialized
DEBUG - 2012-07-19 09:11:26 --> Model Class Initialized
DEBUG - 2012-07-19 09:11:26 --> Database Driver Class Initialized
DEBUG - 2012-07-19 09:11:26 --> Helper loaded: form_helper
DEBUG - 2012-07-19 09:11:26 --> Helper loaded: html_helper
DEBUG - 2012-07-19 09:11:26 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 09:11:26 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 09:11:26 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:11:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:11:26 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 09:11:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 09:11:26 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 09:11:26 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 09:11:26 --> Final output sent to browser
DEBUG - 2012-07-19 09:11:26 --> Total execution time: 0.0401
DEBUG - 2012-07-19 09:11:27 --> Config Class Initialized
DEBUG - 2012-07-19 09:11:27 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:11:27 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:11:27 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:11:27 --> URI Class Initialized
DEBUG - 2012-07-19 09:11:27 --> Router Class Initialized
ERROR - 2012-07-19 09:11:27 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 09:11:49 --> Config Class Initialized
DEBUG - 2012-07-19 09:11:49 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:11:49 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:11:49 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:11:49 --> URI Class Initialized
DEBUG - 2012-07-19 09:11:49 --> Router Class Initialized
DEBUG - 2012-07-19 09:11:49 --> Output Class Initialized
DEBUG - 2012-07-19 09:11:49 --> Security Class Initialized
DEBUG - 2012-07-19 09:11:49 --> Input Class Initialized
DEBUG - 2012-07-19 09:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 09:11:49 --> Language Class Initialized
DEBUG - 2012-07-19 09:11:49 --> Loader Class Initialized
DEBUG - 2012-07-19 09:11:49 --> Helper loaded: url_helper
DEBUG - 2012-07-19 09:11:49 --> Controller Class Initialized
DEBUG - 2012-07-19 09:11:49 --> Model Class Initialized
DEBUG - 2012-07-19 09:11:49 --> Database Driver Class Initialized
DEBUG - 2012-07-19 09:11:49 --> Helper loaded: form_helper
DEBUG - 2012-07-19 09:11:49 --> Helper loaded: html_helper
DEBUG - 2012-07-19 09:11:49 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 09:11:49 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 09:11:49 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:11:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:11:49 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 09:11:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 09:11:49 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 09:11:49 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 09:11:49 --> Final output sent to browser
DEBUG - 2012-07-19 09:11:49 --> Total execution time: 0.0397
DEBUG - 2012-07-19 09:11:49 --> Config Class Initialized
DEBUG - 2012-07-19 09:11:49 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:11:49 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:11:49 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:11:49 --> URI Class Initialized
DEBUG - 2012-07-19 09:11:49 --> Router Class Initialized
ERROR - 2012-07-19 09:11:49 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 09:14:23 --> Config Class Initialized
DEBUG - 2012-07-19 09:14:23 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:14:23 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:14:23 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:14:23 --> URI Class Initialized
DEBUG - 2012-07-19 09:14:23 --> Router Class Initialized
DEBUG - 2012-07-19 09:14:23 --> Output Class Initialized
DEBUG - 2012-07-19 09:14:23 --> Security Class Initialized
DEBUG - 2012-07-19 09:14:23 --> Input Class Initialized
DEBUG - 2012-07-19 09:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 09:14:23 --> Language Class Initialized
DEBUG - 2012-07-19 09:14:23 --> Loader Class Initialized
DEBUG - 2012-07-19 09:14:23 --> Helper loaded: url_helper
DEBUG - 2012-07-19 09:14:23 --> Controller Class Initialized
DEBUG - 2012-07-19 09:14:23 --> Model Class Initialized
DEBUG - 2012-07-19 09:14:23 --> Database Driver Class Initialized
DEBUG - 2012-07-19 09:14:23 --> Helper loaded: form_helper
DEBUG - 2012-07-19 09:14:23 --> Helper loaded: html_helper
DEBUG - 2012-07-19 09:14:23 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 09:14:23 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 09:14:23 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:14:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:14:23 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 09:14:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 09:14:23 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 09:14:23 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 09:14:23 --> Final output sent to browser
DEBUG - 2012-07-19 09:14:23 --> Total execution time: 0.3557
DEBUG - 2012-07-19 09:14:24 --> Config Class Initialized
DEBUG - 2012-07-19 09:14:24 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:14:24 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:14:24 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:14:24 --> URI Class Initialized
DEBUG - 2012-07-19 09:14:24 --> Router Class Initialized
ERROR - 2012-07-19 09:14:24 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 09:20:38 --> Config Class Initialized
DEBUG - 2012-07-19 09:20:38 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:20:38 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:20:38 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:20:38 --> URI Class Initialized
DEBUG - 2012-07-19 09:20:38 --> Router Class Initialized
DEBUG - 2012-07-19 09:20:38 --> Output Class Initialized
DEBUG - 2012-07-19 09:20:38 --> Security Class Initialized
DEBUG - 2012-07-19 09:20:38 --> Input Class Initialized
DEBUG - 2012-07-19 09:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 09:20:38 --> Language Class Initialized
DEBUG - 2012-07-19 09:20:38 --> Loader Class Initialized
DEBUG - 2012-07-19 09:20:38 --> Helper loaded: url_helper
DEBUG - 2012-07-19 09:20:38 --> Controller Class Initialized
DEBUG - 2012-07-19 09:20:38 --> Model Class Initialized
DEBUG - 2012-07-19 09:20:38 --> Database Driver Class Initialized
DEBUG - 2012-07-19 09:20:38 --> Helper loaded: form_helper
DEBUG - 2012-07-19 09:20:38 --> Helper loaded: html_helper
DEBUG - 2012-07-19 09:20:38 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 09:20:38 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 09:20:39 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:20:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:20:39 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 09:20:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 09:20:39 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 09:20:39 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 09:20:39 --> Final output sent to browser
DEBUG - 2012-07-19 09:20:39 --> Total execution time: 0.3417
DEBUG - 2012-07-19 09:20:39 --> Config Class Initialized
DEBUG - 2012-07-19 09:20:39 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:20:39 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:20:39 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:20:39 --> URI Class Initialized
DEBUG - 2012-07-19 09:20:39 --> Router Class Initialized
ERROR - 2012-07-19 09:20:39 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 09:22:26 --> Config Class Initialized
DEBUG - 2012-07-19 09:22:26 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:22:26 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:22:26 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:22:26 --> URI Class Initialized
DEBUG - 2012-07-19 09:22:26 --> Router Class Initialized
DEBUG - 2012-07-19 09:22:26 --> Output Class Initialized
DEBUG - 2012-07-19 09:22:26 --> Security Class Initialized
DEBUG - 2012-07-19 09:22:26 --> Input Class Initialized
DEBUG - 2012-07-19 09:22:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 09:22:26 --> Language Class Initialized
DEBUG - 2012-07-19 09:22:26 --> Loader Class Initialized
DEBUG - 2012-07-19 09:22:26 --> Helper loaded: url_helper
DEBUG - 2012-07-19 09:22:26 --> Controller Class Initialized
DEBUG - 2012-07-19 09:22:26 --> Model Class Initialized
DEBUG - 2012-07-19 09:22:26 --> Database Driver Class Initialized
DEBUG - 2012-07-19 09:22:26 --> Helper loaded: form_helper
DEBUG - 2012-07-19 09:22:26 --> Helper loaded: html_helper
DEBUG - 2012-07-19 09:22:26 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 09:22:26 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 09:22:26 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:22:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:22:26 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 09:22:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 09:22:26 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 09:22:26 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 09:22:26 --> Final output sent to browser
DEBUG - 2012-07-19 09:22:26 --> Total execution time: 0.0397
DEBUG - 2012-07-19 09:22:27 --> Config Class Initialized
DEBUG - 2012-07-19 09:22:27 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:22:27 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:22:27 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:22:27 --> URI Class Initialized
DEBUG - 2012-07-19 09:22:27 --> Router Class Initialized
ERROR - 2012-07-19 09:22:27 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 09:28:18 --> Config Class Initialized
DEBUG - 2012-07-19 09:28:18 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:28:18 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:28:18 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:28:18 --> URI Class Initialized
DEBUG - 2012-07-19 09:28:18 --> Router Class Initialized
DEBUG - 2012-07-19 09:28:18 --> Output Class Initialized
DEBUG - 2012-07-19 09:28:18 --> Security Class Initialized
DEBUG - 2012-07-19 09:28:18 --> Input Class Initialized
DEBUG - 2012-07-19 09:28:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 09:28:18 --> Language Class Initialized
DEBUG - 2012-07-19 09:28:18 --> Loader Class Initialized
DEBUG - 2012-07-19 09:28:18 --> Helper loaded: url_helper
DEBUG - 2012-07-19 09:28:18 --> Controller Class Initialized
DEBUG - 2012-07-19 09:28:18 --> Model Class Initialized
DEBUG - 2012-07-19 09:28:18 --> Database Driver Class Initialized
DEBUG - 2012-07-19 09:28:18 --> Helper loaded: form_helper
DEBUG - 2012-07-19 09:28:18 --> Helper loaded: html_helper
DEBUG - 2012-07-19 09:28:18 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 09:28:18 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 09:28:18 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:28:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:28:18 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 09:28:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 09:28:18 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 09:28:18 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 09:28:18 --> Final output sent to browser
DEBUG - 2012-07-19 09:28:18 --> Total execution time: 0.0413
DEBUG - 2012-07-19 09:28:19 --> Config Class Initialized
DEBUG - 2012-07-19 09:28:19 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:28:19 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:28:19 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:28:19 --> URI Class Initialized
DEBUG - 2012-07-19 09:28:19 --> Router Class Initialized
ERROR - 2012-07-19 09:28:19 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 09:29:13 --> Config Class Initialized
DEBUG - 2012-07-19 09:29:13 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:29:13 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:29:13 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:29:13 --> URI Class Initialized
DEBUG - 2012-07-19 09:29:13 --> Router Class Initialized
DEBUG - 2012-07-19 09:29:13 --> Output Class Initialized
DEBUG - 2012-07-19 09:29:13 --> Security Class Initialized
DEBUG - 2012-07-19 09:29:13 --> Input Class Initialized
DEBUG - 2012-07-19 09:29:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 09:29:13 --> Language Class Initialized
DEBUG - 2012-07-19 09:29:13 --> Loader Class Initialized
DEBUG - 2012-07-19 09:29:13 --> Helper loaded: url_helper
DEBUG - 2012-07-19 09:29:13 --> Controller Class Initialized
DEBUG - 2012-07-19 09:29:13 --> Model Class Initialized
DEBUG - 2012-07-19 09:29:13 --> Database Driver Class Initialized
DEBUG - 2012-07-19 09:29:13 --> Helper loaded: form_helper
DEBUG - 2012-07-19 09:29:13 --> Helper loaded: html_helper
DEBUG - 2012-07-19 09:29:13 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 09:29:13 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 09:29:13 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:29:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:29:13 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 09:29:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 09:29:13 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 09:29:13 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 09:29:13 --> Final output sent to browser
DEBUG - 2012-07-19 09:29:13 --> Total execution time: 0.0396
DEBUG - 2012-07-19 09:29:13 --> Config Class Initialized
DEBUG - 2012-07-19 09:29:13 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:29:13 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:29:13 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:29:13 --> URI Class Initialized
DEBUG - 2012-07-19 09:29:13 --> Router Class Initialized
ERROR - 2012-07-19 09:29:13 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 09:30:38 --> Config Class Initialized
DEBUG - 2012-07-19 09:30:38 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:30:38 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:30:38 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:30:38 --> URI Class Initialized
DEBUG - 2012-07-19 09:30:38 --> Router Class Initialized
DEBUG - 2012-07-19 09:30:38 --> Output Class Initialized
DEBUG - 2012-07-19 09:30:38 --> Security Class Initialized
DEBUG - 2012-07-19 09:30:38 --> Input Class Initialized
DEBUG - 2012-07-19 09:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 09:30:38 --> Language Class Initialized
DEBUG - 2012-07-19 09:30:38 --> Loader Class Initialized
DEBUG - 2012-07-19 09:30:38 --> Helper loaded: url_helper
DEBUG - 2012-07-19 09:30:38 --> Controller Class Initialized
DEBUG - 2012-07-19 09:30:38 --> Model Class Initialized
DEBUG - 2012-07-19 09:30:38 --> Database Driver Class Initialized
DEBUG - 2012-07-19 09:30:38 --> Helper loaded: form_helper
DEBUG - 2012-07-19 09:30:38 --> Helper loaded: html_helper
DEBUG - 2012-07-19 09:30:38 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 09:30:38 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 09:30:38 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:30:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:30:38 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 09:30:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 09:30:38 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 09:30:38 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 09:30:38 --> Final output sent to browser
DEBUG - 2012-07-19 09:30:38 --> Total execution time: 0.0404
DEBUG - 2012-07-19 09:30:38 --> Config Class Initialized
DEBUG - 2012-07-19 09:30:38 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:30:38 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:30:38 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:30:38 --> URI Class Initialized
DEBUG - 2012-07-19 09:30:38 --> Router Class Initialized
ERROR - 2012-07-19 09:30:38 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 09:35:10 --> Config Class Initialized
DEBUG - 2012-07-19 09:35:10 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:35:10 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:35:10 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:35:10 --> URI Class Initialized
DEBUG - 2012-07-19 09:35:10 --> Router Class Initialized
DEBUG - 2012-07-19 09:35:10 --> Output Class Initialized
DEBUG - 2012-07-19 09:35:10 --> Security Class Initialized
DEBUG - 2012-07-19 09:35:10 --> Input Class Initialized
DEBUG - 2012-07-19 09:35:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 09:35:10 --> Language Class Initialized
DEBUG - 2012-07-19 09:35:10 --> Loader Class Initialized
DEBUG - 2012-07-19 09:35:10 --> Helper loaded: url_helper
DEBUG - 2012-07-19 09:35:10 --> Controller Class Initialized
DEBUG - 2012-07-19 09:35:10 --> Model Class Initialized
DEBUG - 2012-07-19 09:35:10 --> Database Driver Class Initialized
DEBUG - 2012-07-19 09:35:10 --> Helper loaded: form_helper
DEBUG - 2012-07-19 09:35:10 --> Helper loaded: html_helper
DEBUG - 2012-07-19 09:35:10 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 09:35:10 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 09:35:10 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:35:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:35:10 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 09:35:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 09:35:10 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 09:35:10 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 09:35:10 --> Final output sent to browser
DEBUG - 2012-07-19 09:35:10 --> Total execution time: 0.9171
DEBUG - 2012-07-19 09:35:11 --> Config Class Initialized
DEBUG - 2012-07-19 09:35:11 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:35:11 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:35:11 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:35:11 --> URI Class Initialized
DEBUG - 2012-07-19 09:35:11 --> Router Class Initialized
ERROR - 2012-07-19 09:35:11 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 09:36:57 --> Config Class Initialized
DEBUG - 2012-07-19 09:36:57 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:36:57 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:36:57 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:36:57 --> URI Class Initialized
DEBUG - 2012-07-19 09:36:57 --> Router Class Initialized
DEBUG - 2012-07-19 09:36:57 --> Output Class Initialized
DEBUG - 2012-07-19 09:36:57 --> Security Class Initialized
DEBUG - 2012-07-19 09:36:57 --> Input Class Initialized
DEBUG - 2012-07-19 09:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 09:36:57 --> Language Class Initialized
DEBUG - 2012-07-19 09:36:57 --> Loader Class Initialized
DEBUG - 2012-07-19 09:36:57 --> Helper loaded: url_helper
DEBUG - 2012-07-19 09:36:57 --> Controller Class Initialized
DEBUG - 2012-07-19 09:36:57 --> Model Class Initialized
DEBUG - 2012-07-19 09:36:57 --> Database Driver Class Initialized
DEBUG - 2012-07-19 09:36:57 --> Helper loaded: form_helper
DEBUG - 2012-07-19 09:36:57 --> Helper loaded: html_helper
DEBUG - 2012-07-19 09:36:57 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 09:36:57 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 09:36:57 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:36:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:36:57 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 09:36:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 09:36:57 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 09:36:57 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 09:36:57 --> Final output sent to browser
DEBUG - 2012-07-19 09:36:57 --> Total execution time: 0.0405
DEBUG - 2012-07-19 09:36:57 --> Config Class Initialized
DEBUG - 2012-07-19 09:36:57 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:36:57 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:36:57 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:36:57 --> URI Class Initialized
DEBUG - 2012-07-19 09:36:57 --> Router Class Initialized
ERROR - 2012-07-19 09:36:57 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 09:37:55 --> Config Class Initialized
DEBUG - 2012-07-19 09:37:55 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:37:55 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:37:55 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:37:55 --> URI Class Initialized
DEBUG - 2012-07-19 09:37:55 --> Router Class Initialized
DEBUG - 2012-07-19 09:37:55 --> Output Class Initialized
DEBUG - 2012-07-19 09:37:55 --> Security Class Initialized
DEBUG - 2012-07-19 09:37:55 --> Input Class Initialized
DEBUG - 2012-07-19 09:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 09:37:55 --> Language Class Initialized
DEBUG - 2012-07-19 09:37:55 --> Loader Class Initialized
DEBUG - 2012-07-19 09:37:55 --> Helper loaded: url_helper
DEBUG - 2012-07-19 09:37:55 --> Controller Class Initialized
DEBUG - 2012-07-19 09:37:55 --> Model Class Initialized
DEBUG - 2012-07-19 09:37:55 --> Database Driver Class Initialized
DEBUG - 2012-07-19 09:37:55 --> Helper loaded: form_helper
DEBUG - 2012-07-19 09:37:55 --> Helper loaded: html_helper
DEBUG - 2012-07-19 09:37:55 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 09:37:55 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 09:37:55 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:37:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:37:55 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 09:37:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 09:37:55 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 09:37:55 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 09:37:55 --> Final output sent to browser
DEBUG - 2012-07-19 09:37:55 --> Total execution time: 0.0511
DEBUG - 2012-07-19 09:37:55 --> Config Class Initialized
DEBUG - 2012-07-19 09:37:55 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:37:55 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:37:55 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:37:55 --> URI Class Initialized
DEBUG - 2012-07-19 09:37:55 --> Router Class Initialized
ERROR - 2012-07-19 09:37:55 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 09:38:04 --> Config Class Initialized
DEBUG - 2012-07-19 09:38:04 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:38:04 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:38:04 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:38:04 --> URI Class Initialized
DEBUG - 2012-07-19 09:38:04 --> Router Class Initialized
DEBUG - 2012-07-19 09:38:04 --> Output Class Initialized
DEBUG - 2012-07-19 09:38:04 --> Security Class Initialized
DEBUG - 2012-07-19 09:38:04 --> Input Class Initialized
DEBUG - 2012-07-19 09:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 09:38:04 --> Language Class Initialized
DEBUG - 2012-07-19 09:38:04 --> Loader Class Initialized
DEBUG - 2012-07-19 09:38:04 --> Helper loaded: url_helper
DEBUG - 2012-07-19 09:38:04 --> Controller Class Initialized
DEBUG - 2012-07-19 09:38:04 --> Model Class Initialized
DEBUG - 2012-07-19 09:38:04 --> Database Driver Class Initialized
DEBUG - 2012-07-19 09:38:04 --> Helper loaded: form_helper
DEBUG - 2012-07-19 09:38:04 --> Helper loaded: html_helper
DEBUG - 2012-07-19 09:38:04 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 09:38:04 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 09:38:04 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:38:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:38:04 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 09:38:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 09:38:04 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 09:38:04 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 09:38:04 --> Final output sent to browser
DEBUG - 2012-07-19 09:38:04 --> Total execution time: 0.0447
DEBUG - 2012-07-19 09:38:05 --> Config Class Initialized
DEBUG - 2012-07-19 09:38:05 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:38:05 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:38:05 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:38:05 --> URI Class Initialized
DEBUG - 2012-07-19 09:38:05 --> Router Class Initialized
ERROR - 2012-07-19 09:38:05 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 09:38:39 --> Config Class Initialized
DEBUG - 2012-07-19 09:38:39 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:38:39 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:38:39 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:38:39 --> URI Class Initialized
DEBUG - 2012-07-19 09:38:39 --> Router Class Initialized
DEBUG - 2012-07-19 09:38:39 --> Output Class Initialized
DEBUG - 2012-07-19 09:38:39 --> Security Class Initialized
DEBUG - 2012-07-19 09:38:39 --> Input Class Initialized
DEBUG - 2012-07-19 09:38:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 09:38:39 --> Language Class Initialized
DEBUG - 2012-07-19 09:38:39 --> Loader Class Initialized
DEBUG - 2012-07-19 09:38:39 --> Helper loaded: url_helper
DEBUG - 2012-07-19 09:38:39 --> Controller Class Initialized
DEBUG - 2012-07-19 09:38:39 --> Model Class Initialized
DEBUG - 2012-07-19 09:38:39 --> Database Driver Class Initialized
DEBUG - 2012-07-19 09:38:39 --> Helper loaded: form_helper
DEBUG - 2012-07-19 09:38:39 --> Helper loaded: html_helper
DEBUG - 2012-07-19 09:38:39 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 09:38:39 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 09:38:39 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:38:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:38:39 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 09:38:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 09:38:39 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 09:38:39 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 09:38:39 --> Final output sent to browser
DEBUG - 2012-07-19 09:38:39 --> Total execution time: 0.0398
DEBUG - 2012-07-19 09:38:39 --> Config Class Initialized
DEBUG - 2012-07-19 09:38:39 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:38:39 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:38:39 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:38:39 --> URI Class Initialized
DEBUG - 2012-07-19 09:38:39 --> Router Class Initialized
ERROR - 2012-07-19 09:38:39 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 09:39:01 --> Config Class Initialized
DEBUG - 2012-07-19 09:39:01 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:39:01 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:39:01 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:39:01 --> URI Class Initialized
DEBUG - 2012-07-19 09:39:01 --> Router Class Initialized
DEBUG - 2012-07-19 09:39:01 --> Output Class Initialized
DEBUG - 2012-07-19 09:39:01 --> Security Class Initialized
DEBUG - 2012-07-19 09:39:01 --> Input Class Initialized
DEBUG - 2012-07-19 09:39:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 09:39:01 --> Language Class Initialized
DEBUG - 2012-07-19 09:39:01 --> Loader Class Initialized
DEBUG - 2012-07-19 09:39:01 --> Helper loaded: url_helper
DEBUG - 2012-07-19 09:39:01 --> Controller Class Initialized
DEBUG - 2012-07-19 09:39:01 --> Model Class Initialized
DEBUG - 2012-07-19 09:39:01 --> Database Driver Class Initialized
DEBUG - 2012-07-19 09:39:01 --> Helper loaded: form_helper
DEBUG - 2012-07-19 09:39:01 --> Helper loaded: html_helper
DEBUG - 2012-07-19 09:39:01 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 09:39:01 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 09:39:01 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:39:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:39:01 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 09:39:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 09:39:01 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 09:39:01 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 09:39:01 --> Final output sent to browser
DEBUG - 2012-07-19 09:39:01 --> Total execution time: 0.0426
DEBUG - 2012-07-19 09:39:01 --> Config Class Initialized
DEBUG - 2012-07-19 09:39:01 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:39:01 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:39:01 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:39:01 --> URI Class Initialized
DEBUG - 2012-07-19 09:39:01 --> Router Class Initialized
ERROR - 2012-07-19 09:39:01 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 09:39:15 --> Config Class Initialized
DEBUG - 2012-07-19 09:39:15 --> Hooks Class Initialized
DEBUG - 2012-07-19 09:39:15 --> Utf8 Class Initialized
DEBUG - 2012-07-19 09:39:15 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 09:39:15 --> URI Class Initialized
DEBUG - 2012-07-19 09:39:15 --> Router Class Initialized
DEBUG - 2012-07-19 09:39:15 --> Output Class Initialized
DEBUG - 2012-07-19 09:39:15 --> Security Class Initialized
DEBUG - 2012-07-19 09:39:15 --> Input Class Initialized
DEBUG - 2012-07-19 09:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 09:39:15 --> Language Class Initialized
DEBUG - 2012-07-19 09:39:15 --> Loader Class Initialized
DEBUG - 2012-07-19 09:39:15 --> Helper loaded: url_helper
DEBUG - 2012-07-19 09:39:15 --> Controller Class Initialized
DEBUG - 2012-07-19 09:39:15 --> Model Class Initialized
DEBUG - 2012-07-19 09:39:15 --> Database Driver Class Initialized
DEBUG - 2012-07-19 09:39:15 --> Helper loaded: form_helper
DEBUG - 2012-07-19 09:39:15 --> Helper loaded: html_helper
DEBUG - 2012-07-19 09:39:15 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 09:39:15 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 09:39:15 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:39:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 09:39:15 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 09:39:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 09:39:15 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 09:39:15 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 09:39:15 --> Final output sent to browser
DEBUG - 2012-07-19 09:39:15 --> Total execution time: 0.0397
DEBUG - 2012-07-19 13:06:27 --> Config Class Initialized
DEBUG - 2012-07-19 13:06:27 --> Hooks Class Initialized
DEBUG - 2012-07-19 13:06:27 --> Utf8 Class Initialized
DEBUG - 2012-07-19 13:06:27 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 13:06:27 --> URI Class Initialized
DEBUG - 2012-07-19 13:06:27 --> Router Class Initialized
DEBUG - 2012-07-19 13:06:27 --> Output Class Initialized
DEBUG - 2012-07-19 13:06:27 --> Security Class Initialized
DEBUG - 2012-07-19 13:06:27 --> Input Class Initialized
DEBUG - 2012-07-19 13:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 13:06:27 --> Language Class Initialized
DEBUG - 2012-07-19 13:06:27 --> Loader Class Initialized
DEBUG - 2012-07-19 13:06:27 --> Helper loaded: url_helper
DEBUG - 2012-07-19 13:06:27 --> Controller Class Initialized
DEBUG - 2012-07-19 13:06:27 --> Model Class Initialized
DEBUG - 2012-07-19 13:06:27 --> Database Driver Class Initialized
DEBUG - 2012-07-19 13:06:27 --> Helper loaded: form_helper
DEBUG - 2012-07-19 13:06:27 --> Helper loaded: html_helper
DEBUG - 2012-07-19 13:06:27 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 13:06:27 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 13:06:27 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 13:06:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 13:06:27 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 13:06:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 13:06:27 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 13:06:27 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 13:06:27 --> Final output sent to browser
DEBUG - 2012-07-19 13:06:27 --> Total execution time: 0.3898
DEBUG - 2012-07-19 13:06:27 --> Config Class Initialized
DEBUG - 2012-07-19 13:06:27 --> Hooks Class Initialized
DEBUG - 2012-07-19 13:06:27 --> Utf8 Class Initialized
DEBUG - 2012-07-19 13:06:27 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 13:06:27 --> URI Class Initialized
DEBUG - 2012-07-19 13:06:27 --> Router Class Initialized
ERROR - 2012-07-19 13:06:27 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 13:06:31 --> Config Class Initialized
DEBUG - 2012-07-19 13:06:31 --> Hooks Class Initialized
DEBUG - 2012-07-19 13:06:31 --> Utf8 Class Initialized
DEBUG - 2012-07-19 13:06:31 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 13:06:31 --> URI Class Initialized
DEBUG - 2012-07-19 13:06:31 --> Router Class Initialized
DEBUG - 2012-07-19 13:06:31 --> Output Class Initialized
DEBUG - 2012-07-19 13:06:31 --> Security Class Initialized
DEBUG - 2012-07-19 13:06:31 --> Input Class Initialized
DEBUG - 2012-07-19 13:06:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 13:06:31 --> Language Class Initialized
DEBUG - 2012-07-19 13:06:31 --> Loader Class Initialized
DEBUG - 2012-07-19 13:06:31 --> Helper loaded: url_helper
DEBUG - 2012-07-19 13:06:31 --> Controller Class Initialized
DEBUG - 2012-07-19 13:06:31 --> Model Class Initialized
DEBUG - 2012-07-19 13:06:31 --> Database Driver Class Initialized
DEBUG - 2012-07-19 13:06:31 --> Helper loaded: form_helper
DEBUG - 2012-07-19 13:06:31 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-19 13:06:31 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-19 13:06:31 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-19 13:06:31 --> File loaded: application/views/admin/pages/business.php
DEBUG - 2012-07-19 13:06:32 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-19 13:06:32 --> Final output sent to browser
DEBUG - 2012-07-19 13:06:32 --> Total execution time: 0.2097
DEBUG - 2012-07-19 13:06:35 --> Config Class Initialized
DEBUG - 2012-07-19 13:06:35 --> Hooks Class Initialized
DEBUG - 2012-07-19 13:06:35 --> Utf8 Class Initialized
DEBUG - 2012-07-19 13:06:35 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 13:06:35 --> URI Class Initialized
DEBUG - 2012-07-19 13:06:35 --> Router Class Initialized
DEBUG - 2012-07-19 13:06:35 --> Output Class Initialized
DEBUG - 2012-07-19 13:06:35 --> Security Class Initialized
DEBUG - 2012-07-19 13:06:35 --> Input Class Initialized
DEBUG - 2012-07-19 13:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 13:06:35 --> Language Class Initialized
DEBUG - 2012-07-19 13:06:35 --> Loader Class Initialized
DEBUG - 2012-07-19 13:06:35 --> Helper loaded: url_helper
DEBUG - 2012-07-19 13:06:35 --> Controller Class Initialized
DEBUG - 2012-07-19 13:06:35 --> Model Class Initialized
DEBUG - 2012-07-19 13:06:35 --> Database Driver Class Initialized
DEBUG - 2012-07-19 13:06:35 --> Helper loaded: form_helper
DEBUG - 2012-07-19 13:06:35 --> Helper loaded: html_helper
DEBUG - 2012-07-19 13:06:35 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 13:06:35 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 13:06:35 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 13:06:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 13:06:35 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 13:06:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 13:06:35 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 13:06:35 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 13:06:35 --> Final output sent to browser
DEBUG - 2012-07-19 13:06:35 --> Total execution time: 0.0491
DEBUG - 2012-07-19 13:06:36 --> Config Class Initialized
DEBUG - 2012-07-19 13:06:36 --> Hooks Class Initialized
DEBUG - 2012-07-19 13:06:36 --> Utf8 Class Initialized
DEBUG - 2012-07-19 13:06:36 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 13:06:36 --> URI Class Initialized
DEBUG - 2012-07-19 13:06:36 --> Router Class Initialized
ERROR - 2012-07-19 13:06:36 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 13:13:48 --> Config Class Initialized
DEBUG - 2012-07-19 13:13:48 --> Hooks Class Initialized
DEBUG - 2012-07-19 13:13:48 --> Utf8 Class Initialized
DEBUG - 2012-07-19 13:13:48 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 13:13:48 --> URI Class Initialized
DEBUG - 2012-07-19 13:13:48 --> Router Class Initialized
DEBUG - 2012-07-19 13:13:48 --> Output Class Initialized
DEBUG - 2012-07-19 13:13:48 --> Security Class Initialized
DEBUG - 2012-07-19 13:13:48 --> Input Class Initialized
DEBUG - 2012-07-19 13:13:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 13:13:48 --> Language Class Initialized
DEBUG - 2012-07-19 13:13:48 --> Loader Class Initialized
DEBUG - 2012-07-19 13:13:48 --> Helper loaded: url_helper
DEBUG - 2012-07-19 13:13:48 --> Controller Class Initialized
DEBUG - 2012-07-19 13:13:48 --> Model Class Initialized
DEBUG - 2012-07-19 13:13:48 --> Database Driver Class Initialized
DEBUG - 2012-07-19 13:13:48 --> Helper loaded: form_helper
DEBUG - 2012-07-19 13:13:48 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-19 13:13:48 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-19 13:13:48 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-19 13:13:48 --> File loaded: application/views/admin/pages/business.php
DEBUG - 2012-07-19 13:13:48 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-19 13:13:48 --> Final output sent to browser
DEBUG - 2012-07-19 13:13:48 --> Total execution time: 0.0635
DEBUG - 2012-07-19 13:13:53 --> Config Class Initialized
DEBUG - 2012-07-19 13:13:53 --> Hooks Class Initialized
DEBUG - 2012-07-19 13:13:53 --> Utf8 Class Initialized
DEBUG - 2012-07-19 13:13:53 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 13:13:53 --> URI Class Initialized
DEBUG - 2012-07-19 13:13:53 --> Router Class Initialized
DEBUG - 2012-07-19 13:13:53 --> Output Class Initialized
DEBUG - 2012-07-19 13:13:53 --> Security Class Initialized
DEBUG - 2012-07-19 13:13:53 --> Input Class Initialized
DEBUG - 2012-07-19 13:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 13:13:53 --> Language Class Initialized
DEBUG - 2012-07-19 13:13:53 --> Loader Class Initialized
DEBUG - 2012-07-19 13:13:53 --> Helper loaded: url_helper
DEBUG - 2012-07-19 13:13:53 --> Controller Class Initialized
DEBUG - 2012-07-19 13:13:53 --> Model Class Initialized
DEBUG - 2012-07-19 13:13:53 --> Database Driver Class Initialized
DEBUG - 2012-07-19 13:13:53 --> Helper loaded: form_helper
DEBUG - 2012-07-19 13:13:53 --> Helper loaded: html_helper
DEBUG - 2012-07-19 13:13:53 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 13:13:53 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 13:13:53 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 13:13:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 13:13:53 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 13:13:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 13:13:53 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 13:13:53 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 13:13:53 --> Final output sent to browser
DEBUG - 2012-07-19 13:13:53 --> Total execution time: 0.0410
DEBUG - 2012-07-19 13:13:54 --> Config Class Initialized
DEBUG - 2012-07-19 13:13:54 --> Hooks Class Initialized
DEBUG - 2012-07-19 13:13:54 --> Utf8 Class Initialized
DEBUG - 2012-07-19 13:13:54 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 13:13:54 --> URI Class Initialized
DEBUG - 2012-07-19 13:13:54 --> Router Class Initialized
ERROR - 2012-07-19 13:13:54 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 14:43:46 --> Config Class Initialized
DEBUG - 2012-07-19 14:43:46 --> Hooks Class Initialized
DEBUG - 2012-07-19 14:43:46 --> Utf8 Class Initialized
DEBUG - 2012-07-19 14:43:46 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 14:43:46 --> URI Class Initialized
DEBUG - 2012-07-19 14:43:46 --> Router Class Initialized
DEBUG - 2012-07-19 14:43:46 --> Output Class Initialized
DEBUG - 2012-07-19 14:43:46 --> Security Class Initialized
DEBUG - 2012-07-19 14:43:46 --> Input Class Initialized
DEBUG - 2012-07-19 14:43:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 14:43:46 --> Language Class Initialized
DEBUG - 2012-07-19 14:43:46 --> Loader Class Initialized
DEBUG - 2012-07-19 14:43:46 --> Helper loaded: url_helper
DEBUG - 2012-07-19 14:43:46 --> Controller Class Initialized
DEBUG - 2012-07-19 14:43:46 --> Model Class Initialized
DEBUG - 2012-07-19 14:43:46 --> Database Driver Class Initialized
DEBUG - 2012-07-19 14:43:46 --> Helper loaded: form_helper
DEBUG - 2012-07-19 14:43:46 --> Helper loaded: html_helper
DEBUG - 2012-07-19 14:43:46 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 14:43:46 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 14:43:46 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 14:43:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 14:43:46 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 14:43:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 14:43:46 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 14:43:46 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 14:43:46 --> Final output sent to browser
DEBUG - 2012-07-19 14:43:46 --> Total execution time: 0.0402
DEBUG - 2012-07-19 14:43:46 --> Config Class Initialized
DEBUG - 2012-07-19 14:43:46 --> Hooks Class Initialized
DEBUG - 2012-07-19 14:43:46 --> Utf8 Class Initialized
DEBUG - 2012-07-19 14:43:46 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 14:43:46 --> URI Class Initialized
DEBUG - 2012-07-19 14:43:46 --> Router Class Initialized
ERROR - 2012-07-19 14:43:46 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 16:37:45 --> Config Class Initialized
DEBUG - 2012-07-19 16:37:45 --> Hooks Class Initialized
DEBUG - 2012-07-19 16:37:45 --> Utf8 Class Initialized
DEBUG - 2012-07-19 16:37:45 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 16:37:45 --> URI Class Initialized
DEBUG - 2012-07-19 16:37:45 --> Router Class Initialized
DEBUG - 2012-07-19 16:37:45 --> Output Class Initialized
DEBUG - 2012-07-19 16:37:45 --> Security Class Initialized
DEBUG - 2012-07-19 16:37:45 --> Input Class Initialized
DEBUG - 2012-07-19 16:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 16:37:45 --> Language Class Initialized
DEBUG - 2012-07-19 16:37:45 --> Loader Class Initialized
DEBUG - 2012-07-19 16:37:45 --> Helper loaded: url_helper
DEBUG - 2012-07-19 16:37:45 --> Controller Class Initialized
DEBUG - 2012-07-19 16:37:45 --> Model Class Initialized
DEBUG - 2012-07-19 16:37:45 --> Database Driver Class Initialized
DEBUG - 2012-07-19 16:37:45 --> Helper loaded: form_helper
DEBUG - 2012-07-19 16:37:45 --> Helper loaded: html_helper
DEBUG - 2012-07-19 16:37:45 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 16:37:45 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 16:37:45 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 16:37:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 16:37:45 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 16:37:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 16:37:45 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 16:37:45 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 16:37:45 --> Final output sent to browser
DEBUG - 2012-07-19 16:37:45 --> Total execution time: 0.0398
DEBUG - 2012-07-19 16:37:45 --> Config Class Initialized
DEBUG - 2012-07-19 16:37:45 --> Hooks Class Initialized
DEBUG - 2012-07-19 16:37:45 --> Utf8 Class Initialized
DEBUG - 2012-07-19 16:37:45 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 16:37:45 --> URI Class Initialized
DEBUG - 2012-07-19 16:37:45 --> Router Class Initialized
ERROR - 2012-07-19 16:37:45 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 17:09:11 --> Config Class Initialized
DEBUG - 2012-07-19 17:09:11 --> Hooks Class Initialized
DEBUG - 2012-07-19 17:09:11 --> Utf8 Class Initialized
DEBUG - 2012-07-19 17:09:11 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 17:09:11 --> URI Class Initialized
DEBUG - 2012-07-19 17:09:11 --> Router Class Initialized
DEBUG - 2012-07-19 17:09:11 --> Output Class Initialized
DEBUG - 2012-07-19 17:09:11 --> Security Class Initialized
DEBUG - 2012-07-19 17:09:11 --> Input Class Initialized
DEBUG - 2012-07-19 17:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 17:09:11 --> Language Class Initialized
DEBUG - 2012-07-19 17:09:11 --> Loader Class Initialized
DEBUG - 2012-07-19 17:09:11 --> Helper loaded: url_helper
DEBUG - 2012-07-19 17:09:11 --> Controller Class Initialized
DEBUG - 2012-07-19 17:09:11 --> Model Class Initialized
DEBUG - 2012-07-19 17:09:11 --> Database Driver Class Initialized
DEBUG - 2012-07-19 17:09:11 --> Helper loaded: form_helper
DEBUG - 2012-07-19 17:09:11 --> Helper loaded: html_helper
DEBUG - 2012-07-19 17:09:11 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 17:09:11 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 17:09:11 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 17:09:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 17:09:11 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 17:09:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 17:09:11 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 17:09:11 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 17:09:11 --> Final output sent to browser
DEBUG - 2012-07-19 17:09:11 --> Total execution time: 0.0408
DEBUG - 2012-07-19 17:09:12 --> Config Class Initialized
DEBUG - 2012-07-19 17:09:12 --> Hooks Class Initialized
DEBUG - 2012-07-19 17:09:12 --> Utf8 Class Initialized
DEBUG - 2012-07-19 17:09:12 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 17:09:12 --> URI Class Initialized
DEBUG - 2012-07-19 17:09:12 --> Router Class Initialized
ERROR - 2012-07-19 17:09:12 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 17:11:23 --> Config Class Initialized
DEBUG - 2012-07-19 17:11:23 --> Hooks Class Initialized
DEBUG - 2012-07-19 17:11:23 --> Utf8 Class Initialized
DEBUG - 2012-07-19 17:11:23 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 17:11:23 --> URI Class Initialized
DEBUG - 2012-07-19 17:11:23 --> Router Class Initialized
ERROR - 2012-07-19 17:11:23 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 17:20:39 --> Config Class Initialized
DEBUG - 2012-07-19 17:20:39 --> Hooks Class Initialized
DEBUG - 2012-07-19 17:20:39 --> Utf8 Class Initialized
DEBUG - 2012-07-19 17:20:39 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 17:20:39 --> URI Class Initialized
DEBUG - 2012-07-19 17:20:39 --> Router Class Initialized
DEBUG - 2012-07-19 17:20:39 --> Output Class Initialized
DEBUG - 2012-07-19 17:20:39 --> Security Class Initialized
DEBUG - 2012-07-19 17:20:39 --> Input Class Initialized
DEBUG - 2012-07-19 17:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 17:20:39 --> Language Class Initialized
DEBUG - 2012-07-19 17:20:39 --> Loader Class Initialized
DEBUG - 2012-07-19 17:20:39 --> Helper loaded: url_helper
DEBUG - 2012-07-19 17:20:39 --> Controller Class Initialized
DEBUG - 2012-07-19 17:20:39 --> Model Class Initialized
DEBUG - 2012-07-19 17:20:39 --> Database Driver Class Initialized
DEBUG - 2012-07-19 17:20:39 --> Helper loaded: form_helper
DEBUG - 2012-07-19 17:20:39 --> Helper loaded: html_helper
DEBUG - 2012-07-19 17:20:39 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 17:20:39 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 17:20:39 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 17:20:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 17:20:39 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 17:20:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 17:20:39 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 17:20:39 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 17:20:39 --> Final output sent to browser
DEBUG - 2012-07-19 17:20:39 --> Total execution time: 0.0450
DEBUG - 2012-07-19 17:21:00 --> Config Class Initialized
DEBUG - 2012-07-19 17:21:00 --> Hooks Class Initialized
DEBUG - 2012-07-19 17:21:00 --> Utf8 Class Initialized
DEBUG - 2012-07-19 17:21:00 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 17:21:00 --> URI Class Initialized
DEBUG - 2012-07-19 17:21:00 --> Router Class Initialized
DEBUG - 2012-07-19 17:21:00 --> Output Class Initialized
DEBUG - 2012-07-19 17:21:00 --> Security Class Initialized
DEBUG - 2012-07-19 17:21:00 --> Input Class Initialized
DEBUG - 2012-07-19 17:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 17:21:00 --> Language Class Initialized
DEBUG - 2012-07-19 17:21:00 --> Loader Class Initialized
DEBUG - 2012-07-19 17:21:00 --> Helper loaded: url_helper
DEBUG - 2012-07-19 17:21:00 --> Controller Class Initialized
DEBUG - 2012-07-19 17:21:00 --> Model Class Initialized
DEBUG - 2012-07-19 17:21:00 --> Database Driver Class Initialized
DEBUG - 2012-07-19 17:21:00 --> Helper loaded: form_helper
DEBUG - 2012-07-19 17:21:00 --> Helper loaded: html_helper
DEBUG - 2012-07-19 17:21:00 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 17:21:00 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 17:21:00 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 17:21:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 17:21:00 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 17:21:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 17:21:00 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 17:21:00 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 17:21:00 --> Final output sent to browser
DEBUG - 2012-07-19 17:21:00 --> Total execution time: 0.0398
DEBUG - 2012-07-19 17:21:16 --> Config Class Initialized
DEBUG - 2012-07-19 17:21:16 --> Hooks Class Initialized
DEBUG - 2012-07-19 17:21:16 --> Utf8 Class Initialized
DEBUG - 2012-07-19 17:21:16 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 17:21:16 --> URI Class Initialized
DEBUG - 2012-07-19 17:21:16 --> Router Class Initialized
DEBUG - 2012-07-19 17:21:16 --> Output Class Initialized
DEBUG - 2012-07-19 17:21:16 --> Security Class Initialized
DEBUG - 2012-07-19 17:21:16 --> Input Class Initialized
DEBUG - 2012-07-19 17:21:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 17:21:16 --> Language Class Initialized
DEBUG - 2012-07-19 17:21:16 --> Loader Class Initialized
DEBUG - 2012-07-19 17:21:16 --> Helper loaded: url_helper
DEBUG - 2012-07-19 17:21:16 --> Controller Class Initialized
DEBUG - 2012-07-19 17:21:16 --> Model Class Initialized
DEBUG - 2012-07-19 17:21:16 --> Database Driver Class Initialized
DEBUG - 2012-07-19 17:21:16 --> Helper loaded: form_helper
DEBUG - 2012-07-19 17:21:16 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-19 17:21:16 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-19 17:21:16 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-19 17:21:16 --> File loaded: application/views/admin/pages/business.php
DEBUG - 2012-07-19 17:21:16 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-19 17:21:16 --> Final output sent to browser
DEBUG - 2012-07-19 17:21:16 --> Total execution time: 0.0525
DEBUG - 2012-07-19 17:21:17 --> Config Class Initialized
DEBUG - 2012-07-19 17:21:17 --> Hooks Class Initialized
DEBUG - 2012-07-19 17:21:17 --> Utf8 Class Initialized
DEBUG - 2012-07-19 17:21:17 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 17:21:17 --> URI Class Initialized
DEBUG - 2012-07-19 17:21:17 --> Router Class Initialized
ERROR - 2012-07-19 17:21:17 --> 404 Page Not Found --> js
DEBUG - 2012-07-19 17:21:21 --> Config Class Initialized
DEBUG - 2012-07-19 17:21:21 --> Hooks Class Initialized
DEBUG - 2012-07-19 17:21:21 --> Utf8 Class Initialized
DEBUG - 2012-07-19 17:21:21 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 17:21:21 --> URI Class Initialized
DEBUG - 2012-07-19 17:21:21 --> Router Class Initialized
DEBUG - 2012-07-19 17:21:21 --> Output Class Initialized
DEBUG - 2012-07-19 17:21:21 --> Security Class Initialized
DEBUG - 2012-07-19 17:21:21 --> Input Class Initialized
DEBUG - 2012-07-19 17:21:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 17:21:21 --> Language Class Initialized
DEBUG - 2012-07-19 17:21:21 --> Loader Class Initialized
DEBUG - 2012-07-19 17:21:21 --> Helper loaded: url_helper
DEBUG - 2012-07-19 17:21:21 --> Controller Class Initialized
DEBUG - 2012-07-19 17:21:21 --> Model Class Initialized
DEBUG - 2012-07-19 17:21:21 --> Database Driver Class Initialized
DEBUG - 2012-07-19 17:21:21 --> Helper loaded: form_helper
DEBUG - 2012-07-19 17:21:21 --> Helper loaded: html_helper
DEBUG - 2012-07-19 17:21:21 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 17:21:21 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 17:21:21 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 17:21:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 17:21:21 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 17:21:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 17:21:21 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 17:21:21 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 17:21:21 --> Final output sent to browser
DEBUG - 2012-07-19 17:21:21 --> Total execution time: 0.0462
DEBUG - 2012-07-19 17:24:06 --> Config Class Initialized
DEBUG - 2012-07-19 17:24:06 --> Hooks Class Initialized
DEBUG - 2012-07-19 17:24:06 --> Utf8 Class Initialized
DEBUG - 2012-07-19 17:24:06 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 17:24:06 --> URI Class Initialized
DEBUG - 2012-07-19 17:24:06 --> Router Class Initialized
DEBUG - 2012-07-19 17:24:06 --> Output Class Initialized
DEBUG - 2012-07-19 17:24:06 --> Security Class Initialized
DEBUG - 2012-07-19 17:24:06 --> Input Class Initialized
DEBUG - 2012-07-19 17:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 17:24:06 --> Language Class Initialized
DEBUG - 2012-07-19 17:24:06 --> Loader Class Initialized
DEBUG - 2012-07-19 17:24:06 --> Helper loaded: url_helper
DEBUG - 2012-07-19 17:24:06 --> Controller Class Initialized
DEBUG - 2012-07-19 17:24:06 --> Model Class Initialized
DEBUG - 2012-07-19 17:24:06 --> Database Driver Class Initialized
DEBUG - 2012-07-19 17:24:06 --> Helper loaded: form_helper
DEBUG - 2012-07-19 17:24:06 --> Helper loaded: html_helper
DEBUG - 2012-07-19 17:24:06 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 17:24:06 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 17:24:06 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 17:24:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 17:24:06 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 17:24:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 17:24:06 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 17:24:06 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 17:24:06 --> Final output sent to browser
DEBUG - 2012-07-19 17:24:06 --> Total execution time: 0.0406
DEBUG - 2012-07-19 17:25:59 --> Config Class Initialized
DEBUG - 2012-07-19 17:25:59 --> Hooks Class Initialized
DEBUG - 2012-07-19 17:25:59 --> Utf8 Class Initialized
DEBUG - 2012-07-19 17:25:59 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 17:25:59 --> URI Class Initialized
DEBUG - 2012-07-19 17:25:59 --> Router Class Initialized
DEBUG - 2012-07-19 17:25:59 --> Output Class Initialized
DEBUG - 2012-07-19 17:25:59 --> Security Class Initialized
DEBUG - 2012-07-19 17:25:59 --> Input Class Initialized
DEBUG - 2012-07-19 17:25:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 17:25:59 --> Language Class Initialized
DEBUG - 2012-07-19 17:25:59 --> Loader Class Initialized
DEBUG - 2012-07-19 17:25:59 --> Helper loaded: url_helper
DEBUG - 2012-07-19 17:25:59 --> Controller Class Initialized
DEBUG - 2012-07-19 17:25:59 --> Model Class Initialized
DEBUG - 2012-07-19 17:25:59 --> Database Driver Class Initialized
DEBUG - 2012-07-19 17:25:59 --> Helper loaded: form_helper
DEBUG - 2012-07-19 17:25:59 --> Helper loaded: html_helper
DEBUG - 2012-07-19 17:25:59 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 17:25:59 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 17:26:00 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 17:26:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 17:26:00 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 17:26:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 17:26:00 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 17:26:00 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 17:26:00 --> Final output sent to browser
DEBUG - 2012-07-19 17:26:00 --> Total execution time: 0.0449
DEBUG - 2012-07-19 17:26:44 --> Config Class Initialized
DEBUG - 2012-07-19 17:26:44 --> Hooks Class Initialized
DEBUG - 2012-07-19 17:26:44 --> Utf8 Class Initialized
DEBUG - 2012-07-19 17:26:44 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 17:26:44 --> URI Class Initialized
DEBUG - 2012-07-19 17:26:44 --> Router Class Initialized
DEBUG - 2012-07-19 17:26:44 --> Output Class Initialized
DEBUG - 2012-07-19 17:26:44 --> Security Class Initialized
DEBUG - 2012-07-19 17:26:44 --> Input Class Initialized
DEBUG - 2012-07-19 17:26:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 17:26:44 --> Language Class Initialized
DEBUG - 2012-07-19 17:26:44 --> Loader Class Initialized
DEBUG - 2012-07-19 17:26:44 --> Helper loaded: url_helper
DEBUG - 2012-07-19 17:26:44 --> Controller Class Initialized
DEBUG - 2012-07-19 17:26:44 --> Model Class Initialized
DEBUG - 2012-07-19 17:26:44 --> Database Driver Class Initialized
DEBUG - 2012-07-19 17:26:44 --> Helper loaded: form_helper
DEBUG - 2012-07-19 17:26:44 --> Helper loaded: html_helper
DEBUG - 2012-07-19 17:26:44 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 17:26:44 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 17:26:44 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 17:26:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 17:26:44 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 17:26:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 17:26:44 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 17:26:44 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 17:26:44 --> Final output sent to browser
DEBUG - 2012-07-19 17:26:44 --> Total execution time: 0.0403
DEBUG - 2012-07-19 17:27:00 --> Config Class Initialized
DEBUG - 2012-07-19 17:27:00 --> Hooks Class Initialized
DEBUG - 2012-07-19 17:27:00 --> Utf8 Class Initialized
DEBUG - 2012-07-19 17:27:00 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 17:27:00 --> URI Class Initialized
DEBUG - 2012-07-19 17:27:00 --> Router Class Initialized
DEBUG - 2012-07-19 17:27:00 --> Output Class Initialized
DEBUG - 2012-07-19 17:27:00 --> Security Class Initialized
DEBUG - 2012-07-19 17:27:00 --> Input Class Initialized
DEBUG - 2012-07-19 17:27:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 17:27:00 --> Language Class Initialized
DEBUG - 2012-07-19 17:27:00 --> Loader Class Initialized
DEBUG - 2012-07-19 17:27:00 --> Helper loaded: url_helper
DEBUG - 2012-07-19 17:27:00 --> Controller Class Initialized
DEBUG - 2012-07-19 17:27:00 --> Model Class Initialized
DEBUG - 2012-07-19 17:27:00 --> Database Driver Class Initialized
DEBUG - 2012-07-19 17:27:00 --> Helper loaded: form_helper
DEBUG - 2012-07-19 17:27:00 --> Helper loaded: html_helper
DEBUG - 2012-07-19 17:27:00 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 17:27:00 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 17:27:00 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 17:27:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 17:27:00 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 17:27:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 17:27:00 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 17:27:00 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 17:27:00 --> Final output sent to browser
DEBUG - 2012-07-19 17:27:00 --> Total execution time: 0.0456
DEBUG - 2012-07-19 17:41:06 --> Config Class Initialized
DEBUG - 2012-07-19 17:41:06 --> Hooks Class Initialized
DEBUG - 2012-07-19 17:41:06 --> Utf8 Class Initialized
DEBUG - 2012-07-19 17:41:06 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 17:41:06 --> URI Class Initialized
DEBUG - 2012-07-19 17:41:06 --> Router Class Initialized
DEBUG - 2012-07-19 17:41:06 --> Output Class Initialized
DEBUG - 2012-07-19 17:41:06 --> Security Class Initialized
DEBUG - 2012-07-19 17:41:06 --> Input Class Initialized
DEBUG - 2012-07-19 17:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 17:41:06 --> Language Class Initialized
DEBUG - 2012-07-19 17:41:06 --> Loader Class Initialized
DEBUG - 2012-07-19 17:41:06 --> Helper loaded: url_helper
DEBUG - 2012-07-19 17:41:06 --> Controller Class Initialized
DEBUG - 2012-07-19 17:41:06 --> Model Class Initialized
DEBUG - 2012-07-19 17:41:06 --> Database Driver Class Initialized
DEBUG - 2012-07-19 17:41:06 --> Helper loaded: form_helper
DEBUG - 2012-07-19 17:41:06 --> Helper loaded: html_helper
DEBUG - 2012-07-19 17:41:06 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 17:41:06 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 17:41:06 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 17:41:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 17:41:06 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 17:41:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 17:41:06 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 17:41:06 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 17:41:06 --> Final output sent to browser
DEBUG - 2012-07-19 17:41:06 --> Total execution time: 0.0397
DEBUG - 2012-07-19 17:46:43 --> Config Class Initialized
DEBUG - 2012-07-19 17:46:43 --> Hooks Class Initialized
DEBUG - 2012-07-19 17:46:43 --> Utf8 Class Initialized
DEBUG - 2012-07-19 17:46:43 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 17:46:43 --> URI Class Initialized
DEBUG - 2012-07-19 17:46:43 --> Router Class Initialized
DEBUG - 2012-07-19 17:46:43 --> Output Class Initialized
DEBUG - 2012-07-19 17:46:43 --> Security Class Initialized
DEBUG - 2012-07-19 17:46:43 --> Input Class Initialized
DEBUG - 2012-07-19 17:46:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 17:46:43 --> Language Class Initialized
DEBUG - 2012-07-19 17:46:43 --> Loader Class Initialized
DEBUG - 2012-07-19 17:46:43 --> Helper loaded: url_helper
DEBUG - 2012-07-19 17:46:43 --> Controller Class Initialized
DEBUG - 2012-07-19 17:46:43 --> Model Class Initialized
DEBUG - 2012-07-19 17:46:43 --> Database Driver Class Initialized
DEBUG - 2012-07-19 17:46:43 --> Helper loaded: form_helper
DEBUG - 2012-07-19 17:46:43 --> Helper loaded: html_helper
DEBUG - 2012-07-19 17:46:43 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 17:46:43 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 17:46:43 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 17:46:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 17:46:43 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 17:46:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 17:46:43 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 17:46:43 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 17:46:43 --> Final output sent to browser
DEBUG - 2012-07-19 17:46:43 --> Total execution time: 0.0394
DEBUG - 2012-07-19 17:50:45 --> Config Class Initialized
DEBUG - 2012-07-19 17:50:45 --> Hooks Class Initialized
DEBUG - 2012-07-19 17:50:45 --> Utf8 Class Initialized
DEBUG - 2012-07-19 17:50:45 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 17:50:45 --> URI Class Initialized
DEBUG - 2012-07-19 17:50:45 --> Router Class Initialized
DEBUG - 2012-07-19 17:50:45 --> Output Class Initialized
DEBUG - 2012-07-19 17:50:45 --> Security Class Initialized
DEBUG - 2012-07-19 17:50:45 --> Input Class Initialized
DEBUG - 2012-07-19 17:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 17:50:45 --> Language Class Initialized
DEBUG - 2012-07-19 17:50:45 --> Loader Class Initialized
DEBUG - 2012-07-19 17:50:45 --> Helper loaded: url_helper
DEBUG - 2012-07-19 17:50:45 --> Controller Class Initialized
DEBUG - 2012-07-19 17:50:45 --> Model Class Initialized
DEBUG - 2012-07-19 17:50:45 --> Database Driver Class Initialized
DEBUG - 2012-07-19 17:50:45 --> Helper loaded: form_helper
DEBUG - 2012-07-19 17:50:45 --> Helper loaded: html_helper
DEBUG - 2012-07-19 17:50:45 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 17:50:45 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 17:50:45 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 17:50:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 17:50:45 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 17:50:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 17:50:45 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 17:50:45 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 17:50:45 --> Final output sent to browser
DEBUG - 2012-07-19 17:50:45 --> Total execution time: 0.0500
DEBUG - 2012-07-19 17:57:04 --> Config Class Initialized
DEBUG - 2012-07-19 17:57:04 --> Hooks Class Initialized
DEBUG - 2012-07-19 17:57:04 --> Utf8 Class Initialized
DEBUG - 2012-07-19 17:57:04 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 17:57:04 --> URI Class Initialized
DEBUG - 2012-07-19 17:57:04 --> Router Class Initialized
DEBUG - 2012-07-19 17:57:04 --> Output Class Initialized
DEBUG - 2012-07-19 17:57:04 --> Security Class Initialized
DEBUG - 2012-07-19 17:57:04 --> Input Class Initialized
DEBUG - 2012-07-19 17:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 17:57:04 --> Language Class Initialized
DEBUG - 2012-07-19 17:57:04 --> Loader Class Initialized
DEBUG - 2012-07-19 17:57:04 --> Helper loaded: url_helper
DEBUG - 2012-07-19 17:57:04 --> Controller Class Initialized
DEBUG - 2012-07-19 17:57:04 --> Model Class Initialized
DEBUG - 2012-07-19 17:57:04 --> Database Driver Class Initialized
DEBUG - 2012-07-19 17:57:04 --> Helper loaded: form_helper
DEBUG - 2012-07-19 17:57:04 --> Helper loaded: html_helper
DEBUG - 2012-07-19 17:57:04 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 17:57:04 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 17:57:04 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 17:57:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 17:57:04 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 17:57:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 17:57:04 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 17:57:04 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 17:57:04 --> Final output sent to browser
DEBUG - 2012-07-19 17:57:04 --> Total execution time: 0.0411
DEBUG - 2012-07-19 18:03:29 --> Config Class Initialized
DEBUG - 2012-07-19 18:03:29 --> Hooks Class Initialized
DEBUG - 2012-07-19 18:03:29 --> Utf8 Class Initialized
DEBUG - 2012-07-19 18:03:29 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 18:03:29 --> URI Class Initialized
DEBUG - 2012-07-19 18:03:29 --> Router Class Initialized
DEBUG - 2012-07-19 18:03:29 --> Output Class Initialized
DEBUG - 2012-07-19 18:03:29 --> Security Class Initialized
DEBUG - 2012-07-19 18:03:29 --> Input Class Initialized
DEBUG - 2012-07-19 18:03:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 18:03:29 --> Language Class Initialized
DEBUG - 2012-07-19 18:03:29 --> Loader Class Initialized
DEBUG - 2012-07-19 18:03:29 --> Helper loaded: url_helper
DEBUG - 2012-07-19 18:03:29 --> Controller Class Initialized
DEBUG - 2012-07-19 18:03:29 --> Model Class Initialized
DEBUG - 2012-07-19 18:03:29 --> Database Driver Class Initialized
DEBUG - 2012-07-19 18:03:29 --> Helper loaded: form_helper
DEBUG - 2012-07-19 18:03:29 --> Helper loaded: html_helper
DEBUG - 2012-07-19 18:03:29 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 18:03:29 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 18:03:29 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 18:03:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 18:03:29 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 18:03:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 18:03:29 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 18:03:29 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 18:03:29 --> Final output sent to browser
DEBUG - 2012-07-19 18:03:29 --> Total execution time: 0.0400
DEBUG - 2012-07-19 18:05:37 --> Config Class Initialized
DEBUG - 2012-07-19 18:05:37 --> Hooks Class Initialized
DEBUG - 2012-07-19 18:05:37 --> Utf8 Class Initialized
DEBUG - 2012-07-19 18:05:37 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 18:05:37 --> URI Class Initialized
DEBUG - 2012-07-19 18:05:37 --> Router Class Initialized
DEBUG - 2012-07-19 18:05:37 --> Output Class Initialized
DEBUG - 2012-07-19 18:05:37 --> Security Class Initialized
DEBUG - 2012-07-19 18:05:37 --> Input Class Initialized
DEBUG - 2012-07-19 18:05:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 18:05:37 --> Language Class Initialized
DEBUG - 2012-07-19 18:05:37 --> Loader Class Initialized
DEBUG - 2012-07-19 18:05:37 --> Helper loaded: url_helper
DEBUG - 2012-07-19 18:05:37 --> Controller Class Initialized
DEBUG - 2012-07-19 18:05:37 --> Model Class Initialized
DEBUG - 2012-07-19 18:05:37 --> Database Driver Class Initialized
DEBUG - 2012-07-19 18:05:37 --> Helper loaded: form_helper
DEBUG - 2012-07-19 18:05:37 --> Helper loaded: html_helper
DEBUG - 2012-07-19 18:05:37 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 18:05:37 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 18:05:37 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 18:05:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 18:05:37 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 18:05:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 18:05:37 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 18:05:37 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 18:05:37 --> Final output sent to browser
DEBUG - 2012-07-19 18:05:37 --> Total execution time: 0.0408
DEBUG - 2012-07-19 18:14:45 --> Config Class Initialized
DEBUG - 2012-07-19 18:14:45 --> Hooks Class Initialized
DEBUG - 2012-07-19 18:14:45 --> Utf8 Class Initialized
DEBUG - 2012-07-19 18:14:45 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 18:14:45 --> URI Class Initialized
DEBUG - 2012-07-19 18:14:45 --> Router Class Initialized
DEBUG - 2012-07-19 18:14:45 --> Output Class Initialized
DEBUG - 2012-07-19 18:14:45 --> Security Class Initialized
DEBUG - 2012-07-19 18:14:45 --> Input Class Initialized
DEBUG - 2012-07-19 18:14:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 18:14:45 --> Language Class Initialized
DEBUG - 2012-07-19 18:14:45 --> Loader Class Initialized
DEBUG - 2012-07-19 18:14:45 --> Helper loaded: url_helper
DEBUG - 2012-07-19 18:14:45 --> Controller Class Initialized
DEBUG - 2012-07-19 18:14:45 --> Model Class Initialized
DEBUG - 2012-07-19 18:14:45 --> Database Driver Class Initialized
DEBUG - 2012-07-19 18:14:45 --> Helper loaded: form_helper
DEBUG - 2012-07-19 18:14:45 --> Helper loaded: html_helper
DEBUG - 2012-07-19 18:14:45 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 18:14:45 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 18:14:45 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 18:14:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 18:14:45 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 18:14:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 18:14:45 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 18:14:45 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 18:14:45 --> Final output sent to browser
DEBUG - 2012-07-19 18:14:45 --> Total execution time: 0.0489
DEBUG - 2012-07-19 18:15:39 --> Config Class Initialized
DEBUG - 2012-07-19 18:15:39 --> Hooks Class Initialized
DEBUG - 2012-07-19 18:15:39 --> Utf8 Class Initialized
DEBUG - 2012-07-19 18:15:39 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 18:15:39 --> URI Class Initialized
DEBUG - 2012-07-19 18:15:39 --> Router Class Initialized
DEBUG - 2012-07-19 18:15:39 --> Output Class Initialized
DEBUG - 2012-07-19 18:15:39 --> Security Class Initialized
DEBUG - 2012-07-19 18:15:39 --> Input Class Initialized
DEBUG - 2012-07-19 18:15:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 18:15:39 --> Language Class Initialized
DEBUG - 2012-07-19 18:15:39 --> Loader Class Initialized
DEBUG - 2012-07-19 18:15:39 --> Helper loaded: url_helper
DEBUG - 2012-07-19 18:15:39 --> Controller Class Initialized
DEBUG - 2012-07-19 18:15:39 --> Model Class Initialized
DEBUG - 2012-07-19 18:15:39 --> Database Driver Class Initialized
DEBUG - 2012-07-19 18:15:39 --> Helper loaded: form_helper
DEBUG - 2012-07-19 18:15:39 --> Helper loaded: html_helper
DEBUG - 2012-07-19 18:15:39 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 18:15:39 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 18:15:39 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 18:15:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 18:15:39 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 18:15:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 18:15:39 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 18:15:39 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 18:15:39 --> Final output sent to browser
DEBUG - 2012-07-19 18:15:39 --> Total execution time: 0.0397
DEBUG - 2012-07-19 18:16:16 --> Config Class Initialized
DEBUG - 2012-07-19 18:16:16 --> Hooks Class Initialized
DEBUG - 2012-07-19 18:16:16 --> Utf8 Class Initialized
DEBUG - 2012-07-19 18:16:16 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 18:16:16 --> URI Class Initialized
DEBUG - 2012-07-19 18:16:16 --> Router Class Initialized
DEBUG - 2012-07-19 18:16:16 --> Output Class Initialized
DEBUG - 2012-07-19 18:16:16 --> Security Class Initialized
DEBUG - 2012-07-19 18:16:16 --> Input Class Initialized
DEBUG - 2012-07-19 18:16:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 18:16:16 --> Language Class Initialized
DEBUG - 2012-07-19 18:16:16 --> Loader Class Initialized
DEBUG - 2012-07-19 18:16:16 --> Helper loaded: url_helper
DEBUG - 2012-07-19 18:16:16 --> Controller Class Initialized
DEBUG - 2012-07-19 18:16:16 --> Model Class Initialized
DEBUG - 2012-07-19 18:16:16 --> Database Driver Class Initialized
DEBUG - 2012-07-19 18:16:16 --> Helper loaded: form_helper
DEBUG - 2012-07-19 18:16:16 --> Helper loaded: html_helper
DEBUG - 2012-07-19 18:16:16 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 18:16:16 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 18:16:16 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 18:16:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 18:16:16 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 18:16:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 18:16:16 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 18:16:16 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 18:16:16 --> Final output sent to browser
DEBUG - 2012-07-19 18:16:16 --> Total execution time: 0.0399
DEBUG - 2012-07-19 18:19:51 --> Config Class Initialized
DEBUG - 2012-07-19 18:19:51 --> Hooks Class Initialized
DEBUG - 2012-07-19 18:19:51 --> Utf8 Class Initialized
DEBUG - 2012-07-19 18:19:51 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 18:19:51 --> URI Class Initialized
DEBUG - 2012-07-19 18:19:51 --> Router Class Initialized
DEBUG - 2012-07-19 18:19:51 --> Output Class Initialized
DEBUG - 2012-07-19 18:19:51 --> Security Class Initialized
DEBUG - 2012-07-19 18:19:51 --> Input Class Initialized
DEBUG - 2012-07-19 18:19:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 18:19:51 --> Language Class Initialized
DEBUG - 2012-07-19 18:19:51 --> Loader Class Initialized
DEBUG - 2012-07-19 18:19:51 --> Helper loaded: url_helper
DEBUG - 2012-07-19 18:19:51 --> Controller Class Initialized
DEBUG - 2012-07-19 18:19:51 --> Model Class Initialized
DEBUG - 2012-07-19 18:19:51 --> Database Driver Class Initialized
DEBUG - 2012-07-19 18:19:51 --> Helper loaded: form_helper
DEBUG - 2012-07-19 18:19:51 --> Helper loaded: html_helper
DEBUG - 2012-07-19 18:19:51 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 18:19:51 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 18:19:51 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 18:19:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 18:19:51 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 18:19:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 18:19:51 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 18:19:51 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 18:19:51 --> Final output sent to browser
DEBUG - 2012-07-19 18:19:51 --> Total execution time: 0.0500
DEBUG - 2012-07-19 18:24:32 --> Config Class Initialized
DEBUG - 2012-07-19 18:24:32 --> Hooks Class Initialized
DEBUG - 2012-07-19 18:24:32 --> Utf8 Class Initialized
DEBUG - 2012-07-19 18:24:32 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 18:24:32 --> URI Class Initialized
DEBUG - 2012-07-19 18:24:32 --> Router Class Initialized
DEBUG - 2012-07-19 18:24:32 --> Output Class Initialized
DEBUG - 2012-07-19 18:24:32 --> Security Class Initialized
DEBUG - 2012-07-19 18:24:32 --> Input Class Initialized
DEBUG - 2012-07-19 18:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 18:24:32 --> Language Class Initialized
DEBUG - 2012-07-19 18:24:32 --> Loader Class Initialized
DEBUG - 2012-07-19 18:24:32 --> Helper loaded: url_helper
DEBUG - 2012-07-19 18:24:32 --> Controller Class Initialized
DEBUG - 2012-07-19 18:24:32 --> Model Class Initialized
DEBUG - 2012-07-19 18:24:32 --> Database Driver Class Initialized
DEBUG - 2012-07-19 18:24:32 --> Helper loaded: form_helper
DEBUG - 2012-07-19 18:24:32 --> Helper loaded: html_helper
DEBUG - 2012-07-19 18:24:32 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 18:24:32 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 18:24:32 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 18:24:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 18:24:32 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 18:24:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 18:24:32 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 18:24:32 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 18:24:32 --> Final output sent to browser
DEBUG - 2012-07-19 18:24:32 --> Total execution time: 0.0399
DEBUG - 2012-07-19 18:25:59 --> Config Class Initialized
DEBUG - 2012-07-19 18:25:59 --> Hooks Class Initialized
DEBUG - 2012-07-19 18:25:59 --> Utf8 Class Initialized
DEBUG - 2012-07-19 18:25:59 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 18:25:59 --> URI Class Initialized
DEBUG - 2012-07-19 18:25:59 --> Router Class Initialized
DEBUG - 2012-07-19 18:25:59 --> Output Class Initialized
DEBUG - 2012-07-19 18:25:59 --> Security Class Initialized
DEBUG - 2012-07-19 18:25:59 --> Input Class Initialized
DEBUG - 2012-07-19 18:25:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 18:25:59 --> Language Class Initialized
DEBUG - 2012-07-19 18:25:59 --> Loader Class Initialized
DEBUG - 2012-07-19 18:25:59 --> Helper loaded: url_helper
DEBUG - 2012-07-19 18:25:59 --> Controller Class Initialized
DEBUG - 2012-07-19 18:25:59 --> Model Class Initialized
DEBUG - 2012-07-19 18:25:59 --> Database Driver Class Initialized
DEBUG - 2012-07-19 18:25:59 --> Helper loaded: form_helper
DEBUG - 2012-07-19 18:25:59 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-19 18:25:59 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-19 18:25:59 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-19 18:25:59 --> File loaded: application/views/admin/pages/account.php
DEBUG - 2012-07-19 18:25:59 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-19 18:25:59 --> Final output sent to browser
DEBUG - 2012-07-19 18:25:59 --> Total execution time: 0.0547
DEBUG - 2012-07-19 18:26:05 --> Config Class Initialized
DEBUG - 2012-07-19 18:26:05 --> Hooks Class Initialized
DEBUG - 2012-07-19 18:26:05 --> Utf8 Class Initialized
DEBUG - 2012-07-19 18:26:05 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 18:26:05 --> URI Class Initialized
DEBUG - 2012-07-19 18:26:05 --> Router Class Initialized
DEBUG - 2012-07-19 18:26:05 --> Output Class Initialized
DEBUG - 2012-07-19 18:26:05 --> Security Class Initialized
DEBUG - 2012-07-19 18:26:05 --> Input Class Initialized
DEBUG - 2012-07-19 18:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 18:26:05 --> Language Class Initialized
DEBUG - 2012-07-19 18:26:05 --> Loader Class Initialized
DEBUG - 2012-07-19 18:26:05 --> Helper loaded: url_helper
DEBUG - 2012-07-19 18:26:05 --> Controller Class Initialized
DEBUG - 2012-07-19 18:26:05 --> Model Class Initialized
DEBUG - 2012-07-19 18:26:05 --> Database Driver Class Initialized
DEBUG - 2012-07-19 18:26:05 --> Helper loaded: form_helper
DEBUG - 2012-07-19 18:26:05 --> Helper loaded: html_helper
DEBUG - 2012-07-19 18:26:05 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 18:26:05 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 18:26:05 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 18:26:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 18:26:05 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 18:26:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 18:26:05 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 18:26:05 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 18:26:05 --> Final output sent to browser
DEBUG - 2012-07-19 18:26:05 --> Total execution time: 0.0413
DEBUG - 2012-07-19 19:13:26 --> Config Class Initialized
DEBUG - 2012-07-19 19:13:26 --> Hooks Class Initialized
DEBUG - 2012-07-19 19:13:26 --> Utf8 Class Initialized
DEBUG - 2012-07-19 19:13:26 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 19:13:26 --> URI Class Initialized
DEBUG - 2012-07-19 19:13:26 --> Router Class Initialized
DEBUG - 2012-07-19 19:13:26 --> Output Class Initialized
DEBUG - 2012-07-19 19:13:26 --> Security Class Initialized
DEBUG - 2012-07-19 19:13:26 --> Input Class Initialized
DEBUG - 2012-07-19 19:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 19:13:26 --> Language Class Initialized
DEBUG - 2012-07-19 19:13:26 --> Loader Class Initialized
DEBUG - 2012-07-19 19:13:26 --> Helper loaded: url_helper
DEBUG - 2012-07-19 19:13:26 --> Controller Class Initialized
DEBUG - 2012-07-19 19:13:26 --> Model Class Initialized
DEBUG - 2012-07-19 19:13:26 --> Database Driver Class Initialized
DEBUG - 2012-07-19 19:13:26 --> Helper loaded: form_helper
DEBUG - 2012-07-19 19:13:26 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-19 19:13:26 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-19 19:13:26 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-19 19:13:26 --> File loaded: application/views/admin/pages/account.php
DEBUG - 2012-07-19 19:13:26 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-19 19:13:26 --> Final output sent to browser
DEBUG - 2012-07-19 19:13:26 --> Total execution time: 0.0391
DEBUG - 2012-07-19 19:13:45 --> Config Class Initialized
DEBUG - 2012-07-19 19:13:45 --> Hooks Class Initialized
DEBUG - 2012-07-19 19:13:45 --> Utf8 Class Initialized
DEBUG - 2012-07-19 19:13:45 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 19:13:45 --> URI Class Initialized
DEBUG - 2012-07-19 19:13:45 --> Router Class Initialized
DEBUG - 2012-07-19 19:13:45 --> Output Class Initialized
DEBUG - 2012-07-19 19:13:45 --> Security Class Initialized
DEBUG - 2012-07-19 19:13:45 --> Input Class Initialized
DEBUG - 2012-07-19 19:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 19:13:45 --> Language Class Initialized
DEBUG - 2012-07-19 19:13:45 --> Loader Class Initialized
DEBUG - 2012-07-19 19:13:45 --> Helper loaded: url_helper
DEBUG - 2012-07-19 19:13:45 --> Controller Class Initialized
DEBUG - 2012-07-19 19:13:45 --> Model Class Initialized
DEBUG - 2012-07-19 19:13:45 --> Database Driver Class Initialized
ERROR - 2012-07-19 19:13:45 --> 404 Page Not Found --> business/ajax_account_name
DEBUG - 2012-07-19 19:36:48 --> Config Class Initialized
DEBUG - 2012-07-19 19:36:48 --> Hooks Class Initialized
DEBUG - 2012-07-19 19:36:48 --> Utf8 Class Initialized
DEBUG - 2012-07-19 19:36:48 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 19:36:48 --> URI Class Initialized
DEBUG - 2012-07-19 19:36:48 --> Router Class Initialized
DEBUG - 2012-07-19 19:36:48 --> Output Class Initialized
DEBUG - 2012-07-19 19:36:49 --> Security Class Initialized
DEBUG - 2012-07-19 19:36:49 --> Input Class Initialized
DEBUG - 2012-07-19 19:36:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 19:36:49 --> Language Class Initialized
DEBUG - 2012-07-19 19:36:49 --> Loader Class Initialized
DEBUG - 2012-07-19 19:36:49 --> Helper loaded: url_helper
DEBUG - 2012-07-19 19:36:49 --> Controller Class Initialized
DEBUG - 2012-07-19 19:36:49 --> Model Class Initialized
DEBUG - 2012-07-19 19:36:49 --> Database Driver Class Initialized
DEBUG - 2012-07-19 19:37:48 --> Config Class Initialized
DEBUG - 2012-07-19 19:37:48 --> Hooks Class Initialized
DEBUG - 2012-07-19 19:37:49 --> Utf8 Class Initialized
DEBUG - 2012-07-19 19:37:49 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 19:37:49 --> URI Class Initialized
DEBUG - 2012-07-19 19:37:49 --> Router Class Initialized
DEBUG - 2012-07-19 19:37:49 --> Output Class Initialized
DEBUG - 2012-07-19 19:37:49 --> Security Class Initialized
DEBUG - 2012-07-19 19:37:49 --> Input Class Initialized
DEBUG - 2012-07-19 19:37:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 19:37:49 --> Language Class Initialized
DEBUG - 2012-07-19 19:37:49 --> Loader Class Initialized
DEBUG - 2012-07-19 19:37:49 --> Helper loaded: url_helper
DEBUG - 2012-07-19 19:37:49 --> Controller Class Initialized
DEBUG - 2012-07-19 19:37:49 --> Model Class Initialized
DEBUG - 2012-07-19 19:37:49 --> Database Driver Class Initialized
DEBUG - 2012-07-19 19:37:49 --> Helper loaded: form_helper
DEBUG - 2012-07-19 19:37:49 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-19 19:37:49 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-19 19:37:49 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-19 19:37:49 --> File loaded: application/views/admin/pages/account.php
DEBUG - 2012-07-19 19:37:49 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-19 19:37:49 --> Final output sent to browser
DEBUG - 2012-07-19 19:37:49 --> Total execution time: 0.0392
DEBUG - 2012-07-19 19:39:54 --> Config Class Initialized
DEBUG - 2012-07-19 19:39:54 --> Hooks Class Initialized
DEBUG - 2012-07-19 19:39:54 --> Utf8 Class Initialized
DEBUG - 2012-07-19 19:39:54 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 19:39:54 --> URI Class Initialized
DEBUG - 2012-07-19 19:39:54 --> Router Class Initialized
DEBUG - 2012-07-19 19:39:54 --> Output Class Initialized
DEBUG - 2012-07-19 19:39:54 --> Security Class Initialized
DEBUG - 2012-07-19 19:39:54 --> Input Class Initialized
DEBUG - 2012-07-19 19:39:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 19:39:54 --> Language Class Initialized
DEBUG - 2012-07-19 19:39:54 --> Loader Class Initialized
DEBUG - 2012-07-19 19:39:54 --> Helper loaded: url_helper
DEBUG - 2012-07-19 19:39:54 --> Controller Class Initialized
DEBUG - 2012-07-19 19:39:54 --> Model Class Initialized
DEBUG - 2012-07-19 19:39:54 --> Database Driver Class Initialized
DEBUG - 2012-07-19 19:40:54 --> Config Class Initialized
DEBUG - 2012-07-19 19:40:54 --> Hooks Class Initialized
DEBUG - 2012-07-19 19:40:54 --> Utf8 Class Initialized
DEBUG - 2012-07-19 19:40:54 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 19:40:54 --> URI Class Initialized
DEBUG - 2012-07-19 19:40:54 --> Router Class Initialized
DEBUG - 2012-07-19 19:40:54 --> Output Class Initialized
DEBUG - 2012-07-19 19:40:54 --> Security Class Initialized
DEBUG - 2012-07-19 19:40:54 --> Input Class Initialized
DEBUG - 2012-07-19 19:40:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 19:40:54 --> Language Class Initialized
DEBUG - 2012-07-19 19:40:54 --> Loader Class Initialized
DEBUG - 2012-07-19 19:40:54 --> Helper loaded: url_helper
DEBUG - 2012-07-19 19:40:54 --> Controller Class Initialized
DEBUG - 2012-07-19 19:40:54 --> Model Class Initialized
DEBUG - 2012-07-19 19:40:54 --> Database Driver Class Initialized
DEBUG - 2012-07-19 19:40:54 --> Helper loaded: form_helper
DEBUG - 2012-07-19 19:40:54 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-19 19:40:54 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-19 19:40:54 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-19 19:40:54 --> File loaded: application/views/admin/pages/account.php
DEBUG - 2012-07-19 19:40:54 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-19 19:40:54 --> Final output sent to browser
DEBUG - 2012-07-19 19:40:54 --> Total execution time: 0.0446
DEBUG - 2012-07-19 19:43:45 --> Config Class Initialized
DEBUG - 2012-07-19 19:43:45 --> Hooks Class Initialized
DEBUG - 2012-07-19 19:43:45 --> Utf8 Class Initialized
DEBUG - 2012-07-19 19:43:45 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 19:43:45 --> URI Class Initialized
DEBUG - 2012-07-19 19:43:45 --> Router Class Initialized
DEBUG - 2012-07-19 19:43:45 --> Output Class Initialized
DEBUG - 2012-07-19 19:43:45 --> Security Class Initialized
DEBUG - 2012-07-19 19:43:45 --> Input Class Initialized
DEBUG - 2012-07-19 19:43:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 19:43:45 --> Language Class Initialized
DEBUG - 2012-07-19 19:43:45 --> Loader Class Initialized
DEBUG - 2012-07-19 19:43:45 --> Helper loaded: url_helper
DEBUG - 2012-07-19 19:43:45 --> Controller Class Initialized
DEBUG - 2012-07-19 19:43:45 --> Model Class Initialized
DEBUG - 2012-07-19 19:43:45 --> Database Driver Class Initialized
DEBUG - 2012-07-19 19:43:45 --> Helper loaded: form_helper
DEBUG - 2012-07-19 19:43:45 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-19 19:43:45 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-19 19:43:45 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-19 19:43:45 --> File loaded: application/views/admin/pages/account.php
DEBUG - 2012-07-19 19:43:45 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-19 19:43:45 --> Final output sent to browser
DEBUG - 2012-07-19 19:43:45 --> Total execution time: 0.0401
DEBUG - 2012-07-19 19:43:59 --> Config Class Initialized
DEBUG - 2012-07-19 19:43:59 --> Hooks Class Initialized
DEBUG - 2012-07-19 19:43:59 --> Utf8 Class Initialized
DEBUG - 2012-07-19 19:43:59 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 19:43:59 --> URI Class Initialized
DEBUG - 2012-07-19 19:43:59 --> Router Class Initialized
DEBUG - 2012-07-19 19:43:59 --> Output Class Initialized
DEBUG - 2012-07-19 19:43:59 --> Security Class Initialized
DEBUG - 2012-07-19 19:43:59 --> Input Class Initialized
DEBUG - 2012-07-19 19:43:59 --> XSS Filtering completed
DEBUG - 2012-07-19 19:43:59 --> XSS Filtering completed
DEBUG - 2012-07-19 19:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 19:43:59 --> Language Class Initialized
DEBUG - 2012-07-19 19:43:59 --> Loader Class Initialized
DEBUG - 2012-07-19 19:43:59 --> Helper loaded: url_helper
DEBUG - 2012-07-19 19:43:59 --> Controller Class Initialized
DEBUG - 2012-07-19 19:43:59 --> Model Class Initialized
DEBUG - 2012-07-19 19:43:59 --> Database Driver Class Initialized
DEBUG - 2012-07-19 19:43:59 --> Helper loaded: form_helper
DEBUG - 2012-07-19 19:43:59 --> Form Validation Class Initialized
DEBUG - 2012-07-19 19:43:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-19 19:43:59 --> Final output sent to browser
DEBUG - 2012-07-19 19:43:59 --> Total execution time: 0.1062
DEBUG - 2012-07-19 19:45:43 --> Config Class Initialized
DEBUG - 2012-07-19 19:45:43 --> Hooks Class Initialized
DEBUG - 2012-07-19 19:45:43 --> Utf8 Class Initialized
DEBUG - 2012-07-19 19:45:43 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 19:45:43 --> URI Class Initialized
DEBUG - 2012-07-19 19:45:43 --> Router Class Initialized
DEBUG - 2012-07-19 19:45:43 --> Output Class Initialized
DEBUG - 2012-07-19 19:45:43 --> Security Class Initialized
DEBUG - 2012-07-19 19:45:43 --> Input Class Initialized
DEBUG - 2012-07-19 19:45:43 --> XSS Filtering completed
DEBUG - 2012-07-19 19:45:43 --> XSS Filtering completed
DEBUG - 2012-07-19 19:45:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 19:45:43 --> Language Class Initialized
DEBUG - 2012-07-19 19:45:43 --> Loader Class Initialized
DEBUG - 2012-07-19 19:45:43 --> Helper loaded: url_helper
DEBUG - 2012-07-19 19:45:43 --> Controller Class Initialized
DEBUG - 2012-07-19 19:45:43 --> Model Class Initialized
DEBUG - 2012-07-19 19:45:43 --> Database Driver Class Initialized
DEBUG - 2012-07-19 19:45:43 --> Helper loaded: form_helper
DEBUG - 2012-07-19 19:45:43 --> Form Validation Class Initialized
DEBUG - 2012-07-19 19:45:43 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2012-07-19 19:45:43 --> Severity: Notice  --> Undefined property: Business::$_get_site_owner_id /home/jwp/www/justinwylliephotography.com/clients/system/core/Model.php 51
DEBUG - 2012-07-19 19:45:43 --> Final output sent to browser
DEBUG - 2012-07-19 19:45:43 --> Total execution time: 0.0727
DEBUG - 2012-07-19 19:45:55 --> Config Class Initialized
DEBUG - 2012-07-19 19:45:55 --> Hooks Class Initialized
DEBUG - 2012-07-19 19:45:55 --> Utf8 Class Initialized
DEBUG - 2012-07-19 19:45:55 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 19:45:55 --> URI Class Initialized
DEBUG - 2012-07-19 19:45:55 --> Router Class Initialized
DEBUG - 2012-07-19 19:45:55 --> Output Class Initialized
DEBUG - 2012-07-19 19:45:55 --> Security Class Initialized
DEBUG - 2012-07-19 19:45:55 --> Input Class Initialized
DEBUG - 2012-07-19 19:45:55 --> XSS Filtering completed
DEBUG - 2012-07-19 19:45:55 --> XSS Filtering completed
DEBUG - 2012-07-19 19:45:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 19:45:55 --> Language Class Initialized
DEBUG - 2012-07-19 19:45:55 --> Loader Class Initialized
DEBUG - 2012-07-19 19:45:55 --> Helper loaded: url_helper
DEBUG - 2012-07-19 19:45:55 --> Controller Class Initialized
DEBUG - 2012-07-19 19:45:55 --> Model Class Initialized
DEBUG - 2012-07-19 19:45:55 --> Database Driver Class Initialized
DEBUG - 2012-07-19 19:45:55 --> Helper loaded: form_helper
DEBUG - 2012-07-19 19:45:55 --> Form Validation Class Initialized
DEBUG - 2012-07-19 19:45:55 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2012-07-19 19:45:55 --> Severity: Notice  --> Undefined property: Business::$_get_site_owner_id /home/jwp/www/justinwylliephotography.com/clients/system/core/Model.php 51
DEBUG - 2012-07-19 19:45:55 --> Final output sent to browser
DEBUG - 2012-07-19 19:45:55 --> Total execution time: 0.0390
DEBUG - 2012-07-19 19:46:58 --> Config Class Initialized
DEBUG - 2012-07-19 19:46:58 --> Hooks Class Initialized
DEBUG - 2012-07-19 19:46:58 --> Utf8 Class Initialized
DEBUG - 2012-07-19 19:46:58 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 19:46:58 --> URI Class Initialized
DEBUG - 2012-07-19 19:46:58 --> Router Class Initialized
DEBUG - 2012-07-19 19:46:58 --> Output Class Initialized
DEBUG - 2012-07-19 19:46:58 --> Security Class Initialized
DEBUG - 2012-07-19 19:46:58 --> Input Class Initialized
DEBUG - 2012-07-19 19:46:58 --> XSS Filtering completed
DEBUG - 2012-07-19 19:46:58 --> XSS Filtering completed
DEBUG - 2012-07-19 19:46:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 19:46:58 --> Language Class Initialized
DEBUG - 2012-07-19 19:46:58 --> Loader Class Initialized
DEBUG - 2012-07-19 19:46:58 --> Helper loaded: url_helper
DEBUG - 2012-07-19 19:46:58 --> Controller Class Initialized
DEBUG - 2012-07-19 19:46:58 --> Model Class Initialized
DEBUG - 2012-07-19 19:46:58 --> Database Driver Class Initialized
DEBUG - 2012-07-19 19:46:58 --> Helper loaded: form_helper
DEBUG - 2012-07-19 19:46:58 --> Form Validation Class Initialized
DEBUG - 2012-07-19 19:46:58 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2012-07-19 19:46:58 --> Severity: Notice  --> Undefined property: Business::$_get_site_owner_id /home/jwp/www/justinwylliephotography.com/clients/system/core/Model.php 51
DEBUG - 2012-07-19 19:51:17 --> Config Class Initialized
DEBUG - 2012-07-19 19:51:17 --> Hooks Class Initialized
DEBUG - 2012-07-19 19:51:17 --> Utf8 Class Initialized
DEBUG - 2012-07-19 19:51:17 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 19:51:17 --> URI Class Initialized
DEBUG - 2012-07-19 19:51:17 --> Router Class Initialized
DEBUG - 2012-07-19 19:51:17 --> Output Class Initialized
DEBUG - 2012-07-19 19:51:17 --> Security Class Initialized
DEBUG - 2012-07-19 19:51:17 --> Input Class Initialized
DEBUG - 2012-07-19 19:51:17 --> XSS Filtering completed
DEBUG - 2012-07-19 19:51:17 --> XSS Filtering completed
DEBUG - 2012-07-19 19:51:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 19:51:17 --> Language Class Initialized
DEBUG - 2012-07-19 19:51:17 --> Loader Class Initialized
DEBUG - 2012-07-19 19:51:17 --> Helper loaded: url_helper
DEBUG - 2012-07-19 19:51:17 --> Controller Class Initialized
DEBUG - 2012-07-19 19:51:17 --> Model Class Initialized
DEBUG - 2012-07-19 19:51:17 --> Database Driver Class Initialized
DEBUG - 2012-07-19 19:51:17 --> Helper loaded: form_helper
DEBUG - 2012-07-19 19:51:17 --> Form Validation Class Initialized
DEBUG - 2012-07-19 19:51:17 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-19 19:51:17 --> Final output sent to browser
DEBUG - 2012-07-19 19:51:17 --> Total execution time: 0.0964
DEBUG - 2012-07-19 19:51:21 --> Config Class Initialized
DEBUG - 2012-07-19 19:51:21 --> Hooks Class Initialized
DEBUG - 2012-07-19 19:51:21 --> Utf8 Class Initialized
DEBUG - 2012-07-19 19:51:21 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 19:51:21 --> URI Class Initialized
DEBUG - 2012-07-19 19:51:21 --> Router Class Initialized
DEBUG - 2012-07-19 19:51:21 --> Output Class Initialized
DEBUG - 2012-07-19 19:51:21 --> Security Class Initialized
DEBUG - 2012-07-19 19:51:21 --> Input Class Initialized
DEBUG - 2012-07-19 19:51:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 19:51:21 --> Language Class Initialized
DEBUG - 2012-07-19 19:51:21 --> Loader Class Initialized
DEBUG - 2012-07-19 19:51:21 --> Helper loaded: url_helper
DEBUG - 2012-07-19 19:51:21 --> Controller Class Initialized
DEBUG - 2012-07-19 19:51:21 --> Model Class Initialized
DEBUG - 2012-07-19 19:51:21 --> Database Driver Class Initialized
DEBUG - 2012-07-19 19:51:21 --> Helper loaded: form_helper
DEBUG - 2012-07-19 19:51:21 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-19 19:51:21 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-19 19:51:21 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-19 19:51:21 --> File loaded: application/views/admin/pages/account.php
DEBUG - 2012-07-19 19:51:21 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-19 19:51:21 --> Final output sent to browser
DEBUG - 2012-07-19 19:51:21 --> Total execution time: 0.0412
DEBUG - 2012-07-19 19:54:50 --> Config Class Initialized
DEBUG - 2012-07-19 19:54:50 --> Hooks Class Initialized
DEBUG - 2012-07-19 19:54:50 --> Utf8 Class Initialized
DEBUG - 2012-07-19 19:54:50 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 19:54:50 --> URI Class Initialized
DEBUG - 2012-07-19 19:54:50 --> Router Class Initialized
DEBUG - 2012-07-19 19:54:50 --> Output Class Initialized
DEBUG - 2012-07-19 19:54:50 --> Security Class Initialized
DEBUG - 2012-07-19 19:54:50 --> Input Class Initialized
DEBUG - 2012-07-19 19:54:50 --> XSS Filtering completed
DEBUG - 2012-07-19 19:54:50 --> XSS Filtering completed
DEBUG - 2012-07-19 19:54:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 19:54:50 --> Language Class Initialized
DEBUG - 2012-07-19 19:54:50 --> Loader Class Initialized
DEBUG - 2012-07-19 19:54:50 --> Helper loaded: url_helper
DEBUG - 2012-07-19 19:54:50 --> Controller Class Initialized
DEBUG - 2012-07-19 19:54:50 --> Model Class Initialized
DEBUG - 2012-07-19 19:54:50 --> Database Driver Class Initialized
DEBUG - 2012-07-19 19:54:50 --> Helper loaded: form_helper
DEBUG - 2012-07-19 19:54:50 --> Form Validation Class Initialized
DEBUG - 2012-07-19 19:54:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-19 19:54:50 --> Final output sent to browser
DEBUG - 2012-07-19 19:54:50 --> Total execution time: 0.0389
DEBUG - 2012-07-19 19:55:10 --> Config Class Initialized
DEBUG - 2012-07-19 19:55:10 --> Hooks Class Initialized
DEBUG - 2012-07-19 19:55:10 --> Utf8 Class Initialized
DEBUG - 2012-07-19 19:55:10 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 19:55:10 --> URI Class Initialized
DEBUG - 2012-07-19 19:55:10 --> Router Class Initialized
DEBUG - 2012-07-19 19:55:10 --> Output Class Initialized
DEBUG - 2012-07-19 19:55:10 --> Security Class Initialized
DEBUG - 2012-07-19 19:55:10 --> Input Class Initialized
DEBUG - 2012-07-19 19:55:10 --> XSS Filtering completed
DEBUG - 2012-07-19 19:55:10 --> XSS Filtering completed
DEBUG - 2012-07-19 19:55:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 19:55:10 --> Language Class Initialized
DEBUG - 2012-07-19 19:55:10 --> Loader Class Initialized
DEBUG - 2012-07-19 19:55:10 --> Helper loaded: url_helper
DEBUG - 2012-07-19 19:55:10 --> Controller Class Initialized
DEBUG - 2012-07-19 19:55:10 --> Model Class Initialized
DEBUG - 2012-07-19 19:55:10 --> Database Driver Class Initialized
DEBUG - 2012-07-19 19:55:10 --> Helper loaded: form_helper
DEBUG - 2012-07-19 19:55:10 --> Form Validation Class Initialized
DEBUG - 2012-07-19 19:55:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-19 19:55:10 --> Final output sent to browser
DEBUG - 2012-07-19 19:55:10 --> Total execution time: 0.0380
DEBUG - 2012-07-19 19:55:18 --> Config Class Initialized
DEBUG - 2012-07-19 19:55:18 --> Hooks Class Initialized
DEBUG - 2012-07-19 19:55:18 --> Utf8 Class Initialized
DEBUG - 2012-07-19 19:55:18 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 19:55:18 --> URI Class Initialized
DEBUG - 2012-07-19 19:55:18 --> Router Class Initialized
DEBUG - 2012-07-19 19:55:18 --> Output Class Initialized
DEBUG - 2012-07-19 19:55:18 --> Security Class Initialized
DEBUG - 2012-07-19 19:55:18 --> Input Class Initialized
DEBUG - 2012-07-19 19:55:18 --> XSS Filtering completed
DEBUG - 2012-07-19 19:55:18 --> XSS Filtering completed
DEBUG - 2012-07-19 19:55:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 19:55:18 --> Language Class Initialized
DEBUG - 2012-07-19 19:55:18 --> Loader Class Initialized
DEBUG - 2012-07-19 19:55:18 --> Helper loaded: url_helper
DEBUG - 2012-07-19 19:55:18 --> Controller Class Initialized
DEBUG - 2012-07-19 19:55:18 --> Model Class Initialized
DEBUG - 2012-07-19 19:55:18 --> Database Driver Class Initialized
DEBUG - 2012-07-19 19:55:18 --> Helper loaded: form_helper
DEBUG - 2012-07-19 19:55:18 --> Form Validation Class Initialized
DEBUG - 2012-07-19 19:55:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-19 19:55:18 --> Final output sent to browser
DEBUG - 2012-07-19 19:55:18 --> Total execution time: 0.0423
DEBUG - 2012-07-19 19:55:24 --> Config Class Initialized
DEBUG - 2012-07-19 19:55:24 --> Hooks Class Initialized
DEBUG - 2012-07-19 19:55:24 --> Utf8 Class Initialized
DEBUG - 2012-07-19 19:55:24 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 19:55:24 --> URI Class Initialized
DEBUG - 2012-07-19 19:55:24 --> Router Class Initialized
DEBUG - 2012-07-19 19:55:24 --> Output Class Initialized
DEBUG - 2012-07-19 19:55:24 --> Security Class Initialized
DEBUG - 2012-07-19 19:55:24 --> Input Class Initialized
DEBUG - 2012-07-19 19:55:24 --> XSS Filtering completed
DEBUG - 2012-07-19 19:55:24 --> XSS Filtering completed
DEBUG - 2012-07-19 19:55:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 19:55:24 --> Language Class Initialized
DEBUG - 2012-07-19 19:55:24 --> Loader Class Initialized
DEBUG - 2012-07-19 19:55:24 --> Helper loaded: url_helper
DEBUG - 2012-07-19 19:55:24 --> Controller Class Initialized
DEBUG - 2012-07-19 19:55:24 --> Model Class Initialized
DEBUG - 2012-07-19 19:55:24 --> Database Driver Class Initialized
DEBUG - 2012-07-19 19:55:24 --> Helper loaded: form_helper
DEBUG - 2012-07-19 19:55:24 --> Form Validation Class Initialized
DEBUG - 2012-07-19 19:55:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-19 19:55:24 --> Final output sent to browser
DEBUG - 2012-07-19 19:55:24 --> Total execution time: 0.0448
DEBUG - 2012-07-19 19:55:32 --> Config Class Initialized
DEBUG - 2012-07-19 19:55:32 --> Hooks Class Initialized
DEBUG - 2012-07-19 19:55:32 --> Utf8 Class Initialized
DEBUG - 2012-07-19 19:55:32 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 19:55:32 --> URI Class Initialized
DEBUG - 2012-07-19 19:55:32 --> Router Class Initialized
DEBUG - 2012-07-19 19:55:32 --> Output Class Initialized
DEBUG - 2012-07-19 19:55:32 --> Security Class Initialized
DEBUG - 2012-07-19 19:55:32 --> Input Class Initialized
DEBUG - 2012-07-19 19:55:32 --> XSS Filtering completed
DEBUG - 2012-07-19 19:55:32 --> XSS Filtering completed
DEBUG - 2012-07-19 19:55:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 19:55:32 --> Language Class Initialized
DEBUG - 2012-07-19 19:55:32 --> Loader Class Initialized
DEBUG - 2012-07-19 19:55:32 --> Helper loaded: url_helper
DEBUG - 2012-07-19 19:55:32 --> Controller Class Initialized
DEBUG - 2012-07-19 19:55:32 --> Model Class Initialized
DEBUG - 2012-07-19 19:55:32 --> Database Driver Class Initialized
DEBUG - 2012-07-19 19:55:32 --> Helper loaded: form_helper
DEBUG - 2012-07-19 19:55:32 --> Form Validation Class Initialized
DEBUG - 2012-07-19 19:55:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-19 19:55:32 --> Final output sent to browser
DEBUG - 2012-07-19 19:55:32 --> Total execution time: 0.1252
DEBUG - 2012-07-19 19:55:53 --> Config Class Initialized
DEBUG - 2012-07-19 19:55:53 --> Hooks Class Initialized
DEBUG - 2012-07-19 19:55:53 --> Utf8 Class Initialized
DEBUG - 2012-07-19 19:55:53 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 19:55:53 --> URI Class Initialized
DEBUG - 2012-07-19 19:55:53 --> Router Class Initialized
DEBUG - 2012-07-19 19:55:53 --> Output Class Initialized
DEBUG - 2012-07-19 19:55:53 --> Security Class Initialized
DEBUG - 2012-07-19 19:55:53 --> Input Class Initialized
DEBUG - 2012-07-19 19:55:53 --> XSS Filtering completed
DEBUG - 2012-07-19 19:55:53 --> XSS Filtering completed
DEBUG - 2012-07-19 19:55:53 --> XSS Filtering completed
DEBUG - 2012-07-19 19:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 19:55:53 --> Language Class Initialized
DEBUG - 2012-07-19 19:55:53 --> Loader Class Initialized
DEBUG - 2012-07-19 19:55:53 --> Helper loaded: url_helper
DEBUG - 2012-07-19 19:55:53 --> Controller Class Initialized
DEBUG - 2012-07-19 19:55:53 --> Model Class Initialized
DEBUG - 2012-07-19 19:55:53 --> Database Driver Class Initialized
ERROR - 2012-07-19 19:55:53 --> 404 Page Not Found --> business/ajax_account_password
DEBUG - 2012-07-19 20:12:11 --> Config Class Initialized
DEBUG - 2012-07-19 20:12:11 --> Hooks Class Initialized
DEBUG - 2012-07-19 20:12:11 --> Utf8 Class Initialized
DEBUG - 2012-07-19 20:12:11 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 20:12:11 --> URI Class Initialized
DEBUG - 2012-07-19 20:12:11 --> Router Class Initialized
DEBUG - 2012-07-19 20:12:11 --> Output Class Initialized
DEBUG - 2012-07-19 20:12:11 --> Security Class Initialized
DEBUG - 2012-07-19 20:12:11 --> Input Class Initialized
DEBUG - 2012-07-19 20:12:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 20:12:11 --> Language Class Initialized
DEBUG - 2012-07-19 20:12:11 --> Loader Class Initialized
DEBUG - 2012-07-19 20:12:11 --> Helper loaded: url_helper
DEBUG - 2012-07-19 20:12:11 --> Controller Class Initialized
DEBUG - 2012-07-19 20:12:11 --> Model Class Initialized
DEBUG - 2012-07-19 20:12:11 --> Database Driver Class Initialized
DEBUG - 2012-07-19 20:12:11 --> Helper loaded: form_helper
DEBUG - 2012-07-19 20:12:11 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-19 20:12:11 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-19 20:12:11 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-19 20:12:11 --> File loaded: application/views/admin/pages/account.php
DEBUG - 2012-07-19 20:12:11 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-19 20:12:11 --> Final output sent to browser
DEBUG - 2012-07-19 20:12:11 --> Total execution time: 0.0394
DEBUG - 2012-07-19 20:16:51 --> Config Class Initialized
DEBUG - 2012-07-19 20:16:51 --> Hooks Class Initialized
DEBUG - 2012-07-19 20:16:51 --> Utf8 Class Initialized
DEBUG - 2012-07-19 20:16:51 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 20:16:51 --> URI Class Initialized
DEBUG - 2012-07-19 20:16:51 --> Router Class Initialized
DEBUG - 2012-07-19 20:16:51 --> Output Class Initialized
DEBUG - 2012-07-19 20:16:51 --> Security Class Initialized
DEBUG - 2012-07-19 20:16:51 --> Input Class Initialized
DEBUG - 2012-07-19 20:16:51 --> XSS Filtering completed
DEBUG - 2012-07-19 20:16:51 --> XSS Filtering completed
DEBUG - 2012-07-19 20:16:51 --> XSS Filtering completed
DEBUG - 2012-07-19 20:16:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 20:16:51 --> Language Class Initialized
DEBUG - 2012-07-19 20:16:51 --> Loader Class Initialized
DEBUG - 2012-07-19 20:16:51 --> Helper loaded: url_helper
DEBUG - 2012-07-19 20:16:51 --> Controller Class Initialized
DEBUG - 2012-07-19 20:16:51 --> Model Class Initialized
DEBUG - 2012-07-19 20:16:51 --> Database Driver Class Initialized
DEBUG - 2012-07-19 20:16:51 --> Helper loaded: form_helper
DEBUG - 2012-07-19 20:16:51 --> Form Validation Class Initialized
DEBUG - 2012-07-19 20:16:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-19 20:17:54 --> Config Class Initialized
DEBUG - 2012-07-19 20:17:54 --> Hooks Class Initialized
DEBUG - 2012-07-19 20:17:54 --> Utf8 Class Initialized
DEBUG - 2012-07-19 20:17:54 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 20:17:54 --> URI Class Initialized
DEBUG - 2012-07-19 20:17:54 --> Router Class Initialized
DEBUG - 2012-07-19 20:17:54 --> Output Class Initialized
DEBUG - 2012-07-19 20:17:54 --> Security Class Initialized
DEBUG - 2012-07-19 20:17:54 --> Input Class Initialized
DEBUG - 2012-07-19 20:17:54 --> XSS Filtering completed
DEBUG - 2012-07-19 20:17:54 --> XSS Filtering completed
DEBUG - 2012-07-19 20:17:54 --> XSS Filtering completed
DEBUG - 2012-07-19 20:17:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 20:17:54 --> Language Class Initialized
DEBUG - 2012-07-19 20:17:54 --> Loader Class Initialized
DEBUG - 2012-07-19 20:17:54 --> Helper loaded: url_helper
DEBUG - 2012-07-19 20:17:54 --> Controller Class Initialized
DEBUG - 2012-07-19 20:17:54 --> Model Class Initialized
DEBUG - 2012-07-19 20:17:54 --> Database Driver Class Initialized
DEBUG - 2012-07-19 20:17:54 --> Helper loaded: form_helper
DEBUG - 2012-07-19 20:17:54 --> Form Validation Class Initialized
DEBUG - 2012-07-19 20:17:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-19 20:17:55 --> Final output sent to browser
DEBUG - 2012-07-19 20:17:55 --> Total execution time: 0.0800
DEBUG - 2012-07-19 20:18:15 --> Config Class Initialized
DEBUG - 2012-07-19 20:18:15 --> Hooks Class Initialized
DEBUG - 2012-07-19 20:18:15 --> Utf8 Class Initialized
DEBUG - 2012-07-19 20:18:15 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 20:18:15 --> URI Class Initialized
DEBUG - 2012-07-19 20:18:15 --> Router Class Initialized
DEBUG - 2012-07-19 20:18:15 --> Output Class Initialized
DEBUG - 2012-07-19 20:18:15 --> Security Class Initialized
DEBUG - 2012-07-19 20:18:15 --> Input Class Initialized
DEBUG - 2012-07-19 20:18:15 --> XSS Filtering completed
DEBUG - 2012-07-19 20:18:15 --> XSS Filtering completed
DEBUG - 2012-07-19 20:18:15 --> XSS Filtering completed
DEBUG - 2012-07-19 20:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 20:18:15 --> Language Class Initialized
DEBUG - 2012-07-19 20:18:15 --> Loader Class Initialized
DEBUG - 2012-07-19 20:18:15 --> Helper loaded: url_helper
DEBUG - 2012-07-19 20:18:15 --> Controller Class Initialized
DEBUG - 2012-07-19 20:18:15 --> Model Class Initialized
DEBUG - 2012-07-19 20:18:15 --> Database Driver Class Initialized
DEBUG - 2012-07-19 20:18:15 --> Helper loaded: form_helper
DEBUG - 2012-07-19 20:18:15 --> Form Validation Class Initialized
DEBUG - 2012-07-19 20:18:15 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-19 20:18:15 --> Final output sent to browser
DEBUG - 2012-07-19 20:18:15 --> Total execution time: 0.0396
DEBUG - 2012-07-19 20:30:05 --> Config Class Initialized
DEBUG - 2012-07-19 20:30:05 --> Hooks Class Initialized
DEBUG - 2012-07-19 20:30:05 --> Utf8 Class Initialized
DEBUG - 2012-07-19 20:30:05 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 20:30:05 --> URI Class Initialized
DEBUG - 2012-07-19 20:30:05 --> Router Class Initialized
DEBUG - 2012-07-19 20:30:05 --> Output Class Initialized
DEBUG - 2012-07-19 20:30:05 --> Security Class Initialized
DEBUG - 2012-07-19 20:30:05 --> Input Class Initialized
DEBUG - 2012-07-19 20:30:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 20:30:05 --> Language Class Initialized
DEBUG - 2012-07-19 20:30:05 --> Loader Class Initialized
DEBUG - 2012-07-19 20:30:05 --> Helper loaded: url_helper
DEBUG - 2012-07-19 20:30:05 --> Controller Class Initialized
DEBUG - 2012-07-19 20:30:05 --> Model Class Initialized
DEBUG - 2012-07-19 20:30:05 --> Database Driver Class Initialized
DEBUG - 2012-07-19 20:30:05 --> Helper loaded: form_helper
DEBUG - 2012-07-19 20:30:05 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-19 20:30:05 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-19 20:30:05 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-19 20:30:05 --> File loaded: application/views/admin/pages/account.php
DEBUG - 2012-07-19 20:30:05 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-19 20:30:05 --> Final output sent to browser
DEBUG - 2012-07-19 20:30:05 --> Total execution time: 0.0397
DEBUG - 2012-07-19 20:30:11 --> Config Class Initialized
DEBUG - 2012-07-19 20:30:11 --> Hooks Class Initialized
DEBUG - 2012-07-19 20:30:11 --> Utf8 Class Initialized
DEBUG - 2012-07-19 20:30:11 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 20:30:11 --> URI Class Initialized
DEBUG - 2012-07-19 20:30:11 --> Router Class Initialized
DEBUG - 2012-07-19 20:30:11 --> Output Class Initialized
DEBUG - 2012-07-19 20:30:11 --> Security Class Initialized
DEBUG - 2012-07-19 20:30:11 --> Input Class Initialized
DEBUG - 2012-07-19 20:30:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 20:30:11 --> Language Class Initialized
DEBUG - 2012-07-19 20:30:11 --> Loader Class Initialized
DEBUG - 2012-07-19 20:30:11 --> Helper loaded: url_helper
DEBUG - 2012-07-19 20:30:11 --> Controller Class Initialized
DEBUG - 2012-07-19 20:30:11 --> Model Class Initialized
DEBUG - 2012-07-19 20:30:11 --> Database Driver Class Initialized
DEBUG - 2012-07-19 20:30:11 --> Helper loaded: form_helper
DEBUG - 2012-07-19 20:30:11 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-19 20:30:11 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-19 20:30:11 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-19 20:30:11 --> File loaded: application/views/admin/pages/business.php
DEBUG - 2012-07-19 20:30:11 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-19 20:30:11 --> Final output sent to browser
DEBUG - 2012-07-19 20:30:11 --> Total execution time: 0.0392
DEBUG - 2012-07-19 20:30:14 --> Config Class Initialized
DEBUG - 2012-07-19 20:30:14 --> Hooks Class Initialized
DEBUG - 2012-07-19 20:30:14 --> Utf8 Class Initialized
DEBUG - 2012-07-19 20:30:14 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 20:30:14 --> URI Class Initialized
DEBUG - 2012-07-19 20:30:14 --> Router Class Initialized
DEBUG - 2012-07-19 20:30:14 --> Output Class Initialized
DEBUG - 2012-07-19 20:30:14 --> Security Class Initialized
DEBUG - 2012-07-19 20:30:14 --> Input Class Initialized
DEBUG - 2012-07-19 20:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 20:30:14 --> Language Class Initialized
DEBUG - 2012-07-19 20:30:14 --> Loader Class Initialized
DEBUG - 2012-07-19 20:30:14 --> Helper loaded: url_helper
DEBUG - 2012-07-19 20:30:14 --> Controller Class Initialized
DEBUG - 2012-07-19 20:30:14 --> Model Class Initialized
DEBUG - 2012-07-19 20:30:14 --> Database Driver Class Initialized
DEBUG - 2012-07-19 20:30:14 --> Helper loaded: language_helper
DEBUG - 2012-07-19 20:30:14 --> Helper loaded: html_helper
DEBUG - 2012-07-19 20:30:14 --> Helper loaded: form_helper
DEBUG - 2012-07-19 20:30:14 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-19 20:30:14 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-19 20:30:14 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-19 20:30:14 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-19 20:30:14 --> File loaded: application/views/admin/pages/logo.php
DEBUG - 2012-07-19 20:30:14 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-19 20:30:14 --> Final output sent to browser
DEBUG - 2012-07-19 20:30:14 --> Total execution time: 0.0797
DEBUG - 2012-07-19 20:32:46 --> Config Class Initialized
DEBUG - 2012-07-19 20:32:46 --> Hooks Class Initialized
DEBUG - 2012-07-19 20:32:46 --> Utf8 Class Initialized
DEBUG - 2012-07-19 20:32:46 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 20:32:46 --> URI Class Initialized
DEBUG - 2012-07-19 20:32:46 --> Router Class Initialized
DEBUG - 2012-07-19 20:32:46 --> Output Class Initialized
DEBUG - 2012-07-19 20:32:46 --> Security Class Initialized
DEBUG - 2012-07-19 20:32:46 --> Input Class Initialized
DEBUG - 2012-07-19 20:32:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 20:32:46 --> Language Class Initialized
DEBUG - 2012-07-19 20:32:46 --> Loader Class Initialized
DEBUG - 2012-07-19 20:32:46 --> Helper loaded: url_helper
DEBUG - 2012-07-19 20:32:46 --> Controller Class Initialized
DEBUG - 2012-07-19 20:32:46 --> Model Class Initialized
DEBUG - 2012-07-19 20:32:46 --> Database Driver Class Initialized
DEBUG - 2012-07-19 20:32:46 --> Helper loaded: language_helper
DEBUG - 2012-07-19 20:32:46 --> Helper loaded: html_helper
DEBUG - 2012-07-19 20:32:46 --> Helper loaded: form_helper
DEBUG - 2012-07-19 20:32:46 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-19 20:32:46 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-19 20:32:46 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-19 20:32:46 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-19 20:32:46 --> File loaded: application/views/admin/pages/logo.php
DEBUG - 2012-07-19 20:32:46 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-19 20:32:46 --> Final output sent to browser
DEBUG - 2012-07-19 20:32:46 --> Total execution time: 0.0507
DEBUG - 2012-07-19 20:33:02 --> Config Class Initialized
DEBUG - 2012-07-19 20:33:02 --> Hooks Class Initialized
DEBUG - 2012-07-19 20:33:02 --> Utf8 Class Initialized
DEBUG - 2012-07-19 20:33:02 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 20:33:02 --> URI Class Initialized
DEBUG - 2012-07-19 20:33:02 --> Router Class Initialized
DEBUG - 2012-07-19 20:33:02 --> Output Class Initialized
DEBUG - 2012-07-19 20:33:02 --> Security Class Initialized
DEBUG - 2012-07-19 20:33:02 --> Input Class Initialized
DEBUG - 2012-07-19 20:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 20:33:02 --> Language Class Initialized
DEBUG - 2012-07-19 20:33:02 --> Loader Class Initialized
DEBUG - 2012-07-19 20:33:02 --> Helper loaded: url_helper
DEBUG - 2012-07-19 20:33:02 --> Controller Class Initialized
DEBUG - 2012-07-19 20:33:02 --> Model Class Initialized
DEBUG - 2012-07-19 20:33:02 --> Database Driver Class Initialized
DEBUG - 2012-07-19 20:33:02 --> Helper loaded: form_helper
DEBUG - 2012-07-19 20:33:02 --> Helper loaded: html_helper
DEBUG - 2012-07-19 20:33:02 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 20:33:02 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 20:33:02 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 20:33:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 20:33:02 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 20:33:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 20:33:02 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 20:33:02 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 20:33:02 --> Final output sent to browser
DEBUG - 2012-07-19 20:33:02 --> Total execution time: 0.0401
DEBUG - 2012-07-19 22:07:18 --> Config Class Initialized
DEBUG - 2012-07-19 22:07:18 --> Hooks Class Initialized
DEBUG - 2012-07-19 22:07:18 --> Utf8 Class Initialized
DEBUG - 2012-07-19 22:07:18 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 22:07:18 --> URI Class Initialized
DEBUG - 2012-07-19 22:07:18 --> Router Class Initialized
DEBUG - 2012-07-19 22:07:18 --> Output Class Initialized
DEBUG - 2012-07-19 22:07:18 --> Security Class Initialized
DEBUG - 2012-07-19 22:07:18 --> Input Class Initialized
DEBUG - 2012-07-19 22:07:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 22:07:18 --> Language Class Initialized
DEBUG - 2012-07-19 22:07:18 --> Loader Class Initialized
DEBUG - 2012-07-19 22:07:18 --> Helper loaded: url_helper
DEBUG - 2012-07-19 22:07:18 --> Controller Class Initialized
DEBUG - 2012-07-19 22:07:18 --> Model Class Initialized
DEBUG - 2012-07-19 22:07:18 --> Database Driver Class Initialized
DEBUG - 2012-07-19 22:07:18 --> Helper loaded: form_helper
DEBUG - 2012-07-19 22:07:18 --> Helper loaded: html_helper
DEBUG - 2012-07-19 22:07:18 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 22:07:18 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 22:07:18 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 22:07:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 22:07:18 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 22:07:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 22:07:18 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 22:07:18 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 22:07:18 --> Final output sent to browser
DEBUG - 2012-07-19 22:07:18 --> Total execution time: 0.0456
DEBUG - 2012-07-19 22:20:39 --> Config Class Initialized
DEBUG - 2012-07-19 22:20:39 --> Hooks Class Initialized
DEBUG - 2012-07-19 22:20:39 --> Utf8 Class Initialized
DEBUG - 2012-07-19 22:20:39 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 22:20:39 --> URI Class Initialized
DEBUG - 2012-07-19 22:20:39 --> Router Class Initialized
DEBUG - 2012-07-19 22:20:39 --> Output Class Initialized
DEBUG - 2012-07-19 22:20:39 --> Security Class Initialized
DEBUG - 2012-07-19 22:20:39 --> Input Class Initialized
DEBUG - 2012-07-19 22:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 22:20:39 --> Language Class Initialized
DEBUG - 2012-07-19 22:20:39 --> Loader Class Initialized
DEBUG - 2012-07-19 22:20:39 --> Helper loaded: url_helper
DEBUG - 2012-07-19 22:20:39 --> Controller Class Initialized
DEBUG - 2012-07-19 22:20:39 --> Model Class Initialized
DEBUG - 2012-07-19 22:20:39 --> Database Driver Class Initialized
DEBUG - 2012-07-19 22:20:39 --> Helper loaded: form_helper
DEBUG - 2012-07-19 22:20:39 --> Helper loaded: html_helper
DEBUG - 2012-07-19 22:20:39 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 22:20:39 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 22:20:39 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 22:20:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 22:20:39 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 22:20:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 22:20:39 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 22:20:39 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 22:20:39 --> Final output sent to browser
DEBUG - 2012-07-19 22:20:39 --> Total execution time: 0.0415
DEBUG - 2012-07-19 22:27:13 --> Config Class Initialized
DEBUG - 2012-07-19 22:27:13 --> Hooks Class Initialized
DEBUG - 2012-07-19 22:27:13 --> Utf8 Class Initialized
DEBUG - 2012-07-19 22:27:13 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 22:27:13 --> URI Class Initialized
DEBUG - 2012-07-19 22:27:13 --> Router Class Initialized
DEBUG - 2012-07-19 22:27:13 --> Output Class Initialized
DEBUG - 2012-07-19 22:27:13 --> Security Class Initialized
DEBUG - 2012-07-19 22:27:13 --> Input Class Initialized
DEBUG - 2012-07-19 22:27:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 22:27:13 --> Language Class Initialized
DEBUG - 2012-07-19 22:27:13 --> Loader Class Initialized
DEBUG - 2012-07-19 22:27:13 --> Helper loaded: url_helper
DEBUG - 2012-07-19 22:27:13 --> Controller Class Initialized
DEBUG - 2012-07-19 22:27:13 --> Model Class Initialized
DEBUG - 2012-07-19 22:27:13 --> Database Driver Class Initialized
DEBUG - 2012-07-19 22:27:13 --> Helper loaded: form_helper
DEBUG - 2012-07-19 22:27:13 --> Helper loaded: html_helper
DEBUG - 2012-07-19 22:27:13 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 22:27:13 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 22:27:13 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 22:27:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 22:27:13 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 22:27:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 22:27:13 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 22:27:13 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 22:27:13 --> Final output sent to browser
DEBUG - 2012-07-19 22:27:13 --> Total execution time: 0.0447
DEBUG - 2012-07-19 22:58:47 --> Config Class Initialized
DEBUG - 2012-07-19 22:58:47 --> Hooks Class Initialized
DEBUG - 2012-07-19 22:58:47 --> Utf8 Class Initialized
DEBUG - 2012-07-19 22:58:47 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 22:58:47 --> URI Class Initialized
DEBUG - 2012-07-19 22:58:47 --> Router Class Initialized
DEBUG - 2012-07-19 22:58:47 --> Output Class Initialized
DEBUG - 2012-07-19 22:58:47 --> Security Class Initialized
DEBUG - 2012-07-19 22:58:47 --> Input Class Initialized
DEBUG - 2012-07-19 22:58:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 22:58:47 --> Language Class Initialized
DEBUG - 2012-07-19 22:58:47 --> Loader Class Initialized
DEBUG - 2012-07-19 22:58:47 --> Helper loaded: url_helper
DEBUG - 2012-07-19 22:58:47 --> Controller Class Initialized
DEBUG - 2012-07-19 22:58:47 --> Model Class Initialized
DEBUG - 2012-07-19 22:58:47 --> Database Driver Class Initialized
DEBUG - 2012-07-19 22:58:47 --> Helper loaded: form_helper
DEBUG - 2012-07-19 22:58:47 --> Helper loaded: html_helper
DEBUG - 2012-07-19 22:58:47 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 22:58:47 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 22:58:47 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 22:58:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 22:58:47 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 22:58:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 22:58:47 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 22:58:47 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 22:58:47 --> Final output sent to browser
DEBUG - 2012-07-19 22:58:47 --> Total execution time: 0.0396
DEBUG - 2012-07-19 23:00:48 --> Config Class Initialized
DEBUG - 2012-07-19 23:00:48 --> Hooks Class Initialized
DEBUG - 2012-07-19 23:00:48 --> Utf8 Class Initialized
DEBUG - 2012-07-19 23:00:48 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 23:00:48 --> URI Class Initialized
DEBUG - 2012-07-19 23:00:48 --> Router Class Initialized
DEBUG - 2012-07-19 23:00:48 --> Output Class Initialized
DEBUG - 2012-07-19 23:00:48 --> Security Class Initialized
DEBUG - 2012-07-19 23:00:48 --> Input Class Initialized
DEBUG - 2012-07-19 23:00:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 23:00:48 --> Language Class Initialized
DEBUG - 2012-07-19 23:00:48 --> Loader Class Initialized
DEBUG - 2012-07-19 23:00:48 --> Helper loaded: url_helper
DEBUG - 2012-07-19 23:00:48 --> Controller Class Initialized
DEBUG - 2012-07-19 23:00:48 --> Model Class Initialized
DEBUG - 2012-07-19 23:00:48 --> Database Driver Class Initialized
DEBUG - 2012-07-19 23:00:48 --> Helper loaded: form_helper
DEBUG - 2012-07-19 23:00:48 --> Helper loaded: html_helper
DEBUG - 2012-07-19 23:00:48 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 23:00:48 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 23:00:48 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 23:00:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 23:00:48 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 23:00:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 23:00:48 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 23:00:48 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 23:00:48 --> Final output sent to browser
DEBUG - 2012-07-19 23:00:48 --> Total execution time: 0.0403
DEBUG - 2012-07-19 23:01:17 --> Config Class Initialized
DEBUG - 2012-07-19 23:01:17 --> Hooks Class Initialized
DEBUG - 2012-07-19 23:01:17 --> Utf8 Class Initialized
DEBUG - 2012-07-19 23:01:17 --> UTF-8 Support Disabled
DEBUG - 2012-07-19 23:01:17 --> URI Class Initialized
DEBUG - 2012-07-19 23:01:17 --> Router Class Initialized
DEBUG - 2012-07-19 23:01:17 --> Output Class Initialized
DEBUG - 2012-07-19 23:01:17 --> Security Class Initialized
DEBUG - 2012-07-19 23:01:17 --> Input Class Initialized
DEBUG - 2012-07-19 23:01:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-19 23:01:17 --> Language Class Initialized
DEBUG - 2012-07-19 23:01:17 --> Loader Class Initialized
DEBUG - 2012-07-19 23:01:17 --> Helper loaded: url_helper
DEBUG - 2012-07-19 23:01:17 --> Controller Class Initialized
DEBUG - 2012-07-19 23:01:17 --> Model Class Initialized
DEBUG - 2012-07-19 23:01:17 --> Database Driver Class Initialized
DEBUG - 2012-07-19 23:01:17 --> Helper loaded: form_helper
DEBUG - 2012-07-19 23:01:17 --> Helper loaded: html_helper
DEBUG - 2012-07-19 23:01:17 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-19 23:01:17 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-19 23:01:17 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 23:01:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-19 23:01:17 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-19 23:01:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-19 23:01:17 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-19 23:01:17 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-19 23:01:17 --> Final output sent to browser
DEBUG - 2012-07-19 23:01:17 --> Total execution time: 0.0522
