<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-07-20 21:01:10 --> Config Class Initialized
DEBUG - 2012-07-20 21:01:10 --> Hooks Class Initialized
DEBUG - 2012-07-20 21:01:10 --> Utf8 Class Initialized
DEBUG - 2012-07-20 21:01:10 --> UTF-8 Support Disabled
DEBUG - 2012-07-20 21:01:10 --> URI Class Initialized
DEBUG - 2012-07-20 21:01:10 --> Router Class Initialized
DEBUG - 2012-07-20 21:01:10 --> Output Class Initialized
DEBUG - 2012-07-20 21:01:10 --> Security Class Initialized
DEBUG - 2012-07-20 21:01:10 --> Input Class Initialized
DEBUG - 2012-07-20 21:01:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-20 21:01:10 --> Language Class Initialized
DEBUG - 2012-07-20 21:01:11 --> Loader Class Initialized
DEBUG - 2012-07-20 21:01:11 --> Helper loaded: url_helper
DEBUG - 2012-07-20 21:01:11 --> Controller Class Initialized
DEBUG - 2012-07-20 21:01:11 --> Model Class Initialized
DEBUG - 2012-07-20 21:01:11 --> Database Driver Class Initialized
DEBUG - 2012-07-20 21:01:11 --> Helper loaded: form_helper
DEBUG - 2012-07-20 21:01:11 --> Helper loaded: html_helper
DEBUG - 2012-07-20 21:01:11 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-20 21:01:11 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-20 21:01:11 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-20 21:01:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-20 21:01:11 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-20 21:01:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-20 21:01:11 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-20 21:01:11 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-20 21:01:11 --> Final output sent to browser
DEBUG - 2012-07-20 21:01:11 --> Total execution time: 0.5951
DEBUG - 2012-07-20 21:01:32 --> Config Class Initialized
DEBUG - 2012-07-20 21:01:32 --> Hooks Class Initialized
DEBUG - 2012-07-20 21:01:32 --> Utf8 Class Initialized
DEBUG - 2012-07-20 21:01:32 --> UTF-8 Support Disabled
DEBUG - 2012-07-20 21:01:32 --> URI Class Initialized
DEBUG - 2012-07-20 21:01:32 --> Router Class Initialized
DEBUG - 2012-07-20 21:01:32 --> Output Class Initialized
DEBUG - 2012-07-20 21:01:32 --> Security Class Initialized
DEBUG - 2012-07-20 21:01:32 --> Input Class Initialized
DEBUG - 2012-07-20 21:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-20 21:01:32 --> Language Class Initialized
DEBUG - 2012-07-20 21:01:32 --> Loader Class Initialized
DEBUG - 2012-07-20 21:01:32 --> Helper loaded: url_helper
DEBUG - 2012-07-20 21:01:32 --> Controller Class Initialized
DEBUG - 2012-07-20 21:01:32 --> Model Class Initialized
DEBUG - 2012-07-20 21:01:32 --> Database Driver Class Initialized
DEBUG - 2012-07-20 21:01:32 --> Helper loaded: form_helper
DEBUG - 2012-07-20 21:01:32 --> Helper loaded: html_helper
DEBUG - 2012-07-20 21:01:32 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-20 21:01:32 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-20 21:01:32 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-20 21:01:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-20 21:01:32 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-20 21:01:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-20 21:01:32 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-20 21:01:32 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-20 21:01:32 --> Final output sent to browser
DEBUG - 2012-07-20 21:01:32 --> Total execution time: 0.0448
DEBUG - 2012-07-20 21:17:18 --> Config Class Initialized
DEBUG - 2012-07-20 21:17:18 --> Hooks Class Initialized
DEBUG - 2012-07-20 21:17:18 --> Utf8 Class Initialized
DEBUG - 2012-07-20 21:17:18 --> UTF-8 Support Disabled
DEBUG - 2012-07-20 21:17:18 --> URI Class Initialized
DEBUG - 2012-07-20 21:17:18 --> Router Class Initialized
DEBUG - 2012-07-20 21:17:18 --> Output Class Initialized
DEBUG - 2012-07-20 21:17:18 --> Security Class Initialized
DEBUG - 2012-07-20 21:17:18 --> Input Class Initialized
DEBUG - 2012-07-20 21:17:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-20 21:17:18 --> Language Class Initialized
DEBUG - 2012-07-20 21:17:18 --> Loader Class Initialized
DEBUG - 2012-07-20 21:17:18 --> Helper loaded: url_helper
DEBUG - 2012-07-20 21:17:18 --> Controller Class Initialized
DEBUG - 2012-07-20 21:17:18 --> Model Class Initialized
DEBUG - 2012-07-20 21:17:18 --> Database Driver Class Initialized
DEBUG - 2012-07-20 21:17:18 --> Helper loaded: form_helper
DEBUG - 2012-07-20 21:17:19 --> Helper loaded: html_helper
DEBUG - 2012-07-20 21:17:19 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-20 21:17:19 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-20 21:17:19 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-20 21:17:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-20 21:17:19 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-20 21:17:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-20 21:17:19 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-20 21:17:19 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-20 21:17:19 --> Final output sent to browser
DEBUG - 2012-07-20 21:17:19 --> Total execution time: 0.0446
