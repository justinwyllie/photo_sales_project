<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-07-21 19:51:27 --> Config Class Initialized
DEBUG - 2012-07-21 19:51:27 --> Hooks Class Initialized
DEBUG - 2012-07-21 19:51:27 --> Utf8 Class Initialized
DEBUG - 2012-07-21 19:51:27 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 19:51:27 --> URI Class Initialized
DEBUG - 2012-07-21 19:51:27 --> Router Class Initialized
DEBUG - 2012-07-21 19:51:27 --> Output Class Initialized
DEBUG - 2012-07-21 19:51:27 --> Security Class Initialized
DEBUG - 2012-07-21 19:51:27 --> Input Class Initialized
DEBUG - 2012-07-21 19:51:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 19:51:27 --> Language Class Initialized
DEBUG - 2012-07-21 19:51:27 --> Loader Class Initialized
DEBUG - 2012-07-21 19:51:27 --> Helper loaded: url_helper
DEBUG - 2012-07-21 19:51:27 --> Controller Class Initialized
DEBUG - 2012-07-21 19:51:27 --> Model Class Initialized
DEBUG - 2012-07-21 19:51:27 --> Database Driver Class Initialized
DEBUG - 2012-07-21 19:51:27 --> Helper loaded: form_helper
DEBUG - 2012-07-21 19:51:27 --> Helper loaded: html_helper
DEBUG - 2012-07-21 19:51:27 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-21 19:51:27 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-21 19:51:27 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-21 19:51:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-21 19:51:27 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-21 19:51:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-21 19:51:27 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-21 19:51:27 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-21 19:51:27 --> Final output sent to browser
DEBUG - 2012-07-21 19:51:27 --> Total execution time: 0.4433
DEBUG - 2012-07-21 20:09:20 --> Config Class Initialized
DEBUG - 2012-07-21 20:09:20 --> Hooks Class Initialized
DEBUG - 2012-07-21 20:09:20 --> Utf8 Class Initialized
DEBUG - 2012-07-21 20:09:20 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 20:09:20 --> URI Class Initialized
DEBUG - 2012-07-21 20:09:20 --> Router Class Initialized
DEBUG - 2012-07-21 20:09:20 --> Output Class Initialized
DEBUG - 2012-07-21 20:09:20 --> Security Class Initialized
DEBUG - 2012-07-21 20:09:20 --> Input Class Initialized
DEBUG - 2012-07-21 20:09:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 20:09:20 --> Language Class Initialized
DEBUG - 2012-07-21 20:09:20 --> Loader Class Initialized
DEBUG - 2012-07-21 20:09:20 --> Helper loaded: url_helper
DEBUG - 2012-07-21 20:09:20 --> Controller Class Initialized
DEBUG - 2012-07-21 20:09:20 --> Model Class Initialized
DEBUG - 2012-07-21 20:09:20 --> Database Driver Class Initialized
DEBUG - 2012-07-21 20:09:20 --> Helper loaded: form_helper
DEBUG - 2012-07-21 20:09:20 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 20:09:20 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-21 20:09:20 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 20:09:20 --> File loaded: application/views/admin/pages/account.php
DEBUG - 2012-07-21 20:09:20 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 20:09:20 --> Final output sent to browser
DEBUG - 2012-07-21 20:09:20 --> Total execution time: 0.1187
DEBUG - 2012-07-21 20:09:24 --> Config Class Initialized
DEBUG - 2012-07-21 20:09:24 --> Hooks Class Initialized
DEBUG - 2012-07-21 20:09:24 --> Utf8 Class Initialized
DEBUG - 2012-07-21 20:09:24 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 20:09:24 --> URI Class Initialized
DEBUG - 2012-07-21 20:09:24 --> Router Class Initialized
DEBUG - 2012-07-21 20:09:24 --> Output Class Initialized
DEBUG - 2012-07-21 20:09:24 --> Security Class Initialized
DEBUG - 2012-07-21 20:09:24 --> Input Class Initialized
DEBUG - 2012-07-21 20:09:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 20:09:24 --> Language Class Initialized
DEBUG - 2012-07-21 20:09:24 --> Loader Class Initialized
DEBUG - 2012-07-21 20:09:24 --> Helper loaded: url_helper
DEBUG - 2012-07-21 20:09:24 --> Controller Class Initialized
DEBUG - 2012-07-21 20:09:24 --> Model Class Initialized
DEBUG - 2012-07-21 20:09:24 --> Database Driver Class Initialized
DEBUG - 2012-07-21 20:09:24 --> Helper loaded: form_helper
DEBUG - 2012-07-21 20:09:25 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 20:09:25 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-21 20:09:25 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 20:09:25 --> File loaded: application/views/admin/pages/business.php
DEBUG - 2012-07-21 20:09:25 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 20:09:25 --> Final output sent to browser
DEBUG - 2012-07-21 20:09:25 --> Total execution time: 0.3931
DEBUG - 2012-07-21 20:09:28 --> Config Class Initialized
DEBUG - 2012-07-21 20:09:28 --> Hooks Class Initialized
DEBUG - 2012-07-21 20:09:28 --> Utf8 Class Initialized
DEBUG - 2012-07-21 20:09:28 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 20:09:28 --> URI Class Initialized
DEBUG - 2012-07-21 20:09:28 --> Router Class Initialized
DEBUG - 2012-07-21 20:09:28 --> Output Class Initialized
DEBUG - 2012-07-21 20:09:28 --> Security Class Initialized
DEBUG - 2012-07-21 20:09:28 --> Input Class Initialized
DEBUG - 2012-07-21 20:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 20:09:28 --> Language Class Initialized
DEBUG - 2012-07-21 20:09:28 --> Loader Class Initialized
DEBUG - 2012-07-21 20:09:28 --> Helper loaded: url_helper
DEBUG - 2012-07-21 20:09:28 --> Controller Class Initialized
DEBUG - 2012-07-21 20:09:28 --> Model Class Initialized
DEBUG - 2012-07-21 20:09:28 --> Database Driver Class Initialized
DEBUG - 2012-07-21 20:09:28 --> Helper loaded: language_helper
DEBUG - 2012-07-21 20:09:28 --> Helper loaded: html_helper
DEBUG - 2012-07-21 20:09:28 --> Helper loaded: form_helper
DEBUG - 2012-07-21 20:09:28 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-21 20:09:28 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 20:09:28 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-21 20:09:28 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 20:09:28 --> File loaded: application/views/admin/pages/logo.php
DEBUG - 2012-07-21 20:09:28 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 20:09:28 --> Final output sent to browser
DEBUG - 2012-07-21 20:09:28 --> Total execution time: 0.1210
DEBUG - 2012-07-21 20:09:31 --> Config Class Initialized
DEBUG - 2012-07-21 20:09:31 --> Hooks Class Initialized
DEBUG - 2012-07-21 20:09:31 --> Utf8 Class Initialized
DEBUG - 2012-07-21 20:09:31 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 20:09:31 --> URI Class Initialized
DEBUG - 2012-07-21 20:09:31 --> Router Class Initialized
ERROR - 2012-07-21 20:09:31 --> 404 Page Not Found --> admin/pricing
DEBUG - 2012-07-21 20:41:45 --> Config Class Initialized
DEBUG - 2012-07-21 20:41:45 --> Hooks Class Initialized
DEBUG - 2012-07-21 20:41:45 --> Utf8 Class Initialized
DEBUG - 2012-07-21 20:41:45 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 20:41:45 --> URI Class Initialized
DEBUG - 2012-07-21 20:41:45 --> Router Class Initialized
DEBUG - 2012-07-21 20:41:45 --> Output Class Initialized
DEBUG - 2012-07-21 20:41:45 --> Security Class Initialized
DEBUG - 2012-07-21 20:41:45 --> Input Class Initialized
DEBUG - 2012-07-21 20:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 20:41:45 --> Language Class Initialized
DEBUG - 2012-07-21 20:41:45 --> Loader Class Initialized
DEBUG - 2012-07-21 20:41:45 --> Helper loaded: url_helper
DEBUG - 2012-07-21 20:41:45 --> Controller Class Initialized
DEBUG - 2012-07-21 20:41:45 --> Model Class Initialized
DEBUG - 2012-07-21 20:41:45 --> Database Driver Class Initialized
DEBUG - 2012-07-21 20:41:49 --> Config Class Initialized
DEBUG - 2012-07-21 20:41:49 --> Hooks Class Initialized
DEBUG - 2012-07-21 20:41:49 --> Utf8 Class Initialized
DEBUG - 2012-07-21 20:41:49 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 20:41:49 --> URI Class Initialized
DEBUG - 2012-07-21 20:41:49 --> Router Class Initialized
DEBUG - 2012-07-21 20:41:49 --> Output Class Initialized
DEBUG - 2012-07-21 20:41:49 --> Security Class Initialized
DEBUG - 2012-07-21 20:41:49 --> Input Class Initialized
DEBUG - 2012-07-21 20:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 20:41:49 --> Language Class Initialized
DEBUG - 2012-07-21 20:41:49 --> Loader Class Initialized
DEBUG - 2012-07-21 20:41:49 --> Helper loaded: url_helper
DEBUG - 2012-07-21 20:41:49 --> Controller Class Initialized
DEBUG - 2012-07-21 20:41:49 --> Model Class Initialized
DEBUG - 2012-07-21 20:41:49 --> Database Driver Class Initialized
DEBUG - 2012-07-21 20:41:49 --> Helper loaded: language_helper
DEBUG - 2012-07-21 20:41:49 --> Helper loaded: html_helper
DEBUG - 2012-07-21 20:41:49 --> Helper loaded: form_helper
DEBUG - 2012-07-21 20:41:49 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-21 20:41:49 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 20:41:49 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-21 20:41:49 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 20:41:49 --> File loaded: application/views/admin/pages/business/logo.php
DEBUG - 2012-07-21 20:41:49 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 20:41:49 --> Final output sent to browser
DEBUG - 2012-07-21 20:41:49 --> Total execution time: 0.0410
DEBUG - 2012-07-21 20:41:52 --> Config Class Initialized
DEBUG - 2012-07-21 20:41:52 --> Hooks Class Initialized
DEBUG - 2012-07-21 20:41:52 --> Utf8 Class Initialized
DEBUG - 2012-07-21 20:41:52 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 20:41:52 --> URI Class Initialized
DEBUG - 2012-07-21 20:41:52 --> Router Class Initialized
DEBUG - 2012-07-21 20:41:52 --> Output Class Initialized
DEBUG - 2012-07-21 20:41:52 --> Security Class Initialized
DEBUG - 2012-07-21 20:41:52 --> Input Class Initialized
DEBUG - 2012-07-21 20:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 20:41:52 --> Language Class Initialized
DEBUG - 2012-07-21 20:41:52 --> Loader Class Initialized
DEBUG - 2012-07-21 20:41:52 --> Helper loaded: url_helper
DEBUG - 2012-07-21 20:41:52 --> Controller Class Initialized
DEBUG - 2012-07-21 20:41:52 --> Model Class Initialized
DEBUG - 2012-07-21 20:41:52 --> Database Driver Class Initialized
DEBUG - 2012-07-21 20:41:52 --> Helper loaded: form_helper
DEBUG - 2012-07-21 20:41:52 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 20:41:52 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-21 20:41:52 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 20:41:52 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-07-21 20:41:52 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 20:41:52 --> Final output sent to browser
DEBUG - 2012-07-21 20:41:52 --> Total execution time: 0.0438
DEBUG - 2012-07-21 20:41:53 --> Config Class Initialized
DEBUG - 2012-07-21 20:41:53 --> Hooks Class Initialized
DEBUG - 2012-07-21 20:41:53 --> Utf8 Class Initialized
DEBUG - 2012-07-21 20:41:53 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 20:41:53 --> URI Class Initialized
DEBUG - 2012-07-21 20:41:53 --> Router Class Initialized
DEBUG - 2012-07-21 20:41:53 --> Output Class Initialized
DEBUG - 2012-07-21 20:41:53 --> Security Class Initialized
DEBUG - 2012-07-21 20:41:53 --> Input Class Initialized
DEBUG - 2012-07-21 20:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 20:41:53 --> Language Class Initialized
DEBUG - 2012-07-21 20:41:53 --> Loader Class Initialized
DEBUG - 2012-07-21 20:41:53 --> Helper loaded: url_helper
DEBUG - 2012-07-21 20:41:53 --> Controller Class Initialized
DEBUG - 2012-07-21 20:41:53 --> Model Class Initialized
DEBUG - 2012-07-21 20:41:53 --> Database Driver Class Initialized
DEBUG - 2012-07-21 20:41:53 --> Helper loaded: form_helper
DEBUG - 2012-07-21 20:41:53 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 20:41:53 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-21 20:41:53 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 20:41:53 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-07-21 20:41:53 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 20:41:53 --> Final output sent to browser
DEBUG - 2012-07-21 20:41:53 --> Total execution time: 0.0434
DEBUG - 2012-07-21 20:41:55 --> Config Class Initialized
DEBUG - 2012-07-21 20:41:55 --> Hooks Class Initialized
DEBUG - 2012-07-21 20:41:55 --> Utf8 Class Initialized
DEBUG - 2012-07-21 20:41:55 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 20:41:55 --> URI Class Initialized
DEBUG - 2012-07-21 20:41:55 --> Router Class Initialized
DEBUG - 2012-07-21 20:41:55 --> Output Class Initialized
DEBUG - 2012-07-21 20:41:55 --> Security Class Initialized
DEBUG - 2012-07-21 20:41:55 --> Input Class Initialized
DEBUG - 2012-07-21 20:41:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 20:41:55 --> Language Class Initialized
DEBUG - 2012-07-21 20:41:55 --> Loader Class Initialized
DEBUG - 2012-07-21 20:41:55 --> Helper loaded: url_helper
DEBUG - 2012-07-21 20:41:55 --> Controller Class Initialized
DEBUG - 2012-07-21 20:41:55 --> Model Class Initialized
DEBUG - 2012-07-21 20:41:55 --> Database Driver Class Initialized
DEBUG - 2012-07-21 20:41:55 --> Helper loaded: language_helper
DEBUG - 2012-07-21 20:41:55 --> Helper loaded: html_helper
DEBUG - 2012-07-21 20:41:55 --> Helper loaded: form_helper
DEBUG - 2012-07-21 20:41:55 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-21 20:41:55 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 20:41:55 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-21 20:41:55 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 20:41:55 --> File loaded: application/views/admin/pages/business/logo.php
DEBUG - 2012-07-21 20:41:55 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 20:41:55 --> Final output sent to browser
DEBUG - 2012-07-21 20:41:55 --> Total execution time: 0.0477
DEBUG - 2012-07-21 20:42:00 --> Config Class Initialized
DEBUG - 2012-07-21 20:42:00 --> Hooks Class Initialized
DEBUG - 2012-07-21 20:42:00 --> Utf8 Class Initialized
DEBUG - 2012-07-21 20:42:00 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 20:42:00 --> URI Class Initialized
DEBUG - 2012-07-21 20:42:00 --> Router Class Initialized
DEBUG - 2012-07-21 20:42:00 --> Output Class Initialized
DEBUG - 2012-07-21 20:42:00 --> Security Class Initialized
DEBUG - 2012-07-21 20:42:00 --> Input Class Initialized
DEBUG - 2012-07-21 20:42:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 20:42:00 --> Language Class Initialized
DEBUG - 2012-07-21 20:42:00 --> Loader Class Initialized
DEBUG - 2012-07-21 20:42:00 --> Helper loaded: url_helper
DEBUG - 2012-07-21 20:42:00 --> Controller Class Initialized
DEBUG - 2012-07-21 20:42:00 --> Model Class Initialized
DEBUG - 2012-07-21 20:42:00 --> Database Driver Class Initialized
DEBUG - 2012-07-21 20:42:00 --> Helper loaded: form_helper
DEBUG - 2012-07-21 20:42:00 --> Helper loaded: html_helper
DEBUG - 2012-07-21 20:42:00 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-21 20:42:00 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-21 20:42:00 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-21 20:42:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-21 20:42:00 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-21 20:42:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-21 20:42:00 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-21 20:42:00 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-21 20:42:00 --> Final output sent to browser
DEBUG - 2012-07-21 20:42:00 --> Total execution time: 0.0513
DEBUG - 2012-07-21 20:42:34 --> Config Class Initialized
DEBUG - 2012-07-21 20:42:34 --> Hooks Class Initialized
DEBUG - 2012-07-21 20:42:34 --> Utf8 Class Initialized
DEBUG - 2012-07-21 20:42:34 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 20:42:34 --> URI Class Initialized
DEBUG - 2012-07-21 20:42:34 --> Router Class Initialized
DEBUG - 2012-07-21 20:42:34 --> Output Class Initialized
DEBUG - 2012-07-21 20:42:34 --> Security Class Initialized
DEBUG - 2012-07-21 20:42:34 --> Input Class Initialized
DEBUG - 2012-07-21 20:42:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 20:42:34 --> Language Class Initialized
DEBUG - 2012-07-21 20:42:34 --> Loader Class Initialized
DEBUG - 2012-07-21 20:42:34 --> Helper loaded: url_helper
DEBUG - 2012-07-21 20:42:34 --> Controller Class Initialized
DEBUG - 2012-07-21 20:42:34 --> Model Class Initialized
DEBUG - 2012-07-21 20:42:34 --> Database Driver Class Initialized
DEBUG - 2012-07-21 20:42:39 --> Config Class Initialized
DEBUG - 2012-07-21 20:42:39 --> Hooks Class Initialized
DEBUG - 2012-07-21 20:42:39 --> Utf8 Class Initialized
DEBUG - 2012-07-21 20:42:39 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 20:42:39 --> URI Class Initialized
DEBUG - 2012-07-21 20:42:39 --> Router Class Initialized
DEBUG - 2012-07-21 20:42:39 --> Output Class Initialized
DEBUG - 2012-07-21 20:42:39 --> Security Class Initialized
DEBUG - 2012-07-21 20:42:39 --> Input Class Initialized
DEBUG - 2012-07-21 20:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 20:42:39 --> Language Class Initialized
DEBUG - 2012-07-21 20:42:39 --> Loader Class Initialized
DEBUG - 2012-07-21 20:42:39 --> Helper loaded: url_helper
DEBUG - 2012-07-21 20:42:39 --> Controller Class Initialized
DEBUG - 2012-07-21 20:42:39 --> Model Class Initialized
DEBUG - 2012-07-21 20:42:39 --> Database Driver Class Initialized
DEBUG - 2012-07-21 20:44:04 --> Config Class Initialized
DEBUG - 2012-07-21 20:44:04 --> Hooks Class Initialized
DEBUG - 2012-07-21 20:44:04 --> Utf8 Class Initialized
DEBUG - 2012-07-21 20:44:04 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 20:44:04 --> URI Class Initialized
DEBUG - 2012-07-21 20:44:04 --> Router Class Initialized
DEBUG - 2012-07-21 20:44:04 --> Output Class Initialized
DEBUG - 2012-07-21 20:44:04 --> Security Class Initialized
DEBUG - 2012-07-21 20:44:04 --> Input Class Initialized
DEBUG - 2012-07-21 20:44:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 20:44:04 --> Language Class Initialized
DEBUG - 2012-07-21 20:44:04 --> Loader Class Initialized
DEBUG - 2012-07-21 20:44:04 --> Helper loaded: url_helper
DEBUG - 2012-07-21 20:44:04 --> Controller Class Initialized
DEBUG - 2012-07-21 20:44:04 --> Model Class Initialized
DEBUG - 2012-07-21 20:44:04 --> Database Driver Class Initialized
DEBUG - 2012-07-21 20:44:06 --> Config Class Initialized
DEBUG - 2012-07-21 20:44:06 --> Hooks Class Initialized
DEBUG - 2012-07-21 20:44:06 --> Utf8 Class Initialized
DEBUG - 2012-07-21 20:44:06 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 20:44:06 --> URI Class Initialized
DEBUG - 2012-07-21 20:44:06 --> Router Class Initialized
DEBUG - 2012-07-21 20:44:06 --> Output Class Initialized
DEBUG - 2012-07-21 20:44:06 --> Security Class Initialized
DEBUG - 2012-07-21 20:44:06 --> Input Class Initialized
DEBUG - 2012-07-21 20:44:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 20:44:06 --> Language Class Initialized
DEBUG - 2012-07-21 20:44:06 --> Loader Class Initialized
DEBUG - 2012-07-21 20:44:06 --> Helper loaded: url_helper
DEBUG - 2012-07-21 20:44:06 --> Controller Class Initialized
DEBUG - 2012-07-21 20:44:06 --> Model Class Initialized
DEBUG - 2012-07-21 20:44:06 --> Database Driver Class Initialized
DEBUG - 2012-07-21 20:48:42 --> Config Class Initialized
DEBUG - 2012-07-21 20:48:42 --> Hooks Class Initialized
DEBUG - 2012-07-21 20:48:42 --> Utf8 Class Initialized
DEBUG - 2012-07-21 20:48:42 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 20:48:42 --> URI Class Initialized
DEBUG - 2012-07-21 20:48:42 --> Router Class Initialized
DEBUG - 2012-07-21 20:48:42 --> Output Class Initialized
DEBUG - 2012-07-21 20:48:42 --> Security Class Initialized
DEBUG - 2012-07-21 20:48:42 --> Input Class Initialized
DEBUG - 2012-07-21 20:48:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 20:48:42 --> Language Class Initialized
DEBUG - 2012-07-21 20:48:42 --> Loader Class Initialized
DEBUG - 2012-07-21 20:48:42 --> Helper loaded: url_helper
DEBUG - 2012-07-21 20:48:42 --> Controller Class Initialized
DEBUG - 2012-07-21 20:48:42 --> Model Class Initialized
DEBUG - 2012-07-21 20:48:42 --> Database Driver Class Initialized
DEBUG - 2012-07-21 20:48:45 --> Config Class Initialized
DEBUG - 2012-07-21 20:48:45 --> Hooks Class Initialized
DEBUG - 2012-07-21 20:48:45 --> Utf8 Class Initialized
DEBUG - 2012-07-21 20:48:45 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 20:48:45 --> URI Class Initialized
DEBUG - 2012-07-21 20:48:45 --> Router Class Initialized
DEBUG - 2012-07-21 20:48:45 --> Output Class Initialized
DEBUG - 2012-07-21 20:48:45 --> Security Class Initialized
DEBUG - 2012-07-21 20:48:45 --> Input Class Initialized
DEBUG - 2012-07-21 20:48:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 20:48:45 --> Language Class Initialized
DEBUG - 2012-07-21 20:48:45 --> Loader Class Initialized
DEBUG - 2012-07-21 20:48:45 --> Helper loaded: url_helper
DEBUG - 2012-07-21 20:48:45 --> Controller Class Initialized
DEBUG - 2012-07-21 20:48:45 --> Model Class Initialized
DEBUG - 2012-07-21 20:48:45 --> Database Driver Class Initialized
DEBUG - 2012-07-21 20:48:47 --> Config Class Initialized
DEBUG - 2012-07-21 20:48:47 --> Hooks Class Initialized
DEBUG - 2012-07-21 20:48:47 --> Utf8 Class Initialized
DEBUG - 2012-07-21 20:48:47 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 20:48:47 --> URI Class Initialized
DEBUG - 2012-07-21 20:48:47 --> Router Class Initialized
DEBUG - 2012-07-21 20:48:47 --> Output Class Initialized
DEBUG - 2012-07-21 20:48:47 --> Security Class Initialized
DEBUG - 2012-07-21 20:48:47 --> Input Class Initialized
DEBUG - 2012-07-21 20:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 20:48:47 --> Language Class Initialized
DEBUG - 2012-07-21 20:48:47 --> Loader Class Initialized
DEBUG - 2012-07-21 20:48:47 --> Helper loaded: url_helper
DEBUG - 2012-07-21 20:48:47 --> Controller Class Initialized
DEBUG - 2012-07-21 20:48:47 --> Model Class Initialized
DEBUG - 2012-07-21 20:48:47 --> Database Driver Class Initialized
DEBUG - 2012-07-21 20:49:01 --> Config Class Initialized
DEBUG - 2012-07-21 20:49:01 --> Hooks Class Initialized
DEBUG - 2012-07-21 20:49:01 --> Utf8 Class Initialized
DEBUG - 2012-07-21 20:49:01 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 20:49:01 --> URI Class Initialized
DEBUG - 2012-07-21 20:49:01 --> Router Class Initialized
DEBUG - 2012-07-21 20:49:01 --> Output Class Initialized
DEBUG - 2012-07-21 20:49:01 --> Security Class Initialized
DEBUG - 2012-07-21 20:49:01 --> Input Class Initialized
DEBUG - 2012-07-21 20:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 20:49:01 --> Language Class Initialized
DEBUG - 2012-07-21 20:49:01 --> Loader Class Initialized
DEBUG - 2012-07-21 20:49:01 --> Helper loaded: url_helper
DEBUG - 2012-07-21 20:49:01 --> Controller Class Initialized
DEBUG - 2012-07-21 20:49:01 --> Model Class Initialized
DEBUG - 2012-07-21 20:49:01 --> Database Driver Class Initialized
DEBUG - 2012-07-21 20:49:01 --> Helper loaded: form_helper
ERROR - 2012-07-21 20:49:01 --> Severity: Notice  --> Undefined property: Pricing::$business_model /home/jwp/www/justinwylliephotography.com/clients/application/controllers/admin/pricing.php 26
DEBUG - 2012-07-21 20:59:32 --> Config Class Initialized
DEBUG - 2012-07-21 20:59:32 --> Hooks Class Initialized
DEBUG - 2012-07-21 20:59:32 --> Utf8 Class Initialized
DEBUG - 2012-07-21 20:59:32 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 20:59:32 --> URI Class Initialized
DEBUG - 2012-07-21 20:59:32 --> Router Class Initialized
DEBUG - 2012-07-21 20:59:32 --> Output Class Initialized
DEBUG - 2012-07-21 20:59:32 --> Security Class Initialized
DEBUG - 2012-07-21 20:59:32 --> Input Class Initialized
DEBUG - 2012-07-21 20:59:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 20:59:32 --> Language Class Initialized
DEBUG - 2012-07-21 20:59:34 --> Config Class Initialized
DEBUG - 2012-07-21 20:59:34 --> Hooks Class Initialized
DEBUG - 2012-07-21 20:59:34 --> Utf8 Class Initialized
DEBUG - 2012-07-21 20:59:34 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 20:59:34 --> URI Class Initialized
DEBUG - 2012-07-21 20:59:34 --> Router Class Initialized
DEBUG - 2012-07-21 20:59:34 --> Output Class Initialized
DEBUG - 2012-07-21 20:59:34 --> Security Class Initialized
DEBUG - 2012-07-21 20:59:34 --> Input Class Initialized
DEBUG - 2012-07-21 20:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 20:59:34 --> Language Class Initialized
DEBUG - 2012-07-21 21:04:49 --> Config Class Initialized
DEBUG - 2012-07-21 21:04:49 --> Hooks Class Initialized
DEBUG - 2012-07-21 21:04:49 --> Utf8 Class Initialized
DEBUG - 2012-07-21 21:04:49 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 21:04:49 --> URI Class Initialized
DEBUG - 2012-07-21 21:04:49 --> Router Class Initialized
DEBUG - 2012-07-21 21:04:49 --> Output Class Initialized
DEBUG - 2012-07-21 21:04:49 --> Security Class Initialized
DEBUG - 2012-07-21 21:04:49 --> Input Class Initialized
DEBUG - 2012-07-21 21:04:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 21:04:49 --> Language Class Initialized
DEBUG - 2012-07-21 21:05:42 --> Config Class Initialized
DEBUG - 2012-07-21 21:05:42 --> Hooks Class Initialized
DEBUG - 2012-07-21 21:05:42 --> Utf8 Class Initialized
DEBUG - 2012-07-21 21:05:42 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 21:05:42 --> URI Class Initialized
DEBUG - 2012-07-21 21:05:42 --> Router Class Initialized
DEBUG - 2012-07-21 21:05:42 --> Output Class Initialized
DEBUG - 2012-07-21 21:05:42 --> Security Class Initialized
DEBUG - 2012-07-21 21:05:42 --> Input Class Initialized
DEBUG - 2012-07-21 21:05:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 21:05:42 --> Language Class Initialized
DEBUG - 2012-07-21 21:05:42 --> Loader Class Initialized
DEBUG - 2012-07-21 21:05:42 --> Helper loaded: url_helper
DEBUG - 2012-07-21 21:05:42 --> Controller Class Initialized
DEBUG - 2012-07-21 21:05:42 --> Model Class Initialized
DEBUG - 2012-07-21 21:05:42 --> Database Driver Class Initialized
DEBUG - 2012-07-21 21:05:42 --> Helper loaded: form_helper
DEBUG - 2012-07-21 21:05:42 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 21:05:42 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-21 21:05:42 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 21:06:03 --> Config Class Initialized
DEBUG - 2012-07-21 21:06:03 --> Hooks Class Initialized
DEBUG - 2012-07-21 21:06:03 --> Utf8 Class Initialized
DEBUG - 2012-07-21 21:06:03 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 21:06:03 --> URI Class Initialized
DEBUG - 2012-07-21 21:06:03 --> Router Class Initialized
DEBUG - 2012-07-21 21:06:03 --> Output Class Initialized
DEBUG - 2012-07-21 21:06:03 --> Security Class Initialized
DEBUG - 2012-07-21 21:06:03 --> Input Class Initialized
DEBUG - 2012-07-21 21:06:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 21:06:03 --> Language Class Initialized
DEBUG - 2012-07-21 21:06:03 --> Loader Class Initialized
DEBUG - 2012-07-21 21:06:03 --> Helper loaded: url_helper
DEBUG - 2012-07-21 21:06:03 --> Controller Class Initialized
DEBUG - 2012-07-21 21:06:03 --> Model Class Initialized
DEBUG - 2012-07-21 21:06:03 --> Database Driver Class Initialized
DEBUG - 2012-07-21 21:06:03 --> Helper loaded: form_helper
DEBUG - 2012-07-21 21:06:03 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 21:06:03 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-21 21:06:03 --> File loaded: application/views/admin/templates/left_menu.php
ERROR - 2012-07-21 21:06:03 --> Severity: Notice  --> Undefined variable: siteOwner /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/prints.php 11
ERROR - 2012-07-21 21:06:03 --> Severity: Notice  --> Undefined variable: siteOwner /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/prints.php 15
ERROR - 2012-07-21 21:06:03 --> Severity: Notice  --> Undefined variable: siteOwner /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/prints.php 19
ERROR - 2012-07-21 21:06:03 --> Severity: Notice  --> Undefined variable: siteOwner /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/prints.php 24
ERROR - 2012-07-21 21:06:03 --> Severity: Notice  --> Undefined variable: siteOwner /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/prints.php 30
ERROR - 2012-07-21 21:06:03 --> Severity: Notice  --> Undefined variable: siteOwner /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/prints.php 35
ERROR - 2012-07-21 21:06:03 --> Severity: Notice  --> Undefined variable: siteOwner /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/prints.php 39
ERROR - 2012-07-21 21:06:03 --> Severity: Notice  --> Undefined variable: siteOwner /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/prints.php 46
DEBUG - 2012-07-21 21:06:03 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-21 21:06:03 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 21:06:03 --> Final output sent to browser
DEBUG - 2012-07-21 21:06:03 --> Total execution time: 0.0472
DEBUG - 2012-07-21 21:07:11 --> Config Class Initialized
DEBUG - 2012-07-21 21:07:11 --> Hooks Class Initialized
DEBUG - 2012-07-21 21:07:11 --> Utf8 Class Initialized
DEBUG - 2012-07-21 21:07:11 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 21:07:11 --> URI Class Initialized
DEBUG - 2012-07-21 21:07:11 --> Router Class Initialized
DEBUG - 2012-07-21 21:07:11 --> Output Class Initialized
DEBUG - 2012-07-21 21:07:11 --> Security Class Initialized
DEBUG - 2012-07-21 21:07:11 --> Input Class Initialized
DEBUG - 2012-07-21 21:07:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 21:07:11 --> Language Class Initialized
DEBUG - 2012-07-21 21:07:11 --> Loader Class Initialized
DEBUG - 2012-07-21 21:07:11 --> Helper loaded: url_helper
DEBUG - 2012-07-21 21:07:11 --> Controller Class Initialized
DEBUG - 2012-07-21 21:07:11 --> Model Class Initialized
DEBUG - 2012-07-21 21:07:11 --> Database Driver Class Initialized
DEBUG - 2012-07-21 21:07:11 --> Helper loaded: form_helper
DEBUG - 2012-07-21 21:07:11 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 21:07:11 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-21 21:07:11 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 21:07:11 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-21 21:07:11 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 21:07:11 --> Final output sent to browser
DEBUG - 2012-07-21 21:07:11 --> Total execution time: 0.0496
DEBUG - 2012-07-21 21:07:31 --> Config Class Initialized
DEBUG - 2012-07-21 21:07:31 --> Hooks Class Initialized
DEBUG - 2012-07-21 21:07:31 --> Utf8 Class Initialized
DEBUG - 2012-07-21 21:07:31 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 21:07:31 --> URI Class Initialized
DEBUG - 2012-07-21 21:07:31 --> Router Class Initialized
DEBUG - 2012-07-21 21:07:31 --> Output Class Initialized
DEBUG - 2012-07-21 21:07:31 --> Security Class Initialized
DEBUG - 2012-07-21 21:07:31 --> Input Class Initialized
DEBUG - 2012-07-21 21:07:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 21:07:31 --> Language Class Initialized
DEBUG - 2012-07-21 21:07:31 --> Loader Class Initialized
DEBUG - 2012-07-21 21:07:31 --> Helper loaded: url_helper
DEBUG - 2012-07-21 21:07:31 --> Controller Class Initialized
DEBUG - 2012-07-21 21:07:31 --> Model Class Initialized
DEBUG - 2012-07-21 21:07:31 --> Database Driver Class Initialized
DEBUG - 2012-07-21 21:07:31 --> Helper loaded: form_helper
DEBUG - 2012-07-21 21:07:31 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 21:07:31 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-21 21:07:31 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 21:07:31 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-21 21:07:31 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 21:07:31 --> Final output sent to browser
DEBUG - 2012-07-21 21:07:31 --> Total execution time: 0.0390
DEBUG - 2012-07-21 21:07:44 --> Config Class Initialized
DEBUG - 2012-07-21 21:07:44 --> Hooks Class Initialized
DEBUG - 2012-07-21 21:07:44 --> Utf8 Class Initialized
DEBUG - 2012-07-21 21:07:44 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 21:07:44 --> URI Class Initialized
DEBUG - 2012-07-21 21:07:44 --> Router Class Initialized
DEBUG - 2012-07-21 21:07:44 --> Output Class Initialized
DEBUG - 2012-07-21 21:07:44 --> Security Class Initialized
DEBUG - 2012-07-21 21:07:44 --> Input Class Initialized
DEBUG - 2012-07-21 21:07:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 21:07:44 --> Language Class Initialized
DEBUG - 2012-07-21 21:07:44 --> Loader Class Initialized
DEBUG - 2012-07-21 21:07:44 --> Helper loaded: url_helper
DEBUG - 2012-07-21 21:07:44 --> Controller Class Initialized
DEBUG - 2012-07-21 21:07:44 --> Model Class Initialized
DEBUG - 2012-07-21 21:07:44 --> Database Driver Class Initialized
DEBUG - 2012-07-21 21:07:44 --> Helper loaded: form_helper
DEBUG - 2012-07-21 21:07:44 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 21:07:44 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-21 21:07:44 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 21:07:44 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-21 21:07:44 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 21:07:44 --> Final output sent to browser
DEBUG - 2012-07-21 21:07:44 --> Total execution time: 0.0384
DEBUG - 2012-07-21 21:10:07 --> Config Class Initialized
DEBUG - 2012-07-21 21:10:07 --> Hooks Class Initialized
DEBUG - 2012-07-21 21:10:07 --> Utf8 Class Initialized
DEBUG - 2012-07-21 21:10:07 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 21:10:07 --> URI Class Initialized
DEBUG - 2012-07-21 21:10:07 --> Router Class Initialized
DEBUG - 2012-07-21 21:10:07 --> Output Class Initialized
DEBUG - 2012-07-21 21:10:07 --> Security Class Initialized
DEBUG - 2012-07-21 21:10:07 --> Input Class Initialized
DEBUG - 2012-07-21 21:10:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 21:10:07 --> Language Class Initialized
DEBUG - 2012-07-21 21:10:07 --> Loader Class Initialized
DEBUG - 2012-07-21 21:10:07 --> Helper loaded: url_helper
DEBUG - 2012-07-21 21:10:07 --> Controller Class Initialized
DEBUG - 2012-07-21 21:10:07 --> Model Class Initialized
DEBUG - 2012-07-21 21:10:07 --> Database Driver Class Initialized
DEBUG - 2012-07-21 21:10:07 --> Helper loaded: form_helper
DEBUG - 2012-07-21 21:10:07 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 21:10:07 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-21 21:10:07 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 21:10:07 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-21 21:10:07 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 21:10:07 --> Final output sent to browser
DEBUG - 2012-07-21 21:10:07 --> Total execution time: 0.0396
DEBUG - 2012-07-21 21:11:59 --> Config Class Initialized
DEBUG - 2012-07-21 21:11:59 --> Hooks Class Initialized
DEBUG - 2012-07-21 21:11:59 --> Utf8 Class Initialized
DEBUG - 2012-07-21 21:11:59 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 21:11:59 --> URI Class Initialized
DEBUG - 2012-07-21 21:11:59 --> Router Class Initialized
DEBUG - 2012-07-21 21:11:59 --> Output Class Initialized
DEBUG - 2012-07-21 21:11:59 --> Security Class Initialized
DEBUG - 2012-07-21 21:11:59 --> Input Class Initialized
DEBUG - 2012-07-21 21:11:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 21:11:59 --> Language Class Initialized
DEBUG - 2012-07-21 21:11:59 --> Loader Class Initialized
DEBUG - 2012-07-21 21:11:59 --> Helper loaded: url_helper
DEBUG - 2012-07-21 21:11:59 --> Controller Class Initialized
DEBUG - 2012-07-21 21:11:59 --> Model Class Initialized
DEBUG - 2012-07-21 21:11:59 --> Database Driver Class Initialized
DEBUG - 2012-07-21 21:11:59 --> Helper loaded: form_helper
DEBUG - 2012-07-21 21:11:59 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 21:11:59 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-21 21:11:59 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 21:11:59 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-21 21:11:59 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 21:11:59 --> Final output sent to browser
DEBUG - 2012-07-21 21:11:59 --> Total execution time: 0.0393
DEBUG - 2012-07-21 21:12:04 --> Config Class Initialized
DEBUG - 2012-07-21 21:12:04 --> Hooks Class Initialized
DEBUG - 2012-07-21 21:12:04 --> Utf8 Class Initialized
DEBUG - 2012-07-21 21:12:04 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 21:12:04 --> URI Class Initialized
DEBUG - 2012-07-21 21:12:04 --> Router Class Initialized
DEBUG - 2012-07-21 21:12:04 --> Output Class Initialized
DEBUG - 2012-07-21 21:12:04 --> Security Class Initialized
DEBUG - 2012-07-21 21:12:04 --> Input Class Initialized
DEBUG - 2012-07-21 21:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 21:12:04 --> Language Class Initialized
DEBUG - 2012-07-21 21:12:04 --> Loader Class Initialized
DEBUG - 2012-07-21 21:12:04 --> Helper loaded: url_helper
DEBUG - 2012-07-21 21:12:04 --> Controller Class Initialized
DEBUG - 2012-07-21 21:12:04 --> Model Class Initialized
DEBUG - 2012-07-21 21:12:04 --> Database Driver Class Initialized
DEBUG - 2012-07-21 21:12:04 --> Helper loaded: form_helper
DEBUG - 2012-07-21 21:12:04 --> Helper loaded: html_helper
DEBUG - 2012-07-21 21:12:04 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-21 21:12:04 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-21 21:12:04 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-21 21:12:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-21 21:12:04 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-21 21:12:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-21 21:12:04 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-21 21:12:04 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-21 21:12:04 --> Final output sent to browser
DEBUG - 2012-07-21 21:12:04 --> Total execution time: 0.0397
DEBUG - 2012-07-21 21:12:11 --> Config Class Initialized
DEBUG - 2012-07-21 21:12:11 --> Hooks Class Initialized
DEBUG - 2012-07-21 21:12:11 --> Utf8 Class Initialized
DEBUG - 2012-07-21 21:12:11 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 21:12:11 --> URI Class Initialized
DEBUG - 2012-07-21 21:12:11 --> Router Class Initialized
DEBUG - 2012-07-21 21:12:11 --> Output Class Initialized
DEBUG - 2012-07-21 21:12:11 --> Security Class Initialized
DEBUG - 2012-07-21 21:12:11 --> Input Class Initialized
DEBUG - 2012-07-21 21:12:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 21:12:11 --> Language Class Initialized
DEBUG - 2012-07-21 21:12:11 --> Loader Class Initialized
DEBUG - 2012-07-21 21:12:11 --> Helper loaded: url_helper
DEBUG - 2012-07-21 21:12:11 --> Controller Class Initialized
DEBUG - 2012-07-21 21:12:11 --> Model Class Initialized
DEBUG - 2012-07-21 21:12:11 --> Database Driver Class Initialized
DEBUG - 2012-07-21 21:12:11 --> Helper loaded: form_helper
DEBUG - 2012-07-21 21:12:11 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 21:12:11 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-21 21:12:11 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 21:12:11 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-21 21:12:11 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 21:12:11 --> Final output sent to browser
DEBUG - 2012-07-21 21:12:11 --> Total execution time: 0.0390
DEBUG - 2012-07-21 21:15:44 --> Config Class Initialized
DEBUG - 2012-07-21 21:15:44 --> Hooks Class Initialized
DEBUG - 2012-07-21 21:15:44 --> Utf8 Class Initialized
DEBUG - 2012-07-21 21:15:44 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 21:15:44 --> URI Class Initialized
DEBUG - 2012-07-21 21:15:44 --> Router Class Initialized
DEBUG - 2012-07-21 21:15:44 --> Output Class Initialized
DEBUG - 2012-07-21 21:15:44 --> Security Class Initialized
DEBUG - 2012-07-21 21:15:44 --> Input Class Initialized
DEBUG - 2012-07-21 21:15:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 21:15:44 --> Language Class Initialized
DEBUG - 2012-07-21 21:15:44 --> Loader Class Initialized
DEBUG - 2012-07-21 21:15:44 --> Helper loaded: url_helper
DEBUG - 2012-07-21 21:15:44 --> Controller Class Initialized
DEBUG - 2012-07-21 21:15:44 --> Model Class Initialized
DEBUG - 2012-07-21 21:15:44 --> Database Driver Class Initialized
DEBUG - 2012-07-21 21:15:44 --> Helper loaded: form_helper
DEBUG - 2012-07-21 21:15:44 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 21:15:44 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-21 21:15:44 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 21:15:44 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-21 21:15:44 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 21:15:44 --> Final output sent to browser
DEBUG - 2012-07-21 21:15:44 --> Total execution time: 0.0479
DEBUG - 2012-07-21 21:16:35 --> Config Class Initialized
DEBUG - 2012-07-21 21:16:35 --> Hooks Class Initialized
DEBUG - 2012-07-21 21:16:35 --> Utf8 Class Initialized
DEBUG - 2012-07-21 21:16:35 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 21:16:35 --> URI Class Initialized
DEBUG - 2012-07-21 21:16:35 --> Router Class Initialized
DEBUG - 2012-07-21 21:16:35 --> Output Class Initialized
DEBUG - 2012-07-21 21:16:35 --> Security Class Initialized
DEBUG - 2012-07-21 21:16:35 --> Input Class Initialized
DEBUG - 2012-07-21 21:16:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 21:16:35 --> Language Class Initialized
DEBUG - 2012-07-21 21:16:35 --> Loader Class Initialized
DEBUG - 2012-07-21 21:16:35 --> Helper loaded: url_helper
DEBUG - 2012-07-21 21:16:35 --> Controller Class Initialized
DEBUG - 2012-07-21 21:16:35 --> Model Class Initialized
DEBUG - 2012-07-21 21:16:35 --> Database Driver Class Initialized
DEBUG - 2012-07-21 21:16:35 --> Helper loaded: form_helper
DEBUG - 2012-07-21 21:16:35 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 21:16:35 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-21 21:16:35 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 21:16:35 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-21 21:16:35 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 21:16:35 --> Final output sent to browser
DEBUG - 2012-07-21 21:16:35 --> Total execution time: 0.0387
DEBUG - 2012-07-21 21:18:18 --> Config Class Initialized
DEBUG - 2012-07-21 21:18:18 --> Hooks Class Initialized
DEBUG - 2012-07-21 21:18:18 --> Utf8 Class Initialized
DEBUG - 2012-07-21 21:18:18 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 21:18:18 --> URI Class Initialized
DEBUG - 2012-07-21 21:18:18 --> Router Class Initialized
DEBUG - 2012-07-21 21:18:18 --> Output Class Initialized
DEBUG - 2012-07-21 21:18:18 --> Security Class Initialized
DEBUG - 2012-07-21 21:18:18 --> Input Class Initialized
DEBUG - 2012-07-21 21:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 21:18:18 --> Language Class Initialized
DEBUG - 2012-07-21 21:18:18 --> Loader Class Initialized
DEBUG - 2012-07-21 21:18:18 --> Helper loaded: url_helper
DEBUG - 2012-07-21 21:18:18 --> Controller Class Initialized
DEBUG - 2012-07-21 21:18:18 --> Model Class Initialized
DEBUG - 2012-07-21 21:18:18 --> Database Driver Class Initialized
DEBUG - 2012-07-21 21:18:18 --> Helper loaded: form_helper
DEBUG - 2012-07-21 21:18:18 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 21:18:18 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-21 21:18:18 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 21:18:18 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-21 21:18:18 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 21:18:18 --> Final output sent to browser
DEBUG - 2012-07-21 21:18:18 --> Total execution time: 0.0431
DEBUG - 2012-07-21 21:18:54 --> Config Class Initialized
DEBUG - 2012-07-21 21:18:54 --> Hooks Class Initialized
DEBUG - 2012-07-21 21:18:54 --> Utf8 Class Initialized
DEBUG - 2012-07-21 21:18:54 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 21:18:54 --> URI Class Initialized
DEBUG - 2012-07-21 21:18:54 --> Router Class Initialized
DEBUG - 2012-07-21 21:18:54 --> Output Class Initialized
DEBUG - 2012-07-21 21:18:54 --> Security Class Initialized
DEBUG - 2012-07-21 21:18:54 --> Input Class Initialized
DEBUG - 2012-07-21 21:18:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 21:18:54 --> Language Class Initialized
DEBUG - 2012-07-21 21:18:54 --> Loader Class Initialized
DEBUG - 2012-07-21 21:18:54 --> Helper loaded: url_helper
DEBUG - 2012-07-21 21:18:54 --> Controller Class Initialized
DEBUG - 2012-07-21 21:18:54 --> Model Class Initialized
DEBUG - 2012-07-21 21:18:54 --> Database Driver Class Initialized
DEBUG - 2012-07-21 21:18:54 --> Helper loaded: form_helper
DEBUG - 2012-07-21 21:18:54 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 21:18:54 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 21:18:54 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-21 21:18:54 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 21:18:54 --> Final output sent to browser
DEBUG - 2012-07-21 21:18:54 --> Total execution time: 0.0387
DEBUG - 2012-07-21 22:15:23 --> Config Class Initialized
DEBUG - 2012-07-21 22:15:23 --> Hooks Class Initialized
DEBUG - 2012-07-21 22:15:23 --> Utf8 Class Initialized
DEBUG - 2012-07-21 22:15:23 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 22:15:23 --> URI Class Initialized
DEBUG - 2012-07-21 22:15:23 --> Router Class Initialized
DEBUG - 2012-07-21 22:15:23 --> Output Class Initialized
DEBUG - 2012-07-21 22:15:23 --> Security Class Initialized
DEBUG - 2012-07-21 22:15:23 --> Input Class Initialized
DEBUG - 2012-07-21 22:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 22:15:23 --> Language Class Initialized
DEBUG - 2012-07-21 22:15:23 --> Loader Class Initialized
DEBUG - 2012-07-21 22:15:23 --> Helper loaded: url_helper
DEBUG - 2012-07-21 22:15:23 --> Controller Class Initialized
DEBUG - 2012-07-21 22:15:23 --> Model Class Initialized
DEBUG - 2012-07-21 22:15:23 --> Database Driver Class Initialized
DEBUG - 2012-07-21 22:15:23 --> Helper loaded: form_helper
DEBUG - 2012-07-21 22:15:23 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 22:15:23 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 22:16:35 --> Config Class Initialized
DEBUG - 2012-07-21 22:16:35 --> Hooks Class Initialized
DEBUG - 2012-07-21 22:16:35 --> Utf8 Class Initialized
DEBUG - 2012-07-21 22:16:35 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 22:16:35 --> URI Class Initialized
DEBUG - 2012-07-21 22:16:35 --> Router Class Initialized
DEBUG - 2012-07-21 22:16:35 --> Output Class Initialized
DEBUG - 2012-07-21 22:16:35 --> Security Class Initialized
DEBUG - 2012-07-21 22:16:35 --> Input Class Initialized
DEBUG - 2012-07-21 22:16:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 22:16:35 --> Language Class Initialized
DEBUG - 2012-07-21 22:16:35 --> Loader Class Initialized
DEBUG - 2012-07-21 22:16:35 --> Helper loaded: url_helper
DEBUG - 2012-07-21 22:16:35 --> Controller Class Initialized
DEBUG - 2012-07-21 22:16:35 --> Model Class Initialized
DEBUG - 2012-07-21 22:16:35 --> Database Driver Class Initialized
DEBUG - 2012-07-21 22:16:35 --> Helper loaded: form_helper
DEBUG - 2012-07-21 22:16:36 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 22:16:36 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 22:16:37 --> Config Class Initialized
DEBUG - 2012-07-21 22:16:37 --> Hooks Class Initialized
DEBUG - 2012-07-21 22:16:37 --> Utf8 Class Initialized
DEBUG - 2012-07-21 22:16:37 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 22:16:37 --> URI Class Initialized
DEBUG - 2012-07-21 22:16:37 --> Router Class Initialized
DEBUG - 2012-07-21 22:16:37 --> Output Class Initialized
DEBUG - 2012-07-21 22:16:37 --> Security Class Initialized
DEBUG - 2012-07-21 22:16:37 --> Input Class Initialized
DEBUG - 2012-07-21 22:16:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 22:16:37 --> Language Class Initialized
DEBUG - 2012-07-21 22:16:37 --> Loader Class Initialized
DEBUG - 2012-07-21 22:16:37 --> Helper loaded: url_helper
DEBUG - 2012-07-21 22:16:37 --> Controller Class Initialized
DEBUG - 2012-07-21 22:16:37 --> Model Class Initialized
DEBUG - 2012-07-21 22:16:37 --> Database Driver Class Initialized
DEBUG - 2012-07-21 22:16:37 --> Helper loaded: form_helper
DEBUG - 2012-07-21 22:16:37 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 22:16:37 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 22:17:08 --> Config Class Initialized
DEBUG - 2012-07-21 22:17:08 --> Hooks Class Initialized
DEBUG - 2012-07-21 22:17:08 --> Utf8 Class Initialized
DEBUG - 2012-07-21 22:17:08 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 22:17:08 --> URI Class Initialized
DEBUG - 2012-07-21 22:17:08 --> Router Class Initialized
DEBUG - 2012-07-21 22:17:08 --> Output Class Initialized
DEBUG - 2012-07-21 22:17:08 --> Security Class Initialized
DEBUG - 2012-07-21 22:17:08 --> Input Class Initialized
DEBUG - 2012-07-21 22:17:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 22:17:08 --> Language Class Initialized
DEBUG - 2012-07-21 22:17:08 --> Loader Class Initialized
DEBUG - 2012-07-21 22:17:08 --> Helper loaded: url_helper
DEBUG - 2012-07-21 22:17:08 --> Controller Class Initialized
DEBUG - 2012-07-21 22:17:08 --> Model Class Initialized
DEBUG - 2012-07-21 22:17:08 --> Database Driver Class Initialized
DEBUG - 2012-07-21 22:17:08 --> Helper loaded: form_helper
DEBUG - 2012-07-21 22:17:08 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 22:17:08 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 22:17:09 --> Config Class Initialized
DEBUG - 2012-07-21 22:17:09 --> Hooks Class Initialized
DEBUG - 2012-07-21 22:17:09 --> Utf8 Class Initialized
DEBUG - 2012-07-21 22:17:09 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 22:17:09 --> URI Class Initialized
DEBUG - 2012-07-21 22:17:09 --> Router Class Initialized
DEBUG - 2012-07-21 22:17:09 --> Output Class Initialized
DEBUG - 2012-07-21 22:17:09 --> Security Class Initialized
DEBUG - 2012-07-21 22:17:09 --> Input Class Initialized
DEBUG - 2012-07-21 22:17:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 22:17:09 --> Language Class Initialized
DEBUG - 2012-07-21 22:17:09 --> Loader Class Initialized
DEBUG - 2012-07-21 22:17:09 --> Helper loaded: url_helper
DEBUG - 2012-07-21 22:17:09 --> Controller Class Initialized
DEBUG - 2012-07-21 22:17:09 --> Model Class Initialized
DEBUG - 2012-07-21 22:17:09 --> Database Driver Class Initialized
DEBUG - 2012-07-21 22:17:09 --> Helper loaded: form_helper
DEBUG - 2012-07-21 22:17:09 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 22:17:09 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 22:18:35 --> Config Class Initialized
DEBUG - 2012-07-21 22:18:35 --> Hooks Class Initialized
DEBUG - 2012-07-21 22:18:35 --> Utf8 Class Initialized
DEBUG - 2012-07-21 22:18:35 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 22:18:35 --> URI Class Initialized
DEBUG - 2012-07-21 22:18:35 --> Router Class Initialized
DEBUG - 2012-07-21 22:18:35 --> Output Class Initialized
DEBUG - 2012-07-21 22:18:35 --> Security Class Initialized
DEBUG - 2012-07-21 22:18:35 --> Input Class Initialized
DEBUG - 2012-07-21 22:18:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 22:18:35 --> Language Class Initialized
DEBUG - 2012-07-21 22:18:35 --> Loader Class Initialized
DEBUG - 2012-07-21 22:18:35 --> Helper loaded: url_helper
DEBUG - 2012-07-21 22:18:35 --> Controller Class Initialized
DEBUG - 2012-07-21 22:18:35 --> Model Class Initialized
DEBUG - 2012-07-21 22:18:35 --> Database Driver Class Initialized
DEBUG - 2012-07-21 22:18:35 --> Helper loaded: form_helper
DEBUG - 2012-07-21 22:18:35 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 22:18:35 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 22:18:43 --> Config Class Initialized
DEBUG - 2012-07-21 22:18:43 --> Hooks Class Initialized
DEBUG - 2012-07-21 22:18:43 --> Utf8 Class Initialized
DEBUG - 2012-07-21 22:18:43 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 22:18:43 --> URI Class Initialized
DEBUG - 2012-07-21 22:18:43 --> Router Class Initialized
DEBUG - 2012-07-21 22:18:43 --> Output Class Initialized
DEBUG - 2012-07-21 22:18:43 --> Security Class Initialized
DEBUG - 2012-07-21 22:18:43 --> Input Class Initialized
DEBUG - 2012-07-21 22:18:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 22:18:43 --> Language Class Initialized
DEBUG - 2012-07-21 22:18:43 --> Loader Class Initialized
DEBUG - 2012-07-21 22:18:43 --> Helper loaded: url_helper
DEBUG - 2012-07-21 22:18:43 --> Controller Class Initialized
DEBUG - 2012-07-21 22:18:43 --> Model Class Initialized
DEBUG - 2012-07-21 22:18:43 --> Database Driver Class Initialized
DEBUG - 2012-07-21 22:18:43 --> Helper loaded: form_helper
DEBUG - 2012-07-21 22:18:43 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 22:18:43 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 22:19:32 --> Config Class Initialized
DEBUG - 2012-07-21 22:19:32 --> Hooks Class Initialized
DEBUG - 2012-07-21 22:19:32 --> Utf8 Class Initialized
DEBUG - 2012-07-21 22:19:32 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 22:19:32 --> URI Class Initialized
DEBUG - 2012-07-21 22:19:32 --> Router Class Initialized
DEBUG - 2012-07-21 22:19:32 --> Output Class Initialized
DEBUG - 2012-07-21 22:19:32 --> Security Class Initialized
DEBUG - 2012-07-21 22:19:32 --> Input Class Initialized
DEBUG - 2012-07-21 22:19:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 22:19:32 --> Language Class Initialized
DEBUG - 2012-07-21 22:19:32 --> Loader Class Initialized
DEBUG - 2012-07-21 22:19:32 --> Helper loaded: url_helper
DEBUG - 2012-07-21 22:19:32 --> Controller Class Initialized
DEBUG - 2012-07-21 22:19:32 --> Model Class Initialized
DEBUG - 2012-07-21 22:19:32 --> Database Driver Class Initialized
DEBUG - 2012-07-21 22:19:32 --> Helper loaded: form_helper
DEBUG - 2012-07-21 22:19:32 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 22:19:32 --> File loaded: application/views/admin/templates/left_menu.php
ERROR - 2012-07-21 22:19:32 --> Severity: Notice  --> Undefined variable: base_url /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/prints.php 12
DEBUG - 2012-07-21 22:19:54 --> Config Class Initialized
DEBUG - 2012-07-21 22:19:54 --> Hooks Class Initialized
DEBUG - 2012-07-21 22:19:54 --> Utf8 Class Initialized
DEBUG - 2012-07-21 22:19:54 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 22:19:54 --> URI Class Initialized
DEBUG - 2012-07-21 22:19:54 --> Router Class Initialized
DEBUG - 2012-07-21 22:19:54 --> Output Class Initialized
DEBUG - 2012-07-21 22:19:54 --> Security Class Initialized
DEBUG - 2012-07-21 22:19:54 --> Input Class Initialized
DEBUG - 2012-07-21 22:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 22:19:54 --> Language Class Initialized
DEBUG - 2012-07-21 22:19:54 --> Loader Class Initialized
DEBUG - 2012-07-21 22:19:54 --> Helper loaded: url_helper
DEBUG - 2012-07-21 22:19:54 --> Controller Class Initialized
DEBUG - 2012-07-21 22:19:54 --> Model Class Initialized
DEBUG - 2012-07-21 22:19:54 --> Database Driver Class Initialized
DEBUG - 2012-07-21 22:19:54 --> Helper loaded: form_helper
DEBUG - 2012-07-21 22:19:54 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 22:19:54 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 22:19:54 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-21 22:19:54 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 22:19:54 --> Final output sent to browser
DEBUG - 2012-07-21 22:19:54 --> Total execution time: 0.0385
DEBUG - 2012-07-21 22:20:07 --> Config Class Initialized
DEBUG - 2012-07-21 22:20:07 --> Hooks Class Initialized
DEBUG - 2012-07-21 22:20:07 --> Utf8 Class Initialized
DEBUG - 2012-07-21 22:20:07 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 22:20:07 --> URI Class Initialized
DEBUG - 2012-07-21 22:20:07 --> Router Class Initialized
DEBUG - 2012-07-21 22:20:07 --> Output Class Initialized
DEBUG - 2012-07-21 22:20:07 --> Security Class Initialized
DEBUG - 2012-07-21 22:20:07 --> Input Class Initialized
DEBUG - 2012-07-21 22:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 22:20:07 --> Language Class Initialized
DEBUG - 2012-07-21 22:20:07 --> Loader Class Initialized
DEBUG - 2012-07-21 22:20:07 --> Helper loaded: url_helper
DEBUG - 2012-07-21 22:20:07 --> Controller Class Initialized
DEBUG - 2012-07-21 22:20:07 --> Model Class Initialized
DEBUG - 2012-07-21 22:20:07 --> Database Driver Class Initialized
DEBUG - 2012-07-21 22:20:07 --> Helper loaded: form_helper
DEBUG - 2012-07-21 22:20:07 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 22:20:07 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-21 22:20:07 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 22:20:07 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-07-21 22:20:07 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 22:20:07 --> Final output sent to browser
DEBUG - 2012-07-21 22:20:07 --> Total execution time: 0.0394
DEBUG - 2012-07-21 22:20:14 --> Config Class Initialized
DEBUG - 2012-07-21 22:20:14 --> Hooks Class Initialized
DEBUG - 2012-07-21 22:20:14 --> Utf8 Class Initialized
DEBUG - 2012-07-21 22:20:14 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 22:20:14 --> URI Class Initialized
DEBUG - 2012-07-21 22:20:14 --> Router Class Initialized
DEBUG - 2012-07-21 22:20:14 --> Output Class Initialized
DEBUG - 2012-07-21 22:20:14 --> Security Class Initialized
DEBUG - 2012-07-21 22:20:14 --> Input Class Initialized
DEBUG - 2012-07-21 22:20:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 22:20:14 --> Language Class Initialized
DEBUG - 2012-07-21 22:20:14 --> Loader Class Initialized
DEBUG - 2012-07-21 22:20:14 --> Helper loaded: url_helper
DEBUG - 2012-07-21 22:20:14 --> Controller Class Initialized
DEBUG - 2012-07-21 22:20:14 --> Model Class Initialized
DEBUG - 2012-07-21 22:20:14 --> Database Driver Class Initialized
DEBUG - 2012-07-21 22:20:14 --> Helper loaded: form_helper
DEBUG - 2012-07-21 22:20:14 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 22:20:14 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 22:20:14 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-21 22:20:14 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 22:20:14 --> Final output sent to browser
DEBUG - 2012-07-21 22:20:14 --> Total execution time: 0.0450
DEBUG - 2012-07-21 22:20:16 --> Config Class Initialized
DEBUG - 2012-07-21 22:20:16 --> Hooks Class Initialized
DEBUG - 2012-07-21 22:20:16 --> Utf8 Class Initialized
DEBUG - 2012-07-21 22:20:16 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 22:20:16 --> URI Class Initialized
DEBUG - 2012-07-21 22:20:16 --> Router Class Initialized
DEBUG - 2012-07-21 22:20:16 --> Output Class Initialized
DEBUG - 2012-07-21 22:20:16 --> Security Class Initialized
DEBUG - 2012-07-21 22:20:16 --> Input Class Initialized
DEBUG - 2012-07-21 22:20:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 22:20:16 --> Language Class Initialized
DEBUG - 2012-07-21 22:20:16 --> Loader Class Initialized
DEBUG - 2012-07-21 22:20:16 --> Helper loaded: url_helper
DEBUG - 2012-07-21 22:20:16 --> Controller Class Initialized
DEBUG - 2012-07-21 22:20:16 --> Model Class Initialized
DEBUG - 2012-07-21 22:20:16 --> Database Driver Class Initialized
DEBUG - 2012-07-21 22:20:16 --> Helper loaded: form_helper
DEBUG - 2012-07-21 22:20:16 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 22:20:16 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-21 22:20:16 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 22:20:16 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-07-21 22:20:16 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 22:20:16 --> Final output sent to browser
DEBUG - 2012-07-21 22:20:16 --> Total execution time: 0.0391
DEBUG - 2012-07-21 22:26:35 --> Config Class Initialized
DEBUG - 2012-07-21 22:26:35 --> Hooks Class Initialized
DEBUG - 2012-07-21 22:26:35 --> Utf8 Class Initialized
DEBUG - 2012-07-21 22:26:35 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 22:26:35 --> URI Class Initialized
DEBUG - 2012-07-21 22:26:35 --> Router Class Initialized
DEBUG - 2012-07-21 22:26:35 --> Output Class Initialized
DEBUG - 2012-07-21 22:26:35 --> Security Class Initialized
DEBUG - 2012-07-21 22:26:35 --> Input Class Initialized
DEBUG - 2012-07-21 22:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 22:26:35 --> Language Class Initialized
DEBUG - 2012-07-21 22:26:35 --> Loader Class Initialized
DEBUG - 2012-07-21 22:26:35 --> Helper loaded: url_helper
DEBUG - 2012-07-21 22:26:35 --> Controller Class Initialized
DEBUG - 2012-07-21 22:26:35 --> Model Class Initialized
DEBUG - 2012-07-21 22:26:35 --> Database Driver Class Initialized
DEBUG - 2012-07-21 22:26:35 --> Helper loaded: form_helper
DEBUG - 2012-07-21 22:26:35 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 22:26:35 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 22:26:35 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-21 22:26:35 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 22:26:35 --> Final output sent to browser
DEBUG - 2012-07-21 22:26:35 --> Total execution time: 0.0383
DEBUG - 2012-07-21 22:26:49 --> Config Class Initialized
DEBUG - 2012-07-21 22:26:49 --> Hooks Class Initialized
DEBUG - 2012-07-21 22:26:49 --> Utf8 Class Initialized
DEBUG - 2012-07-21 22:26:49 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 22:26:49 --> URI Class Initialized
DEBUG - 2012-07-21 22:26:49 --> Router Class Initialized
DEBUG - 2012-07-21 22:26:49 --> Output Class Initialized
DEBUG - 2012-07-21 22:26:49 --> Security Class Initialized
DEBUG - 2012-07-21 22:26:49 --> Input Class Initialized
DEBUG - 2012-07-21 22:26:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 22:26:49 --> Language Class Initialized
DEBUG - 2012-07-21 22:26:49 --> Loader Class Initialized
DEBUG - 2012-07-21 22:26:49 --> Helper loaded: url_helper
DEBUG - 2012-07-21 22:26:49 --> Controller Class Initialized
DEBUG - 2012-07-21 22:26:49 --> Model Class Initialized
DEBUG - 2012-07-21 22:26:49 --> Database Driver Class Initialized
DEBUG - 2012-07-21 22:26:49 --> Helper loaded: form_helper
DEBUG - 2012-07-21 22:26:49 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 22:26:49 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 22:26:49 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-21 22:26:49 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 22:26:49 --> Final output sent to browser
DEBUG - 2012-07-21 22:26:49 --> Total execution time: 0.0383
DEBUG - 2012-07-21 22:28:53 --> Config Class Initialized
DEBUG - 2012-07-21 22:28:53 --> Hooks Class Initialized
DEBUG - 2012-07-21 22:28:53 --> Utf8 Class Initialized
DEBUG - 2012-07-21 22:28:53 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 22:28:53 --> URI Class Initialized
DEBUG - 2012-07-21 22:28:53 --> Router Class Initialized
DEBUG - 2012-07-21 22:28:53 --> Output Class Initialized
DEBUG - 2012-07-21 22:28:53 --> Security Class Initialized
DEBUG - 2012-07-21 22:28:53 --> Input Class Initialized
DEBUG - 2012-07-21 22:28:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 22:28:53 --> Language Class Initialized
DEBUG - 2012-07-21 22:28:53 --> Loader Class Initialized
DEBUG - 2012-07-21 22:28:53 --> Helper loaded: url_helper
DEBUG - 2012-07-21 22:28:53 --> Controller Class Initialized
DEBUG - 2012-07-21 22:28:53 --> Model Class Initialized
DEBUG - 2012-07-21 22:28:53 --> Database Driver Class Initialized
DEBUG - 2012-07-21 22:28:53 --> Helper loaded: form_helper
DEBUG - 2012-07-21 22:28:55 --> Config Class Initialized
DEBUG - 2012-07-21 22:28:55 --> Hooks Class Initialized
DEBUG - 2012-07-21 22:28:55 --> Utf8 Class Initialized
DEBUG - 2012-07-21 22:28:55 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 22:28:55 --> URI Class Initialized
DEBUG - 2012-07-21 22:28:55 --> Router Class Initialized
DEBUG - 2012-07-21 22:28:55 --> Output Class Initialized
DEBUG - 2012-07-21 22:28:55 --> Security Class Initialized
DEBUG - 2012-07-21 22:28:55 --> Input Class Initialized
DEBUG - 2012-07-21 22:28:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 22:28:55 --> Language Class Initialized
DEBUG - 2012-07-21 22:28:55 --> Loader Class Initialized
DEBUG - 2012-07-21 22:28:55 --> Helper loaded: url_helper
DEBUG - 2012-07-21 22:28:55 --> Controller Class Initialized
DEBUG - 2012-07-21 22:28:55 --> Model Class Initialized
DEBUG - 2012-07-21 22:28:55 --> Database Driver Class Initialized
DEBUG - 2012-07-21 22:28:55 --> Helper loaded: form_helper
DEBUG - 2012-07-21 22:28:56 --> Config Class Initialized
DEBUG - 2012-07-21 22:28:56 --> Hooks Class Initialized
DEBUG - 2012-07-21 22:28:56 --> Utf8 Class Initialized
DEBUG - 2012-07-21 22:28:56 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 22:28:56 --> URI Class Initialized
DEBUG - 2012-07-21 22:28:56 --> Router Class Initialized
DEBUG - 2012-07-21 22:28:56 --> Output Class Initialized
DEBUG - 2012-07-21 22:28:56 --> Security Class Initialized
DEBUG - 2012-07-21 22:28:56 --> Input Class Initialized
DEBUG - 2012-07-21 22:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 22:28:56 --> Language Class Initialized
DEBUG - 2012-07-21 22:28:56 --> Loader Class Initialized
DEBUG - 2012-07-21 22:28:56 --> Helper loaded: url_helper
DEBUG - 2012-07-21 22:28:56 --> Controller Class Initialized
DEBUG - 2012-07-21 22:28:56 --> Model Class Initialized
DEBUG - 2012-07-21 22:28:56 --> Database Driver Class Initialized
DEBUG - 2012-07-21 22:28:56 --> Helper loaded: form_helper
DEBUG - 2012-07-21 22:30:03 --> Config Class Initialized
DEBUG - 2012-07-21 22:30:03 --> Hooks Class Initialized
DEBUG - 2012-07-21 22:30:03 --> Utf8 Class Initialized
DEBUG - 2012-07-21 22:30:03 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 22:30:03 --> URI Class Initialized
DEBUG - 2012-07-21 22:30:03 --> Router Class Initialized
DEBUG - 2012-07-21 22:30:03 --> Output Class Initialized
DEBUG - 2012-07-21 22:30:03 --> Security Class Initialized
DEBUG - 2012-07-21 22:30:03 --> Input Class Initialized
DEBUG - 2012-07-21 22:30:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 22:30:03 --> Language Class Initialized
DEBUG - 2012-07-21 22:30:03 --> Loader Class Initialized
DEBUG - 2012-07-21 22:30:03 --> Helper loaded: url_helper
DEBUG - 2012-07-21 22:30:03 --> Controller Class Initialized
DEBUG - 2012-07-21 22:30:03 --> Model Class Initialized
DEBUG - 2012-07-21 22:30:03 --> Database Driver Class Initialized
DEBUG - 2012-07-21 22:30:03 --> Helper loaded: form_helper
DEBUG - 2012-07-21 22:31:42 --> Config Class Initialized
DEBUG - 2012-07-21 22:31:42 --> Hooks Class Initialized
DEBUG - 2012-07-21 22:31:42 --> Utf8 Class Initialized
DEBUG - 2012-07-21 22:31:42 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 22:31:42 --> URI Class Initialized
DEBUG - 2012-07-21 22:31:42 --> Router Class Initialized
DEBUG - 2012-07-21 22:31:42 --> Output Class Initialized
DEBUG - 2012-07-21 22:31:42 --> Security Class Initialized
DEBUG - 2012-07-21 22:31:42 --> Input Class Initialized
DEBUG - 2012-07-21 22:31:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 22:31:42 --> Language Class Initialized
DEBUG - 2012-07-21 22:31:42 --> Loader Class Initialized
DEBUG - 2012-07-21 22:31:42 --> Helper loaded: url_helper
DEBUG - 2012-07-21 22:31:42 --> Controller Class Initialized
DEBUG - 2012-07-21 22:31:42 --> Model Class Initialized
DEBUG - 2012-07-21 22:31:42 --> Database Driver Class Initialized
DEBUG - 2012-07-21 22:31:42 --> Helper loaded: form_helper
DEBUG - 2012-07-21 22:31:42 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 22:31:42 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 22:31:42 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-21 22:31:42 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 22:31:42 --> Final output sent to browser
DEBUG - 2012-07-21 22:31:42 --> Total execution time: 0.0398
DEBUG - 2012-07-21 22:32:34 --> Config Class Initialized
DEBUG - 2012-07-21 22:32:34 --> Hooks Class Initialized
DEBUG - 2012-07-21 22:32:34 --> Utf8 Class Initialized
DEBUG - 2012-07-21 22:32:34 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 22:32:34 --> URI Class Initialized
DEBUG - 2012-07-21 22:32:34 --> Router Class Initialized
DEBUG - 2012-07-21 22:32:34 --> Output Class Initialized
DEBUG - 2012-07-21 22:32:34 --> Security Class Initialized
DEBUG - 2012-07-21 22:32:34 --> Input Class Initialized
DEBUG - 2012-07-21 22:32:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 22:32:34 --> Language Class Initialized
DEBUG - 2012-07-21 22:32:34 --> Loader Class Initialized
DEBUG - 2012-07-21 22:32:34 --> Helper loaded: url_helper
DEBUG - 2012-07-21 22:32:34 --> Controller Class Initialized
DEBUG - 2012-07-21 22:32:34 --> Model Class Initialized
DEBUG - 2012-07-21 22:32:34 --> Database Driver Class Initialized
DEBUG - 2012-07-21 22:32:34 --> Helper loaded: form_helper
DEBUG - 2012-07-21 22:32:34 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 22:32:34 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 22:32:34 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-21 22:32:34 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 22:32:34 --> Final output sent to browser
DEBUG - 2012-07-21 22:32:34 --> Total execution time: 0.0507
DEBUG - 2012-07-21 22:42:18 --> Config Class Initialized
DEBUG - 2012-07-21 22:42:18 --> Hooks Class Initialized
DEBUG - 2012-07-21 22:42:18 --> Utf8 Class Initialized
DEBUG - 2012-07-21 22:42:18 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 22:42:18 --> URI Class Initialized
DEBUG - 2012-07-21 22:42:18 --> Router Class Initialized
DEBUG - 2012-07-21 22:42:18 --> Output Class Initialized
DEBUG - 2012-07-21 22:42:18 --> Security Class Initialized
DEBUG - 2012-07-21 22:42:18 --> Input Class Initialized
DEBUG - 2012-07-21 22:42:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 22:42:18 --> Language Class Initialized
DEBUG - 2012-07-21 22:42:18 --> Loader Class Initialized
DEBUG - 2012-07-21 22:42:18 --> Helper loaded: url_helper
DEBUG - 2012-07-21 22:42:18 --> Controller Class Initialized
DEBUG - 2012-07-21 22:42:18 --> Model Class Initialized
DEBUG - 2012-07-21 22:42:18 --> Database Driver Class Initialized
DEBUG - 2012-07-21 22:42:18 --> Helper loaded: form_helper
DEBUG - 2012-07-21 22:42:18 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 22:42:18 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 22:42:18 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-21 22:42:18 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 22:42:18 --> Final output sent to browser
DEBUG - 2012-07-21 22:42:18 --> Total execution time: 0.0386
DEBUG - 2012-07-21 22:43:48 --> Config Class Initialized
DEBUG - 2012-07-21 22:43:48 --> Hooks Class Initialized
DEBUG - 2012-07-21 22:43:48 --> Utf8 Class Initialized
DEBUG - 2012-07-21 22:43:48 --> UTF-8 Support Disabled
DEBUG - 2012-07-21 22:43:48 --> URI Class Initialized
DEBUG - 2012-07-21 22:43:48 --> Router Class Initialized
DEBUG - 2012-07-21 22:43:48 --> Output Class Initialized
DEBUG - 2012-07-21 22:43:48 --> Security Class Initialized
DEBUG - 2012-07-21 22:43:48 --> Input Class Initialized
DEBUG - 2012-07-21 22:43:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-21 22:43:48 --> Language Class Initialized
DEBUG - 2012-07-21 22:43:48 --> Loader Class Initialized
DEBUG - 2012-07-21 22:43:48 --> Helper loaded: url_helper
DEBUG - 2012-07-21 22:43:48 --> Controller Class Initialized
DEBUG - 2012-07-21 22:43:48 --> Model Class Initialized
DEBUG - 2012-07-21 22:43:48 --> Database Driver Class Initialized
DEBUG - 2012-07-21 22:43:48 --> Helper loaded: form_helper
DEBUG - 2012-07-21 22:43:48 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-21 22:43:48 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-21 22:43:48 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-21 22:43:48 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-21 22:43:48 --> Final output sent to browser
DEBUG - 2012-07-21 22:43:48 --> Total execution time: 0.0384
