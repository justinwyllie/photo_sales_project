<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-07-23 17:58:51 --> Config Class Initialized
DEBUG - 2012-07-23 17:58:51 --> Hooks Class Initialized
DEBUG - 2012-07-23 17:58:51 --> Utf8 Class Initialized
DEBUG - 2012-07-23 17:58:51 --> UTF-8 Support Disabled
DEBUG - 2012-07-23 17:58:51 --> URI Class Initialized
DEBUG - 2012-07-23 17:58:51 --> Router Class Initialized
DEBUG - 2012-07-23 17:58:51 --> Output Class Initialized
DEBUG - 2012-07-23 17:58:51 --> Security Class Initialized
DEBUG - 2012-07-23 17:58:51 --> Input Class Initialized
DEBUG - 2012-07-23 17:58:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-23 17:58:51 --> Language Class Initialized
DEBUG - 2012-07-23 17:58:51 --> Loader Class Initialized
DEBUG - 2012-07-23 17:58:51 --> Helper loaded: url_helper
DEBUG - 2012-07-23 17:58:51 --> Controller Class Initialized
DEBUG - 2012-07-23 17:58:51 --> Model Class Initialized
DEBUG - 2012-07-23 17:58:51 --> Database Driver Class Initialized
DEBUG - 2012-07-23 17:58:52 --> Helper loaded: form_helper
DEBUG - 2012-07-23 17:58:52 --> Helper loaded: html_helper
DEBUG - 2012-07-23 17:58:52 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-23 17:58:52 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-23 17:58:52 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-23 17:58:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-23 17:58:52 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 64
ERROR - 2012-07-23 17:58:52 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-23 17:58:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-23 17:58:52 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-23 17:58:52 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-23 17:58:52 --> Final output sent to browser
DEBUG - 2012-07-23 17:58:52 --> Total execution time: 0.6357
DEBUG - 2012-07-23 18:00:07 --> Config Class Initialized
DEBUG - 2012-07-23 18:00:07 --> Hooks Class Initialized
DEBUG - 2012-07-23 18:00:07 --> Utf8 Class Initialized
DEBUG - 2012-07-23 18:00:07 --> UTF-8 Support Disabled
DEBUG - 2012-07-23 18:00:07 --> URI Class Initialized
DEBUG - 2012-07-23 18:00:07 --> Router Class Initialized
DEBUG - 2012-07-23 18:00:07 --> Output Class Initialized
DEBUG - 2012-07-23 18:00:07 --> Security Class Initialized
DEBUG - 2012-07-23 18:00:07 --> Input Class Initialized
DEBUG - 2012-07-23 18:00:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-23 18:00:07 --> Language Class Initialized
DEBUG - 2012-07-23 18:00:07 --> Loader Class Initialized
DEBUG - 2012-07-23 18:00:07 --> Helper loaded: url_helper
DEBUG - 2012-07-23 18:00:07 --> Controller Class Initialized
DEBUG - 2012-07-23 18:00:07 --> Model Class Initialized
DEBUG - 2012-07-23 18:00:07 --> Database Driver Class Initialized
DEBUG - 2012-07-23 18:00:07 --> Helper loaded: form_helper
DEBUG - 2012-07-23 18:00:07 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-23 18:00:07 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-23 18:00:07 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-23 18:00:07 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-23 18:00:07 --> Final output sent to browser
DEBUG - 2012-07-23 18:00:07 --> Total execution time: 0.1114
DEBUG - 2012-07-23 18:11:11 --> Config Class Initialized
DEBUG - 2012-07-23 18:11:11 --> Hooks Class Initialized
DEBUG - 2012-07-23 18:11:11 --> Utf8 Class Initialized
DEBUG - 2012-07-23 18:11:11 --> UTF-8 Support Disabled
DEBUG - 2012-07-23 18:11:11 --> URI Class Initialized
DEBUG - 2012-07-23 18:11:11 --> Router Class Initialized
DEBUG - 2012-07-23 18:11:11 --> Output Class Initialized
DEBUG - 2012-07-23 18:11:11 --> Security Class Initialized
DEBUG - 2012-07-23 18:11:11 --> Input Class Initialized
DEBUG - 2012-07-23 18:11:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-23 18:11:11 --> Language Class Initialized
DEBUG - 2012-07-23 18:11:11 --> Loader Class Initialized
DEBUG - 2012-07-23 18:11:11 --> Helper loaded: url_helper
DEBUG - 2012-07-23 18:11:11 --> Controller Class Initialized
DEBUG - 2012-07-23 18:11:11 --> Model Class Initialized
DEBUG - 2012-07-23 18:11:11 --> Database Driver Class Initialized
DEBUG - 2012-07-23 18:11:11 --> Helper loaded: form_helper
DEBUG - 2012-07-23 18:11:11 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-23 18:11:11 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-23 18:11:11 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-23 18:11:11 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-23 18:11:11 --> Final output sent to browser
DEBUG - 2012-07-23 18:11:11 --> Total execution time: 0.0430
DEBUG - 2012-07-23 18:32:21 --> Config Class Initialized
DEBUG - 2012-07-23 18:32:21 --> Hooks Class Initialized
DEBUG - 2012-07-23 18:32:21 --> Utf8 Class Initialized
DEBUG - 2012-07-23 18:32:21 --> UTF-8 Support Disabled
DEBUG - 2012-07-23 18:32:21 --> URI Class Initialized
DEBUG - 2012-07-23 18:32:21 --> Router Class Initialized
DEBUG - 2012-07-23 18:32:21 --> Output Class Initialized
DEBUG - 2012-07-23 18:32:21 --> Security Class Initialized
DEBUG - 2012-07-23 18:32:21 --> Input Class Initialized
DEBUG - 2012-07-23 18:32:21 --> XSS Filtering completed
DEBUG - 2012-07-23 18:32:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-23 18:32:21 --> Language Class Initialized
DEBUG - 2012-07-23 18:32:21 --> Loader Class Initialized
DEBUG - 2012-07-23 18:32:21 --> Helper loaded: url_helper
DEBUG - 2012-07-23 18:32:21 --> Controller Class Initialized
DEBUG - 2012-07-23 18:32:21 --> Model Class Initialized
DEBUG - 2012-07-23 18:32:21 --> Database Driver Class Initialized
DEBUG - 2012-07-23 18:32:21 --> Helper loaded: form_helper
DEBUG - 2012-07-23 18:32:21 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-23 18:32:21 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-23 18:32:21 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-23 18:32:21 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-23 18:32:21 --> Final output sent to browser
DEBUG - 2012-07-23 18:32:21 --> Total execution time: 0.0440
DEBUG - 2012-07-23 18:33:00 --> Config Class Initialized
DEBUG - 2012-07-23 18:33:00 --> Hooks Class Initialized
DEBUG - 2012-07-23 18:33:00 --> Utf8 Class Initialized
DEBUG - 2012-07-23 18:33:00 --> UTF-8 Support Disabled
DEBUG - 2012-07-23 18:33:00 --> URI Class Initialized
DEBUG - 2012-07-23 18:33:00 --> Router Class Initialized
DEBUG - 2012-07-23 18:33:00 --> Output Class Initialized
DEBUG - 2012-07-23 18:33:00 --> Security Class Initialized
DEBUG - 2012-07-23 18:33:00 --> Input Class Initialized
DEBUG - 2012-07-23 18:33:00 --> XSS Filtering completed
DEBUG - 2012-07-23 18:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-23 18:33:00 --> Language Class Initialized
DEBUG - 2012-07-23 18:33:00 --> Loader Class Initialized
DEBUG - 2012-07-23 18:33:00 --> Helper loaded: url_helper
DEBUG - 2012-07-23 18:33:00 --> Controller Class Initialized
DEBUG - 2012-07-23 18:33:00 --> Model Class Initialized
DEBUG - 2012-07-23 18:33:00 --> Database Driver Class Initialized
DEBUG - 2012-07-23 18:33:00 --> Helper loaded: form_helper
DEBUG - 2012-07-23 18:33:00 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-23 18:33:00 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-23 18:33:00 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-23 18:33:00 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-23 18:33:00 --> Final output sent to browser
DEBUG - 2012-07-23 18:33:00 --> Total execution time: 0.0476
DEBUG - 2012-07-23 18:37:43 --> Config Class Initialized
DEBUG - 2012-07-23 18:37:43 --> Hooks Class Initialized
DEBUG - 2012-07-23 18:37:43 --> Utf8 Class Initialized
DEBUG - 2012-07-23 18:37:43 --> UTF-8 Support Disabled
DEBUG - 2012-07-23 18:37:43 --> URI Class Initialized
DEBUG - 2012-07-23 18:37:43 --> Router Class Initialized
DEBUG - 2012-07-23 18:37:43 --> Output Class Initialized
DEBUG - 2012-07-23 18:37:43 --> Security Class Initialized
DEBUG - 2012-07-23 18:37:43 --> Input Class Initialized
DEBUG - 2012-07-23 18:37:43 --> XSS Filtering completed
DEBUG - 2012-07-23 18:37:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-23 18:37:43 --> Language Class Initialized
DEBUG - 2012-07-23 18:37:43 --> Loader Class Initialized
DEBUG - 2012-07-23 18:37:43 --> Helper loaded: url_helper
DEBUG - 2012-07-23 18:37:43 --> Controller Class Initialized
DEBUG - 2012-07-23 18:37:43 --> Model Class Initialized
DEBUG - 2012-07-23 18:37:43 --> Database Driver Class Initialized
DEBUG - 2012-07-23 18:37:43 --> Helper loaded: form_helper
DEBUG - 2012-07-23 18:37:43 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-23 18:37:43 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-23 18:37:43 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-23 18:37:43 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-23 18:37:43 --> Final output sent to browser
DEBUG - 2012-07-23 18:37:43 --> Total execution time: 0.0539
DEBUG - 2012-07-23 18:41:44 --> Config Class Initialized
DEBUG - 2012-07-23 18:41:44 --> Hooks Class Initialized
DEBUG - 2012-07-23 18:41:44 --> Utf8 Class Initialized
DEBUG - 2012-07-23 18:41:44 --> UTF-8 Support Disabled
DEBUG - 2012-07-23 18:41:44 --> URI Class Initialized
DEBUG - 2012-07-23 18:41:44 --> Router Class Initialized
DEBUG - 2012-07-23 18:41:44 --> Output Class Initialized
DEBUG - 2012-07-23 18:41:44 --> Security Class Initialized
DEBUG - 2012-07-23 18:41:44 --> Input Class Initialized
DEBUG - 2012-07-23 18:41:44 --> XSS Filtering completed
DEBUG - 2012-07-23 18:41:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-23 18:41:44 --> Language Class Initialized
DEBUG - 2012-07-23 18:41:44 --> Loader Class Initialized
DEBUG - 2012-07-23 18:41:44 --> Helper loaded: url_helper
DEBUG - 2012-07-23 18:41:44 --> Controller Class Initialized
DEBUG - 2012-07-23 18:41:44 --> Model Class Initialized
DEBUG - 2012-07-23 18:41:44 --> Database Driver Class Initialized
DEBUG - 2012-07-23 18:41:44 --> Helper loaded: form_helper
DEBUG - 2012-07-23 18:41:44 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-23 18:41:44 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-23 18:41:44 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-23 18:41:44 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-23 18:41:44 --> Final output sent to browser
DEBUG - 2012-07-23 18:41:44 --> Total execution time: 0.0404
DEBUG - 2012-07-23 18:49:33 --> Config Class Initialized
DEBUG - 2012-07-23 18:49:33 --> Hooks Class Initialized
DEBUG - 2012-07-23 18:49:33 --> Utf8 Class Initialized
DEBUG - 2012-07-23 18:49:33 --> UTF-8 Support Disabled
DEBUG - 2012-07-23 18:49:33 --> URI Class Initialized
DEBUG - 2012-07-23 18:49:33 --> Router Class Initialized
DEBUG - 2012-07-23 18:49:33 --> Output Class Initialized
DEBUG - 2012-07-23 18:49:33 --> Security Class Initialized
DEBUG - 2012-07-23 18:49:33 --> Input Class Initialized
DEBUG - 2012-07-23 18:49:33 --> XSS Filtering completed
DEBUG - 2012-07-23 18:49:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-23 18:49:33 --> Language Class Initialized
DEBUG - 2012-07-23 18:49:33 --> Loader Class Initialized
DEBUG - 2012-07-23 18:49:33 --> Helper loaded: url_helper
DEBUG - 2012-07-23 18:49:33 --> Controller Class Initialized
DEBUG - 2012-07-23 18:49:33 --> Model Class Initialized
DEBUG - 2012-07-23 18:49:33 --> Database Driver Class Initialized
DEBUG - 2012-07-23 18:49:33 --> Helper loaded: form_helper
DEBUG - 2012-07-23 18:49:33 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-23 18:49:33 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-23 18:49:33 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-23 18:49:33 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-23 18:49:33 --> Final output sent to browser
DEBUG - 2012-07-23 18:49:33 --> Total execution time: 0.0389
DEBUG - 2012-07-23 19:40:18 --> Config Class Initialized
DEBUG - 2012-07-23 19:40:18 --> Hooks Class Initialized
DEBUG - 2012-07-23 19:40:18 --> Utf8 Class Initialized
DEBUG - 2012-07-23 19:40:18 --> UTF-8 Support Disabled
DEBUG - 2012-07-23 19:40:18 --> URI Class Initialized
DEBUG - 2012-07-23 19:40:18 --> Router Class Initialized
DEBUG - 2012-07-23 19:40:18 --> Output Class Initialized
DEBUG - 2012-07-23 19:40:18 --> Security Class Initialized
DEBUG - 2012-07-23 19:40:18 --> Input Class Initialized
DEBUG - 2012-07-23 19:40:18 --> XSS Filtering completed
DEBUG - 2012-07-23 19:40:18 --> XSS Filtering completed
DEBUG - 2012-07-23 19:40:18 --> XSS Filtering completed
DEBUG - 2012-07-23 19:40:18 --> XSS Filtering completed
DEBUG - 2012-07-23 19:40:18 --> XSS Filtering completed
DEBUG - 2012-07-23 19:40:18 --> XSS Filtering completed
DEBUG - 2012-07-23 19:40:18 --> XSS Filtering completed
DEBUG - 2012-07-23 19:40:18 --> XSS Filtering completed
DEBUG - 2012-07-23 19:40:18 --> XSS Filtering completed
DEBUG - 2012-07-23 19:40:18 --> XSS Filtering completed
DEBUG - 2012-07-23 19:40:18 --> XSS Filtering completed
DEBUG - 2012-07-23 19:40:18 --> XSS Filtering completed
DEBUG - 2012-07-23 19:40:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-23 19:40:18 --> Language Class Initialized
DEBUG - 2012-07-23 19:40:18 --> Loader Class Initialized
DEBUG - 2012-07-23 19:40:18 --> Helper loaded: url_helper
DEBUG - 2012-07-23 19:40:18 --> Controller Class Initialized
DEBUG - 2012-07-23 19:40:18 --> Model Class Initialized
DEBUG - 2012-07-23 19:40:18 --> Database Driver Class Initialized
DEBUG - 2012-07-23 19:40:18 --> Helper loaded: form_helper
DEBUG - 2012-07-23 19:40:18 --> Form Validation Class Initialized
DEBUG - 2012-07-23 20:04:41 --> Config Class Initialized
DEBUG - 2012-07-23 20:04:41 --> Hooks Class Initialized
DEBUG - 2012-07-23 20:04:41 --> Utf8 Class Initialized
DEBUG - 2012-07-23 20:04:41 --> UTF-8 Support Disabled
DEBUG - 2012-07-23 20:04:41 --> URI Class Initialized
DEBUG - 2012-07-23 20:04:41 --> Router Class Initialized
DEBUG - 2012-07-23 20:04:41 --> Output Class Initialized
DEBUG - 2012-07-23 20:04:41 --> Security Class Initialized
DEBUG - 2012-07-23 20:04:41 --> Input Class Initialized
DEBUG - 2012-07-23 20:04:41 --> XSS Filtering completed
DEBUG - 2012-07-23 20:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-23 20:04:41 --> Language Class Initialized
DEBUG - 2012-07-23 20:04:41 --> Loader Class Initialized
DEBUG - 2012-07-23 20:04:41 --> Helper loaded: url_helper
DEBUG - 2012-07-23 20:04:41 --> Controller Class Initialized
DEBUG - 2012-07-23 20:04:41 --> Model Class Initialized
DEBUG - 2012-07-23 20:04:41 --> Database Driver Class Initialized
DEBUG - 2012-07-23 20:04:42 --> Helper loaded: form_helper
DEBUG - 2012-07-23 20:04:42 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-23 20:04:42 --> File loaded: application/views/admin/templates/left_menu.php
ERROR - 2012-07-23 20:04:42 --> Severity: Notice  --> Undefined property: stdClass::$sizeprint_sizes_id /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/prints.php 26
ERROR - 2012-07-23 20:04:42 --> Severity: Notice  --> Undefined property: stdClass::$sizeprint_sizes_id /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/prints.php 26
DEBUG - 2012-07-23 20:04:42 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-23 20:04:42 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-23 20:04:42 --> Final output sent to browser
DEBUG - 2012-07-23 20:04:42 --> Total execution time: 0.3697
DEBUG - 2012-07-23 20:06:07 --> Config Class Initialized
DEBUG - 2012-07-23 20:06:07 --> Hooks Class Initialized
DEBUG - 2012-07-23 20:06:07 --> Utf8 Class Initialized
DEBUG - 2012-07-23 20:06:07 --> UTF-8 Support Disabled
DEBUG - 2012-07-23 20:06:07 --> URI Class Initialized
DEBUG - 2012-07-23 20:06:07 --> Router Class Initialized
DEBUG - 2012-07-23 20:06:07 --> Output Class Initialized
DEBUG - 2012-07-23 20:06:07 --> Security Class Initialized
DEBUG - 2012-07-23 20:06:07 --> Input Class Initialized
DEBUG - 2012-07-23 20:06:07 --> XSS Filtering completed
DEBUG - 2012-07-23 20:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-23 20:06:07 --> Language Class Initialized
DEBUG - 2012-07-23 20:06:07 --> Loader Class Initialized
DEBUG - 2012-07-23 20:06:07 --> Helper loaded: url_helper
DEBUG - 2012-07-23 20:06:07 --> Controller Class Initialized
DEBUG - 2012-07-23 20:06:07 --> Model Class Initialized
DEBUG - 2012-07-23 20:06:07 --> Database Driver Class Initialized
DEBUG - 2012-07-23 20:06:07 --> Helper loaded: form_helper
DEBUG - 2012-07-23 20:06:07 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-23 20:06:07 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-23 20:06:07 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-23 20:06:07 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-23 20:06:07 --> Final output sent to browser
DEBUG - 2012-07-23 20:06:07 --> Total execution time: 0.0492
DEBUG - 2012-07-23 20:16:15 --> Config Class Initialized
DEBUG - 2012-07-23 20:16:15 --> Hooks Class Initialized
DEBUG - 2012-07-23 20:16:15 --> Utf8 Class Initialized
DEBUG - 2012-07-23 20:16:15 --> UTF-8 Support Disabled
DEBUG - 2012-07-23 20:16:15 --> URI Class Initialized
DEBUG - 2012-07-23 20:16:15 --> Router Class Initialized
DEBUG - 2012-07-23 20:16:15 --> Output Class Initialized
DEBUG - 2012-07-23 20:16:15 --> Security Class Initialized
DEBUG - 2012-07-23 20:16:15 --> Input Class Initialized
DEBUG - 2012-07-23 20:16:15 --> XSS Filtering completed
DEBUG - 2012-07-23 20:16:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-23 20:16:15 --> Language Class Initialized
DEBUG - 2012-07-23 20:16:15 --> Loader Class Initialized
DEBUG - 2012-07-23 20:16:15 --> Helper loaded: url_helper
DEBUG - 2012-07-23 20:16:15 --> Controller Class Initialized
DEBUG - 2012-07-23 20:16:15 --> Model Class Initialized
DEBUG - 2012-07-23 20:16:15 --> Database Driver Class Initialized
DEBUG - 2012-07-23 20:16:15 --> Helper loaded: form_helper
DEBUG - 2012-07-23 20:16:15 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-23 20:16:15 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-23 20:16:15 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-23 20:16:15 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-23 20:16:15 --> Final output sent to browser
DEBUG - 2012-07-23 20:16:15 --> Total execution time: 0.0443
DEBUG - 2012-07-23 20:17:28 --> Config Class Initialized
DEBUG - 2012-07-23 20:17:28 --> Hooks Class Initialized
DEBUG - 2012-07-23 20:17:28 --> Utf8 Class Initialized
DEBUG - 2012-07-23 20:17:28 --> UTF-8 Support Disabled
DEBUG - 2012-07-23 20:17:28 --> URI Class Initialized
DEBUG - 2012-07-23 20:17:28 --> Router Class Initialized
DEBUG - 2012-07-23 20:17:28 --> Output Class Initialized
DEBUG - 2012-07-23 20:17:28 --> Security Class Initialized
DEBUG - 2012-07-23 20:17:28 --> Input Class Initialized
DEBUG - 2012-07-23 20:17:28 --> XSS Filtering completed
DEBUG - 2012-07-23 20:17:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-23 20:17:28 --> Language Class Initialized
DEBUG - 2012-07-23 20:17:28 --> Loader Class Initialized
DEBUG - 2012-07-23 20:17:28 --> Helper loaded: url_helper
DEBUG - 2012-07-23 20:17:28 --> Controller Class Initialized
DEBUG - 2012-07-23 20:17:28 --> Model Class Initialized
DEBUG - 2012-07-23 20:17:28 --> Database Driver Class Initialized
DEBUG - 2012-07-23 20:17:28 --> Helper loaded: form_helper
DEBUG - 2012-07-23 20:17:28 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-23 20:17:28 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-23 20:17:28 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-23 20:17:28 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-23 20:17:28 --> Final output sent to browser
DEBUG - 2012-07-23 20:17:28 --> Total execution time: 0.0481
DEBUG - 2012-07-23 20:18:29 --> Config Class Initialized
DEBUG - 2012-07-23 20:18:29 --> Hooks Class Initialized
DEBUG - 2012-07-23 20:18:29 --> Utf8 Class Initialized
DEBUG - 2012-07-23 20:18:29 --> UTF-8 Support Disabled
DEBUG - 2012-07-23 20:18:29 --> URI Class Initialized
DEBUG - 2012-07-23 20:18:29 --> Router Class Initialized
DEBUG - 2012-07-23 20:18:29 --> Output Class Initialized
DEBUG - 2012-07-23 20:18:29 --> Security Class Initialized
DEBUG - 2012-07-23 20:18:29 --> Input Class Initialized
DEBUG - 2012-07-23 20:18:29 --> XSS Filtering completed
DEBUG - 2012-07-23 20:18:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-23 20:18:29 --> Language Class Initialized
DEBUG - 2012-07-23 20:18:29 --> Loader Class Initialized
DEBUG - 2012-07-23 20:18:29 --> Helper loaded: url_helper
DEBUG - 2012-07-23 20:18:29 --> Controller Class Initialized
DEBUG - 2012-07-23 20:18:29 --> Model Class Initialized
DEBUG - 2012-07-23 20:18:29 --> Database Driver Class Initialized
DEBUG - 2012-07-23 20:18:29 --> Helper loaded: form_helper
DEBUG - 2012-07-23 20:18:29 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-23 20:18:29 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-23 20:18:29 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-23 20:18:29 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-23 20:18:29 --> Final output sent to browser
DEBUG - 2012-07-23 20:18:29 --> Total execution time: 0.0385
DEBUG - 2012-07-23 21:17:44 --> Config Class Initialized
DEBUG - 2012-07-23 21:17:44 --> Hooks Class Initialized
DEBUG - 2012-07-23 21:17:44 --> Utf8 Class Initialized
DEBUG - 2012-07-23 21:17:44 --> UTF-8 Support Disabled
DEBUG - 2012-07-23 21:17:45 --> URI Class Initialized
DEBUG - 2012-07-23 21:17:45 --> Router Class Initialized
DEBUG - 2012-07-23 21:17:45 --> Output Class Initialized
DEBUG - 2012-07-23 21:17:45 --> Security Class Initialized
DEBUG - 2012-07-23 21:17:45 --> Input Class Initialized
DEBUG - 2012-07-23 21:17:45 --> XSS Filtering completed
DEBUG - 2012-07-23 21:17:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-23 21:17:45 --> Language Class Initialized
DEBUG - 2012-07-23 21:18:35 --> Config Class Initialized
DEBUG - 2012-07-23 21:18:35 --> Hooks Class Initialized
DEBUG - 2012-07-23 21:18:35 --> Utf8 Class Initialized
DEBUG - 2012-07-23 21:18:35 --> UTF-8 Support Disabled
DEBUG - 2012-07-23 21:18:35 --> URI Class Initialized
DEBUG - 2012-07-23 21:18:35 --> Router Class Initialized
DEBUG - 2012-07-23 21:18:35 --> Output Class Initialized
DEBUG - 2012-07-23 21:18:35 --> Security Class Initialized
DEBUG - 2012-07-23 21:18:35 --> Input Class Initialized
DEBUG - 2012-07-23 21:18:35 --> XSS Filtering completed
DEBUG - 2012-07-23 21:18:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-23 21:18:35 --> Language Class Initialized
DEBUG - 2012-07-23 21:18:35 --> Loader Class Initialized
DEBUG - 2012-07-23 21:18:35 --> Helper loaded: url_helper
DEBUG - 2012-07-23 21:18:35 --> Controller Class Initialized
DEBUG - 2012-07-23 21:18:35 --> Model Class Initialized
DEBUG - 2012-07-23 21:18:35 --> Database Driver Class Initialized
DEBUG - 2012-07-23 21:18:35 --> Helper loaded: form_helper
DEBUG - 2012-07-23 21:18:35 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-23 21:18:35 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-23 21:18:35 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-23 21:18:35 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-23 21:18:35 --> Final output sent to browser
DEBUG - 2012-07-23 21:18:35 --> Total execution time: 0.0416
DEBUG - 2012-07-23 21:20:17 --> Config Class Initialized
DEBUG - 2012-07-23 21:20:17 --> Hooks Class Initialized
DEBUG - 2012-07-23 21:20:17 --> Utf8 Class Initialized
DEBUG - 2012-07-23 21:20:17 --> UTF-8 Support Disabled
DEBUG - 2012-07-23 21:20:17 --> URI Class Initialized
DEBUG - 2012-07-23 21:20:17 --> Router Class Initialized
DEBUG - 2012-07-23 21:20:17 --> Output Class Initialized
DEBUG - 2012-07-23 21:20:17 --> Security Class Initialized
DEBUG - 2012-07-23 21:20:17 --> Input Class Initialized
DEBUG - 2012-07-23 21:20:17 --> XSS Filtering completed
DEBUG - 2012-07-23 21:20:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-23 21:20:17 --> Language Class Initialized
DEBUG - 2012-07-23 21:20:17 --> Loader Class Initialized
DEBUG - 2012-07-23 21:20:17 --> Helper loaded: url_helper
DEBUG - 2012-07-23 21:20:17 --> Controller Class Initialized
DEBUG - 2012-07-23 21:20:17 --> Model Class Initialized
DEBUG - 2012-07-23 21:20:17 --> Database Driver Class Initialized
DEBUG - 2012-07-23 21:20:17 --> Helper loaded: form_helper
DEBUG - 2012-07-23 21:20:17 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-23 21:20:17 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-23 21:20:17 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-23 21:20:17 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-23 21:20:17 --> Final output sent to browser
DEBUG - 2012-07-23 21:20:17 --> Total execution time: 0.0466
DEBUG - 2012-07-23 21:56:36 --> Config Class Initialized
DEBUG - 2012-07-23 21:56:36 --> Hooks Class Initialized
DEBUG - 2012-07-23 21:56:36 --> Utf8 Class Initialized
DEBUG - 2012-07-23 21:56:36 --> UTF-8 Support Disabled
DEBUG - 2012-07-23 21:56:36 --> URI Class Initialized
DEBUG - 2012-07-23 21:56:36 --> Router Class Initialized
DEBUG - 2012-07-23 21:56:36 --> Output Class Initialized
DEBUG - 2012-07-23 21:56:36 --> Security Class Initialized
DEBUG - 2012-07-23 21:56:36 --> Input Class Initialized
DEBUG - 2012-07-23 21:56:36 --> XSS Filtering completed
DEBUG - 2012-07-23 21:56:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-23 21:56:36 --> Language Class Initialized
DEBUG - 2012-07-23 21:56:36 --> Loader Class Initialized
DEBUG - 2012-07-23 21:56:36 --> Helper loaded: url_helper
DEBUG - 2012-07-23 21:56:36 --> Controller Class Initialized
DEBUG - 2012-07-23 21:56:36 --> Model Class Initialized
DEBUG - 2012-07-23 21:56:36 --> Database Driver Class Initialized
DEBUG - 2012-07-23 21:56:36 --> Helper loaded: form_helper
DEBUG - 2012-07-23 21:56:36 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-23 21:56:36 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-23 21:56:36 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-23 21:56:36 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-23 21:56:36 --> Final output sent to browser
DEBUG - 2012-07-23 21:56:36 --> Total execution time: 0.0383
DEBUG - 2012-07-23 22:00:56 --> Config Class Initialized
DEBUG - 2012-07-23 22:00:56 --> Hooks Class Initialized
DEBUG - 2012-07-23 22:00:56 --> Utf8 Class Initialized
DEBUG - 2012-07-23 22:00:56 --> UTF-8 Support Disabled
DEBUG - 2012-07-23 22:00:56 --> URI Class Initialized
DEBUG - 2012-07-23 22:00:56 --> Router Class Initialized
DEBUG - 2012-07-23 22:00:56 --> Output Class Initialized
DEBUG - 2012-07-23 22:00:56 --> Security Class Initialized
DEBUG - 2012-07-23 22:00:56 --> Input Class Initialized
DEBUG - 2012-07-23 22:00:56 --> XSS Filtering completed
DEBUG - 2012-07-23 22:00:56 --> XSS Filtering completed
DEBUG - 2012-07-23 22:00:56 --> XSS Filtering completed
DEBUG - 2012-07-23 22:00:56 --> XSS Filtering completed
DEBUG - 2012-07-23 22:00:56 --> XSS Filtering completed
DEBUG - 2012-07-23 22:00:56 --> XSS Filtering completed
DEBUG - 2012-07-23 22:00:56 --> XSS Filtering completed
DEBUG - 2012-07-23 22:00:56 --> XSS Filtering completed
DEBUG - 2012-07-23 22:00:56 --> XSS Filtering completed
DEBUG - 2012-07-23 22:00:56 --> XSS Filtering completed
DEBUG - 2012-07-23 22:00:56 --> XSS Filtering completed
DEBUG - 2012-07-23 22:00:56 --> XSS Filtering completed
DEBUG - 2012-07-23 22:00:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-23 22:00:56 --> Language Class Initialized
DEBUG - 2012-07-23 22:00:56 --> Loader Class Initialized
DEBUG - 2012-07-23 22:00:56 --> Helper loaded: url_helper
DEBUG - 2012-07-23 22:00:56 --> Controller Class Initialized
DEBUG - 2012-07-23 22:00:56 --> Model Class Initialized
DEBUG - 2012-07-23 22:00:56 --> Database Driver Class Initialized
DEBUG - 2012-07-23 22:00:56 --> Helper loaded: form_helper
DEBUG - 2012-07-23 22:00:56 --> Form Validation Class Initialized
