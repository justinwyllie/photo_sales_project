<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-07-24 14:59:09 --> Config Class Initialized
DEBUG - 2012-07-24 14:59:09 --> Hooks Class Initialized
DEBUG - 2012-07-24 14:59:09 --> Utf8 Class Initialized
DEBUG - 2012-07-24 14:59:09 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 14:59:09 --> URI Class Initialized
DEBUG - 2012-07-24 14:59:09 --> Router Class Initialized
DEBUG - 2012-07-24 14:59:09 --> Output Class Initialized
DEBUG - 2012-07-24 14:59:09 --> Security Class Initialized
DEBUG - 2012-07-24 14:59:09 --> Input Class Initialized
DEBUG - 2012-07-24 14:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 14:59:09 --> Language Class Initialized
DEBUG - 2012-07-24 14:59:09 --> Loader Class Initialized
DEBUG - 2012-07-24 14:59:09 --> Helper loaded: url_helper
DEBUG - 2012-07-24 14:59:09 --> Controller Class Initialized
DEBUG - 2012-07-24 14:59:09 --> Model Class Initialized
DEBUG - 2012-07-24 14:59:09 --> Database Driver Class Initialized
DEBUG - 2012-07-24 14:59:09 --> Helper loaded: form_helper
DEBUG - 2012-07-24 14:59:09 --> Helper loaded: html_helper
DEBUG - 2012-07-24 14:59:09 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-24 14:59:09 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-24 14:59:09 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-24 14:59:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-24 14:59:09 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 64
ERROR - 2012-07-24 14:59:09 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-24 14:59:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-24 14:59:09 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-24 14:59:09 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-24 14:59:09 --> Final output sent to browser
DEBUG - 2012-07-24 14:59:09 --> Total execution time: 0.3832
DEBUG - 2012-07-24 14:59:13 --> Config Class Initialized
DEBUG - 2012-07-24 14:59:13 --> Hooks Class Initialized
DEBUG - 2012-07-24 14:59:13 --> Utf8 Class Initialized
DEBUG - 2012-07-24 14:59:13 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 14:59:13 --> URI Class Initialized
DEBUG - 2012-07-24 14:59:13 --> Router Class Initialized
DEBUG - 2012-07-24 14:59:13 --> Output Class Initialized
DEBUG - 2012-07-24 14:59:13 --> Security Class Initialized
DEBUG - 2012-07-24 14:59:13 --> Input Class Initialized
DEBUG - 2012-07-24 14:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 14:59:13 --> Language Class Initialized
DEBUG - 2012-07-24 14:59:13 --> Loader Class Initialized
DEBUG - 2012-07-24 14:59:13 --> Helper loaded: url_helper
DEBUG - 2012-07-24 14:59:13 --> Controller Class Initialized
DEBUG - 2012-07-24 14:59:13 --> Model Class Initialized
DEBUG - 2012-07-24 14:59:13 --> Database Driver Class Initialized
DEBUG - 2012-07-24 14:59:13 --> Helper loaded: form_helper
DEBUG - 2012-07-24 14:59:13 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 14:59:13 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 14:59:13 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 14:59:13 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 14:59:13 --> Final output sent to browser
DEBUG - 2012-07-24 14:59:13 --> Total execution time: 0.1875
DEBUG - 2012-07-24 15:05:50 --> Config Class Initialized
DEBUG - 2012-07-24 15:05:50 --> Hooks Class Initialized
DEBUG - 2012-07-24 15:05:50 --> Utf8 Class Initialized
DEBUG - 2012-07-24 15:05:50 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 15:05:50 --> URI Class Initialized
DEBUG - 2012-07-24 15:05:50 --> Router Class Initialized
DEBUG - 2012-07-24 15:05:50 --> Output Class Initialized
DEBUG - 2012-07-24 15:05:50 --> Security Class Initialized
DEBUG - 2012-07-24 15:05:50 --> Input Class Initialized
DEBUG - 2012-07-24 15:05:50 --> XSS Filtering completed
DEBUG - 2012-07-24 15:05:50 --> XSS Filtering completed
DEBUG - 2012-07-24 15:05:50 --> XSS Filtering completed
DEBUG - 2012-07-24 15:05:50 --> XSS Filtering completed
DEBUG - 2012-07-24 15:05:50 --> XSS Filtering completed
DEBUG - 2012-07-24 15:05:50 --> XSS Filtering completed
DEBUG - 2012-07-24 15:05:50 --> XSS Filtering completed
DEBUG - 2012-07-24 15:05:50 --> XSS Filtering completed
DEBUG - 2012-07-24 15:05:50 --> XSS Filtering completed
DEBUG - 2012-07-24 15:05:50 --> XSS Filtering completed
DEBUG - 2012-07-24 15:05:50 --> XSS Filtering completed
DEBUG - 2012-07-24 15:05:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 15:05:50 --> Language Class Initialized
DEBUG - 2012-07-24 15:05:50 --> Loader Class Initialized
DEBUG - 2012-07-24 15:05:50 --> Helper loaded: url_helper
DEBUG - 2012-07-24 15:05:50 --> Controller Class Initialized
DEBUG - 2012-07-24 15:05:50 --> Model Class Initialized
DEBUG - 2012-07-24 15:05:50 --> Database Driver Class Initialized
DEBUG - 2012-07-24 15:05:50 --> Helper loaded: form_helper
DEBUG - 2012-07-24 15:05:50 --> Form Validation Class Initialized
DEBUG - 2012-07-24 15:09:30 --> Config Class Initialized
DEBUG - 2012-07-24 15:09:30 --> Hooks Class Initialized
DEBUG - 2012-07-24 15:09:30 --> Utf8 Class Initialized
DEBUG - 2012-07-24 15:09:30 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 15:09:30 --> URI Class Initialized
DEBUG - 2012-07-24 15:09:30 --> Router Class Initialized
DEBUG - 2012-07-24 15:09:30 --> Output Class Initialized
DEBUG - 2012-07-24 15:09:30 --> Security Class Initialized
DEBUG - 2012-07-24 15:09:30 --> Input Class Initialized
DEBUG - 2012-07-24 15:09:30 --> XSS Filtering completed
DEBUG - 2012-07-24 15:09:30 --> XSS Filtering completed
DEBUG - 2012-07-24 15:09:30 --> XSS Filtering completed
DEBUG - 2012-07-24 15:09:30 --> XSS Filtering completed
DEBUG - 2012-07-24 15:09:30 --> XSS Filtering completed
DEBUG - 2012-07-24 15:09:30 --> XSS Filtering completed
DEBUG - 2012-07-24 15:09:30 --> XSS Filtering completed
DEBUG - 2012-07-24 15:09:30 --> XSS Filtering completed
DEBUG - 2012-07-24 15:09:30 --> XSS Filtering completed
DEBUG - 2012-07-24 15:09:30 --> XSS Filtering completed
DEBUG - 2012-07-24 15:09:30 --> XSS Filtering completed
DEBUG - 2012-07-24 15:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 15:09:30 --> Language Class Initialized
DEBUG - 2012-07-24 15:09:30 --> Loader Class Initialized
DEBUG - 2012-07-24 15:09:30 --> Helper loaded: url_helper
DEBUG - 2012-07-24 15:09:30 --> Controller Class Initialized
DEBUG - 2012-07-24 15:09:30 --> Model Class Initialized
DEBUG - 2012-07-24 15:09:30 --> Database Driver Class Initialized
DEBUG - 2012-07-24 15:09:30 --> Helper loaded: form_helper
DEBUG - 2012-07-24 15:09:30 --> Form Validation Class Initialized
ERROR - 2012-07-24 15:09:30 --> Severity: Notice  --> Undefined property: Pricing::$pricing /home/jwp/www/justinwylliephotography.com/clients/application/controllers/admin/pricing.php 55
DEBUG - 2012-07-24 15:12:59 --> Config Class Initialized
DEBUG - 2012-07-24 15:12:59 --> Hooks Class Initialized
DEBUG - 2012-07-24 15:12:59 --> Utf8 Class Initialized
DEBUG - 2012-07-24 15:12:59 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 15:12:59 --> URI Class Initialized
DEBUG - 2012-07-24 15:12:59 --> Router Class Initialized
DEBUG - 2012-07-24 15:12:59 --> Output Class Initialized
DEBUG - 2012-07-24 15:12:59 --> Security Class Initialized
DEBUG - 2012-07-24 15:12:59 --> Input Class Initialized
DEBUG - 2012-07-24 15:12:59 --> XSS Filtering completed
DEBUG - 2012-07-24 15:12:59 --> XSS Filtering completed
DEBUG - 2012-07-24 15:12:59 --> XSS Filtering completed
DEBUG - 2012-07-24 15:12:59 --> XSS Filtering completed
DEBUG - 2012-07-24 15:12:59 --> XSS Filtering completed
DEBUG - 2012-07-24 15:12:59 --> XSS Filtering completed
DEBUG - 2012-07-24 15:12:59 --> XSS Filtering completed
DEBUG - 2012-07-24 15:12:59 --> XSS Filtering completed
DEBUG - 2012-07-24 15:12:59 --> XSS Filtering completed
DEBUG - 2012-07-24 15:12:59 --> XSS Filtering completed
DEBUG - 2012-07-24 15:12:59 --> XSS Filtering completed
DEBUG - 2012-07-24 15:12:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 15:12:59 --> Language Class Initialized
DEBUG - 2012-07-24 15:12:59 --> Loader Class Initialized
DEBUG - 2012-07-24 15:12:59 --> Helper loaded: url_helper
DEBUG - 2012-07-24 15:12:59 --> Controller Class Initialized
DEBUG - 2012-07-24 15:12:59 --> Model Class Initialized
DEBUG - 2012-07-24 15:12:59 --> Database Driver Class Initialized
DEBUG - 2012-07-24 15:12:59 --> Helper loaded: form_helper
DEBUG - 2012-07-24 15:12:59 --> Form Validation Class Initialized
ERROR - 2012-07-24 15:12:59 --> Severity: Notice  --> Undefined property: Prices::$input_ /home/jwp/www/justinwylliephotography.com/clients/application/libraries/Prices.php 17
DEBUG - 2012-07-24 15:13:25 --> Config Class Initialized
DEBUG - 2012-07-24 15:13:25 --> Hooks Class Initialized
DEBUG - 2012-07-24 15:13:25 --> Utf8 Class Initialized
DEBUG - 2012-07-24 15:13:25 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 15:13:25 --> URI Class Initialized
DEBUG - 2012-07-24 15:13:25 --> Router Class Initialized
DEBUG - 2012-07-24 15:13:25 --> Output Class Initialized
DEBUG - 2012-07-24 15:13:25 --> Security Class Initialized
DEBUG - 2012-07-24 15:13:25 --> Input Class Initialized
DEBUG - 2012-07-24 15:13:25 --> XSS Filtering completed
DEBUG - 2012-07-24 15:13:25 --> XSS Filtering completed
DEBUG - 2012-07-24 15:13:25 --> XSS Filtering completed
DEBUG - 2012-07-24 15:13:25 --> XSS Filtering completed
DEBUG - 2012-07-24 15:13:25 --> XSS Filtering completed
DEBUG - 2012-07-24 15:13:25 --> XSS Filtering completed
DEBUG - 2012-07-24 15:13:25 --> XSS Filtering completed
DEBUG - 2012-07-24 15:13:25 --> XSS Filtering completed
DEBUG - 2012-07-24 15:13:25 --> XSS Filtering completed
DEBUG - 2012-07-24 15:13:25 --> XSS Filtering completed
DEBUG - 2012-07-24 15:13:25 --> XSS Filtering completed
DEBUG - 2012-07-24 15:13:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 15:13:25 --> Language Class Initialized
DEBUG - 2012-07-24 15:13:25 --> Loader Class Initialized
DEBUG - 2012-07-24 15:13:25 --> Helper loaded: url_helper
DEBUG - 2012-07-24 15:13:25 --> Controller Class Initialized
DEBUG - 2012-07-24 15:13:25 --> Model Class Initialized
DEBUG - 2012-07-24 15:13:25 --> Database Driver Class Initialized
DEBUG - 2012-07-24 15:13:25 --> Helper loaded: form_helper
DEBUG - 2012-07-24 15:13:25 --> Form Validation Class Initialized
ERROR - 2012-07-24 15:13:25 --> Severity: Notice  --> Undefined property: Prices::$input /home/jwp/www/justinwylliephotography.com/clients/application/libraries/Prices.php 17
DEBUG - 2012-07-24 15:16:17 --> Config Class Initialized
DEBUG - 2012-07-24 15:16:17 --> Hooks Class Initialized
DEBUG - 2012-07-24 15:16:17 --> Utf8 Class Initialized
DEBUG - 2012-07-24 15:16:17 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 15:16:17 --> URI Class Initialized
DEBUG - 2012-07-24 15:16:17 --> Router Class Initialized
DEBUG - 2012-07-24 15:16:17 --> Output Class Initialized
DEBUG - 2012-07-24 15:16:17 --> Security Class Initialized
DEBUG - 2012-07-24 15:16:17 --> Input Class Initialized
DEBUG - 2012-07-24 15:16:17 --> XSS Filtering completed
DEBUG - 2012-07-24 15:16:17 --> XSS Filtering completed
DEBUG - 2012-07-24 15:16:17 --> XSS Filtering completed
DEBUG - 2012-07-24 15:16:17 --> XSS Filtering completed
DEBUG - 2012-07-24 15:16:17 --> XSS Filtering completed
DEBUG - 2012-07-24 15:16:17 --> XSS Filtering completed
DEBUG - 2012-07-24 15:16:17 --> XSS Filtering completed
DEBUG - 2012-07-24 15:16:17 --> XSS Filtering completed
DEBUG - 2012-07-24 15:16:17 --> XSS Filtering completed
DEBUG - 2012-07-24 15:16:17 --> XSS Filtering completed
DEBUG - 2012-07-24 15:16:17 --> XSS Filtering completed
DEBUG - 2012-07-24 15:16:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 15:16:17 --> Language Class Initialized
DEBUG - 2012-07-24 15:16:17 --> Loader Class Initialized
DEBUG - 2012-07-24 15:16:17 --> Helper loaded: url_helper
DEBUG - 2012-07-24 15:16:17 --> Controller Class Initialized
DEBUG - 2012-07-24 15:16:17 --> Model Class Initialized
DEBUG - 2012-07-24 15:16:17 --> Database Driver Class Initialized
DEBUG - 2012-07-24 15:16:17 --> Helper loaded: form_helper
DEBUG - 2012-07-24 15:16:17 --> Form Validation Class Initialized
ERROR - 2012-07-24 15:16:17 --> Severity: Notice  --> Undefined property: Prices::$input /home/jwp/www/justinwylliephotography.com/clients/application/libraries/Prices.php 18
DEBUG - 2012-07-24 15:16:42 --> Config Class Initialized
DEBUG - 2012-07-24 15:16:42 --> Hooks Class Initialized
DEBUG - 2012-07-24 15:16:42 --> Utf8 Class Initialized
DEBUG - 2012-07-24 15:16:42 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 15:16:42 --> URI Class Initialized
DEBUG - 2012-07-24 15:16:42 --> Router Class Initialized
DEBUG - 2012-07-24 15:16:42 --> Output Class Initialized
DEBUG - 2012-07-24 15:16:42 --> Security Class Initialized
DEBUG - 2012-07-24 15:16:42 --> Input Class Initialized
DEBUG - 2012-07-24 15:16:42 --> XSS Filtering completed
DEBUG - 2012-07-24 15:16:42 --> XSS Filtering completed
DEBUG - 2012-07-24 15:16:42 --> XSS Filtering completed
DEBUG - 2012-07-24 15:16:42 --> XSS Filtering completed
DEBUG - 2012-07-24 15:16:42 --> XSS Filtering completed
DEBUG - 2012-07-24 15:16:42 --> XSS Filtering completed
DEBUG - 2012-07-24 15:16:42 --> XSS Filtering completed
DEBUG - 2012-07-24 15:16:42 --> XSS Filtering completed
DEBUG - 2012-07-24 15:16:42 --> XSS Filtering completed
DEBUG - 2012-07-24 15:16:42 --> XSS Filtering completed
DEBUG - 2012-07-24 15:16:42 --> XSS Filtering completed
DEBUG - 2012-07-24 15:16:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 15:16:42 --> Language Class Initialized
DEBUG - 2012-07-24 15:16:42 --> Loader Class Initialized
DEBUG - 2012-07-24 15:16:42 --> Helper loaded: url_helper
DEBUG - 2012-07-24 15:16:42 --> Controller Class Initialized
DEBUG - 2012-07-24 15:16:42 --> Model Class Initialized
DEBUG - 2012-07-24 15:16:42 --> Database Driver Class Initialized
DEBUG - 2012-07-24 15:16:42 --> Helper loaded: form_helper
DEBUG - 2012-07-24 15:16:42 --> Form Validation Class Initialized
DEBUG - 2012-07-24 15:30:33 --> Config Class Initialized
DEBUG - 2012-07-24 15:30:33 --> Hooks Class Initialized
DEBUG - 2012-07-24 15:30:33 --> Utf8 Class Initialized
DEBUG - 2012-07-24 15:30:33 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 15:30:33 --> URI Class Initialized
DEBUG - 2012-07-24 15:30:33 --> Router Class Initialized
DEBUG - 2012-07-24 15:30:33 --> Output Class Initialized
DEBUG - 2012-07-24 15:30:33 --> Security Class Initialized
DEBUG - 2012-07-24 15:30:33 --> Input Class Initialized
DEBUG - 2012-07-24 15:30:33 --> XSS Filtering completed
DEBUG - 2012-07-24 15:30:33 --> XSS Filtering completed
DEBUG - 2012-07-24 15:30:33 --> XSS Filtering completed
DEBUG - 2012-07-24 15:30:33 --> XSS Filtering completed
DEBUG - 2012-07-24 15:30:33 --> XSS Filtering completed
DEBUG - 2012-07-24 15:30:33 --> XSS Filtering completed
DEBUG - 2012-07-24 15:30:33 --> XSS Filtering completed
DEBUG - 2012-07-24 15:30:33 --> XSS Filtering completed
DEBUG - 2012-07-24 15:30:33 --> XSS Filtering completed
DEBUG - 2012-07-24 15:30:33 --> XSS Filtering completed
DEBUG - 2012-07-24 15:30:33 --> XSS Filtering completed
DEBUG - 2012-07-24 15:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 15:30:33 --> Language Class Initialized
DEBUG - 2012-07-24 15:30:33 --> Loader Class Initialized
DEBUG - 2012-07-24 15:30:33 --> Helper loaded: url_helper
DEBUG - 2012-07-24 15:30:33 --> Controller Class Initialized
DEBUG - 2012-07-24 15:30:33 --> Model Class Initialized
DEBUG - 2012-07-24 15:30:33 --> Database Driver Class Initialized
DEBUG - 2012-07-24 15:30:33 --> Helper loaded: form_helper
DEBUG - 2012-07-24 15:30:33 --> Form Validation Class Initialized
DEBUG - 2012-07-24 15:31:00 --> Config Class Initialized
DEBUG - 2012-07-24 15:31:00 --> Hooks Class Initialized
DEBUG - 2012-07-24 15:31:00 --> Utf8 Class Initialized
DEBUG - 2012-07-24 15:31:00 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 15:31:00 --> URI Class Initialized
DEBUG - 2012-07-24 15:31:00 --> Router Class Initialized
DEBUG - 2012-07-24 15:31:00 --> Output Class Initialized
DEBUG - 2012-07-24 15:31:00 --> Security Class Initialized
DEBUG - 2012-07-24 15:31:00 --> Input Class Initialized
DEBUG - 2012-07-24 15:31:00 --> XSS Filtering completed
DEBUG - 2012-07-24 15:31:00 --> XSS Filtering completed
DEBUG - 2012-07-24 15:31:00 --> XSS Filtering completed
DEBUG - 2012-07-24 15:31:00 --> XSS Filtering completed
DEBUG - 2012-07-24 15:31:00 --> XSS Filtering completed
DEBUG - 2012-07-24 15:31:00 --> XSS Filtering completed
DEBUG - 2012-07-24 15:31:00 --> XSS Filtering completed
DEBUG - 2012-07-24 15:31:00 --> XSS Filtering completed
DEBUG - 2012-07-24 15:31:00 --> XSS Filtering completed
DEBUG - 2012-07-24 15:31:00 --> XSS Filtering completed
DEBUG - 2012-07-24 15:31:00 --> XSS Filtering completed
DEBUG - 2012-07-24 15:31:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 15:31:00 --> Language Class Initialized
DEBUG - 2012-07-24 15:31:00 --> Loader Class Initialized
DEBUG - 2012-07-24 15:31:00 --> Helper loaded: url_helper
DEBUG - 2012-07-24 15:31:00 --> Controller Class Initialized
DEBUG - 2012-07-24 15:31:00 --> Model Class Initialized
DEBUG - 2012-07-24 15:31:00 --> Database Driver Class Initialized
DEBUG - 2012-07-24 15:31:00 --> Helper loaded: form_helper
DEBUG - 2012-07-24 15:31:00 --> Form Validation Class Initialized
DEBUG - 2012-07-24 15:31:59 --> Config Class Initialized
DEBUG - 2012-07-24 15:31:59 --> Hooks Class Initialized
DEBUG - 2012-07-24 15:31:59 --> Utf8 Class Initialized
DEBUG - 2012-07-24 15:31:59 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 15:31:59 --> URI Class Initialized
DEBUG - 2012-07-24 15:31:59 --> Router Class Initialized
DEBUG - 2012-07-24 15:31:59 --> Output Class Initialized
DEBUG - 2012-07-24 15:31:59 --> Security Class Initialized
DEBUG - 2012-07-24 15:31:59 --> Input Class Initialized
DEBUG - 2012-07-24 15:31:59 --> XSS Filtering completed
DEBUG - 2012-07-24 15:31:59 --> XSS Filtering completed
DEBUG - 2012-07-24 15:31:59 --> XSS Filtering completed
DEBUG - 2012-07-24 15:31:59 --> XSS Filtering completed
DEBUG - 2012-07-24 15:31:59 --> XSS Filtering completed
DEBUG - 2012-07-24 15:31:59 --> XSS Filtering completed
DEBUG - 2012-07-24 15:31:59 --> XSS Filtering completed
DEBUG - 2012-07-24 15:31:59 --> XSS Filtering completed
DEBUG - 2012-07-24 15:31:59 --> XSS Filtering completed
DEBUG - 2012-07-24 15:31:59 --> XSS Filtering completed
DEBUG - 2012-07-24 15:31:59 --> XSS Filtering completed
DEBUG - 2012-07-24 15:31:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 15:31:59 --> Language Class Initialized
DEBUG - 2012-07-24 15:31:59 --> Loader Class Initialized
DEBUG - 2012-07-24 15:31:59 --> Helper loaded: url_helper
DEBUG - 2012-07-24 15:31:59 --> Controller Class Initialized
DEBUG - 2012-07-24 15:31:59 --> Model Class Initialized
DEBUG - 2012-07-24 15:31:59 --> Database Driver Class Initialized
DEBUG - 2012-07-24 15:31:59 --> Helper loaded: form_helper
DEBUG - 2012-07-24 15:31:59 --> Form Validation Class Initialized
DEBUG - 2012-07-24 15:32:29 --> Config Class Initialized
DEBUG - 2012-07-24 15:32:29 --> Hooks Class Initialized
DEBUG - 2012-07-24 15:32:29 --> Utf8 Class Initialized
DEBUG - 2012-07-24 15:32:29 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 15:32:29 --> URI Class Initialized
DEBUG - 2012-07-24 15:32:29 --> Router Class Initialized
DEBUG - 2012-07-24 15:32:29 --> Output Class Initialized
DEBUG - 2012-07-24 15:32:29 --> Security Class Initialized
DEBUG - 2012-07-24 15:32:29 --> Input Class Initialized
DEBUG - 2012-07-24 15:32:29 --> XSS Filtering completed
DEBUG - 2012-07-24 15:32:29 --> XSS Filtering completed
DEBUG - 2012-07-24 15:32:29 --> XSS Filtering completed
DEBUG - 2012-07-24 15:32:29 --> XSS Filtering completed
DEBUG - 2012-07-24 15:32:29 --> XSS Filtering completed
DEBUG - 2012-07-24 15:32:29 --> XSS Filtering completed
DEBUG - 2012-07-24 15:32:29 --> XSS Filtering completed
DEBUG - 2012-07-24 15:32:29 --> XSS Filtering completed
DEBUG - 2012-07-24 15:32:29 --> XSS Filtering completed
DEBUG - 2012-07-24 15:32:29 --> XSS Filtering completed
DEBUG - 2012-07-24 15:32:29 --> XSS Filtering completed
DEBUG - 2012-07-24 15:32:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 15:32:29 --> Language Class Initialized
DEBUG - 2012-07-24 15:32:29 --> Loader Class Initialized
DEBUG - 2012-07-24 15:32:29 --> Helper loaded: url_helper
DEBUG - 2012-07-24 15:32:29 --> Controller Class Initialized
DEBUG - 2012-07-24 15:32:29 --> Model Class Initialized
DEBUG - 2012-07-24 15:32:29 --> Database Driver Class Initialized
DEBUG - 2012-07-24 15:32:29 --> Helper loaded: form_helper
DEBUG - 2012-07-24 15:32:29 --> Form Validation Class Initialized
DEBUG - 2012-07-24 15:33:07 --> Config Class Initialized
DEBUG - 2012-07-24 15:33:07 --> Hooks Class Initialized
DEBUG - 2012-07-24 15:33:07 --> Utf8 Class Initialized
DEBUG - 2012-07-24 15:33:07 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 15:33:07 --> URI Class Initialized
DEBUG - 2012-07-24 15:33:07 --> Router Class Initialized
DEBUG - 2012-07-24 15:33:07 --> Output Class Initialized
DEBUG - 2012-07-24 15:33:07 --> Security Class Initialized
DEBUG - 2012-07-24 15:33:07 --> Input Class Initialized
DEBUG - 2012-07-24 15:33:07 --> XSS Filtering completed
DEBUG - 2012-07-24 15:33:07 --> XSS Filtering completed
DEBUG - 2012-07-24 15:33:07 --> XSS Filtering completed
DEBUG - 2012-07-24 15:33:07 --> XSS Filtering completed
DEBUG - 2012-07-24 15:33:07 --> XSS Filtering completed
DEBUG - 2012-07-24 15:33:07 --> XSS Filtering completed
DEBUG - 2012-07-24 15:33:07 --> XSS Filtering completed
DEBUG - 2012-07-24 15:33:07 --> XSS Filtering completed
DEBUG - 2012-07-24 15:33:07 --> XSS Filtering completed
DEBUG - 2012-07-24 15:33:07 --> XSS Filtering completed
DEBUG - 2012-07-24 15:33:07 --> XSS Filtering completed
DEBUG - 2012-07-24 15:33:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 15:33:07 --> Language Class Initialized
DEBUG - 2012-07-24 15:33:07 --> Loader Class Initialized
DEBUG - 2012-07-24 15:33:07 --> Helper loaded: url_helper
DEBUG - 2012-07-24 15:33:07 --> Controller Class Initialized
DEBUG - 2012-07-24 15:33:07 --> Model Class Initialized
DEBUG - 2012-07-24 15:33:07 --> Database Driver Class Initialized
DEBUG - 2012-07-24 15:33:07 --> Helper loaded: form_helper
DEBUG - 2012-07-24 15:33:07 --> Form Validation Class Initialized
DEBUG - 2012-07-24 15:41:50 --> Config Class Initialized
DEBUG - 2012-07-24 15:41:50 --> Hooks Class Initialized
DEBUG - 2012-07-24 15:41:50 --> Utf8 Class Initialized
DEBUG - 2012-07-24 15:41:50 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 15:41:50 --> URI Class Initialized
DEBUG - 2012-07-24 15:41:50 --> Router Class Initialized
DEBUG - 2012-07-24 15:41:50 --> Output Class Initialized
DEBUG - 2012-07-24 15:41:50 --> Security Class Initialized
DEBUG - 2012-07-24 15:41:50 --> Input Class Initialized
DEBUG - 2012-07-24 15:41:50 --> XSS Filtering completed
DEBUG - 2012-07-24 15:41:50 --> XSS Filtering completed
DEBUG - 2012-07-24 15:41:50 --> XSS Filtering completed
DEBUG - 2012-07-24 15:41:50 --> XSS Filtering completed
DEBUG - 2012-07-24 15:41:50 --> XSS Filtering completed
DEBUG - 2012-07-24 15:41:50 --> XSS Filtering completed
DEBUG - 2012-07-24 15:41:50 --> XSS Filtering completed
DEBUG - 2012-07-24 15:41:50 --> XSS Filtering completed
DEBUG - 2012-07-24 15:41:50 --> XSS Filtering completed
DEBUG - 2012-07-24 15:41:50 --> XSS Filtering completed
DEBUG - 2012-07-24 15:41:50 --> XSS Filtering completed
DEBUG - 2012-07-24 15:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 15:41:50 --> Language Class Initialized
DEBUG - 2012-07-24 15:41:50 --> Loader Class Initialized
DEBUG - 2012-07-24 15:41:50 --> Helper loaded: url_helper
DEBUG - 2012-07-24 15:41:50 --> Controller Class Initialized
DEBUG - 2012-07-24 15:41:50 --> Model Class Initialized
DEBUG - 2012-07-24 15:41:50 --> Database Driver Class Initialized
DEBUG - 2012-07-24 15:41:50 --> Helper loaded: form_helper
DEBUG - 2012-07-24 15:41:50 --> Form Validation Class Initialized
DEBUG - 2012-07-24 15:42:24 --> Config Class Initialized
DEBUG - 2012-07-24 15:42:24 --> Hooks Class Initialized
DEBUG - 2012-07-24 15:42:24 --> Utf8 Class Initialized
DEBUG - 2012-07-24 15:42:24 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 15:42:24 --> URI Class Initialized
DEBUG - 2012-07-24 15:42:24 --> Router Class Initialized
DEBUG - 2012-07-24 15:42:24 --> Output Class Initialized
DEBUG - 2012-07-24 15:42:24 --> Security Class Initialized
DEBUG - 2012-07-24 15:42:24 --> Input Class Initialized
DEBUG - 2012-07-24 15:42:24 --> XSS Filtering completed
DEBUG - 2012-07-24 15:42:24 --> XSS Filtering completed
DEBUG - 2012-07-24 15:42:24 --> XSS Filtering completed
DEBUG - 2012-07-24 15:42:24 --> XSS Filtering completed
DEBUG - 2012-07-24 15:42:24 --> XSS Filtering completed
DEBUG - 2012-07-24 15:42:24 --> XSS Filtering completed
DEBUG - 2012-07-24 15:42:24 --> XSS Filtering completed
DEBUG - 2012-07-24 15:42:24 --> XSS Filtering completed
DEBUG - 2012-07-24 15:42:24 --> XSS Filtering completed
DEBUG - 2012-07-24 15:42:24 --> XSS Filtering completed
DEBUG - 2012-07-24 15:42:24 --> XSS Filtering completed
DEBUG - 2012-07-24 15:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 15:42:24 --> Language Class Initialized
DEBUG - 2012-07-24 15:42:24 --> Loader Class Initialized
DEBUG - 2012-07-24 15:42:24 --> Helper loaded: url_helper
DEBUG - 2012-07-24 15:42:24 --> Controller Class Initialized
DEBUG - 2012-07-24 15:42:24 --> Model Class Initialized
DEBUG - 2012-07-24 15:42:24 --> Database Driver Class Initialized
DEBUG - 2012-07-24 15:42:24 --> Helper loaded: form_helper
DEBUG - 2012-07-24 15:42:24 --> Form Validation Class Initialized
ERROR - 2012-07-24 15:42:24 --> Severity: Notice  --> Undefined index: print_size_1 /home/jwp/www/justinwylliephotography.com/clients/application/libraries/Prices.php 28
ERROR - 2012-07-24 15:42:24 --> Severity: Notice  --> Undefined index: print_size_2 /home/jwp/www/justinwylliephotography.com/clients/application/libraries/Prices.php 28
DEBUG - 2012-07-24 15:47:45 --> Config Class Initialized
DEBUG - 2012-07-24 15:47:45 --> Hooks Class Initialized
DEBUG - 2012-07-24 15:47:45 --> Utf8 Class Initialized
DEBUG - 2012-07-24 15:47:45 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 15:47:45 --> URI Class Initialized
DEBUG - 2012-07-24 15:47:45 --> Router Class Initialized
DEBUG - 2012-07-24 15:47:45 --> Output Class Initialized
DEBUG - 2012-07-24 15:47:45 --> Security Class Initialized
DEBUG - 2012-07-24 15:47:45 --> Input Class Initialized
DEBUG - 2012-07-24 15:47:45 --> XSS Filtering completed
DEBUG - 2012-07-24 15:47:45 --> XSS Filtering completed
DEBUG - 2012-07-24 15:47:45 --> XSS Filtering completed
DEBUG - 2012-07-24 15:47:45 --> XSS Filtering completed
DEBUG - 2012-07-24 15:47:45 --> XSS Filtering completed
DEBUG - 2012-07-24 15:47:45 --> XSS Filtering completed
DEBUG - 2012-07-24 15:47:45 --> XSS Filtering completed
DEBUG - 2012-07-24 15:47:45 --> XSS Filtering completed
DEBUG - 2012-07-24 15:47:45 --> XSS Filtering completed
DEBUG - 2012-07-24 15:47:45 --> XSS Filtering completed
DEBUG - 2012-07-24 15:47:45 --> XSS Filtering completed
DEBUG - 2012-07-24 15:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 15:47:45 --> Language Class Initialized
DEBUG - 2012-07-24 15:47:45 --> Loader Class Initialized
DEBUG - 2012-07-24 15:47:45 --> Helper loaded: url_helper
DEBUG - 2012-07-24 15:47:45 --> Controller Class Initialized
DEBUG - 2012-07-24 15:47:45 --> Model Class Initialized
DEBUG - 2012-07-24 15:47:45 --> Database Driver Class Initialized
DEBUG - 2012-07-24 15:47:45 --> Helper loaded: form_helper
DEBUG - 2012-07-24 15:47:45 --> Form Validation Class Initialized
DEBUG - 2012-07-24 15:54:17 --> Config Class Initialized
DEBUG - 2012-07-24 15:54:17 --> Hooks Class Initialized
DEBUG - 2012-07-24 15:54:17 --> Utf8 Class Initialized
DEBUG - 2012-07-24 15:54:17 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 15:54:17 --> URI Class Initialized
DEBUG - 2012-07-24 15:54:17 --> Router Class Initialized
DEBUG - 2012-07-24 15:54:17 --> Output Class Initialized
DEBUG - 2012-07-24 15:54:17 --> Security Class Initialized
DEBUG - 2012-07-24 15:54:17 --> Input Class Initialized
DEBUG - 2012-07-24 15:54:17 --> XSS Filtering completed
DEBUG - 2012-07-24 15:54:17 --> XSS Filtering completed
DEBUG - 2012-07-24 15:54:17 --> XSS Filtering completed
DEBUG - 2012-07-24 15:54:17 --> XSS Filtering completed
DEBUG - 2012-07-24 15:54:17 --> XSS Filtering completed
DEBUG - 2012-07-24 15:54:17 --> XSS Filtering completed
DEBUG - 2012-07-24 15:54:17 --> XSS Filtering completed
DEBUG - 2012-07-24 15:54:17 --> XSS Filtering completed
DEBUG - 2012-07-24 15:54:17 --> XSS Filtering completed
DEBUG - 2012-07-24 15:54:17 --> XSS Filtering completed
DEBUG - 2012-07-24 15:54:17 --> XSS Filtering completed
DEBUG - 2012-07-24 15:54:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 15:54:17 --> Language Class Initialized
DEBUG - 2012-07-24 15:54:17 --> Loader Class Initialized
DEBUG - 2012-07-24 15:54:17 --> Helper loaded: url_helper
DEBUG - 2012-07-24 15:54:17 --> Controller Class Initialized
DEBUG - 2012-07-24 15:54:17 --> Model Class Initialized
DEBUG - 2012-07-24 15:54:17 --> Database Driver Class Initialized
DEBUG - 2012-07-24 15:54:17 --> Helper loaded: form_helper
DEBUG - 2012-07-24 15:54:17 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:12:40 --> Config Class Initialized
DEBUG - 2012-07-24 16:12:40 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:12:40 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:12:40 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:12:40 --> URI Class Initialized
DEBUG - 2012-07-24 16:12:40 --> Router Class Initialized
DEBUG - 2012-07-24 16:12:40 --> Output Class Initialized
DEBUG - 2012-07-24 16:12:40 --> Security Class Initialized
DEBUG - 2012-07-24 16:12:40 --> Input Class Initialized
DEBUG - 2012-07-24 16:12:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:12:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:12:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:12:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:12:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:12:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:12:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:12:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:12:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:12:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:12:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:12:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:12:40 --> Language Class Initialized
DEBUG - 2012-07-24 16:12:40 --> Loader Class Initialized
DEBUG - 2012-07-24 16:12:40 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:12:40 --> Controller Class Initialized
DEBUG - 2012-07-24 16:12:40 --> Model Class Initialized
DEBUG - 2012-07-24 16:12:40 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:13:50 --> Config Class Initialized
DEBUG - 2012-07-24 16:13:50 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:13:50 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:13:50 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:13:50 --> URI Class Initialized
DEBUG - 2012-07-24 16:13:50 --> Router Class Initialized
DEBUG - 2012-07-24 16:13:50 --> Output Class Initialized
DEBUG - 2012-07-24 16:13:50 --> Security Class Initialized
DEBUG - 2012-07-24 16:13:50 --> Input Class Initialized
DEBUG - 2012-07-24 16:13:50 --> XSS Filtering completed
DEBUG - 2012-07-24 16:13:50 --> XSS Filtering completed
DEBUG - 2012-07-24 16:13:50 --> XSS Filtering completed
DEBUG - 2012-07-24 16:13:50 --> XSS Filtering completed
DEBUG - 2012-07-24 16:13:50 --> XSS Filtering completed
DEBUG - 2012-07-24 16:13:50 --> XSS Filtering completed
DEBUG - 2012-07-24 16:13:50 --> XSS Filtering completed
DEBUG - 2012-07-24 16:13:50 --> XSS Filtering completed
DEBUG - 2012-07-24 16:13:50 --> XSS Filtering completed
DEBUG - 2012-07-24 16:13:50 --> XSS Filtering completed
DEBUG - 2012-07-24 16:13:50 --> XSS Filtering completed
DEBUG - 2012-07-24 16:13:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:13:50 --> Language Class Initialized
DEBUG - 2012-07-24 16:13:50 --> Loader Class Initialized
DEBUG - 2012-07-24 16:13:50 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:13:50 --> Controller Class Initialized
DEBUG - 2012-07-24 16:13:50 --> Model Class Initialized
DEBUG - 2012-07-24 16:13:50 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:13:50 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:13:50 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:19:37 --> Config Class Initialized
DEBUG - 2012-07-24 16:19:37 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:19:37 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:19:37 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:19:37 --> URI Class Initialized
DEBUG - 2012-07-24 16:19:37 --> Router Class Initialized
DEBUG - 2012-07-24 16:19:37 --> Output Class Initialized
DEBUG - 2012-07-24 16:19:37 --> Security Class Initialized
DEBUG - 2012-07-24 16:19:37 --> Input Class Initialized
DEBUG - 2012-07-24 16:19:37 --> XSS Filtering completed
DEBUG - 2012-07-24 16:19:37 --> XSS Filtering completed
DEBUG - 2012-07-24 16:19:37 --> XSS Filtering completed
DEBUG - 2012-07-24 16:19:37 --> XSS Filtering completed
DEBUG - 2012-07-24 16:19:37 --> XSS Filtering completed
DEBUG - 2012-07-24 16:19:37 --> XSS Filtering completed
DEBUG - 2012-07-24 16:19:37 --> XSS Filtering completed
DEBUG - 2012-07-24 16:19:37 --> XSS Filtering completed
DEBUG - 2012-07-24 16:19:37 --> XSS Filtering completed
DEBUG - 2012-07-24 16:19:37 --> XSS Filtering completed
DEBUG - 2012-07-24 16:19:37 --> XSS Filtering completed
DEBUG - 2012-07-24 16:19:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:19:37 --> Language Class Initialized
DEBUG - 2012-07-24 16:19:37 --> Loader Class Initialized
DEBUG - 2012-07-24 16:19:37 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:19:37 --> Controller Class Initialized
DEBUG - 2012-07-24 16:19:37 --> Model Class Initialized
DEBUG - 2012-07-24 16:19:37 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:19:37 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:19:37 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:22:40 --> Config Class Initialized
DEBUG - 2012-07-24 16:22:40 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:22:40 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:22:40 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:22:40 --> URI Class Initialized
DEBUG - 2012-07-24 16:22:40 --> Router Class Initialized
DEBUG - 2012-07-24 16:22:40 --> Output Class Initialized
DEBUG - 2012-07-24 16:22:40 --> Security Class Initialized
DEBUG - 2012-07-24 16:22:40 --> Input Class Initialized
DEBUG - 2012-07-24 16:22:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:22:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:22:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:22:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:22:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:22:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:22:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:22:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:22:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:22:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:22:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:22:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:22:40 --> Language Class Initialized
DEBUG - 2012-07-24 16:22:40 --> Loader Class Initialized
DEBUG - 2012-07-24 16:22:40 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:22:40 --> Controller Class Initialized
DEBUG - 2012-07-24 16:22:40 --> Model Class Initialized
DEBUG - 2012-07-24 16:22:40 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:22:40 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:22:40 --> Form Validation Class Initialized
ERROR - 2012-07-24 16:22:40 --> Severity: Notice  --> Undefined index: updates /home/jwp/www/justinwylliephotography.com/clients/application/controllers/admin/pricing.php 68
ERROR - 2012-07-24 16:22:40 --> Severity: Notice  --> Undefined index: inserts /home/jwp/www/justinwylliephotography.com/clients/application/controllers/admin/pricing.php 72
DEBUG - 2012-07-24 16:22:40 --> Final output sent to browser
DEBUG - 2012-07-24 16:22:40 --> Total execution time: 0.0464
DEBUG - 2012-07-24 16:23:14 --> Config Class Initialized
DEBUG - 2012-07-24 16:23:14 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:23:14 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:23:14 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:23:14 --> URI Class Initialized
DEBUG - 2012-07-24 16:23:14 --> Router Class Initialized
DEBUG - 2012-07-24 16:23:14 --> Output Class Initialized
DEBUG - 2012-07-24 16:23:14 --> Security Class Initialized
DEBUG - 2012-07-24 16:23:14 --> Input Class Initialized
DEBUG - 2012-07-24 16:23:14 --> XSS Filtering completed
DEBUG - 2012-07-24 16:23:14 --> XSS Filtering completed
DEBUG - 2012-07-24 16:23:14 --> XSS Filtering completed
DEBUG - 2012-07-24 16:23:14 --> XSS Filtering completed
DEBUG - 2012-07-24 16:23:14 --> XSS Filtering completed
DEBUG - 2012-07-24 16:23:14 --> XSS Filtering completed
DEBUG - 2012-07-24 16:23:14 --> XSS Filtering completed
DEBUG - 2012-07-24 16:23:14 --> XSS Filtering completed
DEBUG - 2012-07-24 16:23:14 --> XSS Filtering completed
DEBUG - 2012-07-24 16:23:14 --> XSS Filtering completed
DEBUG - 2012-07-24 16:23:14 --> XSS Filtering completed
DEBUG - 2012-07-24 16:23:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:23:14 --> Language Class Initialized
DEBUG - 2012-07-24 16:23:14 --> Loader Class Initialized
DEBUG - 2012-07-24 16:23:14 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:23:14 --> Controller Class Initialized
DEBUG - 2012-07-24 16:23:14 --> Model Class Initialized
DEBUG - 2012-07-24 16:23:14 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:23:14 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:23:14 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:23:14 --> Final output sent to browser
DEBUG - 2012-07-24 16:23:14 --> Total execution time: 0.0543
DEBUG - 2012-07-24 16:26:28 --> Config Class Initialized
DEBUG - 2012-07-24 16:26:28 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:26:28 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:26:28 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:26:28 --> URI Class Initialized
DEBUG - 2012-07-24 16:26:28 --> Router Class Initialized
DEBUG - 2012-07-24 16:26:28 --> Output Class Initialized
DEBUG - 2012-07-24 16:26:28 --> Security Class Initialized
DEBUG - 2012-07-24 16:26:28 --> Input Class Initialized
DEBUG - 2012-07-24 16:26:28 --> XSS Filtering completed
DEBUG - 2012-07-24 16:26:28 --> XSS Filtering completed
DEBUG - 2012-07-24 16:26:28 --> XSS Filtering completed
DEBUG - 2012-07-24 16:26:28 --> XSS Filtering completed
DEBUG - 2012-07-24 16:26:28 --> XSS Filtering completed
DEBUG - 2012-07-24 16:26:28 --> XSS Filtering completed
DEBUG - 2012-07-24 16:26:28 --> XSS Filtering completed
DEBUG - 2012-07-24 16:26:28 --> XSS Filtering completed
DEBUG - 2012-07-24 16:26:28 --> XSS Filtering completed
DEBUG - 2012-07-24 16:26:28 --> XSS Filtering completed
DEBUG - 2012-07-24 16:26:28 --> XSS Filtering completed
DEBUG - 2012-07-24 16:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:26:28 --> Language Class Initialized
DEBUG - 2012-07-24 16:26:28 --> Loader Class Initialized
DEBUG - 2012-07-24 16:26:28 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:26:28 --> Controller Class Initialized
DEBUG - 2012-07-24 16:26:28 --> Model Class Initialized
DEBUG - 2012-07-24 16:26:28 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:26:28 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:26:28 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:26:28 --> Final output sent to browser
DEBUG - 2012-07-24 16:26:28 --> Total execution time: 0.0408
DEBUG - 2012-07-24 16:27:02 --> Config Class Initialized
DEBUG - 2012-07-24 16:27:02 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:27:02 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:27:02 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:27:02 --> URI Class Initialized
DEBUG - 2012-07-24 16:27:02 --> Router Class Initialized
DEBUG - 2012-07-24 16:27:02 --> Output Class Initialized
DEBUG - 2012-07-24 16:27:02 --> Security Class Initialized
DEBUG - 2012-07-24 16:27:02 --> Input Class Initialized
DEBUG - 2012-07-24 16:27:02 --> XSS Filtering completed
DEBUG - 2012-07-24 16:27:02 --> XSS Filtering completed
DEBUG - 2012-07-24 16:27:02 --> XSS Filtering completed
DEBUG - 2012-07-24 16:27:02 --> XSS Filtering completed
DEBUG - 2012-07-24 16:27:02 --> XSS Filtering completed
DEBUG - 2012-07-24 16:27:02 --> XSS Filtering completed
DEBUG - 2012-07-24 16:27:02 --> XSS Filtering completed
DEBUG - 2012-07-24 16:27:02 --> XSS Filtering completed
DEBUG - 2012-07-24 16:27:02 --> XSS Filtering completed
DEBUG - 2012-07-24 16:27:02 --> XSS Filtering completed
DEBUG - 2012-07-24 16:27:02 --> XSS Filtering completed
DEBUG - 2012-07-24 16:27:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:27:02 --> Language Class Initialized
DEBUG - 2012-07-24 16:27:02 --> Loader Class Initialized
DEBUG - 2012-07-24 16:27:02 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:27:02 --> Controller Class Initialized
DEBUG - 2012-07-24 16:27:02 --> Model Class Initialized
DEBUG - 2012-07-24 16:27:02 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:27:02 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:27:02 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:28:16 --> Config Class Initialized
DEBUG - 2012-07-24 16:28:16 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:28:16 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:28:16 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:28:16 --> URI Class Initialized
DEBUG - 2012-07-24 16:28:16 --> Router Class Initialized
DEBUG - 2012-07-24 16:28:16 --> Output Class Initialized
DEBUG - 2012-07-24 16:28:16 --> Security Class Initialized
DEBUG - 2012-07-24 16:28:16 --> Input Class Initialized
DEBUG - 2012-07-24 16:28:16 --> XSS Filtering completed
DEBUG - 2012-07-24 16:28:16 --> XSS Filtering completed
DEBUG - 2012-07-24 16:28:16 --> XSS Filtering completed
DEBUG - 2012-07-24 16:28:16 --> XSS Filtering completed
DEBUG - 2012-07-24 16:28:16 --> XSS Filtering completed
DEBUG - 2012-07-24 16:28:16 --> XSS Filtering completed
DEBUG - 2012-07-24 16:28:16 --> XSS Filtering completed
DEBUG - 2012-07-24 16:28:16 --> XSS Filtering completed
DEBUG - 2012-07-24 16:28:16 --> XSS Filtering completed
DEBUG - 2012-07-24 16:28:16 --> XSS Filtering completed
DEBUG - 2012-07-24 16:28:16 --> XSS Filtering completed
DEBUG - 2012-07-24 16:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:28:16 --> Language Class Initialized
DEBUG - 2012-07-24 16:28:16 --> Loader Class Initialized
DEBUG - 2012-07-24 16:28:16 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:28:16 --> Controller Class Initialized
DEBUG - 2012-07-24 16:28:16 --> Model Class Initialized
DEBUG - 2012-07-24 16:28:16 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:28:16 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:28:16 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:28:47 --> Config Class Initialized
DEBUG - 2012-07-24 16:28:47 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:28:47 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:28:47 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:28:47 --> URI Class Initialized
DEBUG - 2012-07-24 16:28:47 --> Router Class Initialized
DEBUG - 2012-07-24 16:28:47 --> Output Class Initialized
DEBUG - 2012-07-24 16:28:47 --> Security Class Initialized
DEBUG - 2012-07-24 16:28:47 --> Input Class Initialized
DEBUG - 2012-07-24 16:28:47 --> XSS Filtering completed
DEBUG - 2012-07-24 16:28:47 --> XSS Filtering completed
DEBUG - 2012-07-24 16:28:47 --> XSS Filtering completed
DEBUG - 2012-07-24 16:28:47 --> XSS Filtering completed
DEBUG - 2012-07-24 16:28:47 --> XSS Filtering completed
DEBUG - 2012-07-24 16:28:47 --> XSS Filtering completed
DEBUG - 2012-07-24 16:28:47 --> XSS Filtering completed
DEBUG - 2012-07-24 16:28:47 --> XSS Filtering completed
DEBUG - 2012-07-24 16:28:47 --> XSS Filtering completed
DEBUG - 2012-07-24 16:28:47 --> XSS Filtering completed
DEBUG - 2012-07-24 16:28:47 --> XSS Filtering completed
DEBUG - 2012-07-24 16:28:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:28:47 --> Language Class Initialized
DEBUG - 2012-07-24 16:28:47 --> Loader Class Initialized
DEBUG - 2012-07-24 16:28:47 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:28:47 --> Controller Class Initialized
DEBUG - 2012-07-24 16:28:47 --> Model Class Initialized
DEBUG - 2012-07-24 16:28:47 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:28:47 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:28:47 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:30:25 --> Config Class Initialized
DEBUG - 2012-07-24 16:30:25 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:30:25 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:30:25 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:30:25 --> URI Class Initialized
DEBUG - 2012-07-24 16:30:25 --> Router Class Initialized
DEBUG - 2012-07-24 16:30:25 --> Output Class Initialized
DEBUG - 2012-07-24 16:30:25 --> Security Class Initialized
DEBUG - 2012-07-24 16:30:25 --> Input Class Initialized
DEBUG - 2012-07-24 16:30:25 --> XSS Filtering completed
DEBUG - 2012-07-24 16:30:25 --> XSS Filtering completed
DEBUG - 2012-07-24 16:30:25 --> XSS Filtering completed
DEBUG - 2012-07-24 16:30:25 --> XSS Filtering completed
DEBUG - 2012-07-24 16:30:25 --> XSS Filtering completed
DEBUG - 2012-07-24 16:30:25 --> XSS Filtering completed
DEBUG - 2012-07-24 16:30:25 --> XSS Filtering completed
DEBUG - 2012-07-24 16:30:25 --> XSS Filtering completed
DEBUG - 2012-07-24 16:30:25 --> XSS Filtering completed
DEBUG - 2012-07-24 16:30:25 --> XSS Filtering completed
DEBUG - 2012-07-24 16:30:25 --> XSS Filtering completed
DEBUG - 2012-07-24 16:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:30:25 --> Language Class Initialized
DEBUG - 2012-07-24 16:30:25 --> Loader Class Initialized
DEBUG - 2012-07-24 16:30:25 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:30:25 --> Controller Class Initialized
DEBUG - 2012-07-24 16:30:25 --> Model Class Initialized
DEBUG - 2012-07-24 16:30:25 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:30:25 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:30:25 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:30:49 --> Config Class Initialized
DEBUG - 2012-07-24 16:30:49 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:30:49 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:30:49 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:30:49 --> URI Class Initialized
DEBUG - 2012-07-24 16:30:49 --> Router Class Initialized
DEBUG - 2012-07-24 16:30:49 --> Output Class Initialized
DEBUG - 2012-07-24 16:30:49 --> Security Class Initialized
DEBUG - 2012-07-24 16:30:49 --> Input Class Initialized
DEBUG - 2012-07-24 16:30:49 --> XSS Filtering completed
DEBUG - 2012-07-24 16:30:49 --> XSS Filtering completed
DEBUG - 2012-07-24 16:30:49 --> XSS Filtering completed
DEBUG - 2012-07-24 16:30:49 --> XSS Filtering completed
DEBUG - 2012-07-24 16:30:49 --> XSS Filtering completed
DEBUG - 2012-07-24 16:30:49 --> XSS Filtering completed
DEBUG - 2012-07-24 16:30:49 --> XSS Filtering completed
DEBUG - 2012-07-24 16:30:49 --> XSS Filtering completed
DEBUG - 2012-07-24 16:30:49 --> XSS Filtering completed
DEBUG - 2012-07-24 16:30:49 --> XSS Filtering completed
DEBUG - 2012-07-24 16:30:49 --> XSS Filtering completed
DEBUG - 2012-07-24 16:30:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:30:49 --> Language Class Initialized
DEBUG - 2012-07-24 16:30:49 --> Loader Class Initialized
DEBUG - 2012-07-24 16:30:49 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:30:49 --> Controller Class Initialized
DEBUG - 2012-07-24 16:30:49 --> Model Class Initialized
DEBUG - 2012-07-24 16:30:49 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:30:49 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:30:49 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:31:04 --> Config Class Initialized
DEBUG - 2012-07-24 16:31:04 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:31:04 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:31:04 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:31:04 --> URI Class Initialized
DEBUG - 2012-07-24 16:31:04 --> Router Class Initialized
DEBUG - 2012-07-24 16:31:04 --> Output Class Initialized
DEBUG - 2012-07-24 16:31:04 --> Security Class Initialized
DEBUG - 2012-07-24 16:31:04 --> Input Class Initialized
DEBUG - 2012-07-24 16:31:04 --> XSS Filtering completed
DEBUG - 2012-07-24 16:31:04 --> XSS Filtering completed
DEBUG - 2012-07-24 16:31:04 --> XSS Filtering completed
DEBUG - 2012-07-24 16:31:04 --> XSS Filtering completed
DEBUG - 2012-07-24 16:31:04 --> XSS Filtering completed
DEBUG - 2012-07-24 16:31:04 --> XSS Filtering completed
DEBUG - 2012-07-24 16:31:04 --> XSS Filtering completed
DEBUG - 2012-07-24 16:31:05 --> XSS Filtering completed
DEBUG - 2012-07-24 16:31:05 --> XSS Filtering completed
DEBUG - 2012-07-24 16:31:05 --> XSS Filtering completed
DEBUG - 2012-07-24 16:31:05 --> XSS Filtering completed
DEBUG - 2012-07-24 16:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:31:05 --> Language Class Initialized
DEBUG - 2012-07-24 16:31:05 --> Loader Class Initialized
DEBUG - 2012-07-24 16:31:05 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:31:05 --> Controller Class Initialized
DEBUG - 2012-07-24 16:31:05 --> Model Class Initialized
DEBUG - 2012-07-24 16:31:05 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:31:05 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:31:05 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:31:41 --> Config Class Initialized
DEBUG - 2012-07-24 16:31:41 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:31:41 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:31:41 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:31:41 --> URI Class Initialized
DEBUG - 2012-07-24 16:31:41 --> Router Class Initialized
DEBUG - 2012-07-24 16:31:41 --> Output Class Initialized
DEBUG - 2012-07-24 16:31:41 --> Security Class Initialized
DEBUG - 2012-07-24 16:31:41 --> Input Class Initialized
DEBUG - 2012-07-24 16:31:41 --> XSS Filtering completed
DEBUG - 2012-07-24 16:31:41 --> XSS Filtering completed
DEBUG - 2012-07-24 16:31:41 --> XSS Filtering completed
DEBUG - 2012-07-24 16:31:41 --> XSS Filtering completed
DEBUG - 2012-07-24 16:31:41 --> XSS Filtering completed
DEBUG - 2012-07-24 16:31:41 --> XSS Filtering completed
DEBUG - 2012-07-24 16:31:41 --> XSS Filtering completed
DEBUG - 2012-07-24 16:31:41 --> XSS Filtering completed
DEBUG - 2012-07-24 16:31:41 --> XSS Filtering completed
DEBUG - 2012-07-24 16:31:41 --> XSS Filtering completed
DEBUG - 2012-07-24 16:31:41 --> XSS Filtering completed
DEBUG - 2012-07-24 16:31:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:31:41 --> Language Class Initialized
DEBUG - 2012-07-24 16:31:41 --> Loader Class Initialized
DEBUG - 2012-07-24 16:31:41 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:31:41 --> Controller Class Initialized
DEBUG - 2012-07-24 16:31:41 --> Model Class Initialized
DEBUG - 2012-07-24 16:31:41 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:31:41 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:31:41 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:35:37 --> Config Class Initialized
DEBUG - 2012-07-24 16:35:37 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:35:37 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:35:37 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:35:37 --> URI Class Initialized
DEBUG - 2012-07-24 16:35:37 --> Router Class Initialized
DEBUG - 2012-07-24 16:35:37 --> Output Class Initialized
DEBUG - 2012-07-24 16:35:37 --> Security Class Initialized
DEBUG - 2012-07-24 16:35:37 --> Input Class Initialized
DEBUG - 2012-07-24 16:35:37 --> XSS Filtering completed
DEBUG - 2012-07-24 16:35:37 --> XSS Filtering completed
DEBUG - 2012-07-24 16:35:37 --> XSS Filtering completed
DEBUG - 2012-07-24 16:35:37 --> XSS Filtering completed
DEBUG - 2012-07-24 16:35:37 --> XSS Filtering completed
DEBUG - 2012-07-24 16:35:37 --> XSS Filtering completed
DEBUG - 2012-07-24 16:35:37 --> XSS Filtering completed
DEBUG - 2012-07-24 16:35:37 --> XSS Filtering completed
DEBUG - 2012-07-24 16:35:37 --> XSS Filtering completed
DEBUG - 2012-07-24 16:35:37 --> XSS Filtering completed
DEBUG - 2012-07-24 16:35:37 --> XSS Filtering completed
DEBUG - 2012-07-24 16:35:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:35:37 --> Language Class Initialized
DEBUG - 2012-07-24 16:35:37 --> Loader Class Initialized
DEBUG - 2012-07-24 16:35:37 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:35:37 --> Controller Class Initialized
DEBUG - 2012-07-24 16:35:37 --> Model Class Initialized
DEBUG - 2012-07-24 16:35:37 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:35:37 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:35:37 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:35:38 --> Final output sent to browser
DEBUG - 2012-07-24 16:35:38 --> Total execution time: 0.2235
DEBUG - 2012-07-24 16:37:36 --> Config Class Initialized
DEBUG - 2012-07-24 16:37:36 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:37:36 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:37:36 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:37:36 --> URI Class Initialized
DEBUG - 2012-07-24 16:37:36 --> Router Class Initialized
DEBUG - 2012-07-24 16:37:36 --> Output Class Initialized
DEBUG - 2012-07-24 16:37:36 --> Security Class Initialized
DEBUG - 2012-07-24 16:37:36 --> Input Class Initialized
DEBUG - 2012-07-24 16:37:36 --> XSS Filtering completed
DEBUG - 2012-07-24 16:37:36 --> XSS Filtering completed
DEBUG - 2012-07-24 16:37:36 --> XSS Filtering completed
DEBUG - 2012-07-24 16:37:36 --> XSS Filtering completed
DEBUG - 2012-07-24 16:37:36 --> XSS Filtering completed
DEBUG - 2012-07-24 16:37:36 --> XSS Filtering completed
DEBUG - 2012-07-24 16:37:36 --> XSS Filtering completed
DEBUG - 2012-07-24 16:37:36 --> XSS Filtering completed
DEBUG - 2012-07-24 16:37:36 --> XSS Filtering completed
DEBUG - 2012-07-24 16:37:36 --> XSS Filtering completed
DEBUG - 2012-07-24 16:37:36 --> XSS Filtering completed
DEBUG - 2012-07-24 16:37:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:37:36 --> Language Class Initialized
DEBUG - 2012-07-24 16:37:36 --> Loader Class Initialized
DEBUG - 2012-07-24 16:37:36 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:37:36 --> Controller Class Initialized
DEBUG - 2012-07-24 16:37:36 --> Model Class Initialized
DEBUG - 2012-07-24 16:37:36 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:37:36 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:37:36 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:38:40 --> Config Class Initialized
DEBUG - 2012-07-24 16:38:40 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:38:40 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:38:40 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:38:40 --> URI Class Initialized
DEBUG - 2012-07-24 16:38:40 --> Router Class Initialized
DEBUG - 2012-07-24 16:38:40 --> Output Class Initialized
DEBUG - 2012-07-24 16:38:40 --> Security Class Initialized
DEBUG - 2012-07-24 16:38:40 --> Input Class Initialized
DEBUG - 2012-07-24 16:38:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:38:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:38:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:38:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:38:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:38:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:38:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:38:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:38:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:38:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:38:40 --> XSS Filtering completed
DEBUG - 2012-07-24 16:38:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:38:40 --> Language Class Initialized
DEBUG - 2012-07-24 16:38:40 --> Loader Class Initialized
DEBUG - 2012-07-24 16:38:40 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:38:40 --> Controller Class Initialized
DEBUG - 2012-07-24 16:38:40 --> Model Class Initialized
DEBUG - 2012-07-24 16:38:40 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:38:40 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:38:40 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:38:40 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-07-24 16:44:44 --> Config Class Initialized
DEBUG - 2012-07-24 16:44:44 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:44:44 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:44:44 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:44:44 --> URI Class Initialized
DEBUG - 2012-07-24 16:44:44 --> Router Class Initialized
DEBUG - 2012-07-24 16:44:44 --> Output Class Initialized
DEBUG - 2012-07-24 16:44:44 --> Security Class Initialized
DEBUG - 2012-07-24 16:44:44 --> Input Class Initialized
DEBUG - 2012-07-24 16:44:44 --> XSS Filtering completed
DEBUG - 2012-07-24 16:44:44 --> XSS Filtering completed
DEBUG - 2012-07-24 16:44:44 --> XSS Filtering completed
DEBUG - 2012-07-24 16:44:44 --> XSS Filtering completed
DEBUG - 2012-07-24 16:44:44 --> XSS Filtering completed
DEBUG - 2012-07-24 16:44:44 --> XSS Filtering completed
DEBUG - 2012-07-24 16:44:44 --> XSS Filtering completed
DEBUG - 2012-07-24 16:44:44 --> XSS Filtering completed
DEBUG - 2012-07-24 16:44:44 --> XSS Filtering completed
DEBUG - 2012-07-24 16:44:44 --> XSS Filtering completed
DEBUG - 2012-07-24 16:44:44 --> XSS Filtering completed
DEBUG - 2012-07-24 16:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:44:44 --> Language Class Initialized
DEBUG - 2012-07-24 16:44:44 --> Loader Class Initialized
DEBUG - 2012-07-24 16:44:44 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:44:44 --> Controller Class Initialized
DEBUG - 2012-07-24 16:44:44 --> Model Class Initialized
DEBUG - 2012-07-24 16:44:44 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:44:44 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:44:44 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:49:12 --> Config Class Initialized
DEBUG - 2012-07-24 16:49:12 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:49:12 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:49:12 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:49:12 --> URI Class Initialized
DEBUG - 2012-07-24 16:49:12 --> Router Class Initialized
DEBUG - 2012-07-24 16:49:12 --> Output Class Initialized
DEBUG - 2012-07-24 16:49:12 --> Security Class Initialized
DEBUG - 2012-07-24 16:49:12 --> Input Class Initialized
DEBUG - 2012-07-24 16:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:49:12 --> Language Class Initialized
DEBUG - 2012-07-24 16:49:12 --> Loader Class Initialized
DEBUG - 2012-07-24 16:49:12 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:49:12 --> Controller Class Initialized
DEBUG - 2012-07-24 16:49:12 --> Model Class Initialized
DEBUG - 2012-07-24 16:49:12 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:49:12 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:49:12 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 16:49:12 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 16:49:12 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 16:49:12 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 16:49:12 --> Final output sent to browser
DEBUG - 2012-07-24 16:49:12 --> Total execution time: 0.0507
DEBUG - 2012-07-24 16:49:17 --> Config Class Initialized
DEBUG - 2012-07-24 16:49:17 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:49:17 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:49:17 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:49:17 --> URI Class Initialized
DEBUG - 2012-07-24 16:49:17 --> Router Class Initialized
DEBUG - 2012-07-24 16:49:17 --> Output Class Initialized
DEBUG - 2012-07-24 16:49:17 --> Security Class Initialized
DEBUG - 2012-07-24 16:49:17 --> Input Class Initialized
DEBUG - 2012-07-24 16:49:17 --> XSS Filtering completed
DEBUG - 2012-07-24 16:49:17 --> XSS Filtering completed
DEBUG - 2012-07-24 16:49:17 --> XSS Filtering completed
DEBUG - 2012-07-24 16:49:17 --> XSS Filtering completed
DEBUG - 2012-07-24 16:49:17 --> XSS Filtering completed
DEBUG - 2012-07-24 16:49:17 --> XSS Filtering completed
DEBUG - 2012-07-24 16:49:17 --> XSS Filtering completed
DEBUG - 2012-07-24 16:49:17 --> XSS Filtering completed
DEBUG - 2012-07-24 16:49:17 --> XSS Filtering completed
DEBUG - 2012-07-24 16:49:17 --> XSS Filtering completed
DEBUG - 2012-07-24 16:49:17 --> XSS Filtering completed
DEBUG - 2012-07-24 16:49:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:49:17 --> Language Class Initialized
DEBUG - 2012-07-24 16:49:17 --> Loader Class Initialized
DEBUG - 2012-07-24 16:49:17 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:49:17 --> Controller Class Initialized
DEBUG - 2012-07-24 16:49:17 --> Model Class Initialized
DEBUG - 2012-07-24 16:49:18 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:49:18 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:49:18 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:49:18 --> Final output sent to browser
DEBUG - 2012-07-24 16:49:18 --> Total execution time: 0.0418
DEBUG - 2012-07-24 16:50:21 --> Config Class Initialized
DEBUG - 2012-07-24 16:50:21 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:50:21 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:50:21 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:50:21 --> URI Class Initialized
DEBUG - 2012-07-24 16:50:21 --> Router Class Initialized
DEBUG - 2012-07-24 16:50:21 --> Output Class Initialized
DEBUG - 2012-07-24 16:50:21 --> Security Class Initialized
DEBUG - 2012-07-24 16:50:21 --> Input Class Initialized
DEBUG - 2012-07-24 16:50:21 --> XSS Filtering completed
DEBUG - 2012-07-24 16:50:21 --> XSS Filtering completed
DEBUG - 2012-07-24 16:50:21 --> XSS Filtering completed
DEBUG - 2012-07-24 16:50:21 --> XSS Filtering completed
DEBUG - 2012-07-24 16:50:21 --> XSS Filtering completed
DEBUG - 2012-07-24 16:50:21 --> XSS Filtering completed
DEBUG - 2012-07-24 16:50:21 --> XSS Filtering completed
DEBUG - 2012-07-24 16:50:21 --> XSS Filtering completed
DEBUG - 2012-07-24 16:50:21 --> XSS Filtering completed
DEBUG - 2012-07-24 16:50:21 --> XSS Filtering completed
DEBUG - 2012-07-24 16:50:21 --> XSS Filtering completed
DEBUG - 2012-07-24 16:50:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:50:21 --> Language Class Initialized
DEBUG - 2012-07-24 16:50:21 --> Loader Class Initialized
DEBUG - 2012-07-24 16:50:21 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:50:21 --> Controller Class Initialized
DEBUG - 2012-07-24 16:50:21 --> Model Class Initialized
DEBUG - 2012-07-24 16:50:21 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:50:21 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:50:21 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:50:21 --> Final output sent to browser
DEBUG - 2012-07-24 16:50:21 --> Total execution time: 0.0420
DEBUG - 2012-07-24 16:50:46 --> Config Class Initialized
DEBUG - 2012-07-24 16:50:46 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:50:46 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:50:46 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:50:46 --> URI Class Initialized
DEBUG - 2012-07-24 16:50:46 --> Router Class Initialized
DEBUG - 2012-07-24 16:50:46 --> Output Class Initialized
DEBUG - 2012-07-24 16:50:46 --> Security Class Initialized
DEBUG - 2012-07-24 16:50:46 --> Input Class Initialized
DEBUG - 2012-07-24 16:50:46 --> XSS Filtering completed
DEBUG - 2012-07-24 16:50:46 --> XSS Filtering completed
DEBUG - 2012-07-24 16:50:46 --> XSS Filtering completed
DEBUG - 2012-07-24 16:50:46 --> XSS Filtering completed
DEBUG - 2012-07-24 16:50:46 --> XSS Filtering completed
DEBUG - 2012-07-24 16:50:46 --> XSS Filtering completed
DEBUG - 2012-07-24 16:50:46 --> XSS Filtering completed
DEBUG - 2012-07-24 16:50:46 --> XSS Filtering completed
DEBUG - 2012-07-24 16:50:46 --> XSS Filtering completed
DEBUG - 2012-07-24 16:50:46 --> XSS Filtering completed
DEBUG - 2012-07-24 16:50:46 --> XSS Filtering completed
DEBUG - 2012-07-24 16:50:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:50:46 --> Language Class Initialized
DEBUG - 2012-07-24 16:50:46 --> Loader Class Initialized
DEBUG - 2012-07-24 16:50:46 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:50:46 --> Controller Class Initialized
DEBUG - 2012-07-24 16:50:46 --> Model Class Initialized
DEBUG - 2012-07-24 16:50:46 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:50:46 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:50:46 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:51:43 --> Config Class Initialized
DEBUG - 2012-07-24 16:51:43 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:51:43 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:51:43 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:51:43 --> URI Class Initialized
DEBUG - 2012-07-24 16:51:43 --> Router Class Initialized
DEBUG - 2012-07-24 16:51:43 --> Output Class Initialized
DEBUG - 2012-07-24 16:51:43 --> Security Class Initialized
DEBUG - 2012-07-24 16:51:43 --> Input Class Initialized
DEBUG - 2012-07-24 16:51:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:51:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:51:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:51:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:51:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:51:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:51:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:51:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:51:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:51:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:51:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:51:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:51:43 --> Language Class Initialized
DEBUG - 2012-07-24 16:51:43 --> Loader Class Initialized
DEBUG - 2012-07-24 16:51:43 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:51:43 --> Controller Class Initialized
DEBUG - 2012-07-24 16:51:43 --> Model Class Initialized
DEBUG - 2012-07-24 16:51:43 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:51:43 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:51:43 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:52:02 --> Config Class Initialized
DEBUG - 2012-07-24 16:52:02 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:52:02 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:52:02 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:52:02 --> URI Class Initialized
DEBUG - 2012-07-24 16:52:02 --> Router Class Initialized
DEBUG - 2012-07-24 16:52:02 --> Output Class Initialized
DEBUG - 2012-07-24 16:52:02 --> Security Class Initialized
DEBUG - 2012-07-24 16:52:02 --> Input Class Initialized
DEBUG - 2012-07-24 16:52:02 --> XSS Filtering completed
DEBUG - 2012-07-24 16:52:02 --> XSS Filtering completed
DEBUG - 2012-07-24 16:52:02 --> XSS Filtering completed
DEBUG - 2012-07-24 16:52:02 --> XSS Filtering completed
DEBUG - 2012-07-24 16:52:02 --> XSS Filtering completed
DEBUG - 2012-07-24 16:52:02 --> XSS Filtering completed
DEBUG - 2012-07-24 16:52:02 --> XSS Filtering completed
DEBUG - 2012-07-24 16:52:02 --> XSS Filtering completed
DEBUG - 2012-07-24 16:52:02 --> XSS Filtering completed
DEBUG - 2012-07-24 16:52:02 --> XSS Filtering completed
DEBUG - 2012-07-24 16:52:02 --> XSS Filtering completed
DEBUG - 2012-07-24 16:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:52:02 --> Language Class Initialized
DEBUG - 2012-07-24 16:52:02 --> Loader Class Initialized
DEBUG - 2012-07-24 16:52:02 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:52:02 --> Controller Class Initialized
DEBUG - 2012-07-24 16:52:02 --> Model Class Initialized
DEBUG - 2012-07-24 16:52:02 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:52:02 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:52:02 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:53:12 --> Config Class Initialized
DEBUG - 2012-07-24 16:53:12 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:53:12 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:53:12 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:53:12 --> URI Class Initialized
DEBUG - 2012-07-24 16:53:12 --> Router Class Initialized
DEBUG - 2012-07-24 16:53:12 --> Output Class Initialized
DEBUG - 2012-07-24 16:53:12 --> Security Class Initialized
DEBUG - 2012-07-24 16:53:12 --> Input Class Initialized
DEBUG - 2012-07-24 16:53:12 --> XSS Filtering completed
DEBUG - 2012-07-24 16:53:12 --> XSS Filtering completed
DEBUG - 2012-07-24 16:53:12 --> XSS Filtering completed
DEBUG - 2012-07-24 16:53:12 --> XSS Filtering completed
DEBUG - 2012-07-24 16:53:12 --> XSS Filtering completed
DEBUG - 2012-07-24 16:53:12 --> XSS Filtering completed
DEBUG - 2012-07-24 16:53:12 --> XSS Filtering completed
DEBUG - 2012-07-24 16:53:12 --> XSS Filtering completed
DEBUG - 2012-07-24 16:53:12 --> XSS Filtering completed
DEBUG - 2012-07-24 16:53:12 --> XSS Filtering completed
DEBUG - 2012-07-24 16:53:12 --> XSS Filtering completed
DEBUG - 2012-07-24 16:53:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:53:12 --> Language Class Initialized
DEBUG - 2012-07-24 16:53:12 --> Loader Class Initialized
DEBUG - 2012-07-24 16:53:12 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:53:12 --> Controller Class Initialized
DEBUG - 2012-07-24 16:53:12 --> Model Class Initialized
DEBUG - 2012-07-24 16:53:12 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:53:12 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:53:12 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:54:07 --> Config Class Initialized
DEBUG - 2012-07-24 16:54:07 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:54:07 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:54:07 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:54:07 --> URI Class Initialized
DEBUG - 2012-07-24 16:54:07 --> Router Class Initialized
DEBUG - 2012-07-24 16:54:07 --> Output Class Initialized
DEBUG - 2012-07-24 16:54:07 --> Security Class Initialized
DEBUG - 2012-07-24 16:54:07 --> Input Class Initialized
DEBUG - 2012-07-24 16:54:07 --> XSS Filtering completed
DEBUG - 2012-07-24 16:54:07 --> XSS Filtering completed
DEBUG - 2012-07-24 16:54:07 --> XSS Filtering completed
DEBUG - 2012-07-24 16:54:07 --> XSS Filtering completed
DEBUG - 2012-07-24 16:54:07 --> XSS Filtering completed
DEBUG - 2012-07-24 16:54:07 --> XSS Filtering completed
DEBUG - 2012-07-24 16:54:07 --> XSS Filtering completed
DEBUG - 2012-07-24 16:54:07 --> XSS Filtering completed
DEBUG - 2012-07-24 16:54:07 --> XSS Filtering completed
DEBUG - 2012-07-24 16:54:07 --> XSS Filtering completed
DEBUG - 2012-07-24 16:54:07 --> XSS Filtering completed
DEBUG - 2012-07-24 16:54:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:54:07 --> Language Class Initialized
DEBUG - 2012-07-24 16:54:07 --> Loader Class Initialized
DEBUG - 2012-07-24 16:54:07 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:54:07 --> Controller Class Initialized
DEBUG - 2012-07-24 16:54:07 --> Model Class Initialized
DEBUG - 2012-07-24 16:54:07 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:54:07 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:54:07 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:54:27 --> Config Class Initialized
DEBUG - 2012-07-24 16:54:27 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:54:27 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:54:27 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:54:27 --> URI Class Initialized
DEBUG - 2012-07-24 16:54:27 --> Router Class Initialized
DEBUG - 2012-07-24 16:54:27 --> Output Class Initialized
DEBUG - 2012-07-24 16:54:27 --> Security Class Initialized
DEBUG - 2012-07-24 16:54:27 --> Input Class Initialized
DEBUG - 2012-07-24 16:54:27 --> XSS Filtering completed
DEBUG - 2012-07-24 16:54:27 --> XSS Filtering completed
DEBUG - 2012-07-24 16:54:27 --> XSS Filtering completed
DEBUG - 2012-07-24 16:54:27 --> XSS Filtering completed
DEBUG - 2012-07-24 16:54:27 --> XSS Filtering completed
DEBUG - 2012-07-24 16:54:27 --> XSS Filtering completed
DEBUG - 2012-07-24 16:54:27 --> XSS Filtering completed
DEBUG - 2012-07-24 16:54:27 --> XSS Filtering completed
DEBUG - 2012-07-24 16:54:27 --> XSS Filtering completed
DEBUG - 2012-07-24 16:54:27 --> XSS Filtering completed
DEBUG - 2012-07-24 16:54:27 --> XSS Filtering completed
DEBUG - 2012-07-24 16:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:54:27 --> Language Class Initialized
DEBUG - 2012-07-24 16:54:27 --> Loader Class Initialized
DEBUG - 2012-07-24 16:54:27 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:54:27 --> Controller Class Initialized
DEBUG - 2012-07-24 16:54:27 --> Model Class Initialized
DEBUG - 2012-07-24 16:54:27 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:54:27 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:54:27 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:55:11 --> Config Class Initialized
DEBUG - 2012-07-24 16:55:11 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:55:11 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:55:11 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:55:11 --> URI Class Initialized
DEBUG - 2012-07-24 16:55:11 --> Router Class Initialized
DEBUG - 2012-07-24 16:55:11 --> Output Class Initialized
DEBUG - 2012-07-24 16:55:11 --> Security Class Initialized
DEBUG - 2012-07-24 16:55:11 --> Input Class Initialized
DEBUG - 2012-07-24 16:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:55:11 --> Language Class Initialized
DEBUG - 2012-07-24 16:55:11 --> Loader Class Initialized
DEBUG - 2012-07-24 16:55:11 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:55:11 --> Controller Class Initialized
DEBUG - 2012-07-24 16:55:11 --> Model Class Initialized
DEBUG - 2012-07-24 16:55:11 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:55:11 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:55:11 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 16:55:11 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 16:55:11 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 16:55:11 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 16:55:11 --> Final output sent to browser
DEBUG - 2012-07-24 16:55:11 --> Total execution time: 0.0456
DEBUG - 2012-07-24 16:55:56 --> Config Class Initialized
DEBUG - 2012-07-24 16:55:56 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:55:56 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:55:56 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:55:56 --> URI Class Initialized
DEBUG - 2012-07-24 16:55:56 --> Router Class Initialized
DEBUG - 2012-07-24 16:55:56 --> Output Class Initialized
DEBUG - 2012-07-24 16:55:56 --> Security Class Initialized
DEBUG - 2012-07-24 16:55:56 --> Input Class Initialized
DEBUG - 2012-07-24 16:55:56 --> XSS Filtering completed
DEBUG - 2012-07-24 16:55:56 --> XSS Filtering completed
DEBUG - 2012-07-24 16:55:56 --> XSS Filtering completed
DEBUG - 2012-07-24 16:55:56 --> XSS Filtering completed
DEBUG - 2012-07-24 16:55:56 --> XSS Filtering completed
DEBUG - 2012-07-24 16:55:56 --> XSS Filtering completed
DEBUG - 2012-07-24 16:55:56 --> XSS Filtering completed
DEBUG - 2012-07-24 16:55:56 --> XSS Filtering completed
DEBUG - 2012-07-24 16:55:56 --> XSS Filtering completed
DEBUG - 2012-07-24 16:55:56 --> XSS Filtering completed
DEBUG - 2012-07-24 16:55:56 --> XSS Filtering completed
DEBUG - 2012-07-24 16:55:56 --> XSS Filtering completed
DEBUG - 2012-07-24 16:55:56 --> XSS Filtering completed
DEBUG - 2012-07-24 16:55:56 --> XSS Filtering completed
DEBUG - 2012-07-24 16:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:55:56 --> Language Class Initialized
DEBUG - 2012-07-24 16:55:56 --> Loader Class Initialized
DEBUG - 2012-07-24 16:55:56 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:55:56 --> Controller Class Initialized
DEBUG - 2012-07-24 16:55:56 --> Model Class Initialized
DEBUG - 2012-07-24 16:55:56 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:55:56 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:55:56 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:56:27 --> Config Class Initialized
DEBUG - 2012-07-24 16:56:27 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:56:27 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:56:27 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:56:27 --> URI Class Initialized
DEBUG - 2012-07-24 16:56:27 --> Router Class Initialized
DEBUG - 2012-07-24 16:56:27 --> Output Class Initialized
DEBUG - 2012-07-24 16:56:27 --> Security Class Initialized
DEBUG - 2012-07-24 16:56:27 --> Input Class Initialized
DEBUG - 2012-07-24 16:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:56:27 --> Language Class Initialized
DEBUG - 2012-07-24 16:56:27 --> Loader Class Initialized
DEBUG - 2012-07-24 16:56:27 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:56:27 --> Controller Class Initialized
DEBUG - 2012-07-24 16:56:27 --> Model Class Initialized
DEBUG - 2012-07-24 16:56:27 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:56:27 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:56:27 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 16:56:27 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 16:56:27 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 16:56:27 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 16:56:27 --> Final output sent to browser
DEBUG - 2012-07-24 16:56:27 --> Total execution time: 0.0391
DEBUG - 2012-07-24 16:56:43 --> Config Class Initialized
DEBUG - 2012-07-24 16:56:43 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:56:43 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:56:43 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:56:43 --> URI Class Initialized
DEBUG - 2012-07-24 16:56:43 --> Router Class Initialized
DEBUG - 2012-07-24 16:56:43 --> Output Class Initialized
DEBUG - 2012-07-24 16:56:43 --> Security Class Initialized
DEBUG - 2012-07-24 16:56:43 --> Input Class Initialized
DEBUG - 2012-07-24 16:56:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:56:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:56:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:56:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:56:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:56:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:56:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:56:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:56:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:56:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:56:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:56:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:56:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:56:43 --> XSS Filtering completed
DEBUG - 2012-07-24 16:56:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:56:43 --> Language Class Initialized
DEBUG - 2012-07-24 16:56:43 --> Loader Class Initialized
DEBUG - 2012-07-24 16:56:43 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:56:43 --> Controller Class Initialized
DEBUG - 2012-07-24 16:56:43 --> Model Class Initialized
DEBUG - 2012-07-24 16:56:43 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:56:43 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:56:43 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:57:25 --> Config Class Initialized
DEBUG - 2012-07-24 16:57:25 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:57:25 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:57:25 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:57:25 --> URI Class Initialized
DEBUG - 2012-07-24 16:57:25 --> Router Class Initialized
DEBUG - 2012-07-24 16:57:25 --> Output Class Initialized
DEBUG - 2012-07-24 16:57:25 --> Security Class Initialized
DEBUG - 2012-07-24 16:57:25 --> Input Class Initialized
DEBUG - 2012-07-24 16:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:57:25 --> Language Class Initialized
DEBUG - 2012-07-24 16:57:25 --> Loader Class Initialized
DEBUG - 2012-07-24 16:57:25 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:57:25 --> Controller Class Initialized
DEBUG - 2012-07-24 16:57:25 --> Model Class Initialized
DEBUG - 2012-07-24 16:57:25 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:57:25 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:57:25 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 16:57:25 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 16:57:25 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 16:57:25 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 16:57:25 --> Final output sent to browser
DEBUG - 2012-07-24 16:57:25 --> Total execution time: 0.0385
DEBUG - 2012-07-24 16:57:42 --> Config Class Initialized
DEBUG - 2012-07-24 16:57:42 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:57:42 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:57:42 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:57:42 --> URI Class Initialized
DEBUG - 2012-07-24 16:57:42 --> Router Class Initialized
DEBUG - 2012-07-24 16:57:42 --> Output Class Initialized
DEBUG - 2012-07-24 16:57:42 --> Security Class Initialized
DEBUG - 2012-07-24 16:57:42 --> Input Class Initialized
DEBUG - 2012-07-24 16:57:42 --> XSS Filtering completed
DEBUG - 2012-07-24 16:57:42 --> XSS Filtering completed
DEBUG - 2012-07-24 16:57:42 --> XSS Filtering completed
DEBUG - 2012-07-24 16:57:42 --> XSS Filtering completed
DEBUG - 2012-07-24 16:57:42 --> XSS Filtering completed
DEBUG - 2012-07-24 16:57:42 --> XSS Filtering completed
DEBUG - 2012-07-24 16:57:42 --> XSS Filtering completed
DEBUG - 2012-07-24 16:57:42 --> XSS Filtering completed
DEBUG - 2012-07-24 16:57:42 --> XSS Filtering completed
DEBUG - 2012-07-24 16:57:42 --> XSS Filtering completed
DEBUG - 2012-07-24 16:57:42 --> XSS Filtering completed
DEBUG - 2012-07-24 16:57:42 --> XSS Filtering completed
DEBUG - 2012-07-24 16:57:42 --> XSS Filtering completed
DEBUG - 2012-07-24 16:57:42 --> XSS Filtering completed
DEBUG - 2012-07-24 16:57:42 --> XSS Filtering completed
DEBUG - 2012-07-24 16:57:42 --> XSS Filtering completed
DEBUG - 2012-07-24 16:57:42 --> XSS Filtering completed
DEBUG - 2012-07-24 16:57:42 --> XSS Filtering completed
DEBUG - 2012-07-24 16:57:42 --> XSS Filtering completed
DEBUG - 2012-07-24 16:57:42 --> XSS Filtering completed
DEBUG - 2012-07-24 16:57:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:57:42 --> Language Class Initialized
DEBUG - 2012-07-24 16:57:42 --> Loader Class Initialized
DEBUG - 2012-07-24 16:57:42 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:57:42 --> Controller Class Initialized
DEBUG - 2012-07-24 16:57:42 --> Model Class Initialized
DEBUG - 2012-07-24 16:57:42 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:57:42 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:57:42 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:58:59 --> Config Class Initialized
DEBUG - 2012-07-24 16:58:59 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:58:59 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:58:59 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:58:59 --> URI Class Initialized
DEBUG - 2012-07-24 16:58:59 --> Router Class Initialized
DEBUG - 2012-07-24 16:58:59 --> Output Class Initialized
DEBUG - 2012-07-24 16:58:59 --> Security Class Initialized
DEBUG - 2012-07-24 16:58:59 --> Input Class Initialized
DEBUG - 2012-07-24 16:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:58:59 --> Language Class Initialized
DEBUG - 2012-07-24 16:58:59 --> Loader Class Initialized
DEBUG - 2012-07-24 16:58:59 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:58:59 --> Controller Class Initialized
DEBUG - 2012-07-24 16:58:59 --> Model Class Initialized
DEBUG - 2012-07-24 16:58:59 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:58:59 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:58:59 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 16:58:59 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 16:58:59 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 16:58:59 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 16:58:59 --> Final output sent to browser
DEBUG - 2012-07-24 16:58:59 --> Total execution time: 0.0706
DEBUG - 2012-07-24 16:59:11 --> Config Class Initialized
DEBUG - 2012-07-24 16:59:11 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:59:11 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:59:11 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:59:11 --> URI Class Initialized
DEBUG - 2012-07-24 16:59:11 --> Router Class Initialized
DEBUG - 2012-07-24 16:59:11 --> Output Class Initialized
DEBUG - 2012-07-24 16:59:11 --> Security Class Initialized
DEBUG - 2012-07-24 16:59:11 --> Input Class Initialized
DEBUG - 2012-07-24 16:59:11 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:11 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:11 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:11 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:11 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:11 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:11 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:11 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:11 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:11 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:11 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:11 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:11 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:11 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:11 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:11 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:11 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:11 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:11 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:11 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:59:11 --> Language Class Initialized
DEBUG - 2012-07-24 16:59:11 --> Loader Class Initialized
DEBUG - 2012-07-24 16:59:11 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:59:11 --> Controller Class Initialized
DEBUG - 2012-07-24 16:59:11 --> Model Class Initialized
DEBUG - 2012-07-24 16:59:11 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:59:11 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:59:11 --> Form Validation Class Initialized
DEBUG - 2012-07-24 16:59:40 --> Config Class Initialized
DEBUG - 2012-07-24 16:59:40 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:59:40 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:59:40 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:59:40 --> URI Class Initialized
DEBUG - 2012-07-24 16:59:41 --> Router Class Initialized
DEBUG - 2012-07-24 16:59:41 --> Output Class Initialized
DEBUG - 2012-07-24 16:59:41 --> Security Class Initialized
DEBUG - 2012-07-24 16:59:41 --> Input Class Initialized
DEBUG - 2012-07-24 16:59:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:59:41 --> Language Class Initialized
DEBUG - 2012-07-24 16:59:41 --> Loader Class Initialized
DEBUG - 2012-07-24 16:59:41 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:59:41 --> Controller Class Initialized
DEBUG - 2012-07-24 16:59:41 --> Model Class Initialized
DEBUG - 2012-07-24 16:59:41 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:59:41 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:59:41 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 16:59:41 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 16:59:41 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 16:59:41 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 16:59:41 --> Final output sent to browser
DEBUG - 2012-07-24 16:59:41 --> Total execution time: 0.0430
DEBUG - 2012-07-24 16:59:52 --> Config Class Initialized
DEBUG - 2012-07-24 16:59:52 --> Hooks Class Initialized
DEBUG - 2012-07-24 16:59:52 --> Utf8 Class Initialized
DEBUG - 2012-07-24 16:59:52 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 16:59:52 --> URI Class Initialized
DEBUG - 2012-07-24 16:59:52 --> Router Class Initialized
DEBUG - 2012-07-24 16:59:52 --> Output Class Initialized
DEBUG - 2012-07-24 16:59:52 --> Security Class Initialized
DEBUG - 2012-07-24 16:59:52 --> Input Class Initialized
DEBUG - 2012-07-24 16:59:52 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:52 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:52 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:52 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:52 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:52 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:52 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:52 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:52 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:52 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:52 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:52 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:52 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:52 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:52 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:52 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:52 --> XSS Filtering completed
DEBUG - 2012-07-24 16:59:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 16:59:52 --> Language Class Initialized
DEBUG - 2012-07-24 16:59:52 --> Loader Class Initialized
DEBUG - 2012-07-24 16:59:52 --> Helper loaded: url_helper
DEBUG - 2012-07-24 16:59:52 --> Controller Class Initialized
DEBUG - 2012-07-24 16:59:52 --> Model Class Initialized
DEBUG - 2012-07-24 16:59:52 --> Database Driver Class Initialized
DEBUG - 2012-07-24 16:59:52 --> Helper loaded: form_helper
DEBUG - 2012-07-24 16:59:52 --> Form Validation Class Initialized
DEBUG - 2012-07-24 17:05:25 --> Config Class Initialized
DEBUG - 2012-07-24 17:05:25 --> Hooks Class Initialized
DEBUG - 2012-07-24 17:05:25 --> Utf8 Class Initialized
DEBUG - 2012-07-24 17:05:25 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 17:05:25 --> URI Class Initialized
DEBUG - 2012-07-24 17:05:25 --> Router Class Initialized
DEBUG - 2012-07-24 17:05:25 --> Output Class Initialized
DEBUG - 2012-07-24 17:05:25 --> Security Class Initialized
DEBUG - 2012-07-24 17:05:25 --> Input Class Initialized
DEBUG - 2012-07-24 17:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 17:05:25 --> Language Class Initialized
DEBUG - 2012-07-24 17:05:25 --> Loader Class Initialized
DEBUG - 2012-07-24 17:05:25 --> Helper loaded: url_helper
DEBUG - 2012-07-24 17:05:25 --> Controller Class Initialized
DEBUG - 2012-07-24 17:05:25 --> Model Class Initialized
DEBUG - 2012-07-24 17:05:25 --> Database Driver Class Initialized
DEBUG - 2012-07-24 17:05:26 --> Helper loaded: form_helper
DEBUG - 2012-07-24 17:05:26 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 17:05:26 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 17:05:26 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 17:05:26 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 17:05:26 --> Final output sent to browser
DEBUG - 2012-07-24 17:05:26 --> Total execution time: 0.3148
DEBUG - 2012-07-24 17:06:07 --> Config Class Initialized
DEBUG - 2012-07-24 17:06:07 --> Hooks Class Initialized
DEBUG - 2012-07-24 17:06:07 --> Utf8 Class Initialized
DEBUG - 2012-07-24 17:06:07 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 17:06:07 --> URI Class Initialized
DEBUG - 2012-07-24 17:06:07 --> Router Class Initialized
DEBUG - 2012-07-24 17:06:07 --> Output Class Initialized
DEBUG - 2012-07-24 17:06:07 --> Security Class Initialized
DEBUG - 2012-07-24 17:06:07 --> Input Class Initialized
DEBUG - 2012-07-24 17:06:07 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:07 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:07 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:07 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:07 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:07 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:07 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:07 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:07 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:07 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:07 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:07 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:07 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:07 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:07 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:07 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:07 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:07 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:07 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:07 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 17:06:07 --> Language Class Initialized
DEBUG - 2012-07-24 17:06:07 --> Loader Class Initialized
DEBUG - 2012-07-24 17:06:07 --> Helper loaded: url_helper
DEBUG - 2012-07-24 17:06:07 --> Controller Class Initialized
DEBUG - 2012-07-24 17:06:07 --> Model Class Initialized
DEBUG - 2012-07-24 17:06:07 --> Database Driver Class Initialized
DEBUG - 2012-07-24 17:06:07 --> Helper loaded: form_helper
DEBUG - 2012-07-24 17:06:07 --> Form Validation Class Initialized
DEBUG - 2012-07-24 17:06:20 --> Config Class Initialized
DEBUG - 2012-07-24 17:06:20 --> Hooks Class Initialized
DEBUG - 2012-07-24 17:06:20 --> Utf8 Class Initialized
DEBUG - 2012-07-24 17:06:20 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 17:06:20 --> URI Class Initialized
DEBUG - 2012-07-24 17:06:20 --> Router Class Initialized
DEBUG - 2012-07-24 17:06:20 --> Output Class Initialized
DEBUG - 2012-07-24 17:06:20 --> Security Class Initialized
DEBUG - 2012-07-24 17:06:20 --> Input Class Initialized
DEBUG - 2012-07-24 17:06:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 17:06:20 --> Language Class Initialized
DEBUG - 2012-07-24 17:06:20 --> Loader Class Initialized
DEBUG - 2012-07-24 17:06:20 --> Helper loaded: url_helper
DEBUG - 2012-07-24 17:06:20 --> Controller Class Initialized
DEBUG - 2012-07-24 17:06:20 --> Model Class Initialized
DEBUG - 2012-07-24 17:06:20 --> Database Driver Class Initialized
DEBUG - 2012-07-24 17:06:20 --> Helper loaded: form_helper
DEBUG - 2012-07-24 17:06:20 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 17:06:20 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 17:06:20 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 17:06:20 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 17:06:20 --> Final output sent to browser
DEBUG - 2012-07-24 17:06:20 --> Total execution time: 0.0381
DEBUG - 2012-07-24 17:06:30 --> Config Class Initialized
DEBUG - 2012-07-24 17:06:30 --> Hooks Class Initialized
DEBUG - 2012-07-24 17:06:30 --> Utf8 Class Initialized
DEBUG - 2012-07-24 17:06:30 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 17:06:30 --> URI Class Initialized
DEBUG - 2012-07-24 17:06:30 --> Router Class Initialized
DEBUG - 2012-07-24 17:06:30 --> Output Class Initialized
DEBUG - 2012-07-24 17:06:30 --> Security Class Initialized
DEBUG - 2012-07-24 17:06:30 --> Input Class Initialized
DEBUG - 2012-07-24 17:06:30 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:30 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:30 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:30 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:30 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:30 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:30 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:30 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:30 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:30 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:30 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:30 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:30 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:30 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:30 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:30 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:30 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:30 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:30 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:30 --> XSS Filtering completed
DEBUG - 2012-07-24 17:06:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 17:06:30 --> Language Class Initialized
DEBUG - 2012-07-24 17:06:30 --> Loader Class Initialized
DEBUG - 2012-07-24 17:06:30 --> Helper loaded: url_helper
DEBUG - 2012-07-24 17:06:30 --> Controller Class Initialized
DEBUG - 2012-07-24 17:06:30 --> Model Class Initialized
DEBUG - 2012-07-24 17:06:30 --> Database Driver Class Initialized
DEBUG - 2012-07-24 17:06:30 --> Helper loaded: form_helper
DEBUG - 2012-07-24 17:06:30 --> Form Validation Class Initialized
DEBUG - 2012-07-24 17:12:51 --> Config Class Initialized
DEBUG - 2012-07-24 17:12:51 --> Hooks Class Initialized
DEBUG - 2012-07-24 17:12:51 --> Utf8 Class Initialized
DEBUG - 2012-07-24 17:12:51 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 17:12:51 --> URI Class Initialized
DEBUG - 2012-07-24 17:12:51 --> Router Class Initialized
DEBUG - 2012-07-24 17:12:51 --> Output Class Initialized
DEBUG - 2012-07-24 17:12:51 --> Security Class Initialized
DEBUG - 2012-07-24 17:12:51 --> Input Class Initialized
DEBUG - 2012-07-24 17:12:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 17:12:51 --> Language Class Initialized
DEBUG - 2012-07-24 17:12:51 --> Loader Class Initialized
DEBUG - 2012-07-24 17:12:51 --> Helper loaded: url_helper
DEBUG - 2012-07-24 17:12:51 --> Controller Class Initialized
DEBUG - 2012-07-24 17:12:51 --> Model Class Initialized
DEBUG - 2012-07-24 17:12:51 --> Database Driver Class Initialized
DEBUG - 2012-07-24 17:12:51 --> Helper loaded: form_helper
DEBUG - 2012-07-24 17:12:51 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 17:12:51 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-24 17:12:51 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 17:12:51 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-07-24 17:12:51 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 17:12:51 --> Final output sent to browser
DEBUG - 2012-07-24 17:12:51 --> Total execution time: 0.0639
DEBUG - 2012-07-24 17:12:55 --> Config Class Initialized
DEBUG - 2012-07-24 17:12:55 --> Hooks Class Initialized
DEBUG - 2012-07-24 17:12:55 --> Utf8 Class Initialized
DEBUG - 2012-07-24 17:12:55 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 17:12:55 --> URI Class Initialized
DEBUG - 2012-07-24 17:12:55 --> Router Class Initialized
DEBUG - 2012-07-24 17:12:55 --> Output Class Initialized
DEBUG - 2012-07-24 17:12:55 --> Security Class Initialized
DEBUG - 2012-07-24 17:12:55 --> Input Class Initialized
DEBUG - 2012-07-24 17:12:55 --> XSS Filtering completed
DEBUG - 2012-07-24 17:12:55 --> XSS Filtering completed
DEBUG - 2012-07-24 17:12:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 17:12:55 --> Language Class Initialized
DEBUG - 2012-07-24 17:12:55 --> Loader Class Initialized
DEBUG - 2012-07-24 17:12:55 --> Helper loaded: url_helper
DEBUG - 2012-07-24 17:12:55 --> Controller Class Initialized
DEBUG - 2012-07-24 17:12:55 --> Model Class Initialized
DEBUG - 2012-07-24 17:12:55 --> Database Driver Class Initialized
DEBUG - 2012-07-24 17:12:55 --> Helper loaded: form_helper
DEBUG - 2012-07-24 17:12:55 --> Form Validation Class Initialized
DEBUG - 2012-07-24 17:12:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-24 17:12:56 --> Final output sent to browser
DEBUG - 2012-07-24 17:12:56 --> Total execution time: 0.1524
DEBUG - 2012-07-24 17:13:16 --> Config Class Initialized
DEBUG - 2012-07-24 17:13:16 --> Hooks Class Initialized
DEBUG - 2012-07-24 17:13:16 --> Utf8 Class Initialized
DEBUG - 2012-07-24 17:13:16 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 17:13:16 --> URI Class Initialized
DEBUG - 2012-07-24 17:13:16 --> Router Class Initialized
DEBUG - 2012-07-24 17:13:16 --> Output Class Initialized
DEBUG - 2012-07-24 17:13:16 --> Security Class Initialized
DEBUG - 2012-07-24 17:13:16 --> Input Class Initialized
DEBUG - 2012-07-24 17:13:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:13:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 17:13:16 --> Language Class Initialized
DEBUG - 2012-07-24 17:13:16 --> Loader Class Initialized
DEBUG - 2012-07-24 17:13:16 --> Helper loaded: url_helper
DEBUG - 2012-07-24 17:13:16 --> Controller Class Initialized
DEBUG - 2012-07-24 17:13:16 --> Model Class Initialized
DEBUG - 2012-07-24 17:13:16 --> Database Driver Class Initialized
DEBUG - 2012-07-24 17:13:16 --> Helper loaded: form_helper
DEBUG - 2012-07-24 17:13:16 --> Form Validation Class Initialized
DEBUG - 2012-07-24 17:13:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-24 17:13:16 --> Final output sent to browser
DEBUG - 2012-07-24 17:13:16 --> Total execution time: 0.0412
DEBUG - 2012-07-24 17:13:33 --> Config Class Initialized
DEBUG - 2012-07-24 17:13:33 --> Hooks Class Initialized
DEBUG - 2012-07-24 17:13:33 --> Utf8 Class Initialized
DEBUG - 2012-07-24 17:13:33 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 17:13:33 --> URI Class Initialized
DEBUG - 2012-07-24 17:13:33 --> Router Class Initialized
DEBUG - 2012-07-24 17:13:33 --> Output Class Initialized
DEBUG - 2012-07-24 17:13:33 --> Security Class Initialized
DEBUG - 2012-07-24 17:13:33 --> Input Class Initialized
DEBUG - 2012-07-24 17:13:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 17:13:33 --> Language Class Initialized
DEBUG - 2012-07-24 17:13:33 --> Loader Class Initialized
DEBUG - 2012-07-24 17:13:33 --> Helper loaded: url_helper
DEBUG - 2012-07-24 17:13:33 --> Controller Class Initialized
DEBUG - 2012-07-24 17:13:33 --> Model Class Initialized
DEBUG - 2012-07-24 17:13:33 --> Database Driver Class Initialized
DEBUG - 2012-07-24 17:13:33 --> Helper loaded: form_helper
DEBUG - 2012-07-24 17:13:33 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 17:13:33 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 17:13:33 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 17:13:33 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 17:13:33 --> Final output sent to browser
DEBUG - 2012-07-24 17:13:33 --> Total execution time: 0.0397
DEBUG - 2012-07-24 17:24:11 --> Config Class Initialized
DEBUG - 2012-07-24 17:24:11 --> Hooks Class Initialized
DEBUG - 2012-07-24 17:24:11 --> Utf8 Class Initialized
DEBUG - 2012-07-24 17:24:11 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 17:24:11 --> URI Class Initialized
DEBUG - 2012-07-24 17:24:11 --> Router Class Initialized
DEBUG - 2012-07-24 17:24:11 --> Output Class Initialized
DEBUG - 2012-07-24 17:24:11 --> Security Class Initialized
DEBUG - 2012-07-24 17:24:11 --> Input Class Initialized
DEBUG - 2012-07-24 17:24:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 17:24:11 --> Language Class Initialized
DEBUG - 2012-07-24 17:24:11 --> Loader Class Initialized
DEBUG - 2012-07-24 17:24:11 --> Helper loaded: url_helper
DEBUG - 2012-07-24 17:24:11 --> Controller Class Initialized
DEBUG - 2012-07-24 17:24:11 --> Model Class Initialized
DEBUG - 2012-07-24 17:24:11 --> Database Driver Class Initialized
DEBUG - 2012-07-24 17:24:12 --> Helper loaded: form_helper
DEBUG - 2012-07-24 17:24:12 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 17:24:12 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 17:24:12 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 17:24:12 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 17:24:12 --> Final output sent to browser
DEBUG - 2012-07-24 17:24:12 --> Total execution time: 0.3775
DEBUG - 2012-07-24 17:24:28 --> Config Class Initialized
DEBUG - 2012-07-24 17:24:28 --> Hooks Class Initialized
DEBUG - 2012-07-24 17:24:28 --> Utf8 Class Initialized
DEBUG - 2012-07-24 17:24:28 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 17:24:28 --> URI Class Initialized
DEBUG - 2012-07-24 17:24:28 --> Router Class Initialized
DEBUG - 2012-07-24 17:24:28 --> Output Class Initialized
DEBUG - 2012-07-24 17:24:28 --> Security Class Initialized
DEBUG - 2012-07-24 17:24:28 --> Input Class Initialized
DEBUG - 2012-07-24 17:24:28 --> XSS Filtering completed
DEBUG - 2012-07-24 17:24:28 --> XSS Filtering completed
DEBUG - 2012-07-24 17:24:28 --> XSS Filtering completed
DEBUG - 2012-07-24 17:24:28 --> XSS Filtering completed
DEBUG - 2012-07-24 17:24:28 --> XSS Filtering completed
DEBUG - 2012-07-24 17:24:28 --> XSS Filtering completed
DEBUG - 2012-07-24 17:24:28 --> XSS Filtering completed
DEBUG - 2012-07-24 17:24:28 --> XSS Filtering completed
DEBUG - 2012-07-24 17:24:28 --> XSS Filtering completed
DEBUG - 2012-07-24 17:24:28 --> XSS Filtering completed
DEBUG - 2012-07-24 17:24:28 --> XSS Filtering completed
DEBUG - 2012-07-24 17:24:28 --> XSS Filtering completed
DEBUG - 2012-07-24 17:24:28 --> XSS Filtering completed
DEBUG - 2012-07-24 17:24:28 --> XSS Filtering completed
DEBUG - 2012-07-24 17:24:28 --> XSS Filtering completed
DEBUG - 2012-07-24 17:24:28 --> XSS Filtering completed
DEBUG - 2012-07-24 17:24:28 --> XSS Filtering completed
DEBUG - 2012-07-24 17:24:28 --> XSS Filtering completed
DEBUG - 2012-07-24 17:24:28 --> XSS Filtering completed
DEBUG - 2012-07-24 17:24:28 --> XSS Filtering completed
DEBUG - 2012-07-24 17:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 17:24:28 --> Language Class Initialized
DEBUG - 2012-07-24 17:24:28 --> Loader Class Initialized
DEBUG - 2012-07-24 17:24:28 --> Helper loaded: url_helper
DEBUG - 2012-07-24 17:24:28 --> Controller Class Initialized
DEBUG - 2012-07-24 17:24:28 --> Model Class Initialized
DEBUG - 2012-07-24 17:24:28 --> Database Driver Class Initialized
DEBUG - 2012-07-24 17:24:28 --> Helper loaded: form_helper
DEBUG - 2012-07-24 17:24:28 --> Form Validation Class Initialized
DEBUG - 2012-07-24 17:24:59 --> Config Class Initialized
DEBUG - 2012-07-24 17:24:59 --> Hooks Class Initialized
DEBUG - 2012-07-24 17:24:59 --> Utf8 Class Initialized
DEBUG - 2012-07-24 17:24:59 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 17:24:59 --> URI Class Initialized
DEBUG - 2012-07-24 17:24:59 --> Router Class Initialized
DEBUG - 2012-07-24 17:24:59 --> Output Class Initialized
DEBUG - 2012-07-24 17:24:59 --> Security Class Initialized
DEBUG - 2012-07-24 17:24:59 --> Input Class Initialized
DEBUG - 2012-07-24 17:24:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 17:24:59 --> Language Class Initialized
DEBUG - 2012-07-24 17:24:59 --> Loader Class Initialized
DEBUG - 2012-07-24 17:24:59 --> Helper loaded: url_helper
DEBUG - 2012-07-24 17:24:59 --> Controller Class Initialized
DEBUG - 2012-07-24 17:24:59 --> Model Class Initialized
DEBUG - 2012-07-24 17:24:59 --> Database Driver Class Initialized
DEBUG - 2012-07-24 17:24:59 --> Helper loaded: form_helper
DEBUG - 2012-07-24 17:24:59 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 17:24:59 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 17:24:59 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 17:24:59 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 17:24:59 --> Final output sent to browser
DEBUG - 2012-07-24 17:24:59 --> Total execution time: 0.0464
DEBUG - 2012-07-24 17:25:08 --> Config Class Initialized
DEBUG - 2012-07-24 17:25:08 --> Hooks Class Initialized
DEBUG - 2012-07-24 17:25:08 --> Utf8 Class Initialized
DEBUG - 2012-07-24 17:25:08 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 17:25:08 --> URI Class Initialized
DEBUG - 2012-07-24 17:25:08 --> Router Class Initialized
DEBUG - 2012-07-24 17:25:08 --> Output Class Initialized
DEBUG - 2012-07-24 17:25:08 --> Security Class Initialized
DEBUG - 2012-07-24 17:25:08 --> Input Class Initialized
DEBUG - 2012-07-24 17:25:08 --> XSS Filtering completed
DEBUG - 2012-07-24 17:25:08 --> XSS Filtering completed
DEBUG - 2012-07-24 17:25:08 --> XSS Filtering completed
DEBUG - 2012-07-24 17:25:08 --> XSS Filtering completed
DEBUG - 2012-07-24 17:25:08 --> XSS Filtering completed
DEBUG - 2012-07-24 17:25:08 --> XSS Filtering completed
DEBUG - 2012-07-24 17:25:08 --> XSS Filtering completed
DEBUG - 2012-07-24 17:25:08 --> XSS Filtering completed
DEBUG - 2012-07-24 17:25:08 --> XSS Filtering completed
DEBUG - 2012-07-24 17:25:08 --> XSS Filtering completed
DEBUG - 2012-07-24 17:25:08 --> XSS Filtering completed
DEBUG - 2012-07-24 17:25:08 --> XSS Filtering completed
DEBUG - 2012-07-24 17:25:08 --> XSS Filtering completed
DEBUG - 2012-07-24 17:25:08 --> XSS Filtering completed
DEBUG - 2012-07-24 17:25:08 --> XSS Filtering completed
DEBUG - 2012-07-24 17:25:08 --> XSS Filtering completed
DEBUG - 2012-07-24 17:25:08 --> XSS Filtering completed
DEBUG - 2012-07-24 17:25:08 --> XSS Filtering completed
DEBUG - 2012-07-24 17:25:08 --> XSS Filtering completed
DEBUG - 2012-07-24 17:25:08 --> XSS Filtering completed
DEBUG - 2012-07-24 17:25:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 17:25:08 --> Language Class Initialized
DEBUG - 2012-07-24 17:25:08 --> Loader Class Initialized
DEBUG - 2012-07-24 17:25:08 --> Helper loaded: url_helper
DEBUG - 2012-07-24 17:25:08 --> Controller Class Initialized
DEBUG - 2012-07-24 17:25:08 --> Model Class Initialized
DEBUG - 2012-07-24 17:25:08 --> Database Driver Class Initialized
DEBUG - 2012-07-24 17:25:08 --> Helper loaded: form_helper
DEBUG - 2012-07-24 17:25:08 --> Form Validation Class Initialized
DEBUG - 2012-07-24 17:28:57 --> Config Class Initialized
DEBUG - 2012-07-24 17:28:57 --> Hooks Class Initialized
DEBUG - 2012-07-24 17:28:57 --> Utf8 Class Initialized
DEBUG - 2012-07-24 17:28:57 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 17:28:57 --> URI Class Initialized
DEBUG - 2012-07-24 17:28:57 --> Router Class Initialized
DEBUG - 2012-07-24 17:28:57 --> Output Class Initialized
DEBUG - 2012-07-24 17:28:57 --> Security Class Initialized
DEBUG - 2012-07-24 17:28:57 --> Input Class Initialized
DEBUG - 2012-07-24 17:28:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 17:28:57 --> Language Class Initialized
DEBUG - 2012-07-24 17:28:57 --> Loader Class Initialized
DEBUG - 2012-07-24 17:28:57 --> Helper loaded: url_helper
DEBUG - 2012-07-24 17:28:57 --> Controller Class Initialized
DEBUG - 2012-07-24 17:28:57 --> Model Class Initialized
DEBUG - 2012-07-24 17:28:57 --> Database Driver Class Initialized
DEBUG - 2012-07-24 17:30:46 --> Config Class Initialized
DEBUG - 2012-07-24 17:30:46 --> Hooks Class Initialized
DEBUG - 2012-07-24 17:30:46 --> Utf8 Class Initialized
DEBUG - 2012-07-24 17:30:46 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 17:30:46 --> URI Class Initialized
DEBUG - 2012-07-24 17:30:46 --> Router Class Initialized
DEBUG - 2012-07-24 17:30:46 --> Output Class Initialized
DEBUG - 2012-07-24 17:30:46 --> Security Class Initialized
DEBUG - 2012-07-24 17:30:46 --> Input Class Initialized
DEBUG - 2012-07-24 17:30:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 17:30:46 --> Language Class Initialized
DEBUG - 2012-07-24 17:30:46 --> Loader Class Initialized
DEBUG - 2012-07-24 17:30:46 --> Helper loaded: url_helper
DEBUG - 2012-07-24 17:30:46 --> Controller Class Initialized
DEBUG - 2012-07-24 17:30:46 --> Model Class Initialized
DEBUG - 2012-07-24 17:30:46 --> Database Driver Class Initialized
DEBUG - 2012-07-24 17:30:46 --> Helper loaded: form_helper
DEBUG - 2012-07-24 17:30:46 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 17:30:46 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 17:30:46 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 17:30:46 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 17:30:46 --> Final output sent to browser
DEBUG - 2012-07-24 17:30:46 --> Total execution time: 0.0398
DEBUG - 2012-07-24 17:30:53 --> Config Class Initialized
DEBUG - 2012-07-24 17:30:53 --> Hooks Class Initialized
DEBUG - 2012-07-24 17:30:53 --> Utf8 Class Initialized
DEBUG - 2012-07-24 17:30:53 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 17:30:53 --> URI Class Initialized
DEBUG - 2012-07-24 17:30:53 --> Router Class Initialized
DEBUG - 2012-07-24 17:30:53 --> Output Class Initialized
DEBUG - 2012-07-24 17:30:53 --> Security Class Initialized
DEBUG - 2012-07-24 17:30:53 --> Input Class Initialized
DEBUG - 2012-07-24 17:30:53 --> XSS Filtering completed
DEBUG - 2012-07-24 17:30:53 --> XSS Filtering completed
DEBUG - 2012-07-24 17:30:53 --> XSS Filtering completed
DEBUG - 2012-07-24 17:30:53 --> XSS Filtering completed
DEBUG - 2012-07-24 17:30:53 --> XSS Filtering completed
DEBUG - 2012-07-24 17:30:53 --> XSS Filtering completed
DEBUG - 2012-07-24 17:30:53 --> XSS Filtering completed
DEBUG - 2012-07-24 17:30:53 --> XSS Filtering completed
DEBUG - 2012-07-24 17:30:53 --> XSS Filtering completed
DEBUG - 2012-07-24 17:30:53 --> XSS Filtering completed
DEBUG - 2012-07-24 17:30:53 --> XSS Filtering completed
DEBUG - 2012-07-24 17:30:53 --> XSS Filtering completed
DEBUG - 2012-07-24 17:30:53 --> XSS Filtering completed
DEBUG - 2012-07-24 17:30:53 --> XSS Filtering completed
DEBUG - 2012-07-24 17:30:53 --> XSS Filtering completed
DEBUG - 2012-07-24 17:30:53 --> XSS Filtering completed
DEBUG - 2012-07-24 17:30:53 --> XSS Filtering completed
DEBUG - 2012-07-24 17:30:53 --> XSS Filtering completed
DEBUG - 2012-07-24 17:30:53 --> XSS Filtering completed
DEBUG - 2012-07-24 17:30:53 --> XSS Filtering completed
DEBUG - 2012-07-24 17:30:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 17:30:53 --> Language Class Initialized
DEBUG - 2012-07-24 17:30:53 --> Loader Class Initialized
DEBUG - 2012-07-24 17:30:53 --> Helper loaded: url_helper
DEBUG - 2012-07-24 17:30:53 --> Controller Class Initialized
DEBUG - 2012-07-24 17:30:53 --> Model Class Initialized
DEBUG - 2012-07-24 17:30:53 --> Database Driver Class Initialized
DEBUG - 2012-07-24 17:30:53 --> Helper loaded: form_helper
DEBUG - 2012-07-24 17:30:53 --> Form Validation Class Initialized
DEBUG - 2012-07-24 17:31:52 --> Config Class Initialized
DEBUG - 2012-07-24 17:31:52 --> Hooks Class Initialized
DEBUG - 2012-07-24 17:31:52 --> Utf8 Class Initialized
DEBUG - 2012-07-24 17:31:52 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 17:31:52 --> URI Class Initialized
DEBUG - 2012-07-24 17:31:52 --> Router Class Initialized
DEBUG - 2012-07-24 17:31:52 --> Output Class Initialized
DEBUG - 2012-07-24 17:31:52 --> Security Class Initialized
DEBUG - 2012-07-24 17:31:52 --> Input Class Initialized
DEBUG - 2012-07-24 17:31:52 --> XSS Filtering completed
DEBUG - 2012-07-24 17:31:52 --> XSS Filtering completed
DEBUG - 2012-07-24 17:31:52 --> XSS Filtering completed
DEBUG - 2012-07-24 17:31:52 --> XSS Filtering completed
DEBUG - 2012-07-24 17:31:52 --> XSS Filtering completed
DEBUG - 2012-07-24 17:31:52 --> XSS Filtering completed
DEBUG - 2012-07-24 17:31:52 --> XSS Filtering completed
DEBUG - 2012-07-24 17:31:52 --> XSS Filtering completed
DEBUG - 2012-07-24 17:31:52 --> XSS Filtering completed
DEBUG - 2012-07-24 17:31:52 --> XSS Filtering completed
DEBUG - 2012-07-24 17:31:52 --> XSS Filtering completed
DEBUG - 2012-07-24 17:31:52 --> XSS Filtering completed
DEBUG - 2012-07-24 17:31:52 --> XSS Filtering completed
DEBUG - 2012-07-24 17:31:52 --> XSS Filtering completed
DEBUG - 2012-07-24 17:31:52 --> XSS Filtering completed
DEBUG - 2012-07-24 17:31:52 --> XSS Filtering completed
DEBUG - 2012-07-24 17:31:52 --> XSS Filtering completed
DEBUG - 2012-07-24 17:31:52 --> XSS Filtering completed
DEBUG - 2012-07-24 17:31:52 --> XSS Filtering completed
DEBUG - 2012-07-24 17:31:52 --> XSS Filtering completed
DEBUG - 2012-07-24 17:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 17:31:52 --> Language Class Initialized
DEBUG - 2012-07-24 17:31:52 --> Loader Class Initialized
DEBUG - 2012-07-24 17:31:52 --> Helper loaded: url_helper
DEBUG - 2012-07-24 17:31:52 --> Controller Class Initialized
DEBUG - 2012-07-24 17:31:52 --> Model Class Initialized
DEBUG - 2012-07-24 17:31:52 --> Database Driver Class Initialized
DEBUG - 2012-07-24 17:31:52 --> Helper loaded: form_helper
DEBUG - 2012-07-24 17:31:52 --> Form Validation Class Initialized
DEBUG - 2012-07-24 17:32:09 --> Config Class Initialized
DEBUG - 2012-07-24 17:32:09 --> Hooks Class Initialized
DEBUG - 2012-07-24 17:32:09 --> Utf8 Class Initialized
DEBUG - 2012-07-24 17:32:09 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 17:32:09 --> URI Class Initialized
DEBUG - 2012-07-24 17:32:09 --> Router Class Initialized
DEBUG - 2012-07-24 17:32:09 --> Output Class Initialized
DEBUG - 2012-07-24 17:32:09 --> Security Class Initialized
DEBUG - 2012-07-24 17:32:09 --> Input Class Initialized
DEBUG - 2012-07-24 17:32:09 --> XSS Filtering completed
DEBUG - 2012-07-24 17:32:09 --> XSS Filtering completed
DEBUG - 2012-07-24 17:32:09 --> XSS Filtering completed
DEBUG - 2012-07-24 17:32:09 --> XSS Filtering completed
DEBUG - 2012-07-24 17:32:09 --> XSS Filtering completed
DEBUG - 2012-07-24 17:32:09 --> XSS Filtering completed
DEBUG - 2012-07-24 17:32:09 --> XSS Filtering completed
DEBUG - 2012-07-24 17:32:09 --> XSS Filtering completed
DEBUG - 2012-07-24 17:32:09 --> XSS Filtering completed
DEBUG - 2012-07-24 17:32:09 --> XSS Filtering completed
DEBUG - 2012-07-24 17:32:09 --> XSS Filtering completed
DEBUG - 2012-07-24 17:32:09 --> XSS Filtering completed
DEBUG - 2012-07-24 17:32:09 --> XSS Filtering completed
DEBUG - 2012-07-24 17:32:09 --> XSS Filtering completed
DEBUG - 2012-07-24 17:32:09 --> XSS Filtering completed
DEBUG - 2012-07-24 17:32:09 --> XSS Filtering completed
DEBUG - 2012-07-24 17:32:09 --> XSS Filtering completed
DEBUG - 2012-07-24 17:32:09 --> XSS Filtering completed
DEBUG - 2012-07-24 17:32:09 --> XSS Filtering completed
DEBUG - 2012-07-24 17:32:09 --> XSS Filtering completed
DEBUG - 2012-07-24 17:32:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 17:32:09 --> Language Class Initialized
DEBUG - 2012-07-24 17:32:09 --> Loader Class Initialized
DEBUG - 2012-07-24 17:32:09 --> Helper loaded: url_helper
DEBUG - 2012-07-24 17:32:09 --> Controller Class Initialized
DEBUG - 2012-07-24 17:32:09 --> Model Class Initialized
DEBUG - 2012-07-24 17:32:09 --> Database Driver Class Initialized
DEBUG - 2012-07-24 17:32:09 --> Helper loaded: form_helper
DEBUG - 2012-07-24 17:32:09 --> Form Validation Class Initialized
DEBUG - 2012-07-24 17:37:36 --> Config Class Initialized
DEBUG - 2012-07-24 17:37:36 --> Hooks Class Initialized
DEBUG - 2012-07-24 17:37:36 --> Utf8 Class Initialized
DEBUG - 2012-07-24 17:37:36 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 17:37:36 --> URI Class Initialized
DEBUG - 2012-07-24 17:37:36 --> Router Class Initialized
DEBUG - 2012-07-24 17:37:36 --> Output Class Initialized
DEBUG - 2012-07-24 17:37:36 --> Security Class Initialized
DEBUG - 2012-07-24 17:37:36 --> Input Class Initialized
DEBUG - 2012-07-24 17:37:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 17:37:36 --> Language Class Initialized
DEBUG - 2012-07-24 17:37:36 --> Loader Class Initialized
DEBUG - 2012-07-24 17:37:36 --> Helper loaded: url_helper
DEBUG - 2012-07-24 17:37:36 --> Controller Class Initialized
DEBUG - 2012-07-24 17:37:36 --> Model Class Initialized
DEBUG - 2012-07-24 17:37:37 --> Database Driver Class Initialized
DEBUG - 2012-07-24 17:37:37 --> Helper loaded: form_helper
DEBUG - 2012-07-24 17:37:37 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 17:37:37 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 17:37:37 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 17:37:37 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 17:37:37 --> Final output sent to browser
DEBUG - 2012-07-24 17:37:37 --> Total execution time: 0.0978
DEBUG - 2012-07-24 17:37:40 --> Config Class Initialized
DEBUG - 2012-07-24 17:37:40 --> Hooks Class Initialized
DEBUG - 2012-07-24 17:37:40 --> Utf8 Class Initialized
DEBUG - 2012-07-24 17:37:40 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 17:37:40 --> URI Class Initialized
DEBUG - 2012-07-24 17:37:40 --> Router Class Initialized
DEBUG - 2012-07-24 17:37:40 --> Output Class Initialized
DEBUG - 2012-07-24 17:37:40 --> Security Class Initialized
DEBUG - 2012-07-24 17:37:40 --> Input Class Initialized
DEBUG - 2012-07-24 17:37:40 --> XSS Filtering completed
DEBUG - 2012-07-24 17:37:40 --> XSS Filtering completed
DEBUG - 2012-07-24 17:37:40 --> XSS Filtering completed
DEBUG - 2012-07-24 17:37:40 --> XSS Filtering completed
DEBUG - 2012-07-24 17:37:40 --> XSS Filtering completed
DEBUG - 2012-07-24 17:37:40 --> XSS Filtering completed
DEBUG - 2012-07-24 17:37:40 --> XSS Filtering completed
DEBUG - 2012-07-24 17:37:40 --> XSS Filtering completed
DEBUG - 2012-07-24 17:37:40 --> XSS Filtering completed
DEBUG - 2012-07-24 17:37:40 --> XSS Filtering completed
DEBUG - 2012-07-24 17:37:40 --> XSS Filtering completed
DEBUG - 2012-07-24 17:37:40 --> XSS Filtering completed
DEBUG - 2012-07-24 17:37:40 --> XSS Filtering completed
DEBUG - 2012-07-24 17:37:40 --> XSS Filtering completed
DEBUG - 2012-07-24 17:37:40 --> XSS Filtering completed
DEBUG - 2012-07-24 17:37:40 --> XSS Filtering completed
DEBUG - 2012-07-24 17:37:40 --> XSS Filtering completed
DEBUG - 2012-07-24 17:37:40 --> XSS Filtering completed
DEBUG - 2012-07-24 17:37:40 --> XSS Filtering completed
DEBUG - 2012-07-24 17:37:40 --> XSS Filtering completed
DEBUG - 2012-07-24 17:37:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 17:37:40 --> Language Class Initialized
DEBUG - 2012-07-24 17:37:40 --> Loader Class Initialized
DEBUG - 2012-07-24 17:37:40 --> Helper loaded: url_helper
DEBUG - 2012-07-24 17:37:40 --> Controller Class Initialized
DEBUG - 2012-07-24 17:37:40 --> Model Class Initialized
DEBUG - 2012-07-24 17:37:40 --> Database Driver Class Initialized
DEBUG - 2012-07-24 17:37:40 --> Helper loaded: form_helper
DEBUG - 2012-07-24 17:37:40 --> Form Validation Class Initialized
DEBUG - 2012-07-24 17:39:59 --> Config Class Initialized
DEBUG - 2012-07-24 17:39:59 --> Hooks Class Initialized
DEBUG - 2012-07-24 17:39:59 --> Utf8 Class Initialized
DEBUG - 2012-07-24 17:39:59 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 17:39:59 --> URI Class Initialized
DEBUG - 2012-07-24 17:39:59 --> Router Class Initialized
DEBUG - 2012-07-24 17:39:59 --> Output Class Initialized
DEBUG - 2012-07-24 17:39:59 --> Security Class Initialized
DEBUG - 2012-07-24 17:39:59 --> Input Class Initialized
DEBUG - 2012-07-24 17:39:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 17:39:59 --> Language Class Initialized
DEBUG - 2012-07-24 17:39:59 --> Loader Class Initialized
DEBUG - 2012-07-24 17:39:59 --> Helper loaded: url_helper
DEBUG - 2012-07-24 17:39:59 --> Controller Class Initialized
DEBUG - 2012-07-24 17:39:59 --> Model Class Initialized
DEBUG - 2012-07-24 17:39:59 --> Database Driver Class Initialized
DEBUG - 2012-07-24 17:39:59 --> Helper loaded: form_helper
DEBUG - 2012-07-24 17:39:59 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 17:39:59 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 17:39:59 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 17:39:59 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 17:39:59 --> Final output sent to browser
DEBUG - 2012-07-24 17:39:59 --> Total execution time: 0.0392
DEBUG - 2012-07-24 17:40:16 --> Config Class Initialized
DEBUG - 2012-07-24 17:40:16 --> Hooks Class Initialized
DEBUG - 2012-07-24 17:40:16 --> Utf8 Class Initialized
DEBUG - 2012-07-24 17:40:16 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 17:40:16 --> URI Class Initialized
DEBUG - 2012-07-24 17:40:16 --> Router Class Initialized
DEBUG - 2012-07-24 17:40:16 --> Output Class Initialized
DEBUG - 2012-07-24 17:40:16 --> Security Class Initialized
DEBUG - 2012-07-24 17:40:16 --> Input Class Initialized
DEBUG - 2012-07-24 17:40:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:40:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:40:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:40:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:40:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:40:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:40:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:40:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:40:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:40:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:40:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:40:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:40:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:40:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:40:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:40:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:40:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:40:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:40:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:40:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:40:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:40:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:40:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 17:40:16 --> Language Class Initialized
DEBUG - 2012-07-24 17:40:16 --> Loader Class Initialized
DEBUG - 2012-07-24 17:40:16 --> Helper loaded: url_helper
DEBUG - 2012-07-24 17:40:16 --> Controller Class Initialized
DEBUG - 2012-07-24 17:40:16 --> Model Class Initialized
DEBUG - 2012-07-24 17:40:16 --> Database Driver Class Initialized
DEBUG - 2012-07-24 17:40:16 --> Helper loaded: form_helper
DEBUG - 2012-07-24 17:40:16 --> Form Validation Class Initialized
DEBUG - 2012-07-24 17:40:16 --> Final output sent to browser
DEBUG - 2012-07-24 17:40:16 --> Total execution time: 0.2105
DEBUG - 2012-07-24 17:45:16 --> Config Class Initialized
DEBUG - 2012-07-24 17:45:16 --> Hooks Class Initialized
DEBUG - 2012-07-24 17:45:16 --> Utf8 Class Initialized
DEBUG - 2012-07-24 17:45:16 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 17:45:16 --> URI Class Initialized
DEBUG - 2012-07-24 17:45:16 --> Router Class Initialized
DEBUG - 2012-07-24 17:45:16 --> Output Class Initialized
DEBUG - 2012-07-24 17:45:16 --> Security Class Initialized
DEBUG - 2012-07-24 17:45:16 --> Input Class Initialized
DEBUG - 2012-07-24 17:45:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:45:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:45:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:45:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:45:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:45:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:45:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:45:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:45:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:45:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:45:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:45:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:45:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:45:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:45:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:45:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:45:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:45:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:45:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:45:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:45:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:45:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:45:16 --> XSS Filtering completed
DEBUG - 2012-07-24 17:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 17:45:16 --> Language Class Initialized
DEBUG - 2012-07-24 17:45:16 --> Loader Class Initialized
DEBUG - 2012-07-24 17:45:16 --> Helper loaded: url_helper
DEBUG - 2012-07-24 17:45:16 --> Controller Class Initialized
DEBUG - 2012-07-24 17:45:16 --> Model Class Initialized
DEBUG - 2012-07-24 17:45:16 --> Database Driver Class Initialized
DEBUG - 2012-07-24 17:45:16 --> Helper loaded: form_helper
DEBUG - 2012-07-24 17:45:16 --> Form Validation Class Initialized
DEBUG - 2012-07-24 17:45:17 --> Final output sent to browser
DEBUG - 2012-07-24 17:45:17 --> Total execution time: 0.3435
DEBUG - 2012-07-24 18:22:25 --> Config Class Initialized
DEBUG - 2012-07-24 18:22:25 --> Hooks Class Initialized
DEBUG - 2012-07-24 18:22:25 --> Utf8 Class Initialized
DEBUG - 2012-07-24 18:22:25 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 18:22:25 --> URI Class Initialized
DEBUG - 2012-07-24 18:22:25 --> Router Class Initialized
DEBUG - 2012-07-24 18:22:25 --> Output Class Initialized
DEBUG - 2012-07-24 18:22:25 --> Security Class Initialized
DEBUG - 2012-07-24 18:22:25 --> Input Class Initialized
DEBUG - 2012-07-24 18:22:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 18:22:25 --> Language Class Initialized
DEBUG - 2012-07-24 18:22:25 --> Loader Class Initialized
DEBUG - 2012-07-24 18:22:25 --> Helper loaded: url_helper
DEBUG - 2012-07-24 18:22:25 --> Controller Class Initialized
DEBUG - 2012-07-24 18:22:25 --> Model Class Initialized
DEBUG - 2012-07-24 18:22:25 --> Database Driver Class Initialized
DEBUG - 2012-07-24 18:22:25 --> Helper loaded: form_helper
DEBUG - 2012-07-24 18:22:25 --> Helper loaded: html_helper
DEBUG - 2012-07-24 18:22:25 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-24 18:22:25 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-24 18:22:25 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-24 18:22:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-24 18:22:25 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 64
ERROR - 2012-07-24 18:22:25 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-24 18:22:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-24 18:22:25 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-24 18:22:25 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-24 18:22:25 --> Final output sent to browser
DEBUG - 2012-07-24 18:22:25 --> Total execution time: 0.0823
DEBUG - 2012-07-24 18:22:31 --> Config Class Initialized
DEBUG - 2012-07-24 18:22:31 --> Hooks Class Initialized
DEBUG - 2012-07-24 18:22:31 --> Utf8 Class Initialized
DEBUG - 2012-07-24 18:22:31 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 18:22:31 --> URI Class Initialized
DEBUG - 2012-07-24 18:22:31 --> Router Class Initialized
DEBUG - 2012-07-24 18:22:31 --> Output Class Initialized
DEBUG - 2012-07-24 18:22:31 --> Security Class Initialized
DEBUG - 2012-07-24 18:22:31 --> Input Class Initialized
DEBUG - 2012-07-24 18:22:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 18:22:31 --> Language Class Initialized
DEBUG - 2012-07-24 18:22:31 --> Loader Class Initialized
DEBUG - 2012-07-24 18:22:31 --> Helper loaded: url_helper
DEBUG - 2012-07-24 18:22:31 --> Controller Class Initialized
DEBUG - 2012-07-24 18:22:31 --> Model Class Initialized
DEBUG - 2012-07-24 18:22:31 --> Database Driver Class Initialized
DEBUG - 2012-07-24 18:22:31 --> Helper loaded: form_helper
DEBUG - 2012-07-24 18:22:31 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 18:22:31 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 18:22:31 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 18:22:31 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 18:22:31 --> Final output sent to browser
DEBUG - 2012-07-24 18:22:31 --> Total execution time: 0.0445
DEBUG - 2012-07-24 18:24:02 --> Config Class Initialized
DEBUG - 2012-07-24 18:24:02 --> Hooks Class Initialized
DEBUG - 2012-07-24 18:24:02 --> Utf8 Class Initialized
DEBUG - 2012-07-24 18:24:02 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 18:24:02 --> URI Class Initialized
DEBUG - 2012-07-24 18:24:02 --> Router Class Initialized
DEBUG - 2012-07-24 18:24:02 --> Output Class Initialized
DEBUG - 2012-07-24 18:24:02 --> Security Class Initialized
DEBUG - 2012-07-24 18:24:02 --> Input Class Initialized
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> XSS Filtering completed
DEBUG - 2012-07-24 18:24:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 18:24:02 --> Language Class Initialized
DEBUG - 2012-07-24 18:24:02 --> Loader Class Initialized
DEBUG - 2012-07-24 18:24:02 --> Helper loaded: url_helper
DEBUG - 2012-07-24 18:24:02 --> Controller Class Initialized
DEBUG - 2012-07-24 18:24:02 --> Model Class Initialized
DEBUG - 2012-07-24 18:24:02 --> Database Driver Class Initialized
DEBUG - 2012-07-24 18:24:02 --> Helper loaded: form_helper
DEBUG - 2012-07-24 18:24:02 --> Form Validation Class Initialized
DEBUG - 2012-07-24 18:24:02 --> Final output sent to browser
DEBUG - 2012-07-24 18:24:02 --> Total execution time: 0.1000
DEBUG - 2012-07-24 18:25:00 --> Config Class Initialized
DEBUG - 2012-07-24 18:25:00 --> Hooks Class Initialized
DEBUG - 2012-07-24 18:25:00 --> Utf8 Class Initialized
DEBUG - 2012-07-24 18:25:00 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 18:25:00 --> URI Class Initialized
DEBUG - 2012-07-24 18:25:00 --> Router Class Initialized
DEBUG - 2012-07-24 18:25:00 --> Output Class Initialized
DEBUG - 2012-07-24 18:25:00 --> Security Class Initialized
DEBUG - 2012-07-24 18:25:00 --> Input Class Initialized
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> XSS Filtering completed
DEBUG - 2012-07-24 18:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 18:25:00 --> Language Class Initialized
DEBUG - 2012-07-24 18:25:00 --> Loader Class Initialized
DEBUG - 2012-07-24 18:25:00 --> Helper loaded: url_helper
DEBUG - 2012-07-24 18:25:00 --> Controller Class Initialized
DEBUG - 2012-07-24 18:25:00 --> Model Class Initialized
DEBUG - 2012-07-24 18:25:00 --> Database Driver Class Initialized
DEBUG - 2012-07-24 18:25:00 --> Helper loaded: form_helper
DEBUG - 2012-07-24 18:25:00 --> Form Validation Class Initialized
DEBUG - 2012-07-24 18:25:00 --> Final output sent to browser
DEBUG - 2012-07-24 18:25:00 --> Total execution time: 0.1688
DEBUG - 2012-07-24 18:33:13 --> Config Class Initialized
DEBUG - 2012-07-24 18:33:13 --> Hooks Class Initialized
DEBUG - 2012-07-24 18:33:13 --> Utf8 Class Initialized
DEBUG - 2012-07-24 18:33:13 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 18:33:13 --> URI Class Initialized
DEBUG - 2012-07-24 18:33:13 --> Router Class Initialized
DEBUG - 2012-07-24 18:33:13 --> Output Class Initialized
DEBUG - 2012-07-24 18:33:13 --> Security Class Initialized
DEBUG - 2012-07-24 18:33:13 --> Input Class Initialized
DEBUG - 2012-07-24 18:33:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 18:33:13 --> Language Class Initialized
DEBUG - 2012-07-24 18:33:13 --> Loader Class Initialized
DEBUG - 2012-07-24 18:33:13 --> Helper loaded: url_helper
DEBUG - 2012-07-24 18:33:13 --> Controller Class Initialized
DEBUG - 2012-07-24 18:33:13 --> Model Class Initialized
DEBUG - 2012-07-24 18:33:13 --> Database Driver Class Initialized
DEBUG - 2012-07-24 18:33:13 --> Helper loaded: form_helper
DEBUG - 2012-07-24 18:33:13 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 18:33:13 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 18:33:13 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 18:33:13 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 18:33:13 --> Final output sent to browser
DEBUG - 2012-07-24 18:33:13 --> Total execution time: 0.0544
DEBUG - 2012-07-24 19:13:53 --> Config Class Initialized
DEBUG - 2012-07-24 19:13:53 --> Hooks Class Initialized
DEBUG - 2012-07-24 19:13:53 --> Utf8 Class Initialized
DEBUG - 2012-07-24 19:13:53 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 19:13:53 --> URI Class Initialized
DEBUG - 2012-07-24 19:13:53 --> Router Class Initialized
DEBUG - 2012-07-24 19:13:53 --> Output Class Initialized
DEBUG - 2012-07-24 19:13:53 --> Security Class Initialized
DEBUG - 2012-07-24 19:13:53 --> Input Class Initialized
DEBUG - 2012-07-24 19:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 19:13:53 --> Language Class Initialized
DEBUG - 2012-07-24 19:14:30 --> Config Class Initialized
DEBUG - 2012-07-24 19:14:30 --> Hooks Class Initialized
DEBUG - 2012-07-24 19:14:30 --> Utf8 Class Initialized
DEBUG - 2012-07-24 19:14:30 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 19:14:30 --> URI Class Initialized
DEBUG - 2012-07-24 19:14:30 --> Router Class Initialized
DEBUG - 2012-07-24 19:14:30 --> Output Class Initialized
DEBUG - 2012-07-24 19:14:30 --> Security Class Initialized
DEBUG - 2012-07-24 19:14:30 --> Input Class Initialized
DEBUG - 2012-07-24 19:14:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 19:14:30 --> Language Class Initialized
DEBUG - 2012-07-24 19:14:30 --> Loader Class Initialized
DEBUG - 2012-07-24 19:14:30 --> Helper loaded: url_helper
DEBUG - 2012-07-24 19:14:30 --> Controller Class Initialized
DEBUG - 2012-07-24 19:14:30 --> Model Class Initialized
DEBUG - 2012-07-24 19:14:30 --> Database Driver Class Initialized
DEBUG - 2012-07-24 19:14:34 --> Config Class Initialized
DEBUG - 2012-07-24 19:14:34 --> Hooks Class Initialized
DEBUG - 2012-07-24 19:14:34 --> Utf8 Class Initialized
DEBUG - 2012-07-24 19:14:34 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 19:14:34 --> URI Class Initialized
DEBUG - 2012-07-24 19:14:34 --> Router Class Initialized
DEBUG - 2012-07-24 19:14:34 --> Output Class Initialized
DEBUG - 2012-07-24 19:14:34 --> Security Class Initialized
DEBUG - 2012-07-24 19:14:34 --> Input Class Initialized
DEBUG - 2012-07-24 19:14:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 19:14:34 --> Language Class Initialized
DEBUG - 2012-07-24 19:14:34 --> Loader Class Initialized
DEBUG - 2012-07-24 19:14:34 --> Helper loaded: url_helper
DEBUG - 2012-07-24 19:14:34 --> Controller Class Initialized
DEBUG - 2012-07-24 19:14:34 --> Model Class Initialized
DEBUG - 2012-07-24 19:14:34 --> Database Driver Class Initialized
DEBUG - 2012-07-24 19:15:07 --> Config Class Initialized
DEBUG - 2012-07-24 19:15:07 --> Hooks Class Initialized
DEBUG - 2012-07-24 19:15:07 --> Utf8 Class Initialized
DEBUG - 2012-07-24 19:15:07 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 19:15:07 --> URI Class Initialized
DEBUG - 2012-07-24 19:15:07 --> Router Class Initialized
DEBUG - 2012-07-24 19:15:07 --> Output Class Initialized
DEBUG - 2012-07-24 19:15:07 --> Security Class Initialized
DEBUG - 2012-07-24 19:15:07 --> Input Class Initialized
DEBUG - 2012-07-24 19:15:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 19:15:07 --> Language Class Initialized
DEBUG - 2012-07-24 19:15:07 --> Loader Class Initialized
DEBUG - 2012-07-24 19:15:07 --> Helper loaded: url_helper
DEBUG - 2012-07-24 19:15:07 --> Controller Class Initialized
DEBUG - 2012-07-24 19:15:07 --> Model Class Initialized
DEBUG - 2012-07-24 19:15:07 --> Database Driver Class Initialized
DEBUG - 2012-07-24 19:15:33 --> Config Class Initialized
DEBUG - 2012-07-24 19:15:33 --> Hooks Class Initialized
DEBUG - 2012-07-24 19:15:33 --> Utf8 Class Initialized
DEBUG - 2012-07-24 19:15:33 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 19:15:33 --> URI Class Initialized
DEBUG - 2012-07-24 19:15:33 --> Router Class Initialized
DEBUG - 2012-07-24 19:15:33 --> Output Class Initialized
DEBUG - 2012-07-24 19:15:33 --> Security Class Initialized
DEBUG - 2012-07-24 19:15:33 --> Input Class Initialized
DEBUG - 2012-07-24 19:15:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 19:15:33 --> Language Class Initialized
DEBUG - 2012-07-24 19:15:33 --> Loader Class Initialized
DEBUG - 2012-07-24 19:15:33 --> Helper loaded: url_helper
DEBUG - 2012-07-24 19:15:33 --> Controller Class Initialized
DEBUG - 2012-07-24 19:15:33 --> Model Class Initialized
DEBUG - 2012-07-24 19:15:33 --> Database Driver Class Initialized
DEBUG - 2012-07-24 19:15:33 --> Helper loaded: form_helper
DEBUG - 2012-07-24 19:15:33 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 19:15:33 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 19:15:33 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 19:15:33 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 19:15:33 --> Final output sent to browser
DEBUG - 2012-07-24 19:15:33 --> Total execution time: 0.0386
DEBUG - 2012-07-24 19:16:53 --> Config Class Initialized
DEBUG - 2012-07-24 19:16:53 --> Hooks Class Initialized
DEBUG - 2012-07-24 19:16:53 --> Utf8 Class Initialized
DEBUG - 2012-07-24 19:16:53 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 19:16:53 --> URI Class Initialized
DEBUG - 2012-07-24 19:16:53 --> Router Class Initialized
DEBUG - 2012-07-24 19:16:53 --> Output Class Initialized
DEBUG - 2012-07-24 19:16:53 --> Security Class Initialized
DEBUG - 2012-07-24 19:16:53 --> Input Class Initialized
DEBUG - 2012-07-24 19:16:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 19:16:53 --> Language Class Initialized
DEBUG - 2012-07-24 19:16:53 --> Loader Class Initialized
DEBUG - 2012-07-24 19:16:53 --> Helper loaded: url_helper
DEBUG - 2012-07-24 19:16:53 --> Controller Class Initialized
DEBUG - 2012-07-24 19:16:53 --> Model Class Initialized
DEBUG - 2012-07-24 19:16:53 --> Database Driver Class Initialized
DEBUG - 2012-07-24 19:16:53 --> Helper loaded: form_helper
DEBUG - 2012-07-24 19:16:53 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 19:16:53 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 19:16:53 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 19:16:53 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 19:16:53 --> Final output sent to browser
DEBUG - 2012-07-24 19:16:53 --> Total execution time: 0.0385
DEBUG - 2012-07-24 19:19:09 --> Config Class Initialized
DEBUG - 2012-07-24 19:19:09 --> Hooks Class Initialized
DEBUG - 2012-07-24 19:19:09 --> Utf8 Class Initialized
DEBUG - 2012-07-24 19:19:09 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 19:19:09 --> URI Class Initialized
DEBUG - 2012-07-24 19:19:09 --> Router Class Initialized
DEBUG - 2012-07-24 19:19:09 --> Output Class Initialized
DEBUG - 2012-07-24 19:19:09 --> Security Class Initialized
DEBUG - 2012-07-24 19:19:09 --> Input Class Initialized
DEBUG - 2012-07-24 19:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 19:19:09 --> Language Class Initialized
DEBUG - 2012-07-24 19:19:09 --> Loader Class Initialized
DEBUG - 2012-07-24 19:19:09 --> Helper loaded: url_helper
DEBUG - 2012-07-24 19:19:09 --> Controller Class Initialized
DEBUG - 2012-07-24 19:19:09 --> Model Class Initialized
DEBUG - 2012-07-24 19:19:09 --> Database Driver Class Initialized
DEBUG - 2012-07-24 19:19:09 --> Helper loaded: form_helper
DEBUG - 2012-07-24 19:19:09 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 19:19:09 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 19:19:09 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 19:19:09 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 19:19:09 --> Final output sent to browser
DEBUG - 2012-07-24 19:19:09 --> Total execution time: 0.0389
DEBUG - 2012-07-24 19:21:05 --> Config Class Initialized
DEBUG - 2012-07-24 19:21:05 --> Hooks Class Initialized
DEBUG - 2012-07-24 19:21:05 --> Utf8 Class Initialized
DEBUG - 2012-07-24 19:21:05 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 19:21:05 --> URI Class Initialized
DEBUG - 2012-07-24 19:21:05 --> Router Class Initialized
DEBUG - 2012-07-24 19:21:05 --> Output Class Initialized
DEBUG - 2012-07-24 19:21:05 --> Security Class Initialized
DEBUG - 2012-07-24 19:21:05 --> Input Class Initialized
DEBUG - 2012-07-24 19:21:05 --> XSS Filtering completed
DEBUG - 2012-07-24 19:21:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 19:21:05 --> Language Class Initialized
DEBUG - 2012-07-24 19:21:05 --> Loader Class Initialized
DEBUG - 2012-07-24 19:21:05 --> Helper loaded: url_helper
DEBUG - 2012-07-24 19:21:05 --> Controller Class Initialized
DEBUG - 2012-07-24 19:21:05 --> Model Class Initialized
DEBUG - 2012-07-24 19:21:05 --> Database Driver Class Initialized
ERROR - 2012-07-24 19:21:05 --> Severity: Warning  --> Missing argument 1 for Pricing_model::delete_print_sizes(), called in /home/jwp/www/justinwylliephotography.com/clients/application/controllers/admin/pricing.php on line 102 and defined /home/jwp/www/justinwylliephotography.com/clients/application/models/pricing_model.php 66
DEBUG - 2012-07-24 19:21:05 --> Final output sent to browser
DEBUG - 2012-07-24 19:21:05 --> Total execution time: 0.0318
DEBUG - 2012-07-24 19:21:23 --> Config Class Initialized
DEBUG - 2012-07-24 19:21:23 --> Hooks Class Initialized
DEBUG - 2012-07-24 19:21:23 --> Utf8 Class Initialized
DEBUG - 2012-07-24 19:21:23 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 19:21:23 --> URI Class Initialized
DEBUG - 2012-07-24 19:21:23 --> Router Class Initialized
DEBUG - 2012-07-24 19:21:23 --> Output Class Initialized
DEBUG - 2012-07-24 19:21:23 --> Security Class Initialized
DEBUG - 2012-07-24 19:21:23 --> Input Class Initialized
DEBUG - 2012-07-24 19:21:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 19:21:23 --> Language Class Initialized
DEBUG - 2012-07-24 19:21:23 --> Loader Class Initialized
DEBUG - 2012-07-24 19:21:23 --> Helper loaded: url_helper
DEBUG - 2012-07-24 19:21:23 --> Controller Class Initialized
DEBUG - 2012-07-24 19:21:23 --> Model Class Initialized
DEBUG - 2012-07-24 19:21:23 --> Database Driver Class Initialized
DEBUG - 2012-07-24 19:21:23 --> Helper loaded: form_helper
DEBUG - 2012-07-24 19:21:23 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 19:21:23 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 19:21:23 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 19:21:23 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 19:21:23 --> Final output sent to browser
DEBUG - 2012-07-24 19:21:23 --> Total execution time: 0.0385
DEBUG - 2012-07-24 19:21:26 --> Config Class Initialized
DEBUG - 2012-07-24 19:21:26 --> Hooks Class Initialized
DEBUG - 2012-07-24 19:21:26 --> Utf8 Class Initialized
DEBUG - 2012-07-24 19:21:26 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 19:21:26 --> URI Class Initialized
DEBUG - 2012-07-24 19:21:26 --> Router Class Initialized
DEBUG - 2012-07-24 19:21:26 --> Output Class Initialized
DEBUG - 2012-07-24 19:21:26 --> Security Class Initialized
DEBUG - 2012-07-24 19:21:26 --> Input Class Initialized
DEBUG - 2012-07-24 19:21:26 --> XSS Filtering completed
DEBUG - 2012-07-24 19:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 19:21:26 --> Language Class Initialized
DEBUG - 2012-07-24 19:21:26 --> Loader Class Initialized
DEBUG - 2012-07-24 19:21:26 --> Helper loaded: url_helper
DEBUG - 2012-07-24 19:21:26 --> Controller Class Initialized
DEBUG - 2012-07-24 19:21:26 --> Model Class Initialized
DEBUG - 2012-07-24 19:21:26 --> Database Driver Class Initialized
ERROR - 2012-07-24 19:21:26 --> Severity: Warning  --> Missing argument 1 for Pricing_model::delete_print_sizes(), called in /home/jwp/www/justinwylliephotography.com/clients/application/controllers/admin/pricing.php on line 102 and defined /home/jwp/www/justinwylliephotography.com/clients/application/models/pricing_model.php 66
DEBUG - 2012-07-24 19:21:26 --> Final output sent to browser
DEBUG - 2012-07-24 19:21:26 --> Total execution time: 0.0314
DEBUG - 2012-07-24 19:22:18 --> Config Class Initialized
DEBUG - 2012-07-24 19:22:18 --> Hooks Class Initialized
DEBUG - 2012-07-24 19:22:18 --> Utf8 Class Initialized
DEBUG - 2012-07-24 19:22:18 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 19:22:18 --> URI Class Initialized
DEBUG - 2012-07-24 19:22:18 --> Router Class Initialized
DEBUG - 2012-07-24 19:22:18 --> Output Class Initialized
DEBUG - 2012-07-24 19:22:18 --> Security Class Initialized
DEBUG - 2012-07-24 19:22:18 --> Input Class Initialized
DEBUG - 2012-07-24 19:22:18 --> XSS Filtering completed
DEBUG - 2012-07-24 19:22:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 19:22:18 --> Language Class Initialized
DEBUG - 2012-07-24 19:22:18 --> Loader Class Initialized
DEBUG - 2012-07-24 19:22:18 --> Helper loaded: url_helper
DEBUG - 2012-07-24 19:22:18 --> Controller Class Initialized
DEBUG - 2012-07-24 19:22:18 --> Model Class Initialized
DEBUG - 2012-07-24 19:22:18 --> Database Driver Class Initialized
DEBUG - 2012-07-24 19:22:18 --> Final output sent to browser
DEBUG - 2012-07-24 19:22:18 --> Total execution time: 0.0310
DEBUG - 2012-07-24 19:22:26 --> Config Class Initialized
DEBUG - 2012-07-24 19:22:26 --> Hooks Class Initialized
DEBUG - 2012-07-24 19:22:26 --> Utf8 Class Initialized
DEBUG - 2012-07-24 19:22:26 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 19:22:26 --> URI Class Initialized
DEBUG - 2012-07-24 19:22:26 --> Router Class Initialized
DEBUG - 2012-07-24 19:22:26 --> Output Class Initialized
DEBUG - 2012-07-24 19:22:26 --> Security Class Initialized
DEBUG - 2012-07-24 19:22:26 --> Input Class Initialized
DEBUG - 2012-07-24 19:22:26 --> XSS Filtering completed
DEBUG - 2012-07-24 19:22:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 19:22:26 --> Language Class Initialized
DEBUG - 2012-07-24 19:22:26 --> Loader Class Initialized
DEBUG - 2012-07-24 19:22:26 --> Helper loaded: url_helper
DEBUG - 2012-07-24 19:22:26 --> Controller Class Initialized
DEBUG - 2012-07-24 19:22:26 --> Model Class Initialized
DEBUG - 2012-07-24 19:22:26 --> Database Driver Class Initialized
DEBUG - 2012-07-24 19:22:26 --> Final output sent to browser
DEBUG - 2012-07-24 19:22:26 --> Total execution time: 0.0314
DEBUG - 2012-07-24 19:23:15 --> Config Class Initialized
DEBUG - 2012-07-24 19:23:15 --> Hooks Class Initialized
DEBUG - 2012-07-24 19:23:15 --> Utf8 Class Initialized
DEBUG - 2012-07-24 19:23:15 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 19:23:15 --> URI Class Initialized
DEBUG - 2012-07-24 19:23:15 --> Router Class Initialized
DEBUG - 2012-07-24 19:23:15 --> Output Class Initialized
DEBUG - 2012-07-24 19:23:15 --> Security Class Initialized
DEBUG - 2012-07-24 19:23:15 --> Input Class Initialized
DEBUG - 2012-07-24 19:23:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 19:23:15 --> Language Class Initialized
DEBUG - 2012-07-24 19:23:15 --> Loader Class Initialized
DEBUG - 2012-07-24 19:23:15 --> Helper loaded: url_helper
DEBUG - 2012-07-24 19:23:15 --> Controller Class Initialized
DEBUG - 2012-07-24 19:23:15 --> Model Class Initialized
DEBUG - 2012-07-24 19:23:15 --> Database Driver Class Initialized
DEBUG - 2012-07-24 19:23:15 --> Helper loaded: form_helper
DEBUG - 2012-07-24 19:23:15 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 19:23:15 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 19:23:15 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 19:23:15 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 19:23:15 --> Final output sent to browser
DEBUG - 2012-07-24 19:23:15 --> Total execution time: 0.0390
DEBUG - 2012-07-24 19:23:17 --> Config Class Initialized
DEBUG - 2012-07-24 19:23:17 --> Hooks Class Initialized
DEBUG - 2012-07-24 19:23:17 --> Utf8 Class Initialized
DEBUG - 2012-07-24 19:23:17 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 19:23:17 --> URI Class Initialized
DEBUG - 2012-07-24 19:23:17 --> Router Class Initialized
DEBUG - 2012-07-24 19:23:17 --> Output Class Initialized
DEBUG - 2012-07-24 19:23:17 --> Security Class Initialized
DEBUG - 2012-07-24 19:23:17 --> Input Class Initialized
DEBUG - 2012-07-24 19:23:17 --> XSS Filtering completed
DEBUG - 2012-07-24 19:23:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 19:23:18 --> Language Class Initialized
DEBUG - 2012-07-24 19:23:18 --> Loader Class Initialized
DEBUG - 2012-07-24 19:23:18 --> Helper loaded: url_helper
DEBUG - 2012-07-24 19:23:18 --> Controller Class Initialized
DEBUG - 2012-07-24 19:23:18 --> Model Class Initialized
DEBUG - 2012-07-24 19:23:18 --> Database Driver Class Initialized
DEBUG - 2012-07-24 19:23:18 --> Final output sent to browser
DEBUG - 2012-07-24 19:23:18 --> Total execution time: 0.0304
DEBUG - 2012-07-24 19:24:31 --> Config Class Initialized
DEBUG - 2012-07-24 19:24:31 --> Hooks Class Initialized
DEBUG - 2012-07-24 19:24:31 --> Utf8 Class Initialized
DEBUG - 2012-07-24 19:24:31 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 19:24:31 --> URI Class Initialized
DEBUG - 2012-07-24 19:24:31 --> Router Class Initialized
DEBUG - 2012-07-24 19:24:31 --> Output Class Initialized
DEBUG - 2012-07-24 19:24:31 --> Security Class Initialized
DEBUG - 2012-07-24 19:24:31 --> Input Class Initialized
DEBUG - 2012-07-24 19:24:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 19:24:31 --> Language Class Initialized
DEBUG - 2012-07-24 19:24:31 --> Loader Class Initialized
DEBUG - 2012-07-24 19:24:31 --> Helper loaded: url_helper
DEBUG - 2012-07-24 19:24:31 --> Controller Class Initialized
DEBUG - 2012-07-24 19:24:31 --> Model Class Initialized
DEBUG - 2012-07-24 19:24:31 --> Database Driver Class Initialized
DEBUG - 2012-07-24 19:24:31 --> Helper loaded: form_helper
DEBUG - 2012-07-24 19:24:31 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 19:24:31 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 19:24:31 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 19:24:31 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 19:24:31 --> Final output sent to browser
DEBUG - 2012-07-24 19:24:31 --> Total execution time: 0.0389
DEBUG - 2012-07-24 19:24:35 --> Config Class Initialized
DEBUG - 2012-07-24 19:24:35 --> Hooks Class Initialized
DEBUG - 2012-07-24 19:24:35 --> Utf8 Class Initialized
DEBUG - 2012-07-24 19:24:35 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 19:24:35 --> URI Class Initialized
DEBUG - 2012-07-24 19:24:35 --> Router Class Initialized
DEBUG - 2012-07-24 19:24:35 --> Output Class Initialized
DEBUG - 2012-07-24 19:24:35 --> Security Class Initialized
DEBUG - 2012-07-24 19:24:35 --> Input Class Initialized
DEBUG - 2012-07-24 19:24:35 --> XSS Filtering completed
DEBUG - 2012-07-24 19:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 19:24:35 --> Language Class Initialized
DEBUG - 2012-07-24 19:24:35 --> Loader Class Initialized
DEBUG - 2012-07-24 19:24:35 --> Helper loaded: url_helper
DEBUG - 2012-07-24 19:24:35 --> Controller Class Initialized
DEBUG - 2012-07-24 19:24:35 --> Model Class Initialized
DEBUG - 2012-07-24 19:24:35 --> Database Driver Class Initialized
DEBUG - 2012-07-24 19:24:35 --> Final output sent to browser
DEBUG - 2012-07-24 19:24:35 --> Total execution time: 0.0953
DEBUG - 2012-07-24 20:12:43 --> Config Class Initialized
DEBUG - 2012-07-24 20:12:43 --> Hooks Class Initialized
DEBUG - 2012-07-24 20:12:43 --> Utf8 Class Initialized
DEBUG - 2012-07-24 20:12:43 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 20:12:43 --> URI Class Initialized
DEBUG - 2012-07-24 20:12:43 --> Router Class Initialized
DEBUG - 2012-07-24 20:12:43 --> Output Class Initialized
DEBUG - 2012-07-24 20:12:43 --> Security Class Initialized
DEBUG - 2012-07-24 20:12:43 --> Input Class Initialized
DEBUG - 2012-07-24 20:12:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 20:12:43 --> Language Class Initialized
DEBUG - 2012-07-24 20:12:43 --> Loader Class Initialized
DEBUG - 2012-07-24 20:12:43 --> Helper loaded: url_helper
DEBUG - 2012-07-24 20:12:43 --> Controller Class Initialized
DEBUG - 2012-07-24 20:12:43 --> Model Class Initialized
DEBUG - 2012-07-24 20:12:43 --> Database Driver Class Initialized
DEBUG - 2012-07-24 20:12:43 --> Helper loaded: form_helper
DEBUG - 2012-07-24 20:12:43 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 20:12:43 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 20:12:43 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 20:12:43 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 20:12:43 --> Final output sent to browser
DEBUG - 2012-07-24 20:12:43 --> Total execution time: 0.0393
DEBUG - 2012-07-24 20:14:23 --> Config Class Initialized
DEBUG - 2012-07-24 20:14:23 --> Hooks Class Initialized
DEBUG - 2012-07-24 20:14:23 --> Utf8 Class Initialized
DEBUG - 2012-07-24 20:14:23 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 20:14:23 --> URI Class Initialized
DEBUG - 2012-07-24 20:14:23 --> Router Class Initialized
DEBUG - 2012-07-24 20:14:23 --> Output Class Initialized
DEBUG - 2012-07-24 20:14:23 --> Security Class Initialized
DEBUG - 2012-07-24 20:14:23 --> Input Class Initialized
DEBUG - 2012-07-24 20:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 20:14:23 --> Language Class Initialized
DEBUG - 2012-07-24 20:14:23 --> Loader Class Initialized
DEBUG - 2012-07-24 20:14:23 --> Helper loaded: url_helper
DEBUG - 2012-07-24 20:14:23 --> Controller Class Initialized
DEBUG - 2012-07-24 20:14:23 --> Model Class Initialized
DEBUG - 2012-07-24 20:14:23 --> Database Driver Class Initialized
DEBUG - 2012-07-24 20:14:23 --> Helper loaded: form_helper
DEBUG - 2012-07-24 20:14:23 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 20:14:23 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 20:14:23 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 20:14:23 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 20:14:23 --> Final output sent to browser
DEBUG - 2012-07-24 20:14:23 --> Total execution time: 0.0550
DEBUG - 2012-07-24 20:19:13 --> Config Class Initialized
DEBUG - 2012-07-24 20:19:13 --> Hooks Class Initialized
DEBUG - 2012-07-24 20:19:13 --> Utf8 Class Initialized
DEBUG - 2012-07-24 20:19:13 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 20:19:13 --> URI Class Initialized
DEBUG - 2012-07-24 20:19:13 --> Router Class Initialized
DEBUG - 2012-07-24 20:19:13 --> Output Class Initialized
DEBUG - 2012-07-24 20:19:13 --> Security Class Initialized
DEBUG - 2012-07-24 20:19:13 --> Input Class Initialized
DEBUG - 2012-07-24 20:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 20:19:13 --> Language Class Initialized
DEBUG - 2012-07-24 20:19:13 --> Loader Class Initialized
DEBUG - 2012-07-24 20:19:13 --> Helper loaded: url_helper
DEBUG - 2012-07-24 20:19:13 --> Controller Class Initialized
DEBUG - 2012-07-24 20:19:13 --> Model Class Initialized
DEBUG - 2012-07-24 20:19:13 --> Database Driver Class Initialized
DEBUG - 2012-07-24 20:19:13 --> Helper loaded: form_helper
DEBUG - 2012-07-24 20:19:13 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 20:19:13 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 20:19:13 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 20:19:13 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 20:19:13 --> Final output sent to browser
DEBUG - 2012-07-24 20:19:13 --> Total execution time: 0.0412
DEBUG - 2012-07-24 20:19:58 --> Config Class Initialized
DEBUG - 2012-07-24 20:19:58 --> Hooks Class Initialized
DEBUG - 2012-07-24 20:19:58 --> Utf8 Class Initialized
DEBUG - 2012-07-24 20:19:58 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 20:19:58 --> URI Class Initialized
DEBUG - 2012-07-24 20:19:58 --> Router Class Initialized
DEBUG - 2012-07-24 20:19:58 --> Output Class Initialized
DEBUG - 2012-07-24 20:19:58 --> Security Class Initialized
DEBUG - 2012-07-24 20:19:58 --> Input Class Initialized
DEBUG - 2012-07-24 20:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 20:19:58 --> Language Class Initialized
DEBUG - 2012-07-24 20:19:58 --> Loader Class Initialized
DEBUG - 2012-07-24 20:19:58 --> Helper loaded: url_helper
DEBUG - 2012-07-24 20:19:58 --> Controller Class Initialized
DEBUG - 2012-07-24 20:19:58 --> Model Class Initialized
DEBUG - 2012-07-24 20:19:58 --> Database Driver Class Initialized
DEBUG - 2012-07-24 20:19:58 --> Helper loaded: form_helper
DEBUG - 2012-07-24 20:19:58 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 20:19:58 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 20:19:58 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 20:19:58 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 20:19:58 --> Final output sent to browser
DEBUG - 2012-07-24 20:19:58 --> Total execution time: 0.0416
DEBUG - 2012-07-24 20:21:31 --> Config Class Initialized
DEBUG - 2012-07-24 20:21:31 --> Hooks Class Initialized
DEBUG - 2012-07-24 20:21:31 --> Utf8 Class Initialized
DEBUG - 2012-07-24 20:21:31 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 20:21:31 --> URI Class Initialized
DEBUG - 2012-07-24 20:21:31 --> Router Class Initialized
DEBUG - 2012-07-24 20:21:31 --> Output Class Initialized
DEBUG - 2012-07-24 20:21:31 --> Security Class Initialized
DEBUG - 2012-07-24 20:21:31 --> Input Class Initialized
DEBUG - 2012-07-24 20:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 20:21:31 --> Language Class Initialized
DEBUG - 2012-07-24 20:21:31 --> Loader Class Initialized
DEBUG - 2012-07-24 20:21:31 --> Helper loaded: url_helper
DEBUG - 2012-07-24 20:21:31 --> Controller Class Initialized
DEBUG - 2012-07-24 20:21:31 --> Model Class Initialized
DEBUG - 2012-07-24 20:21:31 --> Database Driver Class Initialized
DEBUG - 2012-07-24 20:21:31 --> Helper loaded: form_helper
DEBUG - 2012-07-24 20:21:31 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 20:21:31 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 20:21:31 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 20:21:31 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 20:21:31 --> Final output sent to browser
DEBUG - 2012-07-24 20:21:31 --> Total execution time: 0.0390
DEBUG - 2012-07-24 20:32:17 --> Config Class Initialized
DEBUG - 2012-07-24 20:32:17 --> Hooks Class Initialized
DEBUG - 2012-07-24 20:32:17 --> Utf8 Class Initialized
DEBUG - 2012-07-24 20:32:17 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 20:32:17 --> URI Class Initialized
DEBUG - 2012-07-24 20:32:17 --> Router Class Initialized
DEBUG - 2012-07-24 20:32:17 --> Output Class Initialized
DEBUG - 2012-07-24 20:32:17 --> Security Class Initialized
DEBUG - 2012-07-24 20:32:17 --> Input Class Initialized
DEBUG - 2012-07-24 20:32:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 20:32:17 --> Language Class Initialized
DEBUG - 2012-07-24 20:32:17 --> Loader Class Initialized
DEBUG - 2012-07-24 20:32:17 --> Helper loaded: url_helper
DEBUG - 2012-07-24 20:32:17 --> Controller Class Initialized
DEBUG - 2012-07-24 20:32:17 --> Model Class Initialized
DEBUG - 2012-07-24 20:32:17 --> Database Driver Class Initialized
DEBUG - 2012-07-24 20:32:17 --> Helper loaded: form_helper
DEBUG - 2012-07-24 20:32:17 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 20:32:17 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 20:32:17 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 20:32:17 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 20:32:17 --> Final output sent to browser
DEBUG - 2012-07-24 20:32:17 --> Total execution time: 0.0516
DEBUG - 2012-07-24 20:33:34 --> Config Class Initialized
DEBUG - 2012-07-24 20:33:34 --> Hooks Class Initialized
DEBUG - 2012-07-24 20:33:34 --> Utf8 Class Initialized
DEBUG - 2012-07-24 20:33:34 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 20:33:34 --> URI Class Initialized
DEBUG - 2012-07-24 20:33:34 --> Router Class Initialized
DEBUG - 2012-07-24 20:33:34 --> Output Class Initialized
DEBUG - 2012-07-24 20:33:34 --> Security Class Initialized
DEBUG - 2012-07-24 20:33:34 --> Input Class Initialized
DEBUG - 2012-07-24 20:33:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 20:33:34 --> Language Class Initialized
DEBUG - 2012-07-24 20:33:34 --> Loader Class Initialized
DEBUG - 2012-07-24 20:33:34 --> Helper loaded: url_helper
DEBUG - 2012-07-24 20:33:34 --> Controller Class Initialized
DEBUG - 2012-07-24 20:33:34 --> Model Class Initialized
DEBUG - 2012-07-24 20:33:34 --> Database Driver Class Initialized
DEBUG - 2012-07-24 20:33:34 --> Helper loaded: form_helper
DEBUG - 2012-07-24 20:33:34 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 20:33:34 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 20:33:34 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 20:33:34 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 20:33:34 --> Final output sent to browser
DEBUG - 2012-07-24 20:33:34 --> Total execution time: 0.0393
DEBUG - 2012-07-24 20:33:59 --> Config Class Initialized
DEBUG - 2012-07-24 20:33:59 --> Hooks Class Initialized
DEBUG - 2012-07-24 20:33:59 --> Utf8 Class Initialized
DEBUG - 2012-07-24 20:33:59 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 20:33:59 --> URI Class Initialized
DEBUG - 2012-07-24 20:33:59 --> Router Class Initialized
DEBUG - 2012-07-24 20:33:59 --> Output Class Initialized
DEBUG - 2012-07-24 20:33:59 --> Security Class Initialized
DEBUG - 2012-07-24 20:33:59 --> Input Class Initialized
DEBUG - 2012-07-24 20:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 20:33:59 --> Language Class Initialized
DEBUG - 2012-07-24 20:33:59 --> Loader Class Initialized
DEBUG - 2012-07-24 20:33:59 --> Helper loaded: url_helper
DEBUG - 2012-07-24 20:33:59 --> Controller Class Initialized
DEBUG - 2012-07-24 20:33:59 --> Model Class Initialized
DEBUG - 2012-07-24 20:33:59 --> Database Driver Class Initialized
DEBUG - 2012-07-24 20:33:59 --> Helper loaded: form_helper
DEBUG - 2012-07-24 20:33:59 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 20:33:59 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 20:33:59 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 20:33:59 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 20:33:59 --> Final output sent to browser
DEBUG - 2012-07-24 20:33:59 --> Total execution time: 0.0394
DEBUG - 2012-07-24 20:34:43 --> Config Class Initialized
DEBUG - 2012-07-24 20:34:43 --> Hooks Class Initialized
DEBUG - 2012-07-24 20:34:43 --> Utf8 Class Initialized
DEBUG - 2012-07-24 20:34:43 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 20:34:43 --> URI Class Initialized
DEBUG - 2012-07-24 20:34:43 --> Router Class Initialized
DEBUG - 2012-07-24 20:34:43 --> Output Class Initialized
DEBUG - 2012-07-24 20:34:43 --> Security Class Initialized
DEBUG - 2012-07-24 20:34:43 --> Input Class Initialized
DEBUG - 2012-07-24 20:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 20:34:43 --> Language Class Initialized
DEBUG - 2012-07-24 20:34:43 --> Loader Class Initialized
DEBUG - 2012-07-24 20:34:43 --> Helper loaded: url_helper
DEBUG - 2012-07-24 20:34:43 --> Controller Class Initialized
DEBUG - 2012-07-24 20:34:43 --> Model Class Initialized
DEBUG - 2012-07-24 20:34:43 --> Database Driver Class Initialized
DEBUG - 2012-07-24 20:34:43 --> Helper loaded: form_helper
DEBUG - 2012-07-24 20:34:44 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 20:34:44 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 20:34:44 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 20:34:44 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 20:34:44 --> Final output sent to browser
DEBUG - 2012-07-24 20:34:44 --> Total execution time: 0.0388
DEBUG - 2012-07-24 20:35:06 --> Config Class Initialized
DEBUG - 2012-07-24 20:35:06 --> Hooks Class Initialized
DEBUG - 2012-07-24 20:35:06 --> Utf8 Class Initialized
DEBUG - 2012-07-24 20:35:06 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 20:35:06 --> URI Class Initialized
DEBUG - 2012-07-24 20:35:06 --> Router Class Initialized
DEBUG - 2012-07-24 20:35:06 --> Output Class Initialized
DEBUG - 2012-07-24 20:35:06 --> Security Class Initialized
DEBUG - 2012-07-24 20:35:06 --> Input Class Initialized
DEBUG - 2012-07-24 20:35:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 20:35:06 --> Language Class Initialized
DEBUG - 2012-07-24 20:35:06 --> Loader Class Initialized
DEBUG - 2012-07-24 20:35:06 --> Helper loaded: url_helper
DEBUG - 2012-07-24 20:35:06 --> Controller Class Initialized
DEBUG - 2012-07-24 20:35:06 --> Model Class Initialized
DEBUG - 2012-07-24 20:35:06 --> Database Driver Class Initialized
DEBUG - 2012-07-24 20:35:06 --> Helper loaded: form_helper
DEBUG - 2012-07-24 20:35:06 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 20:35:06 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 20:35:06 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 20:35:06 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 20:35:06 --> Final output sent to browser
DEBUG - 2012-07-24 20:35:06 --> Total execution time: 0.0385
DEBUG - 2012-07-24 20:40:13 --> Config Class Initialized
DEBUG - 2012-07-24 20:40:13 --> Hooks Class Initialized
DEBUG - 2012-07-24 20:40:13 --> Utf8 Class Initialized
DEBUG - 2012-07-24 20:40:13 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 20:40:13 --> URI Class Initialized
DEBUG - 2012-07-24 20:40:13 --> Router Class Initialized
DEBUG - 2012-07-24 20:40:13 --> Output Class Initialized
DEBUG - 2012-07-24 20:40:13 --> Security Class Initialized
DEBUG - 2012-07-24 20:40:13 --> Input Class Initialized
DEBUG - 2012-07-24 20:40:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 20:40:13 --> Language Class Initialized
DEBUG - 2012-07-24 20:40:13 --> Loader Class Initialized
DEBUG - 2012-07-24 20:40:13 --> Helper loaded: url_helper
DEBUG - 2012-07-24 20:40:13 --> Controller Class Initialized
DEBUG - 2012-07-24 20:40:13 --> Model Class Initialized
DEBUG - 2012-07-24 20:40:13 --> Database Driver Class Initialized
DEBUG - 2012-07-24 20:40:13 --> Helper loaded: form_helper
DEBUG - 2012-07-24 20:40:13 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 20:40:13 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 20:40:13 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 20:40:13 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 20:40:13 --> Final output sent to browser
DEBUG - 2012-07-24 20:40:13 --> Total execution time: 0.0395
DEBUG - 2012-07-24 20:42:03 --> Config Class Initialized
DEBUG - 2012-07-24 20:42:03 --> Hooks Class Initialized
DEBUG - 2012-07-24 20:42:03 --> Utf8 Class Initialized
DEBUG - 2012-07-24 20:42:03 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 20:42:03 --> URI Class Initialized
DEBUG - 2012-07-24 20:42:03 --> Router Class Initialized
DEBUG - 2012-07-24 20:42:03 --> Output Class Initialized
DEBUG - 2012-07-24 20:42:03 --> Security Class Initialized
DEBUG - 2012-07-24 20:42:03 --> Input Class Initialized
DEBUG - 2012-07-24 20:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 20:42:03 --> Language Class Initialized
DEBUG - 2012-07-24 20:42:03 --> Loader Class Initialized
DEBUG - 2012-07-24 20:42:03 --> Helper loaded: url_helper
DEBUG - 2012-07-24 20:42:03 --> Controller Class Initialized
DEBUG - 2012-07-24 20:42:03 --> Model Class Initialized
DEBUG - 2012-07-24 20:42:03 --> Database Driver Class Initialized
DEBUG - 2012-07-24 20:42:03 --> Helper loaded: form_helper
DEBUG - 2012-07-24 20:42:03 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 20:42:03 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 20:42:03 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 20:42:03 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 20:42:03 --> Final output sent to browser
DEBUG - 2012-07-24 20:42:03 --> Total execution time: 0.0393
DEBUG - 2012-07-24 21:01:23 --> Config Class Initialized
DEBUG - 2012-07-24 21:01:23 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:01:23 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:01:23 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:01:23 --> URI Class Initialized
DEBUG - 2012-07-24 21:01:23 --> Router Class Initialized
DEBUG - 2012-07-24 21:01:23 --> Output Class Initialized
DEBUG - 2012-07-24 21:01:23 --> Security Class Initialized
DEBUG - 2012-07-24 21:01:23 --> Input Class Initialized
DEBUG - 2012-07-24 21:01:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:01:23 --> Language Class Initialized
DEBUG - 2012-07-24 21:01:23 --> Loader Class Initialized
DEBUG - 2012-07-24 21:01:23 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:01:23 --> Controller Class Initialized
DEBUG - 2012-07-24 21:01:23 --> Model Class Initialized
DEBUG - 2012-07-24 21:01:23 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:01:23 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:01:23 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:01:23 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:01:23 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 21:01:23 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 21:01:23 --> Final output sent to browser
DEBUG - 2012-07-24 21:01:23 --> Total execution time: 0.0383
DEBUG - 2012-07-24 21:01:45 --> Config Class Initialized
DEBUG - 2012-07-24 21:01:45 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:01:45 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:01:45 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:01:46 --> URI Class Initialized
DEBUG - 2012-07-24 21:01:46 --> Router Class Initialized
DEBUG - 2012-07-24 21:01:46 --> Output Class Initialized
DEBUG - 2012-07-24 21:01:46 --> Security Class Initialized
DEBUG - 2012-07-24 21:01:46 --> Input Class Initialized
DEBUG - 2012-07-24 21:01:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:01:46 --> Language Class Initialized
DEBUG - 2012-07-24 21:01:46 --> Loader Class Initialized
DEBUG - 2012-07-24 21:01:46 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:01:46 --> Controller Class Initialized
DEBUG - 2012-07-24 21:01:46 --> Model Class Initialized
DEBUG - 2012-07-24 21:01:46 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:01:46 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:01:46 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:01:46 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:01:46 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 21:01:46 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 21:01:46 --> Final output sent to browser
DEBUG - 2012-07-24 21:01:46 --> Total execution time: 0.0385
DEBUG - 2012-07-24 21:07:32 --> Config Class Initialized
DEBUG - 2012-07-24 21:07:32 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:07:32 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:07:32 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:07:32 --> URI Class Initialized
DEBUG - 2012-07-24 21:07:32 --> Router Class Initialized
DEBUG - 2012-07-24 21:07:32 --> Output Class Initialized
DEBUG - 2012-07-24 21:07:32 --> Security Class Initialized
DEBUG - 2012-07-24 21:07:32 --> Input Class Initialized
DEBUG - 2012-07-24 21:07:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:07:32 --> Language Class Initialized
DEBUG - 2012-07-24 21:07:32 --> Loader Class Initialized
DEBUG - 2012-07-24 21:07:32 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:07:32 --> Controller Class Initialized
DEBUG - 2012-07-24 21:07:32 --> Model Class Initialized
DEBUG - 2012-07-24 21:07:32 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:07:32 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:07:32 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:07:32 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:07:32 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 21:07:32 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 21:07:32 --> Final output sent to browser
DEBUG - 2012-07-24 21:07:32 --> Total execution time: 0.0383
DEBUG - 2012-07-24 21:15:05 --> Config Class Initialized
DEBUG - 2012-07-24 21:15:05 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:15:05 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:15:05 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:15:05 --> URI Class Initialized
DEBUG - 2012-07-24 21:15:05 --> Router Class Initialized
DEBUG - 2012-07-24 21:15:05 --> Output Class Initialized
DEBUG - 2012-07-24 21:15:05 --> Security Class Initialized
DEBUG - 2012-07-24 21:15:05 --> Input Class Initialized
DEBUG - 2012-07-24 21:15:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:15:05 --> Language Class Initialized
DEBUG - 2012-07-24 21:15:05 --> Loader Class Initialized
DEBUG - 2012-07-24 21:15:05 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:15:05 --> Controller Class Initialized
DEBUG - 2012-07-24 21:15:05 --> Model Class Initialized
DEBUG - 2012-07-24 21:15:06 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:15:06 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:15:06 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:15:06 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:15:08 --> Config Class Initialized
DEBUG - 2012-07-24 21:15:08 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:15:08 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:15:08 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:15:08 --> URI Class Initialized
DEBUG - 2012-07-24 21:15:08 --> Router Class Initialized
DEBUG - 2012-07-24 21:15:08 --> Output Class Initialized
DEBUG - 2012-07-24 21:15:08 --> Security Class Initialized
DEBUG - 2012-07-24 21:15:08 --> Input Class Initialized
DEBUG - 2012-07-24 21:15:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:15:08 --> Language Class Initialized
DEBUG - 2012-07-24 21:15:08 --> Loader Class Initialized
DEBUG - 2012-07-24 21:15:08 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:15:08 --> Controller Class Initialized
DEBUG - 2012-07-24 21:15:08 --> Model Class Initialized
DEBUG - 2012-07-24 21:15:08 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:15:08 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:15:08 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:15:08 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:15:41 --> Config Class Initialized
DEBUG - 2012-07-24 21:15:41 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:15:41 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:15:41 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:15:41 --> URI Class Initialized
DEBUG - 2012-07-24 21:15:41 --> Router Class Initialized
DEBUG - 2012-07-24 21:15:41 --> Output Class Initialized
DEBUG - 2012-07-24 21:15:41 --> Security Class Initialized
DEBUG - 2012-07-24 21:15:41 --> Input Class Initialized
DEBUG - 2012-07-24 21:15:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:15:41 --> Language Class Initialized
DEBUG - 2012-07-24 21:15:41 --> Loader Class Initialized
DEBUG - 2012-07-24 21:15:41 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:15:41 --> Controller Class Initialized
DEBUG - 2012-07-24 21:15:41 --> Model Class Initialized
DEBUG - 2012-07-24 21:15:41 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:15:41 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:15:41 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:15:41 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:15:41 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 21:15:41 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 21:15:41 --> Final output sent to browser
DEBUG - 2012-07-24 21:15:41 --> Total execution time: 0.0389
DEBUG - 2012-07-24 21:17:26 --> Config Class Initialized
DEBUG - 2012-07-24 21:17:26 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:17:26 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:17:26 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:17:26 --> URI Class Initialized
DEBUG - 2012-07-24 21:17:26 --> Router Class Initialized
DEBUG - 2012-07-24 21:17:26 --> Output Class Initialized
DEBUG - 2012-07-24 21:17:26 --> Security Class Initialized
DEBUG - 2012-07-24 21:17:26 --> Input Class Initialized
DEBUG - 2012-07-24 21:17:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:17:26 --> Language Class Initialized
DEBUG - 2012-07-24 21:17:26 --> Loader Class Initialized
DEBUG - 2012-07-24 21:17:26 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:17:26 --> Controller Class Initialized
DEBUG - 2012-07-24 21:17:26 --> Model Class Initialized
DEBUG - 2012-07-24 21:17:26 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:17:26 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:17:26 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:17:26 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:17:26 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 21:17:26 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 21:17:26 --> Final output sent to browser
DEBUG - 2012-07-24 21:17:26 --> Total execution time: 0.0392
DEBUG - 2012-07-24 21:17:57 --> Config Class Initialized
DEBUG - 2012-07-24 21:17:57 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:17:57 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:17:57 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:17:57 --> URI Class Initialized
DEBUG - 2012-07-24 21:17:57 --> Router Class Initialized
DEBUG - 2012-07-24 21:17:57 --> Output Class Initialized
DEBUG - 2012-07-24 21:17:57 --> Security Class Initialized
DEBUG - 2012-07-24 21:17:57 --> Input Class Initialized
DEBUG - 2012-07-24 21:17:57 --> XSS Filtering completed
DEBUG - 2012-07-24 21:17:57 --> XSS Filtering completed
DEBUG - 2012-07-24 21:17:57 --> XSS Filtering completed
DEBUG - 2012-07-24 21:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:17:57 --> Language Class Initialized
DEBUG - 2012-07-24 21:17:57 --> Loader Class Initialized
DEBUG - 2012-07-24 21:17:57 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:17:57 --> Controller Class Initialized
DEBUG - 2012-07-24 21:17:57 --> Model Class Initialized
DEBUG - 2012-07-24 21:17:57 --> Database Driver Class Initialized
ERROR - 2012-07-24 21:17:57 --> Severity: Notice  --> Undefined variable: insert /home/jwp/www/justinwylliephotography.com/clients/application/models/pricing_model.php 91
DEBUG - 2012-07-24 21:18:53 --> Config Class Initialized
DEBUG - 2012-07-24 21:18:53 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:18:53 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:18:53 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:18:53 --> URI Class Initialized
DEBUG - 2012-07-24 21:18:53 --> Router Class Initialized
DEBUG - 2012-07-24 21:18:53 --> Output Class Initialized
DEBUG - 2012-07-24 21:18:53 --> Security Class Initialized
DEBUG - 2012-07-24 21:18:53 --> Input Class Initialized
DEBUG - 2012-07-24 21:18:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:18:53 --> Language Class Initialized
DEBUG - 2012-07-24 21:18:53 --> Loader Class Initialized
DEBUG - 2012-07-24 21:18:53 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:18:53 --> Controller Class Initialized
DEBUG - 2012-07-24 21:18:53 --> Model Class Initialized
DEBUG - 2012-07-24 21:18:53 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:18:53 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:18:53 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:18:53 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:18:53 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 21:18:53 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 21:18:53 --> Final output sent to browser
DEBUG - 2012-07-24 21:18:53 --> Total execution time: 0.0384
DEBUG - 2012-07-24 21:19:08 --> Config Class Initialized
DEBUG - 2012-07-24 21:19:08 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:19:08 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:19:08 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:19:08 --> URI Class Initialized
DEBUG - 2012-07-24 21:19:08 --> Router Class Initialized
DEBUG - 2012-07-24 21:19:08 --> Output Class Initialized
DEBUG - 2012-07-24 21:19:08 --> Security Class Initialized
DEBUG - 2012-07-24 21:19:08 --> Input Class Initialized
DEBUG - 2012-07-24 21:19:08 --> XSS Filtering completed
DEBUG - 2012-07-24 21:19:08 --> XSS Filtering completed
DEBUG - 2012-07-24 21:19:08 --> XSS Filtering completed
DEBUG - 2012-07-24 21:19:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:19:08 --> Language Class Initialized
DEBUG - 2012-07-24 21:19:08 --> Loader Class Initialized
DEBUG - 2012-07-24 21:19:08 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:19:08 --> Controller Class Initialized
DEBUG - 2012-07-24 21:19:08 --> Model Class Initialized
DEBUG - 2012-07-24 21:19:08 --> Database Driver Class Initialized
ERROR - 2012-07-24 21:19:08 --> Severity: Notice  --> Undefined variable: insert /home/jwp/www/justinwylliephotography.com/clients/application/models/pricing_model.php 91
DEBUG - 2012-07-24 21:19:08 --> Final output sent to browser
DEBUG - 2012-07-24 21:19:08 --> Total execution time: 0.0358
DEBUG - 2012-07-24 21:19:16 --> Config Class Initialized
DEBUG - 2012-07-24 21:19:16 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:19:16 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:19:16 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:19:16 --> URI Class Initialized
DEBUG - 2012-07-24 21:19:16 --> Router Class Initialized
DEBUG - 2012-07-24 21:19:16 --> Output Class Initialized
DEBUG - 2012-07-24 21:19:16 --> Security Class Initialized
DEBUG - 2012-07-24 21:19:16 --> Input Class Initialized
DEBUG - 2012-07-24 21:19:16 --> XSS Filtering completed
DEBUG - 2012-07-24 21:19:16 --> XSS Filtering completed
DEBUG - 2012-07-24 21:19:16 --> XSS Filtering completed
DEBUG - 2012-07-24 21:19:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:19:16 --> Language Class Initialized
DEBUG - 2012-07-24 21:19:16 --> Loader Class Initialized
DEBUG - 2012-07-24 21:19:16 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:19:16 --> Controller Class Initialized
DEBUG - 2012-07-24 21:19:16 --> Model Class Initialized
DEBUG - 2012-07-24 21:19:16 --> Database Driver Class Initialized
ERROR - 2012-07-24 21:19:16 --> Severity: Notice  --> Undefined variable: insert /home/jwp/www/justinwylliephotography.com/clients/application/models/pricing_model.php 91
DEBUG - 2012-07-24 21:19:16 --> Final output sent to browser
DEBUG - 2012-07-24 21:19:16 --> Total execution time: 0.0466
DEBUG - 2012-07-24 21:19:34 --> Config Class Initialized
DEBUG - 2012-07-24 21:19:34 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:19:34 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:19:34 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:19:34 --> URI Class Initialized
DEBUG - 2012-07-24 21:19:34 --> Router Class Initialized
DEBUG - 2012-07-24 21:19:34 --> Output Class Initialized
DEBUG - 2012-07-24 21:19:34 --> Security Class Initialized
DEBUG - 2012-07-24 21:19:34 --> Input Class Initialized
DEBUG - 2012-07-24 21:19:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:19:34 --> Language Class Initialized
DEBUG - 2012-07-24 21:19:34 --> Loader Class Initialized
DEBUG - 2012-07-24 21:19:34 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:19:34 --> Controller Class Initialized
DEBUG - 2012-07-24 21:19:34 --> Model Class Initialized
DEBUG - 2012-07-24 21:19:34 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:19:34 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:19:34 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:19:34 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:19:34 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 21:19:34 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 21:19:34 --> Final output sent to browser
DEBUG - 2012-07-24 21:19:34 --> Total execution time: 0.0384
DEBUG - 2012-07-24 21:20:01 --> Config Class Initialized
DEBUG - 2012-07-24 21:20:01 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:20:01 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:20:01 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:20:01 --> URI Class Initialized
DEBUG - 2012-07-24 21:20:01 --> Router Class Initialized
DEBUG - 2012-07-24 21:20:01 --> Output Class Initialized
DEBUG - 2012-07-24 21:20:01 --> Security Class Initialized
DEBUG - 2012-07-24 21:20:01 --> Input Class Initialized
DEBUG - 2012-07-24 21:20:01 --> XSS Filtering completed
DEBUG - 2012-07-24 21:20:01 --> XSS Filtering completed
DEBUG - 2012-07-24 21:20:01 --> XSS Filtering completed
DEBUG - 2012-07-24 21:20:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:20:01 --> Language Class Initialized
DEBUG - 2012-07-24 21:20:01 --> Loader Class Initialized
DEBUG - 2012-07-24 21:20:01 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:20:01 --> Controller Class Initialized
DEBUG - 2012-07-24 21:20:01 --> Model Class Initialized
DEBUG - 2012-07-24 21:20:01 --> Database Driver Class Initialized
ERROR - 2012-07-24 21:20:01 --> Severity: Notice  --> Undefined variable: insert /home/jwp/www/justinwylliephotography.com/clients/application/models/pricing_model.php 91
DEBUG - 2012-07-24 21:20:01 --> Final output sent to browser
DEBUG - 2012-07-24 21:20:01 --> Total execution time: 0.0706
DEBUG - 2012-07-24 21:21:54 --> Config Class Initialized
DEBUG - 2012-07-24 21:21:54 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:21:54 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:21:54 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:21:54 --> URI Class Initialized
DEBUG - 2012-07-24 21:21:54 --> Router Class Initialized
DEBUG - 2012-07-24 21:21:54 --> Output Class Initialized
DEBUG - 2012-07-24 21:21:54 --> Security Class Initialized
DEBUG - 2012-07-24 21:21:54 --> Input Class Initialized
DEBUG - 2012-07-24 21:21:54 --> XSS Filtering completed
DEBUG - 2012-07-24 21:21:54 --> XSS Filtering completed
DEBUG - 2012-07-24 21:21:54 --> XSS Filtering completed
DEBUG - 2012-07-24 21:21:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:21:54 --> Language Class Initialized
DEBUG - 2012-07-24 21:21:54 --> Loader Class Initialized
DEBUG - 2012-07-24 21:21:54 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:21:54 --> Controller Class Initialized
DEBUG - 2012-07-24 21:21:54 --> Model Class Initialized
DEBUG - 2012-07-24 21:21:54 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:21:54 --> Final output sent to browser
DEBUG - 2012-07-24 21:21:54 --> Total execution time: 0.1270
DEBUG - 2012-07-24 21:24:24 --> Config Class Initialized
DEBUG - 2012-07-24 21:24:24 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:24:24 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:24:24 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:24:24 --> URI Class Initialized
DEBUG - 2012-07-24 21:24:24 --> Router Class Initialized
DEBUG - 2012-07-24 21:24:24 --> Output Class Initialized
DEBUG - 2012-07-24 21:24:24 --> Security Class Initialized
DEBUG - 2012-07-24 21:24:24 --> Input Class Initialized
DEBUG - 2012-07-24 21:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:24:24 --> Language Class Initialized
DEBUG - 2012-07-24 21:24:24 --> Loader Class Initialized
DEBUG - 2012-07-24 21:24:24 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:24:24 --> Controller Class Initialized
DEBUG - 2012-07-24 21:24:24 --> Model Class Initialized
DEBUG - 2012-07-24 21:24:24 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:24:24 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:24:24 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:24:24 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:24:24 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 21:24:24 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 21:24:24 --> Final output sent to browser
DEBUG - 2012-07-24 21:24:24 --> Total execution time: 0.0385
DEBUG - 2012-07-24 21:26:49 --> Config Class Initialized
DEBUG - 2012-07-24 21:26:49 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:26:49 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:26:49 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:26:49 --> URI Class Initialized
DEBUG - 2012-07-24 21:26:49 --> Router Class Initialized
DEBUG - 2012-07-24 21:26:49 --> Output Class Initialized
DEBUG - 2012-07-24 21:26:49 --> Security Class Initialized
DEBUG - 2012-07-24 21:26:49 --> Input Class Initialized
DEBUG - 2012-07-24 21:26:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:26:49 --> Language Class Initialized
DEBUG - 2012-07-24 21:26:49 --> Loader Class Initialized
DEBUG - 2012-07-24 21:26:49 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:26:49 --> Controller Class Initialized
DEBUG - 2012-07-24 21:26:49 --> Model Class Initialized
DEBUG - 2012-07-24 21:26:49 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:26:49 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:26:49 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:26:49 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:26:49 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 21:26:49 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 21:26:49 --> Final output sent to browser
DEBUG - 2012-07-24 21:26:49 --> Total execution time: 0.0392
DEBUG - 2012-07-24 21:27:10 --> Config Class Initialized
DEBUG - 2012-07-24 21:27:10 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:27:10 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:27:10 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:27:10 --> URI Class Initialized
DEBUG - 2012-07-24 21:27:10 --> Router Class Initialized
DEBUG - 2012-07-24 21:27:10 --> Output Class Initialized
DEBUG - 2012-07-24 21:27:10 --> Security Class Initialized
DEBUG - 2012-07-24 21:27:10 --> Input Class Initialized
DEBUG - 2012-07-24 21:27:10 --> XSS Filtering completed
DEBUG - 2012-07-24 21:27:10 --> XSS Filtering completed
DEBUG - 2012-07-24 21:27:10 --> XSS Filtering completed
DEBUG - 2012-07-24 21:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:27:10 --> Language Class Initialized
DEBUG - 2012-07-24 21:27:10 --> Loader Class Initialized
DEBUG - 2012-07-24 21:27:10 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:27:10 --> Controller Class Initialized
DEBUG - 2012-07-24 21:27:10 --> Model Class Initialized
DEBUG - 2012-07-24 21:27:10 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:27:10 --> Final output sent to browser
DEBUG - 2012-07-24 21:27:10 --> Total execution time: 0.0903
DEBUG - 2012-07-24 21:27:20 --> Config Class Initialized
DEBUG - 2012-07-24 21:27:20 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:27:20 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:27:20 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:27:20 --> URI Class Initialized
DEBUG - 2012-07-24 21:27:20 --> Router Class Initialized
DEBUG - 2012-07-24 21:27:20 --> Output Class Initialized
DEBUG - 2012-07-24 21:27:20 --> Security Class Initialized
DEBUG - 2012-07-24 21:27:20 --> Input Class Initialized
DEBUG - 2012-07-24 21:27:20 --> XSS Filtering completed
DEBUG - 2012-07-24 21:27:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:27:20 --> Language Class Initialized
DEBUG - 2012-07-24 21:27:20 --> Loader Class Initialized
DEBUG - 2012-07-24 21:27:20 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:27:20 --> Controller Class Initialized
DEBUG - 2012-07-24 21:27:20 --> Model Class Initialized
DEBUG - 2012-07-24 21:27:20 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:27:20 --> Final output sent to browser
DEBUG - 2012-07-24 21:27:20 --> Total execution time: 0.0442
DEBUG - 2012-07-24 21:30:26 --> Config Class Initialized
DEBUG - 2012-07-24 21:30:26 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:30:26 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:30:26 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:30:26 --> URI Class Initialized
DEBUG - 2012-07-24 21:30:26 --> Router Class Initialized
DEBUG - 2012-07-24 21:30:26 --> Output Class Initialized
DEBUG - 2012-07-24 21:30:26 --> Security Class Initialized
DEBUG - 2012-07-24 21:30:26 --> Input Class Initialized
DEBUG - 2012-07-24 21:30:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:30:26 --> Language Class Initialized
DEBUG - 2012-07-24 21:30:26 --> Loader Class Initialized
DEBUG - 2012-07-24 21:30:26 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:30:26 --> Controller Class Initialized
DEBUG - 2012-07-24 21:30:26 --> Model Class Initialized
DEBUG - 2012-07-24 21:30:26 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:30:26 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:30:26 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:30:26 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:30:26 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 21:30:26 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 21:30:26 --> Final output sent to browser
DEBUG - 2012-07-24 21:30:26 --> Total execution time: 0.0490
DEBUG - 2012-07-24 21:32:12 --> Config Class Initialized
DEBUG - 2012-07-24 21:32:12 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:32:12 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:32:12 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:32:12 --> URI Class Initialized
DEBUG - 2012-07-24 21:32:12 --> Router Class Initialized
DEBUG - 2012-07-24 21:32:12 --> Output Class Initialized
DEBUG - 2012-07-24 21:32:12 --> Security Class Initialized
DEBUG - 2012-07-24 21:32:12 --> Input Class Initialized
DEBUG - 2012-07-24 21:32:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:32:12 --> Language Class Initialized
DEBUG - 2012-07-24 21:32:12 --> Loader Class Initialized
DEBUG - 2012-07-24 21:32:12 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:32:12 --> Controller Class Initialized
DEBUG - 2012-07-24 21:32:12 --> Model Class Initialized
DEBUG - 2012-07-24 21:32:12 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:32:12 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:32:12 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:32:12 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:32:12 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 21:32:12 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 21:32:12 --> Final output sent to browser
DEBUG - 2012-07-24 21:32:12 --> Total execution time: 0.0392
DEBUG - 2012-07-24 21:32:31 --> Config Class Initialized
DEBUG - 2012-07-24 21:32:31 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:32:31 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:32:31 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:32:31 --> URI Class Initialized
DEBUG - 2012-07-24 21:32:31 --> Router Class Initialized
DEBUG - 2012-07-24 21:32:31 --> Output Class Initialized
DEBUG - 2012-07-24 21:32:31 --> Security Class Initialized
DEBUG - 2012-07-24 21:32:31 --> Input Class Initialized
DEBUG - 2012-07-24 21:32:31 --> XSS Filtering completed
DEBUG - 2012-07-24 21:32:31 --> XSS Filtering completed
DEBUG - 2012-07-24 21:32:31 --> XSS Filtering completed
DEBUG - 2012-07-24 21:32:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:32:31 --> Language Class Initialized
DEBUG - 2012-07-24 21:32:31 --> Loader Class Initialized
DEBUG - 2012-07-24 21:32:31 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:32:31 --> Controller Class Initialized
DEBUG - 2012-07-24 21:32:31 --> Model Class Initialized
DEBUG - 2012-07-24 21:32:31 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:32:31 --> Final output sent to browser
DEBUG - 2012-07-24 21:32:31 --> Total execution time: 0.2939
DEBUG - 2012-07-24 21:32:36 --> Config Class Initialized
DEBUG - 2012-07-24 21:32:36 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:32:36 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:32:36 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:32:36 --> URI Class Initialized
DEBUG - 2012-07-24 21:32:36 --> Router Class Initialized
DEBUG - 2012-07-24 21:32:36 --> Output Class Initialized
DEBUG - 2012-07-24 21:32:36 --> Security Class Initialized
DEBUG - 2012-07-24 21:32:36 --> Input Class Initialized
DEBUG - 2012-07-24 21:33:38 --> Config Class Initialized
DEBUG - 2012-07-24 21:33:38 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:33:38 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:33:38 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:33:38 --> URI Class Initialized
DEBUG - 2012-07-24 21:33:38 --> Router Class Initialized
DEBUG - 2012-07-24 21:33:38 --> Output Class Initialized
DEBUG - 2012-07-24 21:33:38 --> Security Class Initialized
DEBUG - 2012-07-24 21:33:38 --> Input Class Initialized
DEBUG - 2012-07-24 21:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:33:38 --> Language Class Initialized
DEBUG - 2012-07-24 21:33:38 --> Loader Class Initialized
DEBUG - 2012-07-24 21:33:38 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:33:38 --> Controller Class Initialized
DEBUG - 2012-07-24 21:33:38 --> Model Class Initialized
DEBUG - 2012-07-24 21:33:38 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:33:38 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:33:38 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:33:38 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:33:38 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 21:33:38 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 21:33:38 --> Final output sent to browser
DEBUG - 2012-07-24 21:33:38 --> Total execution time: 0.0415
DEBUG - 2012-07-24 21:33:55 --> Config Class Initialized
DEBUG - 2012-07-24 21:33:55 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:33:55 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:33:55 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:33:55 --> URI Class Initialized
DEBUG - 2012-07-24 21:33:55 --> Router Class Initialized
DEBUG - 2012-07-24 21:33:55 --> Output Class Initialized
DEBUG - 2012-07-24 21:33:55 --> Security Class Initialized
DEBUG - 2012-07-24 21:33:55 --> Input Class Initialized
DEBUG - 2012-07-24 21:33:55 --> XSS Filtering completed
DEBUG - 2012-07-24 21:33:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:33:55 --> Language Class Initialized
DEBUG - 2012-07-24 21:33:55 --> Loader Class Initialized
DEBUG - 2012-07-24 21:33:55 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:33:55 --> Controller Class Initialized
DEBUG - 2012-07-24 21:33:55 --> Model Class Initialized
DEBUG - 2012-07-24 21:33:55 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:33:55 --> Final output sent to browser
DEBUG - 2012-07-24 21:33:55 --> Total execution time: 0.1685
DEBUG - 2012-07-24 21:33:59 --> Config Class Initialized
DEBUG - 2012-07-24 21:33:59 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:33:59 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:33:59 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:33:59 --> URI Class Initialized
DEBUG - 2012-07-24 21:33:59 --> Router Class Initialized
DEBUG - 2012-07-24 21:33:59 --> Output Class Initialized
DEBUG - 2012-07-24 21:33:59 --> Security Class Initialized
DEBUG - 2012-07-24 21:33:59 --> Input Class Initialized
DEBUG - 2012-07-24 21:33:59 --> XSS Filtering completed
DEBUG - 2012-07-24 21:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:33:59 --> Language Class Initialized
DEBUG - 2012-07-24 21:33:59 --> Loader Class Initialized
DEBUG - 2012-07-24 21:33:59 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:33:59 --> Controller Class Initialized
DEBUG - 2012-07-24 21:33:59 --> Model Class Initialized
DEBUG - 2012-07-24 21:33:59 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:33:59 --> Final output sent to browser
DEBUG - 2012-07-24 21:33:59 --> Total execution time: 0.1886
DEBUG - 2012-07-24 21:34:02 --> Config Class Initialized
DEBUG - 2012-07-24 21:34:02 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:34:02 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:34:02 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:34:02 --> URI Class Initialized
DEBUG - 2012-07-24 21:34:02 --> Router Class Initialized
DEBUG - 2012-07-24 21:34:02 --> Output Class Initialized
DEBUG - 2012-07-24 21:34:02 --> Security Class Initialized
DEBUG - 2012-07-24 21:34:02 --> Input Class Initialized
DEBUG - 2012-07-24 21:34:02 --> XSS Filtering completed
DEBUG - 2012-07-24 21:34:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:34:02 --> Language Class Initialized
DEBUG - 2012-07-24 21:34:02 --> Loader Class Initialized
DEBUG - 2012-07-24 21:34:02 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:34:02 --> Controller Class Initialized
DEBUG - 2012-07-24 21:34:02 --> Model Class Initialized
DEBUG - 2012-07-24 21:34:02 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:34:02 --> Final output sent to browser
DEBUG - 2012-07-24 21:34:02 --> Total execution time: 0.1370
DEBUG - 2012-07-24 21:34:05 --> Config Class Initialized
DEBUG - 2012-07-24 21:34:06 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:34:06 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:34:06 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:34:06 --> URI Class Initialized
DEBUG - 2012-07-24 21:34:06 --> Router Class Initialized
DEBUG - 2012-07-24 21:34:06 --> Output Class Initialized
DEBUG - 2012-07-24 21:34:06 --> Security Class Initialized
DEBUG - 2012-07-24 21:34:06 --> Input Class Initialized
DEBUG - 2012-07-24 21:34:06 --> XSS Filtering completed
DEBUG - 2012-07-24 21:34:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:34:06 --> Language Class Initialized
DEBUG - 2012-07-24 21:34:06 --> Loader Class Initialized
DEBUG - 2012-07-24 21:34:06 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:34:06 --> Controller Class Initialized
DEBUG - 2012-07-24 21:34:06 --> Model Class Initialized
DEBUG - 2012-07-24 21:34:06 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:34:06 --> Final output sent to browser
DEBUG - 2012-07-24 21:34:06 --> Total execution time: 0.2126
DEBUG - 2012-07-24 21:34:08 --> Config Class Initialized
DEBUG - 2012-07-24 21:34:08 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:34:08 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:34:08 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:34:08 --> URI Class Initialized
DEBUG - 2012-07-24 21:34:08 --> Router Class Initialized
DEBUG - 2012-07-24 21:34:08 --> Output Class Initialized
DEBUG - 2012-07-24 21:34:08 --> Security Class Initialized
DEBUG - 2012-07-24 21:34:08 --> Input Class Initialized
DEBUG - 2012-07-24 21:34:08 --> XSS Filtering completed
DEBUG - 2012-07-24 21:34:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:34:08 --> Language Class Initialized
DEBUG - 2012-07-24 21:34:08 --> Loader Class Initialized
DEBUG - 2012-07-24 21:34:08 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:34:08 --> Controller Class Initialized
DEBUG - 2012-07-24 21:34:08 --> Model Class Initialized
DEBUG - 2012-07-24 21:34:08 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:34:08 --> Final output sent to browser
DEBUG - 2012-07-24 21:34:08 --> Total execution time: 0.1008
DEBUG - 2012-07-24 21:34:10 --> Config Class Initialized
DEBUG - 2012-07-24 21:34:10 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:34:10 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:34:10 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:34:10 --> URI Class Initialized
DEBUG - 2012-07-24 21:34:10 --> Router Class Initialized
DEBUG - 2012-07-24 21:34:10 --> Output Class Initialized
DEBUG - 2012-07-24 21:34:10 --> Security Class Initialized
DEBUG - 2012-07-24 21:34:10 --> Input Class Initialized
DEBUG - 2012-07-24 21:34:10 --> XSS Filtering completed
DEBUG - 2012-07-24 21:34:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:34:10 --> Language Class Initialized
DEBUG - 2012-07-24 21:34:10 --> Loader Class Initialized
DEBUG - 2012-07-24 21:34:10 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:34:10 --> Controller Class Initialized
DEBUG - 2012-07-24 21:34:10 --> Model Class Initialized
DEBUG - 2012-07-24 21:34:10 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:34:10 --> Final output sent to browser
DEBUG - 2012-07-24 21:34:10 --> Total execution time: 0.1638
DEBUG - 2012-07-24 21:34:13 --> Config Class Initialized
DEBUG - 2012-07-24 21:34:13 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:34:13 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:34:13 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:34:13 --> URI Class Initialized
DEBUG - 2012-07-24 21:34:13 --> Router Class Initialized
DEBUG - 2012-07-24 21:34:13 --> Output Class Initialized
DEBUG - 2012-07-24 21:34:13 --> Security Class Initialized
DEBUG - 2012-07-24 21:34:13 --> Input Class Initialized
DEBUG - 2012-07-24 21:34:13 --> XSS Filtering completed
DEBUG - 2012-07-24 21:34:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:34:13 --> Language Class Initialized
DEBUG - 2012-07-24 21:34:13 --> Loader Class Initialized
DEBUG - 2012-07-24 21:34:13 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:34:13 --> Controller Class Initialized
DEBUG - 2012-07-24 21:34:13 --> Model Class Initialized
DEBUG - 2012-07-24 21:34:13 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:34:13 --> Final output sent to browser
DEBUG - 2012-07-24 21:34:13 --> Total execution time: 0.0975
DEBUG - 2012-07-24 21:34:16 --> Config Class Initialized
DEBUG - 2012-07-24 21:34:16 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:34:16 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:34:16 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:34:16 --> URI Class Initialized
DEBUG - 2012-07-24 21:34:16 --> Router Class Initialized
DEBUG - 2012-07-24 21:34:16 --> Output Class Initialized
DEBUG - 2012-07-24 21:34:16 --> Security Class Initialized
DEBUG - 2012-07-24 21:34:16 --> Input Class Initialized
DEBUG - 2012-07-24 21:34:16 --> XSS Filtering completed
DEBUG - 2012-07-24 21:34:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:34:16 --> Language Class Initialized
DEBUG - 2012-07-24 21:34:16 --> Loader Class Initialized
DEBUG - 2012-07-24 21:34:16 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:34:16 --> Controller Class Initialized
DEBUG - 2012-07-24 21:34:16 --> Model Class Initialized
DEBUG - 2012-07-24 21:34:16 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:34:16 --> Final output sent to browser
DEBUG - 2012-07-24 21:34:16 --> Total execution time: 0.2122
DEBUG - 2012-07-24 21:34:29 --> Config Class Initialized
DEBUG - 2012-07-24 21:34:29 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:34:29 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:34:29 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:34:29 --> URI Class Initialized
DEBUG - 2012-07-24 21:34:29 --> Router Class Initialized
DEBUG - 2012-07-24 21:34:29 --> Output Class Initialized
DEBUG - 2012-07-24 21:34:29 --> Security Class Initialized
DEBUG - 2012-07-24 21:34:29 --> Input Class Initialized
DEBUG - 2012-07-24 21:34:29 --> XSS Filtering completed
DEBUG - 2012-07-24 21:34:29 --> XSS Filtering completed
DEBUG - 2012-07-24 21:34:29 --> XSS Filtering completed
DEBUG - 2012-07-24 21:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:34:29 --> Language Class Initialized
DEBUG - 2012-07-24 21:34:29 --> Loader Class Initialized
DEBUG - 2012-07-24 21:34:29 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:34:29 --> Controller Class Initialized
DEBUG - 2012-07-24 21:34:29 --> Model Class Initialized
DEBUG - 2012-07-24 21:34:29 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:34:30 --> Final output sent to browser
DEBUG - 2012-07-24 21:34:30 --> Total execution time: 0.3848
DEBUG - 2012-07-24 21:34:52 --> Config Class Initialized
DEBUG - 2012-07-24 21:34:52 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:34:52 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:34:52 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:34:52 --> URI Class Initialized
DEBUG - 2012-07-24 21:34:52 --> Router Class Initialized
DEBUG - 2012-07-24 21:34:52 --> Output Class Initialized
DEBUG - 2012-07-24 21:34:52 --> Security Class Initialized
DEBUG - 2012-07-24 21:34:52 --> Input Class Initialized
DEBUG - 2012-07-24 21:34:52 --> XSS Filtering completed
DEBUG - 2012-07-24 21:34:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:34:52 --> Language Class Initialized
DEBUG - 2012-07-24 21:34:52 --> Loader Class Initialized
DEBUG - 2012-07-24 21:34:52 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:34:52 --> Controller Class Initialized
DEBUG - 2012-07-24 21:34:52 --> Model Class Initialized
DEBUG - 2012-07-24 21:34:52 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:34:52 --> Final output sent to browser
DEBUG - 2012-07-24 21:34:52 --> Total execution time: 0.1148
DEBUG - 2012-07-24 21:35:03 --> Config Class Initialized
DEBUG - 2012-07-24 21:35:03 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:35:03 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:35:03 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:35:03 --> URI Class Initialized
DEBUG - 2012-07-24 21:35:03 --> Router Class Initialized
DEBUG - 2012-07-24 21:35:03 --> Output Class Initialized
DEBUG - 2012-07-24 21:35:03 --> Security Class Initialized
DEBUG - 2012-07-24 21:35:03 --> Input Class Initialized
DEBUG - 2012-07-24 21:35:03 --> XSS Filtering completed
DEBUG - 2012-07-24 21:35:03 --> XSS Filtering completed
DEBUG - 2012-07-24 21:35:03 --> XSS Filtering completed
DEBUG - 2012-07-24 21:35:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:35:03 --> Language Class Initialized
DEBUG - 2012-07-24 21:35:03 --> Loader Class Initialized
DEBUG - 2012-07-24 21:35:03 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:35:03 --> Controller Class Initialized
DEBUG - 2012-07-24 21:35:03 --> Model Class Initialized
DEBUG - 2012-07-24 21:35:03 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:35:03 --> Final output sent to browser
DEBUG - 2012-07-24 21:35:03 --> Total execution time: 0.1440
DEBUG - 2012-07-24 21:35:08 --> Config Class Initialized
DEBUG - 2012-07-24 21:35:08 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:35:08 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:35:08 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:35:08 --> URI Class Initialized
DEBUG - 2012-07-24 21:35:08 --> Router Class Initialized
DEBUG - 2012-07-24 21:35:08 --> Output Class Initialized
DEBUG - 2012-07-24 21:35:08 --> Security Class Initialized
DEBUG - 2012-07-24 21:35:08 --> Input Class Initialized
DEBUG - 2012-07-24 21:35:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:35:08 --> Language Class Initialized
DEBUG - 2012-07-24 21:35:08 --> Loader Class Initialized
DEBUG - 2012-07-24 21:35:08 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:35:08 --> Controller Class Initialized
DEBUG - 2012-07-24 21:35:08 --> Model Class Initialized
DEBUG - 2012-07-24 21:35:08 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:35:08 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:35:08 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:35:08 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:35:08 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 21:35:08 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 21:35:08 --> Final output sent to browser
DEBUG - 2012-07-24 21:35:08 --> Total execution time: 0.0399
DEBUG - 2012-07-24 21:37:17 --> Config Class Initialized
DEBUG - 2012-07-24 21:37:17 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:37:17 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:37:17 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:37:17 --> URI Class Initialized
DEBUG - 2012-07-24 21:37:17 --> Router Class Initialized
DEBUG - 2012-07-24 21:37:17 --> Output Class Initialized
DEBUG - 2012-07-24 21:37:17 --> Security Class Initialized
DEBUG - 2012-07-24 21:37:17 --> Input Class Initialized
DEBUG - 2012-07-24 21:37:17 --> XSS Filtering completed
DEBUG - 2012-07-24 21:37:17 --> XSS Filtering completed
DEBUG - 2012-07-24 21:37:17 --> XSS Filtering completed
DEBUG - 2012-07-24 21:37:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:37:17 --> Language Class Initialized
DEBUG - 2012-07-24 21:37:18 --> Loader Class Initialized
DEBUG - 2012-07-24 21:37:18 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:37:18 --> Controller Class Initialized
DEBUG - 2012-07-24 21:37:18 --> Model Class Initialized
DEBUG - 2012-07-24 21:37:18 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:37:36 --> Config Class Initialized
DEBUG - 2012-07-24 21:37:36 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:37:36 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:37:36 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:37:36 --> URI Class Initialized
DEBUG - 2012-07-24 21:37:36 --> Router Class Initialized
DEBUG - 2012-07-24 21:37:36 --> Output Class Initialized
DEBUG - 2012-07-24 21:37:36 --> Security Class Initialized
DEBUG - 2012-07-24 21:37:36 --> Input Class Initialized
DEBUG - 2012-07-24 21:37:36 --> XSS Filtering completed
DEBUG - 2012-07-24 21:37:36 --> XSS Filtering completed
DEBUG - 2012-07-24 21:37:36 --> XSS Filtering completed
DEBUG - 2012-07-24 21:37:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:37:36 --> Language Class Initialized
DEBUG - 2012-07-24 21:37:36 --> Loader Class Initialized
DEBUG - 2012-07-24 21:37:36 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:37:36 --> Controller Class Initialized
DEBUG - 2012-07-24 21:37:36 --> Model Class Initialized
DEBUG - 2012-07-24 21:37:36 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:37:36 --> Final output sent to browser
DEBUG - 2012-07-24 21:37:36 --> Total execution time: 0.2557
DEBUG - 2012-07-24 21:38:14 --> Config Class Initialized
DEBUG - 2012-07-24 21:38:14 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:38:14 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:38:14 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:38:14 --> URI Class Initialized
DEBUG - 2012-07-24 21:38:14 --> Router Class Initialized
DEBUG - 2012-07-24 21:38:14 --> Output Class Initialized
DEBUG - 2012-07-24 21:38:14 --> Security Class Initialized
DEBUG - 2012-07-24 21:38:14 --> Input Class Initialized
DEBUG - 2012-07-24 21:38:14 --> XSS Filtering completed
DEBUG - 2012-07-24 21:38:14 --> XSS Filtering completed
DEBUG - 2012-07-24 21:38:14 --> XSS Filtering completed
DEBUG - 2012-07-24 21:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:38:14 --> Language Class Initialized
DEBUG - 2012-07-24 21:38:14 --> Loader Class Initialized
DEBUG - 2012-07-24 21:38:14 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:38:14 --> Controller Class Initialized
DEBUG - 2012-07-24 21:38:14 --> Model Class Initialized
DEBUG - 2012-07-24 21:38:14 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:38:14 --> Final output sent to browser
DEBUG - 2012-07-24 21:38:14 --> Total execution time: 0.0816
DEBUG - 2012-07-24 21:38:46 --> Config Class Initialized
DEBUG - 2012-07-24 21:38:46 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:38:46 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:38:46 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:38:46 --> URI Class Initialized
DEBUG - 2012-07-24 21:38:46 --> Router Class Initialized
DEBUG - 2012-07-24 21:38:46 --> Output Class Initialized
DEBUG - 2012-07-24 21:38:46 --> Security Class Initialized
DEBUG - 2012-07-24 21:38:46 --> Input Class Initialized
DEBUG - 2012-07-24 21:38:46 --> XSS Filtering completed
DEBUG - 2012-07-24 21:38:46 --> XSS Filtering completed
DEBUG - 2012-07-24 21:38:46 --> XSS Filtering completed
DEBUG - 2012-07-24 21:38:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:38:46 --> Language Class Initialized
DEBUG - 2012-07-24 21:38:46 --> Loader Class Initialized
DEBUG - 2012-07-24 21:38:46 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:38:46 --> Controller Class Initialized
DEBUG - 2012-07-24 21:38:46 --> Model Class Initialized
DEBUG - 2012-07-24 21:38:46 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:38:46 --> Final output sent to browser
DEBUG - 2012-07-24 21:38:46 --> Total execution time: 0.0859
DEBUG - 2012-07-24 21:38:58 --> Config Class Initialized
DEBUG - 2012-07-24 21:38:58 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:38:58 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:38:58 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:38:58 --> URI Class Initialized
DEBUG - 2012-07-24 21:38:58 --> Router Class Initialized
DEBUG - 2012-07-24 21:38:58 --> Output Class Initialized
DEBUG - 2012-07-24 21:38:58 --> Security Class Initialized
DEBUG - 2012-07-24 21:38:58 --> Input Class Initialized
DEBUG - 2012-07-24 21:38:58 --> XSS Filtering completed
DEBUG - 2012-07-24 21:38:58 --> XSS Filtering completed
DEBUG - 2012-07-24 21:38:58 --> XSS Filtering completed
DEBUG - 2012-07-24 21:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:38:58 --> Language Class Initialized
DEBUG - 2012-07-24 21:38:58 --> Loader Class Initialized
DEBUG - 2012-07-24 21:38:58 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:38:58 --> Controller Class Initialized
DEBUG - 2012-07-24 21:38:58 --> Model Class Initialized
DEBUG - 2012-07-24 21:38:58 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:38:58 --> Final output sent to browser
DEBUG - 2012-07-24 21:38:58 --> Total execution time: 0.1529
DEBUG - 2012-07-24 21:40:03 --> Config Class Initialized
DEBUG - 2012-07-24 21:40:03 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:40:03 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:40:03 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:40:03 --> URI Class Initialized
DEBUG - 2012-07-24 21:40:03 --> Router Class Initialized
DEBUG - 2012-07-24 21:40:03 --> Output Class Initialized
DEBUG - 2012-07-24 21:40:03 --> Security Class Initialized
DEBUG - 2012-07-24 21:40:03 --> Input Class Initialized
DEBUG - 2012-07-24 21:40:03 --> XSS Filtering completed
DEBUG - 2012-07-24 21:40:03 --> XSS Filtering completed
DEBUG - 2012-07-24 21:40:03 --> XSS Filtering completed
DEBUG - 2012-07-24 21:40:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:40:03 --> Language Class Initialized
DEBUG - 2012-07-24 21:40:03 --> Loader Class Initialized
DEBUG - 2012-07-24 21:40:03 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:40:03 --> Controller Class Initialized
DEBUG - 2012-07-24 21:40:03 --> Model Class Initialized
DEBUG - 2012-07-24 21:40:03 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:40:20 --> Config Class Initialized
DEBUG - 2012-07-24 21:40:20 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:40:20 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:40:20 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:40:20 --> URI Class Initialized
DEBUG - 2012-07-24 21:40:20 --> Router Class Initialized
DEBUG - 2012-07-24 21:40:20 --> Output Class Initialized
DEBUG - 2012-07-24 21:40:20 --> Security Class Initialized
DEBUG - 2012-07-24 21:40:20 --> Input Class Initialized
DEBUG - 2012-07-24 21:40:20 --> XSS Filtering completed
DEBUG - 2012-07-24 21:40:20 --> XSS Filtering completed
DEBUG - 2012-07-24 21:40:20 --> XSS Filtering completed
DEBUG - 2012-07-24 21:40:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:40:20 --> Language Class Initialized
DEBUG - 2012-07-24 21:40:20 --> Loader Class Initialized
DEBUG - 2012-07-24 21:40:20 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:40:20 --> Controller Class Initialized
DEBUG - 2012-07-24 21:40:20 --> Model Class Initialized
DEBUG - 2012-07-24 21:40:20 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:40:20 --> Final output sent to browser
DEBUG - 2012-07-24 21:40:20 --> Total execution time: 0.1084
DEBUG - 2012-07-24 21:40:56 --> Config Class Initialized
DEBUG - 2012-07-24 21:40:56 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:40:56 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:40:56 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:40:56 --> URI Class Initialized
DEBUG - 2012-07-24 21:40:56 --> Router Class Initialized
DEBUG - 2012-07-24 21:40:56 --> Output Class Initialized
DEBUG - 2012-07-24 21:40:56 --> Security Class Initialized
DEBUG - 2012-07-24 21:40:56 --> Input Class Initialized
DEBUG - 2012-07-24 21:40:56 --> XSS Filtering completed
DEBUG - 2012-07-24 21:40:56 --> XSS Filtering completed
DEBUG - 2012-07-24 21:40:56 --> XSS Filtering completed
DEBUG - 2012-07-24 21:40:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:40:56 --> Language Class Initialized
DEBUG - 2012-07-24 21:40:56 --> Loader Class Initialized
DEBUG - 2012-07-24 21:40:56 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:40:56 --> Controller Class Initialized
DEBUG - 2012-07-24 21:40:56 --> Model Class Initialized
DEBUG - 2012-07-24 21:40:56 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:40:56 --> Final output sent to browser
DEBUG - 2012-07-24 21:40:56 --> Total execution time: 0.0884
DEBUG - 2012-07-24 21:41:50 --> Config Class Initialized
DEBUG - 2012-07-24 21:41:50 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:41:50 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:41:50 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:41:50 --> URI Class Initialized
DEBUG - 2012-07-24 21:41:50 --> Router Class Initialized
DEBUG - 2012-07-24 21:41:50 --> Output Class Initialized
DEBUG - 2012-07-24 21:41:50 --> Security Class Initialized
DEBUG - 2012-07-24 21:41:50 --> Input Class Initialized
DEBUG - 2012-07-24 21:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:41:50 --> Language Class Initialized
DEBUG - 2012-07-24 21:41:50 --> Loader Class Initialized
DEBUG - 2012-07-24 21:41:50 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:41:50 --> Controller Class Initialized
DEBUG - 2012-07-24 21:41:50 --> Model Class Initialized
DEBUG - 2012-07-24 21:41:50 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:41:50 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:41:50 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:41:50 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:41:50 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 21:41:50 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 21:41:50 --> Final output sent to browser
DEBUG - 2012-07-24 21:41:50 --> Total execution time: 0.0400
DEBUG - 2012-07-24 21:41:59 --> Config Class Initialized
DEBUG - 2012-07-24 21:41:59 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:41:59 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:41:59 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:41:59 --> URI Class Initialized
DEBUG - 2012-07-24 21:41:59 --> Router Class Initialized
DEBUG - 2012-07-24 21:41:59 --> Output Class Initialized
DEBUG - 2012-07-24 21:41:59 --> Security Class Initialized
DEBUG - 2012-07-24 21:41:59 --> Input Class Initialized
DEBUG - 2012-07-24 21:41:59 --> XSS Filtering completed
DEBUG - 2012-07-24 21:41:59 --> XSS Filtering completed
DEBUG - 2012-07-24 21:41:59 --> XSS Filtering completed
DEBUG - 2012-07-24 21:41:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:41:59 --> Language Class Initialized
DEBUG - 2012-07-24 21:41:59 --> Loader Class Initialized
DEBUG - 2012-07-24 21:41:59 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:41:59 --> Controller Class Initialized
DEBUG - 2012-07-24 21:41:59 --> Model Class Initialized
DEBUG - 2012-07-24 21:41:59 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:41:59 --> Final output sent to browser
DEBUG - 2012-07-24 21:41:59 --> Total execution time: 0.0786
DEBUG - 2012-07-24 21:42:40 --> Config Class Initialized
DEBUG - 2012-07-24 21:42:40 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:42:40 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:42:40 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:42:40 --> URI Class Initialized
DEBUG - 2012-07-24 21:42:40 --> Router Class Initialized
DEBUG - 2012-07-24 21:42:40 --> Output Class Initialized
DEBUG - 2012-07-24 21:42:40 --> Security Class Initialized
DEBUG - 2012-07-24 21:42:40 --> Input Class Initialized
DEBUG - 2012-07-24 21:42:40 --> XSS Filtering completed
DEBUG - 2012-07-24 21:42:40 --> XSS Filtering completed
DEBUG - 2012-07-24 21:42:40 --> XSS Filtering completed
DEBUG - 2012-07-24 21:42:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:42:40 --> Language Class Initialized
DEBUG - 2012-07-24 21:42:40 --> Loader Class Initialized
DEBUG - 2012-07-24 21:42:40 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:42:40 --> Controller Class Initialized
DEBUG - 2012-07-24 21:42:40 --> Model Class Initialized
DEBUG - 2012-07-24 21:42:40 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:42:40 --> Final output sent to browser
DEBUG - 2012-07-24 21:42:40 --> Total execution time: 0.0879
DEBUG - 2012-07-24 21:42:43 --> Config Class Initialized
DEBUG - 2012-07-24 21:42:43 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:42:43 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:42:43 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:42:43 --> URI Class Initialized
DEBUG - 2012-07-24 21:42:43 --> Router Class Initialized
DEBUG - 2012-07-24 21:42:43 --> Output Class Initialized
DEBUG - 2012-07-24 21:42:43 --> Security Class Initialized
DEBUG - 2012-07-24 21:42:43 --> Input Class Initialized
DEBUG - 2012-07-24 21:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:42:43 --> Language Class Initialized
DEBUG - 2012-07-24 21:42:43 --> Loader Class Initialized
DEBUG - 2012-07-24 21:42:43 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:42:43 --> Controller Class Initialized
DEBUG - 2012-07-24 21:42:43 --> Model Class Initialized
DEBUG - 2012-07-24 21:42:43 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:42:43 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:42:43 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:42:43 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:42:43 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 21:42:43 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 21:42:43 --> Final output sent to browser
DEBUG - 2012-07-24 21:42:43 --> Total execution time: 0.0453
DEBUG - 2012-07-24 21:42:55 --> Config Class Initialized
DEBUG - 2012-07-24 21:42:55 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:42:55 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:42:55 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:42:55 --> URI Class Initialized
DEBUG - 2012-07-24 21:42:55 --> Router Class Initialized
DEBUG - 2012-07-24 21:42:55 --> Output Class Initialized
DEBUG - 2012-07-24 21:42:55 --> Security Class Initialized
DEBUG - 2012-07-24 21:42:55 --> Input Class Initialized
DEBUG - 2012-07-24 21:42:55 --> XSS Filtering completed
DEBUG - 2012-07-24 21:42:55 --> XSS Filtering completed
DEBUG - 2012-07-24 21:42:55 --> XSS Filtering completed
DEBUG - 2012-07-24 21:42:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:42:55 --> Language Class Initialized
DEBUG - 2012-07-24 21:42:55 --> Loader Class Initialized
DEBUG - 2012-07-24 21:42:55 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:42:55 --> Controller Class Initialized
DEBUG - 2012-07-24 21:42:55 --> Model Class Initialized
DEBUG - 2012-07-24 21:42:55 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:42:55 --> Final output sent to browser
DEBUG - 2012-07-24 21:42:55 --> Total execution time: 0.1498
DEBUG - 2012-07-24 21:45:04 --> Config Class Initialized
DEBUG - 2012-07-24 21:45:04 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:45:04 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:45:04 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:45:04 --> URI Class Initialized
DEBUG - 2012-07-24 21:45:04 --> Router Class Initialized
DEBUG - 2012-07-24 21:45:04 --> Output Class Initialized
DEBUG - 2012-07-24 21:45:04 --> Security Class Initialized
DEBUG - 2012-07-24 21:45:04 --> Input Class Initialized
DEBUG - 2012-07-24 21:45:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:45:04 --> Language Class Initialized
DEBUG - 2012-07-24 21:45:04 --> Loader Class Initialized
DEBUG - 2012-07-24 21:45:04 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:45:04 --> Controller Class Initialized
DEBUG - 2012-07-24 21:45:04 --> Model Class Initialized
DEBUG - 2012-07-24 21:45:04 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:45:04 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:45:04 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:45:04 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:45:04 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 21:45:04 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 21:45:04 --> Final output sent to browser
DEBUG - 2012-07-24 21:45:04 --> Total execution time: 0.0388
DEBUG - 2012-07-24 21:45:13 --> Config Class Initialized
DEBUG - 2012-07-24 21:45:13 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:45:13 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:45:13 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:45:13 --> URI Class Initialized
DEBUG - 2012-07-24 21:45:13 --> Router Class Initialized
DEBUG - 2012-07-24 21:45:13 --> Output Class Initialized
DEBUG - 2012-07-24 21:45:13 --> Security Class Initialized
DEBUG - 2012-07-24 21:45:13 --> Input Class Initialized
DEBUG - 2012-07-24 21:45:13 --> XSS Filtering completed
DEBUG - 2012-07-24 21:45:13 --> XSS Filtering completed
DEBUG - 2012-07-24 21:45:13 --> XSS Filtering completed
DEBUG - 2012-07-24 21:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:45:13 --> Language Class Initialized
DEBUG - 2012-07-24 21:45:13 --> Loader Class Initialized
DEBUG - 2012-07-24 21:45:13 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:45:13 --> Controller Class Initialized
DEBUG - 2012-07-24 21:45:13 --> Model Class Initialized
DEBUG - 2012-07-24 21:45:13 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:45:13 --> Final output sent to browser
DEBUG - 2012-07-24 21:45:13 --> Total execution time: 0.1190
DEBUG - 2012-07-24 21:46:04 --> Config Class Initialized
DEBUG - 2012-07-24 21:46:04 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:46:04 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:46:04 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:46:04 --> URI Class Initialized
DEBUG - 2012-07-24 21:46:04 --> Router Class Initialized
DEBUG - 2012-07-24 21:46:04 --> Output Class Initialized
DEBUG - 2012-07-24 21:46:04 --> Security Class Initialized
DEBUG - 2012-07-24 21:46:04 --> Input Class Initialized
DEBUG - 2012-07-24 21:46:04 --> XSS Filtering completed
DEBUG - 2012-07-24 21:46:04 --> XSS Filtering completed
DEBUG - 2012-07-24 21:46:04 --> XSS Filtering completed
DEBUG - 2012-07-24 21:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:46:04 --> Language Class Initialized
DEBUG - 2012-07-24 21:46:04 --> Loader Class Initialized
DEBUG - 2012-07-24 21:46:04 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:46:04 --> Controller Class Initialized
DEBUG - 2012-07-24 21:46:04 --> Model Class Initialized
DEBUG - 2012-07-24 21:46:04 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:46:04 --> Final output sent to browser
DEBUG - 2012-07-24 21:46:04 --> Total execution time: 0.1070
DEBUG - 2012-07-24 21:46:57 --> Config Class Initialized
DEBUG - 2012-07-24 21:46:57 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:46:57 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:46:57 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:46:57 --> URI Class Initialized
DEBUG - 2012-07-24 21:46:57 --> Router Class Initialized
DEBUG - 2012-07-24 21:46:57 --> Output Class Initialized
DEBUG - 2012-07-24 21:46:57 --> Security Class Initialized
DEBUG - 2012-07-24 21:46:57 --> Input Class Initialized
DEBUG - 2012-07-24 21:46:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:46:57 --> Language Class Initialized
DEBUG - 2012-07-24 21:46:57 --> Loader Class Initialized
DEBUG - 2012-07-24 21:46:57 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:46:57 --> Controller Class Initialized
DEBUG - 2012-07-24 21:46:57 --> Model Class Initialized
DEBUG - 2012-07-24 21:46:57 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:46:57 --> Final output sent to browser
DEBUG - 2012-07-24 21:46:57 --> Total execution time: 0.1329
DEBUG - 2012-07-24 21:47:46 --> Config Class Initialized
DEBUG - 2012-07-24 21:47:46 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:47:46 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:47:46 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:47:46 --> URI Class Initialized
DEBUG - 2012-07-24 21:47:46 --> Router Class Initialized
DEBUG - 2012-07-24 21:47:46 --> Output Class Initialized
DEBUG - 2012-07-24 21:47:46 --> Security Class Initialized
DEBUG - 2012-07-24 21:47:46 --> Input Class Initialized
DEBUG - 2012-07-24 21:47:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:47:46 --> Language Class Initialized
DEBUG - 2012-07-24 21:47:46 --> Loader Class Initialized
DEBUG - 2012-07-24 21:47:46 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:47:46 --> Controller Class Initialized
DEBUG - 2012-07-24 21:47:46 --> Model Class Initialized
DEBUG - 2012-07-24 21:47:46 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:47:46 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:47:46 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:47:46 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:47:46 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 21:47:46 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 21:47:46 --> Final output sent to browser
DEBUG - 2012-07-24 21:47:46 --> Total execution time: 0.0519
DEBUG - 2012-07-24 21:48:00 --> Config Class Initialized
DEBUG - 2012-07-24 21:48:00 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:48:00 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:48:00 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:48:00 --> URI Class Initialized
DEBUG - 2012-07-24 21:48:00 --> Router Class Initialized
DEBUG - 2012-07-24 21:48:00 --> Output Class Initialized
DEBUG - 2012-07-24 21:48:00 --> Security Class Initialized
DEBUG - 2012-07-24 21:48:00 --> Input Class Initialized
DEBUG - 2012-07-24 21:48:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:48:00 --> Language Class Initialized
DEBUG - 2012-07-24 21:48:00 --> Loader Class Initialized
DEBUG - 2012-07-24 21:48:00 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:48:00 --> Controller Class Initialized
DEBUG - 2012-07-24 21:48:00 --> Model Class Initialized
DEBUG - 2012-07-24 21:48:00 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:48:00 --> Final output sent to browser
DEBUG - 2012-07-24 21:48:00 --> Total execution time: 0.1651
DEBUG - 2012-07-24 21:48:33 --> Config Class Initialized
DEBUG - 2012-07-24 21:48:33 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:48:33 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:48:33 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:48:33 --> URI Class Initialized
DEBUG - 2012-07-24 21:48:33 --> Router Class Initialized
DEBUG - 2012-07-24 21:48:33 --> Output Class Initialized
DEBUG - 2012-07-24 21:48:33 --> Security Class Initialized
DEBUG - 2012-07-24 21:48:33 --> Input Class Initialized
DEBUG - 2012-07-24 21:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:48:33 --> Language Class Initialized
DEBUG - 2012-07-24 21:48:33 --> Loader Class Initialized
DEBUG - 2012-07-24 21:48:33 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:48:33 --> Controller Class Initialized
DEBUG - 2012-07-24 21:48:33 --> Model Class Initialized
DEBUG - 2012-07-24 21:48:33 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:48:33 --> Final output sent to browser
DEBUG - 2012-07-24 21:48:33 --> Total execution time: 0.1384
DEBUG - 2012-07-24 21:49:35 --> Config Class Initialized
DEBUG - 2012-07-24 21:49:35 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:49:35 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:49:35 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:49:35 --> URI Class Initialized
DEBUG - 2012-07-24 21:49:35 --> Router Class Initialized
DEBUG - 2012-07-24 21:49:35 --> Output Class Initialized
DEBUG - 2012-07-24 21:49:35 --> Security Class Initialized
DEBUG - 2012-07-24 21:49:35 --> Input Class Initialized
DEBUG - 2012-07-24 21:49:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:49:35 --> Language Class Initialized
DEBUG - 2012-07-24 21:49:35 --> Loader Class Initialized
DEBUG - 2012-07-24 21:49:35 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:49:35 --> Controller Class Initialized
DEBUG - 2012-07-24 21:49:35 --> Model Class Initialized
DEBUG - 2012-07-24 21:49:35 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:49:35 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:49:35 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:49:35 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:49:35 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 21:49:35 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 21:49:36 --> Final output sent to browser
DEBUG - 2012-07-24 21:49:36 --> Total execution time: 0.0388
DEBUG - 2012-07-24 21:49:46 --> Config Class Initialized
DEBUG - 2012-07-24 21:49:46 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:49:46 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:49:46 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:49:46 --> URI Class Initialized
DEBUG - 2012-07-24 21:49:46 --> Router Class Initialized
DEBUG - 2012-07-24 21:49:46 --> Output Class Initialized
DEBUG - 2012-07-24 21:49:46 --> Security Class Initialized
DEBUG - 2012-07-24 21:49:46 --> Input Class Initialized
DEBUG - 2012-07-24 21:49:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:49:46 --> Language Class Initialized
DEBUG - 2012-07-24 21:49:46 --> Loader Class Initialized
DEBUG - 2012-07-24 21:49:46 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:49:46 --> Controller Class Initialized
DEBUG - 2012-07-24 21:49:46 --> Model Class Initialized
DEBUG - 2012-07-24 21:49:46 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:49:46 --> Final output sent to browser
DEBUG - 2012-07-24 21:49:46 --> Total execution time: 0.1159
DEBUG - 2012-07-24 21:52:19 --> Config Class Initialized
DEBUG - 2012-07-24 21:52:19 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:52:19 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:52:19 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:52:19 --> URI Class Initialized
DEBUG - 2012-07-24 21:52:19 --> Router Class Initialized
DEBUG - 2012-07-24 21:52:19 --> Output Class Initialized
DEBUG - 2012-07-24 21:52:19 --> Security Class Initialized
DEBUG - 2012-07-24 21:52:19 --> Input Class Initialized
DEBUG - 2012-07-24 21:52:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:52:19 --> Language Class Initialized
DEBUG - 2012-07-24 21:52:19 --> Loader Class Initialized
DEBUG - 2012-07-24 21:52:19 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:52:19 --> Controller Class Initialized
DEBUG - 2012-07-24 21:52:19 --> Model Class Initialized
DEBUG - 2012-07-24 21:52:19 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:52:19 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:52:19 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:52:19 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:52:19 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 21:52:19 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 21:52:20 --> Final output sent to browser
DEBUG - 2012-07-24 21:52:20 --> Total execution time: 0.0386
DEBUG - 2012-07-24 21:52:40 --> Config Class Initialized
DEBUG - 2012-07-24 21:52:40 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:52:40 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:52:40 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:52:40 --> URI Class Initialized
DEBUG - 2012-07-24 21:52:40 --> Router Class Initialized
DEBUG - 2012-07-24 21:52:40 --> Output Class Initialized
DEBUG - 2012-07-24 21:52:40 --> Security Class Initialized
DEBUG - 2012-07-24 21:52:40 --> Input Class Initialized
DEBUG - 2012-07-24 21:52:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:52:40 --> Language Class Initialized
DEBUG - 2012-07-24 21:52:40 --> Loader Class Initialized
DEBUG - 2012-07-24 21:52:40 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:52:40 --> Controller Class Initialized
DEBUG - 2012-07-24 21:52:40 --> Model Class Initialized
DEBUG - 2012-07-24 21:52:40 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:52:40 --> Final output sent to browser
DEBUG - 2012-07-24 21:52:40 --> Total execution time: 0.0820
DEBUG - 2012-07-24 21:53:53 --> Config Class Initialized
DEBUG - 2012-07-24 21:53:53 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:53:53 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:53:53 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:53:53 --> URI Class Initialized
DEBUG - 2012-07-24 21:53:53 --> Router Class Initialized
DEBUG - 2012-07-24 21:53:53 --> Output Class Initialized
DEBUG - 2012-07-24 21:53:53 --> Security Class Initialized
DEBUG - 2012-07-24 21:53:53 --> Input Class Initialized
DEBUG - 2012-07-24 21:53:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:53:53 --> Language Class Initialized
DEBUG - 2012-07-24 21:53:53 --> Loader Class Initialized
DEBUG - 2012-07-24 21:53:53 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:53:53 --> Controller Class Initialized
DEBUG - 2012-07-24 21:53:53 --> Model Class Initialized
DEBUG - 2012-07-24 21:53:53 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:53:53 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:53:53 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:53:53 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:53:53 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 21:53:53 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 21:53:53 --> Final output sent to browser
DEBUG - 2012-07-24 21:53:53 --> Total execution time: 0.0486
DEBUG - 2012-07-24 21:53:59 --> Config Class Initialized
DEBUG - 2012-07-24 21:53:59 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:53:59 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:53:59 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:53:59 --> URI Class Initialized
DEBUG - 2012-07-24 21:53:59 --> Router Class Initialized
DEBUG - 2012-07-24 21:53:59 --> Output Class Initialized
DEBUG - 2012-07-24 21:53:59 --> Security Class Initialized
DEBUG - 2012-07-24 21:53:59 --> Input Class Initialized
DEBUG - 2012-07-24 21:53:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:53:59 --> Language Class Initialized
DEBUG - 2012-07-24 21:53:59 --> Loader Class Initialized
DEBUG - 2012-07-24 21:53:59 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:53:59 --> Controller Class Initialized
DEBUG - 2012-07-24 21:53:59 --> Model Class Initialized
DEBUG - 2012-07-24 21:53:59 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:53:59 --> Final output sent to browser
DEBUG - 2012-07-24 21:53:59 --> Total execution time: 0.1863
DEBUG - 2012-07-24 21:54:01 --> Config Class Initialized
DEBUG - 2012-07-24 21:54:01 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:54:01 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:54:01 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:54:01 --> URI Class Initialized
DEBUG - 2012-07-24 21:54:01 --> Router Class Initialized
DEBUG - 2012-07-24 21:54:01 --> Output Class Initialized
DEBUG - 2012-07-24 21:54:01 --> Security Class Initialized
DEBUG - 2012-07-24 21:54:01 --> Input Class Initialized
DEBUG - 2012-07-24 21:54:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:54:01 --> Language Class Initialized
DEBUG - 2012-07-24 21:54:01 --> Loader Class Initialized
DEBUG - 2012-07-24 21:54:01 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:54:01 --> Controller Class Initialized
DEBUG - 2012-07-24 21:54:01 --> Model Class Initialized
DEBUG - 2012-07-24 21:54:01 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:54:01 --> Final output sent to browser
DEBUG - 2012-07-24 21:54:01 --> Total execution time: 0.1088
DEBUG - 2012-07-24 21:54:03 --> Config Class Initialized
DEBUG - 2012-07-24 21:54:03 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:54:03 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:54:03 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:54:03 --> URI Class Initialized
DEBUG - 2012-07-24 21:54:03 --> Router Class Initialized
DEBUG - 2012-07-24 21:54:03 --> Output Class Initialized
DEBUG - 2012-07-24 21:54:03 --> Security Class Initialized
DEBUG - 2012-07-24 21:54:03 --> Input Class Initialized
DEBUG - 2012-07-24 21:54:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:54:03 --> Language Class Initialized
DEBUG - 2012-07-24 21:54:03 --> Loader Class Initialized
DEBUG - 2012-07-24 21:54:03 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:54:03 --> Controller Class Initialized
DEBUG - 2012-07-24 21:54:03 --> Model Class Initialized
DEBUG - 2012-07-24 21:54:03 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:54:03 --> Final output sent to browser
DEBUG - 2012-07-24 21:54:03 --> Total execution time: 0.0327
DEBUG - 2012-07-24 21:54:07 --> Config Class Initialized
DEBUG - 2012-07-24 21:54:07 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:54:07 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:54:07 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:54:07 --> URI Class Initialized
DEBUG - 2012-07-24 21:54:07 --> Router Class Initialized
DEBUG - 2012-07-24 21:54:07 --> Output Class Initialized
DEBUG - 2012-07-24 21:54:07 --> Security Class Initialized
DEBUG - 2012-07-24 21:54:07 --> Input Class Initialized
DEBUG - 2012-07-24 21:54:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:54:07 --> Language Class Initialized
DEBUG - 2012-07-24 21:54:07 --> Loader Class Initialized
DEBUG - 2012-07-24 21:54:07 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:54:07 --> Controller Class Initialized
DEBUG - 2012-07-24 21:54:07 --> Model Class Initialized
DEBUG - 2012-07-24 21:54:07 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:54:07 --> Final output sent to browser
DEBUG - 2012-07-24 21:54:07 --> Total execution time: 0.1381
DEBUG - 2012-07-24 21:54:10 --> Config Class Initialized
DEBUG - 2012-07-24 21:54:10 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:54:10 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:54:10 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:54:10 --> URI Class Initialized
DEBUG - 2012-07-24 21:54:10 --> Router Class Initialized
DEBUG - 2012-07-24 21:54:10 --> Output Class Initialized
DEBUG - 2012-07-24 21:54:10 --> Security Class Initialized
DEBUG - 2012-07-24 21:54:10 --> Input Class Initialized
DEBUG - 2012-07-24 21:54:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:54:10 --> Language Class Initialized
DEBUG - 2012-07-24 21:54:10 --> Loader Class Initialized
DEBUG - 2012-07-24 21:54:10 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:54:10 --> Controller Class Initialized
DEBUG - 2012-07-24 21:54:10 --> Model Class Initialized
DEBUG - 2012-07-24 21:54:10 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:54:10 --> Final output sent to browser
DEBUG - 2012-07-24 21:54:10 --> Total execution time: 0.1770
DEBUG - 2012-07-24 21:54:13 --> Config Class Initialized
DEBUG - 2012-07-24 21:54:13 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:54:13 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:54:13 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:54:13 --> URI Class Initialized
DEBUG - 2012-07-24 21:54:13 --> Router Class Initialized
DEBUG - 2012-07-24 21:54:13 --> Output Class Initialized
DEBUG - 2012-07-24 21:54:13 --> Security Class Initialized
DEBUG - 2012-07-24 21:54:13 --> Input Class Initialized
DEBUG - 2012-07-24 21:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:54:13 --> Language Class Initialized
DEBUG - 2012-07-24 21:54:13 --> Loader Class Initialized
DEBUG - 2012-07-24 21:54:13 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:54:13 --> Controller Class Initialized
DEBUG - 2012-07-24 21:54:13 --> Model Class Initialized
DEBUG - 2012-07-24 21:54:13 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:54:13 --> Final output sent to browser
DEBUG - 2012-07-24 21:54:13 --> Total execution time: 0.3297
DEBUG - 2012-07-24 21:54:16 --> Config Class Initialized
DEBUG - 2012-07-24 21:54:16 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:54:16 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:54:16 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:54:16 --> URI Class Initialized
DEBUG - 2012-07-24 21:54:16 --> Router Class Initialized
DEBUG - 2012-07-24 21:54:16 --> Output Class Initialized
DEBUG - 2012-07-24 21:54:16 --> Security Class Initialized
DEBUG - 2012-07-24 21:54:16 --> Input Class Initialized
DEBUG - 2012-07-24 21:54:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:54:16 --> Language Class Initialized
DEBUG - 2012-07-24 21:54:16 --> Loader Class Initialized
DEBUG - 2012-07-24 21:54:16 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:54:16 --> Controller Class Initialized
DEBUG - 2012-07-24 21:54:16 --> Model Class Initialized
DEBUG - 2012-07-24 21:54:16 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:54:16 --> Final output sent to browser
DEBUG - 2012-07-24 21:54:16 --> Total execution time: 0.1592
DEBUG - 2012-07-24 21:54:18 --> Config Class Initialized
DEBUG - 2012-07-24 21:54:18 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:54:18 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:54:18 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:54:18 --> URI Class Initialized
DEBUG - 2012-07-24 21:54:18 --> Router Class Initialized
DEBUG - 2012-07-24 21:54:18 --> Output Class Initialized
DEBUG - 2012-07-24 21:54:18 --> Security Class Initialized
DEBUG - 2012-07-24 21:54:18 --> Input Class Initialized
DEBUG - 2012-07-24 21:54:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:54:18 --> Language Class Initialized
DEBUG - 2012-07-24 21:54:18 --> Loader Class Initialized
DEBUG - 2012-07-24 21:54:18 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:54:18 --> Controller Class Initialized
DEBUG - 2012-07-24 21:54:18 --> Model Class Initialized
DEBUG - 2012-07-24 21:54:18 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:54:18 --> Final output sent to browser
DEBUG - 2012-07-24 21:54:18 --> Total execution time: 0.0438
DEBUG - 2012-07-24 21:54:20 --> Config Class Initialized
DEBUG - 2012-07-24 21:54:20 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:54:20 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:54:20 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:54:20 --> URI Class Initialized
DEBUG - 2012-07-24 21:54:20 --> Router Class Initialized
DEBUG - 2012-07-24 21:54:20 --> Output Class Initialized
DEBUG - 2012-07-24 21:54:20 --> Security Class Initialized
DEBUG - 2012-07-24 21:54:20 --> Input Class Initialized
DEBUG - 2012-07-24 21:54:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:54:20 --> Language Class Initialized
DEBUG - 2012-07-24 21:54:20 --> Loader Class Initialized
DEBUG - 2012-07-24 21:54:20 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:54:20 --> Controller Class Initialized
DEBUG - 2012-07-24 21:54:20 --> Model Class Initialized
DEBUG - 2012-07-24 21:54:20 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:54:21 --> Final output sent to browser
DEBUG - 2012-07-24 21:54:21 --> Total execution time: 0.6837
DEBUG - 2012-07-24 21:54:23 --> Config Class Initialized
DEBUG - 2012-07-24 21:54:23 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:54:23 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:54:23 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:54:23 --> URI Class Initialized
DEBUG - 2012-07-24 21:54:23 --> Router Class Initialized
DEBUG - 2012-07-24 21:54:23 --> Output Class Initialized
DEBUG - 2012-07-24 21:54:23 --> Security Class Initialized
DEBUG - 2012-07-24 21:54:23 --> Input Class Initialized
DEBUG - 2012-07-24 21:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:54:23 --> Language Class Initialized
DEBUG - 2012-07-24 21:54:23 --> Loader Class Initialized
DEBUG - 2012-07-24 21:54:23 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:54:23 --> Controller Class Initialized
DEBUG - 2012-07-24 21:54:23 --> Model Class Initialized
DEBUG - 2012-07-24 21:54:23 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:54:23 --> Final output sent to browser
DEBUG - 2012-07-24 21:54:23 --> Total execution time: 0.1768
DEBUG - 2012-07-24 21:54:26 --> Config Class Initialized
DEBUG - 2012-07-24 21:54:26 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:54:26 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:54:26 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:54:26 --> URI Class Initialized
DEBUG - 2012-07-24 21:54:26 --> Router Class Initialized
DEBUG - 2012-07-24 21:54:26 --> Output Class Initialized
DEBUG - 2012-07-24 21:54:26 --> Security Class Initialized
DEBUG - 2012-07-24 21:54:26 --> Input Class Initialized
DEBUG - 2012-07-24 21:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:54:26 --> Language Class Initialized
DEBUG - 2012-07-24 21:54:26 --> Loader Class Initialized
DEBUG - 2012-07-24 21:54:26 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:54:26 --> Controller Class Initialized
DEBUG - 2012-07-24 21:54:26 --> Model Class Initialized
DEBUG - 2012-07-24 21:54:26 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:54:26 --> Final output sent to browser
DEBUG - 2012-07-24 21:54:26 --> Total execution time: 0.1637
DEBUG - 2012-07-24 21:54:28 --> Config Class Initialized
DEBUG - 2012-07-24 21:54:28 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:54:28 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:54:28 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:54:28 --> URI Class Initialized
DEBUG - 2012-07-24 21:54:28 --> Router Class Initialized
DEBUG - 2012-07-24 21:54:28 --> Output Class Initialized
DEBUG - 2012-07-24 21:54:28 --> Security Class Initialized
DEBUG - 2012-07-24 21:54:28 --> Input Class Initialized
DEBUG - 2012-07-24 21:54:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:54:28 --> Language Class Initialized
DEBUG - 2012-07-24 21:54:28 --> Loader Class Initialized
DEBUG - 2012-07-24 21:54:28 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:54:28 --> Controller Class Initialized
DEBUG - 2012-07-24 21:54:28 --> Model Class Initialized
DEBUG - 2012-07-24 21:54:28 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:54:28 --> Final output sent to browser
DEBUG - 2012-07-24 21:54:28 --> Total execution time: 0.1079
DEBUG - 2012-07-24 21:54:30 --> Config Class Initialized
DEBUG - 2012-07-24 21:54:30 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:54:30 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:54:30 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:54:30 --> URI Class Initialized
DEBUG - 2012-07-24 21:54:30 --> Router Class Initialized
DEBUG - 2012-07-24 21:54:30 --> Output Class Initialized
DEBUG - 2012-07-24 21:54:30 --> Security Class Initialized
DEBUG - 2012-07-24 21:54:30 --> Input Class Initialized
DEBUG - 2012-07-24 21:54:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:54:30 --> Language Class Initialized
DEBUG - 2012-07-24 21:54:30 --> Loader Class Initialized
DEBUG - 2012-07-24 21:54:30 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:54:30 --> Controller Class Initialized
DEBUG - 2012-07-24 21:54:30 --> Model Class Initialized
DEBUG - 2012-07-24 21:54:30 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:54:30 --> Final output sent to browser
DEBUG - 2012-07-24 21:54:30 --> Total execution time: 0.1597
DEBUG - 2012-07-24 21:54:32 --> Config Class Initialized
DEBUG - 2012-07-24 21:54:32 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:54:32 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:54:32 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:54:32 --> URI Class Initialized
DEBUG - 2012-07-24 21:54:32 --> Router Class Initialized
DEBUG - 2012-07-24 21:54:32 --> Output Class Initialized
DEBUG - 2012-07-24 21:54:32 --> Security Class Initialized
DEBUG - 2012-07-24 21:54:32 --> Input Class Initialized
DEBUG - 2012-07-24 21:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:54:32 --> Language Class Initialized
DEBUG - 2012-07-24 21:54:32 --> Loader Class Initialized
DEBUG - 2012-07-24 21:54:32 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:54:32 --> Controller Class Initialized
DEBUG - 2012-07-24 21:54:32 --> Model Class Initialized
DEBUG - 2012-07-24 21:54:32 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:54:32 --> Final output sent to browser
DEBUG - 2012-07-24 21:54:32 --> Total execution time: 0.1298
DEBUG - 2012-07-24 21:54:35 --> Config Class Initialized
DEBUG - 2012-07-24 21:54:35 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:54:35 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:54:35 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:54:35 --> URI Class Initialized
DEBUG - 2012-07-24 21:54:35 --> Router Class Initialized
DEBUG - 2012-07-24 21:54:35 --> Output Class Initialized
DEBUG - 2012-07-24 21:54:35 --> Security Class Initialized
DEBUG - 2012-07-24 21:54:35 --> Input Class Initialized
DEBUG - 2012-07-24 21:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:54:35 --> Language Class Initialized
DEBUG - 2012-07-24 21:54:35 --> Loader Class Initialized
DEBUG - 2012-07-24 21:54:35 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:54:35 --> Controller Class Initialized
DEBUG - 2012-07-24 21:54:35 --> Model Class Initialized
DEBUG - 2012-07-24 21:54:35 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:54:35 --> Final output sent to browser
DEBUG - 2012-07-24 21:54:35 --> Total execution time: 0.1449
DEBUG - 2012-07-24 21:54:57 --> Config Class Initialized
DEBUG - 2012-07-24 21:54:57 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:54:57 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:54:57 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:54:57 --> URI Class Initialized
DEBUG - 2012-07-24 21:54:57 --> Router Class Initialized
DEBUG - 2012-07-24 21:54:57 --> Output Class Initialized
DEBUG - 2012-07-24 21:54:57 --> Security Class Initialized
DEBUG - 2012-07-24 21:54:57 --> Input Class Initialized
DEBUG - 2012-07-24 21:54:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:54:57 --> Language Class Initialized
DEBUG - 2012-07-24 21:54:57 --> Loader Class Initialized
DEBUG - 2012-07-24 21:54:57 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:54:57 --> Controller Class Initialized
DEBUG - 2012-07-24 21:54:57 --> Model Class Initialized
DEBUG - 2012-07-24 21:54:57 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:54:57 --> Final output sent to browser
DEBUG - 2012-07-24 21:54:57 --> Total execution time: 0.1253
DEBUG - 2012-07-24 21:55:04 --> Config Class Initialized
DEBUG - 2012-07-24 21:55:04 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:55:04 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:55:04 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:55:04 --> URI Class Initialized
DEBUG - 2012-07-24 21:55:04 --> Router Class Initialized
DEBUG - 2012-07-24 21:55:04 --> Output Class Initialized
DEBUG - 2012-07-24 21:55:04 --> Security Class Initialized
DEBUG - 2012-07-24 21:55:04 --> Input Class Initialized
DEBUG - 2012-07-24 21:55:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:55:04 --> Language Class Initialized
DEBUG - 2012-07-24 21:55:04 --> Loader Class Initialized
DEBUG - 2012-07-24 21:55:04 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:55:04 --> Controller Class Initialized
DEBUG - 2012-07-24 21:55:04 --> Model Class Initialized
DEBUG - 2012-07-24 21:55:04 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:55:04 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:55:04 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:55:04 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:55:04 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 21:55:04 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 21:55:04 --> Final output sent to browser
DEBUG - 2012-07-24 21:55:04 --> Total execution time: 0.0384
DEBUG - 2012-07-24 21:58:21 --> Config Class Initialized
DEBUG - 2012-07-24 21:58:21 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:58:21 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:58:21 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:58:21 --> URI Class Initialized
DEBUG - 2012-07-24 21:58:22 --> Router Class Initialized
DEBUG - 2012-07-24 21:58:22 --> Output Class Initialized
DEBUG - 2012-07-24 21:58:22 --> Security Class Initialized
DEBUG - 2012-07-24 21:58:22 --> Input Class Initialized
DEBUG - 2012-07-24 21:58:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:58:22 --> Language Class Initialized
DEBUG - 2012-07-24 21:58:22 --> Loader Class Initialized
DEBUG - 2012-07-24 21:58:22 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:58:22 --> Controller Class Initialized
DEBUG - 2012-07-24 21:58:22 --> Model Class Initialized
DEBUG - 2012-07-24 21:58:22 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:58:22 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:58:22 --> Helper loaded: html_helper
DEBUG - 2012-07-24 21:58:22 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-07-24 21:58:22 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-07-24 21:58:22 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-24 21:58:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-07-24 21:58:22 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 64
ERROR - 2012-07-24 21:58:22 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-07-24 21:58:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-07-24 21:58:22 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-07-24 21:58:22 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-07-24 21:58:22 --> Final output sent to browser
DEBUG - 2012-07-24 21:58:22 --> Total execution time: 0.0411
DEBUG - 2012-07-24 21:58:34 --> Config Class Initialized
DEBUG - 2012-07-24 21:58:34 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:58:34 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:58:34 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:58:34 --> URI Class Initialized
DEBUG - 2012-07-24 21:58:34 --> Router Class Initialized
DEBUG - 2012-07-24 21:58:34 --> Output Class Initialized
DEBUG - 2012-07-24 21:58:34 --> Security Class Initialized
DEBUG - 2012-07-24 21:58:34 --> Input Class Initialized
DEBUG - 2012-07-24 21:58:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:58:34 --> Language Class Initialized
DEBUG - 2012-07-24 21:58:34 --> Loader Class Initialized
DEBUG - 2012-07-24 21:58:34 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:58:34 --> Controller Class Initialized
DEBUG - 2012-07-24 21:58:34 --> Model Class Initialized
DEBUG - 2012-07-24 21:58:34 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:58:34 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:58:34 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:58:34 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:58:34 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 21:58:34 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 21:58:34 --> Final output sent to browser
DEBUG - 2012-07-24 21:58:34 --> Total execution time: 0.0399
DEBUG - 2012-07-24 21:58:46 --> Config Class Initialized
DEBUG - 2012-07-24 21:58:46 --> Hooks Class Initialized
DEBUG - 2012-07-24 21:58:46 --> Utf8 Class Initialized
DEBUG - 2012-07-24 21:58:46 --> UTF-8 Support Disabled
DEBUG - 2012-07-24 21:58:46 --> URI Class Initialized
DEBUG - 2012-07-24 21:58:46 --> Router Class Initialized
DEBUG - 2012-07-24 21:58:46 --> Output Class Initialized
DEBUG - 2012-07-24 21:58:46 --> Security Class Initialized
DEBUG - 2012-07-24 21:58:46 --> Input Class Initialized
DEBUG - 2012-07-24 21:58:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 21:58:46 --> Language Class Initialized
DEBUG - 2012-07-24 21:58:46 --> Loader Class Initialized
DEBUG - 2012-07-24 21:58:46 --> Helper loaded: url_helper
DEBUG - 2012-07-24 21:58:46 --> Controller Class Initialized
DEBUG - 2012-07-24 21:58:46 --> Model Class Initialized
DEBUG - 2012-07-24 21:58:46 --> Database Driver Class Initialized
DEBUG - 2012-07-24 21:58:46 --> Helper loaded: form_helper
DEBUG - 2012-07-24 21:58:46 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-24 21:58:46 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-24 21:58:46 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-24 21:58:46 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-24 21:58:46 --> Final output sent to browser
DEBUG - 2012-07-24 21:58:46 --> Total execution time: 0.0390
