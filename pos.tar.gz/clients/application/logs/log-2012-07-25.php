<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-07-25 17:49:23 --> Config Class Initialized
DEBUG - 2012-07-25 17:49:23 --> Hooks Class Initialized
DEBUG - 2012-07-25 17:49:23 --> Utf8 Class Initialized
DEBUG - 2012-07-25 17:49:23 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 17:49:23 --> URI Class Initialized
DEBUG - 2012-07-25 17:49:23 --> Router Class Initialized
DEBUG - 2012-07-25 17:49:23 --> Output Class Initialized
DEBUG - 2012-07-25 17:49:23 --> Security Class Initialized
DEBUG - 2012-07-25 17:49:23 --> Input Class Initialized
DEBUG - 2012-07-25 17:49:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 17:49:23 --> Language Class Initialized
DEBUG - 2012-07-25 17:49:23 --> Loader Class Initialized
DEBUG - 2012-07-25 17:49:23 --> Helper loaded: url_helper
DEBUG - 2012-07-25 17:49:23 --> Controller Class Initialized
DEBUG - 2012-07-25 17:49:23 --> Model Class Initialized
DEBUG - 2012-07-25 17:49:23 --> Database Driver Class Initialized
DEBUG - 2012-07-25 17:49:23 --> Helper loaded: form_helper
DEBUG - 2012-07-25 17:49:23 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-25 17:49:23 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-25 17:49:23 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-25 17:49:23 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-25 17:49:23 --> Final output sent to browser
DEBUG - 2012-07-25 17:49:23 --> Total execution time: 0.6785
DEBUG - 2012-07-25 18:10:31 --> Config Class Initialized
DEBUG - 2012-07-25 18:10:31 --> Hooks Class Initialized
DEBUG - 2012-07-25 18:10:31 --> Utf8 Class Initialized
DEBUG - 2012-07-25 18:10:31 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 18:10:31 --> URI Class Initialized
DEBUG - 2012-07-25 18:10:31 --> Router Class Initialized
DEBUG - 2012-07-25 18:10:31 --> Output Class Initialized
DEBUG - 2012-07-25 18:10:31 --> Security Class Initialized
DEBUG - 2012-07-25 18:10:31 --> Input Class Initialized
DEBUG - 2012-07-25 18:10:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 18:10:31 --> Language Class Initialized
DEBUG - 2012-07-25 18:10:31 --> Loader Class Initialized
DEBUG - 2012-07-25 18:10:31 --> Helper loaded: url_helper
DEBUG - 2012-07-25 18:10:31 --> Controller Class Initialized
DEBUG - 2012-07-25 18:10:31 --> Model Class Initialized
DEBUG - 2012-07-25 18:10:31 --> Database Driver Class Initialized
DEBUG - 2012-07-25 18:10:31 --> Helper loaded: form_helper
DEBUG - 2012-07-25 18:10:31 --> Form Validation Class Initialized
DEBUG - 2012-07-25 18:10:46 --> Config Class Initialized
DEBUG - 2012-07-25 18:10:46 --> Hooks Class Initialized
DEBUG - 2012-07-25 18:10:46 --> Utf8 Class Initialized
DEBUG - 2012-07-25 18:10:46 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 18:10:46 --> URI Class Initialized
DEBUG - 2012-07-25 18:10:46 --> Router Class Initialized
DEBUG - 2012-07-25 18:10:46 --> Output Class Initialized
DEBUG - 2012-07-25 18:10:46 --> Security Class Initialized
DEBUG - 2012-07-25 18:10:46 --> Input Class Initialized
DEBUG - 2012-07-25 18:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 18:10:46 --> Language Class Initialized
DEBUG - 2012-07-25 18:10:46 --> Loader Class Initialized
DEBUG - 2012-07-25 18:10:46 --> Helper loaded: url_helper
DEBUG - 2012-07-25 18:10:46 --> Controller Class Initialized
DEBUG - 2012-07-25 18:10:46 --> Model Class Initialized
DEBUG - 2012-07-25 18:10:46 --> Database Driver Class Initialized
DEBUG - 2012-07-25 18:10:46 --> Helper loaded: form_helper
DEBUG - 2012-07-25 18:10:46 --> Form Validation Class Initialized
DEBUG - 2012-07-25 18:10:47 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-07-25 18:17:03 --> Config Class Initialized
DEBUG - 2012-07-25 18:17:03 --> Hooks Class Initialized
DEBUG - 2012-07-25 18:17:03 --> Utf8 Class Initialized
DEBUG - 2012-07-25 18:17:03 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 18:17:03 --> URI Class Initialized
DEBUG - 2012-07-25 18:17:03 --> Router Class Initialized
DEBUG - 2012-07-25 18:17:03 --> Output Class Initialized
DEBUG - 2012-07-25 18:17:03 --> Security Class Initialized
DEBUG - 2012-07-25 18:17:03 --> Input Class Initialized
DEBUG - 2012-07-25 18:17:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 18:17:03 --> Language Class Initialized
DEBUG - 2012-07-25 18:17:03 --> Loader Class Initialized
DEBUG - 2012-07-25 18:17:03 --> Helper loaded: url_helper
DEBUG - 2012-07-25 18:17:03 --> Controller Class Initialized
DEBUG - 2012-07-25 18:17:03 --> Model Class Initialized
DEBUG - 2012-07-25 18:17:03 --> Database Driver Class Initialized
DEBUG - 2012-07-25 18:17:03 --> Helper loaded: form_helper
DEBUG - 2012-07-25 18:17:03 --> Form Validation Class Initialized
DEBUG - 2012-07-25 18:20:09 --> Config Class Initialized
DEBUG - 2012-07-25 18:20:09 --> Hooks Class Initialized
DEBUG - 2012-07-25 18:20:09 --> Utf8 Class Initialized
DEBUG - 2012-07-25 18:20:09 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 18:20:09 --> URI Class Initialized
DEBUG - 2012-07-25 18:20:09 --> Router Class Initialized
DEBUG - 2012-07-25 18:20:09 --> Output Class Initialized
DEBUG - 2012-07-25 18:20:09 --> Security Class Initialized
DEBUG - 2012-07-25 18:20:09 --> Input Class Initialized
DEBUG - 2012-07-25 18:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 18:20:09 --> Language Class Initialized
DEBUG - 2012-07-25 18:20:09 --> Loader Class Initialized
DEBUG - 2012-07-25 18:20:09 --> Helper loaded: url_helper
DEBUG - 2012-07-25 18:20:09 --> Controller Class Initialized
DEBUG - 2012-07-25 18:20:09 --> Model Class Initialized
DEBUG - 2012-07-25 18:20:09 --> Database Driver Class Initialized
DEBUG - 2012-07-25 18:20:09 --> Helper loaded: form_helper
DEBUG - 2012-07-25 18:20:09 --> Form Validation Class Initialized
DEBUG - 2012-07-25 18:30:11 --> Config Class Initialized
DEBUG - 2012-07-25 18:30:11 --> Hooks Class Initialized
DEBUG - 2012-07-25 18:30:11 --> Utf8 Class Initialized
DEBUG - 2012-07-25 18:30:11 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 18:30:11 --> URI Class Initialized
DEBUG - 2012-07-25 18:30:11 --> Router Class Initialized
DEBUG - 2012-07-25 18:30:11 --> Output Class Initialized
DEBUG - 2012-07-25 18:30:11 --> Security Class Initialized
DEBUG - 2012-07-25 18:30:11 --> Input Class Initialized
DEBUG - 2012-07-25 18:30:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 18:30:11 --> Language Class Initialized
DEBUG - 2012-07-25 18:30:11 --> Loader Class Initialized
DEBUG - 2012-07-25 18:30:11 --> Helper loaded: url_helper
DEBUG - 2012-07-25 18:30:11 --> Controller Class Initialized
DEBUG - 2012-07-25 18:30:11 --> Model Class Initialized
DEBUG - 2012-07-25 18:30:11 --> Database Driver Class Initialized
DEBUG - 2012-07-25 18:30:11 --> Helper loaded: form_helper
DEBUG - 2012-07-25 18:30:11 --> Form Validation Class Initialized
DEBUG - 2012-07-25 18:30:11 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-07-25 18:32:08 --> Config Class Initialized
DEBUG - 2012-07-25 18:32:08 --> Hooks Class Initialized
DEBUG - 2012-07-25 18:32:08 --> Utf8 Class Initialized
DEBUG - 2012-07-25 18:32:08 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 18:32:08 --> URI Class Initialized
DEBUG - 2012-07-25 18:32:08 --> Router Class Initialized
DEBUG - 2012-07-25 18:32:08 --> Output Class Initialized
DEBUG - 2012-07-25 18:32:08 --> Security Class Initialized
DEBUG - 2012-07-25 18:32:08 --> Input Class Initialized
DEBUG - 2012-07-25 18:32:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 18:32:08 --> Language Class Initialized
DEBUG - 2012-07-25 18:32:08 --> Loader Class Initialized
DEBUG - 2012-07-25 18:32:08 --> Helper loaded: url_helper
DEBUG - 2012-07-25 18:32:08 --> Controller Class Initialized
DEBUG - 2012-07-25 18:32:08 --> Model Class Initialized
DEBUG - 2012-07-25 18:32:08 --> Database Driver Class Initialized
DEBUG - 2012-07-25 18:32:08 --> Helper loaded: form_helper
DEBUG - 2012-07-25 18:32:08 --> Form Validation Class Initialized
DEBUG - 2012-07-25 18:33:52 --> Config Class Initialized
DEBUG - 2012-07-25 18:33:52 --> Hooks Class Initialized
DEBUG - 2012-07-25 18:33:52 --> Utf8 Class Initialized
DEBUG - 2012-07-25 18:33:52 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 18:33:52 --> URI Class Initialized
DEBUG - 2012-07-25 18:33:52 --> Router Class Initialized
DEBUG - 2012-07-25 18:33:52 --> Output Class Initialized
DEBUG - 2012-07-25 18:33:52 --> Security Class Initialized
DEBUG - 2012-07-25 18:33:52 --> Input Class Initialized
DEBUG - 2012-07-25 18:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 18:33:52 --> Language Class Initialized
DEBUG - 2012-07-25 18:33:52 --> Loader Class Initialized
DEBUG - 2012-07-25 18:33:52 --> Helper loaded: url_helper
DEBUG - 2012-07-25 18:33:52 --> Controller Class Initialized
DEBUG - 2012-07-25 18:33:52 --> Model Class Initialized
DEBUG - 2012-07-25 18:33:52 --> Database Driver Class Initialized
DEBUG - 2012-07-25 18:33:52 --> Helper loaded: form_helper
DEBUG - 2012-07-25 18:33:52 --> Form Validation Class Initialized
DEBUG - 2012-07-25 18:34:37 --> Config Class Initialized
DEBUG - 2012-07-25 18:34:37 --> Hooks Class Initialized
DEBUG - 2012-07-25 18:34:37 --> Utf8 Class Initialized
DEBUG - 2012-07-25 18:34:37 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 18:34:37 --> URI Class Initialized
DEBUG - 2012-07-25 18:34:37 --> Router Class Initialized
DEBUG - 2012-07-25 18:34:37 --> Output Class Initialized
DEBUG - 2012-07-25 18:34:37 --> Security Class Initialized
DEBUG - 2012-07-25 18:34:37 --> Input Class Initialized
DEBUG - 2012-07-25 18:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 18:34:37 --> Language Class Initialized
DEBUG - 2012-07-25 18:34:37 --> Loader Class Initialized
DEBUG - 2012-07-25 18:34:37 --> Helper loaded: url_helper
DEBUG - 2012-07-25 18:34:37 --> Controller Class Initialized
DEBUG - 2012-07-25 18:34:37 --> Model Class Initialized
DEBUG - 2012-07-25 18:34:37 --> Database Driver Class Initialized
DEBUG - 2012-07-25 18:34:37 --> Helper loaded: form_helper
DEBUG - 2012-07-25 18:34:37 --> Form Validation Class Initialized
DEBUG - 2012-07-25 18:37:45 --> Config Class Initialized
DEBUG - 2012-07-25 18:37:45 --> Hooks Class Initialized
DEBUG - 2012-07-25 18:37:45 --> Utf8 Class Initialized
DEBUG - 2012-07-25 18:37:45 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 18:37:45 --> URI Class Initialized
DEBUG - 2012-07-25 18:37:45 --> Router Class Initialized
DEBUG - 2012-07-25 18:37:45 --> Output Class Initialized
DEBUG - 2012-07-25 18:37:45 --> Security Class Initialized
DEBUG - 2012-07-25 18:37:45 --> Input Class Initialized
DEBUG - 2012-07-25 18:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 18:37:45 --> Language Class Initialized
DEBUG - 2012-07-25 18:37:45 --> Loader Class Initialized
DEBUG - 2012-07-25 18:37:45 --> Helper loaded: url_helper
DEBUG - 2012-07-25 18:37:45 --> Controller Class Initialized
DEBUG - 2012-07-25 18:37:45 --> Model Class Initialized
DEBUG - 2012-07-25 18:37:45 --> Database Driver Class Initialized
DEBUG - 2012-07-25 18:37:45 --> Helper loaded: form_helper
DEBUG - 2012-07-25 18:37:45 --> Form Validation Class Initialized
DEBUG - 2012-07-25 18:37:46 --> DB Transaction Failure
DEBUG - 2012-07-25 18:40:04 --> Config Class Initialized
DEBUG - 2012-07-25 18:40:04 --> Hooks Class Initialized
DEBUG - 2012-07-25 18:40:04 --> Utf8 Class Initialized
DEBUG - 2012-07-25 18:40:04 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 18:40:04 --> URI Class Initialized
DEBUG - 2012-07-25 18:40:04 --> Router Class Initialized
DEBUG - 2012-07-25 18:40:04 --> Output Class Initialized
DEBUG - 2012-07-25 18:40:04 --> Security Class Initialized
DEBUG - 2012-07-25 18:40:04 --> Input Class Initialized
DEBUG - 2012-07-25 18:40:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 18:40:04 --> Language Class Initialized
DEBUG - 2012-07-25 18:40:04 --> Loader Class Initialized
DEBUG - 2012-07-25 18:40:04 --> Helper loaded: url_helper
DEBUG - 2012-07-25 18:40:04 --> Controller Class Initialized
DEBUG - 2012-07-25 18:40:04 --> Model Class Initialized
DEBUG - 2012-07-25 18:40:04 --> Database Driver Class Initialized
DEBUG - 2012-07-25 18:40:04 --> Helper loaded: form_helper
DEBUG - 2012-07-25 18:40:04 --> Form Validation Class Initialized
DEBUG - 2012-07-25 18:40:04 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-07-25 18:58:50 --> Config Class Initialized
DEBUG - 2012-07-25 18:58:50 --> Hooks Class Initialized
DEBUG - 2012-07-25 18:58:50 --> Utf8 Class Initialized
DEBUG - 2012-07-25 18:58:50 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 18:58:50 --> URI Class Initialized
DEBUG - 2012-07-25 18:58:50 --> Router Class Initialized
DEBUG - 2012-07-25 18:58:50 --> Output Class Initialized
DEBUG - 2012-07-25 18:58:50 --> Security Class Initialized
DEBUG - 2012-07-25 18:58:50 --> Input Class Initialized
DEBUG - 2012-07-25 18:58:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 18:58:50 --> Language Class Initialized
DEBUG - 2012-07-25 18:58:50 --> Loader Class Initialized
DEBUG - 2012-07-25 18:58:50 --> Helper loaded: url_helper
DEBUG - 2012-07-25 18:58:50 --> Controller Class Initialized
DEBUG - 2012-07-25 18:58:50 --> Model Class Initialized
DEBUG - 2012-07-25 18:58:50 --> Database Driver Class Initialized
DEBUG - 2012-07-25 18:58:50 --> Helper loaded: form_helper
DEBUG - 2012-07-25 18:58:50 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-25 18:58:50 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-25 18:58:50 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-25 18:58:50 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-07-25 18:58:50 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-25 18:58:50 --> Final output sent to browser
DEBUG - 2012-07-25 18:58:50 --> Total execution time: 0.1257
DEBUG - 2012-07-25 19:00:26 --> Config Class Initialized
DEBUG - 2012-07-25 19:00:26 --> Hooks Class Initialized
DEBUG - 2012-07-25 19:00:26 --> Utf8 Class Initialized
DEBUG - 2012-07-25 19:00:26 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 19:00:26 --> URI Class Initialized
DEBUG - 2012-07-25 19:00:26 --> Router Class Initialized
DEBUG - 2012-07-25 19:00:26 --> Output Class Initialized
DEBUG - 2012-07-25 19:00:26 --> Security Class Initialized
DEBUG - 2012-07-25 19:00:26 --> Input Class Initialized
DEBUG - 2012-07-25 19:00:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 19:00:26 --> Language Class Initialized
DEBUG - 2012-07-25 19:00:26 --> Loader Class Initialized
DEBUG - 2012-07-25 19:00:26 --> Helper loaded: url_helper
DEBUG - 2012-07-25 19:00:26 --> Controller Class Initialized
DEBUG - 2012-07-25 19:00:26 --> Model Class Initialized
DEBUG - 2012-07-25 19:00:26 --> Database Driver Class Initialized
DEBUG - 2012-07-25 19:00:26 --> Helper loaded: form_helper
DEBUG - 2012-07-25 19:00:26 --> Form Validation Class Initialized
DEBUG - 2012-07-25 19:00:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-25 19:00:26 --> Final output sent to browser
DEBUG - 2012-07-25 19:00:26 --> Total execution time: 0.0539
DEBUG - 2012-07-25 20:02:57 --> Config Class Initialized
DEBUG - 2012-07-25 20:02:57 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:02:57 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:02:57 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:02:57 --> URI Class Initialized
DEBUG - 2012-07-25 20:02:57 --> Router Class Initialized
DEBUG - 2012-07-25 20:02:57 --> Output Class Initialized
DEBUG - 2012-07-25 20:02:57 --> Security Class Initialized
DEBUG - 2012-07-25 20:02:57 --> Input Class Initialized
DEBUG - 2012-07-25 20:02:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:02:57 --> Language Class Initialized
DEBUG - 2012-07-25 20:02:57 --> Loader Class Initialized
DEBUG - 2012-07-25 20:02:57 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:02:57 --> Controller Class Initialized
DEBUG - 2012-07-25 20:02:57 --> Model Class Initialized
DEBUG - 2012-07-25 20:02:57 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:02:57 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:02:57 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-25 20:02:57 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-25 20:02:57 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-25 20:02:57 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-07-25 20:02:57 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-25 20:02:57 --> Final output sent to browser
DEBUG - 2012-07-25 20:02:57 --> Total execution time: 0.0441
DEBUG - 2012-07-25 20:02:58 --> Config Class Initialized
DEBUG - 2012-07-25 20:02:58 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:02:58 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:02:58 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:02:58 --> URI Class Initialized
DEBUG - 2012-07-25 20:02:58 --> Router Class Initialized
ERROR - 2012-07-25 20:02:58 --> 404 Page Not Found --> css
DEBUG - 2012-07-25 20:02:58 --> Config Class Initialized
DEBUG - 2012-07-25 20:02:58 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:02:58 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:02:58 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:02:58 --> URI Class Initialized
DEBUG - 2012-07-25 20:02:58 --> Router Class Initialized
ERROR - 2012-07-25 20:02:58 --> 404 Page Not Found --> css
DEBUG - 2012-07-25 20:02:58 --> Config Class Initialized
DEBUG - 2012-07-25 20:02:58 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:02:58 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:02:58 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:02:58 --> URI Class Initialized
DEBUG - 2012-07-25 20:02:58 --> Router Class Initialized
ERROR - 2012-07-25 20:02:58 --> 404 Page Not Found --> css
DEBUG - 2012-07-25 20:05:52 --> Config Class Initialized
DEBUG - 2012-07-25 20:05:52 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:05:52 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:05:52 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:05:52 --> URI Class Initialized
DEBUG - 2012-07-25 20:05:52 --> Router Class Initialized
DEBUG - 2012-07-25 20:05:52 --> Output Class Initialized
DEBUG - 2012-07-25 20:05:52 --> Security Class Initialized
DEBUG - 2012-07-25 20:05:52 --> Input Class Initialized
DEBUG - 2012-07-25 20:05:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:05:52 --> Language Class Initialized
DEBUG - 2012-07-25 20:05:52 --> Loader Class Initialized
DEBUG - 2012-07-25 20:05:52 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:05:52 --> Controller Class Initialized
DEBUG - 2012-07-25 20:05:52 --> Model Class Initialized
DEBUG - 2012-07-25 20:05:52 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:05:52 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:05:52 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-25 20:05:52 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-25 20:05:52 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-25 20:05:52 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-07-25 20:05:52 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-25 20:05:52 --> Final output sent to browser
DEBUG - 2012-07-25 20:05:52 --> Total execution time: 0.0427
DEBUG - 2012-07-25 20:06:29 --> Config Class Initialized
DEBUG - 2012-07-25 20:06:29 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:06:29 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:06:29 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:06:29 --> URI Class Initialized
DEBUG - 2012-07-25 20:06:29 --> Router Class Initialized
DEBUG - 2012-07-25 20:06:29 --> Output Class Initialized
DEBUG - 2012-07-25 20:06:29 --> Security Class Initialized
DEBUG - 2012-07-25 20:06:29 --> Input Class Initialized
DEBUG - 2012-07-25 20:06:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:06:29 --> Language Class Initialized
DEBUG - 2012-07-25 20:06:29 --> Loader Class Initialized
DEBUG - 2012-07-25 20:06:29 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:06:29 --> Controller Class Initialized
DEBUG - 2012-07-25 20:06:29 --> Model Class Initialized
DEBUG - 2012-07-25 20:06:29 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:06:29 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:06:29 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-25 20:06:29 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-25 20:06:29 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-25 20:06:29 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-07-25 20:06:29 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-25 20:06:29 --> Final output sent to browser
DEBUG - 2012-07-25 20:06:29 --> Total execution time: 0.0444
DEBUG - 2012-07-25 20:07:25 --> Config Class Initialized
DEBUG - 2012-07-25 20:07:25 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:07:25 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:07:25 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:07:25 --> URI Class Initialized
DEBUG - 2012-07-25 20:07:25 --> Router Class Initialized
DEBUG - 2012-07-25 20:07:25 --> Output Class Initialized
DEBUG - 2012-07-25 20:07:25 --> Security Class Initialized
DEBUG - 2012-07-25 20:07:25 --> Input Class Initialized
DEBUG - 2012-07-25 20:07:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:07:25 --> Language Class Initialized
DEBUG - 2012-07-25 20:07:25 --> Loader Class Initialized
DEBUG - 2012-07-25 20:07:25 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:07:25 --> Controller Class Initialized
DEBUG - 2012-07-25 20:07:25 --> Model Class Initialized
DEBUG - 2012-07-25 20:07:25 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:07:25 --> Helper loaded: language_helper
DEBUG - 2012-07-25 20:07:25 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:07:25 --> Form Validation Class Initialized
DEBUG - 2012-07-25 20:07:25 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-25 20:07:25 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2012-07-25 20:07:25 --> Could not find the language line "invalid_user_name"
DEBUG - 2012-07-25 20:07:25 --> Final output sent to browser
DEBUG - 2012-07-25 20:07:25 --> Total execution time: 0.3035
DEBUG - 2012-07-25 20:14:59 --> Config Class Initialized
DEBUG - 2012-07-25 20:14:59 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:14:59 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:14:59 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:14:59 --> URI Class Initialized
DEBUG - 2012-07-25 20:14:59 --> Router Class Initialized
DEBUG - 2012-07-25 20:14:59 --> Output Class Initialized
DEBUG - 2012-07-25 20:14:59 --> Security Class Initialized
DEBUG - 2012-07-25 20:14:59 --> Input Class Initialized
DEBUG - 2012-07-25 20:14:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:14:59 --> Language Class Initialized
DEBUG - 2012-07-25 20:14:59 --> Loader Class Initialized
DEBUG - 2012-07-25 20:14:59 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:14:59 --> Controller Class Initialized
DEBUG - 2012-07-25 20:14:59 --> Model Class Initialized
DEBUG - 2012-07-25 20:14:59 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:14:59 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:14:59 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-25 20:14:59 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-25 20:14:59 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-25 20:14:59 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-07-25 20:14:59 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-25 20:14:59 --> Final output sent to browser
DEBUG - 2012-07-25 20:14:59 --> Total execution time: 0.0400
DEBUG - 2012-07-25 20:15:08 --> Config Class Initialized
DEBUG - 2012-07-25 20:15:08 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:15:08 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:15:08 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:15:08 --> URI Class Initialized
DEBUG - 2012-07-25 20:15:08 --> Router Class Initialized
DEBUG - 2012-07-25 20:15:08 --> Output Class Initialized
DEBUG - 2012-07-25 20:15:08 --> Security Class Initialized
DEBUG - 2012-07-25 20:15:08 --> Input Class Initialized
DEBUG - 2012-07-25 20:15:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:15:08 --> Language Class Initialized
DEBUG - 2012-07-25 20:15:08 --> Loader Class Initialized
DEBUG - 2012-07-25 20:15:08 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:15:08 --> Controller Class Initialized
DEBUG - 2012-07-25 20:15:08 --> Model Class Initialized
DEBUG - 2012-07-25 20:15:08 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:15:08 --> Helper loaded: language_helper
DEBUG - 2012-07-25 20:15:08 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:15:08 --> Form Validation Class Initialized
DEBUG - 2012-07-25 20:15:08 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-25 20:15:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-25 20:15:08 --> Final output sent to browser
DEBUG - 2012-07-25 20:15:08 --> Total execution time: 0.0378
DEBUG - 2012-07-25 20:15:45 --> Config Class Initialized
DEBUG - 2012-07-25 20:15:45 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:15:45 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:15:45 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:15:45 --> URI Class Initialized
DEBUG - 2012-07-25 20:15:45 --> Router Class Initialized
DEBUG - 2012-07-25 20:15:45 --> Output Class Initialized
DEBUG - 2012-07-25 20:15:45 --> Security Class Initialized
DEBUG - 2012-07-25 20:15:45 --> Input Class Initialized
DEBUG - 2012-07-25 20:15:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:15:45 --> Language Class Initialized
DEBUG - 2012-07-25 20:15:45 --> Loader Class Initialized
DEBUG - 2012-07-25 20:15:45 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:15:45 --> Controller Class Initialized
DEBUG - 2012-07-25 20:15:45 --> Model Class Initialized
DEBUG - 2012-07-25 20:15:45 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:15:45 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:15:45 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-25 20:15:45 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-25 20:15:45 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-25 20:15:45 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-07-25 20:15:45 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-25 20:15:45 --> Final output sent to browser
DEBUG - 2012-07-25 20:15:45 --> Total execution time: 0.0472
DEBUG - 2012-07-25 20:15:51 --> Config Class Initialized
DEBUG - 2012-07-25 20:15:51 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:15:51 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:15:51 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:15:51 --> URI Class Initialized
DEBUG - 2012-07-25 20:15:51 --> Router Class Initialized
DEBUG - 2012-07-25 20:15:51 --> Output Class Initialized
DEBUG - 2012-07-25 20:15:51 --> Security Class Initialized
DEBUG - 2012-07-25 20:15:51 --> Input Class Initialized
DEBUG - 2012-07-25 20:15:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:15:51 --> Language Class Initialized
DEBUG - 2012-07-25 20:15:51 --> Loader Class Initialized
DEBUG - 2012-07-25 20:15:51 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:15:51 --> Controller Class Initialized
DEBUG - 2012-07-25 20:15:51 --> Model Class Initialized
DEBUG - 2012-07-25 20:15:51 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:15:51 --> Helper loaded: language_helper
DEBUG - 2012-07-25 20:15:51 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:15:51 --> Form Validation Class Initialized
DEBUG - 2012-07-25 20:15:51 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-25 20:15:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-25 20:15:51 --> Final output sent to browser
DEBUG - 2012-07-25 20:15:51 --> Total execution time: 0.0439
DEBUG - 2012-07-25 20:16:31 --> Config Class Initialized
DEBUG - 2012-07-25 20:16:31 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:16:31 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:16:31 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:16:31 --> URI Class Initialized
DEBUG - 2012-07-25 20:16:31 --> Router Class Initialized
DEBUG - 2012-07-25 20:16:31 --> Output Class Initialized
DEBUG - 2012-07-25 20:16:31 --> Security Class Initialized
DEBUG - 2012-07-25 20:16:31 --> Input Class Initialized
DEBUG - 2012-07-25 20:16:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:16:31 --> Language Class Initialized
DEBUG - 2012-07-25 20:16:31 --> Loader Class Initialized
DEBUG - 2012-07-25 20:16:31 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:16:31 --> Controller Class Initialized
DEBUG - 2012-07-25 20:16:31 --> Model Class Initialized
DEBUG - 2012-07-25 20:16:31 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:16:31 --> Helper loaded: language_helper
DEBUG - 2012-07-25 20:16:31 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:16:31 --> Form Validation Class Initialized
DEBUG - 2012-07-25 20:16:31 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-25 20:16:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-25 20:16:31 --> Final output sent to browser
DEBUG - 2012-07-25 20:16:31 --> Total execution time: 0.0808
DEBUG - 2012-07-25 20:17:55 --> Config Class Initialized
DEBUG - 2012-07-25 20:17:55 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:17:55 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:17:55 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:17:55 --> URI Class Initialized
DEBUG - 2012-07-25 20:17:55 --> Router Class Initialized
DEBUG - 2012-07-25 20:17:55 --> Output Class Initialized
DEBUG - 2012-07-25 20:17:55 --> Security Class Initialized
DEBUG - 2012-07-25 20:17:55 --> Input Class Initialized
DEBUG - 2012-07-25 20:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:17:55 --> Language Class Initialized
DEBUG - 2012-07-25 20:17:55 --> Loader Class Initialized
DEBUG - 2012-07-25 20:17:55 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:17:55 --> Controller Class Initialized
DEBUG - 2012-07-25 20:17:55 --> Model Class Initialized
DEBUG - 2012-07-25 20:17:55 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:17:55 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:17:55 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-25 20:17:55 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-25 20:17:55 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-25 20:17:55 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-07-25 20:17:55 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-25 20:17:55 --> Final output sent to browser
DEBUG - 2012-07-25 20:17:55 --> Total execution time: 0.0525
DEBUG - 2012-07-25 20:18:03 --> Config Class Initialized
DEBUG - 2012-07-25 20:18:03 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:18:03 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:18:03 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:18:03 --> URI Class Initialized
DEBUG - 2012-07-25 20:18:03 --> Router Class Initialized
DEBUG - 2012-07-25 20:18:03 --> Output Class Initialized
DEBUG - 2012-07-25 20:18:03 --> Security Class Initialized
DEBUG - 2012-07-25 20:18:03 --> Input Class Initialized
DEBUG - 2012-07-25 20:18:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:18:03 --> Language Class Initialized
DEBUG - 2012-07-25 20:18:03 --> Loader Class Initialized
DEBUG - 2012-07-25 20:18:03 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:18:03 --> Controller Class Initialized
DEBUG - 2012-07-25 20:18:03 --> Model Class Initialized
DEBUG - 2012-07-25 20:18:03 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:18:03 --> Helper loaded: language_helper
DEBUG - 2012-07-25 20:18:03 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:18:03 --> Form Validation Class Initialized
DEBUG - 2012-07-25 20:18:03 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-25 20:18:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-25 20:18:03 --> Final output sent to browser
DEBUG - 2012-07-25 20:18:03 --> Total execution time: 0.0392
DEBUG - 2012-07-25 20:18:13 --> Config Class Initialized
DEBUG - 2012-07-25 20:18:13 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:18:13 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:18:13 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:18:13 --> URI Class Initialized
DEBUG - 2012-07-25 20:18:13 --> Router Class Initialized
DEBUG - 2012-07-25 20:18:13 --> Output Class Initialized
DEBUG - 2012-07-25 20:18:13 --> Security Class Initialized
DEBUG - 2012-07-25 20:18:13 --> Input Class Initialized
DEBUG - 2012-07-25 20:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:18:13 --> Language Class Initialized
DEBUG - 2012-07-25 20:18:13 --> Loader Class Initialized
DEBUG - 2012-07-25 20:18:13 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:18:13 --> Controller Class Initialized
DEBUG - 2012-07-25 20:18:13 --> Model Class Initialized
DEBUG - 2012-07-25 20:18:13 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:18:13 --> Helper loaded: language_helper
DEBUG - 2012-07-25 20:18:13 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:18:13 --> Form Validation Class Initialized
DEBUG - 2012-07-25 20:18:13 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-25 20:18:13 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-25 20:18:13 --> Final output sent to browser
DEBUG - 2012-07-25 20:18:13 --> Total execution time: 0.0441
DEBUG - 2012-07-25 20:18:36 --> Config Class Initialized
DEBUG - 2012-07-25 20:18:36 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:18:36 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:18:36 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:18:36 --> URI Class Initialized
DEBUG - 2012-07-25 20:18:36 --> Router Class Initialized
DEBUG - 2012-07-25 20:18:36 --> Output Class Initialized
DEBUG - 2012-07-25 20:18:36 --> Security Class Initialized
DEBUG - 2012-07-25 20:18:36 --> Input Class Initialized
DEBUG - 2012-07-25 20:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:18:36 --> Language Class Initialized
DEBUG - 2012-07-25 20:18:36 --> Loader Class Initialized
DEBUG - 2012-07-25 20:18:36 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:18:36 --> Controller Class Initialized
DEBUG - 2012-07-25 20:18:36 --> Model Class Initialized
DEBUG - 2012-07-25 20:18:36 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:18:36 --> Helper loaded: language_helper
DEBUG - 2012-07-25 20:18:36 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:18:36 --> Form Validation Class Initialized
DEBUG - 2012-07-25 20:18:36 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-25 20:18:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-25 20:18:36 --> Final output sent to browser
DEBUG - 2012-07-25 20:18:36 --> Total execution time: 0.0373
DEBUG - 2012-07-25 20:20:51 --> Config Class Initialized
DEBUG - 2012-07-25 20:20:51 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:20:51 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:20:51 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:20:51 --> URI Class Initialized
DEBUG - 2012-07-25 20:20:51 --> Router Class Initialized
DEBUG - 2012-07-25 20:20:51 --> Output Class Initialized
DEBUG - 2012-07-25 20:20:51 --> Security Class Initialized
DEBUG - 2012-07-25 20:20:51 --> Input Class Initialized
DEBUG - 2012-07-25 20:20:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:20:51 --> Language Class Initialized
DEBUG - 2012-07-25 20:20:51 --> Loader Class Initialized
DEBUG - 2012-07-25 20:20:51 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:20:51 --> Controller Class Initialized
DEBUG - 2012-07-25 20:20:51 --> Model Class Initialized
DEBUG - 2012-07-25 20:20:51 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:20:51 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:20:51 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-25 20:20:51 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-25 20:20:51 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-25 20:20:51 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-07-25 20:20:51 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-25 20:20:51 --> Final output sent to browser
DEBUG - 2012-07-25 20:20:51 --> Total execution time: 0.0441
DEBUG - 2012-07-25 20:20:56 --> Config Class Initialized
DEBUG - 2012-07-25 20:20:56 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:20:56 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:20:56 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:20:56 --> URI Class Initialized
DEBUG - 2012-07-25 20:20:56 --> Router Class Initialized
DEBUG - 2012-07-25 20:20:56 --> Output Class Initialized
DEBUG - 2012-07-25 20:20:56 --> Security Class Initialized
DEBUG - 2012-07-25 20:20:56 --> Input Class Initialized
DEBUG - 2012-07-25 20:20:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:20:56 --> Language Class Initialized
DEBUG - 2012-07-25 20:20:56 --> Loader Class Initialized
DEBUG - 2012-07-25 20:20:56 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:20:56 --> Controller Class Initialized
DEBUG - 2012-07-25 20:20:56 --> Model Class Initialized
DEBUG - 2012-07-25 20:20:56 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:20:56 --> Helper loaded: language_helper
DEBUG - 2012-07-25 20:20:56 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:20:56 --> Form Validation Class Initialized
DEBUG - 2012-07-25 20:20:56 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-25 20:20:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-25 20:20:56 --> Final output sent to browser
DEBUG - 2012-07-25 20:20:56 --> Total execution time: 0.0378
DEBUG - 2012-07-25 20:22:30 --> Config Class Initialized
DEBUG - 2012-07-25 20:22:30 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:22:30 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:22:30 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:22:30 --> URI Class Initialized
DEBUG - 2012-07-25 20:22:30 --> Router Class Initialized
DEBUG - 2012-07-25 20:22:30 --> Output Class Initialized
DEBUG - 2012-07-25 20:22:30 --> Security Class Initialized
DEBUG - 2012-07-25 20:22:30 --> Input Class Initialized
DEBUG - 2012-07-25 20:22:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:22:30 --> Language Class Initialized
DEBUG - 2012-07-25 20:22:30 --> Loader Class Initialized
DEBUG - 2012-07-25 20:22:30 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:22:30 --> Controller Class Initialized
DEBUG - 2012-07-25 20:22:30 --> Model Class Initialized
DEBUG - 2012-07-25 20:22:30 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:22:30 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:22:30 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-25 20:22:30 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-25 20:22:30 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-25 20:22:30 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-07-25 20:22:30 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-25 20:22:30 --> Final output sent to browser
DEBUG - 2012-07-25 20:22:30 --> Total execution time: 0.0471
DEBUG - 2012-07-25 20:22:34 --> Config Class Initialized
DEBUG - 2012-07-25 20:22:34 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:22:34 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:22:34 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:22:34 --> URI Class Initialized
DEBUG - 2012-07-25 20:22:34 --> Router Class Initialized
DEBUG - 2012-07-25 20:22:34 --> Output Class Initialized
DEBUG - 2012-07-25 20:22:34 --> Security Class Initialized
DEBUG - 2012-07-25 20:22:34 --> Input Class Initialized
DEBUG - 2012-07-25 20:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:22:34 --> Language Class Initialized
DEBUG - 2012-07-25 20:22:34 --> Loader Class Initialized
DEBUG - 2012-07-25 20:22:34 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:22:34 --> Controller Class Initialized
DEBUG - 2012-07-25 20:22:34 --> Model Class Initialized
DEBUG - 2012-07-25 20:22:34 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:22:34 --> Helper loaded: language_helper
DEBUG - 2012-07-25 20:22:34 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:22:34 --> Form Validation Class Initialized
DEBUG - 2012-07-25 20:22:34 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-25 20:22:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-25 20:22:34 --> Final output sent to browser
DEBUG - 2012-07-25 20:22:34 --> Total execution time: 0.0376
DEBUG - 2012-07-25 20:22:40 --> Config Class Initialized
DEBUG - 2012-07-25 20:22:40 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:22:40 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:22:40 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:22:40 --> URI Class Initialized
DEBUG - 2012-07-25 20:22:40 --> Router Class Initialized
DEBUG - 2012-07-25 20:22:40 --> Output Class Initialized
DEBUG - 2012-07-25 20:22:40 --> Security Class Initialized
DEBUG - 2012-07-25 20:22:40 --> Input Class Initialized
DEBUG - 2012-07-25 20:22:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:22:40 --> Language Class Initialized
DEBUG - 2012-07-25 20:22:40 --> Loader Class Initialized
DEBUG - 2012-07-25 20:22:40 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:22:40 --> Controller Class Initialized
DEBUG - 2012-07-25 20:22:40 --> Model Class Initialized
DEBUG - 2012-07-25 20:22:40 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:22:40 --> Helper loaded: language_helper
DEBUG - 2012-07-25 20:22:40 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:22:40 --> Form Validation Class Initialized
DEBUG - 2012-07-25 20:22:40 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-25 20:22:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-25 20:22:40 --> Final output sent to browser
DEBUG - 2012-07-25 20:22:40 --> Total execution time: 0.0424
DEBUG - 2012-07-25 20:23:46 --> Config Class Initialized
DEBUG - 2012-07-25 20:23:46 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:23:46 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:23:46 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:23:46 --> URI Class Initialized
DEBUG - 2012-07-25 20:23:46 --> Router Class Initialized
DEBUG - 2012-07-25 20:23:46 --> Output Class Initialized
DEBUG - 2012-07-25 20:23:46 --> Security Class Initialized
DEBUG - 2012-07-25 20:23:46 --> Input Class Initialized
DEBUG - 2012-07-25 20:23:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:23:46 --> Language Class Initialized
DEBUG - 2012-07-25 20:23:46 --> Loader Class Initialized
DEBUG - 2012-07-25 20:23:46 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:23:46 --> Controller Class Initialized
DEBUG - 2012-07-25 20:23:46 --> Model Class Initialized
DEBUG - 2012-07-25 20:23:46 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:23:46 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:23:46 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-25 20:23:46 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-25 20:23:46 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-25 20:23:46 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-07-25 20:23:46 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-25 20:23:46 --> Final output sent to browser
DEBUG - 2012-07-25 20:23:46 --> Total execution time: 0.0529
DEBUG - 2012-07-25 20:23:52 --> Config Class Initialized
DEBUG - 2012-07-25 20:23:52 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:23:52 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:23:52 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:23:52 --> URI Class Initialized
DEBUG - 2012-07-25 20:23:52 --> Router Class Initialized
DEBUG - 2012-07-25 20:23:52 --> Output Class Initialized
DEBUG - 2012-07-25 20:23:52 --> Security Class Initialized
DEBUG - 2012-07-25 20:23:52 --> Input Class Initialized
DEBUG - 2012-07-25 20:23:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:23:52 --> Language Class Initialized
DEBUG - 2012-07-25 20:23:52 --> Loader Class Initialized
DEBUG - 2012-07-25 20:23:52 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:23:52 --> Controller Class Initialized
DEBUG - 2012-07-25 20:23:52 --> Model Class Initialized
DEBUG - 2012-07-25 20:23:52 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:23:52 --> Helper loaded: language_helper
DEBUG - 2012-07-25 20:23:52 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:23:52 --> Form Validation Class Initialized
DEBUG - 2012-07-25 20:23:52 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-25 20:23:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-25 20:23:52 --> Final output sent to browser
DEBUG - 2012-07-25 20:23:52 --> Total execution time: 0.0392
DEBUG - 2012-07-25 20:23:57 --> Config Class Initialized
DEBUG - 2012-07-25 20:23:57 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:23:57 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:23:57 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:23:57 --> URI Class Initialized
DEBUG - 2012-07-25 20:23:57 --> Router Class Initialized
DEBUG - 2012-07-25 20:23:57 --> Output Class Initialized
DEBUG - 2012-07-25 20:23:57 --> Security Class Initialized
DEBUG - 2012-07-25 20:23:57 --> Input Class Initialized
DEBUG - 2012-07-25 20:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:23:57 --> Language Class Initialized
DEBUG - 2012-07-25 20:23:57 --> Loader Class Initialized
DEBUG - 2012-07-25 20:23:57 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:23:57 --> Controller Class Initialized
DEBUG - 2012-07-25 20:23:57 --> Model Class Initialized
DEBUG - 2012-07-25 20:23:57 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:23:57 --> Helper loaded: language_helper
DEBUG - 2012-07-25 20:23:57 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:23:57 --> Form Validation Class Initialized
DEBUG - 2012-07-25 20:23:57 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-25 20:23:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-25 20:23:57 --> Final output sent to browser
DEBUG - 2012-07-25 20:23:57 --> Total execution time: 0.0377
DEBUG - 2012-07-25 20:24:05 --> Config Class Initialized
DEBUG - 2012-07-25 20:24:05 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:24:05 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:24:05 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:24:05 --> URI Class Initialized
DEBUG - 2012-07-25 20:24:05 --> Router Class Initialized
DEBUG - 2012-07-25 20:24:05 --> Output Class Initialized
DEBUG - 2012-07-25 20:24:05 --> Security Class Initialized
DEBUG - 2012-07-25 20:24:05 --> Input Class Initialized
DEBUG - 2012-07-25 20:24:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:24:05 --> Language Class Initialized
DEBUG - 2012-07-25 20:24:05 --> Loader Class Initialized
DEBUG - 2012-07-25 20:24:05 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:24:05 --> Controller Class Initialized
DEBUG - 2012-07-25 20:24:05 --> Model Class Initialized
DEBUG - 2012-07-25 20:24:05 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:24:05 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:24:05 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-25 20:24:05 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-25 20:24:05 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-25 20:24:05 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-07-25 20:24:05 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-25 20:24:05 --> Final output sent to browser
DEBUG - 2012-07-25 20:24:05 --> Total execution time: 0.0446
DEBUG - 2012-07-25 20:24:08 --> Config Class Initialized
DEBUG - 2012-07-25 20:24:08 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:24:08 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:24:08 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:24:08 --> URI Class Initialized
DEBUG - 2012-07-25 20:24:08 --> Router Class Initialized
DEBUG - 2012-07-25 20:24:08 --> Output Class Initialized
DEBUG - 2012-07-25 20:24:08 --> Security Class Initialized
DEBUG - 2012-07-25 20:24:08 --> Input Class Initialized
DEBUG - 2012-07-25 20:24:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:24:08 --> Language Class Initialized
DEBUG - 2012-07-25 20:24:08 --> Loader Class Initialized
DEBUG - 2012-07-25 20:24:08 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:24:08 --> Controller Class Initialized
DEBUG - 2012-07-25 20:24:08 --> Model Class Initialized
DEBUG - 2012-07-25 20:24:08 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:24:08 --> Helper loaded: language_helper
DEBUG - 2012-07-25 20:24:08 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:24:08 --> Form Validation Class Initialized
DEBUG - 2012-07-25 20:24:08 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-25 20:24:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-25 20:24:08 --> Final output sent to browser
DEBUG - 2012-07-25 20:24:08 --> Total execution time: 0.0405
DEBUG - 2012-07-25 20:31:55 --> Config Class Initialized
DEBUG - 2012-07-25 20:31:55 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:31:55 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:31:55 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:31:55 --> URI Class Initialized
DEBUG - 2012-07-25 20:31:55 --> Router Class Initialized
DEBUG - 2012-07-25 20:31:55 --> Output Class Initialized
DEBUG - 2012-07-25 20:31:55 --> Security Class Initialized
DEBUG - 2012-07-25 20:31:55 --> Input Class Initialized
DEBUG - 2012-07-25 20:31:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:31:55 --> Language Class Initialized
DEBUG - 2012-07-25 20:31:55 --> Loader Class Initialized
DEBUG - 2012-07-25 20:31:55 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:31:55 --> Controller Class Initialized
DEBUG - 2012-07-25 20:31:55 --> Model Class Initialized
DEBUG - 2012-07-25 20:31:55 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:31:55 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:31:55 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-25 20:31:55 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-25 20:31:55 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-25 20:31:55 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-07-25 20:31:55 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-25 20:31:55 --> Final output sent to browser
DEBUG - 2012-07-25 20:31:55 --> Total execution time: 0.0395
DEBUG - 2012-07-25 20:31:58 --> Config Class Initialized
DEBUG - 2012-07-25 20:31:58 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:31:58 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:31:58 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:31:58 --> URI Class Initialized
DEBUG - 2012-07-25 20:31:58 --> Router Class Initialized
DEBUG - 2012-07-25 20:31:58 --> Output Class Initialized
DEBUG - 2012-07-25 20:31:58 --> Security Class Initialized
DEBUG - 2012-07-25 20:31:58 --> Input Class Initialized
DEBUG - 2012-07-25 20:31:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:31:58 --> Language Class Initialized
DEBUG - 2012-07-25 20:31:58 --> Loader Class Initialized
DEBUG - 2012-07-25 20:31:58 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:31:58 --> Controller Class Initialized
DEBUG - 2012-07-25 20:31:58 --> Model Class Initialized
DEBUG - 2012-07-25 20:31:58 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:31:58 --> Helper loaded: language_helper
DEBUG - 2012-07-25 20:31:58 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:31:58 --> Form Validation Class Initialized
DEBUG - 2012-07-25 20:31:58 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-25 20:31:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-25 20:31:58 --> Final output sent to browser
DEBUG - 2012-07-25 20:31:58 --> Total execution time: 0.0414
DEBUG - 2012-07-25 20:32:05 --> Config Class Initialized
DEBUG - 2012-07-25 20:32:05 --> Hooks Class Initialized
DEBUG - 2012-07-25 20:32:05 --> Utf8 Class Initialized
DEBUG - 2012-07-25 20:32:05 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 20:32:05 --> URI Class Initialized
DEBUG - 2012-07-25 20:32:05 --> Router Class Initialized
DEBUG - 2012-07-25 20:32:05 --> Output Class Initialized
DEBUG - 2012-07-25 20:32:05 --> Security Class Initialized
DEBUG - 2012-07-25 20:32:05 --> Input Class Initialized
DEBUG - 2012-07-25 20:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 20:32:05 --> Language Class Initialized
DEBUG - 2012-07-25 20:32:05 --> Loader Class Initialized
DEBUG - 2012-07-25 20:32:05 --> Helper loaded: url_helper
DEBUG - 2012-07-25 20:32:05 --> Controller Class Initialized
DEBUG - 2012-07-25 20:32:05 --> Model Class Initialized
DEBUG - 2012-07-25 20:32:05 --> Database Driver Class Initialized
DEBUG - 2012-07-25 20:32:05 --> Helper loaded: language_helper
DEBUG - 2012-07-25 20:32:05 --> Helper loaded: form_helper
DEBUG - 2012-07-25 20:32:05 --> Form Validation Class Initialized
DEBUG - 2012-07-25 20:32:05 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-25 20:32:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-25 20:32:05 --> Final output sent to browser
DEBUG - 2012-07-25 20:32:05 --> Total execution time: 0.0400
DEBUG - 2012-07-25 21:06:16 --> Config Class Initialized
DEBUG - 2012-07-25 21:06:16 --> Hooks Class Initialized
DEBUG - 2012-07-25 21:06:16 --> Utf8 Class Initialized
DEBUG - 2012-07-25 21:06:16 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 21:06:16 --> URI Class Initialized
DEBUG - 2012-07-25 21:06:16 --> Router Class Initialized
DEBUG - 2012-07-25 21:06:16 --> Output Class Initialized
DEBUG - 2012-07-25 21:06:16 --> Security Class Initialized
DEBUG - 2012-07-25 21:06:16 --> Input Class Initialized
DEBUG - 2012-07-25 21:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 21:06:16 --> Language Class Initialized
DEBUG - 2012-07-25 21:06:16 --> Loader Class Initialized
DEBUG - 2012-07-25 21:06:16 --> Helper loaded: url_helper
DEBUG - 2012-07-25 21:06:16 --> Controller Class Initialized
DEBUG - 2012-07-25 21:06:16 --> Model Class Initialized
DEBUG - 2012-07-25 21:06:16 --> Database Driver Class Initialized
DEBUG - 2012-07-25 21:06:16 --> Helper loaded: form_helper
DEBUG - 2012-07-25 21:06:16 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-25 21:06:16 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-25 21:06:16 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-25 21:06:16 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-07-25 21:06:16 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-25 21:06:16 --> Final output sent to browser
DEBUG - 2012-07-25 21:06:16 --> Total execution time: 0.3931
DEBUG - 2012-07-25 21:06:17 --> Config Class Initialized
DEBUG - 2012-07-25 21:06:17 --> Hooks Class Initialized
DEBUG - 2012-07-25 21:06:17 --> Utf8 Class Initialized
DEBUG - 2012-07-25 21:06:17 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 21:06:17 --> URI Class Initialized
DEBUG - 2012-07-25 21:06:17 --> Router Class Initialized
ERROR - 2012-07-25 21:06:17 --> 404 Page Not Found --> css
DEBUG - 2012-07-25 21:06:17 --> Config Class Initialized
DEBUG - 2012-07-25 21:06:17 --> Hooks Class Initialized
DEBUG - 2012-07-25 21:06:17 --> Utf8 Class Initialized
DEBUG - 2012-07-25 21:06:17 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 21:06:17 --> URI Class Initialized
DEBUG - 2012-07-25 21:06:17 --> Router Class Initialized
ERROR - 2012-07-25 21:06:17 --> 404 Page Not Found --> css
DEBUG - 2012-07-25 21:06:17 --> Config Class Initialized
DEBUG - 2012-07-25 21:06:17 --> Hooks Class Initialized
DEBUG - 2012-07-25 21:06:17 --> Utf8 Class Initialized
DEBUG - 2012-07-25 21:06:17 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 21:06:17 --> URI Class Initialized
DEBUG - 2012-07-25 21:06:17 --> Router Class Initialized
ERROR - 2012-07-25 21:06:17 --> 404 Page Not Found --> css
DEBUG - 2012-07-25 21:06:19 --> Config Class Initialized
DEBUG - 2012-07-25 21:06:19 --> Hooks Class Initialized
DEBUG - 2012-07-25 21:06:19 --> Utf8 Class Initialized
DEBUG - 2012-07-25 21:06:19 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 21:06:19 --> URI Class Initialized
DEBUG - 2012-07-25 21:06:19 --> Router Class Initialized
DEBUG - 2012-07-25 21:06:19 --> Output Class Initialized
DEBUG - 2012-07-25 21:06:19 --> Security Class Initialized
DEBUG - 2012-07-25 21:06:19 --> Input Class Initialized
DEBUG - 2012-07-25 21:06:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 21:06:19 --> Language Class Initialized
DEBUG - 2012-07-25 21:06:19 --> Loader Class Initialized
DEBUG - 2012-07-25 21:06:19 --> Helper loaded: url_helper
DEBUG - 2012-07-25 21:06:19 --> Controller Class Initialized
DEBUG - 2012-07-25 21:06:19 --> Model Class Initialized
DEBUG - 2012-07-25 21:06:19 --> Database Driver Class Initialized
DEBUG - 2012-07-25 21:06:19 --> Helper loaded: language_helper
DEBUG - 2012-07-25 21:06:19 --> Helper loaded: form_helper
DEBUG - 2012-07-25 21:06:19 --> Form Validation Class Initialized
DEBUG - 2012-07-25 21:06:19 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-25 21:06:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-25 21:06:19 --> Final output sent to browser
DEBUG - 2012-07-25 21:06:19 --> Total execution time: 0.0507
DEBUG - 2012-07-25 21:06:26 --> Config Class Initialized
DEBUG - 2012-07-25 21:06:26 --> Hooks Class Initialized
DEBUG - 2012-07-25 21:06:26 --> Utf8 Class Initialized
DEBUG - 2012-07-25 21:06:26 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 21:06:26 --> URI Class Initialized
DEBUG - 2012-07-25 21:06:26 --> Router Class Initialized
DEBUG - 2012-07-25 21:06:26 --> Output Class Initialized
DEBUG - 2012-07-25 21:06:26 --> Security Class Initialized
DEBUG - 2012-07-25 21:06:26 --> Input Class Initialized
DEBUG - 2012-07-25 21:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 21:06:26 --> Language Class Initialized
DEBUG - 2012-07-25 21:06:26 --> Loader Class Initialized
DEBUG - 2012-07-25 21:06:26 --> Helper loaded: url_helper
DEBUG - 2012-07-25 21:06:26 --> Controller Class Initialized
DEBUG - 2012-07-25 21:06:26 --> Model Class Initialized
DEBUG - 2012-07-25 21:06:26 --> Database Driver Class Initialized
DEBUG - 2012-07-25 21:06:26 --> Helper loaded: language_helper
DEBUG - 2012-07-25 21:06:26 --> Helper loaded: form_helper
DEBUG - 2012-07-25 21:06:26 --> Form Validation Class Initialized
DEBUG - 2012-07-25 21:06:26 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-25 21:06:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-25 21:06:26 --> Final output sent to browser
DEBUG - 2012-07-25 21:06:26 --> Total execution time: 0.0437
DEBUG - 2012-07-25 21:06:43 --> Config Class Initialized
DEBUG - 2012-07-25 21:06:43 --> Hooks Class Initialized
DEBUG - 2012-07-25 21:06:43 --> Utf8 Class Initialized
DEBUG - 2012-07-25 21:06:43 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 21:06:43 --> URI Class Initialized
DEBUG - 2012-07-25 21:06:43 --> Router Class Initialized
DEBUG - 2012-07-25 21:06:43 --> Output Class Initialized
DEBUG - 2012-07-25 21:06:43 --> Security Class Initialized
DEBUG - 2012-07-25 21:06:43 --> Input Class Initialized
DEBUG - 2012-07-25 21:06:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 21:06:43 --> Language Class Initialized
DEBUG - 2012-07-25 21:06:43 --> Loader Class Initialized
DEBUG - 2012-07-25 21:06:43 --> Helper loaded: url_helper
DEBUG - 2012-07-25 21:06:43 --> Controller Class Initialized
DEBUG - 2012-07-25 21:06:43 --> Model Class Initialized
DEBUG - 2012-07-25 21:06:43 --> Database Driver Class Initialized
DEBUG - 2012-07-25 21:06:43 --> Helper loaded: form_helper
DEBUG - 2012-07-25 21:06:43 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-25 21:06:43 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-25 21:06:43 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-25 21:06:43 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-07-25 21:06:43 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-25 21:06:43 --> Final output sent to browser
DEBUG - 2012-07-25 21:06:43 --> Total execution time: 0.0497
DEBUG - 2012-07-25 21:06:44 --> Config Class Initialized
DEBUG - 2012-07-25 21:06:44 --> Hooks Class Initialized
DEBUG - 2012-07-25 21:06:44 --> Utf8 Class Initialized
DEBUG - 2012-07-25 21:06:44 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 21:06:44 --> URI Class Initialized
DEBUG - 2012-07-25 21:06:44 --> Router Class Initialized
DEBUG - 2012-07-25 21:06:44 --> Output Class Initialized
DEBUG - 2012-07-25 21:06:44 --> Security Class Initialized
DEBUG - 2012-07-25 21:06:44 --> Input Class Initialized
DEBUG - 2012-07-25 21:06:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 21:06:44 --> Language Class Initialized
DEBUG - 2012-07-25 21:06:44 --> Loader Class Initialized
DEBUG - 2012-07-25 21:06:44 --> Helper loaded: url_helper
DEBUG - 2012-07-25 21:06:44 --> Controller Class Initialized
DEBUG - 2012-07-25 21:06:44 --> Model Class Initialized
DEBUG - 2012-07-25 21:06:44 --> Database Driver Class Initialized
DEBUG - 2012-07-25 21:06:44 --> Helper loaded: form_helper
DEBUG - 2012-07-25 21:06:44 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-25 21:06:44 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-25 21:06:44 --> File loaded: application/views/admin/templates/left_menu.php
ERROR - 2012-07-25 21:06:44 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 62
ERROR - 2012-07-25 21:06:44 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 64
ERROR - 2012-07-25 21:06:44 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 64
ERROR - 2012-07-25 21:06:44 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 64
DEBUG - 2012-07-25 21:06:44 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-07-25 21:06:44 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-25 21:06:44 --> Final output sent to browser
DEBUG - 2012-07-25 21:06:44 --> Total execution time: 0.0605
DEBUG - 2012-07-25 21:06:46 --> Config Class Initialized
DEBUG - 2012-07-25 21:06:46 --> Hooks Class Initialized
DEBUG - 2012-07-25 21:06:46 --> Utf8 Class Initialized
DEBUG - 2012-07-25 21:06:46 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 21:06:46 --> URI Class Initialized
DEBUG - 2012-07-25 21:06:46 --> Router Class Initialized
DEBUG - 2012-07-25 21:06:46 --> Output Class Initialized
DEBUG - 2012-07-25 21:06:46 --> Security Class Initialized
DEBUG - 2012-07-25 21:06:46 --> Input Class Initialized
DEBUG - 2012-07-25 21:06:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 21:06:46 --> Language Class Initialized
DEBUG - 2012-07-25 21:06:46 --> Loader Class Initialized
DEBUG - 2012-07-25 21:06:46 --> Helper loaded: url_helper
DEBUG - 2012-07-25 21:06:46 --> Controller Class Initialized
DEBUG - 2012-07-25 21:06:46 --> Model Class Initialized
DEBUG - 2012-07-25 21:06:46 --> Database Driver Class Initialized
DEBUG - 2012-07-25 21:06:46 --> Helper loaded: language_helper
DEBUG - 2012-07-25 21:06:46 --> Helper loaded: html_helper
DEBUG - 2012-07-25 21:06:46 --> Helper loaded: form_helper
DEBUG - 2012-07-25 21:06:46 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-07-25 21:06:46 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-25 21:06:46 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-07-25 21:06:46 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-25 21:06:46 --> File loaded: application/views/admin/pages/business/logo.php
DEBUG - 2012-07-25 21:06:46 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-25 21:06:46 --> Final output sent to browser
DEBUG - 2012-07-25 21:06:46 --> Total execution time: 0.0738
DEBUG - 2012-07-25 21:06:51 --> Config Class Initialized
DEBUG - 2012-07-25 21:06:51 --> Hooks Class Initialized
DEBUG - 2012-07-25 21:06:51 --> Utf8 Class Initialized
DEBUG - 2012-07-25 21:06:51 --> UTF-8 Support Disabled
DEBUG - 2012-07-25 21:06:51 --> URI Class Initialized
DEBUG - 2012-07-25 21:06:51 --> Router Class Initialized
DEBUG - 2012-07-25 21:06:51 --> Output Class Initialized
DEBUG - 2012-07-25 21:06:51 --> Security Class Initialized
DEBUG - 2012-07-25 21:06:51 --> Input Class Initialized
DEBUG - 2012-07-25 21:06:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-25 21:06:51 --> Language Class Initialized
DEBUG - 2012-07-25 21:06:51 --> Loader Class Initialized
DEBUG - 2012-07-25 21:06:51 --> Helper loaded: url_helper
DEBUG - 2012-07-25 21:06:51 --> Controller Class Initialized
DEBUG - 2012-07-25 21:06:51 --> Model Class Initialized
DEBUG - 2012-07-25 21:06:51 --> Database Driver Class Initialized
DEBUG - 2012-07-25 21:06:51 --> Helper loaded: form_helper
DEBUG - 2012-07-25 21:06:51 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-07-25 21:06:51 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-07-25 21:06:51 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-07-25 21:06:51 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-07-25 21:06:53 --> Final output sent to browser
DEBUG - 2012-07-25 21:06:53 --> Total execution time: 0.0923
