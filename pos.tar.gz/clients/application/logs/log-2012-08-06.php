<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-08-06 17:05:26 --> Config Class Initialized
DEBUG - 2012-08-06 17:05:26 --> Hooks Class Initialized
DEBUG - 2012-08-06 17:05:26 --> Utf8 Class Initialized
DEBUG - 2012-08-06 17:05:26 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 17:05:26 --> URI Class Initialized
DEBUG - 2012-08-06 17:05:26 --> Router Class Initialized
DEBUG - 2012-08-06 17:05:26 --> No URI present. Default controller set.
DEBUG - 2012-08-06 17:05:26 --> Output Class Initialized
DEBUG - 2012-08-06 17:05:26 --> Security Class Initialized
DEBUG - 2012-08-06 17:05:26 --> Input Class Initialized
DEBUG - 2012-08-06 17:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 17:05:26 --> Language Class Initialized
DEBUG - 2012-08-06 17:05:26 --> Loader Class Initialized
DEBUG - 2012-08-06 17:05:26 --> Helper loaded: url_helper
DEBUG - 2012-08-06 17:05:26 --> Controller Class Initialized
DEBUG - 2012-08-06 17:05:26 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-08-06 17:05:26 --> Final output sent to browser
DEBUG - 2012-08-06 17:05:26 --> Total execution time: 0.1551
DEBUG - 2012-08-06 17:05:32 --> Config Class Initialized
DEBUG - 2012-08-06 17:05:32 --> Hooks Class Initialized
DEBUG - 2012-08-06 17:05:32 --> Utf8 Class Initialized
DEBUG - 2012-08-06 17:05:32 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 17:05:32 --> URI Class Initialized
DEBUG - 2012-08-06 17:05:32 --> Router Class Initialized
DEBUG - 2012-08-06 17:05:32 --> Output Class Initialized
DEBUG - 2012-08-06 17:05:32 --> Security Class Initialized
DEBUG - 2012-08-06 17:05:32 --> Input Class Initialized
DEBUG - 2012-08-06 17:05:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 17:05:32 --> Language Class Initialized
DEBUG - 2012-08-06 17:05:32 --> Loader Class Initialized
DEBUG - 2012-08-06 17:05:32 --> Helper loaded: url_helper
DEBUG - 2012-08-06 17:05:32 --> Controller Class Initialized
DEBUG - 2012-08-06 17:05:32 --> Model Class Initialized
DEBUG - 2012-08-06 17:05:33 --> Database Driver Class Initialized
DEBUG - 2012-08-06 17:05:33 --> Helper loaded: form_helper
DEBUG - 2012-08-06 17:05:33 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 17:05:33 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-08-06 17:05:33 --> File loaded: application/views/admin/templates/left_menu.php
ERROR - 2012-08-06 17:05:33 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 62
ERROR - 2012-08-06 17:05:33 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 64
ERROR - 2012-08-06 17:05:33 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 64
ERROR - 2012-08-06 17:05:33 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 64
DEBUG - 2012-08-06 17:05:33 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-08-06 17:05:33 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 17:05:33 --> Final output sent to browser
DEBUG - 2012-08-06 17:05:33 --> Total execution time: 0.5107
DEBUG - 2012-08-06 17:06:33 --> Config Class Initialized
DEBUG - 2012-08-06 17:06:33 --> Hooks Class Initialized
DEBUG - 2012-08-06 17:06:33 --> Utf8 Class Initialized
DEBUG - 2012-08-06 17:06:33 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 17:06:33 --> URI Class Initialized
DEBUG - 2012-08-06 17:06:33 --> Router Class Initialized
DEBUG - 2012-08-06 17:06:33 --> Output Class Initialized
DEBUG - 2012-08-06 17:06:33 --> Security Class Initialized
DEBUG - 2012-08-06 17:06:33 --> Input Class Initialized
DEBUG - 2012-08-06 17:06:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 17:06:33 --> Language Class Initialized
DEBUG - 2012-08-06 17:06:33 --> Loader Class Initialized
DEBUG - 2012-08-06 17:06:33 --> Helper loaded: url_helper
DEBUG - 2012-08-06 17:06:33 --> Controller Class Initialized
DEBUG - 2012-08-06 17:06:33 --> Model Class Initialized
DEBUG - 2012-08-06 17:06:33 --> Database Driver Class Initialized
DEBUG - 2012-08-06 17:06:33 --> Helper loaded: form_helper
DEBUG - 2012-08-06 17:06:33 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 17:06:33 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-08-06 17:06:33 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-08-06 17:06:33 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 17:06:33 --> Final output sent to browser
DEBUG - 2012-08-06 17:06:33 --> Total execution time: 0.0815
DEBUG - 2012-08-06 17:07:29 --> Config Class Initialized
DEBUG - 2012-08-06 17:07:29 --> Hooks Class Initialized
DEBUG - 2012-08-06 17:07:29 --> Utf8 Class Initialized
DEBUG - 2012-08-06 17:07:29 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 17:07:29 --> URI Class Initialized
DEBUG - 2012-08-06 17:07:29 --> Router Class Initialized
DEBUG - 2012-08-06 17:07:29 --> Output Class Initialized
DEBUG - 2012-08-06 17:07:29 --> Security Class Initialized
DEBUG - 2012-08-06 17:07:29 --> Input Class Initialized
DEBUG - 2012-08-06 17:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 17:07:29 --> Language Class Initialized
DEBUG - 2012-08-06 17:07:29 --> Loader Class Initialized
DEBUG - 2012-08-06 17:07:29 --> Helper loaded: url_helper
DEBUG - 2012-08-06 17:07:29 --> Controller Class Initialized
DEBUG - 2012-08-06 17:07:29 --> Model Class Initialized
DEBUG - 2012-08-06 17:07:29 --> Database Driver Class Initialized
DEBUG - 2012-08-06 17:07:29 --> Helper loaded: form_helper
DEBUG - 2012-08-06 17:07:29 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 17:07:29 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-08-06 17:07:29 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-08-06 17:07:29 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 17:07:29 --> Final output sent to browser
DEBUG - 2012-08-06 17:07:29 --> Total execution time: 0.0446
DEBUG - 2012-08-06 17:07:44 --> Config Class Initialized
DEBUG - 2012-08-06 17:07:44 --> Hooks Class Initialized
DEBUG - 2012-08-06 17:07:44 --> Utf8 Class Initialized
DEBUG - 2012-08-06 17:07:44 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 17:07:44 --> URI Class Initialized
DEBUG - 2012-08-06 17:07:44 --> Router Class Initialized
DEBUG - 2012-08-06 17:07:44 --> Output Class Initialized
DEBUG - 2012-08-06 17:07:44 --> Security Class Initialized
DEBUG - 2012-08-06 17:07:44 --> Input Class Initialized
DEBUG - 2012-08-06 17:07:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 17:07:44 --> Language Class Initialized
DEBUG - 2012-08-06 17:07:44 --> Loader Class Initialized
DEBUG - 2012-08-06 17:07:44 --> Helper loaded: url_helper
DEBUG - 2012-08-06 17:07:44 --> Controller Class Initialized
DEBUG - 2012-08-06 17:07:44 --> Model Class Initialized
DEBUG - 2012-08-06 17:07:44 --> Database Driver Class Initialized
DEBUG - 2012-08-06 17:07:45 --> Final output sent to browser
DEBUG - 2012-08-06 17:07:45 --> Total execution time: 0.2811
DEBUG - 2012-08-06 17:19:21 --> Config Class Initialized
DEBUG - 2012-08-06 17:19:21 --> Hooks Class Initialized
DEBUG - 2012-08-06 17:19:21 --> Utf8 Class Initialized
DEBUG - 2012-08-06 17:19:21 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 17:19:21 --> URI Class Initialized
DEBUG - 2012-08-06 17:19:21 --> Router Class Initialized
DEBUG - 2012-08-06 17:19:21 --> Output Class Initialized
DEBUG - 2012-08-06 17:19:21 --> Security Class Initialized
DEBUG - 2012-08-06 17:19:21 --> Input Class Initialized
DEBUG - 2012-08-06 17:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 17:19:21 --> Language Class Initialized
DEBUG - 2012-08-06 17:19:21 --> Loader Class Initialized
DEBUG - 2012-08-06 17:19:21 --> Helper loaded: url_helper
DEBUG - 2012-08-06 17:19:21 --> Controller Class Initialized
DEBUG - 2012-08-06 17:19:21 --> Model Class Initialized
DEBUG - 2012-08-06 17:19:21 --> Database Driver Class Initialized
DEBUG - 2012-08-06 17:20:30 --> Config Class Initialized
DEBUG - 2012-08-06 17:20:30 --> Hooks Class Initialized
DEBUG - 2012-08-06 17:20:30 --> Utf8 Class Initialized
DEBUG - 2012-08-06 17:20:30 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 17:20:30 --> URI Class Initialized
DEBUG - 2012-08-06 17:20:30 --> Router Class Initialized
DEBUG - 2012-08-06 17:20:30 --> Output Class Initialized
DEBUG - 2012-08-06 17:20:30 --> Security Class Initialized
DEBUG - 2012-08-06 17:20:30 --> Input Class Initialized
DEBUG - 2012-08-06 17:20:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 17:20:30 --> Language Class Initialized
DEBUG - 2012-08-06 17:20:30 --> Loader Class Initialized
DEBUG - 2012-08-06 17:20:30 --> Helper loaded: url_helper
DEBUG - 2012-08-06 17:20:30 --> Controller Class Initialized
DEBUG - 2012-08-06 17:20:30 --> Model Class Initialized
DEBUG - 2012-08-06 17:20:30 --> Database Driver Class Initialized
DEBUG - 2012-08-06 17:20:30 --> Helper loaded: form_helper
DEBUG - 2012-08-06 17:20:30 --> Form Validation Class Initialized
ERROR - 2012-08-06 17:20:30 --> Severity: Notice  --> Undefined index: printprice_1 /home/jwp/www/justinwylliephotography.com/clients/application/libraries/Prices.php 34
DEBUG - 2012-08-06 17:20:30 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-08-06 17:21:15 --> Config Class Initialized
DEBUG - 2012-08-06 17:21:15 --> Hooks Class Initialized
DEBUG - 2012-08-06 17:21:15 --> Utf8 Class Initialized
DEBUG - 2012-08-06 17:21:15 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 17:21:15 --> URI Class Initialized
DEBUG - 2012-08-06 17:21:15 --> Router Class Initialized
DEBUG - 2012-08-06 17:21:15 --> Output Class Initialized
DEBUG - 2012-08-06 17:21:15 --> Security Class Initialized
DEBUG - 2012-08-06 17:21:15 --> Input Class Initialized
DEBUG - 2012-08-06 17:21:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 17:21:15 --> Language Class Initialized
DEBUG - 2012-08-06 17:21:15 --> Loader Class Initialized
DEBUG - 2012-08-06 17:21:15 --> Helper loaded: url_helper
DEBUG - 2012-08-06 17:21:15 --> Controller Class Initialized
DEBUG - 2012-08-06 17:21:15 --> Model Class Initialized
DEBUG - 2012-08-06 17:21:15 --> Database Driver Class Initialized
DEBUG - 2012-08-06 17:21:15 --> Helper loaded: form_helper
DEBUG - 2012-08-06 17:21:15 --> Form Validation Class Initialized
ERROR - 2012-08-06 17:21:15 --> Severity: Notice  --> Undefined index: printprice_1 /home/jwp/www/justinwylliephotography.com/clients/application/libraries/Prices.php 34
DEBUG - 2012-08-06 17:21:15 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-08-06 17:25:08 --> Config Class Initialized
DEBUG - 2012-08-06 17:25:08 --> Hooks Class Initialized
DEBUG - 2012-08-06 17:25:08 --> Utf8 Class Initialized
DEBUG - 2012-08-06 17:25:08 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 17:25:08 --> URI Class Initialized
DEBUG - 2012-08-06 17:25:08 --> Router Class Initialized
DEBUG - 2012-08-06 17:25:08 --> Output Class Initialized
DEBUG - 2012-08-06 17:25:08 --> Security Class Initialized
DEBUG - 2012-08-06 17:25:08 --> Input Class Initialized
DEBUG - 2012-08-06 17:25:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 17:25:08 --> Language Class Initialized
DEBUG - 2012-08-06 17:25:08 --> Loader Class Initialized
DEBUG - 2012-08-06 17:25:08 --> Helper loaded: url_helper
DEBUG - 2012-08-06 17:25:08 --> Controller Class Initialized
DEBUG - 2012-08-06 17:25:08 --> Model Class Initialized
DEBUG - 2012-08-06 17:25:08 --> Database Driver Class Initialized
DEBUG - 2012-08-06 17:25:08 --> Helper loaded: form_helper
DEBUG - 2012-08-06 17:25:08 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 17:25:08 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-08-06 17:25:08 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-08-06 17:25:08 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 17:25:08 --> Final output sent to browser
DEBUG - 2012-08-06 17:25:08 --> Total execution time: 0.0490
DEBUG - 2012-08-06 17:25:10 --> Config Class Initialized
DEBUG - 2012-08-06 17:25:10 --> Hooks Class Initialized
DEBUG - 2012-08-06 17:25:10 --> Utf8 Class Initialized
DEBUG - 2012-08-06 17:25:10 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 17:25:10 --> URI Class Initialized
DEBUG - 2012-08-06 17:25:10 --> Router Class Initialized
DEBUG - 2012-08-06 17:25:10 --> Output Class Initialized
DEBUG - 2012-08-06 17:25:10 --> Security Class Initialized
DEBUG - 2012-08-06 17:25:10 --> Input Class Initialized
DEBUG - 2012-08-06 17:25:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 17:25:10 --> Language Class Initialized
DEBUG - 2012-08-06 17:25:10 --> Loader Class Initialized
DEBUG - 2012-08-06 17:25:10 --> Helper loaded: url_helper
DEBUG - 2012-08-06 17:25:10 --> Controller Class Initialized
DEBUG - 2012-08-06 17:25:10 --> Model Class Initialized
DEBUG - 2012-08-06 17:25:10 --> Database Driver Class Initialized
DEBUG - 2012-08-06 17:25:10 --> Helper loaded: form_helper
DEBUG - 2012-08-06 17:25:10 --> Form Validation Class Initialized
DEBUG - 2012-08-06 17:25:10 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-08-06 17:26:04 --> Config Class Initialized
DEBUG - 2012-08-06 17:26:04 --> Hooks Class Initialized
DEBUG - 2012-08-06 17:26:04 --> Utf8 Class Initialized
DEBUG - 2012-08-06 17:26:04 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 17:26:04 --> URI Class Initialized
DEBUG - 2012-08-06 17:26:04 --> Router Class Initialized
DEBUG - 2012-08-06 17:26:04 --> Output Class Initialized
DEBUG - 2012-08-06 17:26:04 --> Security Class Initialized
DEBUG - 2012-08-06 17:26:04 --> Input Class Initialized
DEBUG - 2012-08-06 17:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 17:26:04 --> Language Class Initialized
DEBUG - 2012-08-06 17:26:04 --> Loader Class Initialized
DEBUG - 2012-08-06 17:26:04 --> Helper loaded: url_helper
DEBUG - 2012-08-06 17:26:04 --> Controller Class Initialized
DEBUG - 2012-08-06 17:26:04 --> Model Class Initialized
DEBUG - 2012-08-06 17:26:04 --> Database Driver Class Initialized
DEBUG - 2012-08-06 17:26:04 --> Helper loaded: form_helper
DEBUG - 2012-08-06 17:26:04 --> Form Validation Class Initialized
DEBUG - 2012-08-06 17:26:04 --> DB Transaction Failure
DEBUG - 2012-08-06 17:30:15 --> Config Class Initialized
DEBUG - 2012-08-06 17:30:15 --> Hooks Class Initialized
DEBUG - 2012-08-06 17:30:15 --> Utf8 Class Initialized
DEBUG - 2012-08-06 17:30:15 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 17:30:15 --> URI Class Initialized
DEBUG - 2012-08-06 17:30:15 --> Router Class Initialized
DEBUG - 2012-08-06 17:30:15 --> Output Class Initialized
DEBUG - 2012-08-06 17:30:15 --> Security Class Initialized
DEBUG - 2012-08-06 17:30:15 --> Input Class Initialized
DEBUG - 2012-08-06 17:30:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 17:30:15 --> Language Class Initialized
DEBUG - 2012-08-06 17:30:15 --> Loader Class Initialized
DEBUG - 2012-08-06 17:30:15 --> Helper loaded: url_helper
DEBUG - 2012-08-06 17:30:15 --> Controller Class Initialized
DEBUG - 2012-08-06 17:30:15 --> Model Class Initialized
DEBUG - 2012-08-06 17:30:15 --> Database Driver Class Initialized
DEBUG - 2012-08-06 17:30:15 --> Helper loaded: form_helper
DEBUG - 2012-08-06 17:30:15 --> Form Validation Class Initialized
DEBUG - 2012-08-06 17:30:15 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-08-06 17:36:52 --> Config Class Initialized
DEBUG - 2012-08-06 17:36:52 --> Hooks Class Initialized
DEBUG - 2012-08-06 17:36:52 --> Utf8 Class Initialized
DEBUG - 2012-08-06 17:36:52 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 17:36:52 --> URI Class Initialized
DEBUG - 2012-08-06 17:36:52 --> Router Class Initialized
DEBUG - 2012-08-06 17:36:52 --> Output Class Initialized
DEBUG - 2012-08-06 17:36:52 --> Security Class Initialized
DEBUG - 2012-08-06 17:36:52 --> Input Class Initialized
DEBUG - 2012-08-06 17:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 17:36:52 --> Language Class Initialized
DEBUG - 2012-08-06 17:36:52 --> Loader Class Initialized
DEBUG - 2012-08-06 17:36:52 --> Helper loaded: url_helper
DEBUG - 2012-08-06 17:36:52 --> Controller Class Initialized
DEBUG - 2012-08-06 17:36:52 --> Model Class Initialized
DEBUG - 2012-08-06 17:36:52 --> Database Driver Class Initialized
DEBUG - 2012-08-06 17:36:52 --> Helper loaded: form_helper
DEBUG - 2012-08-06 17:36:52 --> Form Validation Class Initialized
DEBUG - 2012-08-06 17:36:52 --> Final output sent to browser
DEBUG - 2012-08-06 17:36:52 --> Total execution time: 0.0378
DEBUG - 2012-08-06 17:39:01 --> Config Class Initialized
DEBUG - 2012-08-06 17:39:01 --> Hooks Class Initialized
DEBUG - 2012-08-06 17:39:01 --> Utf8 Class Initialized
DEBUG - 2012-08-06 17:39:01 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 17:39:01 --> URI Class Initialized
DEBUG - 2012-08-06 17:39:01 --> Router Class Initialized
DEBUG - 2012-08-06 17:39:01 --> Output Class Initialized
DEBUG - 2012-08-06 17:39:01 --> Security Class Initialized
DEBUG - 2012-08-06 17:39:01 --> Input Class Initialized
DEBUG - 2012-08-06 17:39:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 17:39:01 --> Language Class Initialized
DEBUG - 2012-08-06 17:39:01 --> Loader Class Initialized
DEBUG - 2012-08-06 17:39:01 --> Helper loaded: url_helper
DEBUG - 2012-08-06 17:39:01 --> Controller Class Initialized
DEBUG - 2012-08-06 17:39:01 --> Model Class Initialized
DEBUG - 2012-08-06 17:39:01 --> Database Driver Class Initialized
DEBUG - 2012-08-06 17:39:01 --> Helper loaded: form_helper
DEBUG - 2012-08-06 17:39:01 --> Form Validation Class Initialized
DEBUG - 2012-08-06 17:39:01 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-08-06 17:39:42 --> Config Class Initialized
DEBUG - 2012-08-06 17:39:42 --> Hooks Class Initialized
DEBUG - 2012-08-06 17:39:42 --> Utf8 Class Initialized
DEBUG - 2012-08-06 17:39:42 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 17:39:42 --> URI Class Initialized
DEBUG - 2012-08-06 17:39:42 --> Router Class Initialized
DEBUG - 2012-08-06 17:39:42 --> Output Class Initialized
DEBUG - 2012-08-06 17:39:42 --> Security Class Initialized
DEBUG - 2012-08-06 17:39:42 --> Input Class Initialized
DEBUG - 2012-08-06 17:39:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 17:39:42 --> Language Class Initialized
DEBUG - 2012-08-06 17:39:42 --> Loader Class Initialized
DEBUG - 2012-08-06 17:39:42 --> Helper loaded: url_helper
DEBUG - 2012-08-06 17:39:42 --> Controller Class Initialized
DEBUG - 2012-08-06 17:39:42 --> Model Class Initialized
DEBUG - 2012-08-06 17:39:42 --> Database Driver Class Initialized
DEBUG - 2012-08-06 17:39:42 --> Helper loaded: form_helper
DEBUG - 2012-08-06 17:39:42 --> Form Validation Class Initialized
DEBUG - 2012-08-06 17:39:55 --> Config Class Initialized
DEBUG - 2012-08-06 17:39:55 --> Hooks Class Initialized
DEBUG - 2012-08-06 17:39:55 --> Utf8 Class Initialized
DEBUG - 2012-08-06 17:39:55 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 17:39:55 --> URI Class Initialized
DEBUG - 2012-08-06 17:39:55 --> Router Class Initialized
DEBUG - 2012-08-06 17:39:55 --> Output Class Initialized
DEBUG - 2012-08-06 17:39:55 --> Security Class Initialized
DEBUG - 2012-08-06 17:39:55 --> Input Class Initialized
DEBUG - 2012-08-06 17:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 17:39:55 --> Language Class Initialized
DEBUG - 2012-08-06 17:39:55 --> Loader Class Initialized
DEBUG - 2012-08-06 17:39:55 --> Helper loaded: url_helper
DEBUG - 2012-08-06 17:39:55 --> Controller Class Initialized
DEBUG - 2012-08-06 17:39:55 --> Model Class Initialized
DEBUG - 2012-08-06 17:39:55 --> Database Driver Class Initialized
DEBUG - 2012-08-06 17:39:55 --> Helper loaded: form_helper
DEBUG - 2012-08-06 17:39:55 --> Form Validation Class Initialized
DEBUG - 2012-08-06 17:39:55 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-08-06 17:40:10 --> Config Class Initialized
DEBUG - 2012-08-06 17:40:10 --> Hooks Class Initialized
DEBUG - 2012-08-06 17:40:10 --> Utf8 Class Initialized
DEBUG - 2012-08-06 17:40:10 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 17:40:10 --> URI Class Initialized
DEBUG - 2012-08-06 17:40:10 --> Router Class Initialized
DEBUG - 2012-08-06 17:40:10 --> Output Class Initialized
DEBUG - 2012-08-06 17:40:10 --> Security Class Initialized
DEBUG - 2012-08-06 17:40:10 --> Input Class Initialized
DEBUG - 2012-08-06 17:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 17:40:10 --> Language Class Initialized
DEBUG - 2012-08-06 17:40:10 --> Loader Class Initialized
DEBUG - 2012-08-06 17:40:10 --> Helper loaded: url_helper
DEBUG - 2012-08-06 17:40:10 --> Controller Class Initialized
DEBUG - 2012-08-06 17:40:10 --> Model Class Initialized
DEBUG - 2012-08-06 17:40:10 --> Database Driver Class Initialized
DEBUG - 2012-08-06 17:40:10 --> Helper loaded: form_helper
DEBUG - 2012-08-06 17:40:10 --> Form Validation Class Initialized
DEBUG - 2012-08-06 17:40:10 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-08-06 17:40:32 --> Config Class Initialized
DEBUG - 2012-08-06 17:40:32 --> Hooks Class Initialized
DEBUG - 2012-08-06 17:40:32 --> Utf8 Class Initialized
DEBUG - 2012-08-06 17:40:32 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 17:40:32 --> URI Class Initialized
DEBUG - 2012-08-06 17:40:32 --> Router Class Initialized
DEBUG - 2012-08-06 17:40:32 --> Output Class Initialized
DEBUG - 2012-08-06 17:40:32 --> Security Class Initialized
DEBUG - 2012-08-06 17:40:32 --> Input Class Initialized
DEBUG - 2012-08-06 17:40:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 17:40:32 --> Language Class Initialized
DEBUG - 2012-08-06 17:40:32 --> Loader Class Initialized
DEBUG - 2012-08-06 17:40:32 --> Helper loaded: url_helper
DEBUG - 2012-08-06 17:40:32 --> Controller Class Initialized
DEBUG - 2012-08-06 17:40:32 --> Model Class Initialized
ERROR - 2012-08-06 17:40:32 --> Severity: Warning  --> require_once(/home/jwp/www/justinwylliephotography.com/clients/system/database/DB_active_rec.php): failed to open stream: No such file or directory /home/jwp/www/justinwylliephotography.com/clients/system/database/DB.php 125
DEBUG - 2012-08-06 17:40:40 --> Config Class Initialized
DEBUG - 2012-08-06 17:40:40 --> Hooks Class Initialized
DEBUG - 2012-08-06 17:40:40 --> Utf8 Class Initialized
DEBUG - 2012-08-06 17:40:40 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 17:40:40 --> URI Class Initialized
DEBUG - 2012-08-06 17:40:40 --> Router Class Initialized
DEBUG - 2012-08-06 17:40:40 --> Output Class Initialized
DEBUG - 2012-08-06 17:40:40 --> Security Class Initialized
DEBUG - 2012-08-06 17:40:40 --> Input Class Initialized
DEBUG - 2012-08-06 17:40:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 17:40:40 --> Language Class Initialized
DEBUG - 2012-08-06 17:40:40 --> Loader Class Initialized
DEBUG - 2012-08-06 17:40:40 --> Helper loaded: url_helper
DEBUG - 2012-08-06 17:40:40 --> Controller Class Initialized
DEBUG - 2012-08-06 17:40:40 --> Model Class Initialized
DEBUG - 2012-08-06 17:40:40 --> Database Driver Class Initialized
DEBUG - 2012-08-06 17:40:40 --> Helper loaded: form_helper
DEBUG - 2012-08-06 17:40:40 --> Form Validation Class Initialized
DEBUG - 2012-08-06 17:41:50 --> Config Class Initialized
DEBUG - 2012-08-06 17:41:50 --> Hooks Class Initialized
DEBUG - 2012-08-06 17:41:50 --> Utf8 Class Initialized
DEBUG - 2012-08-06 17:41:50 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 17:41:50 --> URI Class Initialized
DEBUG - 2012-08-06 17:41:50 --> Router Class Initialized
DEBUG - 2012-08-06 17:41:50 --> Output Class Initialized
DEBUG - 2012-08-06 17:41:50 --> Security Class Initialized
DEBUG - 2012-08-06 17:41:50 --> Input Class Initialized
DEBUG - 2012-08-06 17:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 17:41:50 --> Language Class Initialized
DEBUG - 2012-08-06 17:41:50 --> Loader Class Initialized
DEBUG - 2012-08-06 17:41:50 --> Helper loaded: url_helper
DEBUG - 2012-08-06 17:41:50 --> Controller Class Initialized
DEBUG - 2012-08-06 17:41:50 --> Model Class Initialized
DEBUG - 2012-08-06 17:41:50 --> Database Driver Class Initialized
DEBUG - 2012-08-06 17:41:50 --> Helper loaded: form_helper
DEBUG - 2012-08-06 17:41:50 --> Form Validation Class Initialized
DEBUG - 2012-08-06 17:57:00 --> Config Class Initialized
DEBUG - 2012-08-06 17:57:00 --> Hooks Class Initialized
DEBUG - 2012-08-06 17:57:00 --> Utf8 Class Initialized
DEBUG - 2012-08-06 17:57:00 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 17:57:00 --> URI Class Initialized
DEBUG - 2012-08-06 17:57:00 --> Router Class Initialized
DEBUG - 2012-08-06 17:57:00 --> Output Class Initialized
DEBUG - 2012-08-06 17:57:00 --> Security Class Initialized
DEBUG - 2012-08-06 17:57:00 --> Input Class Initialized
DEBUG - 2012-08-06 17:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 17:57:00 --> Language Class Initialized
DEBUG - 2012-08-06 17:57:00 --> Loader Class Initialized
DEBUG - 2012-08-06 17:57:00 --> Helper loaded: url_helper
DEBUG - 2012-08-06 17:57:00 --> Controller Class Initialized
DEBUG - 2012-08-06 17:57:00 --> Model Class Initialized
DEBUG - 2012-08-06 17:57:00 --> Database Driver Class Initialized
DEBUG - 2012-08-06 17:57:00 --> Helper loaded: form_helper
DEBUG - 2012-08-06 17:57:00 --> Form Validation Class Initialized
DEBUG - 2012-08-06 18:02:36 --> Config Class Initialized
DEBUG - 2012-08-06 18:02:36 --> Hooks Class Initialized
DEBUG - 2012-08-06 18:02:36 --> Utf8 Class Initialized
DEBUG - 2012-08-06 18:02:36 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 18:02:36 --> URI Class Initialized
DEBUG - 2012-08-06 18:02:36 --> Router Class Initialized
DEBUG - 2012-08-06 18:02:36 --> Output Class Initialized
DEBUG - 2012-08-06 18:02:36 --> Security Class Initialized
DEBUG - 2012-08-06 18:02:36 --> Input Class Initialized
DEBUG - 2012-08-06 18:02:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 18:02:36 --> Language Class Initialized
DEBUG - 2012-08-06 18:02:36 --> Loader Class Initialized
DEBUG - 2012-08-06 18:02:36 --> Helper loaded: url_helper
DEBUG - 2012-08-06 18:02:36 --> Controller Class Initialized
DEBUG - 2012-08-06 18:02:36 --> Model Class Initialized
DEBUG - 2012-08-06 18:02:36 --> Database Driver Class Initialized
DEBUG - 2012-08-06 18:02:36 --> Helper loaded: form_helper
DEBUG - 2012-08-06 18:02:36 --> Form Validation Class Initialized
DEBUG - 2012-08-06 18:28:45 --> Config Class Initialized
DEBUG - 2012-08-06 18:28:45 --> Hooks Class Initialized
DEBUG - 2012-08-06 18:28:45 --> Utf8 Class Initialized
DEBUG - 2012-08-06 18:28:45 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 18:28:45 --> URI Class Initialized
DEBUG - 2012-08-06 18:28:45 --> Router Class Initialized
DEBUG - 2012-08-06 18:28:45 --> Output Class Initialized
DEBUG - 2012-08-06 18:28:45 --> Security Class Initialized
DEBUG - 2012-08-06 18:28:45 --> Input Class Initialized
DEBUG - 2012-08-06 18:28:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 18:28:45 --> Language Class Initialized
DEBUG - 2012-08-06 18:28:45 --> Loader Class Initialized
DEBUG - 2012-08-06 18:28:45 --> Helper loaded: url_helper
DEBUG - 2012-08-06 18:28:45 --> Controller Class Initialized
DEBUG - 2012-08-06 18:28:45 --> Model Class Initialized
DEBUG - 2012-08-06 18:28:45 --> Database Driver Class Initialized
DEBUG - 2012-08-06 18:28:45 --> Helper loaded: form_helper
DEBUG - 2012-08-06 18:28:45 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 18:28:45 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-08-06 18:28:45 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-08-06 18:28:45 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-08-06 18:28:45 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 18:28:45 --> Final output sent to browser
DEBUG - 2012-08-06 18:28:45 --> Total execution time: 0.0437
DEBUG - 2012-08-06 18:28:46 --> Config Class Initialized
DEBUG - 2012-08-06 18:28:46 --> Hooks Class Initialized
DEBUG - 2012-08-06 18:28:46 --> Utf8 Class Initialized
DEBUG - 2012-08-06 18:28:46 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 18:28:46 --> URI Class Initialized
DEBUG - 2012-08-06 18:28:46 --> Router Class Initialized
ERROR - 2012-08-06 18:28:46 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 18:28:46 --> Config Class Initialized
DEBUG - 2012-08-06 18:28:46 --> Hooks Class Initialized
DEBUG - 2012-08-06 18:28:46 --> Utf8 Class Initialized
DEBUG - 2012-08-06 18:28:46 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 18:28:46 --> URI Class Initialized
DEBUG - 2012-08-06 18:28:46 --> Router Class Initialized
ERROR - 2012-08-06 18:28:46 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 18:28:46 --> Config Class Initialized
DEBUG - 2012-08-06 18:28:46 --> Hooks Class Initialized
DEBUG - 2012-08-06 18:28:46 --> Utf8 Class Initialized
DEBUG - 2012-08-06 18:28:46 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 18:28:46 --> URI Class Initialized
DEBUG - 2012-08-06 18:28:46 --> Router Class Initialized
ERROR - 2012-08-06 18:28:46 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 18:28:49 --> Config Class Initialized
DEBUG - 2012-08-06 18:28:49 --> Hooks Class Initialized
DEBUG - 2012-08-06 18:28:49 --> Utf8 Class Initialized
DEBUG - 2012-08-06 18:28:49 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 18:28:49 --> URI Class Initialized
DEBUG - 2012-08-06 18:28:49 --> Router Class Initialized
DEBUG - 2012-08-06 18:28:49 --> Output Class Initialized
DEBUG - 2012-08-06 18:28:49 --> Security Class Initialized
DEBUG - 2012-08-06 18:28:49 --> Input Class Initialized
DEBUG - 2012-08-06 18:28:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 18:28:49 --> Language Class Initialized
DEBUG - 2012-08-06 18:28:49 --> Loader Class Initialized
DEBUG - 2012-08-06 18:28:49 --> Helper loaded: url_helper
DEBUG - 2012-08-06 18:28:49 --> Controller Class Initialized
DEBUG - 2012-08-06 18:28:49 --> Model Class Initialized
DEBUG - 2012-08-06 18:28:49 --> Database Driver Class Initialized
DEBUG - 2012-08-06 18:28:49 --> Helper loaded: language_helper
DEBUG - 2012-08-06 18:28:49 --> Helper loaded: form_helper
DEBUG - 2012-08-06 18:28:49 --> Form Validation Class Initialized
DEBUG - 2012-08-06 18:28:49 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 18:28:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 18:28:49 --> Final output sent to browser
DEBUG - 2012-08-06 18:28:49 --> Total execution time: 0.0381
DEBUG - 2012-08-06 19:12:43 --> Config Class Initialized
DEBUG - 2012-08-06 19:12:43 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:12:43 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:12:43 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:12:43 --> URI Class Initialized
DEBUG - 2012-08-06 19:12:43 --> Router Class Initialized
DEBUG - 2012-08-06 19:12:43 --> Output Class Initialized
DEBUG - 2012-08-06 19:12:43 --> Security Class Initialized
DEBUG - 2012-08-06 19:12:43 --> Input Class Initialized
DEBUG - 2012-08-06 19:12:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:12:43 --> Language Class Initialized
DEBUG - 2012-08-06 19:12:43 --> Loader Class Initialized
DEBUG - 2012-08-06 19:12:43 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:12:43 --> Controller Class Initialized
DEBUG - 2012-08-06 19:12:43 --> Model Class Initialized
DEBUG - 2012-08-06 19:12:43 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:12:43 --> Helper loaded: language_helper
DEBUG - 2012-08-06 19:12:43 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:12:43 --> Form Validation Class Initialized
DEBUG - 2012-08-06 19:12:43 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 19:12:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 19:12:43 --> Final output sent to browser
DEBUG - 2012-08-06 19:12:43 --> Total execution time: 0.0386
DEBUG - 2012-08-06 19:12:46 --> Config Class Initialized
DEBUG - 2012-08-06 19:12:46 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:12:46 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:12:46 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:12:46 --> URI Class Initialized
DEBUG - 2012-08-06 19:12:46 --> Router Class Initialized
DEBUG - 2012-08-06 19:12:46 --> Output Class Initialized
DEBUG - 2012-08-06 19:12:46 --> Security Class Initialized
DEBUG - 2012-08-06 19:12:46 --> Input Class Initialized
DEBUG - 2012-08-06 19:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:12:46 --> Language Class Initialized
DEBUG - 2012-08-06 19:12:46 --> Loader Class Initialized
DEBUG - 2012-08-06 19:12:46 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:12:46 --> Controller Class Initialized
DEBUG - 2012-08-06 19:12:46 --> Model Class Initialized
DEBUG - 2012-08-06 19:12:46 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:12:46 --> Helper loaded: language_helper
DEBUG - 2012-08-06 19:12:46 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:12:46 --> Form Validation Class Initialized
DEBUG - 2012-08-06 19:12:46 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 19:12:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 19:12:46 --> Final output sent to browser
DEBUG - 2012-08-06 19:12:46 --> Total execution time: 0.0440
DEBUG - 2012-08-06 19:15:16 --> Config Class Initialized
DEBUG - 2012-08-06 19:15:16 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:15:16 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:15:16 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:15:16 --> URI Class Initialized
DEBUG - 2012-08-06 19:15:16 --> Router Class Initialized
DEBUG - 2012-08-06 19:15:16 --> Output Class Initialized
DEBUG - 2012-08-06 19:15:16 --> Security Class Initialized
DEBUG - 2012-08-06 19:15:16 --> Input Class Initialized
DEBUG - 2012-08-06 19:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:15:16 --> Language Class Initialized
DEBUG - 2012-08-06 19:15:16 --> Loader Class Initialized
DEBUG - 2012-08-06 19:15:16 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:15:16 --> Controller Class Initialized
DEBUG - 2012-08-06 19:15:16 --> Model Class Initialized
DEBUG - 2012-08-06 19:15:16 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:15:16 --> Helper loaded: language_helper
DEBUG - 2012-08-06 19:15:16 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:15:16 --> Form Validation Class Initialized
DEBUG - 2012-08-06 19:15:16 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 19:15:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 19:15:16 --> Final output sent to browser
DEBUG - 2012-08-06 19:15:16 --> Total execution time: 0.0379
DEBUG - 2012-08-06 19:15:26 --> Config Class Initialized
DEBUG - 2012-08-06 19:15:26 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:15:26 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:15:26 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:15:26 --> URI Class Initialized
DEBUG - 2012-08-06 19:15:26 --> Router Class Initialized
DEBUG - 2012-08-06 19:15:26 --> Output Class Initialized
DEBUG - 2012-08-06 19:15:26 --> Security Class Initialized
DEBUG - 2012-08-06 19:15:26 --> Input Class Initialized
DEBUG - 2012-08-06 19:15:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:15:26 --> Language Class Initialized
DEBUG - 2012-08-06 19:15:26 --> Loader Class Initialized
DEBUG - 2012-08-06 19:15:26 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:15:26 --> Controller Class Initialized
DEBUG - 2012-08-06 19:15:26 --> Model Class Initialized
DEBUG - 2012-08-06 19:15:26 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:15:26 --> Helper loaded: language_helper
DEBUG - 2012-08-06 19:15:26 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:15:26 --> Form Validation Class Initialized
DEBUG - 2012-08-06 19:15:26 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 19:15:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 19:15:26 --> Final output sent to browser
DEBUG - 2012-08-06 19:15:26 --> Total execution time: 0.0422
DEBUG - 2012-08-06 19:18:00 --> Config Class Initialized
DEBUG - 2012-08-06 19:18:00 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:18:00 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:18:00 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:18:00 --> URI Class Initialized
DEBUG - 2012-08-06 19:18:00 --> Router Class Initialized
DEBUG - 2012-08-06 19:18:00 --> Output Class Initialized
DEBUG - 2012-08-06 19:18:00 --> Security Class Initialized
DEBUG - 2012-08-06 19:18:00 --> Input Class Initialized
DEBUG - 2012-08-06 19:18:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:18:00 --> Language Class Initialized
DEBUG - 2012-08-06 19:18:00 --> Loader Class Initialized
DEBUG - 2012-08-06 19:18:00 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:18:00 --> Controller Class Initialized
DEBUG - 2012-08-06 19:18:00 --> Model Class Initialized
DEBUG - 2012-08-06 19:18:00 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:18:01 --> Helper loaded: language_helper
DEBUG - 2012-08-06 19:18:01 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:18:01 --> Form Validation Class Initialized
DEBUG - 2012-08-06 19:18:01 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 19:18:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 19:18:01 --> Final output sent to browser
DEBUG - 2012-08-06 19:18:01 --> Total execution time: 0.0417
DEBUG - 2012-08-06 19:25:34 --> Config Class Initialized
DEBUG - 2012-08-06 19:25:34 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:25:34 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:25:34 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:25:34 --> URI Class Initialized
DEBUG - 2012-08-06 19:25:34 --> Router Class Initialized
DEBUG - 2012-08-06 19:25:34 --> Output Class Initialized
DEBUG - 2012-08-06 19:25:34 --> Security Class Initialized
DEBUG - 2012-08-06 19:25:34 --> Input Class Initialized
DEBUG - 2012-08-06 19:25:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:25:34 --> Language Class Initialized
DEBUG - 2012-08-06 19:25:34 --> Loader Class Initialized
DEBUG - 2012-08-06 19:25:34 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:25:34 --> Controller Class Initialized
DEBUG - 2012-08-06 19:25:34 --> Model Class Initialized
DEBUG - 2012-08-06 19:25:34 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:25:34 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:25:34 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 19:25:34 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-08-06 19:25:34 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-08-06 19:25:34 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-08-06 19:25:34 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 19:25:34 --> Final output sent to browser
DEBUG - 2012-08-06 19:25:34 --> Total execution time: 0.0405
DEBUG - 2012-08-06 19:25:37 --> Config Class Initialized
DEBUG - 2012-08-06 19:25:37 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:25:37 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:25:37 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:25:37 --> URI Class Initialized
DEBUG - 2012-08-06 19:25:37 --> Router Class Initialized
DEBUG - 2012-08-06 19:25:37 --> Output Class Initialized
DEBUG - 2012-08-06 19:25:37 --> Security Class Initialized
DEBUG - 2012-08-06 19:25:37 --> Input Class Initialized
DEBUG - 2012-08-06 19:25:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:25:37 --> Language Class Initialized
DEBUG - 2012-08-06 19:25:37 --> Loader Class Initialized
DEBUG - 2012-08-06 19:25:37 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:25:37 --> Controller Class Initialized
DEBUG - 2012-08-06 19:25:37 --> Model Class Initialized
DEBUG - 2012-08-06 19:25:37 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:25:37 --> Helper loaded: language_helper
DEBUG - 2012-08-06 19:25:37 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:25:37 --> Form Validation Class Initialized
DEBUG - 2012-08-06 19:25:37 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 19:25:37 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 19:25:37 --> Final output sent to browser
DEBUG - 2012-08-06 19:25:37 --> Total execution time: 0.0379
DEBUG - 2012-08-06 19:27:10 --> Config Class Initialized
DEBUG - 2012-08-06 19:27:10 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:27:10 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:27:10 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:27:10 --> URI Class Initialized
DEBUG - 2012-08-06 19:27:10 --> Router Class Initialized
DEBUG - 2012-08-06 19:27:10 --> Output Class Initialized
DEBUG - 2012-08-06 19:27:10 --> Security Class Initialized
DEBUG - 2012-08-06 19:27:10 --> Input Class Initialized
DEBUG - 2012-08-06 19:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:27:10 --> Language Class Initialized
DEBUG - 2012-08-06 19:27:10 --> Loader Class Initialized
DEBUG - 2012-08-06 19:27:10 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:27:10 --> Controller Class Initialized
DEBUG - 2012-08-06 19:27:10 --> Model Class Initialized
DEBUG - 2012-08-06 19:27:10 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:27:10 --> Helper loaded: language_helper
DEBUG - 2012-08-06 19:27:10 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:27:10 --> Form Validation Class Initialized
DEBUG - 2012-08-06 19:27:10 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 19:27:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 19:27:10 --> Final output sent to browser
DEBUG - 2012-08-06 19:27:10 --> Total execution time: 0.0403
DEBUG - 2012-08-06 19:27:59 --> Config Class Initialized
DEBUG - 2012-08-06 19:27:59 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:27:59 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:27:59 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:27:59 --> URI Class Initialized
DEBUG - 2012-08-06 19:27:59 --> Router Class Initialized
DEBUG - 2012-08-06 19:27:59 --> Output Class Initialized
DEBUG - 2012-08-06 19:27:59 --> Security Class Initialized
DEBUG - 2012-08-06 19:27:59 --> Input Class Initialized
DEBUG - 2012-08-06 19:27:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:27:59 --> Language Class Initialized
DEBUG - 2012-08-06 19:27:59 --> Loader Class Initialized
DEBUG - 2012-08-06 19:27:59 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:27:59 --> Controller Class Initialized
DEBUG - 2012-08-06 19:27:59 --> Model Class Initialized
DEBUG - 2012-08-06 19:27:59 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:27:59 --> Helper loaded: language_helper
DEBUG - 2012-08-06 19:27:59 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:27:59 --> Form Validation Class Initialized
DEBUG - 2012-08-06 19:27:59 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 19:27:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 19:27:59 --> Final output sent to browser
DEBUG - 2012-08-06 19:27:59 --> Total execution time: 0.0374
DEBUG - 2012-08-06 19:28:31 --> Config Class Initialized
DEBUG - 2012-08-06 19:28:31 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:28:31 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:28:31 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:28:31 --> URI Class Initialized
DEBUG - 2012-08-06 19:28:31 --> Router Class Initialized
DEBUG - 2012-08-06 19:28:31 --> Output Class Initialized
DEBUG - 2012-08-06 19:28:31 --> Security Class Initialized
DEBUG - 2012-08-06 19:28:31 --> Input Class Initialized
DEBUG - 2012-08-06 19:28:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:28:31 --> Language Class Initialized
DEBUG - 2012-08-06 19:28:31 --> Loader Class Initialized
DEBUG - 2012-08-06 19:28:31 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:28:31 --> Controller Class Initialized
DEBUG - 2012-08-06 19:28:31 --> Model Class Initialized
DEBUG - 2012-08-06 19:28:31 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:28:32 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:28:32 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 19:28:32 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-08-06 19:28:32 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-08-06 19:28:32 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-08-06 19:28:32 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 19:28:32 --> Final output sent to browser
DEBUG - 2012-08-06 19:28:32 --> Total execution time: 0.0395
DEBUG - 2012-08-06 19:28:40 --> Config Class Initialized
DEBUG - 2012-08-06 19:28:40 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:28:40 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:28:40 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:28:40 --> URI Class Initialized
DEBUG - 2012-08-06 19:28:40 --> Router Class Initialized
DEBUG - 2012-08-06 19:28:40 --> Output Class Initialized
DEBUG - 2012-08-06 19:28:40 --> Security Class Initialized
DEBUG - 2012-08-06 19:28:40 --> Input Class Initialized
DEBUG - 2012-08-06 19:28:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:28:40 --> Language Class Initialized
DEBUG - 2012-08-06 19:28:40 --> Loader Class Initialized
DEBUG - 2012-08-06 19:28:40 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:28:40 --> Controller Class Initialized
DEBUG - 2012-08-06 19:28:40 --> Model Class Initialized
DEBUG - 2012-08-06 19:28:40 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:28:40 --> Helper loaded: language_helper
DEBUG - 2012-08-06 19:28:40 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:28:40 --> Form Validation Class Initialized
DEBUG - 2012-08-06 19:28:40 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 19:28:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 19:28:40 --> Final output sent to browser
DEBUG - 2012-08-06 19:28:40 --> Total execution time: 0.0374
DEBUG - 2012-08-06 19:30:26 --> Config Class Initialized
DEBUG - 2012-08-06 19:30:26 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:30:26 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:30:26 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:30:26 --> URI Class Initialized
DEBUG - 2012-08-06 19:30:26 --> Router Class Initialized
DEBUG - 2012-08-06 19:30:26 --> Output Class Initialized
DEBUG - 2012-08-06 19:30:26 --> Security Class Initialized
DEBUG - 2012-08-06 19:30:26 --> Input Class Initialized
DEBUG - 2012-08-06 19:30:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:30:26 --> Language Class Initialized
DEBUG - 2012-08-06 19:30:26 --> Loader Class Initialized
DEBUG - 2012-08-06 19:30:26 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:30:26 --> Controller Class Initialized
DEBUG - 2012-08-06 19:30:26 --> Model Class Initialized
DEBUG - 2012-08-06 19:30:26 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:30:26 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:30:26 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 19:30:26 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-08-06 19:30:26 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-08-06 19:30:26 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-08-06 19:30:26 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 19:30:26 --> Final output sent to browser
DEBUG - 2012-08-06 19:30:26 --> Total execution time: 0.0395
DEBUG - 2012-08-06 19:30:27 --> Config Class Initialized
DEBUG - 2012-08-06 19:30:27 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:30:27 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:30:27 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:30:27 --> URI Class Initialized
DEBUG - 2012-08-06 19:30:27 --> Router Class Initialized
ERROR - 2012-08-06 19:30:27 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 19:30:27 --> Config Class Initialized
DEBUG - 2012-08-06 19:30:27 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:30:27 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:30:27 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:30:27 --> URI Class Initialized
DEBUG - 2012-08-06 19:30:27 --> Router Class Initialized
ERROR - 2012-08-06 19:30:27 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 19:30:27 --> Config Class Initialized
DEBUG - 2012-08-06 19:30:27 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:30:27 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:30:27 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:30:27 --> URI Class Initialized
DEBUG - 2012-08-06 19:30:27 --> Router Class Initialized
ERROR - 2012-08-06 19:30:27 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 19:30:31 --> Config Class Initialized
DEBUG - 2012-08-06 19:30:31 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:30:31 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:30:31 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:30:31 --> URI Class Initialized
DEBUG - 2012-08-06 19:30:31 --> Router Class Initialized
DEBUG - 2012-08-06 19:30:31 --> Output Class Initialized
DEBUG - 2012-08-06 19:30:31 --> Security Class Initialized
DEBUG - 2012-08-06 19:30:31 --> Input Class Initialized
DEBUG - 2012-08-06 19:30:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:30:31 --> Language Class Initialized
DEBUG - 2012-08-06 19:30:31 --> Loader Class Initialized
DEBUG - 2012-08-06 19:30:31 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:30:31 --> Controller Class Initialized
DEBUG - 2012-08-06 19:30:31 --> Model Class Initialized
DEBUG - 2012-08-06 19:30:31 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:30:31 --> Helper loaded: language_helper
DEBUG - 2012-08-06 19:30:31 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:30:31 --> Form Validation Class Initialized
DEBUG - 2012-08-06 19:30:31 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 19:30:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 19:30:31 --> Final output sent to browser
DEBUG - 2012-08-06 19:30:31 --> Total execution time: 0.0373
DEBUG - 2012-08-06 19:30:53 --> Config Class Initialized
DEBUG - 2012-08-06 19:30:53 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:30:53 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:30:53 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:30:53 --> URI Class Initialized
DEBUG - 2012-08-06 19:30:53 --> Router Class Initialized
DEBUG - 2012-08-06 19:30:53 --> Output Class Initialized
DEBUG - 2012-08-06 19:30:53 --> Security Class Initialized
DEBUG - 2012-08-06 19:30:53 --> Input Class Initialized
DEBUG - 2012-08-06 19:30:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:30:53 --> Language Class Initialized
DEBUG - 2012-08-06 19:30:53 --> Loader Class Initialized
DEBUG - 2012-08-06 19:30:53 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:30:53 --> Controller Class Initialized
DEBUG - 2012-08-06 19:30:53 --> Model Class Initialized
DEBUG - 2012-08-06 19:30:53 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:30:53 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:30:53 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 19:30:53 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-08-06 19:30:53 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-08-06 19:30:53 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-08-06 19:30:53 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 19:30:53 --> Final output sent to browser
DEBUG - 2012-08-06 19:30:53 --> Total execution time: 0.0395
DEBUG - 2012-08-06 19:30:55 --> Config Class Initialized
DEBUG - 2012-08-06 19:30:55 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:30:55 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:30:55 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:30:55 --> URI Class Initialized
DEBUG - 2012-08-06 19:30:55 --> Router Class Initialized
ERROR - 2012-08-06 19:30:55 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 19:30:55 --> Config Class Initialized
DEBUG - 2012-08-06 19:30:55 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:30:55 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:30:55 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:30:55 --> URI Class Initialized
DEBUG - 2012-08-06 19:30:55 --> Router Class Initialized
ERROR - 2012-08-06 19:30:55 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 19:30:55 --> Config Class Initialized
DEBUG - 2012-08-06 19:30:55 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:30:55 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:30:55 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:30:55 --> URI Class Initialized
DEBUG - 2012-08-06 19:30:55 --> Router Class Initialized
ERROR - 2012-08-06 19:30:55 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 19:30:58 --> Config Class Initialized
DEBUG - 2012-08-06 19:30:58 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:30:58 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:30:58 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:30:58 --> URI Class Initialized
DEBUG - 2012-08-06 19:30:58 --> Router Class Initialized
DEBUG - 2012-08-06 19:30:58 --> Output Class Initialized
DEBUG - 2012-08-06 19:30:58 --> Security Class Initialized
DEBUG - 2012-08-06 19:30:58 --> Input Class Initialized
DEBUG - 2012-08-06 19:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:30:58 --> Language Class Initialized
DEBUG - 2012-08-06 19:30:58 --> Loader Class Initialized
DEBUG - 2012-08-06 19:30:58 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:30:58 --> Controller Class Initialized
DEBUG - 2012-08-06 19:30:58 --> Model Class Initialized
DEBUG - 2012-08-06 19:30:58 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:30:58 --> Helper loaded: language_helper
DEBUG - 2012-08-06 19:30:58 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:30:58 --> Form Validation Class Initialized
DEBUG - 2012-08-06 19:30:58 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 19:30:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 19:30:58 --> Final output sent to browser
DEBUG - 2012-08-06 19:30:58 --> Total execution time: 0.0375
DEBUG - 2012-08-06 19:32:09 --> Config Class Initialized
DEBUG - 2012-08-06 19:32:09 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:32:09 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:32:09 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:32:09 --> URI Class Initialized
DEBUG - 2012-08-06 19:32:09 --> Router Class Initialized
DEBUG - 2012-08-06 19:32:09 --> Output Class Initialized
DEBUG - 2012-08-06 19:32:09 --> Security Class Initialized
DEBUG - 2012-08-06 19:32:09 --> Input Class Initialized
DEBUG - 2012-08-06 19:32:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:32:09 --> Language Class Initialized
DEBUG - 2012-08-06 19:32:09 --> Loader Class Initialized
DEBUG - 2012-08-06 19:32:09 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:32:09 --> Controller Class Initialized
DEBUG - 2012-08-06 19:32:09 --> Model Class Initialized
DEBUG - 2012-08-06 19:32:09 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:32:09 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:32:10 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 19:32:10 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-08-06 19:32:10 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-08-06 19:32:10 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-08-06 19:32:10 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 19:32:10 --> Final output sent to browser
DEBUG - 2012-08-06 19:32:10 --> Total execution time: 0.0438
DEBUG - 2012-08-06 19:32:11 --> Config Class Initialized
DEBUG - 2012-08-06 19:32:11 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:32:11 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:32:11 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:32:11 --> URI Class Initialized
DEBUG - 2012-08-06 19:32:11 --> Router Class Initialized
ERROR - 2012-08-06 19:32:11 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 19:32:11 --> Config Class Initialized
DEBUG - 2012-08-06 19:32:11 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:32:11 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:32:11 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:32:11 --> URI Class Initialized
DEBUG - 2012-08-06 19:32:11 --> Router Class Initialized
ERROR - 2012-08-06 19:32:11 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 19:32:11 --> Config Class Initialized
DEBUG - 2012-08-06 19:32:11 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:32:11 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:32:11 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:32:11 --> URI Class Initialized
DEBUG - 2012-08-06 19:32:11 --> Router Class Initialized
ERROR - 2012-08-06 19:32:11 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 19:32:13 --> Config Class Initialized
DEBUG - 2012-08-06 19:32:13 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:32:13 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:32:13 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:32:13 --> URI Class Initialized
DEBUG - 2012-08-06 19:32:13 --> Router Class Initialized
DEBUG - 2012-08-06 19:32:13 --> Output Class Initialized
DEBUG - 2012-08-06 19:32:13 --> Security Class Initialized
DEBUG - 2012-08-06 19:32:13 --> Input Class Initialized
DEBUG - 2012-08-06 19:32:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:32:13 --> Language Class Initialized
DEBUG - 2012-08-06 19:32:13 --> Loader Class Initialized
DEBUG - 2012-08-06 19:32:13 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:32:13 --> Controller Class Initialized
DEBUG - 2012-08-06 19:32:13 --> Model Class Initialized
DEBUG - 2012-08-06 19:32:13 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:32:13 --> Helper loaded: language_helper
DEBUG - 2012-08-06 19:32:13 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:32:13 --> Form Validation Class Initialized
DEBUG - 2012-08-06 19:32:13 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 19:32:13 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 19:32:13 --> Final output sent to browser
DEBUG - 2012-08-06 19:32:13 --> Total execution time: 0.0377
DEBUG - 2012-08-06 19:33:46 --> Config Class Initialized
DEBUG - 2012-08-06 19:33:46 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:33:46 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:33:46 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:33:46 --> URI Class Initialized
DEBUG - 2012-08-06 19:33:46 --> Router Class Initialized
DEBUG - 2012-08-06 19:33:46 --> Output Class Initialized
DEBUG - 2012-08-06 19:33:46 --> Security Class Initialized
DEBUG - 2012-08-06 19:33:46 --> Input Class Initialized
DEBUG - 2012-08-06 19:33:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:33:46 --> Language Class Initialized
DEBUG - 2012-08-06 19:33:46 --> Loader Class Initialized
DEBUG - 2012-08-06 19:33:46 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:33:46 --> Controller Class Initialized
DEBUG - 2012-08-06 19:33:46 --> Model Class Initialized
DEBUG - 2012-08-06 19:33:46 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:33:46 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:33:46 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 19:33:46 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-08-06 19:33:46 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-08-06 19:33:46 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-08-06 19:33:46 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 19:33:46 --> Final output sent to browser
DEBUG - 2012-08-06 19:33:46 --> Total execution time: 0.0451
DEBUG - 2012-08-06 19:33:47 --> Config Class Initialized
DEBUG - 2012-08-06 19:33:47 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:33:47 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:33:47 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:33:47 --> URI Class Initialized
DEBUG - 2012-08-06 19:33:47 --> Router Class Initialized
ERROR - 2012-08-06 19:33:47 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 19:33:47 --> Config Class Initialized
DEBUG - 2012-08-06 19:33:47 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:33:47 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:33:47 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:33:47 --> URI Class Initialized
DEBUG - 2012-08-06 19:33:47 --> Router Class Initialized
ERROR - 2012-08-06 19:33:47 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 19:33:47 --> Config Class Initialized
DEBUG - 2012-08-06 19:33:47 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:33:47 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:33:47 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:33:47 --> URI Class Initialized
DEBUG - 2012-08-06 19:33:47 --> Router Class Initialized
ERROR - 2012-08-06 19:33:47 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 19:34:09 --> Config Class Initialized
DEBUG - 2012-08-06 19:34:09 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:34:09 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:34:09 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:34:09 --> URI Class Initialized
DEBUG - 2012-08-06 19:34:09 --> Router Class Initialized
DEBUG - 2012-08-06 19:34:09 --> Output Class Initialized
DEBUG - 2012-08-06 19:34:09 --> Security Class Initialized
DEBUG - 2012-08-06 19:34:09 --> Input Class Initialized
DEBUG - 2012-08-06 19:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:34:09 --> Language Class Initialized
DEBUG - 2012-08-06 19:34:09 --> Loader Class Initialized
DEBUG - 2012-08-06 19:34:09 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:34:09 --> Controller Class Initialized
DEBUG - 2012-08-06 19:34:09 --> Model Class Initialized
DEBUG - 2012-08-06 19:34:09 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:34:09 --> Helper loaded: language_helper
DEBUG - 2012-08-06 19:34:09 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:34:09 --> Form Validation Class Initialized
DEBUG - 2012-08-06 19:34:09 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 19:34:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 19:34:09 --> Final output sent to browser
DEBUG - 2012-08-06 19:34:09 --> Total execution time: 0.0377
DEBUG - 2012-08-06 19:34:21 --> Config Class Initialized
DEBUG - 2012-08-06 19:34:21 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:34:21 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:34:21 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:34:21 --> URI Class Initialized
DEBUG - 2012-08-06 19:34:21 --> Router Class Initialized
DEBUG - 2012-08-06 19:34:21 --> Output Class Initialized
DEBUG - 2012-08-06 19:34:21 --> Security Class Initialized
DEBUG - 2012-08-06 19:34:21 --> Input Class Initialized
DEBUG - 2012-08-06 19:34:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:34:21 --> Language Class Initialized
DEBUG - 2012-08-06 19:34:21 --> Loader Class Initialized
DEBUG - 2012-08-06 19:34:21 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:34:21 --> Controller Class Initialized
DEBUG - 2012-08-06 19:34:21 --> Model Class Initialized
DEBUG - 2012-08-06 19:34:21 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:34:21 --> Helper loaded: language_helper
DEBUG - 2012-08-06 19:34:21 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:34:21 --> Form Validation Class Initialized
DEBUG - 2012-08-06 19:34:21 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 19:34:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 19:34:21 --> Final output sent to browser
DEBUG - 2012-08-06 19:34:21 --> Total execution time: 0.1274
DEBUG - 2012-08-06 19:36:56 --> Config Class Initialized
DEBUG - 2012-08-06 19:36:56 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:36:56 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:36:56 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:36:56 --> URI Class Initialized
DEBUG - 2012-08-06 19:36:56 --> Router Class Initialized
DEBUG - 2012-08-06 19:36:56 --> Output Class Initialized
DEBUG - 2012-08-06 19:36:56 --> Security Class Initialized
DEBUG - 2012-08-06 19:36:56 --> Input Class Initialized
DEBUG - 2012-08-06 19:36:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:36:56 --> Language Class Initialized
DEBUG - 2012-08-06 19:36:56 --> Loader Class Initialized
DEBUG - 2012-08-06 19:36:56 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:36:56 --> Controller Class Initialized
DEBUG - 2012-08-06 19:36:56 --> Model Class Initialized
DEBUG - 2012-08-06 19:36:56 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:36:56 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:36:56 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 19:36:56 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-08-06 19:36:56 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-08-06 19:36:56 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-08-06 19:36:56 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 19:36:56 --> Final output sent to browser
DEBUG - 2012-08-06 19:36:56 --> Total execution time: 0.0389
DEBUG - 2012-08-06 19:37:01 --> Config Class Initialized
DEBUG - 2012-08-06 19:37:01 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:37:01 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:37:01 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:37:01 --> URI Class Initialized
DEBUG - 2012-08-06 19:37:01 --> Router Class Initialized
DEBUG - 2012-08-06 19:37:01 --> Output Class Initialized
DEBUG - 2012-08-06 19:37:01 --> Security Class Initialized
DEBUG - 2012-08-06 19:37:01 --> Input Class Initialized
DEBUG - 2012-08-06 19:37:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:37:01 --> Language Class Initialized
DEBUG - 2012-08-06 19:37:01 --> Loader Class Initialized
DEBUG - 2012-08-06 19:37:01 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:37:01 --> Controller Class Initialized
DEBUG - 2012-08-06 19:37:01 --> Model Class Initialized
DEBUG - 2012-08-06 19:37:01 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:37:01 --> Helper loaded: language_helper
DEBUG - 2012-08-06 19:37:01 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:37:01 --> Form Validation Class Initialized
DEBUG - 2012-08-06 19:37:01 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 19:37:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 19:37:01 --> Final output sent to browser
DEBUG - 2012-08-06 19:37:01 --> Total execution time: 0.0391
DEBUG - 2012-08-06 19:37:08 --> Config Class Initialized
DEBUG - 2012-08-06 19:37:08 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:37:08 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:37:08 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:37:08 --> URI Class Initialized
DEBUG - 2012-08-06 19:37:08 --> Router Class Initialized
DEBUG - 2012-08-06 19:37:08 --> Output Class Initialized
DEBUG - 2012-08-06 19:37:08 --> Security Class Initialized
DEBUG - 2012-08-06 19:37:08 --> Input Class Initialized
DEBUG - 2012-08-06 19:37:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:37:08 --> Language Class Initialized
DEBUG - 2012-08-06 19:37:08 --> Loader Class Initialized
DEBUG - 2012-08-06 19:37:08 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:37:08 --> Controller Class Initialized
DEBUG - 2012-08-06 19:37:08 --> Model Class Initialized
DEBUG - 2012-08-06 19:37:08 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:37:08 --> Helper loaded: language_helper
DEBUG - 2012-08-06 19:37:08 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:37:08 --> Form Validation Class Initialized
DEBUG - 2012-08-06 19:37:08 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 19:37:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 19:37:08 --> Final output sent to browser
DEBUG - 2012-08-06 19:37:08 --> Total execution time: 0.0415
DEBUG - 2012-08-06 19:37:28 --> Config Class Initialized
DEBUG - 2012-08-06 19:37:28 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:37:28 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:37:28 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:37:28 --> URI Class Initialized
DEBUG - 2012-08-06 19:37:29 --> Router Class Initialized
DEBUG - 2012-08-06 19:37:29 --> Output Class Initialized
DEBUG - 2012-08-06 19:37:29 --> Security Class Initialized
DEBUG - 2012-08-06 19:37:29 --> Input Class Initialized
DEBUG - 2012-08-06 19:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:37:29 --> Language Class Initialized
DEBUG - 2012-08-06 19:37:29 --> Loader Class Initialized
DEBUG - 2012-08-06 19:37:29 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:37:29 --> Controller Class Initialized
DEBUG - 2012-08-06 19:37:29 --> Model Class Initialized
DEBUG - 2012-08-06 19:37:29 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:37:29 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:37:29 --> Form Validation Class Initialized
DEBUG - 2012-08-06 19:37:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 19:37:29 --> Final output sent to browser
DEBUG - 2012-08-06 19:37:29 --> Total execution time: 0.0374
DEBUG - 2012-08-06 19:37:41 --> Config Class Initialized
DEBUG - 2012-08-06 19:37:41 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:37:41 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:37:41 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:37:41 --> URI Class Initialized
DEBUG - 2012-08-06 19:37:41 --> Router Class Initialized
DEBUG - 2012-08-06 19:37:41 --> Output Class Initialized
DEBUG - 2012-08-06 19:37:41 --> Security Class Initialized
DEBUG - 2012-08-06 19:37:41 --> Input Class Initialized
DEBUG - 2012-08-06 19:37:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:37:41 --> Language Class Initialized
DEBUG - 2012-08-06 19:37:41 --> Loader Class Initialized
DEBUG - 2012-08-06 19:37:41 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:37:41 --> Controller Class Initialized
DEBUG - 2012-08-06 19:37:41 --> Model Class Initialized
DEBUG - 2012-08-06 19:37:41 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:37:41 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:37:41 --> Form Validation Class Initialized
DEBUG - 2012-08-06 19:37:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 19:37:41 --> Final output sent to browser
DEBUG - 2012-08-06 19:37:41 --> Total execution time: 0.0388
DEBUG - 2012-08-06 19:45:45 --> Config Class Initialized
DEBUG - 2012-08-06 19:45:45 --> Hooks Class Initialized
DEBUG - 2012-08-06 19:45:45 --> Utf8 Class Initialized
DEBUG - 2012-08-06 19:45:45 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 19:45:45 --> URI Class Initialized
DEBUG - 2012-08-06 19:45:45 --> Router Class Initialized
DEBUG - 2012-08-06 19:45:45 --> Output Class Initialized
DEBUG - 2012-08-06 19:45:45 --> Security Class Initialized
DEBUG - 2012-08-06 19:45:45 --> Input Class Initialized
DEBUG - 2012-08-06 19:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 19:45:45 --> Language Class Initialized
DEBUG - 2012-08-06 19:45:45 --> Loader Class Initialized
DEBUG - 2012-08-06 19:45:45 --> Helper loaded: url_helper
DEBUG - 2012-08-06 19:45:45 --> Controller Class Initialized
DEBUG - 2012-08-06 19:45:45 --> Model Class Initialized
DEBUG - 2012-08-06 19:45:45 --> Database Driver Class Initialized
DEBUG - 2012-08-06 19:45:45 --> Helper loaded: form_helper
DEBUG - 2012-08-06 19:45:45 --> Form Validation Class Initialized
DEBUG - 2012-08-06 19:45:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 19:45:45 --> Final output sent to browser
DEBUG - 2012-08-06 19:45:45 --> Total execution time: 0.0383
DEBUG - 2012-08-06 20:02:06 --> Config Class Initialized
DEBUG - 2012-08-06 20:02:06 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:02:06 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:02:06 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:02:06 --> URI Class Initialized
DEBUG - 2012-08-06 20:02:06 --> Router Class Initialized
DEBUG - 2012-08-06 20:02:06 --> Output Class Initialized
DEBUG - 2012-08-06 20:02:06 --> Security Class Initialized
DEBUG - 2012-08-06 20:02:06 --> Input Class Initialized
DEBUG - 2012-08-06 20:02:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:02:06 --> Language Class Initialized
DEBUG - 2012-08-06 20:02:06 --> Loader Class Initialized
DEBUG - 2012-08-06 20:02:06 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:02:06 --> Controller Class Initialized
DEBUG - 2012-08-06 20:02:06 --> Model Class Initialized
DEBUG - 2012-08-06 20:02:06 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:02:06 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:02:06 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 20:02:06 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-08-06 20:02:06 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-08-06 20:02:06 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-08-06 20:02:06 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 20:02:06 --> Final output sent to browser
DEBUG - 2012-08-06 20:02:06 --> Total execution time: 0.0504
DEBUG - 2012-08-06 20:02:18 --> Config Class Initialized
DEBUG - 2012-08-06 20:02:18 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:02:18 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:02:18 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:02:18 --> URI Class Initialized
DEBUG - 2012-08-06 20:02:18 --> Router Class Initialized
DEBUG - 2012-08-06 20:02:18 --> Output Class Initialized
DEBUG - 2012-08-06 20:02:18 --> Security Class Initialized
DEBUG - 2012-08-06 20:02:18 --> Input Class Initialized
DEBUG - 2012-08-06 20:02:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:02:18 --> Language Class Initialized
DEBUG - 2012-08-06 20:02:18 --> Loader Class Initialized
DEBUG - 2012-08-06 20:02:18 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:02:18 --> Controller Class Initialized
DEBUG - 2012-08-06 20:02:18 --> Model Class Initialized
DEBUG - 2012-08-06 20:02:18 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:02:18 --> Helper loaded: language_helper
DEBUG - 2012-08-06 20:02:18 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:02:18 --> Form Validation Class Initialized
DEBUG - 2012-08-06 20:02:18 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 20:02:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 20:02:18 --> Final output sent to browser
DEBUG - 2012-08-06 20:02:18 --> Total execution time: 0.0386
DEBUG - 2012-08-06 20:02:30 --> Config Class Initialized
DEBUG - 2012-08-06 20:02:30 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:02:30 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:02:30 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:02:30 --> URI Class Initialized
DEBUG - 2012-08-06 20:02:30 --> Router Class Initialized
DEBUG - 2012-08-06 20:02:30 --> Output Class Initialized
DEBUG - 2012-08-06 20:02:30 --> Security Class Initialized
DEBUG - 2012-08-06 20:02:30 --> Input Class Initialized
DEBUG - 2012-08-06 20:02:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:02:30 --> Language Class Initialized
DEBUG - 2012-08-06 20:02:30 --> Loader Class Initialized
DEBUG - 2012-08-06 20:02:30 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:02:30 --> Controller Class Initialized
DEBUG - 2012-08-06 20:02:30 --> Model Class Initialized
DEBUG - 2012-08-06 20:02:30 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:02:30 --> Helper loaded: language_helper
DEBUG - 2012-08-06 20:02:30 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:02:30 --> Form Validation Class Initialized
DEBUG - 2012-08-06 20:02:30 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 20:02:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 20:02:30 --> Final output sent to browser
DEBUG - 2012-08-06 20:02:30 --> Total execution time: 0.0420
DEBUG - 2012-08-06 20:02:40 --> Config Class Initialized
DEBUG - 2012-08-06 20:02:40 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:02:40 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:02:40 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:02:40 --> URI Class Initialized
DEBUG - 2012-08-06 20:02:40 --> Router Class Initialized
DEBUG - 2012-08-06 20:02:40 --> Output Class Initialized
DEBUG - 2012-08-06 20:02:40 --> Security Class Initialized
DEBUG - 2012-08-06 20:02:40 --> Input Class Initialized
DEBUG - 2012-08-06 20:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:02:40 --> Language Class Initialized
DEBUG - 2012-08-06 20:02:40 --> Loader Class Initialized
DEBUG - 2012-08-06 20:02:40 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:02:40 --> Controller Class Initialized
DEBUG - 2012-08-06 20:02:40 --> Model Class Initialized
DEBUG - 2012-08-06 20:02:40 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:02:40 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:02:40 --> Form Validation Class Initialized
DEBUG - 2012-08-06 20:02:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 20:02:40 --> Final output sent to browser
DEBUG - 2012-08-06 20:02:40 --> Total execution time: 0.2421
DEBUG - 2012-08-06 20:02:54 --> Config Class Initialized
DEBUG - 2012-08-06 20:02:54 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:02:54 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:02:54 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:02:54 --> URI Class Initialized
DEBUG - 2012-08-06 20:02:54 --> Router Class Initialized
DEBUG - 2012-08-06 20:02:54 --> Output Class Initialized
DEBUG - 2012-08-06 20:02:54 --> Security Class Initialized
DEBUG - 2012-08-06 20:02:54 --> Input Class Initialized
DEBUG - 2012-08-06 20:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:02:54 --> Language Class Initialized
DEBUG - 2012-08-06 20:02:54 --> Loader Class Initialized
DEBUG - 2012-08-06 20:02:54 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:02:54 --> Controller Class Initialized
DEBUG - 2012-08-06 20:02:54 --> Model Class Initialized
DEBUG - 2012-08-06 20:02:54 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:02:54 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:02:54 --> Form Validation Class Initialized
DEBUG - 2012-08-06 20:02:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 20:02:54 --> Final output sent to browser
DEBUG - 2012-08-06 20:02:54 --> Total execution time: 0.0780
DEBUG - 2012-08-06 20:03:10 --> Config Class Initialized
DEBUG - 2012-08-06 20:03:10 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:03:10 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:03:10 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:03:10 --> URI Class Initialized
DEBUG - 2012-08-06 20:03:10 --> Router Class Initialized
DEBUG - 2012-08-06 20:03:10 --> Output Class Initialized
DEBUG - 2012-08-06 20:03:10 --> Security Class Initialized
DEBUG - 2012-08-06 20:03:10 --> Input Class Initialized
DEBUG - 2012-08-06 20:03:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:03:10 --> Language Class Initialized
DEBUG - 2012-08-06 20:03:10 --> Loader Class Initialized
DEBUG - 2012-08-06 20:03:10 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:03:10 --> Controller Class Initialized
DEBUG - 2012-08-06 20:03:10 --> Model Class Initialized
DEBUG - 2012-08-06 20:03:10 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:03:10 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:03:10 --> Form Validation Class Initialized
DEBUG - 2012-08-06 20:03:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 20:03:10 --> Final output sent to browser
DEBUG - 2012-08-06 20:03:10 --> Total execution time: 0.0392
DEBUG - 2012-08-06 20:04:04 --> Config Class Initialized
DEBUG - 2012-08-06 20:04:04 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:04:04 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:04:04 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:04:04 --> URI Class Initialized
DEBUG - 2012-08-06 20:04:04 --> Router Class Initialized
DEBUG - 2012-08-06 20:04:04 --> Output Class Initialized
DEBUG - 2012-08-06 20:04:04 --> Security Class Initialized
DEBUG - 2012-08-06 20:04:04 --> Input Class Initialized
DEBUG - 2012-08-06 20:04:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:04:04 --> Language Class Initialized
DEBUG - 2012-08-06 20:04:04 --> Loader Class Initialized
DEBUG - 2012-08-06 20:04:04 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:04:04 --> Controller Class Initialized
DEBUG - 2012-08-06 20:04:04 --> Model Class Initialized
DEBUG - 2012-08-06 20:04:04 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:04:04 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:04:04 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 20:04:04 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-08-06 20:04:04 --> File loaded: application/views/admin/templates/left_menu.php
ERROR - 2012-08-06 20:04:04 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 62
ERROR - 2012-08-06 20:04:04 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 64
ERROR - 2012-08-06 20:04:04 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 64
ERROR - 2012-08-06 20:04:04 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 64
DEBUG - 2012-08-06 20:04:04 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-08-06 20:04:04 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 20:04:04 --> Final output sent to browser
DEBUG - 2012-08-06 20:04:04 --> Total execution time: 0.0418
DEBUG - 2012-08-06 20:36:48 --> Config Class Initialized
DEBUG - 2012-08-06 20:36:48 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:36:48 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:36:48 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:36:48 --> URI Class Initialized
DEBUG - 2012-08-06 20:36:48 --> Router Class Initialized
DEBUG - 2012-08-06 20:36:48 --> Output Class Initialized
DEBUG - 2012-08-06 20:36:48 --> Security Class Initialized
DEBUG - 2012-08-06 20:36:48 --> Input Class Initialized
DEBUG - 2012-08-06 20:36:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:36:48 --> Language Class Initialized
DEBUG - 2012-08-06 20:36:50 --> Config Class Initialized
DEBUG - 2012-08-06 20:36:50 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:36:50 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:36:50 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:36:50 --> URI Class Initialized
DEBUG - 2012-08-06 20:36:50 --> Router Class Initialized
DEBUG - 2012-08-06 20:36:50 --> Output Class Initialized
DEBUG - 2012-08-06 20:36:50 --> Security Class Initialized
DEBUG - 2012-08-06 20:36:50 --> Input Class Initialized
DEBUG - 2012-08-06 20:36:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:36:50 --> Language Class Initialized
DEBUG - 2012-08-06 20:38:08 --> Config Class Initialized
DEBUG - 2012-08-06 20:38:08 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:38:08 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:38:08 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:38:08 --> URI Class Initialized
DEBUG - 2012-08-06 20:38:08 --> Router Class Initialized
DEBUG - 2012-08-06 20:38:08 --> Output Class Initialized
DEBUG - 2012-08-06 20:38:08 --> Security Class Initialized
DEBUG - 2012-08-06 20:38:08 --> Input Class Initialized
DEBUG - 2012-08-06 20:38:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:38:08 --> Language Class Initialized
DEBUG - 2012-08-06 20:38:08 --> Loader Class Initialized
DEBUG - 2012-08-06 20:38:08 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:38:08 --> Controller Class Initialized
DEBUG - 2012-08-06 20:38:08 --> Model Class Initialized
DEBUG - 2012-08-06 20:38:08 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:38:08 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:38:08 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 20:38:08 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-08-06 20:38:08 --> File loaded: application/views/admin/templates/left_menu.php
ERROR - 2012-08-06 20:38:08 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 71
ERROR - 2012-08-06 20:38:08 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 74
ERROR - 2012-08-06 20:38:08 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 74
ERROR - 2012-08-06 20:38:08 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 74
DEBUG - 2012-08-06 20:38:08 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-08-06 20:38:08 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 20:38:08 --> Final output sent to browser
DEBUG - 2012-08-06 20:38:08 --> Total execution time: 0.0421
DEBUG - 2012-08-06 20:38:09 --> Config Class Initialized
DEBUG - 2012-08-06 20:38:09 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:38:09 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:38:09 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:38:09 --> URI Class Initialized
DEBUG - 2012-08-06 20:38:09 --> Router Class Initialized
ERROR - 2012-08-06 20:38:09 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 20:38:10 --> Config Class Initialized
DEBUG - 2012-08-06 20:38:10 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:38:10 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:38:10 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:38:10 --> URI Class Initialized
DEBUG - 2012-08-06 20:38:10 --> Router Class Initialized
ERROR - 2012-08-06 20:38:10 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 20:38:10 --> Config Class Initialized
DEBUG - 2012-08-06 20:38:10 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:38:10 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:38:10 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:38:10 --> URI Class Initialized
DEBUG - 2012-08-06 20:38:10 --> Router Class Initialized
ERROR - 2012-08-06 20:38:10 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 20:39:10 --> Config Class Initialized
DEBUG - 2012-08-06 20:39:10 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:39:10 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:39:10 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:39:10 --> URI Class Initialized
DEBUG - 2012-08-06 20:39:10 --> Router Class Initialized
DEBUG - 2012-08-06 20:39:10 --> Output Class Initialized
DEBUG - 2012-08-06 20:39:10 --> Security Class Initialized
DEBUG - 2012-08-06 20:39:10 --> Input Class Initialized
DEBUG - 2012-08-06 20:39:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:39:10 --> Language Class Initialized
DEBUG - 2012-08-06 20:39:10 --> Loader Class Initialized
DEBUG - 2012-08-06 20:39:10 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:39:10 --> Controller Class Initialized
DEBUG - 2012-08-06 20:39:10 --> Model Class Initialized
DEBUG - 2012-08-06 20:39:10 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:39:10 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:39:10 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 20:39:10 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-08-06 20:39:10 --> File loaded: application/views/admin/templates/left_menu.php
ERROR - 2012-08-06 20:39:10 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 71
ERROR - 2012-08-06 20:39:10 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 74
ERROR - 2012-08-06 20:39:10 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 74
ERROR - 2012-08-06 20:39:10 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 74
DEBUG - 2012-08-06 20:39:10 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-08-06 20:39:10 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 20:39:10 --> Final output sent to browser
DEBUG - 2012-08-06 20:39:10 --> Total execution time: 0.0409
DEBUG - 2012-08-06 20:39:26 --> Config Class Initialized
DEBUG - 2012-08-06 20:39:26 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:39:26 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:39:26 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:39:26 --> URI Class Initialized
DEBUG - 2012-08-06 20:39:26 --> Router Class Initialized
DEBUG - 2012-08-06 20:39:26 --> Output Class Initialized
DEBUG - 2012-08-06 20:39:26 --> Security Class Initialized
DEBUG - 2012-08-06 20:39:26 --> Input Class Initialized
DEBUG - 2012-08-06 20:39:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:39:26 --> Language Class Initialized
DEBUG - 2012-08-06 20:39:26 --> Loader Class Initialized
DEBUG - 2012-08-06 20:39:26 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:39:26 --> Controller Class Initialized
DEBUG - 2012-08-06 20:39:26 --> Model Class Initialized
DEBUG - 2012-08-06 20:39:26 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:39:26 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:39:26 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 20:39:26 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-08-06 20:39:26 --> File loaded: application/views/admin/templates/left_menu.php
ERROR - 2012-08-06 20:39:26 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 71
ERROR - 2012-08-06 20:39:26 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 74
ERROR - 2012-08-06 20:39:26 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 74
ERROR - 2012-08-06 20:39:26 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 74
DEBUG - 2012-08-06 20:39:26 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-08-06 20:39:26 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 20:39:26 --> Final output sent to browser
DEBUG - 2012-08-06 20:39:26 --> Total execution time: 0.0413
DEBUG - 2012-08-06 20:41:21 --> Config Class Initialized
DEBUG - 2012-08-06 20:41:21 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:41:21 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:41:21 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:41:21 --> URI Class Initialized
DEBUG - 2012-08-06 20:41:21 --> Router Class Initialized
DEBUG - 2012-08-06 20:41:21 --> Output Class Initialized
DEBUG - 2012-08-06 20:41:21 --> Security Class Initialized
DEBUG - 2012-08-06 20:41:21 --> Input Class Initialized
DEBUG - 2012-08-06 20:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:41:21 --> Language Class Initialized
DEBUG - 2012-08-06 20:41:21 --> Loader Class Initialized
DEBUG - 2012-08-06 20:41:21 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:41:21 --> Controller Class Initialized
DEBUG - 2012-08-06 20:41:22 --> Model Class Initialized
DEBUG - 2012-08-06 20:41:22 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:41:22 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:41:22 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 20:41:22 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-08-06 20:41:22 --> File loaded: application/views/admin/templates/left_menu.php
ERROR - 2012-08-06 20:41:22 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 71
ERROR - 2012-08-06 20:41:22 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 74
ERROR - 2012-08-06 20:41:22 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 74
ERROR - 2012-08-06 20:41:22 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/business/business.php 74
DEBUG - 2012-08-06 20:41:22 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-08-06 20:41:22 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 20:41:22 --> Final output sent to browser
DEBUG - 2012-08-06 20:41:22 --> Total execution time: 0.0408
DEBUG - 2012-08-06 20:44:45 --> Config Class Initialized
DEBUG - 2012-08-06 20:44:45 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:44:45 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:44:45 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:44:45 --> URI Class Initialized
DEBUG - 2012-08-06 20:44:45 --> Router Class Initialized
DEBUG - 2012-08-06 20:44:45 --> Output Class Initialized
DEBUG - 2012-08-06 20:44:45 --> Security Class Initialized
DEBUG - 2012-08-06 20:44:45 --> Input Class Initialized
DEBUG - 2012-08-06 20:44:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:44:45 --> Language Class Initialized
DEBUG - 2012-08-06 20:44:45 --> Loader Class Initialized
DEBUG - 2012-08-06 20:44:45 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:44:45 --> Controller Class Initialized
DEBUG - 2012-08-06 20:44:45 --> Model Class Initialized
DEBUG - 2012-08-06 20:44:45 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:44:45 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:46:40 --> Config Class Initialized
DEBUG - 2012-08-06 20:46:40 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:46:40 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:46:40 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:46:40 --> URI Class Initialized
DEBUG - 2012-08-06 20:46:40 --> Router Class Initialized
DEBUG - 2012-08-06 20:46:40 --> Output Class Initialized
DEBUG - 2012-08-06 20:46:40 --> Security Class Initialized
DEBUG - 2012-08-06 20:46:40 --> Input Class Initialized
DEBUG - 2012-08-06 20:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:46:40 --> Language Class Initialized
DEBUG - 2012-08-06 20:46:40 --> Loader Class Initialized
DEBUG - 2012-08-06 20:46:40 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:46:40 --> Controller Class Initialized
DEBUG - 2012-08-06 20:46:40 --> Model Class Initialized
DEBUG - 2012-08-06 20:46:40 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:46:40 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:47:08 --> Config Class Initialized
DEBUG - 2012-08-06 20:47:08 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:47:08 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:47:08 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:47:08 --> URI Class Initialized
DEBUG - 2012-08-06 20:47:08 --> Router Class Initialized
DEBUG - 2012-08-06 20:47:08 --> Output Class Initialized
DEBUG - 2012-08-06 20:47:08 --> Security Class Initialized
DEBUG - 2012-08-06 20:47:08 --> Input Class Initialized
DEBUG - 2012-08-06 20:47:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:47:08 --> Language Class Initialized
DEBUG - 2012-08-06 20:47:08 --> Loader Class Initialized
DEBUG - 2012-08-06 20:47:08 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:47:08 --> Controller Class Initialized
DEBUG - 2012-08-06 20:47:08 --> Model Class Initialized
DEBUG - 2012-08-06 20:47:08 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:47:08 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:47:27 --> Config Class Initialized
DEBUG - 2012-08-06 20:47:27 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:47:27 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:47:27 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:47:27 --> URI Class Initialized
DEBUG - 2012-08-06 20:47:27 --> Router Class Initialized
DEBUG - 2012-08-06 20:47:27 --> Output Class Initialized
DEBUG - 2012-08-06 20:47:27 --> Security Class Initialized
DEBUG - 2012-08-06 20:47:27 --> Input Class Initialized
DEBUG - 2012-08-06 20:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:47:27 --> Language Class Initialized
DEBUG - 2012-08-06 20:47:27 --> Loader Class Initialized
DEBUG - 2012-08-06 20:47:27 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:47:27 --> Controller Class Initialized
DEBUG - 2012-08-06 20:47:27 --> Model Class Initialized
DEBUG - 2012-08-06 20:47:27 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:47:27 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:47:27 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 20:47:27 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-08-06 20:47:27 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-08-06 20:47:27 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-08-06 20:47:27 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 20:47:27 --> Final output sent to browser
DEBUG - 2012-08-06 20:47:27 --> Total execution time: 0.0404
DEBUG - 2012-08-06 20:47:49 --> Config Class Initialized
DEBUG - 2012-08-06 20:47:49 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:47:49 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:47:49 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:47:49 --> URI Class Initialized
DEBUG - 2012-08-06 20:47:49 --> Router Class Initialized
DEBUG - 2012-08-06 20:47:49 --> Output Class Initialized
DEBUG - 2012-08-06 20:47:49 --> Security Class Initialized
DEBUG - 2012-08-06 20:47:49 --> Input Class Initialized
DEBUG - 2012-08-06 20:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:47:49 --> Language Class Initialized
DEBUG - 2012-08-06 20:47:49 --> Loader Class Initialized
DEBUG - 2012-08-06 20:47:49 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:47:49 --> Controller Class Initialized
DEBUG - 2012-08-06 20:47:49 --> Model Class Initialized
DEBUG - 2012-08-06 20:47:49 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:47:49 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:47:49 --> Form Validation Class Initialized
DEBUG - 2012-08-06 20:47:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 20:51:03 --> Config Class Initialized
DEBUG - 2012-08-06 20:51:03 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:51:03 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:51:03 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:51:03 --> URI Class Initialized
DEBUG - 2012-08-06 20:51:03 --> Router Class Initialized
DEBUG - 2012-08-06 20:51:03 --> Output Class Initialized
DEBUG - 2012-08-06 20:51:03 --> Security Class Initialized
DEBUG - 2012-08-06 20:51:03 --> Input Class Initialized
DEBUG - 2012-08-06 20:51:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:51:03 --> Language Class Initialized
DEBUG - 2012-08-06 20:51:03 --> Loader Class Initialized
DEBUG - 2012-08-06 20:51:03 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:51:03 --> Controller Class Initialized
DEBUG - 2012-08-06 20:51:03 --> Model Class Initialized
DEBUG - 2012-08-06 20:51:03 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:51:03 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:51:03 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 20:51:03 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-08-06 20:51:03 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-08-06 20:51:03 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-08-06 20:51:03 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 20:51:03 --> Final output sent to browser
DEBUG - 2012-08-06 20:51:03 --> Total execution time: 0.0474
DEBUG - 2012-08-06 20:51:22 --> Config Class Initialized
DEBUG - 2012-08-06 20:51:22 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:51:22 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:51:22 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:51:22 --> URI Class Initialized
DEBUG - 2012-08-06 20:51:22 --> Router Class Initialized
DEBUG - 2012-08-06 20:51:22 --> Output Class Initialized
DEBUG - 2012-08-06 20:51:22 --> Security Class Initialized
DEBUG - 2012-08-06 20:51:22 --> Input Class Initialized
DEBUG - 2012-08-06 20:51:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:51:22 --> Language Class Initialized
DEBUG - 2012-08-06 20:51:22 --> Loader Class Initialized
DEBUG - 2012-08-06 20:51:22 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:51:22 --> Controller Class Initialized
DEBUG - 2012-08-06 20:51:22 --> Model Class Initialized
DEBUG - 2012-08-06 20:51:22 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:51:22 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:51:22 --> Form Validation Class Initialized
DEBUG - 2012-08-06 20:51:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 20:52:57 --> Config Class Initialized
DEBUG - 2012-08-06 20:52:57 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:52:57 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:52:57 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:52:57 --> URI Class Initialized
DEBUG - 2012-08-06 20:52:57 --> Router Class Initialized
DEBUG - 2012-08-06 20:52:57 --> Output Class Initialized
DEBUG - 2012-08-06 20:52:57 --> Security Class Initialized
DEBUG - 2012-08-06 20:52:57 --> Input Class Initialized
DEBUG - 2012-08-06 20:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:52:57 --> Language Class Initialized
DEBUG - 2012-08-06 20:52:57 --> Loader Class Initialized
DEBUG - 2012-08-06 20:52:57 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:52:57 --> Controller Class Initialized
DEBUG - 2012-08-06 20:52:57 --> Model Class Initialized
DEBUG - 2012-08-06 20:52:57 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:52:57 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:52:57 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 20:52:57 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-08-06 20:52:57 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-08-06 20:52:57 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-08-06 20:52:57 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 20:52:57 --> Final output sent to browser
DEBUG - 2012-08-06 20:52:57 --> Total execution time: 0.0440
DEBUG - 2012-08-06 20:52:58 --> Config Class Initialized
DEBUG - 2012-08-06 20:52:58 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:52:58 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:52:58 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:52:58 --> URI Class Initialized
DEBUG - 2012-08-06 20:52:58 --> Router Class Initialized
ERROR - 2012-08-06 20:52:58 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 20:52:58 --> Config Class Initialized
DEBUG - 2012-08-06 20:52:58 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:52:58 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:52:58 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:52:58 --> URI Class Initialized
DEBUG - 2012-08-06 20:52:58 --> Router Class Initialized
ERROR - 2012-08-06 20:52:58 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 20:52:58 --> Config Class Initialized
DEBUG - 2012-08-06 20:52:58 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:52:58 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:52:58 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:52:58 --> URI Class Initialized
DEBUG - 2012-08-06 20:52:58 --> Router Class Initialized
ERROR - 2012-08-06 20:52:58 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 20:53:14 --> Config Class Initialized
DEBUG - 2012-08-06 20:53:14 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:53:14 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:53:14 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:53:14 --> URI Class Initialized
DEBUG - 2012-08-06 20:53:14 --> Router Class Initialized
DEBUG - 2012-08-06 20:53:14 --> Output Class Initialized
DEBUG - 2012-08-06 20:53:14 --> Security Class Initialized
DEBUG - 2012-08-06 20:53:14 --> Input Class Initialized
DEBUG - 2012-08-06 20:53:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:53:14 --> Language Class Initialized
DEBUG - 2012-08-06 20:53:14 --> Loader Class Initialized
DEBUG - 2012-08-06 20:53:14 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:53:14 --> Controller Class Initialized
DEBUG - 2012-08-06 20:53:14 --> Model Class Initialized
DEBUG - 2012-08-06 20:53:14 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:53:14 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:53:14 --> Form Validation Class Initialized
DEBUG - 2012-08-06 20:53:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 20:54:06 --> Config Class Initialized
DEBUG - 2012-08-06 20:54:06 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:54:06 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:54:06 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:54:06 --> URI Class Initialized
DEBUG - 2012-08-06 20:54:06 --> Router Class Initialized
DEBUG - 2012-08-06 20:54:06 --> Output Class Initialized
DEBUG - 2012-08-06 20:54:06 --> Security Class Initialized
DEBUG - 2012-08-06 20:54:06 --> Input Class Initialized
DEBUG - 2012-08-06 20:54:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:54:06 --> Language Class Initialized
DEBUG - 2012-08-06 20:54:06 --> Loader Class Initialized
DEBUG - 2012-08-06 20:54:06 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:54:06 --> Controller Class Initialized
DEBUG - 2012-08-06 20:54:06 --> Model Class Initialized
DEBUG - 2012-08-06 20:54:06 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:54:06 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:54:06 --> Form Validation Class Initialized
DEBUG - 2012-08-06 20:54:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 20:54:08 --> Config Class Initialized
DEBUG - 2012-08-06 20:54:08 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:54:08 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:54:08 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:54:08 --> URI Class Initialized
DEBUG - 2012-08-06 20:54:08 --> Router Class Initialized
DEBUG - 2012-08-06 20:54:08 --> Output Class Initialized
DEBUG - 2012-08-06 20:54:08 --> Security Class Initialized
DEBUG - 2012-08-06 20:54:08 --> Input Class Initialized
DEBUG - 2012-08-06 20:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:54:08 --> Language Class Initialized
DEBUG - 2012-08-06 20:54:08 --> Loader Class Initialized
DEBUG - 2012-08-06 20:54:08 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:54:08 --> Controller Class Initialized
DEBUG - 2012-08-06 20:54:08 --> Model Class Initialized
DEBUG - 2012-08-06 20:54:08 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:54:08 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:54:08 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 20:54:08 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-08-06 20:54:08 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-08-06 20:54:08 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-08-06 20:54:08 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 20:54:08 --> Final output sent to browser
DEBUG - 2012-08-06 20:54:08 --> Total execution time: 0.0702
DEBUG - 2012-08-06 20:54:10 --> Config Class Initialized
DEBUG - 2012-08-06 20:54:10 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:54:10 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:54:10 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:54:10 --> URI Class Initialized
DEBUG - 2012-08-06 20:54:10 --> Router Class Initialized
ERROR - 2012-08-06 20:54:10 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 20:54:10 --> Config Class Initialized
DEBUG - 2012-08-06 20:54:10 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:54:10 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:54:10 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:54:10 --> URI Class Initialized
DEBUG - 2012-08-06 20:54:10 --> Router Class Initialized
ERROR - 2012-08-06 20:54:10 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 20:54:10 --> Config Class Initialized
DEBUG - 2012-08-06 20:54:10 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:54:10 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:54:10 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:54:10 --> URI Class Initialized
DEBUG - 2012-08-06 20:54:10 --> Router Class Initialized
ERROR - 2012-08-06 20:54:10 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 20:54:22 --> Config Class Initialized
DEBUG - 2012-08-06 20:54:22 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:54:22 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:54:22 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:54:22 --> URI Class Initialized
DEBUG - 2012-08-06 20:54:22 --> Router Class Initialized
DEBUG - 2012-08-06 20:54:22 --> Output Class Initialized
DEBUG - 2012-08-06 20:54:22 --> Security Class Initialized
DEBUG - 2012-08-06 20:54:22 --> Input Class Initialized
DEBUG - 2012-08-06 20:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:54:22 --> Language Class Initialized
DEBUG - 2012-08-06 20:54:22 --> Loader Class Initialized
DEBUG - 2012-08-06 20:54:22 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:54:22 --> Controller Class Initialized
DEBUG - 2012-08-06 20:54:22 --> Model Class Initialized
DEBUG - 2012-08-06 20:54:22 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:54:22 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:54:22 --> Form Validation Class Initialized
DEBUG - 2012-08-06 20:54:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 20:57:03 --> Config Class Initialized
DEBUG - 2012-08-06 20:57:03 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:57:03 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:57:03 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:57:03 --> URI Class Initialized
DEBUG - 2012-08-06 20:57:03 --> Router Class Initialized
DEBUG - 2012-08-06 20:57:03 --> Output Class Initialized
DEBUG - 2012-08-06 20:57:03 --> Security Class Initialized
DEBUG - 2012-08-06 20:57:03 --> Input Class Initialized
DEBUG - 2012-08-06 20:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:57:03 --> Language Class Initialized
DEBUG - 2012-08-06 20:57:03 --> Loader Class Initialized
DEBUG - 2012-08-06 20:57:03 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:57:03 --> Controller Class Initialized
DEBUG - 2012-08-06 20:57:03 --> Model Class Initialized
DEBUG - 2012-08-06 20:57:03 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:57:03 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:57:03 --> Form Validation Class Initialized
DEBUG - 2012-08-06 20:57:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 20:57:26 --> Config Class Initialized
DEBUG - 2012-08-06 20:57:26 --> Hooks Class Initialized
DEBUG - 2012-08-06 20:57:26 --> Utf8 Class Initialized
DEBUG - 2012-08-06 20:57:26 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 20:57:26 --> URI Class Initialized
DEBUG - 2012-08-06 20:57:26 --> Router Class Initialized
DEBUG - 2012-08-06 20:57:26 --> Output Class Initialized
DEBUG - 2012-08-06 20:57:26 --> Security Class Initialized
DEBUG - 2012-08-06 20:57:26 --> Input Class Initialized
DEBUG - 2012-08-06 20:57:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 20:57:26 --> Language Class Initialized
DEBUG - 2012-08-06 20:57:26 --> Loader Class Initialized
DEBUG - 2012-08-06 20:57:26 --> Helper loaded: url_helper
DEBUG - 2012-08-06 20:57:26 --> Controller Class Initialized
DEBUG - 2012-08-06 20:57:26 --> Model Class Initialized
DEBUG - 2012-08-06 20:57:26 --> Database Driver Class Initialized
DEBUG - 2012-08-06 20:57:26 --> Helper loaded: form_helper
DEBUG - 2012-08-06 20:57:26 --> Form Validation Class Initialized
DEBUG - 2012-08-06 20:57:26 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2012-08-06 20:57:26 --> Could not find the language line "select_selected"
DEBUG - 2012-08-06 20:57:26 --> Final output sent to browser
DEBUG - 2012-08-06 20:57:26 --> Total execution time: 0.0375
DEBUG - 2012-08-06 21:00:37 --> Config Class Initialized
DEBUG - 2012-08-06 21:00:37 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:00:37 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:00:37 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:00:37 --> URI Class Initialized
DEBUG - 2012-08-06 21:00:37 --> Router Class Initialized
DEBUG - 2012-08-06 21:00:37 --> Output Class Initialized
DEBUG - 2012-08-06 21:00:37 --> Security Class Initialized
DEBUG - 2012-08-06 21:00:37 --> Input Class Initialized
DEBUG - 2012-08-06 21:00:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 21:00:37 --> Language Class Initialized
DEBUG - 2012-08-06 21:00:37 --> Loader Class Initialized
DEBUG - 2012-08-06 21:00:37 --> Helper loaded: url_helper
DEBUG - 2012-08-06 21:00:37 --> Controller Class Initialized
DEBUG - 2012-08-06 21:00:37 --> Model Class Initialized
DEBUG - 2012-08-06 21:00:37 --> Database Driver Class Initialized
DEBUG - 2012-08-06 21:00:37 --> Helper loaded: form_helper
DEBUG - 2012-08-06 21:00:37 --> Form Validation Class Initialized
DEBUG - 2012-08-06 21:00:37 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2012-08-06 21:00:37 --> Could not find the language line "select_selected"
DEBUG - 2012-08-06 21:00:37 --> Final output sent to browser
DEBUG - 2012-08-06 21:00:37 --> Total execution time: 0.0380
DEBUG - 2012-08-06 21:02:29 --> Config Class Initialized
DEBUG - 2012-08-06 21:02:29 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:02:29 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:02:29 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:02:29 --> URI Class Initialized
DEBUG - 2012-08-06 21:02:29 --> Router Class Initialized
DEBUG - 2012-08-06 21:02:29 --> Output Class Initialized
DEBUG - 2012-08-06 21:02:29 --> Security Class Initialized
DEBUG - 2012-08-06 21:02:29 --> Input Class Initialized
DEBUG - 2012-08-06 21:02:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 21:02:29 --> Language Class Initialized
DEBUG - 2012-08-06 21:02:29 --> Loader Class Initialized
DEBUG - 2012-08-06 21:02:29 --> Helper loaded: url_helper
DEBUG - 2012-08-06 21:02:29 --> Controller Class Initialized
DEBUG - 2012-08-06 21:02:29 --> Model Class Initialized
DEBUG - 2012-08-06 21:02:29 --> Database Driver Class Initialized
DEBUG - 2012-08-06 21:02:29 --> Helper loaded: form_helper
DEBUG - 2012-08-06 21:02:30 --> Form Validation Class Initialized
DEBUG - 2012-08-06 21:02:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 21:02:30 --> Final output sent to browser
DEBUG - 2012-08-06 21:02:30 --> Total execution time: 0.0443
DEBUG - 2012-08-06 21:02:50 --> Config Class Initialized
DEBUG - 2012-08-06 21:02:50 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:02:50 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:02:50 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:02:50 --> URI Class Initialized
DEBUG - 2012-08-06 21:02:50 --> Router Class Initialized
DEBUG - 2012-08-06 21:02:50 --> Output Class Initialized
DEBUG - 2012-08-06 21:02:50 --> Security Class Initialized
DEBUG - 2012-08-06 21:02:50 --> Input Class Initialized
DEBUG - 2012-08-06 21:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 21:02:50 --> Language Class Initialized
DEBUG - 2012-08-06 21:02:50 --> Loader Class Initialized
DEBUG - 2012-08-06 21:02:50 --> Helper loaded: url_helper
DEBUG - 2012-08-06 21:02:50 --> Controller Class Initialized
DEBUG - 2012-08-06 21:02:50 --> Model Class Initialized
DEBUG - 2012-08-06 21:02:50 --> Database Driver Class Initialized
DEBUG - 2012-08-06 21:02:50 --> Helper loaded: form_helper
DEBUG - 2012-08-06 21:02:50 --> Form Validation Class Initialized
DEBUG - 2012-08-06 21:02:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 21:02:50 --> Final output sent to browser
DEBUG - 2012-08-06 21:02:50 --> Total execution time: 0.0383
DEBUG - 2012-08-06 21:04:24 --> Config Class Initialized
DEBUG - 2012-08-06 21:04:24 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:04:24 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:04:24 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:04:24 --> URI Class Initialized
DEBUG - 2012-08-06 21:04:24 --> Router Class Initialized
DEBUG - 2012-08-06 21:04:24 --> Output Class Initialized
DEBUG - 2012-08-06 21:04:24 --> Security Class Initialized
DEBUG - 2012-08-06 21:04:24 --> Input Class Initialized
DEBUG - 2012-08-06 21:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 21:04:24 --> Language Class Initialized
DEBUG - 2012-08-06 21:04:24 --> Loader Class Initialized
DEBUG - 2012-08-06 21:04:24 --> Helper loaded: url_helper
DEBUG - 2012-08-06 21:04:24 --> Controller Class Initialized
DEBUG - 2012-08-06 21:04:24 --> Model Class Initialized
DEBUG - 2012-08-06 21:04:24 --> Database Driver Class Initialized
DEBUG - 2012-08-06 21:04:24 --> Helper loaded: form_helper
DEBUG - 2012-08-06 21:04:24 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 21:04:24 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-08-06 21:04:24 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-08-06 21:04:24 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-08-06 21:04:24 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 21:04:24 --> Final output sent to browser
DEBUG - 2012-08-06 21:04:24 --> Total execution time: 0.0398
DEBUG - 2012-08-06 21:04:25 --> Config Class Initialized
DEBUG - 2012-08-06 21:04:25 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:04:25 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:04:25 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:04:25 --> URI Class Initialized
DEBUG - 2012-08-06 21:04:25 --> Router Class Initialized
ERROR - 2012-08-06 21:04:25 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 21:04:25 --> Config Class Initialized
DEBUG - 2012-08-06 21:04:25 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:04:25 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:04:25 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:04:25 --> URI Class Initialized
DEBUG - 2012-08-06 21:04:25 --> Router Class Initialized
ERROR - 2012-08-06 21:04:25 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 21:04:25 --> Config Class Initialized
DEBUG - 2012-08-06 21:04:25 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:04:25 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:04:25 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:04:25 --> URI Class Initialized
DEBUG - 2012-08-06 21:04:25 --> Router Class Initialized
ERROR - 2012-08-06 21:04:25 --> 404 Page Not Found --> css
DEBUG - 2012-08-06 21:04:32 --> Config Class Initialized
DEBUG - 2012-08-06 21:04:32 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:04:32 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:04:32 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:04:32 --> URI Class Initialized
DEBUG - 2012-08-06 21:04:32 --> Router Class Initialized
DEBUG - 2012-08-06 21:04:32 --> Output Class Initialized
DEBUG - 2012-08-06 21:04:32 --> Security Class Initialized
DEBUG - 2012-08-06 21:04:32 --> Input Class Initialized
DEBUG - 2012-08-06 21:04:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 21:04:32 --> Language Class Initialized
DEBUG - 2012-08-06 21:04:32 --> Loader Class Initialized
DEBUG - 2012-08-06 21:04:32 --> Helper loaded: url_helper
DEBUG - 2012-08-06 21:04:32 --> Controller Class Initialized
DEBUG - 2012-08-06 21:04:32 --> Model Class Initialized
DEBUG - 2012-08-06 21:04:32 --> Database Driver Class Initialized
DEBUG - 2012-08-06 21:04:32 --> Helper loaded: form_helper
DEBUG - 2012-08-06 21:04:32 --> Form Validation Class Initialized
DEBUG - 2012-08-06 21:04:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 21:04:32 --> Final output sent to browser
DEBUG - 2012-08-06 21:04:32 --> Total execution time: 0.0403
DEBUG - 2012-08-06 21:04:45 --> Config Class Initialized
DEBUG - 2012-08-06 21:04:45 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:04:45 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:04:45 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:04:45 --> URI Class Initialized
DEBUG - 2012-08-06 21:04:45 --> Router Class Initialized
DEBUG - 2012-08-06 21:04:45 --> Output Class Initialized
DEBUG - 2012-08-06 21:04:45 --> Security Class Initialized
DEBUG - 2012-08-06 21:04:45 --> Input Class Initialized
DEBUG - 2012-08-06 21:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 21:04:45 --> Language Class Initialized
DEBUG - 2012-08-06 21:04:45 --> Loader Class Initialized
DEBUG - 2012-08-06 21:04:45 --> Helper loaded: url_helper
DEBUG - 2012-08-06 21:04:45 --> Controller Class Initialized
DEBUG - 2012-08-06 21:04:45 --> Model Class Initialized
DEBUG - 2012-08-06 21:04:45 --> Database Driver Class Initialized
DEBUG - 2012-08-06 21:04:45 --> Helper loaded: form_helper
DEBUG - 2012-08-06 21:04:45 --> Form Validation Class Initialized
DEBUG - 2012-08-06 21:04:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 21:04:45 --> Final output sent to browser
DEBUG - 2012-08-06 21:04:45 --> Total execution time: 0.0372
DEBUG - 2012-08-06 21:06:13 --> Config Class Initialized
DEBUG - 2012-08-06 21:06:13 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:06:13 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:06:13 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:06:13 --> URI Class Initialized
DEBUG - 2012-08-06 21:06:13 --> Router Class Initialized
DEBUG - 2012-08-06 21:06:13 --> Output Class Initialized
DEBUG - 2012-08-06 21:06:13 --> Security Class Initialized
DEBUG - 2012-08-06 21:06:13 --> Input Class Initialized
DEBUG - 2012-08-06 21:06:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 21:06:13 --> Language Class Initialized
DEBUG - 2012-08-06 21:06:13 --> Loader Class Initialized
DEBUG - 2012-08-06 21:06:13 --> Helper loaded: url_helper
DEBUG - 2012-08-06 21:06:13 --> Controller Class Initialized
DEBUG - 2012-08-06 21:06:13 --> Model Class Initialized
DEBUG - 2012-08-06 21:06:13 --> Database Driver Class Initialized
DEBUG - 2012-08-06 21:06:13 --> Helper loaded: form_helper
DEBUG - 2012-08-06 21:06:13 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 21:06:13 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-08-06 21:06:13 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-08-06 21:06:13 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-08-06 21:06:13 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 21:06:13 --> Final output sent to browser
DEBUG - 2012-08-06 21:06:13 --> Total execution time: 0.0398
DEBUG - 2012-08-06 21:06:23 --> Config Class Initialized
DEBUG - 2012-08-06 21:06:23 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:06:23 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:06:23 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:06:23 --> URI Class Initialized
DEBUG - 2012-08-06 21:06:23 --> Router Class Initialized
DEBUG - 2012-08-06 21:06:23 --> Output Class Initialized
DEBUG - 2012-08-06 21:06:23 --> Security Class Initialized
DEBUG - 2012-08-06 21:06:23 --> Input Class Initialized
DEBUG - 2012-08-06 21:06:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 21:06:23 --> Language Class Initialized
DEBUG - 2012-08-06 21:06:23 --> Loader Class Initialized
DEBUG - 2012-08-06 21:06:23 --> Helper loaded: url_helper
DEBUG - 2012-08-06 21:06:23 --> Controller Class Initialized
DEBUG - 2012-08-06 21:06:23 --> Model Class Initialized
DEBUG - 2012-08-06 21:06:23 --> Database Driver Class Initialized
DEBUG - 2012-08-06 21:06:23 --> Helper loaded: form_helper
DEBUG - 2012-08-06 21:06:23 --> Form Validation Class Initialized
DEBUG - 2012-08-06 21:06:23 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 21:06:23 --> Final output sent to browser
DEBUG - 2012-08-06 21:06:23 --> Total execution time: 0.0373
DEBUG - 2012-08-06 21:06:29 --> Config Class Initialized
DEBUG - 2012-08-06 21:06:29 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:06:29 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:06:29 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:06:29 --> URI Class Initialized
DEBUG - 2012-08-06 21:06:29 --> Router Class Initialized
DEBUG - 2012-08-06 21:06:29 --> Output Class Initialized
DEBUG - 2012-08-06 21:06:29 --> Security Class Initialized
DEBUG - 2012-08-06 21:06:29 --> Input Class Initialized
DEBUG - 2012-08-06 21:06:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 21:06:29 --> Language Class Initialized
DEBUG - 2012-08-06 21:06:29 --> Loader Class Initialized
DEBUG - 2012-08-06 21:06:29 --> Helper loaded: url_helper
DEBUG - 2012-08-06 21:06:29 --> Controller Class Initialized
DEBUG - 2012-08-06 21:06:29 --> Model Class Initialized
DEBUG - 2012-08-06 21:06:29 --> Database Driver Class Initialized
DEBUG - 2012-08-06 21:06:29 --> Helper loaded: form_helper
DEBUG - 2012-08-06 21:06:29 --> Form Validation Class Initialized
DEBUG - 2012-08-06 21:06:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 21:06:29 --> Final output sent to browser
DEBUG - 2012-08-06 21:06:29 --> Total execution time: 0.0386
DEBUG - 2012-08-06 21:07:08 --> Config Class Initialized
DEBUG - 2012-08-06 21:07:08 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:07:08 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:07:08 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:07:08 --> URI Class Initialized
DEBUG - 2012-08-06 21:07:08 --> Router Class Initialized
DEBUG - 2012-08-06 21:07:08 --> Output Class Initialized
DEBUG - 2012-08-06 21:07:08 --> Security Class Initialized
DEBUG - 2012-08-06 21:07:08 --> Input Class Initialized
DEBUG - 2012-08-06 21:07:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 21:07:08 --> Language Class Initialized
DEBUG - 2012-08-06 21:07:08 --> Loader Class Initialized
DEBUG - 2012-08-06 21:07:08 --> Helper loaded: url_helper
DEBUG - 2012-08-06 21:07:08 --> Controller Class Initialized
DEBUG - 2012-08-06 21:07:08 --> Model Class Initialized
DEBUG - 2012-08-06 21:07:08 --> Database Driver Class Initialized
DEBUG - 2012-08-06 21:07:08 --> Helper loaded: form_helper
DEBUG - 2012-08-06 21:07:08 --> Form Validation Class Initialized
DEBUG - 2012-08-06 21:07:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 21:07:08 --> Final output sent to browser
DEBUG - 2012-08-06 21:07:08 --> Total execution time: 0.0372
DEBUG - 2012-08-06 21:07:12 --> Config Class Initialized
DEBUG - 2012-08-06 21:07:12 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:07:12 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:07:12 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:07:12 --> URI Class Initialized
DEBUG - 2012-08-06 21:07:12 --> Router Class Initialized
DEBUG - 2012-08-06 21:07:12 --> Output Class Initialized
DEBUG - 2012-08-06 21:07:12 --> Security Class Initialized
DEBUG - 2012-08-06 21:07:12 --> Input Class Initialized
DEBUG - 2012-08-06 21:07:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 21:07:12 --> Language Class Initialized
DEBUG - 2012-08-06 21:07:12 --> Loader Class Initialized
DEBUG - 2012-08-06 21:07:12 --> Helper loaded: url_helper
DEBUG - 2012-08-06 21:07:12 --> Controller Class Initialized
DEBUG - 2012-08-06 21:07:12 --> Model Class Initialized
DEBUG - 2012-08-06 21:07:12 --> Database Driver Class Initialized
DEBUG - 2012-08-06 21:07:12 --> Helper loaded: form_helper
DEBUG - 2012-08-06 21:07:12 --> Form Validation Class Initialized
DEBUG - 2012-08-06 21:07:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 21:07:12 --> Final output sent to browser
DEBUG - 2012-08-06 21:07:12 --> Total execution time: 0.0401
DEBUG - 2012-08-06 21:09:04 --> Config Class Initialized
DEBUG - 2012-08-06 21:09:04 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:09:04 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:09:04 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:09:04 --> URI Class Initialized
DEBUG - 2012-08-06 21:09:04 --> Router Class Initialized
DEBUG - 2012-08-06 21:09:04 --> Output Class Initialized
DEBUG - 2012-08-06 21:09:04 --> Security Class Initialized
DEBUG - 2012-08-06 21:09:04 --> Input Class Initialized
DEBUG - 2012-08-06 21:09:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 21:09:04 --> Language Class Initialized
DEBUG - 2012-08-06 21:09:04 --> Loader Class Initialized
DEBUG - 2012-08-06 21:09:04 --> Helper loaded: url_helper
DEBUG - 2012-08-06 21:09:04 --> Controller Class Initialized
DEBUG - 2012-08-06 21:09:04 --> Model Class Initialized
DEBUG - 2012-08-06 21:09:04 --> Database Driver Class Initialized
DEBUG - 2012-08-06 21:09:04 --> Helper loaded: form_helper
DEBUG - 2012-08-06 21:09:04 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-08-06 21:09:04 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-08-06 21:09:04 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-08-06 21:09:04 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-08-06 21:09:04 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-08-06 21:09:04 --> Final output sent to browser
DEBUG - 2012-08-06 21:09:04 --> Total execution time: 0.0396
DEBUG - 2012-08-06 21:09:11 --> Config Class Initialized
DEBUG - 2012-08-06 21:09:11 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:09:11 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:09:11 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:09:11 --> URI Class Initialized
DEBUG - 2012-08-06 21:09:11 --> Router Class Initialized
DEBUG - 2012-08-06 21:09:11 --> Output Class Initialized
DEBUG - 2012-08-06 21:09:11 --> Security Class Initialized
DEBUG - 2012-08-06 21:09:11 --> Input Class Initialized
DEBUG - 2012-08-06 21:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 21:09:11 --> Language Class Initialized
DEBUG - 2012-08-06 21:09:11 --> Loader Class Initialized
DEBUG - 2012-08-06 21:09:11 --> Helper loaded: url_helper
DEBUG - 2012-08-06 21:09:11 --> Controller Class Initialized
DEBUG - 2012-08-06 21:09:11 --> Model Class Initialized
DEBUG - 2012-08-06 21:09:11 --> Database Driver Class Initialized
DEBUG - 2012-08-06 21:09:11 --> Helper loaded: form_helper
DEBUG - 2012-08-06 21:09:11 --> Form Validation Class Initialized
DEBUG - 2012-08-06 21:09:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 21:09:11 --> Final output sent to browser
DEBUG - 2012-08-06 21:09:11 --> Total execution time: 0.0375
DEBUG - 2012-08-06 21:10:55 --> Config Class Initialized
DEBUG - 2012-08-06 21:10:55 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:10:55 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:10:55 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:10:55 --> URI Class Initialized
DEBUG - 2012-08-06 21:10:55 --> Router Class Initialized
DEBUG - 2012-08-06 21:10:55 --> Output Class Initialized
DEBUG - 2012-08-06 21:10:55 --> Security Class Initialized
DEBUG - 2012-08-06 21:10:55 --> Input Class Initialized
DEBUG - 2012-08-06 21:10:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 21:10:55 --> Language Class Initialized
DEBUG - 2012-08-06 21:10:55 --> Loader Class Initialized
DEBUG - 2012-08-06 21:10:55 --> Helper loaded: url_helper
DEBUG - 2012-08-06 21:10:55 --> Controller Class Initialized
DEBUG - 2012-08-06 21:10:55 --> Model Class Initialized
DEBUG - 2012-08-06 21:10:55 --> Database Driver Class Initialized
DEBUG - 2012-08-06 21:10:55 --> Helper loaded: form_helper
DEBUG - 2012-08-06 21:10:55 --> Form Validation Class Initialized
DEBUG - 2012-08-06 21:10:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 21:10:55 --> Final output sent to browser
DEBUG - 2012-08-06 21:10:55 --> Total execution time: 0.0395
DEBUG - 2012-08-06 21:17:14 --> Config Class Initialized
DEBUG - 2012-08-06 21:17:14 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:17:14 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:17:14 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:17:14 --> URI Class Initialized
DEBUG - 2012-08-06 21:17:14 --> Router Class Initialized
DEBUG - 2012-08-06 21:17:14 --> Output Class Initialized
DEBUG - 2012-08-06 21:17:14 --> Security Class Initialized
DEBUG - 2012-08-06 21:17:14 --> Input Class Initialized
DEBUG - 2012-08-06 21:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 21:17:14 --> Language Class Initialized
DEBUG - 2012-08-06 21:18:01 --> Config Class Initialized
DEBUG - 2012-08-06 21:18:01 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:18:01 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:18:01 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:18:01 --> URI Class Initialized
DEBUG - 2012-08-06 21:18:01 --> Router Class Initialized
DEBUG - 2012-08-06 21:18:01 --> Output Class Initialized
DEBUG - 2012-08-06 21:18:01 --> Security Class Initialized
DEBUG - 2012-08-06 21:18:01 --> Input Class Initialized
DEBUG - 2012-08-06 21:18:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 21:18:01 --> Language Class Initialized
DEBUG - 2012-08-06 21:18:01 --> Loader Class Initialized
DEBUG - 2012-08-06 21:18:01 --> Helper loaded: url_helper
DEBUG - 2012-08-06 21:18:01 --> Controller Class Initialized
DEBUG - 2012-08-06 21:18:01 --> Model Class Initialized
DEBUG - 2012-08-06 21:18:01 --> Database Driver Class Initialized
DEBUG - 2012-08-06 21:18:01 --> Helper loaded: language_helper
DEBUG - 2012-08-06 21:18:01 --> Helper loaded: form_helper
DEBUG - 2012-08-06 21:18:01 --> Form Validation Class Initialized
DEBUG - 2012-08-06 21:18:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 21:18:01 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 21:18:01 --> Final output sent to browser
DEBUG - 2012-08-06 21:18:01 --> Total execution time: 0.0389
DEBUG - 2012-08-06 21:18:36 --> Config Class Initialized
DEBUG - 2012-08-06 21:18:36 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:18:36 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:18:36 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:18:36 --> URI Class Initialized
DEBUG - 2012-08-06 21:18:36 --> Router Class Initialized
DEBUG - 2012-08-06 21:18:36 --> Output Class Initialized
DEBUG - 2012-08-06 21:18:36 --> Security Class Initialized
DEBUG - 2012-08-06 21:18:36 --> Input Class Initialized
DEBUG - 2012-08-06 21:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 21:18:36 --> Language Class Initialized
DEBUG - 2012-08-06 21:18:36 --> Loader Class Initialized
DEBUG - 2012-08-06 21:18:36 --> Helper loaded: url_helper
DEBUG - 2012-08-06 21:18:36 --> Controller Class Initialized
DEBUG - 2012-08-06 21:18:36 --> Model Class Initialized
DEBUG - 2012-08-06 21:18:36 --> Database Driver Class Initialized
DEBUG - 2012-08-06 21:18:36 --> Helper loaded: language_helper
DEBUG - 2012-08-06 21:18:36 --> Helper loaded: form_helper
DEBUG - 2012-08-06 21:18:36 --> Form Validation Class Initialized
DEBUG - 2012-08-06 21:18:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 21:18:36 --> Final output sent to browser
DEBUG - 2012-08-06 21:18:36 --> Total execution time: 0.0407
DEBUG - 2012-08-06 21:23:03 --> Config Class Initialized
DEBUG - 2012-08-06 21:23:03 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:23:03 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:23:03 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:23:03 --> URI Class Initialized
DEBUG - 2012-08-06 21:23:03 --> Router Class Initialized
DEBUG - 2012-08-06 21:23:03 --> Output Class Initialized
DEBUG - 2012-08-06 21:23:03 --> Security Class Initialized
DEBUG - 2012-08-06 21:23:03 --> Input Class Initialized
DEBUG - 2012-08-06 21:23:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 21:23:03 --> Language Class Initialized
DEBUG - 2012-08-06 21:23:03 --> Loader Class Initialized
DEBUG - 2012-08-06 21:23:03 --> Helper loaded: url_helper
DEBUG - 2012-08-06 21:23:03 --> Controller Class Initialized
DEBUG - 2012-08-06 21:23:03 --> Model Class Initialized
DEBUG - 2012-08-06 21:23:03 --> Database Driver Class Initialized
DEBUG - 2012-08-06 21:23:03 --> Helper loaded: language_helper
DEBUG - 2012-08-06 21:23:03 --> Helper loaded: form_helper
DEBUG - 2012-08-06 21:23:03 --> Form Validation Class Initialized
DEBUG - 2012-08-06 21:23:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 21:23:03 --> Final output sent to browser
DEBUG - 2012-08-06 21:23:03 --> Total execution time: 0.0413
DEBUG - 2012-08-06 21:24:11 --> Config Class Initialized
DEBUG - 2012-08-06 21:24:11 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:24:11 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:24:11 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:24:11 --> URI Class Initialized
DEBUG - 2012-08-06 21:24:11 --> Router Class Initialized
DEBUG - 2012-08-06 21:24:11 --> Output Class Initialized
DEBUG - 2012-08-06 21:24:11 --> Security Class Initialized
DEBUG - 2012-08-06 21:24:11 --> Input Class Initialized
DEBUG - 2012-08-06 21:24:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 21:24:11 --> Language Class Initialized
DEBUG - 2012-08-06 21:24:11 --> Loader Class Initialized
DEBUG - 2012-08-06 21:24:11 --> Helper loaded: url_helper
DEBUG - 2012-08-06 21:24:11 --> Controller Class Initialized
DEBUG - 2012-08-06 21:24:11 --> Model Class Initialized
DEBUG - 2012-08-06 21:24:11 --> Database Driver Class Initialized
DEBUG - 2012-08-06 21:24:35 --> Config Class Initialized
DEBUG - 2012-08-06 21:24:35 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:24:35 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:24:35 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:24:35 --> URI Class Initialized
DEBUG - 2012-08-06 21:24:35 --> Router Class Initialized
DEBUG - 2012-08-06 21:24:35 --> Output Class Initialized
DEBUG - 2012-08-06 21:24:35 --> Security Class Initialized
DEBUG - 2012-08-06 21:24:35 --> Input Class Initialized
DEBUG - 2012-08-06 21:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 21:24:35 --> Language Class Initialized
DEBUG - 2012-08-06 21:24:35 --> Loader Class Initialized
DEBUG - 2012-08-06 21:24:35 --> Helper loaded: url_helper
DEBUG - 2012-08-06 21:24:35 --> Controller Class Initialized
DEBUG - 2012-08-06 21:24:35 --> Model Class Initialized
DEBUG - 2012-08-06 21:24:35 --> Database Driver Class Initialized
DEBUG - 2012-08-06 21:24:35 --> Helper loaded: language_helper
DEBUG - 2012-08-06 21:24:35 --> Helper loaded: form_helper
DEBUG - 2012-08-06 21:24:35 --> Form Validation Class Initialized
DEBUG - 2012-08-06 21:24:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 21:24:35 --> Final output sent to browser
DEBUG - 2012-08-06 21:24:35 --> Total execution time: 0.0424
DEBUG - 2012-08-06 21:24:57 --> Config Class Initialized
DEBUG - 2012-08-06 21:24:57 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:24:57 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:24:57 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:24:57 --> URI Class Initialized
DEBUG - 2012-08-06 21:24:57 --> Router Class Initialized
DEBUG - 2012-08-06 21:24:57 --> Output Class Initialized
DEBUG - 2012-08-06 21:24:57 --> Security Class Initialized
DEBUG - 2012-08-06 21:24:57 --> Input Class Initialized
DEBUG - 2012-08-06 21:24:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 21:24:57 --> Language Class Initialized
DEBUG - 2012-08-06 21:24:57 --> Loader Class Initialized
DEBUG - 2012-08-06 21:24:57 --> Helper loaded: url_helper
DEBUG - 2012-08-06 21:24:57 --> Controller Class Initialized
DEBUG - 2012-08-06 21:24:57 --> Model Class Initialized
DEBUG - 2012-08-06 21:24:57 --> Database Driver Class Initialized
DEBUG - 2012-08-06 21:24:57 --> Helper loaded: language_helper
DEBUG - 2012-08-06 21:24:57 --> Helper loaded: form_helper
DEBUG - 2012-08-06 21:24:57 --> Form Validation Class Initialized
DEBUG - 2012-08-06 21:24:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 21:24:58 --> Final output sent to browser
DEBUG - 2012-08-06 21:24:58 --> Total execution time: 0.2282
DEBUG - 2012-08-06 21:27:41 --> Config Class Initialized
DEBUG - 2012-08-06 21:27:41 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:27:41 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:27:41 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:27:41 --> URI Class Initialized
DEBUG - 2012-08-06 21:27:41 --> Router Class Initialized
DEBUG - 2012-08-06 21:27:41 --> Output Class Initialized
DEBUG - 2012-08-06 21:27:41 --> Security Class Initialized
DEBUG - 2012-08-06 21:27:41 --> Input Class Initialized
DEBUG - 2012-08-06 21:27:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 21:27:41 --> Language Class Initialized
DEBUG - 2012-08-06 21:27:41 --> Loader Class Initialized
DEBUG - 2012-08-06 21:27:41 --> Helper loaded: url_helper
DEBUG - 2012-08-06 21:27:41 --> Controller Class Initialized
DEBUG - 2012-08-06 21:27:41 --> Model Class Initialized
DEBUG - 2012-08-06 21:27:41 --> Database Driver Class Initialized
DEBUG - 2012-08-06 21:27:41 --> Helper loaded: language_helper
DEBUG - 2012-08-06 21:27:41 --> Helper loaded: form_helper
DEBUG - 2012-08-06 21:27:41 --> Form Validation Class Initialized
DEBUG - 2012-08-06 21:27:41 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 21:27:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 21:27:41 --> Final output sent to browser
DEBUG - 2012-08-06 21:27:41 --> Total execution time: 0.0427
DEBUG - 2012-08-06 21:28:25 --> Config Class Initialized
DEBUG - 2012-08-06 21:28:25 --> Hooks Class Initialized
DEBUG - 2012-08-06 21:28:25 --> Utf8 Class Initialized
DEBUG - 2012-08-06 21:28:25 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 21:28:25 --> URI Class Initialized
DEBUG - 2012-08-06 21:28:25 --> Router Class Initialized
DEBUG - 2012-08-06 21:28:25 --> Output Class Initialized
DEBUG - 2012-08-06 21:28:25 --> Security Class Initialized
DEBUG - 2012-08-06 21:28:25 --> Input Class Initialized
DEBUG - 2012-08-06 21:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 21:28:25 --> Language Class Initialized
DEBUG - 2012-08-06 21:28:25 --> Loader Class Initialized
DEBUG - 2012-08-06 21:28:25 --> Helper loaded: url_helper
DEBUG - 2012-08-06 21:28:25 --> Controller Class Initialized
DEBUG - 2012-08-06 21:28:25 --> Model Class Initialized
DEBUG - 2012-08-06 21:28:25 --> Database Driver Class Initialized
DEBUG - 2012-08-06 21:28:25 --> Helper loaded: language_helper
DEBUG - 2012-08-06 21:28:25 --> Helper loaded: form_helper
DEBUG - 2012-08-06 21:28:25 --> Form Validation Class Initialized
DEBUG - 2012-08-06 21:28:25 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 21:28:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 21:28:25 --> Final output sent to browser
DEBUG - 2012-08-06 21:28:25 --> Total execution time: 0.0407
DEBUG - 2012-08-06 23:13:32 --> Config Class Initialized
DEBUG - 2012-08-06 23:13:32 --> Hooks Class Initialized
DEBUG - 2012-08-06 23:13:32 --> Utf8 Class Initialized
DEBUG - 2012-08-06 23:13:32 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 23:13:32 --> URI Class Initialized
DEBUG - 2012-08-06 23:13:32 --> Router Class Initialized
DEBUG - 2012-08-06 23:13:32 --> Output Class Initialized
DEBUG - 2012-08-06 23:13:32 --> Security Class Initialized
DEBUG - 2012-08-06 23:13:32 --> Input Class Initialized
DEBUG - 2012-08-06 23:13:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 23:13:32 --> Language Class Initialized
DEBUG - 2012-08-06 23:13:32 --> Loader Class Initialized
DEBUG - 2012-08-06 23:13:32 --> Helper loaded: url_helper
DEBUG - 2012-08-06 23:13:32 --> Controller Class Initialized
DEBUG - 2012-08-06 23:13:32 --> Model Class Initialized
DEBUG - 2012-08-06 23:13:32 --> Database Driver Class Initialized
DEBUG - 2012-08-06 23:13:32 --> Helper loaded: language_helper
DEBUG - 2012-08-06 23:13:32 --> Helper loaded: form_helper
DEBUG - 2012-08-06 23:13:32 --> Form Validation Class Initialized
DEBUG - 2012-08-06 23:13:32 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 23:13:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 23:13:32 --> Final output sent to browser
DEBUG - 2012-08-06 23:13:32 --> Total execution time: 0.0423
DEBUG - 2012-08-06 23:13:49 --> Config Class Initialized
DEBUG - 2012-08-06 23:13:49 --> Hooks Class Initialized
DEBUG - 2012-08-06 23:13:49 --> Utf8 Class Initialized
DEBUG - 2012-08-06 23:13:49 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 23:13:49 --> URI Class Initialized
DEBUG - 2012-08-06 23:13:49 --> Router Class Initialized
DEBUG - 2012-08-06 23:13:49 --> Output Class Initialized
DEBUG - 2012-08-06 23:13:49 --> Security Class Initialized
DEBUG - 2012-08-06 23:13:49 --> Input Class Initialized
DEBUG - 2012-08-06 23:13:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 23:13:49 --> Language Class Initialized
DEBUG - 2012-08-06 23:13:49 --> Loader Class Initialized
DEBUG - 2012-08-06 23:13:49 --> Helper loaded: url_helper
DEBUG - 2012-08-06 23:13:49 --> Controller Class Initialized
DEBUG - 2012-08-06 23:13:49 --> Model Class Initialized
DEBUG - 2012-08-06 23:13:49 --> Database Driver Class Initialized
DEBUG - 2012-08-06 23:13:49 --> Helper loaded: language_helper
DEBUG - 2012-08-06 23:13:49 --> Helper loaded: form_helper
DEBUG - 2012-08-06 23:13:49 --> Form Validation Class Initialized
DEBUG - 2012-08-06 23:13:49 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 23:13:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 23:13:49 --> Final output sent to browser
DEBUG - 2012-08-06 23:13:49 --> Total execution time: 0.0380
DEBUG - 2012-08-06 23:13:59 --> Config Class Initialized
DEBUG - 2012-08-06 23:13:59 --> Hooks Class Initialized
DEBUG - 2012-08-06 23:13:59 --> Utf8 Class Initialized
DEBUG - 2012-08-06 23:13:59 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 23:13:59 --> URI Class Initialized
DEBUG - 2012-08-06 23:13:59 --> Router Class Initialized
DEBUG - 2012-08-06 23:13:59 --> Output Class Initialized
DEBUG - 2012-08-06 23:13:59 --> Security Class Initialized
DEBUG - 2012-08-06 23:13:59 --> Input Class Initialized
DEBUG - 2012-08-06 23:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 23:13:59 --> Language Class Initialized
DEBUG - 2012-08-06 23:13:59 --> Loader Class Initialized
DEBUG - 2012-08-06 23:13:59 --> Helper loaded: url_helper
DEBUG - 2012-08-06 23:13:59 --> Controller Class Initialized
DEBUG - 2012-08-06 23:13:59 --> Model Class Initialized
DEBUG - 2012-08-06 23:13:59 --> Database Driver Class Initialized
DEBUG - 2012-08-06 23:13:59 --> Helper loaded: language_helper
DEBUG - 2012-08-06 23:13:59 --> Helper loaded: form_helper
DEBUG - 2012-08-06 23:13:59 --> Form Validation Class Initialized
DEBUG - 2012-08-06 23:13:59 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 23:13:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 23:13:59 --> Final output sent to browser
DEBUG - 2012-08-06 23:13:59 --> Total execution time: 0.0379
DEBUG - 2012-08-06 23:14:06 --> Config Class Initialized
DEBUG - 2012-08-06 23:14:06 --> Hooks Class Initialized
DEBUG - 2012-08-06 23:14:06 --> Utf8 Class Initialized
DEBUG - 2012-08-06 23:14:06 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 23:14:06 --> URI Class Initialized
DEBUG - 2012-08-06 23:14:06 --> Router Class Initialized
DEBUG - 2012-08-06 23:14:06 --> Output Class Initialized
DEBUG - 2012-08-06 23:14:06 --> Security Class Initialized
DEBUG - 2012-08-06 23:14:06 --> Input Class Initialized
DEBUG - 2012-08-06 23:14:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 23:14:06 --> Language Class Initialized
DEBUG - 2012-08-06 23:14:06 --> Loader Class Initialized
DEBUG - 2012-08-06 23:14:06 --> Helper loaded: url_helper
DEBUG - 2012-08-06 23:14:06 --> Controller Class Initialized
DEBUG - 2012-08-06 23:14:06 --> Model Class Initialized
DEBUG - 2012-08-06 23:14:06 --> Database Driver Class Initialized
DEBUG - 2012-08-06 23:14:06 --> Helper loaded: language_helper
DEBUG - 2012-08-06 23:14:06 --> Helper loaded: form_helper
DEBUG - 2012-08-06 23:14:06 --> Form Validation Class Initialized
DEBUG - 2012-08-06 23:14:06 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 23:14:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 23:14:06 --> Final output sent to browser
DEBUG - 2012-08-06 23:14:06 --> Total execution time: 0.0503
DEBUG - 2012-08-06 23:14:11 --> Config Class Initialized
DEBUG - 2012-08-06 23:14:11 --> Hooks Class Initialized
DEBUG - 2012-08-06 23:14:11 --> Utf8 Class Initialized
DEBUG - 2012-08-06 23:14:11 --> UTF-8 Support Disabled
DEBUG - 2012-08-06 23:14:11 --> URI Class Initialized
DEBUG - 2012-08-06 23:14:11 --> Router Class Initialized
DEBUG - 2012-08-06 23:14:11 --> Output Class Initialized
DEBUG - 2012-08-06 23:14:11 --> Security Class Initialized
DEBUG - 2012-08-06 23:14:11 --> Input Class Initialized
DEBUG - 2012-08-06 23:14:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 23:14:11 --> Language Class Initialized
DEBUG - 2012-08-06 23:14:11 --> Loader Class Initialized
DEBUG - 2012-08-06 23:14:11 --> Helper loaded: url_helper
DEBUG - 2012-08-06 23:14:11 --> Controller Class Initialized
DEBUG - 2012-08-06 23:14:11 --> Model Class Initialized
DEBUG - 2012-08-06 23:14:11 --> Database Driver Class Initialized
DEBUG - 2012-08-06 23:14:11 --> Helper loaded: language_helper
DEBUG - 2012-08-06 23:14:11 --> Helper loaded: form_helper
DEBUG - 2012-08-06 23:14:11 --> Form Validation Class Initialized
DEBUG - 2012-08-06 23:14:11 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-08-06 23:14:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-08-06 23:14:11 --> Final output sent to browser
DEBUG - 2012-08-06 23:14:11 --> Total execution time: 0.1831
