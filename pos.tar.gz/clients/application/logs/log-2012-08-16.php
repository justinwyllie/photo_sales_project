<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-08-16 22:37:33 --> Config Class Initialized
DEBUG - 2012-08-16 22:37:33 --> Hooks Class Initialized
DEBUG - 2012-08-16 22:37:33 --> Utf8 Class Initialized
DEBUG - 2012-08-16 22:37:33 --> UTF-8 Support Disabled
DEBUG - 2012-08-16 22:37:33 --> URI Class Initialized
DEBUG - 2012-08-16 22:37:33 --> Router Class Initialized
ERROR - 2012-08-16 22:37:33 --> 404 Page Not Found --> familysociety
