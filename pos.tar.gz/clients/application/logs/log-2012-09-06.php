<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-09-06 13:36:13 --> Config Class Initialized
DEBUG - 2012-09-06 13:36:13 --> Hooks Class Initialized
DEBUG - 2012-09-06 13:36:13 --> Utf8 Class Initialized
DEBUG - 2012-09-06 13:36:13 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 13:36:13 --> URI Class Initialized
DEBUG - 2012-09-06 13:36:13 --> Router Class Initialized
DEBUG - 2012-09-06 13:36:13 --> No URI present. Default controller set.
DEBUG - 2012-09-06 13:36:13 --> Output Class Initialized
DEBUG - 2012-09-06 13:36:13 --> Security Class Initialized
DEBUG - 2012-09-06 13:36:13 --> Input Class Initialized
DEBUG - 2012-09-06 13:36:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 13:36:13 --> Language Class Initialized
DEBUG - 2012-09-06 13:36:13 --> Loader Class Initialized
DEBUG - 2012-09-06 13:36:13 --> Helper loaded: url_helper
DEBUG - 2012-09-06 13:36:13 --> Controller Class Initialized
DEBUG - 2012-09-06 13:36:13 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-09-06 13:36:13 --> Final output sent to browser
DEBUG - 2012-09-06 13:36:13 --> Total execution time: 0.1312
DEBUG - 2012-09-06 13:36:19 --> Config Class Initialized
DEBUG - 2012-09-06 13:36:19 --> Hooks Class Initialized
DEBUG - 2012-09-06 13:36:19 --> Utf8 Class Initialized
DEBUG - 2012-09-06 13:36:19 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 13:36:19 --> URI Class Initialized
DEBUG - 2012-09-06 13:36:19 --> Router Class Initialized
DEBUG - 2012-09-06 13:36:19 --> No URI present. Default controller set.
DEBUG - 2012-09-06 13:36:19 --> Output Class Initialized
DEBUG - 2012-09-06 13:36:19 --> Security Class Initialized
DEBUG - 2012-09-06 13:36:19 --> Input Class Initialized
DEBUG - 2012-09-06 13:36:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 13:36:19 --> Language Class Initialized
DEBUG - 2012-09-06 13:36:19 --> Loader Class Initialized
DEBUG - 2012-09-06 13:36:19 --> Helper loaded: url_helper
DEBUG - 2012-09-06 13:36:19 --> Controller Class Initialized
DEBUG - 2012-09-06 13:36:19 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-09-06 13:36:19 --> Final output sent to browser
DEBUG - 2012-09-06 13:36:19 --> Total execution time: 0.1159
DEBUG - 2012-09-06 13:36:26 --> Config Class Initialized
DEBUG - 2012-09-06 13:36:26 --> Hooks Class Initialized
DEBUG - 2012-09-06 13:36:26 --> Utf8 Class Initialized
DEBUG - 2012-09-06 13:36:26 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 13:36:26 --> URI Class Initialized
DEBUG - 2012-09-06 13:36:26 --> Router Class Initialized
DEBUG - 2012-09-06 13:36:26 --> No URI present. Default controller set.
DEBUG - 2012-09-06 13:36:26 --> Output Class Initialized
DEBUG - 2012-09-06 13:36:26 --> Security Class Initialized
DEBUG - 2012-09-06 13:36:26 --> Input Class Initialized
DEBUG - 2012-09-06 13:36:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 13:36:26 --> Language Class Initialized
DEBUG - 2012-09-06 13:36:26 --> Loader Class Initialized
DEBUG - 2012-09-06 13:36:26 --> Helper loaded: url_helper
DEBUG - 2012-09-06 13:36:26 --> Controller Class Initialized
DEBUG - 2012-09-06 13:36:26 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-09-06 13:36:26 --> Final output sent to browser
DEBUG - 2012-09-06 13:36:26 --> Total execution time: 0.0184
DEBUG - 2012-09-06 13:36:30 --> Config Class Initialized
DEBUG - 2012-09-06 13:36:30 --> Hooks Class Initialized
DEBUG - 2012-09-06 13:36:30 --> Utf8 Class Initialized
DEBUG - 2012-09-06 13:36:30 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 13:36:30 --> URI Class Initialized
DEBUG - 2012-09-06 13:36:30 --> Router Class Initialized
ERROR - 2012-09-06 13:36:30 --> 404 Page Not Found --> admin/index
DEBUG - 2012-09-06 13:36:36 --> Config Class Initialized
DEBUG - 2012-09-06 13:36:36 --> Hooks Class Initialized
DEBUG - 2012-09-06 13:36:36 --> Utf8 Class Initialized
DEBUG - 2012-09-06 13:36:36 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 13:36:36 --> URI Class Initialized
DEBUG - 2012-09-06 13:36:36 --> Router Class Initialized
DEBUG - 2012-09-06 13:36:36 --> Output Class Initialized
DEBUG - 2012-09-06 13:36:36 --> Security Class Initialized
DEBUG - 2012-09-06 13:36:36 --> Input Class Initialized
DEBUG - 2012-09-06 13:36:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 13:36:36 --> Language Class Initialized
DEBUG - 2012-09-06 13:36:36 --> Loader Class Initialized
DEBUG - 2012-09-06 13:36:36 --> Helper loaded: url_helper
DEBUG - 2012-09-06 13:36:36 --> Controller Class Initialized
DEBUG - 2012-09-06 13:36:36 --> Model Class Initialized
DEBUG - 2012-09-06 13:36:37 --> Database Driver Class Initialized
DEBUG - 2012-09-06 13:36:37 --> Helper loaded: form_helper
DEBUG - 2012-09-06 13:36:37 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 13:36:37 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-09-06 13:36:37 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 13:36:37 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-09-06 13:36:37 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 13:36:37 --> Final output sent to browser
DEBUG - 2012-09-06 13:36:37 --> Total execution time: 0.6498
DEBUG - 2012-09-06 13:36:39 --> Config Class Initialized
DEBUG - 2012-09-06 13:36:39 --> Config Class Initialized
DEBUG - 2012-09-06 13:36:39 --> Hooks Class Initialized
DEBUG - 2012-09-06 13:36:39 --> Hooks Class Initialized
DEBUG - 2012-09-06 13:36:39 --> Utf8 Class Initialized
DEBUG - 2012-09-06 13:36:39 --> Utf8 Class Initialized
DEBUG - 2012-09-06 13:36:39 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 13:36:39 --> Config Class Initialized
DEBUG - 2012-09-06 13:36:39 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 13:36:39 --> Hooks Class Initialized
DEBUG - 2012-09-06 13:36:39 --> Utf8 Class Initialized
DEBUG - 2012-09-06 13:36:39 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 13:36:39 --> URI Class Initialized
DEBUG - 2012-09-06 13:36:39 --> URI Class Initialized
DEBUG - 2012-09-06 13:36:39 --> URI Class Initialized
DEBUG - 2012-09-06 13:36:39 --> Router Class Initialized
DEBUG - 2012-09-06 13:36:39 --> Router Class Initialized
DEBUG - 2012-09-06 13:36:39 --> Router Class Initialized
ERROR - 2012-09-06 13:36:39 --> 404 Page Not Found --> css
ERROR - 2012-09-06 13:36:39 --> 404 Page Not Found --> css
ERROR - 2012-09-06 13:36:39 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 13:48:59 --> Config Class Initialized
DEBUG - 2012-09-06 13:48:59 --> Hooks Class Initialized
DEBUG - 2012-09-06 13:48:59 --> Utf8 Class Initialized
DEBUG - 2012-09-06 13:48:59 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 13:48:59 --> URI Class Initialized
DEBUG - 2012-09-06 13:48:59 --> Router Class Initialized
DEBUG - 2012-09-06 13:48:59 --> Output Class Initialized
DEBUG - 2012-09-06 13:48:59 --> Security Class Initialized
DEBUG - 2012-09-06 13:48:59 --> Input Class Initialized
DEBUG - 2012-09-06 13:48:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 13:48:59 --> Language Class Initialized
DEBUG - 2012-09-06 13:48:59 --> Loader Class Initialized
DEBUG - 2012-09-06 13:48:59 --> Helper loaded: url_helper
DEBUG - 2012-09-06 13:48:59 --> Controller Class Initialized
DEBUG - 2012-09-06 13:48:59 --> Model Class Initialized
DEBUG - 2012-09-06 13:48:59 --> Database Driver Class Initialized
DEBUG - 2012-09-06 13:48:59 --> Helper loaded: form_helper
DEBUG - 2012-09-06 13:48:59 --> Helper loaded: html_helper
DEBUG - 2012-09-06 13:48:59 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-09-06 13:48:59 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-09-06 13:48:59 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-09-06 13:48:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-09-06 13:48:59 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 64
ERROR - 2012-09-06 13:48:59 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-09-06 13:48:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-09-06 13:48:59 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-09-06 13:48:59 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-09-06 13:48:59 --> Final output sent to browser
DEBUG - 2012-09-06 13:48:59 --> Total execution time: 0.1070
DEBUG - 2012-09-06 13:49:03 --> Config Class Initialized
DEBUG - 2012-09-06 13:49:03 --> Hooks Class Initialized
DEBUG - 2012-09-06 13:49:03 --> Utf8 Class Initialized
DEBUG - 2012-09-06 13:49:03 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 13:49:03 --> URI Class Initialized
DEBUG - 2012-09-06 13:49:03 --> Router Class Initialized
DEBUG - 2012-09-06 13:49:03 --> Output Class Initialized
DEBUG - 2012-09-06 13:49:03 --> Security Class Initialized
DEBUG - 2012-09-06 13:49:03 --> Input Class Initialized
DEBUG - 2012-09-06 13:49:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 13:49:03 --> Language Class Initialized
DEBUG - 2012-09-06 13:49:03 --> Loader Class Initialized
DEBUG - 2012-09-06 13:49:03 --> Helper loaded: url_helper
DEBUG - 2012-09-06 13:49:03 --> Controller Class Initialized
DEBUG - 2012-09-06 13:49:03 --> Model Class Initialized
DEBUG - 2012-09-06 13:49:03 --> Database Driver Class Initialized
DEBUG - 2012-09-06 13:49:03 --> Helper loaded: form_helper
DEBUG - 2012-09-06 13:49:03 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 13:49:03 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-09-06 13:49:03 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 13:49:03 --> File loaded: application/views/admin/pages/business/account.php
DEBUG - 2012-09-06 13:49:03 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 13:49:03 --> Final output sent to browser
DEBUG - 2012-09-06 13:49:03 --> Total execution time: 0.0648
DEBUG - 2012-09-06 13:49:13 --> Config Class Initialized
DEBUG - 2012-09-06 13:49:13 --> Hooks Class Initialized
DEBUG - 2012-09-06 13:49:13 --> Utf8 Class Initialized
DEBUG - 2012-09-06 13:49:13 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 13:49:13 --> URI Class Initialized
DEBUG - 2012-09-06 13:49:13 --> Router Class Initialized
DEBUG - 2012-09-06 13:49:13 --> Output Class Initialized
DEBUG - 2012-09-06 13:49:13 --> Security Class Initialized
DEBUG - 2012-09-06 13:49:13 --> Input Class Initialized
DEBUG - 2012-09-06 13:49:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 13:49:13 --> Language Class Initialized
DEBUG - 2012-09-06 13:49:13 --> Loader Class Initialized
DEBUG - 2012-09-06 13:49:13 --> Helper loaded: url_helper
DEBUG - 2012-09-06 13:49:13 --> Controller Class Initialized
DEBUG - 2012-09-06 13:49:13 --> Model Class Initialized
DEBUG - 2012-09-06 13:49:13 --> Database Driver Class Initialized
DEBUG - 2012-09-06 13:49:13 --> Helper loaded: form_helper
DEBUG - 2012-09-06 13:49:13 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 13:49:13 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-09-06 13:49:13 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 13:49:13 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-09-06 13:49:13 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 13:49:13 --> Final output sent to browser
DEBUG - 2012-09-06 13:49:13 --> Total execution time: 0.0447
DEBUG - 2012-09-06 13:49:18 --> Config Class Initialized
DEBUG - 2012-09-06 13:49:18 --> Hooks Class Initialized
DEBUG - 2012-09-06 13:49:18 --> Utf8 Class Initialized
DEBUG - 2012-09-06 13:49:18 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 13:49:18 --> URI Class Initialized
DEBUG - 2012-09-06 13:49:18 --> Router Class Initialized
DEBUG - 2012-09-06 13:49:18 --> Output Class Initialized
DEBUG - 2012-09-06 13:49:18 --> Security Class Initialized
DEBUG - 2012-09-06 13:49:18 --> Input Class Initialized
DEBUG - 2012-09-06 13:49:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 13:49:18 --> Language Class Initialized
DEBUG - 2012-09-06 13:49:18 --> Loader Class Initialized
DEBUG - 2012-09-06 13:49:18 --> Helper loaded: url_helper
DEBUG - 2012-09-06 13:49:18 --> Controller Class Initialized
DEBUG - 2012-09-06 13:49:18 --> Model Class Initialized
DEBUG - 2012-09-06 13:49:18 --> Database Driver Class Initialized
DEBUG - 2012-09-06 13:49:18 --> Helper loaded: language_helper
DEBUG - 2012-09-06 13:49:18 --> Helper loaded: html_helper
DEBUG - 2012-09-06 13:49:18 --> Helper loaded: form_helper
DEBUG - 2012-09-06 13:49:18 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-06 13:49:18 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 13:49:18 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-09-06 13:49:18 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 13:49:18 --> File loaded: application/views/admin/pages/business/logo.php
DEBUG - 2012-09-06 13:49:18 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 13:49:18 --> Final output sent to browser
DEBUG - 2012-09-06 13:49:18 --> Total execution time: 0.0986
DEBUG - 2012-09-06 13:49:21 --> Config Class Initialized
DEBUG - 2012-09-06 13:49:21 --> Hooks Class Initialized
DEBUG - 2012-09-06 13:49:21 --> Utf8 Class Initialized
DEBUG - 2012-09-06 13:49:21 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 13:49:21 --> URI Class Initialized
DEBUG - 2012-09-06 13:49:21 --> Router Class Initialized
DEBUG - 2012-09-06 13:49:21 --> Output Class Initialized
DEBUG - 2012-09-06 13:49:21 --> Security Class Initialized
DEBUG - 2012-09-06 13:49:21 --> Input Class Initialized
DEBUG - 2012-09-06 13:49:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 13:49:21 --> Language Class Initialized
DEBUG - 2012-09-06 13:49:21 --> Loader Class Initialized
DEBUG - 2012-09-06 13:49:21 --> Helper loaded: url_helper
DEBUG - 2012-09-06 13:49:21 --> Controller Class Initialized
DEBUG - 2012-09-06 13:49:21 --> Model Class Initialized
DEBUG - 2012-09-06 13:49:21 --> Database Driver Class Initialized
DEBUG - 2012-09-06 13:49:21 --> Helper loaded: form_helper
DEBUG - 2012-09-06 13:49:21 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 13:49:21 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 13:49:21 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 13:49:21 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 13:49:21 --> Final output sent to browser
DEBUG - 2012-09-06 13:49:21 --> Total execution time: 0.0796
DEBUG - 2012-09-06 13:49:44 --> Config Class Initialized
DEBUG - 2012-09-06 13:49:44 --> Hooks Class Initialized
DEBUG - 2012-09-06 13:49:44 --> Utf8 Class Initialized
DEBUG - 2012-09-06 13:49:44 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 13:49:44 --> URI Class Initialized
DEBUG - 2012-09-06 13:49:44 --> Router Class Initialized
DEBUG - 2012-09-06 13:49:44 --> Output Class Initialized
DEBUG - 2012-09-06 13:49:44 --> Security Class Initialized
DEBUG - 2012-09-06 13:49:44 --> Input Class Initialized
DEBUG - 2012-09-06 13:49:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 13:49:44 --> Language Class Initialized
DEBUG - 2012-09-06 13:49:44 --> Loader Class Initialized
DEBUG - 2012-09-06 13:49:44 --> Helper loaded: url_helper
DEBUG - 2012-09-06 13:49:44 --> Controller Class Initialized
DEBUG - 2012-09-06 13:49:44 --> Model Class Initialized
DEBUG - 2012-09-06 13:49:44 --> Database Driver Class Initialized
DEBUG - 2012-09-06 13:49:44 --> Final output sent to browser
DEBUG - 2012-09-06 13:49:44 --> Total execution time: 0.1554
DEBUG - 2012-09-06 13:50:10 --> Config Class Initialized
DEBUG - 2012-09-06 13:50:10 --> Hooks Class Initialized
DEBUG - 2012-09-06 13:50:10 --> Utf8 Class Initialized
DEBUG - 2012-09-06 13:50:10 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 13:50:10 --> URI Class Initialized
DEBUG - 2012-09-06 13:50:10 --> Router Class Initialized
DEBUG - 2012-09-06 13:50:10 --> Output Class Initialized
DEBUG - 2012-09-06 13:50:10 --> Security Class Initialized
DEBUG - 2012-09-06 13:50:10 --> Input Class Initialized
DEBUG - 2012-09-06 13:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 13:50:10 --> Language Class Initialized
DEBUG - 2012-09-06 13:50:10 --> Loader Class Initialized
DEBUG - 2012-09-06 13:50:10 --> Helper loaded: url_helper
DEBUG - 2012-09-06 13:50:10 --> Controller Class Initialized
DEBUG - 2012-09-06 13:50:10 --> Model Class Initialized
DEBUG - 2012-09-06 13:50:10 --> Database Driver Class Initialized
DEBUG - 2012-09-06 13:50:10 --> Helper loaded: form_helper
DEBUG - 2012-09-06 13:50:10 --> Form Validation Class Initialized
DEBUG - 2012-09-06 13:54:32 --> Config Class Initialized
DEBUG - 2012-09-06 13:54:32 --> Hooks Class Initialized
DEBUG - 2012-09-06 13:54:32 --> Utf8 Class Initialized
DEBUG - 2012-09-06 13:54:32 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 13:54:32 --> URI Class Initialized
DEBUG - 2012-09-06 13:54:32 --> Router Class Initialized
DEBUG - 2012-09-06 13:54:32 --> Output Class Initialized
DEBUG - 2012-09-06 13:54:32 --> Security Class Initialized
DEBUG - 2012-09-06 13:54:32 --> Input Class Initialized
DEBUG - 2012-09-06 13:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 13:54:32 --> Language Class Initialized
DEBUG - 2012-09-06 13:54:32 --> Loader Class Initialized
DEBUG - 2012-09-06 13:54:32 --> Helper loaded: url_helper
DEBUG - 2012-09-06 13:54:32 --> Controller Class Initialized
DEBUG - 2012-09-06 13:54:32 --> Model Class Initialized
DEBUG - 2012-09-06 13:54:32 --> Database Driver Class Initialized
DEBUG - 2012-09-06 13:54:32 --> Helper loaded: form_helper
DEBUG - 2012-09-06 13:54:32 --> Form Validation Class Initialized
DEBUG - 2012-09-06 14:02:48 --> Config Class Initialized
DEBUG - 2012-09-06 14:02:48 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:02:48 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:02:48 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:02:48 --> URI Class Initialized
DEBUG - 2012-09-06 14:02:48 --> Router Class Initialized
DEBUG - 2012-09-06 14:02:48 --> Output Class Initialized
DEBUG - 2012-09-06 14:02:48 --> Security Class Initialized
DEBUG - 2012-09-06 14:02:48 --> Input Class Initialized
DEBUG - 2012-09-06 14:02:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:02:48 --> Language Class Initialized
DEBUG - 2012-09-06 14:02:48 --> Loader Class Initialized
DEBUG - 2012-09-06 14:02:48 --> Helper loaded: url_helper
DEBUG - 2012-09-06 14:02:48 --> Controller Class Initialized
DEBUG - 2012-09-06 14:02:48 --> Model Class Initialized
DEBUG - 2012-09-06 14:02:48 --> Database Driver Class Initialized
DEBUG - 2012-09-06 14:02:48 --> Helper loaded: form_helper
DEBUG - 2012-09-06 14:02:48 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 14:02:48 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-09-06 14:02:48 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 14:02:48 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-09-06 14:02:48 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 14:02:48 --> Final output sent to browser
DEBUG - 2012-09-06 14:02:48 --> Total execution time: 0.0393
DEBUG - 2012-09-06 14:03:09 --> Config Class Initialized
DEBUG - 2012-09-06 14:03:09 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:03:09 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:03:09 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:03:09 --> URI Class Initialized
DEBUG - 2012-09-06 14:03:09 --> Router Class Initialized
DEBUG - 2012-09-06 14:03:09 --> Output Class Initialized
DEBUG - 2012-09-06 14:03:09 --> Security Class Initialized
DEBUG - 2012-09-06 14:03:09 --> Input Class Initialized
DEBUG - 2012-09-06 14:03:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:03:09 --> Language Class Initialized
DEBUG - 2012-09-06 14:03:09 --> Loader Class Initialized
DEBUG - 2012-09-06 14:03:09 --> Helper loaded: url_helper
DEBUG - 2012-09-06 14:03:09 --> Controller Class Initialized
DEBUG - 2012-09-06 14:03:09 --> Model Class Initialized
DEBUG - 2012-09-06 14:03:09 --> Database Driver Class Initialized
DEBUG - 2012-09-06 14:03:09 --> Helper loaded: form_helper
DEBUG - 2012-09-06 14:03:09 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 14:03:09 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 14:03:09 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 14:03:09 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 14:03:09 --> Final output sent to browser
DEBUG - 2012-09-06 14:03:09 --> Total execution time: 0.0476
DEBUG - 2012-09-06 14:05:54 --> Config Class Initialized
DEBUG - 2012-09-06 14:05:54 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:05:54 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:05:54 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:05:54 --> URI Class Initialized
DEBUG - 2012-09-06 14:05:54 --> Router Class Initialized
DEBUG - 2012-09-06 14:05:54 --> Output Class Initialized
DEBUG - 2012-09-06 14:05:54 --> Security Class Initialized
DEBUG - 2012-09-06 14:05:54 --> Input Class Initialized
DEBUG - 2012-09-06 14:05:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:05:54 --> Language Class Initialized
DEBUG - 2012-09-06 14:05:54 --> Loader Class Initialized
DEBUG - 2012-09-06 14:05:54 --> Helper loaded: url_helper
DEBUG - 2012-09-06 14:05:54 --> Controller Class Initialized
DEBUG - 2012-09-06 14:05:54 --> Model Class Initialized
DEBUG - 2012-09-06 14:05:54 --> Database Driver Class Initialized
DEBUG - 2012-09-06 14:05:54 --> Helper loaded: form_helper
DEBUG - 2012-09-06 14:05:54 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 14:05:54 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-09-06 14:05:54 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 14:05:54 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-09-06 14:05:54 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 14:05:54 --> Final output sent to browser
DEBUG - 2012-09-06 14:05:54 --> Total execution time: 0.0399
DEBUG - 2012-09-06 14:07:50 --> Config Class Initialized
DEBUG - 2012-09-06 14:07:50 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:07:50 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:07:50 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:07:50 --> URI Class Initialized
DEBUG - 2012-09-06 14:07:50 --> Router Class Initialized
DEBUG - 2012-09-06 14:07:50 --> Output Class Initialized
DEBUG - 2012-09-06 14:07:50 --> Security Class Initialized
DEBUG - 2012-09-06 14:07:50 --> Input Class Initialized
DEBUG - 2012-09-06 14:07:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:07:50 --> Language Class Initialized
DEBUG - 2012-09-06 14:07:50 --> Loader Class Initialized
DEBUG - 2012-09-06 14:07:50 --> Helper loaded: url_helper
DEBUG - 2012-09-06 14:07:50 --> Controller Class Initialized
DEBUG - 2012-09-06 14:07:50 --> Model Class Initialized
DEBUG - 2012-09-06 14:07:50 --> Database Driver Class Initialized
DEBUG - 2012-09-06 14:07:50 --> Helper loaded: form_helper
DEBUG - 2012-09-06 14:07:50 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 14:07:50 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-09-06 14:07:50 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 14:07:50 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-09-06 14:07:50 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 14:07:50 --> Final output sent to browser
DEBUG - 2012-09-06 14:07:50 --> Total execution time: 0.0443
DEBUG - 2012-09-06 14:07:54 --> Config Class Initialized
DEBUG - 2012-09-06 14:07:54 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:07:54 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:07:54 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:07:54 --> URI Class Initialized
DEBUG - 2012-09-06 14:07:54 --> Router Class Initialized
DEBUG - 2012-09-06 14:07:54 --> Output Class Initialized
DEBUG - 2012-09-06 14:07:54 --> Security Class Initialized
DEBUG - 2012-09-06 14:07:54 --> Input Class Initialized
DEBUG - 2012-09-06 14:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:07:54 --> Language Class Initialized
DEBUG - 2012-09-06 14:07:54 --> Loader Class Initialized
DEBUG - 2012-09-06 14:07:54 --> Helper loaded: url_helper
DEBUG - 2012-09-06 14:07:54 --> Controller Class Initialized
DEBUG - 2012-09-06 14:07:54 --> Model Class Initialized
DEBUG - 2012-09-06 14:07:54 --> Database Driver Class Initialized
DEBUG - 2012-09-06 14:07:54 --> Helper loaded: form_helper
DEBUG - 2012-09-06 14:07:54 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 14:07:54 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 14:07:54 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 14:07:54 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 14:07:54 --> Final output sent to browser
DEBUG - 2012-09-06 14:07:54 --> Total execution time: 0.0449
DEBUG - 2012-09-06 14:07:55 --> Config Class Initialized
DEBUG - 2012-09-06 14:07:55 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:07:55 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:07:55 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:07:55 --> URI Class Initialized
DEBUG - 2012-09-06 14:07:55 --> Router Class Initialized
DEBUG - 2012-09-06 14:07:55 --> Output Class Initialized
DEBUG - 2012-09-06 14:07:55 --> Security Class Initialized
DEBUG - 2012-09-06 14:07:55 --> Input Class Initialized
DEBUG - 2012-09-06 14:07:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:07:55 --> Language Class Initialized
DEBUG - 2012-09-06 14:07:55 --> Loader Class Initialized
DEBUG - 2012-09-06 14:07:55 --> Helper loaded: url_helper
DEBUG - 2012-09-06 14:07:55 --> Controller Class Initialized
DEBUG - 2012-09-06 14:07:55 --> Model Class Initialized
DEBUG - 2012-09-06 14:07:55 --> Database Driver Class Initialized
DEBUG - 2012-09-06 14:07:55 --> Helper loaded: form_helper
DEBUG - 2012-09-06 14:07:55 --> Form Validation Class Initialized
DEBUG - 2012-09-06 14:11:59 --> Config Class Initialized
DEBUG - 2012-09-06 14:11:59 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:11:59 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:11:59 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:11:59 --> URI Class Initialized
DEBUG - 2012-09-06 14:11:59 --> Router Class Initialized
DEBUG - 2012-09-06 14:11:59 --> Output Class Initialized
DEBUG - 2012-09-06 14:11:59 --> Security Class Initialized
DEBUG - 2012-09-06 14:11:59 --> Input Class Initialized
DEBUG - 2012-09-06 14:11:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:11:59 --> Language Class Initialized
DEBUG - 2012-09-06 14:11:59 --> Loader Class Initialized
DEBUG - 2012-09-06 14:11:59 --> Helper loaded: url_helper
DEBUG - 2012-09-06 14:11:59 --> Controller Class Initialized
DEBUG - 2012-09-06 14:11:59 --> Model Class Initialized
DEBUG - 2012-09-06 14:11:59 --> Database Driver Class Initialized
DEBUG - 2012-09-06 14:11:59 --> Helper loaded: form_helper
DEBUG - 2012-09-06 14:11:59 --> Form Validation Class Initialized
DEBUG - 2012-09-06 14:12:11 --> Config Class Initialized
DEBUG - 2012-09-06 14:12:11 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:12:11 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:12:11 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:12:11 --> URI Class Initialized
DEBUG - 2012-09-06 14:12:11 --> Router Class Initialized
DEBUG - 2012-09-06 14:12:11 --> Output Class Initialized
DEBUG - 2012-09-06 14:12:11 --> Security Class Initialized
DEBUG - 2012-09-06 14:12:11 --> Input Class Initialized
DEBUG - 2012-09-06 14:12:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:12:11 --> Language Class Initialized
DEBUG - 2012-09-06 14:12:11 --> Loader Class Initialized
DEBUG - 2012-09-06 14:12:11 --> Helper loaded: url_helper
DEBUG - 2012-09-06 14:12:11 --> Controller Class Initialized
DEBUG - 2012-09-06 14:12:11 --> Model Class Initialized
DEBUG - 2012-09-06 14:12:11 --> Database Driver Class Initialized
DEBUG - 2012-09-06 14:12:11 --> Helper loaded: form_helper
DEBUG - 2012-09-06 14:12:11 --> Form Validation Class Initialized
DEBUG - 2012-09-06 14:23:14 --> Config Class Initialized
DEBUG - 2012-09-06 14:23:14 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:23:14 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:23:14 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:23:14 --> URI Class Initialized
DEBUG - 2012-09-06 14:23:14 --> Router Class Initialized
DEBUG - 2012-09-06 14:23:14 --> Output Class Initialized
DEBUG - 2012-09-06 14:23:14 --> Security Class Initialized
DEBUG - 2012-09-06 14:23:14 --> Input Class Initialized
DEBUG - 2012-09-06 14:23:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:23:14 --> Language Class Initialized
DEBUG - 2012-09-06 14:23:14 --> Loader Class Initialized
DEBUG - 2012-09-06 14:23:14 --> Helper loaded: url_helper
DEBUG - 2012-09-06 14:23:14 --> Controller Class Initialized
DEBUG - 2012-09-06 14:23:14 --> Model Class Initialized
DEBUG - 2012-09-06 14:23:14 --> Database Driver Class Initialized
DEBUG - 2012-09-06 14:23:14 --> Helper loaded: form_helper
DEBUG - 2012-09-06 14:23:14 --> Form Validation Class Initialized
DEBUG - 2012-09-06 14:27:22 --> Config Class Initialized
DEBUG - 2012-09-06 14:27:22 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:27:22 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:27:22 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:27:22 --> URI Class Initialized
DEBUG - 2012-09-06 14:27:22 --> Router Class Initialized
DEBUG - 2012-09-06 14:27:22 --> Output Class Initialized
DEBUG - 2012-09-06 14:27:22 --> Security Class Initialized
DEBUG - 2012-09-06 14:27:22 --> Input Class Initialized
DEBUG - 2012-09-06 14:27:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:27:22 --> Language Class Initialized
DEBUG - 2012-09-06 14:27:22 --> Loader Class Initialized
DEBUG - 2012-09-06 14:27:22 --> Helper loaded: url_helper
DEBUG - 2012-09-06 14:27:22 --> Controller Class Initialized
DEBUG - 2012-09-06 14:27:22 --> Model Class Initialized
DEBUG - 2012-09-06 14:27:22 --> Database Driver Class Initialized
DEBUG - 2012-09-06 14:27:22 --> Helper loaded: form_helper
DEBUG - 2012-09-06 14:27:22 --> Form Validation Class Initialized
DEBUG - 2012-09-06 14:27:42 --> Config Class Initialized
DEBUG - 2012-09-06 14:27:42 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:27:42 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:27:42 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:27:42 --> URI Class Initialized
DEBUG - 2012-09-06 14:27:42 --> Router Class Initialized
DEBUG - 2012-09-06 14:27:42 --> Output Class Initialized
DEBUG - 2012-09-06 14:27:42 --> Security Class Initialized
DEBUG - 2012-09-06 14:27:42 --> Input Class Initialized
DEBUG - 2012-09-06 14:27:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:27:42 --> Language Class Initialized
DEBUG - 2012-09-06 14:27:42 --> Loader Class Initialized
DEBUG - 2012-09-06 14:27:42 --> Helper loaded: url_helper
DEBUG - 2012-09-06 14:27:42 --> Controller Class Initialized
DEBUG - 2012-09-06 14:27:42 --> Model Class Initialized
DEBUG - 2012-09-06 14:27:42 --> Database Driver Class Initialized
DEBUG - 2012-09-06 14:27:42 --> Helper loaded: form_helper
DEBUG - 2012-09-06 14:27:43 --> Form Validation Class Initialized
DEBUG - 2012-09-06 14:28:56 --> Config Class Initialized
DEBUG - 2012-09-06 14:28:56 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:28:56 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:28:56 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:28:56 --> URI Class Initialized
DEBUG - 2012-09-06 14:28:56 --> Router Class Initialized
DEBUG - 2012-09-06 14:28:56 --> Output Class Initialized
DEBUG - 2012-09-06 14:28:56 --> Security Class Initialized
DEBUG - 2012-09-06 14:28:56 --> Input Class Initialized
DEBUG - 2012-09-06 14:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:28:56 --> Language Class Initialized
DEBUG - 2012-09-06 14:28:56 --> Loader Class Initialized
DEBUG - 2012-09-06 14:28:56 --> Helper loaded: url_helper
DEBUG - 2012-09-06 14:28:56 --> Controller Class Initialized
DEBUG - 2012-09-06 14:28:56 --> Model Class Initialized
DEBUG - 2012-09-06 14:28:56 --> Database Driver Class Initialized
DEBUG - 2012-09-06 14:28:56 --> Helper loaded: form_helper
DEBUG - 2012-09-06 14:28:56 --> Form Validation Class Initialized
DEBUG - 2012-09-06 14:32:36 --> Config Class Initialized
DEBUG - 2012-09-06 14:32:36 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:32:36 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:32:36 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:32:36 --> URI Class Initialized
DEBUG - 2012-09-06 14:32:36 --> Router Class Initialized
DEBUG - 2012-09-06 14:32:36 --> Output Class Initialized
DEBUG - 2012-09-06 14:32:36 --> Security Class Initialized
DEBUG - 2012-09-06 14:32:36 --> Input Class Initialized
DEBUG - 2012-09-06 14:32:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:32:36 --> Language Class Initialized
DEBUG - 2012-09-06 14:32:36 --> Loader Class Initialized
DEBUG - 2012-09-06 14:32:36 --> Helper loaded: url_helper
DEBUG - 2012-09-06 14:32:36 --> Controller Class Initialized
DEBUG - 2012-09-06 14:32:36 --> Model Class Initialized
DEBUG - 2012-09-06 14:32:36 --> Database Driver Class Initialized
DEBUG - 2012-09-06 14:32:36 --> Helper loaded: form_helper
DEBUG - 2012-09-06 14:32:36 --> Form Validation Class Initialized
DEBUG - 2012-09-06 14:33:45 --> Config Class Initialized
DEBUG - 2012-09-06 14:33:45 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:33:45 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:33:45 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:33:45 --> URI Class Initialized
DEBUG - 2012-09-06 14:33:45 --> Router Class Initialized
DEBUG - 2012-09-06 14:33:45 --> Output Class Initialized
DEBUG - 2012-09-06 14:33:45 --> Security Class Initialized
DEBUG - 2012-09-06 14:33:45 --> Input Class Initialized
DEBUG - 2012-09-06 14:33:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:33:45 --> Language Class Initialized
DEBUG - 2012-09-06 14:33:45 --> Loader Class Initialized
DEBUG - 2012-09-06 14:33:45 --> Helper loaded: url_helper
DEBUG - 2012-09-06 14:33:45 --> Controller Class Initialized
DEBUG - 2012-09-06 14:33:45 --> Model Class Initialized
DEBUG - 2012-09-06 14:33:45 --> Database Driver Class Initialized
DEBUG - 2012-09-06 14:33:45 --> Helper loaded: form_helper
DEBUG - 2012-09-06 14:33:45 --> Form Validation Class Initialized
DEBUG - 2012-09-06 14:35:16 --> Config Class Initialized
DEBUG - 2012-09-06 14:35:16 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:35:16 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:35:16 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:35:16 --> URI Class Initialized
DEBUG - 2012-09-06 14:35:16 --> Router Class Initialized
DEBUG - 2012-09-06 14:35:16 --> Output Class Initialized
DEBUG - 2012-09-06 14:35:16 --> Security Class Initialized
DEBUG - 2012-09-06 14:35:16 --> Input Class Initialized
DEBUG - 2012-09-06 14:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:35:16 --> Language Class Initialized
DEBUG - 2012-09-06 14:35:16 --> Loader Class Initialized
DEBUG - 2012-09-06 14:35:16 --> Helper loaded: url_helper
DEBUG - 2012-09-06 14:35:16 --> Controller Class Initialized
DEBUG - 2012-09-06 14:35:16 --> Model Class Initialized
DEBUG - 2012-09-06 14:35:16 --> Database Driver Class Initialized
DEBUG - 2012-09-06 14:35:16 --> Helper loaded: form_helper
DEBUG - 2012-09-06 14:35:16 --> Form Validation Class Initialized
DEBUG - 2012-09-06 14:35:16 --> Final output sent to browser
DEBUG - 2012-09-06 14:35:16 --> Total execution time: 0.0491
DEBUG - 2012-09-06 14:36:33 --> Config Class Initialized
DEBUG - 2012-09-06 14:36:33 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:36:33 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:36:33 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:36:33 --> URI Class Initialized
DEBUG - 2012-09-06 14:36:33 --> Router Class Initialized
DEBUG - 2012-09-06 14:36:33 --> Output Class Initialized
DEBUG - 2012-09-06 14:36:33 --> Security Class Initialized
DEBUG - 2012-09-06 14:36:33 --> Input Class Initialized
DEBUG - 2012-09-06 14:36:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:36:33 --> Language Class Initialized
DEBUG - 2012-09-06 14:36:33 --> Loader Class Initialized
DEBUG - 2012-09-06 14:36:33 --> Helper loaded: url_helper
DEBUG - 2012-09-06 14:36:33 --> Controller Class Initialized
DEBUG - 2012-09-06 14:36:33 --> Model Class Initialized
DEBUG - 2012-09-06 14:36:33 --> Database Driver Class Initialized
DEBUG - 2012-09-06 14:36:33 --> Helper loaded: form_helper
DEBUG - 2012-09-06 14:36:33 --> Form Validation Class Initialized
DEBUG - 2012-09-06 14:36:33 --> Final output sent to browser
DEBUG - 2012-09-06 14:36:33 --> Total execution time: 0.0451
DEBUG - 2012-09-06 14:36:36 --> Config Class Initialized
DEBUG - 2012-09-06 14:36:36 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:36:36 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:36:36 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:36:36 --> URI Class Initialized
DEBUG - 2012-09-06 14:36:36 --> Router Class Initialized
DEBUG - 2012-09-06 14:36:36 --> Output Class Initialized
DEBUG - 2012-09-06 14:36:36 --> Security Class Initialized
DEBUG - 2012-09-06 14:36:36 --> Input Class Initialized
DEBUG - 2012-09-06 14:36:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:36:36 --> Language Class Initialized
DEBUG - 2012-09-06 14:36:36 --> Loader Class Initialized
DEBUG - 2012-09-06 14:36:36 --> Helper loaded: url_helper
DEBUG - 2012-09-06 14:36:36 --> Controller Class Initialized
DEBUG - 2012-09-06 14:36:36 --> Model Class Initialized
DEBUG - 2012-09-06 14:36:36 --> Database Driver Class Initialized
DEBUG - 2012-09-06 14:36:36 --> Helper loaded: form_helper
DEBUG - 2012-09-06 14:36:36 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 14:36:36 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 14:36:36 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 14:36:36 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 14:36:36 --> Final output sent to browser
DEBUG - 2012-09-06 14:36:36 --> Total execution time: 0.0423
DEBUG - 2012-09-06 14:36:38 --> Config Class Initialized
DEBUG - 2012-09-06 14:36:38 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:36:38 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:36:38 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:36:38 --> URI Class Initialized
DEBUG - 2012-09-06 14:36:38 --> Router Class Initialized
DEBUG - 2012-09-06 14:36:38 --> Output Class Initialized
DEBUG - 2012-09-06 14:36:38 --> Security Class Initialized
DEBUG - 2012-09-06 14:36:38 --> Input Class Initialized
DEBUG - 2012-09-06 14:36:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:36:38 --> Language Class Initialized
DEBUG - 2012-09-06 14:36:38 --> Loader Class Initialized
DEBUG - 2012-09-06 14:36:38 --> Helper loaded: url_helper
DEBUG - 2012-09-06 14:36:38 --> Controller Class Initialized
DEBUG - 2012-09-06 14:36:38 --> Model Class Initialized
DEBUG - 2012-09-06 14:36:38 --> Database Driver Class Initialized
DEBUG - 2012-09-06 14:36:38 --> Helper loaded: form_helper
DEBUG - 2012-09-06 14:36:38 --> Form Validation Class Initialized
DEBUG - 2012-09-06 14:36:38 --> Final output sent to browser
DEBUG - 2012-09-06 14:36:38 --> Total execution time: 0.0375
DEBUG - 2012-09-06 14:37:58 --> Config Class Initialized
DEBUG - 2012-09-06 14:37:58 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:37:58 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:37:58 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:37:58 --> URI Class Initialized
DEBUG - 2012-09-06 14:37:58 --> Router Class Initialized
DEBUG - 2012-09-06 14:37:58 --> Output Class Initialized
DEBUG - 2012-09-06 14:37:58 --> Security Class Initialized
DEBUG - 2012-09-06 14:37:58 --> Input Class Initialized
DEBUG - 2012-09-06 14:37:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:37:58 --> Language Class Initialized
DEBUG - 2012-09-06 14:37:58 --> Loader Class Initialized
DEBUG - 2012-09-06 14:37:58 --> Helper loaded: url_helper
DEBUG - 2012-09-06 14:37:58 --> Controller Class Initialized
DEBUG - 2012-09-06 14:37:58 --> Model Class Initialized
DEBUG - 2012-09-06 14:37:58 --> Database Driver Class Initialized
DEBUG - 2012-09-06 14:37:58 --> Final output sent to browser
DEBUG - 2012-09-06 14:37:58 --> Total execution time: 0.1115
DEBUG - 2012-09-06 14:38:02 --> Config Class Initialized
DEBUG - 2012-09-06 14:38:02 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:38:02 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:38:02 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:38:02 --> URI Class Initialized
DEBUG - 2012-09-06 14:38:02 --> Router Class Initialized
DEBUG - 2012-09-06 14:38:02 --> Output Class Initialized
DEBUG - 2012-09-06 14:38:02 --> Security Class Initialized
DEBUG - 2012-09-06 14:38:02 --> Input Class Initialized
DEBUG - 2012-09-06 14:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:38:02 --> Language Class Initialized
DEBUG - 2012-09-06 14:38:02 --> Loader Class Initialized
DEBUG - 2012-09-06 14:38:02 --> Helper loaded: url_helper
DEBUG - 2012-09-06 14:38:02 --> Controller Class Initialized
DEBUG - 2012-09-06 14:38:02 --> Model Class Initialized
DEBUG - 2012-09-06 14:38:02 --> Database Driver Class Initialized
DEBUG - 2012-09-06 14:38:02 --> Helper loaded: form_helper
DEBUG - 2012-09-06 14:38:02 --> Form Validation Class Initialized
DEBUG - 2012-09-06 14:38:02 --> Final output sent to browser
DEBUG - 2012-09-06 14:38:02 --> Total execution time: 0.0415
DEBUG - 2012-09-06 14:38:29 --> Config Class Initialized
DEBUG - 2012-09-06 14:38:29 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:38:29 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:38:29 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:38:29 --> URI Class Initialized
DEBUG - 2012-09-06 14:38:29 --> Router Class Initialized
DEBUG - 2012-09-06 14:38:29 --> Output Class Initialized
DEBUG - 2012-09-06 14:38:29 --> Security Class Initialized
DEBUG - 2012-09-06 14:38:29 --> Input Class Initialized
DEBUG - 2012-09-06 14:38:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:38:29 --> Language Class Initialized
DEBUG - 2012-09-06 14:38:29 --> Loader Class Initialized
DEBUG - 2012-09-06 14:38:29 --> Helper loaded: url_helper
DEBUG - 2012-09-06 14:38:29 --> Controller Class Initialized
DEBUG - 2012-09-06 14:38:29 --> Model Class Initialized
DEBUG - 2012-09-06 14:38:29 --> Database Driver Class Initialized
DEBUG - 2012-09-06 14:38:29 --> Final output sent to browser
DEBUG - 2012-09-06 14:38:29 --> Total execution time: 0.0942
DEBUG - 2012-09-06 14:57:12 --> Config Class Initialized
DEBUG - 2012-09-06 14:57:12 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:57:12 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:57:12 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:57:12 --> URI Class Initialized
DEBUG - 2012-09-06 14:57:12 --> Router Class Initialized
DEBUG - 2012-09-06 14:57:12 --> Output Class Initialized
DEBUG - 2012-09-06 14:57:12 --> Security Class Initialized
DEBUG - 2012-09-06 14:57:12 --> Input Class Initialized
DEBUG - 2012-09-06 14:57:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:57:12 --> Language Class Initialized
DEBUG - 2012-09-06 14:57:12 --> Loader Class Initialized
DEBUG - 2012-09-06 14:57:12 --> Helper loaded: url_helper
DEBUG - 2012-09-06 14:57:12 --> Controller Class Initialized
DEBUG - 2012-09-06 14:57:12 --> Model Class Initialized
DEBUG - 2012-09-06 14:57:12 --> Database Driver Class Initialized
DEBUG - 2012-09-06 14:57:12 --> Helper loaded: form_helper
DEBUG - 2012-09-06 14:57:12 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 14:57:12 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 14:57:12 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 14:57:12 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 14:57:12 --> Final output sent to browser
DEBUG - 2012-09-06 14:57:12 --> Total execution time: 0.0389
DEBUG - 2012-09-06 14:57:15 --> Config Class Initialized
DEBUG - 2012-09-06 14:57:15 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:57:15 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:57:15 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:57:15 --> URI Class Initialized
DEBUG - 2012-09-06 14:57:15 --> Router Class Initialized
DEBUG - 2012-09-06 14:57:15 --> Output Class Initialized
DEBUG - 2012-09-06 14:57:15 --> Security Class Initialized
DEBUG - 2012-09-06 14:57:15 --> Input Class Initialized
DEBUG - 2012-09-06 14:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:57:15 --> Language Class Initialized
DEBUG - 2012-09-06 14:57:15 --> Loader Class Initialized
DEBUG - 2012-09-06 14:57:15 --> Helper loaded: url_helper
DEBUG - 2012-09-06 14:57:15 --> Controller Class Initialized
DEBUG - 2012-09-06 14:57:15 --> Model Class Initialized
DEBUG - 2012-09-06 14:57:15 --> Database Driver Class Initialized
DEBUG - 2012-09-06 14:57:15 --> Final output sent to browser
DEBUG - 2012-09-06 14:57:15 --> Total execution time: 0.1604
DEBUG - 2012-09-06 14:59:57 --> Config Class Initialized
DEBUG - 2012-09-06 14:59:57 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:59:57 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:59:57 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:59:57 --> URI Class Initialized
DEBUG - 2012-09-06 14:59:57 --> Router Class Initialized
DEBUG - 2012-09-06 14:59:57 --> Output Class Initialized
DEBUG - 2012-09-06 14:59:57 --> Security Class Initialized
DEBUG - 2012-09-06 14:59:57 --> Input Class Initialized
DEBUG - 2012-09-06 14:59:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:59:57 --> Language Class Initialized
DEBUG - 2012-09-06 14:59:57 --> Loader Class Initialized
DEBUG - 2012-09-06 14:59:57 --> Helper loaded: url_helper
DEBUG - 2012-09-06 14:59:57 --> Controller Class Initialized
DEBUG - 2012-09-06 14:59:57 --> Model Class Initialized
DEBUG - 2012-09-06 14:59:57 --> Database Driver Class Initialized
DEBUG - 2012-09-06 14:59:57 --> Helper loaded: form_helper
DEBUG - 2012-09-06 14:59:57 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 14:59:57 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 14:59:57 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 14:59:57 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 14:59:57 --> Final output sent to browser
DEBUG - 2012-09-06 14:59:57 --> Total execution time: 0.0391
DEBUG - 2012-09-06 14:59:58 --> Config Class Initialized
DEBUG - 2012-09-06 14:59:58 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:59:58 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:59:58 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:59:58 --> URI Class Initialized
DEBUG - 2012-09-06 14:59:58 --> Router Class Initialized
ERROR - 2012-09-06 14:59:58 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 14:59:58 --> Config Class Initialized
DEBUG - 2012-09-06 14:59:58 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:59:58 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:59:58 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:59:58 --> URI Class Initialized
DEBUG - 2012-09-06 14:59:58 --> Router Class Initialized
ERROR - 2012-09-06 14:59:58 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 14:59:58 --> Config Class Initialized
DEBUG - 2012-09-06 14:59:58 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:59:58 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:59:58 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 14:59:58 --> URI Class Initialized
DEBUG - 2012-09-06 14:59:58 --> Router Class Initialized
ERROR - 2012-09-06 14:59:58 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 15:01:47 --> Config Class Initialized
DEBUG - 2012-09-06 15:01:47 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:01:47 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:01:47 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:01:47 --> URI Class Initialized
DEBUG - 2012-09-06 15:01:47 --> Router Class Initialized
DEBUG - 2012-09-06 15:01:47 --> Output Class Initialized
DEBUG - 2012-09-06 15:01:47 --> Security Class Initialized
DEBUG - 2012-09-06 15:01:47 --> Input Class Initialized
DEBUG - 2012-09-06 15:01:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:01:47 --> Language Class Initialized
DEBUG - 2012-09-06 15:01:47 --> Loader Class Initialized
DEBUG - 2012-09-06 15:01:47 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:01:47 --> Controller Class Initialized
DEBUG - 2012-09-06 15:01:47 --> Model Class Initialized
DEBUG - 2012-09-06 15:01:47 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:01:47 --> Helper loaded: form_helper
DEBUG - 2012-09-06 15:01:47 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 15:01:47 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 15:01:47 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 15:01:47 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 15:01:47 --> Final output sent to browser
DEBUG - 2012-09-06 15:01:47 --> Total execution time: 0.0395
DEBUG - 2012-09-06 15:01:49 --> Config Class Initialized
DEBUG - 2012-09-06 15:01:49 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:01:49 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:01:49 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:01:49 --> URI Class Initialized
DEBUG - 2012-09-06 15:01:49 --> Router Class Initialized
ERROR - 2012-09-06 15:01:49 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 15:01:49 --> Config Class Initialized
DEBUG - 2012-09-06 15:01:49 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:01:49 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:01:49 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:01:49 --> URI Class Initialized
DEBUG - 2012-09-06 15:01:49 --> Router Class Initialized
ERROR - 2012-09-06 15:01:49 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 15:01:49 --> Config Class Initialized
DEBUG - 2012-09-06 15:01:49 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:01:49 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:01:49 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:01:49 --> URI Class Initialized
DEBUG - 2012-09-06 15:01:49 --> Router Class Initialized
ERROR - 2012-09-06 15:01:49 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 15:02:02 --> Config Class Initialized
DEBUG - 2012-09-06 15:02:02 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:02:02 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:02:02 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:02:02 --> URI Class Initialized
DEBUG - 2012-09-06 15:02:02 --> Router Class Initialized
DEBUG - 2012-09-06 15:02:02 --> Output Class Initialized
DEBUG - 2012-09-06 15:02:02 --> Security Class Initialized
DEBUG - 2012-09-06 15:02:02 --> Input Class Initialized
DEBUG - 2012-09-06 15:02:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:02:02 --> Language Class Initialized
DEBUG - 2012-09-06 15:02:02 --> Loader Class Initialized
DEBUG - 2012-09-06 15:02:02 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:02:02 --> Controller Class Initialized
DEBUG - 2012-09-06 15:02:02 --> Model Class Initialized
DEBUG - 2012-09-06 15:02:02 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:02:02 --> Final output sent to browser
DEBUG - 2012-09-06 15:02:02 --> Total execution time: 0.0971
DEBUG - 2012-09-06 15:05:06 --> Config Class Initialized
DEBUG - 2012-09-06 15:05:06 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:05:06 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:05:06 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:05:06 --> URI Class Initialized
DEBUG - 2012-09-06 15:05:06 --> Router Class Initialized
DEBUG - 2012-09-06 15:05:06 --> Output Class Initialized
DEBUG - 2012-09-06 15:05:06 --> Security Class Initialized
DEBUG - 2012-09-06 15:05:06 --> Input Class Initialized
DEBUG - 2012-09-06 15:05:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:05:06 --> Language Class Initialized
DEBUG - 2012-09-06 15:05:06 --> Loader Class Initialized
DEBUG - 2012-09-06 15:05:06 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:05:06 --> Controller Class Initialized
DEBUG - 2012-09-06 15:05:06 --> Model Class Initialized
DEBUG - 2012-09-06 15:05:06 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:05:06 --> Helper loaded: form_helper
DEBUG - 2012-09-06 15:05:06 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 15:05:06 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 15:05:06 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 15:05:06 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 15:05:06 --> Final output sent to browser
DEBUG - 2012-09-06 15:05:06 --> Total execution time: 0.0412
DEBUG - 2012-09-06 15:05:11 --> Config Class Initialized
DEBUG - 2012-09-06 15:05:11 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:05:11 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:05:11 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:05:11 --> URI Class Initialized
DEBUG - 2012-09-06 15:05:11 --> Router Class Initialized
DEBUG - 2012-09-06 15:05:11 --> Output Class Initialized
DEBUG - 2012-09-06 15:05:11 --> Security Class Initialized
DEBUG - 2012-09-06 15:05:11 --> Input Class Initialized
DEBUG - 2012-09-06 15:05:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:05:11 --> Language Class Initialized
DEBUG - 2012-09-06 15:05:11 --> Loader Class Initialized
DEBUG - 2012-09-06 15:05:11 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:05:11 --> Controller Class Initialized
DEBUG - 2012-09-06 15:05:11 --> Model Class Initialized
DEBUG - 2012-09-06 15:05:11 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:05:11 --> Final output sent to browser
DEBUG - 2012-09-06 15:05:11 --> Total execution time: 0.0862
DEBUG - 2012-09-06 15:06:06 --> Config Class Initialized
DEBUG - 2012-09-06 15:06:06 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:06:06 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:06:06 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:06:06 --> URI Class Initialized
DEBUG - 2012-09-06 15:06:06 --> Router Class Initialized
DEBUG - 2012-09-06 15:06:06 --> Output Class Initialized
DEBUG - 2012-09-06 15:06:06 --> Security Class Initialized
DEBUG - 2012-09-06 15:06:06 --> Input Class Initialized
DEBUG - 2012-09-06 15:06:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:06:06 --> Language Class Initialized
DEBUG - 2012-09-06 15:06:06 --> Loader Class Initialized
DEBUG - 2012-09-06 15:06:06 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:06:06 --> Controller Class Initialized
DEBUG - 2012-09-06 15:06:06 --> Model Class Initialized
DEBUG - 2012-09-06 15:06:06 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:06:06 --> Final output sent to browser
DEBUG - 2012-09-06 15:06:06 --> Total execution time: 0.0303
DEBUG - 2012-09-06 15:07:27 --> Config Class Initialized
DEBUG - 2012-09-06 15:07:27 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:07:27 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:07:27 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:07:27 --> URI Class Initialized
DEBUG - 2012-09-06 15:07:27 --> Router Class Initialized
DEBUG - 2012-09-06 15:07:27 --> Output Class Initialized
DEBUG - 2012-09-06 15:07:27 --> Security Class Initialized
DEBUG - 2012-09-06 15:07:27 --> Input Class Initialized
DEBUG - 2012-09-06 15:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:07:27 --> Language Class Initialized
DEBUG - 2012-09-06 15:07:27 --> Loader Class Initialized
DEBUG - 2012-09-06 15:07:27 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:07:27 --> Controller Class Initialized
DEBUG - 2012-09-06 15:07:27 --> Model Class Initialized
DEBUG - 2012-09-06 15:07:27 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:07:27 --> Helper loaded: form_helper
DEBUG - 2012-09-06 15:07:27 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 15:07:27 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 15:07:27 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 15:07:27 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 15:07:27 --> Final output sent to browser
DEBUG - 2012-09-06 15:07:27 --> Total execution time: 0.0470
DEBUG - 2012-09-06 15:07:53 --> Config Class Initialized
DEBUG - 2012-09-06 15:07:53 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:07:53 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:07:53 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:07:53 --> URI Class Initialized
DEBUG - 2012-09-06 15:07:53 --> Router Class Initialized
DEBUG - 2012-09-06 15:07:53 --> Output Class Initialized
DEBUG - 2012-09-06 15:07:53 --> Security Class Initialized
DEBUG - 2012-09-06 15:07:53 --> Input Class Initialized
DEBUG - 2012-09-06 15:07:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:07:53 --> Language Class Initialized
DEBUG - 2012-09-06 15:07:53 --> Loader Class Initialized
DEBUG - 2012-09-06 15:07:53 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:07:53 --> Controller Class Initialized
DEBUG - 2012-09-06 15:07:53 --> Model Class Initialized
DEBUG - 2012-09-06 15:07:53 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:07:53 --> Final output sent to browser
DEBUG - 2012-09-06 15:07:53 --> Total execution time: 0.0341
DEBUG - 2012-09-06 15:13:24 --> Config Class Initialized
DEBUG - 2012-09-06 15:13:24 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:13:24 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:13:24 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:13:24 --> URI Class Initialized
DEBUG - 2012-09-06 15:13:24 --> Router Class Initialized
DEBUG - 2012-09-06 15:13:24 --> Output Class Initialized
DEBUG - 2012-09-06 15:13:24 --> Security Class Initialized
DEBUG - 2012-09-06 15:13:24 --> Input Class Initialized
DEBUG - 2012-09-06 15:13:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:13:24 --> Language Class Initialized
DEBUG - 2012-09-06 15:13:24 --> Loader Class Initialized
DEBUG - 2012-09-06 15:13:24 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:13:24 --> Controller Class Initialized
DEBUG - 2012-09-06 15:13:24 --> Model Class Initialized
DEBUG - 2012-09-06 15:13:24 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:13:24 --> Helper loaded: form_helper
DEBUG - 2012-09-06 15:13:24 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 15:13:24 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 15:13:24 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 15:13:24 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 15:13:24 --> Final output sent to browser
DEBUG - 2012-09-06 15:13:24 --> Total execution time: 0.0385
DEBUG - 2012-09-06 15:13:28 --> Config Class Initialized
DEBUG - 2012-09-06 15:13:28 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:13:28 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:13:28 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:13:28 --> URI Class Initialized
DEBUG - 2012-09-06 15:13:28 --> Router Class Initialized
DEBUG - 2012-09-06 15:13:28 --> Output Class Initialized
DEBUG - 2012-09-06 15:13:28 --> Security Class Initialized
DEBUG - 2012-09-06 15:13:28 --> Input Class Initialized
DEBUG - 2012-09-06 15:13:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:13:28 --> Language Class Initialized
DEBUG - 2012-09-06 15:13:28 --> Loader Class Initialized
DEBUG - 2012-09-06 15:13:28 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:13:28 --> Controller Class Initialized
DEBUG - 2012-09-06 15:13:28 --> Model Class Initialized
DEBUG - 2012-09-06 15:13:28 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:13:28 --> Final output sent to browser
DEBUG - 2012-09-06 15:13:28 --> Total execution time: 0.0297
DEBUG - 2012-09-06 15:13:42 --> Config Class Initialized
DEBUG - 2012-09-06 15:13:42 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:13:42 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:13:42 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:13:42 --> URI Class Initialized
DEBUG - 2012-09-06 15:13:42 --> Router Class Initialized
DEBUG - 2012-09-06 15:13:42 --> Output Class Initialized
DEBUG - 2012-09-06 15:13:42 --> Security Class Initialized
DEBUG - 2012-09-06 15:13:42 --> Input Class Initialized
DEBUG - 2012-09-06 15:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:13:42 --> Language Class Initialized
DEBUG - 2012-09-06 15:13:42 --> Loader Class Initialized
DEBUG - 2012-09-06 15:13:42 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:13:42 --> Controller Class Initialized
DEBUG - 2012-09-06 15:13:42 --> Model Class Initialized
DEBUG - 2012-09-06 15:13:42 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:13:42 --> Final output sent to browser
DEBUG - 2012-09-06 15:13:42 --> Total execution time: 0.0388
DEBUG - 2012-09-06 15:15:12 --> Config Class Initialized
DEBUG - 2012-09-06 15:15:12 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:15:12 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:15:12 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:15:12 --> URI Class Initialized
DEBUG - 2012-09-06 15:15:12 --> Router Class Initialized
DEBUG - 2012-09-06 15:15:12 --> Output Class Initialized
DEBUG - 2012-09-06 15:15:12 --> Security Class Initialized
DEBUG - 2012-09-06 15:15:12 --> Input Class Initialized
DEBUG - 2012-09-06 15:15:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:15:12 --> Language Class Initialized
DEBUG - 2012-09-06 15:15:12 --> Loader Class Initialized
DEBUG - 2012-09-06 15:15:12 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:15:12 --> Controller Class Initialized
DEBUG - 2012-09-06 15:15:12 --> Model Class Initialized
DEBUG - 2012-09-06 15:15:12 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:15:12 --> Helper loaded: form_helper
DEBUG - 2012-09-06 15:15:12 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 15:15:12 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 15:15:12 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 15:15:12 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 15:15:12 --> Final output sent to browser
DEBUG - 2012-09-06 15:15:12 --> Total execution time: 0.0395
DEBUG - 2012-09-06 15:15:16 --> Config Class Initialized
DEBUG - 2012-09-06 15:15:16 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:15:16 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:15:16 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:15:16 --> URI Class Initialized
DEBUG - 2012-09-06 15:15:16 --> Router Class Initialized
DEBUG - 2012-09-06 15:15:16 --> Output Class Initialized
DEBUG - 2012-09-06 15:15:16 --> Security Class Initialized
DEBUG - 2012-09-06 15:15:16 --> Input Class Initialized
DEBUG - 2012-09-06 15:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:15:16 --> Language Class Initialized
DEBUG - 2012-09-06 15:15:16 --> Loader Class Initialized
DEBUG - 2012-09-06 15:15:16 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:15:16 --> Controller Class Initialized
DEBUG - 2012-09-06 15:15:16 --> Model Class Initialized
DEBUG - 2012-09-06 15:15:16 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:15:16 --> Final output sent to browser
DEBUG - 2012-09-06 15:15:16 --> Total execution time: 0.0300
DEBUG - 2012-09-06 15:15:37 --> Config Class Initialized
DEBUG - 2012-09-06 15:15:37 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:15:37 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:15:37 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:15:37 --> URI Class Initialized
DEBUG - 2012-09-06 15:15:37 --> Router Class Initialized
DEBUG - 2012-09-06 15:15:37 --> Output Class Initialized
DEBUG - 2012-09-06 15:15:37 --> Security Class Initialized
DEBUG - 2012-09-06 15:15:37 --> Input Class Initialized
DEBUG - 2012-09-06 15:15:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:15:37 --> Language Class Initialized
DEBUG - 2012-09-06 15:15:37 --> Loader Class Initialized
DEBUG - 2012-09-06 15:15:37 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:15:37 --> Controller Class Initialized
DEBUG - 2012-09-06 15:15:37 --> Model Class Initialized
DEBUG - 2012-09-06 15:15:37 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:15:37 --> Helper loaded: form_helper
DEBUG - 2012-09-06 15:15:37 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 15:15:37 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 15:15:37 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 15:15:37 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 15:15:37 --> Final output sent to browser
DEBUG - 2012-09-06 15:15:37 --> Total execution time: 0.0409
DEBUG - 2012-09-06 15:15:39 --> Config Class Initialized
DEBUG - 2012-09-06 15:15:39 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:15:39 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:15:39 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:15:39 --> URI Class Initialized
DEBUG - 2012-09-06 15:15:39 --> Router Class Initialized
ERROR - 2012-09-06 15:15:39 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 15:15:39 --> Config Class Initialized
DEBUG - 2012-09-06 15:15:39 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:15:39 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:15:39 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:15:39 --> URI Class Initialized
DEBUG - 2012-09-06 15:15:39 --> Router Class Initialized
ERROR - 2012-09-06 15:15:39 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 15:15:39 --> Config Class Initialized
DEBUG - 2012-09-06 15:15:39 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:15:39 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:15:39 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:15:39 --> URI Class Initialized
DEBUG - 2012-09-06 15:15:39 --> Router Class Initialized
ERROR - 2012-09-06 15:15:39 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 15:15:40 --> Config Class Initialized
DEBUG - 2012-09-06 15:15:40 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:15:40 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:15:40 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:15:40 --> URI Class Initialized
DEBUG - 2012-09-06 15:15:40 --> Router Class Initialized
DEBUG - 2012-09-06 15:15:40 --> Output Class Initialized
DEBUG - 2012-09-06 15:15:40 --> Security Class Initialized
DEBUG - 2012-09-06 15:15:40 --> Input Class Initialized
DEBUG - 2012-09-06 15:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:15:40 --> Language Class Initialized
DEBUG - 2012-09-06 15:15:40 --> Loader Class Initialized
DEBUG - 2012-09-06 15:15:40 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:15:40 --> Controller Class Initialized
DEBUG - 2012-09-06 15:15:40 --> Model Class Initialized
DEBUG - 2012-09-06 15:15:40 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:15:40 --> Final output sent to browser
DEBUG - 2012-09-06 15:15:40 --> Total execution time: 0.0323
DEBUG - 2012-09-06 15:22:32 --> Config Class Initialized
DEBUG - 2012-09-06 15:22:32 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:22:32 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:22:32 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:22:32 --> URI Class Initialized
DEBUG - 2012-09-06 15:22:32 --> Router Class Initialized
DEBUG - 2012-09-06 15:22:32 --> Output Class Initialized
DEBUG - 2012-09-06 15:22:32 --> Security Class Initialized
DEBUG - 2012-09-06 15:22:32 --> Input Class Initialized
DEBUG - 2012-09-06 15:22:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:22:32 --> Language Class Initialized
DEBUG - 2012-09-06 15:22:32 --> Loader Class Initialized
DEBUG - 2012-09-06 15:22:32 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:22:32 --> Controller Class Initialized
DEBUG - 2012-09-06 15:22:32 --> Model Class Initialized
DEBUG - 2012-09-06 15:22:32 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:22:32 --> Helper loaded: form_helper
DEBUG - 2012-09-06 15:22:32 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 15:22:32 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 15:22:32 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 15:22:32 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 15:22:32 --> Final output sent to browser
DEBUG - 2012-09-06 15:22:32 --> Total execution time: 0.0429
DEBUG - 2012-09-06 15:22:35 --> Config Class Initialized
DEBUG - 2012-09-06 15:22:35 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:22:35 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:22:35 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:22:35 --> URI Class Initialized
DEBUG - 2012-09-06 15:22:35 --> Router Class Initialized
DEBUG - 2012-09-06 15:22:35 --> Output Class Initialized
DEBUG - 2012-09-06 15:22:35 --> Security Class Initialized
DEBUG - 2012-09-06 15:22:35 --> Input Class Initialized
DEBUG - 2012-09-06 15:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:22:35 --> Language Class Initialized
DEBUG - 2012-09-06 15:22:35 --> Loader Class Initialized
DEBUG - 2012-09-06 15:22:35 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:22:35 --> Controller Class Initialized
DEBUG - 2012-09-06 15:22:35 --> Model Class Initialized
DEBUG - 2012-09-06 15:22:35 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:22:35 --> Final output sent to browser
DEBUG - 2012-09-06 15:22:35 --> Total execution time: 0.0297
DEBUG - 2012-09-06 15:23:14 --> Config Class Initialized
DEBUG - 2012-09-06 15:23:14 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:23:14 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:23:14 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:23:14 --> URI Class Initialized
DEBUG - 2012-09-06 15:23:14 --> Router Class Initialized
DEBUG - 2012-09-06 15:23:14 --> Output Class Initialized
DEBUG - 2012-09-06 15:23:14 --> Security Class Initialized
DEBUG - 2012-09-06 15:23:14 --> Input Class Initialized
DEBUG - 2012-09-06 15:23:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:23:14 --> Language Class Initialized
DEBUG - 2012-09-06 15:23:14 --> Loader Class Initialized
DEBUG - 2012-09-06 15:23:14 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:23:14 --> Controller Class Initialized
DEBUG - 2012-09-06 15:23:14 --> Model Class Initialized
DEBUG - 2012-09-06 15:23:14 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:23:14 --> Helper loaded: form_helper
DEBUG - 2012-09-06 15:23:14 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 15:23:14 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 15:23:14 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 15:23:14 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 15:23:14 --> Final output sent to browser
DEBUG - 2012-09-06 15:23:14 --> Total execution time: 0.0398
DEBUG - 2012-09-06 15:23:16 --> Config Class Initialized
DEBUG - 2012-09-06 15:23:16 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:23:16 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:23:16 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:23:16 --> URI Class Initialized
DEBUG - 2012-09-06 15:23:16 --> Router Class Initialized
DEBUG - 2012-09-06 15:23:16 --> Output Class Initialized
DEBUG - 2012-09-06 15:23:16 --> Security Class Initialized
DEBUG - 2012-09-06 15:23:16 --> Input Class Initialized
DEBUG - 2012-09-06 15:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:23:16 --> Language Class Initialized
DEBUG - 2012-09-06 15:23:16 --> Loader Class Initialized
DEBUG - 2012-09-06 15:23:16 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:23:16 --> Controller Class Initialized
DEBUG - 2012-09-06 15:23:16 --> Model Class Initialized
DEBUG - 2012-09-06 15:23:16 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:23:16 --> Final output sent to browser
DEBUG - 2012-09-06 15:23:16 --> Total execution time: 0.0298
DEBUG - 2012-09-06 15:23:26 --> Config Class Initialized
DEBUG - 2012-09-06 15:23:26 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:23:26 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:23:26 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:23:26 --> URI Class Initialized
DEBUG - 2012-09-06 15:23:26 --> Router Class Initialized
DEBUG - 2012-09-06 15:23:26 --> Output Class Initialized
DEBUG - 2012-09-06 15:23:26 --> Security Class Initialized
DEBUG - 2012-09-06 15:23:26 --> Input Class Initialized
DEBUG - 2012-09-06 15:23:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:23:26 --> Language Class Initialized
DEBUG - 2012-09-06 15:23:26 --> Loader Class Initialized
DEBUG - 2012-09-06 15:23:26 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:23:26 --> Controller Class Initialized
DEBUG - 2012-09-06 15:23:26 --> Model Class Initialized
DEBUG - 2012-09-06 15:23:26 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:23:26 --> Helper loaded: form_helper
DEBUG - 2012-09-06 15:23:26 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 15:23:26 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 15:23:26 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 15:23:26 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 15:23:26 --> Final output sent to browser
DEBUG - 2012-09-06 15:23:26 --> Total execution time: 0.0388
DEBUG - 2012-09-06 15:23:28 --> Config Class Initialized
DEBUG - 2012-09-06 15:23:28 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:23:28 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:23:28 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:23:28 --> URI Class Initialized
DEBUG - 2012-09-06 15:23:28 --> Router Class Initialized
ERROR - 2012-09-06 15:23:28 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 15:23:28 --> Config Class Initialized
DEBUG - 2012-09-06 15:23:28 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:23:28 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:23:28 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:23:28 --> URI Class Initialized
DEBUG - 2012-09-06 15:23:28 --> Router Class Initialized
ERROR - 2012-09-06 15:23:28 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 15:23:28 --> Config Class Initialized
DEBUG - 2012-09-06 15:23:28 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:23:28 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:23:28 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:23:28 --> URI Class Initialized
DEBUG - 2012-09-06 15:23:28 --> Router Class Initialized
ERROR - 2012-09-06 15:23:28 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 15:23:30 --> Config Class Initialized
DEBUG - 2012-09-06 15:23:30 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:23:30 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:23:30 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:23:30 --> URI Class Initialized
DEBUG - 2012-09-06 15:23:30 --> Router Class Initialized
DEBUG - 2012-09-06 15:23:30 --> Output Class Initialized
DEBUG - 2012-09-06 15:23:30 --> Security Class Initialized
DEBUG - 2012-09-06 15:23:30 --> Input Class Initialized
DEBUG - 2012-09-06 15:23:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:23:30 --> Language Class Initialized
DEBUG - 2012-09-06 15:23:30 --> Loader Class Initialized
DEBUG - 2012-09-06 15:23:30 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:23:30 --> Controller Class Initialized
DEBUG - 2012-09-06 15:23:30 --> Model Class Initialized
DEBUG - 2012-09-06 15:23:30 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:23:30 --> Final output sent to browser
DEBUG - 2012-09-06 15:23:30 --> Total execution time: 0.0364
DEBUG - 2012-09-06 15:24:38 --> Config Class Initialized
DEBUG - 2012-09-06 15:24:38 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:24:38 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:24:38 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:24:38 --> URI Class Initialized
DEBUG - 2012-09-06 15:24:38 --> Router Class Initialized
DEBUG - 2012-09-06 15:24:38 --> Output Class Initialized
DEBUG - 2012-09-06 15:24:38 --> Security Class Initialized
DEBUG - 2012-09-06 15:24:38 --> Input Class Initialized
DEBUG - 2012-09-06 15:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:24:38 --> Language Class Initialized
DEBUG - 2012-09-06 15:24:38 --> Loader Class Initialized
DEBUG - 2012-09-06 15:24:38 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:24:38 --> Controller Class Initialized
DEBUG - 2012-09-06 15:24:38 --> Model Class Initialized
DEBUG - 2012-09-06 15:24:38 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:24:38 --> Helper loaded: form_helper
DEBUG - 2012-09-06 15:24:38 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 15:24:38 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 15:24:38 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 15:24:38 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 15:24:38 --> Final output sent to browser
DEBUG - 2012-09-06 15:24:38 --> Total execution time: 0.0437
DEBUG - 2012-09-06 15:24:39 --> Config Class Initialized
DEBUG - 2012-09-06 15:24:39 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:24:39 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:24:39 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:24:39 --> URI Class Initialized
DEBUG - 2012-09-06 15:24:39 --> Router Class Initialized
ERROR - 2012-09-06 15:24:39 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 15:24:39 --> Config Class Initialized
DEBUG - 2012-09-06 15:24:39 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:24:39 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:24:39 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:24:39 --> URI Class Initialized
DEBUG - 2012-09-06 15:24:39 --> Router Class Initialized
ERROR - 2012-09-06 15:24:39 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 15:24:39 --> Config Class Initialized
DEBUG - 2012-09-06 15:24:39 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:24:39 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:24:39 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:24:39 --> URI Class Initialized
DEBUG - 2012-09-06 15:24:39 --> Router Class Initialized
ERROR - 2012-09-06 15:24:39 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 15:24:41 --> Config Class Initialized
DEBUG - 2012-09-06 15:24:41 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:24:41 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:24:41 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:24:41 --> URI Class Initialized
DEBUG - 2012-09-06 15:24:41 --> Router Class Initialized
DEBUG - 2012-09-06 15:24:41 --> Output Class Initialized
DEBUG - 2012-09-06 15:24:41 --> Security Class Initialized
DEBUG - 2012-09-06 15:24:41 --> Input Class Initialized
DEBUG - 2012-09-06 15:24:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:24:41 --> Language Class Initialized
DEBUG - 2012-09-06 15:24:41 --> Loader Class Initialized
DEBUG - 2012-09-06 15:24:41 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:24:41 --> Controller Class Initialized
DEBUG - 2012-09-06 15:24:41 --> Model Class Initialized
DEBUG - 2012-09-06 15:24:41 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:24:41 --> Final output sent to browser
DEBUG - 2012-09-06 15:24:41 --> Total execution time: 0.1177
DEBUG - 2012-09-06 15:25:13 --> Config Class Initialized
DEBUG - 2012-09-06 15:25:13 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:25:13 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:25:13 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:25:13 --> URI Class Initialized
DEBUG - 2012-09-06 15:25:13 --> Router Class Initialized
DEBUG - 2012-09-06 15:25:13 --> Output Class Initialized
DEBUG - 2012-09-06 15:25:13 --> Security Class Initialized
DEBUG - 2012-09-06 15:25:13 --> Input Class Initialized
DEBUG - 2012-09-06 15:25:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:25:13 --> Language Class Initialized
DEBUG - 2012-09-06 15:25:13 --> Loader Class Initialized
DEBUG - 2012-09-06 15:25:13 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:25:13 --> Controller Class Initialized
DEBUG - 2012-09-06 15:25:13 --> Model Class Initialized
DEBUG - 2012-09-06 15:25:13 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:25:13 --> Helper loaded: form_helper
DEBUG - 2012-09-06 15:25:13 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 15:25:13 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 15:25:13 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 15:25:13 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 15:25:13 --> Final output sent to browser
DEBUG - 2012-09-06 15:25:13 --> Total execution time: 0.0490
DEBUG - 2012-09-06 15:25:26 --> Config Class Initialized
DEBUG - 2012-09-06 15:25:26 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:25:26 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:25:26 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:25:26 --> URI Class Initialized
DEBUG - 2012-09-06 15:25:26 --> Router Class Initialized
DEBUG - 2012-09-06 15:25:26 --> Output Class Initialized
DEBUG - 2012-09-06 15:25:26 --> Security Class Initialized
DEBUG - 2012-09-06 15:25:26 --> Input Class Initialized
DEBUG - 2012-09-06 15:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:25:26 --> Language Class Initialized
DEBUG - 2012-09-06 15:25:26 --> Loader Class Initialized
DEBUG - 2012-09-06 15:25:26 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:25:26 --> Controller Class Initialized
DEBUG - 2012-09-06 15:25:26 --> Model Class Initialized
DEBUG - 2012-09-06 15:25:26 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:25:26 --> Final output sent to browser
DEBUG - 2012-09-06 15:25:26 --> Total execution time: 0.0715
DEBUG - 2012-09-06 15:25:31 --> Config Class Initialized
DEBUG - 2012-09-06 15:25:31 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:25:31 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:25:31 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:25:31 --> URI Class Initialized
DEBUG - 2012-09-06 15:25:31 --> Router Class Initialized
DEBUG - 2012-09-06 15:25:31 --> Output Class Initialized
DEBUG - 2012-09-06 15:25:31 --> Security Class Initialized
DEBUG - 2012-09-06 15:25:31 --> Input Class Initialized
DEBUG - 2012-09-06 15:25:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:25:31 --> Language Class Initialized
DEBUG - 2012-09-06 15:25:31 --> Loader Class Initialized
DEBUG - 2012-09-06 15:25:31 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:25:31 --> Controller Class Initialized
DEBUG - 2012-09-06 15:25:31 --> Model Class Initialized
DEBUG - 2012-09-06 15:25:31 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:25:31 --> Helper loaded: form_helper
DEBUG - 2012-09-06 15:25:31 --> Form Validation Class Initialized
DEBUG - 2012-09-06 15:25:31 --> Final output sent to browser
DEBUG - 2012-09-06 15:25:31 --> Total execution time: 0.1601
DEBUG - 2012-09-06 15:26:09 --> Config Class Initialized
DEBUG - 2012-09-06 15:26:09 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:26:09 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:26:09 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:26:09 --> URI Class Initialized
DEBUG - 2012-09-06 15:26:09 --> Router Class Initialized
DEBUG - 2012-09-06 15:26:09 --> Output Class Initialized
DEBUG - 2012-09-06 15:26:09 --> Security Class Initialized
DEBUG - 2012-09-06 15:26:09 --> Input Class Initialized
DEBUG - 2012-09-06 15:26:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:26:09 --> Language Class Initialized
DEBUG - 2012-09-06 15:26:09 --> Loader Class Initialized
DEBUG - 2012-09-06 15:26:09 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:26:09 --> Controller Class Initialized
DEBUG - 2012-09-06 15:26:09 --> Model Class Initialized
DEBUG - 2012-09-06 15:26:09 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:26:09 --> Final output sent to browser
DEBUG - 2012-09-06 15:26:09 --> Total execution time: 0.1299
DEBUG - 2012-09-06 15:39:20 --> Config Class Initialized
DEBUG - 2012-09-06 15:39:20 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:39:20 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:39:20 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:39:20 --> URI Class Initialized
DEBUG - 2012-09-06 15:39:20 --> Router Class Initialized
DEBUG - 2012-09-06 15:39:20 --> Output Class Initialized
DEBUG - 2012-09-06 15:39:20 --> Security Class Initialized
DEBUG - 2012-09-06 15:39:20 --> Input Class Initialized
DEBUG - 2012-09-06 15:39:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:39:20 --> Language Class Initialized
DEBUG - 2012-09-06 15:39:20 --> Loader Class Initialized
DEBUG - 2012-09-06 15:39:20 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:39:20 --> Controller Class Initialized
DEBUG - 2012-09-06 15:39:20 --> Model Class Initialized
DEBUG - 2012-09-06 15:39:20 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:39:20 --> Final output sent to browser
DEBUG - 2012-09-06 15:39:20 --> Total execution time: 0.0884
DEBUG - 2012-09-06 15:39:31 --> Config Class Initialized
DEBUG - 2012-09-06 15:39:31 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:39:31 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:39:31 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:39:31 --> URI Class Initialized
DEBUG - 2012-09-06 15:39:31 --> Router Class Initialized
DEBUG - 2012-09-06 15:39:31 --> Output Class Initialized
DEBUG - 2012-09-06 15:39:31 --> Security Class Initialized
DEBUG - 2012-09-06 15:39:31 --> Input Class Initialized
DEBUG - 2012-09-06 15:39:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:39:31 --> Language Class Initialized
DEBUG - 2012-09-06 15:39:31 --> Loader Class Initialized
DEBUG - 2012-09-06 15:39:31 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:39:31 --> Controller Class Initialized
DEBUG - 2012-09-06 15:39:31 --> Model Class Initialized
DEBUG - 2012-09-06 15:39:31 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:39:31 --> Helper loaded: form_helper
DEBUG - 2012-09-06 15:39:31 --> Form Validation Class Initialized
DEBUG - 2012-09-06 15:39:31 --> Final output sent to browser
DEBUG - 2012-09-06 15:39:31 --> Total execution time: 0.0458
DEBUG - 2012-09-06 15:39:38 --> Config Class Initialized
DEBUG - 2012-09-06 15:39:38 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:39:38 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:39:38 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:39:38 --> URI Class Initialized
DEBUG - 2012-09-06 15:39:38 --> Router Class Initialized
DEBUG - 2012-09-06 15:39:38 --> Output Class Initialized
DEBUG - 2012-09-06 15:39:38 --> Security Class Initialized
DEBUG - 2012-09-06 15:39:38 --> Input Class Initialized
DEBUG - 2012-09-06 15:39:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:39:38 --> Language Class Initialized
DEBUG - 2012-09-06 15:39:38 --> Loader Class Initialized
DEBUG - 2012-09-06 15:39:38 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:39:38 --> Controller Class Initialized
DEBUG - 2012-09-06 15:39:38 --> Model Class Initialized
DEBUG - 2012-09-06 15:39:38 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:39:38 --> Final output sent to browser
DEBUG - 2012-09-06 15:39:38 --> Total execution time: 0.2466
DEBUG - 2012-09-06 15:40:14 --> Config Class Initialized
DEBUG - 2012-09-06 15:40:14 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:40:14 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:40:14 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:40:14 --> URI Class Initialized
DEBUG - 2012-09-06 15:40:14 --> Router Class Initialized
DEBUG - 2012-09-06 15:40:14 --> Output Class Initialized
DEBUG - 2012-09-06 15:40:14 --> Security Class Initialized
DEBUG - 2012-09-06 15:40:14 --> Input Class Initialized
DEBUG - 2012-09-06 15:40:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:40:14 --> Language Class Initialized
DEBUG - 2012-09-06 15:40:14 --> Loader Class Initialized
DEBUG - 2012-09-06 15:40:14 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:40:14 --> Controller Class Initialized
DEBUG - 2012-09-06 15:40:14 --> Model Class Initialized
DEBUG - 2012-09-06 15:40:14 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:40:14 --> Final output sent to browser
DEBUG - 2012-09-06 15:40:14 --> Total execution time: 0.0303
DEBUG - 2012-09-06 15:52:29 --> Config Class Initialized
DEBUG - 2012-09-06 15:52:29 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:52:29 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:52:29 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:52:29 --> URI Class Initialized
DEBUG - 2012-09-06 15:52:29 --> Router Class Initialized
DEBUG - 2012-09-06 15:52:29 --> Output Class Initialized
DEBUG - 2012-09-06 15:52:29 --> Security Class Initialized
DEBUG - 2012-09-06 15:52:29 --> Input Class Initialized
DEBUG - 2012-09-06 15:52:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:52:29 --> Language Class Initialized
DEBUG - 2012-09-06 15:52:29 --> Loader Class Initialized
DEBUG - 2012-09-06 15:52:29 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:52:29 --> Controller Class Initialized
DEBUG - 2012-09-06 15:52:29 --> Model Class Initialized
DEBUG - 2012-09-06 15:52:29 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:52:29 --> Helper loaded: form_helper
DEBUG - 2012-09-06 15:52:29 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 15:52:29 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 15:52:29 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 15:52:29 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 15:52:29 --> Final output sent to browser
DEBUG - 2012-09-06 15:52:29 --> Total execution time: 0.0391
DEBUG - 2012-09-06 15:52:35 --> Config Class Initialized
DEBUG - 2012-09-06 15:52:35 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:52:35 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:52:35 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:52:35 --> URI Class Initialized
DEBUG - 2012-09-06 15:52:35 --> Router Class Initialized
DEBUG - 2012-09-06 15:52:35 --> Output Class Initialized
DEBUG - 2012-09-06 15:52:35 --> Security Class Initialized
DEBUG - 2012-09-06 15:52:35 --> Input Class Initialized
DEBUG - 2012-09-06 15:52:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:52:35 --> Language Class Initialized
DEBUG - 2012-09-06 15:52:35 --> Loader Class Initialized
DEBUG - 2012-09-06 15:52:35 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:52:35 --> Controller Class Initialized
DEBUG - 2012-09-06 15:52:35 --> Model Class Initialized
DEBUG - 2012-09-06 15:52:35 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:52:35 --> Final output sent to browser
DEBUG - 2012-09-06 15:52:35 --> Total execution time: 0.0297
DEBUG - 2012-09-06 15:52:51 --> Config Class Initialized
DEBUG - 2012-09-06 15:52:51 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:52:51 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:52:51 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:52:51 --> URI Class Initialized
DEBUG - 2012-09-06 15:52:51 --> Router Class Initialized
DEBUG - 2012-09-06 15:52:51 --> Output Class Initialized
DEBUG - 2012-09-06 15:52:51 --> Security Class Initialized
DEBUG - 2012-09-06 15:52:51 --> Input Class Initialized
DEBUG - 2012-09-06 15:52:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:52:51 --> Language Class Initialized
DEBUG - 2012-09-06 15:52:51 --> Loader Class Initialized
DEBUG - 2012-09-06 15:52:51 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:52:51 --> Controller Class Initialized
DEBUG - 2012-09-06 15:52:51 --> Model Class Initialized
DEBUG - 2012-09-06 15:52:51 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:52:51 --> Final output sent to browser
DEBUG - 2012-09-06 15:52:51 --> Total execution time: 0.0841
DEBUG - 2012-09-06 15:53:19 --> Config Class Initialized
DEBUG - 2012-09-06 15:53:19 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:53:19 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:53:19 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:53:19 --> URI Class Initialized
DEBUG - 2012-09-06 15:53:19 --> Router Class Initialized
DEBUG - 2012-09-06 15:53:19 --> Output Class Initialized
DEBUG - 2012-09-06 15:53:19 --> Security Class Initialized
DEBUG - 2012-09-06 15:53:19 --> Input Class Initialized
DEBUG - 2012-09-06 15:53:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:53:19 --> Language Class Initialized
DEBUG - 2012-09-06 15:53:19 --> Loader Class Initialized
DEBUG - 2012-09-06 15:53:19 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:53:19 --> Controller Class Initialized
DEBUG - 2012-09-06 15:53:19 --> Model Class Initialized
DEBUG - 2012-09-06 15:53:19 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:53:19 --> Helper loaded: form_helper
DEBUG - 2012-09-06 15:53:19 --> Form Validation Class Initialized
DEBUG - 2012-09-06 15:53:19 --> Final output sent to browser
DEBUG - 2012-09-06 15:53:19 --> Total execution time: 0.1044
DEBUG - 2012-09-06 15:53:25 --> Config Class Initialized
DEBUG - 2012-09-06 15:53:25 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:53:25 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:53:25 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:53:25 --> URI Class Initialized
DEBUG - 2012-09-06 15:53:25 --> Router Class Initialized
DEBUG - 2012-09-06 15:53:25 --> Output Class Initialized
DEBUG - 2012-09-06 15:53:25 --> Security Class Initialized
DEBUG - 2012-09-06 15:53:25 --> Input Class Initialized
DEBUG - 2012-09-06 15:53:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:53:25 --> Language Class Initialized
DEBUG - 2012-09-06 15:53:25 --> Loader Class Initialized
DEBUG - 2012-09-06 15:53:25 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:53:25 --> Controller Class Initialized
DEBUG - 2012-09-06 15:53:25 --> Model Class Initialized
DEBUG - 2012-09-06 15:53:25 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:53:25 --> Final output sent to browser
DEBUG - 2012-09-06 15:53:25 --> Total execution time: 0.0296
DEBUG - 2012-09-06 15:53:28 --> Config Class Initialized
DEBUG - 2012-09-06 15:53:28 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:53:28 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:53:28 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:53:28 --> URI Class Initialized
DEBUG - 2012-09-06 15:53:28 --> Router Class Initialized
DEBUG - 2012-09-06 15:53:28 --> Output Class Initialized
DEBUG - 2012-09-06 15:53:28 --> Security Class Initialized
DEBUG - 2012-09-06 15:53:28 --> Input Class Initialized
DEBUG - 2012-09-06 15:53:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:53:28 --> Language Class Initialized
DEBUG - 2012-09-06 15:53:28 --> Loader Class Initialized
DEBUG - 2012-09-06 15:53:28 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:53:28 --> Controller Class Initialized
DEBUG - 2012-09-06 15:53:28 --> Model Class Initialized
DEBUG - 2012-09-06 15:53:28 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:53:28 --> Final output sent to browser
DEBUG - 2012-09-06 15:53:28 --> Total execution time: 0.1609
DEBUG - 2012-09-06 15:54:06 --> Config Class Initialized
DEBUG - 2012-09-06 15:54:06 --> Hooks Class Initialized
DEBUG - 2012-09-06 15:54:06 --> Utf8 Class Initialized
DEBUG - 2012-09-06 15:54:06 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 15:54:06 --> URI Class Initialized
DEBUG - 2012-09-06 15:54:06 --> Router Class Initialized
DEBUG - 2012-09-06 15:54:06 --> Output Class Initialized
DEBUG - 2012-09-06 15:54:06 --> Security Class Initialized
DEBUG - 2012-09-06 15:54:06 --> Input Class Initialized
DEBUG - 2012-09-06 15:54:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 15:54:06 --> Language Class Initialized
DEBUG - 2012-09-06 15:54:06 --> Loader Class Initialized
DEBUG - 2012-09-06 15:54:06 --> Helper loaded: url_helper
DEBUG - 2012-09-06 15:54:06 --> Controller Class Initialized
DEBUG - 2012-09-06 15:54:06 --> Model Class Initialized
DEBUG - 2012-09-06 15:54:06 --> Database Driver Class Initialized
DEBUG - 2012-09-06 15:54:06 --> Final output sent to browser
DEBUG - 2012-09-06 15:54:06 --> Total execution time: 0.1358
DEBUG - 2012-09-06 16:06:37 --> Config Class Initialized
DEBUG - 2012-09-06 16:06:37 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:06:37 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:06:37 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:06:37 --> URI Class Initialized
DEBUG - 2012-09-06 16:06:37 --> Router Class Initialized
DEBUG - 2012-09-06 16:06:37 --> Output Class Initialized
DEBUG - 2012-09-06 16:06:37 --> Security Class Initialized
DEBUG - 2012-09-06 16:06:37 --> Input Class Initialized
DEBUG - 2012-09-06 16:06:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:06:37 --> Language Class Initialized
DEBUG - 2012-09-06 16:06:37 --> Loader Class Initialized
DEBUG - 2012-09-06 16:06:37 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:06:37 --> Controller Class Initialized
DEBUG - 2012-09-06 16:06:37 --> Model Class Initialized
DEBUG - 2012-09-06 16:06:38 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:06:38 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:06:38 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 16:06:38 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 16:06:38 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 16:06:38 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 16:06:38 --> Final output sent to browser
DEBUG - 2012-09-06 16:06:38 --> Total execution time: 0.7605
DEBUG - 2012-09-06 16:06:57 --> Config Class Initialized
DEBUG - 2012-09-06 16:06:57 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:06:57 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:06:57 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:06:57 --> URI Class Initialized
DEBUG - 2012-09-06 16:06:57 --> Router Class Initialized
DEBUG - 2012-09-06 16:06:57 --> Output Class Initialized
DEBUG - 2012-09-06 16:06:57 --> Security Class Initialized
DEBUG - 2012-09-06 16:06:57 --> Input Class Initialized
DEBUG - 2012-09-06 16:06:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:06:57 --> Language Class Initialized
DEBUG - 2012-09-06 16:06:57 --> Loader Class Initialized
DEBUG - 2012-09-06 16:06:57 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:06:57 --> Controller Class Initialized
DEBUG - 2012-09-06 16:06:57 --> Model Class Initialized
DEBUG - 2012-09-06 16:06:57 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:06:57 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:06:57 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 16:06:57 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 16:06:57 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 16:06:57 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 16:06:57 --> Final output sent to browser
DEBUG - 2012-09-06 16:06:57 --> Total execution time: 0.1263
DEBUG - 2012-09-06 16:11:13 --> Config Class Initialized
DEBUG - 2012-09-06 16:11:13 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:11:13 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:11:13 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:11:13 --> URI Class Initialized
DEBUG - 2012-09-06 16:11:13 --> Router Class Initialized
DEBUG - 2012-09-06 16:11:13 --> Output Class Initialized
DEBUG - 2012-09-06 16:11:13 --> Security Class Initialized
DEBUG - 2012-09-06 16:11:13 --> Input Class Initialized
DEBUG - 2012-09-06 16:11:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:11:13 --> Language Class Initialized
DEBUG - 2012-09-06 16:11:13 --> Loader Class Initialized
DEBUG - 2012-09-06 16:11:13 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:11:13 --> Controller Class Initialized
DEBUG - 2012-09-06 16:11:13 --> Model Class Initialized
DEBUG - 2012-09-06 16:11:13 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:11:13 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:11:13 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 16:11:13 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 16:11:13 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 16:11:13 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 16:11:13 --> Final output sent to browser
DEBUG - 2012-09-06 16:11:13 --> Total execution time: 0.3411
DEBUG - 2012-09-06 16:11:17 --> Config Class Initialized
DEBUG - 2012-09-06 16:11:17 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:11:17 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:11:17 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:11:17 --> URI Class Initialized
DEBUG - 2012-09-06 16:11:17 --> Router Class Initialized
DEBUG - 2012-09-06 16:11:17 --> Output Class Initialized
DEBUG - 2012-09-06 16:11:17 --> Security Class Initialized
DEBUG - 2012-09-06 16:11:17 --> Input Class Initialized
DEBUG - 2012-09-06 16:11:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:11:17 --> Language Class Initialized
DEBUG - 2012-09-06 16:11:17 --> Loader Class Initialized
DEBUG - 2012-09-06 16:11:17 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:11:17 --> Controller Class Initialized
DEBUG - 2012-09-06 16:11:17 --> Model Class Initialized
DEBUG - 2012-09-06 16:11:17 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:11:17 --> Final output sent to browser
DEBUG - 2012-09-06 16:11:17 --> Total execution time: 0.0302
DEBUG - 2012-09-06 16:11:35 --> Config Class Initialized
DEBUG - 2012-09-06 16:11:35 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:11:35 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:11:35 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:11:35 --> URI Class Initialized
DEBUG - 2012-09-06 16:11:35 --> Router Class Initialized
DEBUG - 2012-09-06 16:11:35 --> Output Class Initialized
DEBUG - 2012-09-06 16:11:35 --> Security Class Initialized
DEBUG - 2012-09-06 16:11:35 --> Input Class Initialized
DEBUG - 2012-09-06 16:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:11:35 --> Language Class Initialized
DEBUG - 2012-09-06 16:11:35 --> Loader Class Initialized
DEBUG - 2012-09-06 16:11:35 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:11:35 --> Controller Class Initialized
DEBUG - 2012-09-06 16:11:35 --> Model Class Initialized
DEBUG - 2012-09-06 16:11:35 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:11:35 --> Final output sent to browser
DEBUG - 2012-09-06 16:11:35 --> Total execution time: 0.6864
DEBUG - 2012-09-06 16:12:58 --> Config Class Initialized
DEBUG - 2012-09-06 16:12:58 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:12:58 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:12:58 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:12:58 --> URI Class Initialized
DEBUG - 2012-09-06 16:12:58 --> Router Class Initialized
DEBUG - 2012-09-06 16:12:58 --> Output Class Initialized
DEBUG - 2012-09-06 16:12:58 --> Security Class Initialized
DEBUG - 2012-09-06 16:12:58 --> Input Class Initialized
DEBUG - 2012-09-06 16:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:12:58 --> Language Class Initialized
DEBUG - 2012-09-06 16:12:58 --> Loader Class Initialized
DEBUG - 2012-09-06 16:12:58 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:12:58 --> Controller Class Initialized
DEBUG - 2012-09-06 16:12:58 --> Model Class Initialized
DEBUG - 2012-09-06 16:12:58 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:12:58 --> Final output sent to browser
DEBUG - 2012-09-06 16:12:58 --> Total execution time: 0.0297
DEBUG - 2012-09-06 16:13:03 --> Config Class Initialized
DEBUG - 2012-09-06 16:13:03 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:13:03 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:13:03 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:13:03 --> URI Class Initialized
DEBUG - 2012-09-06 16:13:03 --> Router Class Initialized
DEBUG - 2012-09-06 16:13:03 --> Output Class Initialized
DEBUG - 2012-09-06 16:13:03 --> Security Class Initialized
DEBUG - 2012-09-06 16:13:03 --> Input Class Initialized
DEBUG - 2012-09-06 16:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:13:03 --> Language Class Initialized
DEBUG - 2012-09-06 16:13:03 --> Loader Class Initialized
DEBUG - 2012-09-06 16:13:03 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:13:03 --> Controller Class Initialized
DEBUG - 2012-09-06 16:13:03 --> Model Class Initialized
DEBUG - 2012-09-06 16:13:03 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:13:03 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:13:04 --> Form Validation Class Initialized
DEBUG - 2012-09-06 16:13:06 --> Config Class Initialized
DEBUG - 2012-09-06 16:13:06 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:13:06 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:13:06 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:13:06 --> URI Class Initialized
DEBUG - 2012-09-06 16:13:06 --> Router Class Initialized
DEBUG - 2012-09-06 16:13:06 --> Output Class Initialized
DEBUG - 2012-09-06 16:13:06 --> Security Class Initialized
DEBUG - 2012-09-06 16:13:06 --> Input Class Initialized
DEBUG - 2012-09-06 16:13:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:13:06 --> Language Class Initialized
DEBUG - 2012-09-06 16:13:06 --> Loader Class Initialized
DEBUG - 2012-09-06 16:13:06 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:13:06 --> Controller Class Initialized
DEBUG - 2012-09-06 16:13:06 --> Model Class Initialized
DEBUG - 2012-09-06 16:13:06 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:13:06 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:13:06 --> Form Validation Class Initialized
DEBUG - 2012-09-06 16:13:16 --> Config Class Initialized
DEBUG - 2012-09-06 16:13:16 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:13:16 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:13:16 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:13:16 --> URI Class Initialized
DEBUG - 2012-09-06 16:13:16 --> Router Class Initialized
DEBUG - 2012-09-06 16:13:16 --> Output Class Initialized
DEBUG - 2012-09-06 16:13:16 --> Security Class Initialized
DEBUG - 2012-09-06 16:13:16 --> Input Class Initialized
DEBUG - 2012-09-06 16:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:13:16 --> Language Class Initialized
DEBUG - 2012-09-06 16:13:16 --> Loader Class Initialized
DEBUG - 2012-09-06 16:13:16 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:13:16 --> Controller Class Initialized
DEBUG - 2012-09-06 16:13:16 --> Model Class Initialized
DEBUG - 2012-09-06 16:13:16 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:13:16 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:13:16 --> Form Validation Class Initialized
DEBUG - 2012-09-06 16:13:43 --> Config Class Initialized
DEBUG - 2012-09-06 16:13:43 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:13:43 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:13:43 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:13:43 --> URI Class Initialized
DEBUG - 2012-09-06 16:13:43 --> Router Class Initialized
DEBUG - 2012-09-06 16:13:43 --> Output Class Initialized
DEBUG - 2012-09-06 16:13:43 --> Security Class Initialized
DEBUG - 2012-09-06 16:13:43 --> Input Class Initialized
DEBUG - 2012-09-06 16:13:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:13:43 --> Language Class Initialized
DEBUG - 2012-09-06 16:13:43 --> Loader Class Initialized
DEBUG - 2012-09-06 16:13:43 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:13:43 --> Controller Class Initialized
DEBUG - 2012-09-06 16:13:43 --> Model Class Initialized
DEBUG - 2012-09-06 16:13:43 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:13:43 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:13:43 --> Form Validation Class Initialized
DEBUG - 2012-09-06 16:13:57 --> DB Transaction Failure
DEBUG - 2012-09-06 16:13:57 --> Final output sent to browser
DEBUG - 2012-09-06 16:13:57 --> Total execution time: 50.9193
DEBUG - 2012-09-06 16:14:07 --> DB Transaction Failure
DEBUG - 2012-09-06 16:14:07 --> Final output sent to browser
DEBUG - 2012-09-06 16:14:07 --> Total execution time: 51.1513
DEBUG - 2012-09-06 16:14:36 --> DB Transaction Failure
DEBUG - 2012-09-06 16:14:37 --> Final output sent to browser
DEBUG - 2012-09-06 16:14:37 --> Total execution time: 54.4553
DEBUG - 2012-09-06 16:14:42 --> Final output sent to browser
DEBUG - 2012-09-06 16:14:42 --> Total execution time: 99.4198
DEBUG - 2012-09-06 16:16:11 --> Config Class Initialized
DEBUG - 2012-09-06 16:16:11 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:16:11 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:16:11 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:16:11 --> URI Class Initialized
DEBUG - 2012-09-06 16:16:11 --> Router Class Initialized
DEBUG - 2012-09-06 16:16:11 --> Output Class Initialized
DEBUG - 2012-09-06 16:16:11 --> Security Class Initialized
DEBUG - 2012-09-06 16:16:11 --> Input Class Initialized
DEBUG - 2012-09-06 16:16:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:16:11 --> Language Class Initialized
DEBUG - 2012-09-06 16:16:11 --> Loader Class Initialized
DEBUG - 2012-09-06 16:16:11 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:16:11 --> Controller Class Initialized
DEBUG - 2012-09-06 16:16:11 --> Model Class Initialized
DEBUG - 2012-09-06 16:16:11 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:16:11 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:16:11 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 16:16:11 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 16:16:11 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 16:16:11 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 16:16:11 --> Final output sent to browser
DEBUG - 2012-09-06 16:16:11 --> Total execution time: 0.0435
DEBUG - 2012-09-06 16:16:14 --> Config Class Initialized
DEBUG - 2012-09-06 16:16:14 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:16:14 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:16:14 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:16:14 --> URI Class Initialized
DEBUG - 2012-09-06 16:16:14 --> Router Class Initialized
DEBUG - 2012-09-06 16:16:14 --> Output Class Initialized
DEBUG - 2012-09-06 16:16:14 --> Security Class Initialized
DEBUG - 2012-09-06 16:16:14 --> Input Class Initialized
DEBUG - 2012-09-06 16:16:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:16:14 --> Language Class Initialized
DEBUG - 2012-09-06 16:16:14 --> Loader Class Initialized
DEBUG - 2012-09-06 16:16:14 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:16:14 --> Controller Class Initialized
DEBUG - 2012-09-06 16:16:14 --> Model Class Initialized
DEBUG - 2012-09-06 16:16:14 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:16:14 --> Final output sent to browser
DEBUG - 2012-09-06 16:16:14 --> Total execution time: 0.0296
DEBUG - 2012-09-06 16:16:15 --> Config Class Initialized
DEBUG - 2012-09-06 16:16:15 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:16:15 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:16:15 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:16:15 --> URI Class Initialized
DEBUG - 2012-09-06 16:16:15 --> Router Class Initialized
DEBUG - 2012-09-06 16:16:15 --> Output Class Initialized
DEBUG - 2012-09-06 16:16:15 --> Security Class Initialized
DEBUG - 2012-09-06 16:16:15 --> Input Class Initialized
DEBUG - 2012-09-06 16:16:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:16:15 --> Language Class Initialized
DEBUG - 2012-09-06 16:16:15 --> Loader Class Initialized
DEBUG - 2012-09-06 16:16:15 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:16:15 --> Controller Class Initialized
DEBUG - 2012-09-06 16:16:15 --> Model Class Initialized
DEBUG - 2012-09-06 16:16:15 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:16:15 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:16:15 --> Form Validation Class Initialized
DEBUG - 2012-09-06 16:16:15 --> Final output sent to browser
DEBUG - 2012-09-06 16:16:15 --> Total execution time: 0.0882
DEBUG - 2012-09-06 16:16:20 --> Config Class Initialized
DEBUG - 2012-09-06 16:16:20 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:16:20 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:16:20 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:16:20 --> URI Class Initialized
DEBUG - 2012-09-06 16:16:20 --> Router Class Initialized
DEBUG - 2012-09-06 16:16:20 --> Output Class Initialized
DEBUG - 2012-09-06 16:16:20 --> Security Class Initialized
DEBUG - 2012-09-06 16:16:20 --> Input Class Initialized
DEBUG - 2012-09-06 16:16:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:16:20 --> Language Class Initialized
DEBUG - 2012-09-06 16:16:20 --> Loader Class Initialized
DEBUG - 2012-09-06 16:16:20 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:16:20 --> Controller Class Initialized
DEBUG - 2012-09-06 16:16:20 --> Model Class Initialized
DEBUG - 2012-09-06 16:16:20 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:16:20 --> Final output sent to browser
DEBUG - 2012-09-06 16:16:20 --> Total execution time: 0.0332
DEBUG - 2012-09-06 16:16:35 --> Config Class Initialized
DEBUG - 2012-09-06 16:16:35 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:16:35 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:16:35 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:16:35 --> URI Class Initialized
DEBUG - 2012-09-06 16:16:35 --> Router Class Initialized
DEBUG - 2012-09-06 16:16:35 --> Output Class Initialized
DEBUG - 2012-09-06 16:16:35 --> Security Class Initialized
DEBUG - 2012-09-06 16:16:35 --> Input Class Initialized
DEBUG - 2012-09-06 16:16:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:16:35 --> Language Class Initialized
DEBUG - 2012-09-06 16:16:35 --> Loader Class Initialized
DEBUG - 2012-09-06 16:16:35 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:16:35 --> Controller Class Initialized
DEBUG - 2012-09-06 16:16:35 --> Model Class Initialized
DEBUG - 2012-09-06 16:16:35 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:16:43 --> Config Class Initialized
DEBUG - 2012-09-06 16:16:43 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:16:43 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:16:43 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:16:43 --> URI Class Initialized
DEBUG - 2012-09-06 16:16:43 --> Router Class Initialized
DEBUG - 2012-09-06 16:16:43 --> Output Class Initialized
DEBUG - 2012-09-06 16:16:43 --> Security Class Initialized
DEBUG - 2012-09-06 16:16:43 --> Input Class Initialized
DEBUG - 2012-09-06 16:16:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:16:43 --> Language Class Initialized
DEBUG - 2012-09-06 16:16:43 --> Loader Class Initialized
DEBUG - 2012-09-06 16:16:43 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:16:43 --> Controller Class Initialized
DEBUG - 2012-09-06 16:16:43 --> Model Class Initialized
DEBUG - 2012-09-06 16:16:43 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:16:47 --> Config Class Initialized
DEBUG - 2012-09-06 16:16:47 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:16:47 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:16:47 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:16:47 --> URI Class Initialized
DEBUG - 2012-09-06 16:16:47 --> Router Class Initialized
DEBUG - 2012-09-06 16:16:47 --> Output Class Initialized
DEBUG - 2012-09-06 16:16:47 --> Security Class Initialized
DEBUG - 2012-09-06 16:16:47 --> Input Class Initialized
DEBUG - 2012-09-06 16:16:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:16:47 --> Language Class Initialized
DEBUG - 2012-09-06 16:16:47 --> Loader Class Initialized
DEBUG - 2012-09-06 16:16:47 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:16:47 --> Controller Class Initialized
DEBUG - 2012-09-06 16:16:47 --> Model Class Initialized
DEBUG - 2012-09-06 16:16:47 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:17:34 --> Final output sent to browser
DEBUG - 2012-09-06 16:17:34 --> Total execution time: 50.9858
DEBUG - 2012-09-06 16:17:38 --> Final output sent to browser
DEBUG - 2012-09-06 16:17:38 --> Total execution time: 51.5130
DEBUG - 2012-09-06 16:24:45 --> Final output sent to browser
DEBUG - 2012-09-06 16:24:45 --> Total execution time: 489.6177
DEBUG - 2012-09-06 16:32:02 --> Config Class Initialized
DEBUG - 2012-09-06 16:32:02 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:32:02 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:32:02 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:32:02 --> URI Class Initialized
DEBUG - 2012-09-06 16:32:02 --> Router Class Initialized
DEBUG - 2012-09-06 16:32:02 --> Output Class Initialized
DEBUG - 2012-09-06 16:32:02 --> Security Class Initialized
DEBUG - 2012-09-06 16:32:02 --> Input Class Initialized
DEBUG - 2012-09-06 16:32:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:32:02 --> Language Class Initialized
DEBUG - 2012-09-06 16:32:02 --> Loader Class Initialized
DEBUG - 2012-09-06 16:32:02 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:32:02 --> Controller Class Initialized
DEBUG - 2012-09-06 16:32:02 --> Model Class Initialized
DEBUG - 2012-09-06 16:32:02 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:32:02 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:32:02 --> Form Validation Class Initialized
DEBUG - 2012-09-06 16:32:02 --> Final output sent to browser
DEBUG - 2012-09-06 16:32:02 --> Total execution time: 0.3339
DEBUG - 2012-09-06 16:32:13 --> Config Class Initialized
DEBUG - 2012-09-06 16:32:13 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:32:13 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:32:13 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:32:13 --> URI Class Initialized
DEBUG - 2012-09-06 16:32:13 --> Router Class Initialized
DEBUG - 2012-09-06 16:32:13 --> Output Class Initialized
DEBUG - 2012-09-06 16:32:13 --> Security Class Initialized
DEBUG - 2012-09-06 16:32:13 --> Input Class Initialized
DEBUG - 2012-09-06 16:32:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:32:13 --> Language Class Initialized
DEBUG - 2012-09-06 16:32:13 --> Loader Class Initialized
DEBUG - 2012-09-06 16:32:13 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:32:13 --> Controller Class Initialized
DEBUG - 2012-09-06 16:32:13 --> Model Class Initialized
DEBUG - 2012-09-06 16:32:13 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:32:13 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:32:13 --> Form Validation Class Initialized
DEBUG - 2012-09-06 16:32:13 --> Final output sent to browser
DEBUG - 2012-09-06 16:32:13 --> Total execution time: 0.1188
DEBUG - 2012-09-06 16:32:50 --> Config Class Initialized
DEBUG - 2012-09-06 16:32:50 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:32:50 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:32:50 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:32:50 --> URI Class Initialized
DEBUG - 2012-09-06 16:32:50 --> Router Class Initialized
DEBUG - 2012-09-06 16:32:50 --> Output Class Initialized
DEBUG - 2012-09-06 16:32:50 --> Security Class Initialized
DEBUG - 2012-09-06 16:32:50 --> Input Class Initialized
DEBUG - 2012-09-06 16:32:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:32:50 --> Language Class Initialized
DEBUG - 2012-09-06 16:32:50 --> Loader Class Initialized
DEBUG - 2012-09-06 16:32:50 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:32:50 --> Controller Class Initialized
DEBUG - 2012-09-06 16:32:50 --> Model Class Initialized
DEBUG - 2012-09-06 16:32:50 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:32:50 --> Final output sent to browser
DEBUG - 2012-09-06 16:32:50 --> Total execution time: 0.1289
DEBUG - 2012-09-06 16:33:52 --> Config Class Initialized
DEBUG - 2012-09-06 16:33:52 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:33:52 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:33:52 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:33:52 --> URI Class Initialized
DEBUG - 2012-09-06 16:33:52 --> Router Class Initialized
DEBUG - 2012-09-06 16:33:52 --> Output Class Initialized
DEBUG - 2012-09-06 16:33:52 --> Security Class Initialized
DEBUG - 2012-09-06 16:33:52 --> Input Class Initialized
DEBUG - 2012-09-06 16:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:33:52 --> Language Class Initialized
DEBUG - 2012-09-06 16:33:52 --> Loader Class Initialized
DEBUG - 2012-09-06 16:33:52 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:33:52 --> Controller Class Initialized
DEBUG - 2012-09-06 16:33:52 --> Model Class Initialized
DEBUG - 2012-09-06 16:33:52 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:33:52 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:33:54 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 16:33:54 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 16:33:54 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 16:33:54 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 16:33:54 --> Final output sent to browser
DEBUG - 2012-09-06 16:33:54 --> Total execution time: 1.4967
DEBUG - 2012-09-06 16:33:56 --> Config Class Initialized
DEBUG - 2012-09-06 16:33:56 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:33:56 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:33:56 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:33:56 --> URI Class Initialized
DEBUG - 2012-09-06 16:33:56 --> Router Class Initialized
DEBUG - 2012-09-06 16:33:56 --> Output Class Initialized
DEBUG - 2012-09-06 16:33:56 --> Security Class Initialized
DEBUG - 2012-09-06 16:33:56 --> Input Class Initialized
DEBUG - 2012-09-06 16:33:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:33:56 --> Language Class Initialized
DEBUG - 2012-09-06 16:33:56 --> Loader Class Initialized
DEBUG - 2012-09-06 16:33:56 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:33:56 --> Controller Class Initialized
DEBUG - 2012-09-06 16:33:56 --> Model Class Initialized
DEBUG - 2012-09-06 16:33:56 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:33:56 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:33:56 --> Form Validation Class Initialized
DEBUG - 2012-09-06 16:33:56 --> Final output sent to browser
DEBUG - 2012-09-06 16:33:56 --> Total execution time: 0.0410
DEBUG - 2012-09-06 16:33:58 --> Config Class Initialized
DEBUG - 2012-09-06 16:33:58 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:33:58 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:33:58 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:33:58 --> URI Class Initialized
DEBUG - 2012-09-06 16:33:58 --> Router Class Initialized
DEBUG - 2012-09-06 16:33:58 --> Output Class Initialized
DEBUG - 2012-09-06 16:33:58 --> Security Class Initialized
DEBUG - 2012-09-06 16:33:58 --> Input Class Initialized
DEBUG - 2012-09-06 16:33:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:33:58 --> Language Class Initialized
DEBUG - 2012-09-06 16:33:58 --> Loader Class Initialized
DEBUG - 2012-09-06 16:33:58 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:33:58 --> Controller Class Initialized
DEBUG - 2012-09-06 16:33:58 --> Model Class Initialized
DEBUG - 2012-09-06 16:33:58 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:33:58 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:33:58 --> Form Validation Class Initialized
DEBUG - 2012-09-06 16:33:58 --> Final output sent to browser
DEBUG - 2012-09-06 16:33:58 --> Total execution time: 0.0469
DEBUG - 2012-09-06 16:34:00 --> Config Class Initialized
DEBUG - 2012-09-06 16:34:00 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:34:00 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:34:00 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:34:00 --> URI Class Initialized
DEBUG - 2012-09-06 16:34:00 --> Router Class Initialized
DEBUG - 2012-09-06 16:34:00 --> Output Class Initialized
DEBUG - 2012-09-06 16:34:00 --> Security Class Initialized
DEBUG - 2012-09-06 16:34:00 --> Input Class Initialized
DEBUG - 2012-09-06 16:34:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:34:00 --> Language Class Initialized
DEBUG - 2012-09-06 16:34:00 --> Loader Class Initialized
DEBUG - 2012-09-06 16:34:00 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:34:00 --> Controller Class Initialized
DEBUG - 2012-09-06 16:34:00 --> Model Class Initialized
DEBUG - 2012-09-06 16:34:00 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:34:00 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:34:00 --> Form Validation Class Initialized
DEBUG - 2012-09-06 16:34:00 --> Final output sent to browser
DEBUG - 2012-09-06 16:34:00 --> Total execution time: 0.0461
DEBUG - 2012-09-06 16:35:30 --> Config Class Initialized
DEBUG - 2012-09-06 16:35:30 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:35:30 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:35:30 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:35:30 --> URI Class Initialized
DEBUG - 2012-09-06 16:35:30 --> Router Class Initialized
DEBUG - 2012-09-06 16:35:30 --> Output Class Initialized
DEBUG - 2012-09-06 16:35:30 --> Security Class Initialized
DEBUG - 2012-09-06 16:35:30 --> Input Class Initialized
DEBUG - 2012-09-06 16:35:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:35:30 --> Language Class Initialized
DEBUG - 2012-09-06 16:35:30 --> Loader Class Initialized
DEBUG - 2012-09-06 16:35:30 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:35:30 --> Controller Class Initialized
DEBUG - 2012-09-06 16:35:30 --> Model Class Initialized
DEBUG - 2012-09-06 16:35:30 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:35:30 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:35:30 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 16:35:30 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 16:35:30 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 16:35:30 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 16:35:30 --> Final output sent to browser
DEBUG - 2012-09-06 16:35:30 --> Total execution time: 0.0464
DEBUG - 2012-09-06 16:35:30 --> Config Class Initialized
DEBUG - 2012-09-06 16:35:30 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:35:30 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:35:30 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:35:30 --> URI Class Initialized
DEBUG - 2012-09-06 16:35:30 --> Router Class Initialized
ERROR - 2012-09-06 16:35:31 --> 404 Page Not Found --> js
DEBUG - 2012-09-06 16:35:33 --> Config Class Initialized
DEBUG - 2012-09-06 16:35:33 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:35:33 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:35:33 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:35:33 --> URI Class Initialized
DEBUG - 2012-09-06 16:35:33 --> Router Class Initialized
DEBUG - 2012-09-06 16:35:33 --> Output Class Initialized
DEBUG - 2012-09-06 16:35:33 --> Security Class Initialized
DEBUG - 2012-09-06 16:35:33 --> Input Class Initialized
DEBUG - 2012-09-06 16:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:35:33 --> Language Class Initialized
DEBUG - 2012-09-06 16:35:33 --> Loader Class Initialized
DEBUG - 2012-09-06 16:35:33 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:35:33 --> Controller Class Initialized
DEBUG - 2012-09-06 16:35:33 --> Model Class Initialized
DEBUG - 2012-09-06 16:35:33 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:35:33 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:35:33 --> Form Validation Class Initialized
DEBUG - 2012-09-06 16:35:33 --> Final output sent to browser
DEBUG - 2012-09-06 16:35:33 --> Total execution time: 0.0502
DEBUG - 2012-09-06 16:35:38 --> Config Class Initialized
DEBUG - 2012-09-06 16:35:38 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:35:38 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:35:38 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:35:38 --> URI Class Initialized
DEBUG - 2012-09-06 16:35:38 --> Router Class Initialized
DEBUG - 2012-09-06 16:35:38 --> Output Class Initialized
DEBUG - 2012-09-06 16:35:38 --> Security Class Initialized
DEBUG - 2012-09-06 16:35:38 --> Input Class Initialized
DEBUG - 2012-09-06 16:35:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:35:38 --> Language Class Initialized
DEBUG - 2012-09-06 16:35:38 --> Loader Class Initialized
DEBUG - 2012-09-06 16:35:38 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:35:38 --> Controller Class Initialized
DEBUG - 2012-09-06 16:35:38 --> Model Class Initialized
DEBUG - 2012-09-06 16:35:38 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:35:38 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:35:38 --> Form Validation Class Initialized
DEBUG - 2012-09-06 16:35:38 --> Final output sent to browser
DEBUG - 2012-09-06 16:35:38 --> Total execution time: 0.0396
DEBUG - 2012-09-06 16:38:10 --> Config Class Initialized
DEBUG - 2012-09-06 16:38:10 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:38:10 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:38:10 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:38:10 --> URI Class Initialized
DEBUG - 2012-09-06 16:38:10 --> Router Class Initialized
DEBUG - 2012-09-06 16:38:10 --> Output Class Initialized
DEBUG - 2012-09-06 16:38:10 --> Security Class Initialized
DEBUG - 2012-09-06 16:38:10 --> Input Class Initialized
DEBUG - 2012-09-06 16:38:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:38:10 --> Language Class Initialized
DEBUG - 2012-09-06 16:38:10 --> Loader Class Initialized
DEBUG - 2012-09-06 16:38:10 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:38:10 --> Controller Class Initialized
DEBUG - 2012-09-06 16:38:10 --> Model Class Initialized
DEBUG - 2012-09-06 16:38:10 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:38:10 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:38:10 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 16:38:10 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 16:38:10 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 16:38:10 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 16:38:10 --> Final output sent to browser
DEBUG - 2012-09-06 16:38:10 --> Total execution time: 0.0589
DEBUG - 2012-09-06 16:38:12 --> Config Class Initialized
DEBUG - 2012-09-06 16:38:12 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:38:12 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:38:12 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:38:12 --> URI Class Initialized
DEBUG - 2012-09-06 16:38:12 --> Router Class Initialized
DEBUG - 2012-09-06 16:38:12 --> Output Class Initialized
DEBUG - 2012-09-06 16:38:12 --> Security Class Initialized
DEBUG - 2012-09-06 16:38:12 --> Input Class Initialized
DEBUG - 2012-09-06 16:38:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:38:12 --> Language Class Initialized
DEBUG - 2012-09-06 16:38:12 --> Loader Class Initialized
DEBUG - 2012-09-06 16:38:12 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:38:12 --> Controller Class Initialized
DEBUG - 2012-09-06 16:38:12 --> Model Class Initialized
DEBUG - 2012-09-06 16:38:12 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:38:12 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:38:12 --> Form Validation Class Initialized
DEBUG - 2012-09-06 16:38:12 --> Final output sent to browser
DEBUG - 2012-09-06 16:38:12 --> Total execution time: 0.0402
DEBUG - 2012-09-06 16:38:16 --> Config Class Initialized
DEBUG - 2012-09-06 16:38:16 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:38:16 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:38:16 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:38:16 --> URI Class Initialized
DEBUG - 2012-09-06 16:38:16 --> Router Class Initialized
DEBUG - 2012-09-06 16:38:16 --> Output Class Initialized
DEBUG - 2012-09-06 16:38:16 --> Security Class Initialized
DEBUG - 2012-09-06 16:38:16 --> Input Class Initialized
DEBUG - 2012-09-06 16:38:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:38:16 --> Language Class Initialized
DEBUG - 2012-09-06 16:38:16 --> Loader Class Initialized
DEBUG - 2012-09-06 16:38:16 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:38:16 --> Controller Class Initialized
DEBUG - 2012-09-06 16:38:16 --> Model Class Initialized
DEBUG - 2012-09-06 16:38:16 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:38:16 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:38:16 --> Form Validation Class Initialized
DEBUG - 2012-09-06 16:38:16 --> Final output sent to browser
DEBUG - 2012-09-06 16:38:16 --> Total execution time: 0.0429
DEBUG - 2012-09-06 16:38:30 --> Config Class Initialized
DEBUG - 2012-09-06 16:38:30 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:38:30 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:38:30 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:38:30 --> URI Class Initialized
DEBUG - 2012-09-06 16:38:30 --> Router Class Initialized
DEBUG - 2012-09-06 16:38:30 --> Output Class Initialized
DEBUG - 2012-09-06 16:38:30 --> Security Class Initialized
DEBUG - 2012-09-06 16:38:30 --> Input Class Initialized
DEBUG - 2012-09-06 16:38:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:38:30 --> Language Class Initialized
DEBUG - 2012-09-06 16:38:30 --> Loader Class Initialized
DEBUG - 2012-09-06 16:38:30 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:38:30 --> Controller Class Initialized
DEBUG - 2012-09-06 16:38:30 --> Model Class Initialized
DEBUG - 2012-09-06 16:38:30 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:38:30 --> Final output sent to browser
DEBUG - 2012-09-06 16:38:30 --> Total execution time: 0.0389
DEBUG - 2012-09-06 16:38:44 --> Config Class Initialized
DEBUG - 2012-09-06 16:38:44 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:38:44 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:38:44 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:38:44 --> URI Class Initialized
DEBUG - 2012-09-06 16:38:44 --> Router Class Initialized
DEBUG - 2012-09-06 16:38:44 --> Output Class Initialized
DEBUG - 2012-09-06 16:38:44 --> Security Class Initialized
DEBUG - 2012-09-06 16:38:44 --> Input Class Initialized
DEBUG - 2012-09-06 16:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:38:44 --> Language Class Initialized
DEBUG - 2012-09-06 16:38:44 --> Loader Class Initialized
DEBUG - 2012-09-06 16:38:44 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:38:44 --> Controller Class Initialized
DEBUG - 2012-09-06 16:38:44 --> Model Class Initialized
DEBUG - 2012-09-06 16:38:44 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:38:44 --> Final output sent to browser
DEBUG - 2012-09-06 16:38:44 --> Total execution time: 0.2114
DEBUG - 2012-09-06 16:39:32 --> Config Class Initialized
DEBUG - 2012-09-06 16:39:32 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:39:32 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:39:32 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:39:32 --> URI Class Initialized
DEBUG - 2012-09-06 16:39:32 --> Router Class Initialized
DEBUG - 2012-09-06 16:39:32 --> Output Class Initialized
DEBUG - 2012-09-06 16:39:32 --> Security Class Initialized
DEBUG - 2012-09-06 16:39:32 --> Input Class Initialized
DEBUG - 2012-09-06 16:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:39:32 --> Language Class Initialized
DEBUG - 2012-09-06 16:39:32 --> Loader Class Initialized
DEBUG - 2012-09-06 16:39:32 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:39:32 --> Controller Class Initialized
DEBUG - 2012-09-06 16:39:32 --> Model Class Initialized
DEBUG - 2012-09-06 16:39:32 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:39:33 --> Final output sent to browser
DEBUG - 2012-09-06 16:39:33 --> Total execution time: 0.3345
DEBUG - 2012-09-06 16:39:37 --> Config Class Initialized
DEBUG - 2012-09-06 16:39:37 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:39:37 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:39:37 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:39:37 --> URI Class Initialized
DEBUG - 2012-09-06 16:39:37 --> Router Class Initialized
DEBUG - 2012-09-06 16:39:37 --> Output Class Initialized
DEBUG - 2012-09-06 16:39:37 --> Security Class Initialized
DEBUG - 2012-09-06 16:39:37 --> Input Class Initialized
DEBUG - 2012-09-06 16:39:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:39:37 --> Language Class Initialized
DEBUG - 2012-09-06 16:39:37 --> Loader Class Initialized
DEBUG - 2012-09-06 16:39:37 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:39:37 --> Controller Class Initialized
DEBUG - 2012-09-06 16:39:37 --> Model Class Initialized
DEBUG - 2012-09-06 16:39:37 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:39:37 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:39:37 --> Form Validation Class Initialized
DEBUG - 2012-09-06 16:39:37 --> Final output sent to browser
DEBUG - 2012-09-06 16:39:37 --> Total execution time: 0.0396
DEBUG - 2012-09-06 16:39:40 --> Config Class Initialized
DEBUG - 2012-09-06 16:39:40 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:39:40 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:39:40 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:39:40 --> URI Class Initialized
DEBUG - 2012-09-06 16:39:40 --> Router Class Initialized
DEBUG - 2012-09-06 16:39:40 --> Output Class Initialized
DEBUG - 2012-09-06 16:39:40 --> Security Class Initialized
DEBUG - 2012-09-06 16:39:40 --> Input Class Initialized
DEBUG - 2012-09-06 16:39:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:39:40 --> Language Class Initialized
DEBUG - 2012-09-06 16:39:40 --> Loader Class Initialized
DEBUG - 2012-09-06 16:39:40 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:39:40 --> Controller Class Initialized
DEBUG - 2012-09-06 16:39:40 --> Model Class Initialized
DEBUG - 2012-09-06 16:39:40 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:39:41 --> Final output sent to browser
DEBUG - 2012-09-06 16:39:41 --> Total execution time: 0.2987
DEBUG - 2012-09-06 16:39:58 --> Config Class Initialized
DEBUG - 2012-09-06 16:39:58 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:39:58 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:39:58 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:39:58 --> URI Class Initialized
DEBUG - 2012-09-06 16:39:58 --> Router Class Initialized
DEBUG - 2012-09-06 16:39:58 --> Output Class Initialized
DEBUG - 2012-09-06 16:39:58 --> Security Class Initialized
DEBUG - 2012-09-06 16:39:58 --> Input Class Initialized
DEBUG - 2012-09-06 16:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:39:58 --> Language Class Initialized
DEBUG - 2012-09-06 16:39:58 --> Loader Class Initialized
DEBUG - 2012-09-06 16:39:58 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:39:58 --> Controller Class Initialized
DEBUG - 2012-09-06 16:39:58 --> Model Class Initialized
DEBUG - 2012-09-06 16:39:58 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:39:58 --> Final output sent to browser
DEBUG - 2012-09-06 16:39:58 --> Total execution time: 0.2314
DEBUG - 2012-09-06 16:40:04 --> Config Class Initialized
DEBUG - 2012-09-06 16:40:04 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:40:04 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:40:04 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:40:04 --> URI Class Initialized
DEBUG - 2012-09-06 16:40:04 --> Router Class Initialized
DEBUG - 2012-09-06 16:40:04 --> Output Class Initialized
DEBUG - 2012-09-06 16:40:04 --> Security Class Initialized
DEBUG - 2012-09-06 16:40:04 --> Input Class Initialized
DEBUG - 2012-09-06 16:40:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:40:04 --> Language Class Initialized
DEBUG - 2012-09-06 16:40:04 --> Loader Class Initialized
DEBUG - 2012-09-06 16:40:04 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:40:04 --> Controller Class Initialized
DEBUG - 2012-09-06 16:40:04 --> Model Class Initialized
DEBUG - 2012-09-06 16:40:04 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:40:04 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:40:04 --> Form Validation Class Initialized
DEBUG - 2012-09-06 16:40:04 --> Final output sent to browser
DEBUG - 2012-09-06 16:40:04 --> Total execution time: 0.1504
DEBUG - 2012-09-06 16:40:06 --> Config Class Initialized
DEBUG - 2012-09-06 16:40:06 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:40:06 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:40:06 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:40:06 --> URI Class Initialized
DEBUG - 2012-09-06 16:40:06 --> Router Class Initialized
DEBUG - 2012-09-06 16:40:06 --> Output Class Initialized
DEBUG - 2012-09-06 16:40:06 --> Security Class Initialized
DEBUG - 2012-09-06 16:40:06 --> Input Class Initialized
DEBUG - 2012-09-06 16:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:40:06 --> Language Class Initialized
DEBUG - 2012-09-06 16:40:06 --> Loader Class Initialized
DEBUG - 2012-09-06 16:40:06 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:40:06 --> Controller Class Initialized
DEBUG - 2012-09-06 16:40:06 --> Model Class Initialized
DEBUG - 2012-09-06 16:40:06 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:40:07 --> Final output sent to browser
DEBUG - 2012-09-06 16:40:07 --> Total execution time: 0.3260
DEBUG - 2012-09-06 16:40:59 --> Config Class Initialized
DEBUG - 2012-09-06 16:40:59 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:40:59 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:40:59 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:40:59 --> URI Class Initialized
DEBUG - 2012-09-06 16:40:59 --> Router Class Initialized
DEBUG - 2012-09-06 16:40:59 --> Output Class Initialized
DEBUG - 2012-09-06 16:40:59 --> Security Class Initialized
DEBUG - 2012-09-06 16:40:59 --> Input Class Initialized
DEBUG - 2012-09-06 16:40:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:40:59 --> Language Class Initialized
DEBUG - 2012-09-06 16:40:59 --> Loader Class Initialized
DEBUG - 2012-09-06 16:40:59 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:40:59 --> Controller Class Initialized
DEBUG - 2012-09-06 16:40:59 --> Model Class Initialized
DEBUG - 2012-09-06 16:40:59 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:40:59 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:40:59 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 16:40:59 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 16:40:59 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 16:40:59 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 16:40:59 --> Final output sent to browser
DEBUG - 2012-09-06 16:40:59 --> Total execution time: 0.0464
DEBUG - 2012-09-06 16:41:13 --> Config Class Initialized
DEBUG - 2012-09-06 16:41:13 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:41:13 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:41:13 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:41:13 --> URI Class Initialized
DEBUG - 2012-09-06 16:41:13 --> Router Class Initialized
DEBUG - 2012-09-06 16:41:13 --> Output Class Initialized
DEBUG - 2012-09-06 16:41:13 --> Security Class Initialized
DEBUG - 2012-09-06 16:41:13 --> Input Class Initialized
DEBUG - 2012-09-06 16:41:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:41:13 --> Language Class Initialized
DEBUG - 2012-09-06 16:41:13 --> Loader Class Initialized
DEBUG - 2012-09-06 16:41:13 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:41:13 --> Controller Class Initialized
DEBUG - 2012-09-06 16:41:13 --> Model Class Initialized
DEBUG - 2012-09-06 16:41:13 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:41:13 --> Final output sent to browser
DEBUG - 2012-09-06 16:41:13 --> Total execution time: 0.1896
DEBUG - 2012-09-06 16:41:58 --> Config Class Initialized
DEBUG - 2012-09-06 16:41:58 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:41:58 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:41:58 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:41:58 --> URI Class Initialized
DEBUG - 2012-09-06 16:41:58 --> Router Class Initialized
DEBUG - 2012-09-06 16:41:58 --> Output Class Initialized
DEBUG - 2012-09-06 16:41:58 --> Security Class Initialized
DEBUG - 2012-09-06 16:41:58 --> Input Class Initialized
DEBUG - 2012-09-06 16:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:41:58 --> Language Class Initialized
DEBUG - 2012-09-06 16:41:58 --> Loader Class Initialized
DEBUG - 2012-09-06 16:41:58 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:41:58 --> Controller Class Initialized
DEBUG - 2012-09-06 16:41:58 --> Model Class Initialized
DEBUG - 2012-09-06 16:41:58 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:41:58 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:41:58 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 16:41:58 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-09-06 16:41:58 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 16:41:58 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-09-06 16:41:58 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 16:41:58 --> Final output sent to browser
DEBUG - 2012-09-06 16:41:58 --> Total execution time: 0.2089
DEBUG - 2012-09-06 16:42:00 --> Config Class Initialized
DEBUG - 2012-09-06 16:42:00 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:42:00 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:42:00 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:42:00 --> URI Class Initialized
DEBUG - 2012-09-06 16:42:00 --> Router Class Initialized
DEBUG - 2012-09-06 16:42:00 --> Output Class Initialized
DEBUG - 2012-09-06 16:42:00 --> Security Class Initialized
DEBUG - 2012-09-06 16:42:00 --> Input Class Initialized
DEBUG - 2012-09-06 16:42:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:42:00 --> Language Class Initialized
DEBUG - 2012-09-06 16:42:00 --> Loader Class Initialized
DEBUG - 2012-09-06 16:42:00 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:42:00 --> Controller Class Initialized
DEBUG - 2012-09-06 16:42:00 --> Model Class Initialized
DEBUG - 2012-09-06 16:42:00 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:42:00 --> Helper loaded: language_helper
DEBUG - 2012-09-06 16:42:00 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:42:00 --> Form Validation Class Initialized
DEBUG - 2012-09-06 16:42:00 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-06 16:42:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-06 16:42:00 --> Final output sent to browser
DEBUG - 2012-09-06 16:42:00 --> Total execution time: 0.1098
DEBUG - 2012-09-06 16:42:02 --> Config Class Initialized
DEBUG - 2012-09-06 16:42:02 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:42:02 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:42:02 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:42:02 --> URI Class Initialized
DEBUG - 2012-09-06 16:42:02 --> Router Class Initialized
DEBUG - 2012-09-06 16:42:02 --> Output Class Initialized
DEBUG - 2012-09-06 16:42:02 --> Security Class Initialized
DEBUG - 2012-09-06 16:42:02 --> Input Class Initialized
DEBUG - 2012-09-06 16:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:42:02 --> Language Class Initialized
DEBUG - 2012-09-06 16:42:02 --> Loader Class Initialized
DEBUG - 2012-09-06 16:42:02 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:42:02 --> Controller Class Initialized
DEBUG - 2012-09-06 16:42:02 --> Model Class Initialized
DEBUG - 2012-09-06 16:42:02 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:42:02 --> Helper loaded: language_helper
DEBUG - 2012-09-06 16:42:02 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:42:02 --> Form Validation Class Initialized
DEBUG - 2012-09-06 16:42:02 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-06 16:42:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-06 16:42:02 --> Final output sent to browser
DEBUG - 2012-09-06 16:42:02 --> Total execution time: 0.0433
DEBUG - 2012-09-06 16:42:14 --> Config Class Initialized
DEBUG - 2012-09-06 16:42:14 --> Hooks Class Initialized
DEBUG - 2012-09-06 16:42:14 --> Utf8 Class Initialized
DEBUG - 2012-09-06 16:42:14 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 16:42:14 --> URI Class Initialized
DEBUG - 2012-09-06 16:42:14 --> Router Class Initialized
DEBUG - 2012-09-06 16:42:14 --> Output Class Initialized
DEBUG - 2012-09-06 16:42:14 --> Security Class Initialized
DEBUG - 2012-09-06 16:42:14 --> Input Class Initialized
DEBUG - 2012-09-06 16:42:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 16:42:14 --> Language Class Initialized
DEBUG - 2012-09-06 16:42:14 --> Loader Class Initialized
DEBUG - 2012-09-06 16:42:14 --> Helper loaded: url_helper
DEBUG - 2012-09-06 16:42:14 --> Controller Class Initialized
DEBUG - 2012-09-06 16:42:14 --> Model Class Initialized
DEBUG - 2012-09-06 16:42:14 --> Database Driver Class Initialized
DEBUG - 2012-09-06 16:42:14 --> Helper loaded: form_helper
DEBUG - 2012-09-06 16:42:14 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 16:42:14 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 16:42:14 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 16:42:14 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 16:42:14 --> Final output sent to browser
DEBUG - 2012-09-06 16:42:14 --> Total execution time: 0.0467
DEBUG - 2012-09-06 18:48:40 --> Config Class Initialized
DEBUG - 2012-09-06 18:48:40 --> Hooks Class Initialized
DEBUG - 2012-09-06 18:48:40 --> Utf8 Class Initialized
DEBUG - 2012-09-06 18:48:40 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 18:48:40 --> URI Class Initialized
DEBUG - 2012-09-06 18:48:40 --> Router Class Initialized
DEBUG - 2012-09-06 18:48:40 --> Output Class Initialized
DEBUG - 2012-09-06 18:48:40 --> Security Class Initialized
DEBUG - 2012-09-06 18:48:40 --> Input Class Initialized
DEBUG - 2012-09-06 18:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 18:48:40 --> Language Class Initialized
DEBUG - 2012-09-06 18:48:40 --> Loader Class Initialized
DEBUG - 2012-09-06 18:48:40 --> Helper loaded: url_helper
DEBUG - 2012-09-06 18:48:40 --> Controller Class Initialized
DEBUG - 2012-09-06 18:48:40 --> Model Class Initialized
DEBUG - 2012-09-06 18:48:40 --> Database Driver Class Initialized
ERROR - 2012-09-06 18:48:40 --> 404 Page Not Found --> pricing/mounts
DEBUG - 2012-09-06 19:12:35 --> Config Class Initialized
DEBUG - 2012-09-06 19:12:35 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:12:35 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:12:35 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:12:35 --> URI Class Initialized
DEBUG - 2012-09-06 19:12:35 --> Router Class Initialized
DEBUG - 2012-09-06 19:12:35 --> Output Class Initialized
DEBUG - 2012-09-06 19:12:35 --> Security Class Initialized
DEBUG - 2012-09-06 19:12:35 --> Input Class Initialized
DEBUG - 2012-09-06 19:12:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 19:12:35 --> Language Class Initialized
DEBUG - 2012-09-06 19:12:35 --> Loader Class Initialized
DEBUG - 2012-09-06 19:12:35 --> Helper loaded: url_helper
DEBUG - 2012-09-06 19:12:35 --> Controller Class Initialized
DEBUG - 2012-09-06 19:12:35 --> Model Class Initialized
DEBUG - 2012-09-06 19:12:35 --> Database Driver Class Initialized
DEBUG - 2012-09-06 19:12:35 --> Final output sent to browser
DEBUG - 2012-09-06 19:12:35 --> Total execution time: 0.1106
DEBUG - 2012-09-06 19:17:12 --> Config Class Initialized
DEBUG - 2012-09-06 19:17:12 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:17:12 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:17:12 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:17:12 --> URI Class Initialized
DEBUG - 2012-09-06 19:17:12 --> Router Class Initialized
DEBUG - 2012-09-06 19:17:12 --> Output Class Initialized
DEBUG - 2012-09-06 19:17:12 --> Security Class Initialized
DEBUG - 2012-09-06 19:17:12 --> Input Class Initialized
DEBUG - 2012-09-06 19:17:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 19:17:12 --> Language Class Initialized
DEBUG - 2012-09-06 19:17:12 --> Loader Class Initialized
DEBUG - 2012-09-06 19:17:12 --> Helper loaded: url_helper
DEBUG - 2012-09-06 19:17:12 --> Controller Class Initialized
DEBUG - 2012-09-06 19:17:12 --> Model Class Initialized
DEBUG - 2012-09-06 19:17:12 --> Database Driver Class Initialized
DEBUG - 2012-09-06 19:17:12 --> Helper loaded: form_helper
DEBUG - 2012-09-06 19:17:12 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 19:17:12 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 19:17:12 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 19:17:12 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 19:17:12 --> Final output sent to browser
DEBUG - 2012-09-06 19:17:12 --> Total execution time: 0.1068
DEBUG - 2012-09-06 19:17:13 --> Config Class Initialized
DEBUG - 2012-09-06 19:17:13 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:17:13 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:17:13 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:17:13 --> URI Class Initialized
DEBUG - 2012-09-06 19:17:13 --> Router Class Initialized
ERROR - 2012-09-06 19:17:13 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 19:17:13 --> Config Class Initialized
DEBUG - 2012-09-06 19:17:13 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:17:13 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:17:13 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:17:13 --> URI Class Initialized
DEBUG - 2012-09-06 19:17:13 --> Router Class Initialized
ERROR - 2012-09-06 19:17:13 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 19:17:13 --> Config Class Initialized
DEBUG - 2012-09-06 19:17:13 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:17:13 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:17:13 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:17:13 --> URI Class Initialized
DEBUG - 2012-09-06 19:17:13 --> Router Class Initialized
ERROR - 2012-09-06 19:17:13 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 19:37:26 --> Config Class Initialized
DEBUG - 2012-09-06 19:37:26 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:37:26 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:37:26 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:37:26 --> URI Class Initialized
DEBUG - 2012-09-06 19:37:26 --> Router Class Initialized
DEBUG - 2012-09-06 19:37:26 --> Output Class Initialized
DEBUG - 2012-09-06 19:37:26 --> Security Class Initialized
DEBUG - 2012-09-06 19:37:26 --> Input Class Initialized
DEBUG - 2012-09-06 19:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 19:37:26 --> Language Class Initialized
DEBUG - 2012-09-06 19:37:26 --> Loader Class Initialized
DEBUG - 2012-09-06 19:37:26 --> Helper loaded: url_helper
DEBUG - 2012-09-06 19:37:26 --> Controller Class Initialized
DEBUG - 2012-09-06 19:37:26 --> Model Class Initialized
DEBUG - 2012-09-06 19:37:26 --> Database Driver Class Initialized
DEBUG - 2012-09-06 19:37:26 --> Helper loaded: form_helper
DEBUG - 2012-09-06 19:37:26 --> Helper loaded: html_helper
DEBUG - 2012-09-06 19:37:26 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-09-06 19:37:26 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-09-06 19:37:26 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-09-06 19:37:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-09-06 19:37:26 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 64
ERROR - 2012-09-06 19:37:26 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-09-06 19:37:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-09-06 19:37:26 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-09-06 19:37:26 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-09-06 19:37:26 --> Final output sent to browser
DEBUG - 2012-09-06 19:37:26 --> Total execution time: 0.1291
DEBUG - 2012-09-06 19:38:26 --> Config Class Initialized
DEBUG - 2012-09-06 19:38:26 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:38:26 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:38:26 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:38:26 --> URI Class Initialized
DEBUG - 2012-09-06 19:38:26 --> Router Class Initialized
DEBUG - 2012-09-06 19:38:26 --> Output Class Initialized
DEBUG - 2012-09-06 19:38:26 --> Security Class Initialized
DEBUG - 2012-09-06 19:38:26 --> Input Class Initialized
DEBUG - 2012-09-06 19:38:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 19:38:26 --> Language Class Initialized
DEBUG - 2012-09-06 19:38:26 --> Loader Class Initialized
DEBUG - 2012-09-06 19:38:26 --> Helper loaded: url_helper
DEBUG - 2012-09-06 19:38:26 --> Controller Class Initialized
DEBUG - 2012-09-06 19:38:26 --> Model Class Initialized
DEBUG - 2012-09-06 19:38:26 --> Database Driver Class Initialized
DEBUG - 2012-09-06 19:38:26 --> Helper loaded: form_helper
DEBUG - 2012-09-06 19:38:26 --> Helper loaded: html_helper
DEBUG - 2012-09-06 19:38:26 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-09-06 19:38:26 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-09-06 19:38:26 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-09-06 19:38:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-09-06 19:38:26 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 64
ERROR - 2012-09-06 19:38:26 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-09-06 19:38:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-09-06 19:38:26 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-09-06 19:38:26 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-09-06 19:38:26 --> Final output sent to browser
DEBUG - 2012-09-06 19:38:26 --> Total execution time: 0.0426
DEBUG - 2012-09-06 19:39:09 --> Config Class Initialized
DEBUG - 2012-09-06 19:39:09 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:39:09 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:39:09 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:39:09 --> URI Class Initialized
DEBUG - 2012-09-06 19:39:09 --> Router Class Initialized
DEBUG - 2012-09-06 19:39:09 --> Output Class Initialized
DEBUG - 2012-09-06 19:39:09 --> Security Class Initialized
DEBUG - 2012-09-06 19:39:09 --> Input Class Initialized
DEBUG - 2012-09-06 19:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 19:39:09 --> Language Class Initialized
DEBUG - 2012-09-06 19:39:09 --> Loader Class Initialized
DEBUG - 2012-09-06 19:39:09 --> Helper loaded: url_helper
DEBUG - 2012-09-06 19:39:09 --> Controller Class Initialized
DEBUG - 2012-09-06 19:39:09 --> Model Class Initialized
DEBUG - 2012-09-06 19:39:09 --> Database Driver Class Initialized
DEBUG - 2012-09-06 19:39:09 --> Helper loaded: form_helper
DEBUG - 2012-09-06 19:39:09 --> Helper loaded: html_helper
DEBUG - 2012-09-06 19:39:09 --> File loaded: application/views/test/templates/header.php
DEBUG - 2012-09-06 19:39:09 --> File loaded: application/views/test/templates/left_menu.php
ERROR - 2012-09-06 19:39:09 --> Severity: Notice  --> Undefined variable: salutations /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-09-06 19:39:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 15
ERROR - 2012-09-06 19:39:09 --> Severity: Notice  --> Undefined property: stdClass::$currency /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 64
ERROR - 2012-09-06 19:39:09 --> Severity: Notice  --> Undefined variable: currencies /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
ERROR - 2012-09-06 19:39:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/test/pages/business.php 65
DEBUG - 2012-09-06 19:39:09 --> File loaded: application/views/test/pages/business.php
DEBUG - 2012-09-06 19:39:09 --> File loaded: application/views/test/templates/footer.php
DEBUG - 2012-09-06 19:39:09 --> Final output sent to browser
DEBUG - 2012-09-06 19:39:09 --> Total execution time: 0.0448
DEBUG - 2012-09-06 19:39:12 --> Config Class Initialized
DEBUG - 2012-09-06 19:39:12 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:39:12 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:39:12 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:39:12 --> URI Class Initialized
DEBUG - 2012-09-06 19:39:12 --> Router Class Initialized
DEBUG - 2012-09-06 19:39:12 --> Output Class Initialized
DEBUG - 2012-09-06 19:39:12 --> Security Class Initialized
DEBUG - 2012-09-06 19:39:12 --> Input Class Initialized
DEBUG - 2012-09-06 19:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 19:39:12 --> Language Class Initialized
DEBUG - 2012-09-06 19:39:12 --> Loader Class Initialized
DEBUG - 2012-09-06 19:39:12 --> Helper loaded: url_helper
DEBUG - 2012-09-06 19:39:12 --> Controller Class Initialized
DEBUG - 2012-09-06 19:39:12 --> Model Class Initialized
DEBUG - 2012-09-06 19:39:12 --> Database Driver Class Initialized
DEBUG - 2012-09-06 19:39:12 --> Helper loaded: form_helper
DEBUG - 2012-09-06 19:39:12 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 19:39:12 --> File loaded: application/views/admin/templates/left_menu.php
ERROR - 2012-09-06 19:39:12 --> Severity: Notice  --> Undefined variable: mounts /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/mount_types.php 19
ERROR - 2012-09-06 19:39:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/mount_types.php 19
DEBUG - 2012-09-06 19:39:12 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 19:39:12 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 19:39:12 --> Final output sent to browser
DEBUG - 2012-09-06 19:39:12 --> Total execution time: 0.0377
DEBUG - 2012-09-06 19:40:58 --> Config Class Initialized
DEBUG - 2012-09-06 19:40:58 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:40:58 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:40:58 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:40:58 --> URI Class Initialized
DEBUG - 2012-09-06 19:40:58 --> Router Class Initialized
DEBUG - 2012-09-06 19:40:58 --> Output Class Initialized
DEBUG - 2012-09-06 19:40:58 --> Security Class Initialized
DEBUG - 2012-09-06 19:40:58 --> Input Class Initialized
DEBUG - 2012-09-06 19:40:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 19:40:58 --> Language Class Initialized
DEBUG - 2012-09-06 19:40:58 --> Loader Class Initialized
DEBUG - 2012-09-06 19:40:58 --> Helper loaded: url_helper
DEBUG - 2012-09-06 19:40:58 --> Controller Class Initialized
DEBUG - 2012-09-06 19:40:58 --> Model Class Initialized
DEBUG - 2012-09-06 19:40:58 --> Database Driver Class Initialized
DEBUG - 2012-09-06 19:40:58 --> Helper loaded: form_helper
DEBUG - 2012-09-06 19:40:58 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 19:40:58 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 19:40:58 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 19:40:58 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 19:40:58 --> Final output sent to browser
DEBUG - 2012-09-06 19:40:58 --> Total execution time: 0.0392
DEBUG - 2012-09-06 19:43:10 --> Config Class Initialized
DEBUG - 2012-09-06 19:43:10 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:43:10 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:43:10 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:43:10 --> URI Class Initialized
DEBUG - 2012-09-06 19:43:10 --> Router Class Initialized
DEBUG - 2012-09-06 19:43:10 --> Output Class Initialized
DEBUG - 2012-09-06 19:43:10 --> Security Class Initialized
DEBUG - 2012-09-06 19:43:10 --> Input Class Initialized
DEBUG - 2012-09-06 19:43:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 19:43:10 --> Language Class Initialized
DEBUG - 2012-09-06 19:43:10 --> Loader Class Initialized
DEBUG - 2012-09-06 19:43:10 --> Helper loaded: url_helper
DEBUG - 2012-09-06 19:43:10 --> Controller Class Initialized
DEBUG - 2012-09-06 19:43:10 --> Model Class Initialized
DEBUG - 2012-09-06 19:43:10 --> Database Driver Class Initialized
DEBUG - 2012-09-06 19:43:10 --> Helper loaded: form_helper
DEBUG - 2012-09-06 19:43:10 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 19:43:10 --> File loaded: application/views/admin/templates/left_menu.php
ERROR - 2012-09-06 19:43:10 --> Severity: Notice  --> Undefined variable: mounts /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/mount_types.php 19
ERROR - 2012-09-06 19:43:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/mount_types.php 19
DEBUG - 2012-09-06 19:43:10 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 19:43:10 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 19:43:10 --> Final output sent to browser
DEBUG - 2012-09-06 19:43:10 --> Total execution time: 0.0377
DEBUG - 2012-09-06 19:44:47 --> Config Class Initialized
DEBUG - 2012-09-06 19:44:47 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:44:47 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:44:47 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:44:47 --> URI Class Initialized
DEBUG - 2012-09-06 19:44:47 --> Router Class Initialized
DEBUG - 2012-09-06 19:44:47 --> Output Class Initialized
DEBUG - 2012-09-06 19:44:47 --> Security Class Initialized
DEBUG - 2012-09-06 19:44:47 --> Input Class Initialized
DEBUG - 2012-09-06 19:44:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 19:44:47 --> Language Class Initialized
DEBUG - 2012-09-06 19:44:47 --> Loader Class Initialized
DEBUG - 2012-09-06 19:44:47 --> Helper loaded: url_helper
DEBUG - 2012-09-06 19:44:47 --> Controller Class Initialized
DEBUG - 2012-09-06 19:44:47 --> Model Class Initialized
DEBUG - 2012-09-06 19:44:47 --> Database Driver Class Initialized
DEBUG - 2012-09-06 19:44:47 --> Helper loaded: form_helper
DEBUG - 2012-09-06 19:44:47 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 19:44:47 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 19:44:47 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 19:44:47 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 19:44:47 --> Final output sent to browser
DEBUG - 2012-09-06 19:44:47 --> Total execution time: 0.0499
DEBUG - 2012-09-06 19:50:55 --> Config Class Initialized
DEBUG - 2012-09-06 19:50:55 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:50:55 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:50:55 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:50:55 --> URI Class Initialized
DEBUG - 2012-09-06 19:50:55 --> Router Class Initialized
DEBUG - 2012-09-06 19:50:55 --> Output Class Initialized
DEBUG - 2012-09-06 19:50:55 --> Security Class Initialized
DEBUG - 2012-09-06 19:50:55 --> Input Class Initialized
DEBUG - 2012-09-06 19:50:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 19:50:55 --> Language Class Initialized
DEBUG - 2012-09-06 19:50:55 --> Loader Class Initialized
DEBUG - 2012-09-06 19:50:55 --> Helper loaded: url_helper
DEBUG - 2012-09-06 19:50:55 --> Controller Class Initialized
DEBUG - 2012-09-06 19:50:55 --> Model Class Initialized
DEBUG - 2012-09-06 19:50:55 --> Database Driver Class Initialized
DEBUG - 2012-09-06 19:50:55 --> Helper loaded: form_helper
DEBUG - 2012-09-06 19:50:55 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 19:50:55 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 19:50:55 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 19:50:55 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 19:50:55 --> Final output sent to browser
DEBUG - 2012-09-06 19:50:55 --> Total execution time: 0.0368
DEBUG - 2012-09-06 19:52:30 --> Config Class Initialized
DEBUG - 2012-09-06 19:52:30 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:52:30 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:52:30 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:52:30 --> URI Class Initialized
DEBUG - 2012-09-06 19:52:30 --> Router Class Initialized
DEBUG - 2012-09-06 19:52:30 --> Output Class Initialized
DEBUG - 2012-09-06 19:52:30 --> Security Class Initialized
DEBUG - 2012-09-06 19:52:30 --> Input Class Initialized
DEBUG - 2012-09-06 19:52:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 19:52:30 --> Language Class Initialized
DEBUG - 2012-09-06 19:52:30 --> Loader Class Initialized
DEBUG - 2012-09-06 19:52:30 --> Helper loaded: url_helper
DEBUG - 2012-09-06 19:52:30 --> Controller Class Initialized
DEBUG - 2012-09-06 19:52:30 --> Model Class Initialized
DEBUG - 2012-09-06 19:52:30 --> Database Driver Class Initialized
DEBUG - 2012-09-06 19:52:30 --> Helper loaded: form_helper
DEBUG - 2012-09-06 19:52:30 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 19:52:30 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 19:52:30 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 19:52:30 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 19:52:30 --> Final output sent to browser
DEBUG - 2012-09-06 19:52:30 --> Total execution time: 0.0370
DEBUG - 2012-09-06 19:52:32 --> Config Class Initialized
DEBUG - 2012-09-06 19:52:32 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:52:32 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:52:32 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:52:32 --> URI Class Initialized
DEBUG - 2012-09-06 19:52:32 --> Router Class Initialized
ERROR - 2012-09-06 19:52:32 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 19:52:32 --> Config Class Initialized
DEBUG - 2012-09-06 19:52:32 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:52:32 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:52:32 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:52:32 --> URI Class Initialized
DEBUG - 2012-09-06 19:52:32 --> Router Class Initialized
ERROR - 2012-09-06 19:52:32 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 19:52:32 --> Config Class Initialized
DEBUG - 2012-09-06 19:52:32 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:52:32 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:52:32 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:52:32 --> URI Class Initialized
DEBUG - 2012-09-06 19:52:32 --> Router Class Initialized
ERROR - 2012-09-06 19:52:32 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 19:54:42 --> Config Class Initialized
DEBUG - 2012-09-06 19:54:42 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:54:42 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:54:42 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:54:42 --> URI Class Initialized
DEBUG - 2012-09-06 19:54:42 --> Router Class Initialized
DEBUG - 2012-09-06 19:54:42 --> Output Class Initialized
DEBUG - 2012-09-06 19:54:42 --> Security Class Initialized
DEBUG - 2012-09-06 19:54:42 --> Input Class Initialized
DEBUG - 2012-09-06 19:54:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 19:54:42 --> Language Class Initialized
DEBUG - 2012-09-06 19:54:42 --> Loader Class Initialized
DEBUG - 2012-09-06 19:54:42 --> Helper loaded: url_helper
DEBUG - 2012-09-06 19:54:42 --> Controller Class Initialized
DEBUG - 2012-09-06 19:54:42 --> Model Class Initialized
DEBUG - 2012-09-06 19:54:42 --> Database Driver Class Initialized
DEBUG - 2012-09-06 19:54:42 --> Helper loaded: form_helper
DEBUG - 2012-09-06 19:54:42 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 19:54:42 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 19:54:42 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 19:54:42 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 19:54:42 --> Final output sent to browser
DEBUG - 2012-09-06 19:54:42 --> Total execution time: 0.0415
DEBUG - 2012-09-06 19:54:43 --> Config Class Initialized
DEBUG - 2012-09-06 19:54:43 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:54:43 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:54:43 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:54:43 --> URI Class Initialized
DEBUG - 2012-09-06 19:54:43 --> Router Class Initialized
ERROR - 2012-09-06 19:54:43 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 19:54:43 --> Config Class Initialized
DEBUG - 2012-09-06 19:54:43 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:54:43 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:54:43 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:54:43 --> URI Class Initialized
DEBUG - 2012-09-06 19:54:43 --> Router Class Initialized
ERROR - 2012-09-06 19:54:43 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 19:54:43 --> Config Class Initialized
DEBUG - 2012-09-06 19:54:43 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:54:43 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:54:43 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:54:43 --> URI Class Initialized
DEBUG - 2012-09-06 19:54:43 --> Router Class Initialized
ERROR - 2012-09-06 19:54:43 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 19:55:03 --> Config Class Initialized
DEBUG - 2012-09-06 19:55:03 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:55:03 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:55:03 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:55:03 --> URI Class Initialized
DEBUG - 2012-09-06 19:55:03 --> Router Class Initialized
DEBUG - 2012-09-06 19:55:03 --> Output Class Initialized
DEBUG - 2012-09-06 19:55:03 --> Security Class Initialized
DEBUG - 2012-09-06 19:55:03 --> Input Class Initialized
DEBUG - 2012-09-06 19:55:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 19:55:03 --> Language Class Initialized
DEBUG - 2012-09-06 19:55:03 --> Loader Class Initialized
DEBUG - 2012-09-06 19:55:03 --> Helper loaded: url_helper
DEBUG - 2012-09-06 19:55:03 --> Controller Class Initialized
DEBUG - 2012-09-06 19:55:03 --> Model Class Initialized
DEBUG - 2012-09-06 19:55:03 --> Database Driver Class Initialized
DEBUG - 2012-09-06 19:55:03 --> Helper loaded: form_helper
DEBUG - 2012-09-06 19:55:03 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 19:55:03 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 19:55:03 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 19:55:03 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 19:55:03 --> Final output sent to browser
DEBUG - 2012-09-06 19:55:03 --> Total execution time: 0.0402
DEBUG - 2012-09-06 19:55:10 --> Config Class Initialized
DEBUG - 2012-09-06 19:55:10 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:55:10 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:55:10 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:55:10 --> URI Class Initialized
DEBUG - 2012-09-06 19:55:10 --> Router Class Initialized
DEBUG - 2012-09-06 19:55:10 --> Output Class Initialized
DEBUG - 2012-09-06 19:55:10 --> Security Class Initialized
DEBUG - 2012-09-06 19:55:10 --> Input Class Initialized
DEBUG - 2012-09-06 19:55:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 19:55:10 --> Language Class Initialized
DEBUG - 2012-09-06 19:55:10 --> Loader Class Initialized
DEBUG - 2012-09-06 19:55:10 --> Helper loaded: url_helper
DEBUG - 2012-09-06 19:55:10 --> Controller Class Initialized
DEBUG - 2012-09-06 19:55:10 --> Model Class Initialized
DEBUG - 2012-09-06 19:55:10 --> Database Driver Class Initialized
DEBUG - 2012-09-06 19:55:10 --> Helper loaded: form_helper
DEBUG - 2012-09-06 19:55:10 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 19:55:10 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 19:55:10 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 19:55:10 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 19:55:10 --> Final output sent to browser
DEBUG - 2012-09-06 19:55:10 --> Total execution time: 0.0380
DEBUG - 2012-09-06 19:56:18 --> Config Class Initialized
DEBUG - 2012-09-06 19:56:18 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:56:18 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:56:18 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:56:18 --> URI Class Initialized
DEBUG - 2012-09-06 19:56:18 --> Router Class Initialized
DEBUG - 2012-09-06 19:56:18 --> Output Class Initialized
DEBUG - 2012-09-06 19:56:18 --> Security Class Initialized
DEBUG - 2012-09-06 19:56:18 --> Input Class Initialized
DEBUG - 2012-09-06 19:56:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 19:56:18 --> Language Class Initialized
DEBUG - 2012-09-06 19:56:18 --> Loader Class Initialized
DEBUG - 2012-09-06 19:56:18 --> Helper loaded: url_helper
DEBUG - 2012-09-06 19:56:18 --> Controller Class Initialized
DEBUG - 2012-09-06 19:56:18 --> Model Class Initialized
DEBUG - 2012-09-06 19:56:18 --> Database Driver Class Initialized
DEBUG - 2012-09-06 19:56:18 --> Helper loaded: form_helper
DEBUG - 2012-09-06 19:56:18 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 19:56:18 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 19:56:18 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 19:56:18 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 19:56:18 --> Final output sent to browser
DEBUG - 2012-09-06 19:56:18 --> Total execution time: 0.0369
DEBUG - 2012-09-06 19:56:19 --> Config Class Initialized
DEBUG - 2012-09-06 19:56:19 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:56:19 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:56:19 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:56:19 --> URI Class Initialized
DEBUG - 2012-09-06 19:56:19 --> Router Class Initialized
ERROR - 2012-09-06 19:56:19 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 19:56:19 --> Config Class Initialized
DEBUG - 2012-09-06 19:56:19 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:56:19 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:56:19 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:56:19 --> URI Class Initialized
DEBUG - 2012-09-06 19:56:19 --> Router Class Initialized
ERROR - 2012-09-06 19:56:19 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 19:56:19 --> Config Class Initialized
DEBUG - 2012-09-06 19:56:19 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:56:19 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:56:19 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:56:19 --> URI Class Initialized
DEBUG - 2012-09-06 19:56:19 --> Router Class Initialized
ERROR - 2012-09-06 19:56:19 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 19:56:53 --> Config Class Initialized
DEBUG - 2012-09-06 19:56:53 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:56:53 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:56:53 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:56:53 --> URI Class Initialized
DEBUG - 2012-09-06 19:56:53 --> Router Class Initialized
DEBUG - 2012-09-06 19:56:53 --> Output Class Initialized
DEBUG - 2012-09-06 19:56:53 --> Security Class Initialized
DEBUG - 2012-09-06 19:56:53 --> Input Class Initialized
DEBUG - 2012-09-06 19:56:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 19:56:53 --> Language Class Initialized
DEBUG - 2012-09-06 19:56:53 --> Loader Class Initialized
DEBUG - 2012-09-06 19:56:53 --> Helper loaded: url_helper
DEBUG - 2012-09-06 19:56:53 --> Controller Class Initialized
DEBUG - 2012-09-06 19:56:53 --> Model Class Initialized
DEBUG - 2012-09-06 19:56:53 --> Database Driver Class Initialized
DEBUG - 2012-09-06 19:56:53 --> Helper loaded: form_helper
DEBUG - 2012-09-06 19:56:53 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 19:56:53 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 19:56:53 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 19:56:53 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 19:56:53 --> Final output sent to browser
DEBUG - 2012-09-06 19:56:53 --> Total execution time: 0.0451
DEBUG - 2012-09-06 19:56:54 --> Config Class Initialized
DEBUG - 2012-09-06 19:56:54 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:56:54 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:56:54 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:56:54 --> URI Class Initialized
DEBUG - 2012-09-06 19:56:54 --> Router Class Initialized
ERROR - 2012-09-06 19:56:54 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 19:56:54 --> Config Class Initialized
DEBUG - 2012-09-06 19:56:54 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:56:54 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:56:54 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:56:54 --> URI Class Initialized
DEBUG - 2012-09-06 19:56:54 --> Router Class Initialized
ERROR - 2012-09-06 19:56:54 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 19:56:54 --> Config Class Initialized
DEBUG - 2012-09-06 19:56:54 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:56:54 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:56:54 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:56:54 --> URI Class Initialized
DEBUG - 2012-09-06 19:56:54 --> Router Class Initialized
ERROR - 2012-09-06 19:56:54 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 19:57:02 --> Config Class Initialized
DEBUG - 2012-09-06 19:57:02 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:57:02 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:57:02 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:57:02 --> URI Class Initialized
DEBUG - 2012-09-06 19:57:02 --> Router Class Initialized
DEBUG - 2012-09-06 19:57:02 --> Output Class Initialized
DEBUG - 2012-09-06 19:57:02 --> Security Class Initialized
DEBUG - 2012-09-06 19:57:02 --> Input Class Initialized
DEBUG - 2012-09-06 19:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 19:57:02 --> Language Class Initialized
DEBUG - 2012-09-06 19:57:02 --> Loader Class Initialized
DEBUG - 2012-09-06 19:57:02 --> Helper loaded: url_helper
DEBUG - 2012-09-06 19:57:02 --> Controller Class Initialized
DEBUG - 2012-09-06 19:57:02 --> Model Class Initialized
DEBUG - 2012-09-06 19:57:02 --> Database Driver Class Initialized
DEBUG - 2012-09-06 19:57:02 --> Helper loaded: form_helper
DEBUG - 2012-09-06 19:57:02 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 19:57:02 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 19:57:02 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 19:57:02 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 19:57:02 --> Final output sent to browser
DEBUG - 2012-09-06 19:57:02 --> Total execution time: 0.0386
DEBUG - 2012-09-06 19:57:07 --> Config Class Initialized
DEBUG - 2012-09-06 19:57:07 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:57:07 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:57:07 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:57:07 --> URI Class Initialized
DEBUG - 2012-09-06 19:57:07 --> Router Class Initialized
DEBUG - 2012-09-06 19:57:07 --> Output Class Initialized
DEBUG - 2012-09-06 19:57:07 --> Security Class Initialized
DEBUG - 2012-09-06 19:57:07 --> Input Class Initialized
DEBUG - 2012-09-06 19:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 19:57:07 --> Language Class Initialized
DEBUG - 2012-09-06 19:57:07 --> Loader Class Initialized
DEBUG - 2012-09-06 19:57:07 --> Helper loaded: url_helper
DEBUG - 2012-09-06 19:57:07 --> Controller Class Initialized
DEBUG - 2012-09-06 19:57:07 --> Model Class Initialized
DEBUG - 2012-09-06 19:57:07 --> Database Driver Class Initialized
DEBUG - 2012-09-06 19:57:07 --> Helper loaded: form_helper
DEBUG - 2012-09-06 19:57:07 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 19:57:07 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 19:57:07 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 19:57:07 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 19:57:07 --> Final output sent to browser
DEBUG - 2012-09-06 19:57:07 --> Total execution time: 0.0378
DEBUG - 2012-09-06 19:57:26 --> Config Class Initialized
DEBUG - 2012-09-06 19:57:26 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:57:26 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:57:26 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:57:26 --> URI Class Initialized
DEBUG - 2012-09-06 19:57:26 --> Router Class Initialized
DEBUG - 2012-09-06 19:57:26 --> Output Class Initialized
DEBUG - 2012-09-06 19:57:26 --> Security Class Initialized
DEBUG - 2012-09-06 19:57:26 --> Input Class Initialized
DEBUG - 2012-09-06 19:57:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 19:57:26 --> Language Class Initialized
DEBUG - 2012-09-06 19:57:26 --> Loader Class Initialized
DEBUG - 2012-09-06 19:57:26 --> Helper loaded: url_helper
DEBUG - 2012-09-06 19:57:26 --> Controller Class Initialized
DEBUG - 2012-09-06 19:57:26 --> Model Class Initialized
DEBUG - 2012-09-06 19:57:27 --> Database Driver Class Initialized
DEBUG - 2012-09-06 19:57:27 --> Helper loaded: form_helper
DEBUG - 2012-09-06 19:57:27 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 19:57:27 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 19:57:27 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 19:57:27 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 19:57:27 --> Final output sent to browser
DEBUG - 2012-09-06 19:57:27 --> Total execution time: 0.0384
DEBUG - 2012-09-06 19:59:00 --> Config Class Initialized
DEBUG - 2012-09-06 19:59:00 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:59:00 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:59:00 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:59:00 --> URI Class Initialized
DEBUG - 2012-09-06 19:59:00 --> Router Class Initialized
DEBUG - 2012-09-06 19:59:00 --> Output Class Initialized
DEBUG - 2012-09-06 19:59:00 --> Security Class Initialized
DEBUG - 2012-09-06 19:59:00 --> Input Class Initialized
DEBUG - 2012-09-06 19:59:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 19:59:00 --> Language Class Initialized
DEBUG - 2012-09-06 19:59:00 --> Loader Class Initialized
DEBUG - 2012-09-06 19:59:00 --> Helper loaded: url_helper
DEBUG - 2012-09-06 19:59:00 --> Controller Class Initialized
DEBUG - 2012-09-06 19:59:00 --> Model Class Initialized
DEBUG - 2012-09-06 19:59:00 --> Database Driver Class Initialized
DEBUG - 2012-09-06 19:59:00 --> Helper loaded: form_helper
DEBUG - 2012-09-06 19:59:00 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 19:59:00 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 19:59:00 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 19:59:00 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 19:59:00 --> Final output sent to browser
DEBUG - 2012-09-06 19:59:00 --> Total execution time: 0.0407
DEBUG - 2012-09-06 19:59:03 --> Config Class Initialized
DEBUG - 2012-09-06 19:59:03 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:59:03 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:59:03 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:59:03 --> URI Class Initialized
DEBUG - 2012-09-06 19:59:03 --> Router Class Initialized
DEBUG - 2012-09-06 19:59:03 --> Output Class Initialized
DEBUG - 2012-09-06 19:59:03 --> Security Class Initialized
DEBUG - 2012-09-06 19:59:03 --> Input Class Initialized
DEBUG - 2012-09-06 19:59:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 19:59:03 --> Language Class Initialized
DEBUG - 2012-09-06 19:59:03 --> Loader Class Initialized
DEBUG - 2012-09-06 19:59:03 --> Helper loaded: url_helper
DEBUG - 2012-09-06 19:59:03 --> Controller Class Initialized
DEBUG - 2012-09-06 19:59:03 --> Model Class Initialized
DEBUG - 2012-09-06 19:59:03 --> Database Driver Class Initialized
DEBUG - 2012-09-06 19:59:03 --> Helper loaded: form_helper
DEBUG - 2012-09-06 19:59:03 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 19:59:03 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 19:59:03 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 19:59:03 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 19:59:03 --> Final output sent to browser
DEBUG - 2012-09-06 19:59:03 --> Total execution time: 0.0384
DEBUG - 2012-09-06 19:59:09 --> Config Class Initialized
DEBUG - 2012-09-06 19:59:09 --> Hooks Class Initialized
DEBUG - 2012-09-06 19:59:09 --> Utf8 Class Initialized
DEBUG - 2012-09-06 19:59:09 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 19:59:09 --> URI Class Initialized
DEBUG - 2012-09-06 19:59:09 --> Router Class Initialized
DEBUG - 2012-09-06 19:59:09 --> Output Class Initialized
DEBUG - 2012-09-06 19:59:09 --> Security Class Initialized
DEBUG - 2012-09-06 19:59:09 --> Input Class Initialized
DEBUG - 2012-09-06 19:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 19:59:09 --> Language Class Initialized
DEBUG - 2012-09-06 19:59:09 --> Loader Class Initialized
DEBUG - 2012-09-06 19:59:09 --> Helper loaded: url_helper
DEBUG - 2012-09-06 19:59:09 --> Controller Class Initialized
DEBUG - 2012-09-06 19:59:09 --> Model Class Initialized
DEBUG - 2012-09-06 19:59:09 --> Database Driver Class Initialized
DEBUG - 2012-09-06 19:59:09 --> Helper loaded: form_helper
DEBUG - 2012-09-06 19:59:09 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 19:59:09 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 19:59:09 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 19:59:09 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 19:59:09 --> Final output sent to browser
DEBUG - 2012-09-06 19:59:09 --> Total execution time: 0.0371
DEBUG - 2012-09-06 20:42:54 --> Config Class Initialized
DEBUG - 2012-09-06 20:42:54 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:42:54 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:42:54 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:42:54 --> URI Class Initialized
DEBUG - 2012-09-06 20:42:54 --> Router Class Initialized
DEBUG - 2012-09-06 20:42:54 --> Output Class Initialized
DEBUG - 2012-09-06 20:42:54 --> Security Class Initialized
DEBUG - 2012-09-06 20:42:54 --> Input Class Initialized
DEBUG - 2012-09-06 20:42:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 20:42:54 --> Language Class Initialized
DEBUG - 2012-09-06 20:42:54 --> Loader Class Initialized
DEBUG - 2012-09-06 20:42:54 --> Helper loaded: url_helper
DEBUG - 2012-09-06 20:42:54 --> Controller Class Initialized
DEBUG - 2012-09-06 20:42:54 --> Model Class Initialized
DEBUG - 2012-09-06 20:42:54 --> Database Driver Class Initialized
DEBUG - 2012-09-06 20:42:54 --> Helper loaded: form_helper
DEBUG - 2012-09-06 20:42:54 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 20:42:54 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 20:42:54 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 20:42:54 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 20:42:54 --> Final output sent to browser
DEBUG - 2012-09-06 20:42:54 --> Total execution time: 0.0395
DEBUG - 2012-09-06 20:42:55 --> Config Class Initialized
DEBUG - 2012-09-06 20:42:55 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:42:55 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:42:55 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:42:55 --> URI Class Initialized
DEBUG - 2012-09-06 20:42:55 --> Router Class Initialized
ERROR - 2012-09-06 20:42:55 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 20:42:55 --> Config Class Initialized
DEBUG - 2012-09-06 20:42:55 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:42:55 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:42:55 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:42:55 --> URI Class Initialized
DEBUG - 2012-09-06 20:42:55 --> Router Class Initialized
ERROR - 2012-09-06 20:42:55 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 20:42:55 --> Config Class Initialized
DEBUG - 2012-09-06 20:42:55 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:42:55 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:42:55 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:42:55 --> URI Class Initialized
DEBUG - 2012-09-06 20:42:55 --> Router Class Initialized
ERROR - 2012-09-06 20:42:55 --> 404 Page Not Found --> css
DEBUG - 2012-09-06 20:43:40 --> Config Class Initialized
DEBUG - 2012-09-06 20:43:40 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:43:40 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:43:40 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:43:40 --> URI Class Initialized
DEBUG - 2012-09-06 20:43:40 --> Router Class Initialized
DEBUG - 2012-09-06 20:43:40 --> Output Class Initialized
DEBUG - 2012-09-06 20:43:40 --> Security Class Initialized
DEBUG - 2012-09-06 20:43:40 --> Input Class Initialized
DEBUG - 2012-09-06 20:43:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 20:43:40 --> Language Class Initialized
DEBUG - 2012-09-06 20:43:40 --> Loader Class Initialized
DEBUG - 2012-09-06 20:43:40 --> Helper loaded: url_helper
DEBUG - 2012-09-06 20:43:40 --> Controller Class Initialized
DEBUG - 2012-09-06 20:43:40 --> Model Class Initialized
DEBUG - 2012-09-06 20:43:40 --> Database Driver Class Initialized
DEBUG - 2012-09-06 20:43:40 --> Final output sent to browser
DEBUG - 2012-09-06 20:43:40 --> Total execution time: 0.1294
DEBUG - 2012-09-06 20:47:25 --> Config Class Initialized
DEBUG - 2012-09-06 20:47:25 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:47:25 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:47:25 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:47:25 --> URI Class Initialized
DEBUG - 2012-09-06 20:47:25 --> Router Class Initialized
DEBUG - 2012-09-06 20:47:25 --> Output Class Initialized
DEBUG - 2012-09-06 20:47:25 --> Security Class Initialized
DEBUG - 2012-09-06 20:47:25 --> Input Class Initialized
DEBUG - 2012-09-06 20:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 20:47:25 --> Language Class Initialized
DEBUG - 2012-09-06 20:47:25 --> Loader Class Initialized
DEBUG - 2012-09-06 20:47:25 --> Helper loaded: url_helper
DEBUG - 2012-09-06 20:47:25 --> Controller Class Initialized
DEBUG - 2012-09-06 20:47:25 --> Model Class Initialized
DEBUG - 2012-09-06 20:47:25 --> Database Driver Class Initialized
DEBUG - 2012-09-06 20:47:25 --> Helper loaded: form_helper
DEBUG - 2012-09-06 20:47:25 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 20:47:25 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 20:47:25 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 20:47:25 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 20:47:25 --> Final output sent to browser
DEBUG - 2012-09-06 20:47:25 --> Total execution time: 0.0414
DEBUG - 2012-09-06 20:47:31 --> Config Class Initialized
DEBUG - 2012-09-06 20:47:31 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:47:31 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:47:31 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:47:31 --> URI Class Initialized
DEBUG - 2012-09-06 20:47:31 --> Router Class Initialized
DEBUG - 2012-09-06 20:47:31 --> Output Class Initialized
DEBUG - 2012-09-06 20:47:31 --> Security Class Initialized
DEBUG - 2012-09-06 20:47:31 --> Input Class Initialized
DEBUG - 2012-09-06 20:47:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 20:47:31 --> Language Class Initialized
DEBUG - 2012-09-06 20:47:31 --> Loader Class Initialized
DEBUG - 2012-09-06 20:47:31 --> Helper loaded: url_helper
DEBUG - 2012-09-06 20:47:31 --> Controller Class Initialized
DEBUG - 2012-09-06 20:47:31 --> Model Class Initialized
DEBUG - 2012-09-06 20:47:31 --> Database Driver Class Initialized
ERROR - 2012-09-06 20:47:31 --> 404 Page Not Found --> pricing/ajax_mount_update
DEBUG - 2012-09-06 20:47:39 --> Config Class Initialized
DEBUG - 2012-09-06 20:47:39 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:47:39 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:47:39 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:47:39 --> URI Class Initialized
DEBUG - 2012-09-06 20:47:39 --> Router Class Initialized
DEBUG - 2012-09-06 20:47:39 --> Output Class Initialized
DEBUG - 2012-09-06 20:47:39 --> Security Class Initialized
DEBUG - 2012-09-06 20:47:39 --> Input Class Initialized
DEBUG - 2012-09-06 20:47:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 20:47:39 --> Language Class Initialized
DEBUG - 2012-09-06 20:47:39 --> Loader Class Initialized
DEBUG - 2012-09-06 20:47:39 --> Helper loaded: url_helper
DEBUG - 2012-09-06 20:47:39 --> Controller Class Initialized
DEBUG - 2012-09-06 20:47:39 --> Model Class Initialized
DEBUG - 2012-09-06 20:47:39 --> Database Driver Class Initialized
DEBUG - 2012-09-06 20:47:39 --> Final output sent to browser
DEBUG - 2012-09-06 20:47:39 --> Total execution time: 0.0866
DEBUG - 2012-09-06 20:48:40 --> Config Class Initialized
DEBUG - 2012-09-06 20:48:40 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:48:40 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:48:40 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:48:40 --> URI Class Initialized
DEBUG - 2012-09-06 20:48:40 --> Router Class Initialized
DEBUG - 2012-09-06 20:48:40 --> Output Class Initialized
DEBUG - 2012-09-06 20:48:40 --> Security Class Initialized
DEBUG - 2012-09-06 20:48:40 --> Input Class Initialized
DEBUG - 2012-09-06 20:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 20:48:40 --> Language Class Initialized
DEBUG - 2012-09-06 20:48:40 --> Loader Class Initialized
DEBUG - 2012-09-06 20:48:40 --> Helper loaded: url_helper
DEBUG - 2012-09-06 20:48:40 --> Controller Class Initialized
DEBUG - 2012-09-06 20:48:40 --> Model Class Initialized
DEBUG - 2012-09-06 20:48:40 --> Database Driver Class Initialized
DEBUG - 2012-09-06 20:48:40 --> Helper loaded: form_helper
DEBUG - 2012-09-06 20:48:40 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 20:48:40 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 20:48:40 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 20:48:40 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 20:48:40 --> Final output sent to browser
DEBUG - 2012-09-06 20:48:40 --> Total execution time: 0.0500
DEBUG - 2012-09-06 20:48:43 --> Config Class Initialized
DEBUG - 2012-09-06 20:48:43 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:48:43 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:48:43 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:48:43 --> URI Class Initialized
DEBUG - 2012-09-06 20:48:43 --> Router Class Initialized
DEBUG - 2012-09-06 20:48:43 --> Output Class Initialized
DEBUG - 2012-09-06 20:48:43 --> Security Class Initialized
DEBUG - 2012-09-06 20:48:43 --> Input Class Initialized
DEBUG - 2012-09-06 20:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 20:48:43 --> Language Class Initialized
DEBUG - 2012-09-06 20:48:43 --> Loader Class Initialized
DEBUG - 2012-09-06 20:48:43 --> Helper loaded: url_helper
DEBUG - 2012-09-06 20:48:43 --> Controller Class Initialized
DEBUG - 2012-09-06 20:48:43 --> Model Class Initialized
DEBUG - 2012-09-06 20:48:43 --> Database Driver Class Initialized
DEBUG - 2012-09-06 20:48:43 --> Final output sent to browser
DEBUG - 2012-09-06 20:48:43 --> Total execution time: 0.1268
DEBUG - 2012-09-06 20:50:56 --> Config Class Initialized
DEBUG - 2012-09-06 20:50:56 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:50:56 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:50:56 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:50:56 --> URI Class Initialized
DEBUG - 2012-09-06 20:50:56 --> Router Class Initialized
DEBUG - 2012-09-06 20:50:56 --> Output Class Initialized
DEBUG - 2012-09-06 20:50:56 --> Security Class Initialized
DEBUG - 2012-09-06 20:50:56 --> Input Class Initialized
DEBUG - 2012-09-06 20:50:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 20:50:56 --> Language Class Initialized
DEBUG - 2012-09-06 20:50:56 --> Loader Class Initialized
DEBUG - 2012-09-06 20:50:56 --> Helper loaded: url_helper
DEBUG - 2012-09-06 20:50:56 --> Controller Class Initialized
DEBUG - 2012-09-06 20:50:56 --> Model Class Initialized
DEBUG - 2012-09-06 20:50:56 --> Database Driver Class Initialized
DEBUG - 2012-09-06 20:50:56 --> Helper loaded: form_helper
DEBUG - 2012-09-06 20:50:56 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 20:50:56 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 20:50:56 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 20:50:56 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 20:50:56 --> Final output sent to browser
DEBUG - 2012-09-06 20:50:56 --> Total execution time: 0.0371
DEBUG - 2012-09-06 20:51:05 --> Config Class Initialized
DEBUG - 2012-09-06 20:51:05 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:51:05 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:51:05 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:51:05 --> URI Class Initialized
DEBUG - 2012-09-06 20:51:05 --> Router Class Initialized
DEBUG - 2012-09-06 20:51:05 --> Output Class Initialized
DEBUG - 2012-09-06 20:51:05 --> Security Class Initialized
DEBUG - 2012-09-06 20:51:05 --> Input Class Initialized
DEBUG - 2012-09-06 20:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 20:51:05 --> Language Class Initialized
DEBUG - 2012-09-06 20:51:05 --> Loader Class Initialized
DEBUG - 2012-09-06 20:51:05 --> Helper loaded: url_helper
DEBUG - 2012-09-06 20:51:05 --> Controller Class Initialized
DEBUG - 2012-09-06 20:51:05 --> Model Class Initialized
DEBUG - 2012-09-06 20:51:05 --> Database Driver Class Initialized
DEBUG - 2012-09-06 20:51:05 --> Final output sent to browser
DEBUG - 2012-09-06 20:51:05 --> Total execution time: 0.1382
DEBUG - 2012-09-06 20:52:07 --> Config Class Initialized
DEBUG - 2012-09-06 20:52:07 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:52:07 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:52:07 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:52:07 --> URI Class Initialized
DEBUG - 2012-09-06 20:52:07 --> Router Class Initialized
DEBUG - 2012-09-06 20:52:07 --> Output Class Initialized
DEBUG - 2012-09-06 20:52:07 --> Security Class Initialized
DEBUG - 2012-09-06 20:52:07 --> Input Class Initialized
DEBUG - 2012-09-06 20:52:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 20:52:07 --> Language Class Initialized
DEBUG - 2012-09-06 20:52:07 --> Loader Class Initialized
DEBUG - 2012-09-06 20:52:07 --> Helper loaded: url_helper
DEBUG - 2012-09-06 20:52:07 --> Controller Class Initialized
DEBUG - 2012-09-06 20:52:07 --> Model Class Initialized
DEBUG - 2012-09-06 20:52:07 --> Database Driver Class Initialized
DEBUG - 2012-09-06 20:52:07 --> Helper loaded: form_helper
DEBUG - 2012-09-06 20:52:07 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 20:52:07 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 20:52:07 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 20:52:07 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 20:52:07 --> Final output sent to browser
DEBUG - 2012-09-06 20:52:07 --> Total execution time: 0.0371
DEBUG - 2012-09-06 20:52:15 --> Config Class Initialized
DEBUG - 2012-09-06 20:52:15 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:52:15 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:52:15 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:52:15 --> URI Class Initialized
DEBUG - 2012-09-06 20:52:15 --> Router Class Initialized
DEBUG - 2012-09-06 20:52:15 --> Output Class Initialized
DEBUG - 2012-09-06 20:52:15 --> Security Class Initialized
DEBUG - 2012-09-06 20:52:15 --> Input Class Initialized
DEBUG - 2012-09-06 20:52:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 20:52:15 --> Language Class Initialized
DEBUG - 2012-09-06 20:52:15 --> Loader Class Initialized
DEBUG - 2012-09-06 20:52:15 --> Helper loaded: url_helper
DEBUG - 2012-09-06 20:52:15 --> Controller Class Initialized
DEBUG - 2012-09-06 20:52:15 --> Model Class Initialized
DEBUG - 2012-09-06 20:52:15 --> Database Driver Class Initialized
DEBUG - 2012-09-06 20:52:15 --> Final output sent to browser
DEBUG - 2012-09-06 20:52:15 --> Total execution time: 0.2019
DEBUG - 2012-09-06 20:54:54 --> Config Class Initialized
DEBUG - 2012-09-06 20:54:54 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:54:54 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:54:54 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:54:54 --> URI Class Initialized
DEBUG - 2012-09-06 20:54:54 --> Router Class Initialized
DEBUG - 2012-09-06 20:54:54 --> Output Class Initialized
DEBUG - 2012-09-06 20:54:54 --> Security Class Initialized
DEBUG - 2012-09-06 20:54:54 --> Input Class Initialized
DEBUG - 2012-09-06 20:54:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 20:54:54 --> Language Class Initialized
DEBUG - 2012-09-06 20:54:54 --> Loader Class Initialized
DEBUG - 2012-09-06 20:54:54 --> Helper loaded: url_helper
DEBUG - 2012-09-06 20:54:54 --> Controller Class Initialized
DEBUG - 2012-09-06 20:54:54 --> Model Class Initialized
DEBUG - 2012-09-06 20:54:54 --> Database Driver Class Initialized
DEBUG - 2012-09-06 20:54:54 --> Helper loaded: form_helper
DEBUG - 2012-09-06 20:54:54 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 20:54:54 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 20:54:54 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 20:54:54 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 20:54:54 --> Final output sent to browser
DEBUG - 2012-09-06 20:54:54 --> Total execution time: 0.0376
DEBUG - 2012-09-06 20:55:01 --> Config Class Initialized
DEBUG - 2012-09-06 20:55:01 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:55:01 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:55:01 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:55:01 --> URI Class Initialized
DEBUG - 2012-09-06 20:55:01 --> Router Class Initialized
DEBUG - 2012-09-06 20:55:01 --> Output Class Initialized
DEBUG - 2012-09-06 20:55:01 --> Security Class Initialized
DEBUG - 2012-09-06 20:55:01 --> Input Class Initialized
DEBUG - 2012-09-06 20:55:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 20:55:01 --> Language Class Initialized
DEBUG - 2012-09-06 20:55:01 --> Loader Class Initialized
DEBUG - 2012-09-06 20:55:01 --> Helper loaded: url_helper
DEBUG - 2012-09-06 20:55:01 --> Controller Class Initialized
DEBUG - 2012-09-06 20:55:01 --> Model Class Initialized
DEBUG - 2012-09-06 20:55:01 --> Database Driver Class Initialized
DEBUG - 2012-09-06 20:55:01 --> Final output sent to browser
DEBUG - 2012-09-06 20:55:01 --> Total execution time: 0.1322
DEBUG - 2012-09-06 20:55:44 --> Config Class Initialized
DEBUG - 2012-09-06 20:55:44 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:55:44 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:55:44 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:55:44 --> URI Class Initialized
DEBUG - 2012-09-06 20:55:44 --> Router Class Initialized
DEBUG - 2012-09-06 20:55:44 --> Output Class Initialized
DEBUG - 2012-09-06 20:55:44 --> Security Class Initialized
DEBUG - 2012-09-06 20:55:44 --> Input Class Initialized
DEBUG - 2012-09-06 20:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 20:55:44 --> Language Class Initialized
DEBUG - 2012-09-06 20:55:44 --> Loader Class Initialized
DEBUG - 2012-09-06 20:55:44 --> Helper loaded: url_helper
DEBUG - 2012-09-06 20:55:44 --> Controller Class Initialized
DEBUG - 2012-09-06 20:55:44 --> Model Class Initialized
DEBUG - 2012-09-06 20:55:44 --> Database Driver Class Initialized
DEBUG - 2012-09-06 20:55:44 --> Helper loaded: form_helper
DEBUG - 2012-09-06 20:55:44 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 20:55:44 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 20:55:44 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 20:55:44 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 20:55:44 --> Final output sent to browser
DEBUG - 2012-09-06 20:55:44 --> Total execution time: 0.0375
DEBUG - 2012-09-06 20:55:47 --> Config Class Initialized
DEBUG - 2012-09-06 20:55:47 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:55:47 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:55:47 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:55:47 --> URI Class Initialized
DEBUG - 2012-09-06 20:55:47 --> Router Class Initialized
DEBUG - 2012-09-06 20:55:47 --> Output Class Initialized
DEBUG - 2012-09-06 20:55:47 --> Security Class Initialized
DEBUG - 2012-09-06 20:55:47 --> Input Class Initialized
DEBUG - 2012-09-06 20:55:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 20:55:47 --> Language Class Initialized
DEBUG - 2012-09-06 20:55:47 --> Loader Class Initialized
DEBUG - 2012-09-06 20:55:47 --> Helper loaded: url_helper
DEBUG - 2012-09-06 20:55:47 --> Controller Class Initialized
DEBUG - 2012-09-06 20:55:47 --> Model Class Initialized
DEBUG - 2012-09-06 20:55:48 --> Database Driver Class Initialized
DEBUG - 2012-09-06 20:55:48 --> Helper loaded: form_helper
DEBUG - 2012-09-06 20:55:48 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 20:55:48 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 20:55:48 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 20:55:48 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 20:55:48 --> Final output sent to browser
DEBUG - 2012-09-06 20:55:48 --> Total execution time: 0.0382
DEBUG - 2012-09-06 20:55:59 --> Config Class Initialized
DEBUG - 2012-09-06 20:55:59 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:55:59 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:55:59 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:55:59 --> URI Class Initialized
DEBUG - 2012-09-06 20:55:59 --> Router Class Initialized
DEBUG - 2012-09-06 20:55:59 --> Output Class Initialized
DEBUG - 2012-09-06 20:55:59 --> Security Class Initialized
DEBUG - 2012-09-06 20:55:59 --> Input Class Initialized
DEBUG - 2012-09-06 20:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 20:55:59 --> Language Class Initialized
DEBUG - 2012-09-06 20:55:59 --> Loader Class Initialized
DEBUG - 2012-09-06 20:55:59 --> Helper loaded: url_helper
DEBUG - 2012-09-06 20:55:59 --> Controller Class Initialized
DEBUG - 2012-09-06 20:55:59 --> Model Class Initialized
DEBUG - 2012-09-06 20:55:59 --> Database Driver Class Initialized
DEBUG - 2012-09-06 20:55:59 --> Final output sent to browser
DEBUG - 2012-09-06 20:55:59 --> Total execution time: 0.0905
DEBUG - 2012-09-06 20:56:09 --> Config Class Initialized
DEBUG - 2012-09-06 20:56:09 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:56:09 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:56:09 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:56:09 --> URI Class Initialized
DEBUG - 2012-09-06 20:56:09 --> Router Class Initialized
DEBUG - 2012-09-06 20:56:09 --> Output Class Initialized
DEBUG - 2012-09-06 20:56:09 --> Security Class Initialized
DEBUG - 2012-09-06 20:56:09 --> Input Class Initialized
DEBUG - 2012-09-06 20:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 20:56:09 --> Language Class Initialized
DEBUG - 2012-09-06 20:56:09 --> Loader Class Initialized
DEBUG - 2012-09-06 20:56:09 --> Helper loaded: url_helper
DEBUG - 2012-09-06 20:56:09 --> Controller Class Initialized
DEBUG - 2012-09-06 20:56:09 --> Model Class Initialized
DEBUG - 2012-09-06 20:56:09 --> Database Driver Class Initialized
DEBUG - 2012-09-06 20:56:09 --> Helper loaded: form_helper
DEBUG - 2012-09-06 20:56:09 --> Form Validation Class Initialized
DEBUG - 2012-09-06 20:56:09 --> Final output sent to browser
DEBUG - 2012-09-06 20:56:09 --> Total execution time: 0.0836
DEBUG - 2012-09-06 20:56:14 --> Config Class Initialized
DEBUG - 2012-09-06 20:56:14 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:56:14 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:56:14 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:56:14 --> URI Class Initialized
DEBUG - 2012-09-06 20:56:14 --> Router Class Initialized
DEBUG - 2012-09-06 20:56:14 --> Output Class Initialized
DEBUG - 2012-09-06 20:56:14 --> Security Class Initialized
DEBUG - 2012-09-06 20:56:14 --> Input Class Initialized
DEBUG - 2012-09-06 20:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 20:56:14 --> Language Class Initialized
DEBUG - 2012-09-06 20:56:14 --> Loader Class Initialized
DEBUG - 2012-09-06 20:56:14 --> Helper loaded: url_helper
DEBUG - 2012-09-06 20:56:14 --> Controller Class Initialized
DEBUG - 2012-09-06 20:56:14 --> Model Class Initialized
DEBUG - 2012-09-06 20:56:14 --> Database Driver Class Initialized
DEBUG - 2012-09-06 20:56:14 --> Helper loaded: form_helper
DEBUG - 2012-09-06 20:56:14 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 20:56:14 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 20:56:14 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 20:56:14 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 20:56:14 --> Final output sent to browser
DEBUG - 2012-09-06 20:56:14 --> Total execution time: 0.0459
DEBUG - 2012-09-06 20:56:23 --> Config Class Initialized
DEBUG - 2012-09-06 20:56:23 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:56:23 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:56:23 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:56:23 --> URI Class Initialized
DEBUG - 2012-09-06 20:56:23 --> Router Class Initialized
DEBUG - 2012-09-06 20:56:23 --> Output Class Initialized
DEBUG - 2012-09-06 20:56:23 --> Security Class Initialized
DEBUG - 2012-09-06 20:56:23 --> Input Class Initialized
DEBUG - 2012-09-06 20:56:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 20:56:23 --> Language Class Initialized
DEBUG - 2012-09-06 20:56:23 --> Loader Class Initialized
DEBUG - 2012-09-06 20:56:23 --> Helper loaded: url_helper
DEBUG - 2012-09-06 20:56:23 --> Controller Class Initialized
DEBUG - 2012-09-06 20:56:23 --> Model Class Initialized
DEBUG - 2012-09-06 20:56:23 --> Database Driver Class Initialized
DEBUG - 2012-09-06 20:56:23 --> Helper loaded: form_helper
DEBUG - 2012-09-06 20:56:23 --> Form Validation Class Initialized
DEBUG - 2012-09-06 20:56:23 --> Final output sent to browser
DEBUG - 2012-09-06 20:56:23 --> Total execution time: 0.1614
DEBUG - 2012-09-06 20:56:32 --> Config Class Initialized
DEBUG - 2012-09-06 20:56:32 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:56:32 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:56:32 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:56:32 --> URI Class Initialized
DEBUG - 2012-09-06 20:56:32 --> Router Class Initialized
DEBUG - 2012-09-06 20:56:32 --> Output Class Initialized
DEBUG - 2012-09-06 20:56:32 --> Security Class Initialized
DEBUG - 2012-09-06 20:56:32 --> Input Class Initialized
DEBUG - 2012-09-06 20:56:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 20:56:32 --> Language Class Initialized
DEBUG - 2012-09-06 20:56:32 --> Loader Class Initialized
DEBUG - 2012-09-06 20:56:32 --> Helper loaded: url_helper
DEBUG - 2012-09-06 20:56:32 --> Controller Class Initialized
DEBUG - 2012-09-06 20:56:32 --> Model Class Initialized
DEBUG - 2012-09-06 20:56:33 --> Database Driver Class Initialized
DEBUG - 2012-09-06 20:56:33 --> Final output sent to browser
DEBUG - 2012-09-06 20:56:33 --> Total execution time: 0.1147
DEBUG - 2012-09-06 20:56:39 --> Config Class Initialized
DEBUG - 2012-09-06 20:56:39 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:56:39 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:56:39 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:56:39 --> URI Class Initialized
DEBUG - 2012-09-06 20:56:39 --> Router Class Initialized
DEBUG - 2012-09-06 20:56:39 --> Output Class Initialized
DEBUG - 2012-09-06 20:56:39 --> Security Class Initialized
DEBUG - 2012-09-06 20:56:39 --> Input Class Initialized
DEBUG - 2012-09-06 20:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 20:56:39 --> Language Class Initialized
DEBUG - 2012-09-06 20:56:39 --> Loader Class Initialized
DEBUG - 2012-09-06 20:56:39 --> Helper loaded: url_helper
DEBUG - 2012-09-06 20:56:39 --> Controller Class Initialized
DEBUG - 2012-09-06 20:56:39 --> Model Class Initialized
DEBUG - 2012-09-06 20:56:39 --> Database Driver Class Initialized
DEBUG - 2012-09-06 20:56:39 --> Helper loaded: form_helper
DEBUG - 2012-09-06 20:56:40 --> Form Validation Class Initialized
DEBUG - 2012-09-06 20:56:40 --> Final output sent to browser
DEBUG - 2012-09-06 20:56:40 --> Total execution time: 0.1146
DEBUG - 2012-09-06 20:56:44 --> Config Class Initialized
DEBUG - 2012-09-06 20:56:44 --> Hooks Class Initialized
DEBUG - 2012-09-06 20:56:44 --> Utf8 Class Initialized
DEBUG - 2012-09-06 20:56:44 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 20:56:44 --> URI Class Initialized
DEBUG - 2012-09-06 20:56:44 --> Router Class Initialized
DEBUG - 2012-09-06 20:56:44 --> Output Class Initialized
DEBUG - 2012-09-06 20:56:44 --> Security Class Initialized
DEBUG - 2012-09-06 20:56:44 --> Input Class Initialized
DEBUG - 2012-09-06 20:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 20:56:44 --> Language Class Initialized
DEBUG - 2012-09-06 20:56:44 --> Loader Class Initialized
DEBUG - 2012-09-06 20:56:44 --> Helper loaded: url_helper
DEBUG - 2012-09-06 20:56:44 --> Controller Class Initialized
DEBUG - 2012-09-06 20:56:44 --> Model Class Initialized
DEBUG - 2012-09-06 20:56:44 --> Database Driver Class Initialized
DEBUG - 2012-09-06 20:56:44 --> Helper loaded: form_helper
DEBUG - 2012-09-06 20:56:44 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 20:56:44 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 20:56:44 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-06 20:56:44 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 20:56:44 --> Final output sent to browser
DEBUG - 2012-09-06 20:56:44 --> Total execution time: 0.0382
DEBUG - 2012-09-06 21:36:37 --> Config Class Initialized
DEBUG - 2012-09-06 21:36:37 --> Hooks Class Initialized
DEBUG - 2012-09-06 21:36:37 --> Utf8 Class Initialized
DEBUG - 2012-09-06 21:36:37 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 21:36:37 --> URI Class Initialized
DEBUG - 2012-09-06 21:36:37 --> Router Class Initialized
DEBUG - 2012-09-06 21:36:37 --> Output Class Initialized
DEBUG - 2012-09-06 21:36:37 --> Security Class Initialized
DEBUG - 2012-09-06 21:36:37 --> Input Class Initialized
DEBUG - 2012-09-06 21:36:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 21:36:37 --> Language Class Initialized
DEBUG - 2012-09-06 21:36:37 --> Loader Class Initialized
DEBUG - 2012-09-06 21:36:37 --> Helper loaded: url_helper
DEBUG - 2012-09-06 21:36:37 --> Controller Class Initialized
DEBUG - 2012-09-06 21:36:37 --> Model Class Initialized
DEBUG - 2012-09-06 21:36:37 --> Database Driver Class Initialized
DEBUG - 2012-09-06 21:36:37 --> Helper loaded: form_helper
DEBUG - 2012-09-06 21:36:37 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 21:36:37 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 21:36:37 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 21:36:37 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 21:36:37 --> Final output sent to browser
DEBUG - 2012-09-06 21:36:37 --> Total execution time: 0.0372
DEBUG - 2012-09-06 21:45:24 --> Config Class Initialized
DEBUG - 2012-09-06 21:45:24 --> Hooks Class Initialized
DEBUG - 2012-09-06 21:45:24 --> Utf8 Class Initialized
DEBUG - 2012-09-06 21:45:24 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 21:45:24 --> URI Class Initialized
DEBUG - 2012-09-06 21:45:24 --> Router Class Initialized
DEBUG - 2012-09-06 21:45:24 --> Output Class Initialized
DEBUG - 2012-09-06 21:45:24 --> Security Class Initialized
DEBUG - 2012-09-06 21:45:24 --> Input Class Initialized
DEBUG - 2012-09-06 21:45:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 21:45:24 --> Language Class Initialized
DEBUG - 2012-09-06 21:45:24 --> Loader Class Initialized
DEBUG - 2012-09-06 21:45:24 --> Helper loaded: url_helper
DEBUG - 2012-09-06 21:45:24 --> Controller Class Initialized
DEBUG - 2012-09-06 21:45:24 --> Model Class Initialized
DEBUG - 2012-09-06 21:45:24 --> Database Driver Class Initialized
DEBUG - 2012-09-06 21:45:24 --> Helper loaded: form_helper
DEBUG - 2012-09-06 21:45:24 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 21:45:24 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 21:45:24 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 21:45:24 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 21:45:24 --> Final output sent to browser
DEBUG - 2012-09-06 21:45:24 --> Total execution time: 0.0389
DEBUG - 2012-09-06 21:46:03 --> Config Class Initialized
DEBUG - 2012-09-06 21:46:03 --> Hooks Class Initialized
DEBUG - 2012-09-06 21:46:03 --> Utf8 Class Initialized
DEBUG - 2012-09-06 21:46:03 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 21:46:03 --> URI Class Initialized
DEBUG - 2012-09-06 21:46:03 --> Router Class Initialized
DEBUG - 2012-09-06 21:46:03 --> Output Class Initialized
DEBUG - 2012-09-06 21:46:03 --> Security Class Initialized
DEBUG - 2012-09-06 21:46:03 --> Input Class Initialized
DEBUG - 2012-09-06 21:46:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 21:46:03 --> Language Class Initialized
DEBUG - 2012-09-06 21:46:03 --> Loader Class Initialized
DEBUG - 2012-09-06 21:46:03 --> Helper loaded: url_helper
DEBUG - 2012-09-06 21:46:03 --> Controller Class Initialized
DEBUG - 2012-09-06 21:46:03 --> Model Class Initialized
DEBUG - 2012-09-06 21:46:04 --> Database Driver Class Initialized
DEBUG - 2012-09-06 21:46:04 --> Helper loaded: form_helper
DEBUG - 2012-09-06 21:46:04 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 21:46:04 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 21:46:04 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 21:46:04 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 21:46:04 --> Final output sent to browser
DEBUG - 2012-09-06 21:46:04 --> Total execution time: 0.0383
DEBUG - 2012-09-06 21:46:14 --> Config Class Initialized
DEBUG - 2012-09-06 21:46:14 --> Hooks Class Initialized
DEBUG - 2012-09-06 21:46:14 --> Utf8 Class Initialized
DEBUG - 2012-09-06 21:46:14 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 21:46:14 --> URI Class Initialized
DEBUG - 2012-09-06 21:46:14 --> Router Class Initialized
DEBUG - 2012-09-06 21:46:14 --> Output Class Initialized
DEBUG - 2012-09-06 21:46:14 --> Security Class Initialized
DEBUG - 2012-09-06 21:46:14 --> Input Class Initialized
DEBUG - 2012-09-06 21:46:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 21:46:14 --> Language Class Initialized
DEBUG - 2012-09-06 21:46:14 --> Loader Class Initialized
DEBUG - 2012-09-06 21:46:14 --> Helper loaded: url_helper
DEBUG - 2012-09-06 21:46:14 --> Controller Class Initialized
DEBUG - 2012-09-06 21:46:14 --> Model Class Initialized
DEBUG - 2012-09-06 21:46:14 --> Database Driver Class Initialized
DEBUG - 2012-09-06 21:46:14 --> Final output sent to browser
DEBUG - 2012-09-06 21:46:14 --> Total execution time: 0.1437
DEBUG - 2012-09-06 21:47:56 --> Config Class Initialized
DEBUG - 2012-09-06 21:47:56 --> Hooks Class Initialized
DEBUG - 2012-09-06 21:47:56 --> Utf8 Class Initialized
DEBUG - 2012-09-06 21:47:56 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 21:47:56 --> URI Class Initialized
DEBUG - 2012-09-06 21:47:56 --> Router Class Initialized
DEBUG - 2012-09-06 21:47:56 --> Output Class Initialized
DEBUG - 2012-09-06 21:47:56 --> Security Class Initialized
DEBUG - 2012-09-06 21:47:56 --> Input Class Initialized
DEBUG - 2012-09-06 21:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 21:47:56 --> Language Class Initialized
DEBUG - 2012-09-06 21:47:56 --> Loader Class Initialized
DEBUG - 2012-09-06 21:47:56 --> Helper loaded: url_helper
DEBUG - 2012-09-06 21:47:56 --> Controller Class Initialized
DEBUG - 2012-09-06 21:47:56 --> Model Class Initialized
DEBUG - 2012-09-06 21:47:56 --> Database Driver Class Initialized
DEBUG - 2012-09-06 21:47:56 --> Helper loaded: form_helper
DEBUG - 2012-09-06 21:47:56 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 21:47:56 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 21:47:56 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 21:47:56 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 21:47:56 --> Final output sent to browser
DEBUG - 2012-09-06 21:47:56 --> Total execution time: 0.0374
DEBUG - 2012-09-06 21:48:03 --> Config Class Initialized
DEBUG - 2012-09-06 21:48:03 --> Hooks Class Initialized
DEBUG - 2012-09-06 21:48:03 --> Utf8 Class Initialized
DEBUG - 2012-09-06 21:48:03 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 21:48:03 --> URI Class Initialized
DEBUG - 2012-09-06 21:48:03 --> Router Class Initialized
DEBUG - 2012-09-06 21:48:03 --> Output Class Initialized
DEBUG - 2012-09-06 21:48:03 --> Security Class Initialized
DEBUG - 2012-09-06 21:48:03 --> Input Class Initialized
DEBUG - 2012-09-06 21:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 21:48:03 --> Language Class Initialized
DEBUG - 2012-09-06 21:48:03 --> Loader Class Initialized
DEBUG - 2012-09-06 21:48:03 --> Helper loaded: url_helper
DEBUG - 2012-09-06 21:48:03 --> Controller Class Initialized
DEBUG - 2012-09-06 21:48:03 --> Model Class Initialized
DEBUG - 2012-09-06 21:48:03 --> Database Driver Class Initialized
DEBUG - 2012-09-06 21:48:03 --> Final output sent to browser
DEBUG - 2012-09-06 21:48:03 --> Total execution time: 0.1059
DEBUG - 2012-09-06 21:54:18 --> Config Class Initialized
DEBUG - 2012-09-06 21:54:18 --> Hooks Class Initialized
DEBUG - 2012-09-06 21:54:18 --> Utf8 Class Initialized
DEBUG - 2012-09-06 21:54:18 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 21:54:18 --> URI Class Initialized
DEBUG - 2012-09-06 21:54:18 --> Router Class Initialized
DEBUG - 2012-09-06 21:54:18 --> Output Class Initialized
DEBUG - 2012-09-06 21:54:18 --> Security Class Initialized
DEBUG - 2012-09-06 21:54:18 --> Input Class Initialized
DEBUG - 2012-09-06 21:54:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 21:54:18 --> Language Class Initialized
DEBUG - 2012-09-06 21:54:18 --> Loader Class Initialized
DEBUG - 2012-09-06 21:54:18 --> Helper loaded: url_helper
DEBUG - 2012-09-06 21:54:18 --> Controller Class Initialized
DEBUG - 2012-09-06 21:54:18 --> Model Class Initialized
DEBUG - 2012-09-06 21:54:18 --> Database Driver Class Initialized
DEBUG - 2012-09-06 21:54:18 --> Helper loaded: form_helper
DEBUG - 2012-09-06 21:54:18 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 21:54:18 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 21:54:18 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 21:54:18 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 21:54:18 --> Final output sent to browser
DEBUG - 2012-09-06 21:54:18 --> Total execution time: 0.0383
DEBUG - 2012-09-06 21:54:25 --> Config Class Initialized
DEBUG - 2012-09-06 21:54:25 --> Hooks Class Initialized
DEBUG - 2012-09-06 21:54:25 --> Utf8 Class Initialized
DEBUG - 2012-09-06 21:54:25 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 21:54:25 --> URI Class Initialized
DEBUG - 2012-09-06 21:54:25 --> Router Class Initialized
DEBUG - 2012-09-06 21:54:25 --> Output Class Initialized
DEBUG - 2012-09-06 21:54:25 --> Security Class Initialized
DEBUG - 2012-09-06 21:54:25 --> Input Class Initialized
DEBUG - 2012-09-06 21:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 21:54:25 --> Language Class Initialized
DEBUG - 2012-09-06 21:54:25 --> Loader Class Initialized
DEBUG - 2012-09-06 21:54:25 --> Helper loaded: url_helper
DEBUG - 2012-09-06 21:54:25 --> Controller Class Initialized
DEBUG - 2012-09-06 21:54:25 --> Model Class Initialized
DEBUG - 2012-09-06 21:54:25 --> Database Driver Class Initialized
DEBUG - 2012-09-06 21:54:26 --> Final output sent to browser
DEBUG - 2012-09-06 21:54:26 --> Total execution time: 0.1558
DEBUG - 2012-09-06 21:59:39 --> Config Class Initialized
DEBUG - 2012-09-06 21:59:39 --> Hooks Class Initialized
DEBUG - 2012-09-06 21:59:39 --> Utf8 Class Initialized
DEBUG - 2012-09-06 21:59:39 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 21:59:39 --> URI Class Initialized
DEBUG - 2012-09-06 21:59:39 --> Router Class Initialized
DEBUG - 2012-09-06 21:59:39 --> Output Class Initialized
DEBUG - 2012-09-06 21:59:39 --> Security Class Initialized
DEBUG - 2012-09-06 21:59:39 --> Input Class Initialized
DEBUG - 2012-09-06 21:59:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 21:59:39 --> Language Class Initialized
DEBUG - 2012-09-06 21:59:39 --> Loader Class Initialized
DEBUG - 2012-09-06 21:59:39 --> Helper loaded: url_helper
DEBUG - 2012-09-06 21:59:39 --> Controller Class Initialized
DEBUG - 2012-09-06 21:59:39 --> Model Class Initialized
DEBUG - 2012-09-06 21:59:39 --> Database Driver Class Initialized
DEBUG - 2012-09-06 21:59:39 --> Final output sent to browser
DEBUG - 2012-09-06 21:59:39 --> Total execution time: 0.1892
DEBUG - 2012-09-06 22:04:13 --> Config Class Initialized
DEBUG - 2012-09-06 22:04:13 --> Hooks Class Initialized
DEBUG - 2012-09-06 22:04:13 --> Utf8 Class Initialized
DEBUG - 2012-09-06 22:04:13 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 22:04:13 --> URI Class Initialized
DEBUG - 2012-09-06 22:04:13 --> Router Class Initialized
DEBUG - 2012-09-06 22:04:13 --> Output Class Initialized
DEBUG - 2012-09-06 22:04:13 --> Security Class Initialized
DEBUG - 2012-09-06 22:04:13 --> Input Class Initialized
DEBUG - 2012-09-06 22:04:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 22:04:13 --> Language Class Initialized
DEBUG - 2012-09-06 22:04:13 --> Loader Class Initialized
DEBUG - 2012-09-06 22:04:13 --> Helper loaded: url_helper
DEBUG - 2012-09-06 22:04:13 --> Controller Class Initialized
DEBUG - 2012-09-06 22:04:13 --> Model Class Initialized
DEBUG - 2012-09-06 22:04:13 --> Database Driver Class Initialized
DEBUG - 2012-09-06 22:04:13 --> Helper loaded: form_helper
DEBUG - 2012-09-06 22:04:13 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-06 22:04:13 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-06 22:04:13 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-06 22:04:13 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-06 22:04:13 --> Final output sent to browser
DEBUG - 2012-09-06 22:04:13 --> Total execution time: 0.0374
DEBUG - 2012-09-06 22:04:19 --> Config Class Initialized
DEBUG - 2012-09-06 22:04:19 --> Hooks Class Initialized
DEBUG - 2012-09-06 22:04:19 --> Utf8 Class Initialized
DEBUG - 2012-09-06 22:04:19 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 22:04:19 --> URI Class Initialized
DEBUG - 2012-09-06 22:04:19 --> Router Class Initialized
DEBUG - 2012-09-06 22:04:19 --> Output Class Initialized
DEBUG - 2012-09-06 22:04:19 --> Security Class Initialized
DEBUG - 2012-09-06 22:04:19 --> Input Class Initialized
DEBUG - 2012-09-06 22:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 22:04:19 --> Language Class Initialized
DEBUG - 2012-09-06 22:04:19 --> Loader Class Initialized
DEBUG - 2012-09-06 22:04:19 --> Helper loaded: url_helper
DEBUG - 2012-09-06 22:04:19 --> Controller Class Initialized
DEBUG - 2012-09-06 22:04:19 --> Model Class Initialized
DEBUG - 2012-09-06 22:04:19 --> Database Driver Class Initialized
DEBUG - 2012-09-06 22:04:19 --> Final output sent to browser
DEBUG - 2012-09-06 22:04:19 --> Total execution time: 0.1047
DEBUG - 2012-09-06 22:04:30 --> Config Class Initialized
DEBUG - 2012-09-06 22:04:30 --> Hooks Class Initialized
DEBUG - 2012-09-06 22:04:30 --> Utf8 Class Initialized
DEBUG - 2012-09-06 22:04:30 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 22:04:30 --> URI Class Initialized
DEBUG - 2012-09-06 22:04:30 --> Router Class Initialized
DEBUG - 2012-09-06 22:04:30 --> Output Class Initialized
DEBUG - 2012-09-06 22:04:30 --> Security Class Initialized
DEBUG - 2012-09-06 22:04:30 --> Input Class Initialized
DEBUG - 2012-09-06 22:04:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 22:04:30 --> Language Class Initialized
DEBUG - 2012-09-06 22:04:30 --> Loader Class Initialized
DEBUG - 2012-09-06 22:04:30 --> Helper loaded: url_helper
DEBUG - 2012-09-06 22:04:30 --> Controller Class Initialized
DEBUG - 2012-09-06 22:04:30 --> Model Class Initialized
DEBUG - 2012-09-06 22:04:30 --> Database Driver Class Initialized
DEBUG - 2012-09-06 22:04:30 --> Final output sent to browser
DEBUG - 2012-09-06 22:04:30 --> Total execution time: 0.0611
DEBUG - 2012-09-06 22:04:32 --> Config Class Initialized
DEBUG - 2012-09-06 22:04:32 --> Hooks Class Initialized
DEBUG - 2012-09-06 22:04:32 --> Utf8 Class Initialized
DEBUG - 2012-09-06 22:04:32 --> UTF-8 Support Disabled
DEBUG - 2012-09-06 22:04:32 --> URI Class Initialized
DEBUG - 2012-09-06 22:04:32 --> Router Class Initialized
DEBUG - 2012-09-06 22:04:32 --> Output Class Initialized
DEBUG - 2012-09-06 22:04:32 --> Security Class Initialized
DEBUG - 2012-09-06 22:04:32 --> Input Class Initialized
DEBUG - 2012-09-06 22:04:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 22:04:32 --> Language Class Initialized
DEBUG - 2012-09-06 22:04:32 --> Loader Class Initialized
DEBUG - 2012-09-06 22:04:32 --> Helper loaded: url_helper
DEBUG - 2012-09-06 22:04:32 --> Controller Class Initialized
DEBUG - 2012-09-06 22:04:32 --> Model Class Initialized
DEBUG - 2012-09-06 22:04:32 --> Database Driver Class Initialized
DEBUG - 2012-09-06 22:04:32 --> Final output sent to browser
DEBUG - 2012-09-06 22:04:32 --> Total execution time: 0.1191
