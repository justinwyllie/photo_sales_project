<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-09-17 12:42:53 --> Config Class Initialized
DEBUG - 2012-09-17 12:42:53 --> Hooks Class Initialized
DEBUG - 2012-09-17 12:42:53 --> Utf8 Class Initialized
DEBUG - 2012-09-17 12:42:53 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 12:42:53 --> URI Class Initialized
DEBUG - 2012-09-17 12:42:53 --> Router Class Initialized
ERROR - 2012-09-17 12:42:53 --> 404 Page Not Found --> admin/index
DEBUG - 2012-09-17 12:42:59 --> Config Class Initialized
DEBUG - 2012-09-17 12:42:59 --> Hooks Class Initialized
DEBUG - 2012-09-17 12:42:59 --> Utf8 Class Initialized
DEBUG - 2012-09-17 12:42:59 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 12:42:59 --> URI Class Initialized
DEBUG - 2012-09-17 12:42:59 --> Router Class Initialized
DEBUG - 2012-09-17 12:42:59 --> Output Class Initialized
DEBUG - 2012-09-17 12:42:59 --> Security Class Initialized
DEBUG - 2012-09-17 12:42:59 --> Input Class Initialized
DEBUG - 2012-09-17 12:42:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 12:42:59 --> Language Class Initialized
DEBUG - 2012-09-17 12:42:59 --> Loader Class Initialized
DEBUG - 2012-09-17 12:42:59 --> Helper loaded: url_helper
DEBUG - 2012-09-17 12:42:59 --> Controller Class Initialized
DEBUG - 2012-09-17 12:42:59 --> Model Class Initialized
DEBUG - 2012-09-17 12:42:59 --> Database Driver Class Initialized
DEBUG - 2012-09-17 12:42:59 --> Helper loaded: form_helper
DEBUG - 2012-09-17 12:43:00 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 12:43:00 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-09-17 12:43:00 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-17 12:43:00 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-09-17 12:43:00 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 12:43:00 --> Final output sent to browser
DEBUG - 2012-09-17 12:43:00 --> Total execution time: 0.5699
DEBUG - 2012-09-17 12:43:01 --> Config Class Initialized
DEBUG - 2012-09-17 12:43:01 --> Config Class Initialized
DEBUG - 2012-09-17 12:43:01 --> Hooks Class Initialized
DEBUG - 2012-09-17 12:43:01 --> Hooks Class Initialized
DEBUG - 2012-09-17 12:43:01 --> Utf8 Class Initialized
DEBUG - 2012-09-17 12:43:01 --> Utf8 Class Initialized
DEBUG - 2012-09-17 12:43:01 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 12:43:01 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 12:43:01 --> URI Class Initialized
DEBUG - 2012-09-17 12:43:01 --> URI Class Initialized
DEBUG - 2012-09-17 12:43:01 --> Router Class Initialized
DEBUG - 2012-09-17 12:43:01 --> Router Class Initialized
ERROR - 2012-09-17 12:43:01 --> 404 Page Not Found --> css
ERROR - 2012-09-17 12:43:01 --> 404 Page Not Found --> css
DEBUG - 2012-09-17 12:43:01 --> Config Class Initialized
DEBUG - 2012-09-17 12:43:01 --> Hooks Class Initialized
DEBUG - 2012-09-17 12:43:01 --> Utf8 Class Initialized
DEBUG - 2012-09-17 12:43:01 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 12:43:01 --> URI Class Initialized
DEBUG - 2012-09-17 12:43:01 --> Router Class Initialized
ERROR - 2012-09-17 12:43:01 --> 404 Page Not Found --> css
DEBUG - 2012-09-17 12:55:42 --> Config Class Initialized
DEBUG - 2012-09-17 12:55:42 --> Hooks Class Initialized
DEBUG - 2012-09-17 12:55:42 --> Utf8 Class Initialized
DEBUG - 2012-09-17 12:55:42 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 12:55:42 --> URI Class Initialized
DEBUG - 2012-09-17 12:55:42 --> Router Class Initialized
DEBUG - 2012-09-17 12:55:42 --> Output Class Initialized
DEBUG - 2012-09-17 12:55:42 --> Security Class Initialized
DEBUG - 2012-09-17 12:55:42 --> Input Class Initialized
DEBUG - 2012-09-17 12:55:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 12:55:42 --> Language Class Initialized
DEBUG - 2012-09-17 12:55:42 --> Loader Class Initialized
DEBUG - 2012-09-17 12:55:42 --> Helper loaded: url_helper
DEBUG - 2012-09-17 12:55:42 --> Controller Class Initialized
DEBUG - 2012-09-17 12:55:42 --> Model Class Initialized
DEBUG - 2012-09-17 12:55:42 --> Database Driver Class Initialized
DEBUG - 2012-09-17 12:55:42 --> Helper loaded: form_helper
DEBUG - 2012-09-17 12:55:42 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 12:55:42 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-17 12:55:42 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-17 12:55:42 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 12:55:42 --> Final output sent to browser
DEBUG - 2012-09-17 12:55:42 --> Total execution time: 0.0775
DEBUG - 2012-09-17 12:55:48 --> Config Class Initialized
DEBUG - 2012-09-17 12:55:48 --> Hooks Class Initialized
DEBUG - 2012-09-17 12:55:48 --> Utf8 Class Initialized
DEBUG - 2012-09-17 12:55:48 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 12:55:48 --> URI Class Initialized
DEBUG - 2012-09-17 12:55:48 --> Router Class Initialized
DEBUG - 2012-09-17 12:55:48 --> Output Class Initialized
DEBUG - 2012-09-17 12:55:48 --> Security Class Initialized
DEBUG - 2012-09-17 12:55:48 --> Input Class Initialized
DEBUG - 2012-09-17 12:55:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 12:55:48 --> Language Class Initialized
DEBUG - 2012-09-17 12:55:48 --> Loader Class Initialized
DEBUG - 2012-09-17 12:55:48 --> Helper loaded: url_helper
DEBUG - 2012-09-17 12:55:48 --> Controller Class Initialized
DEBUG - 2012-09-17 12:55:48 --> Model Class Initialized
DEBUG - 2012-09-17 12:55:49 --> Database Driver Class Initialized
DEBUG - 2012-09-17 12:55:49 --> Final output sent to browser
DEBUG - 2012-09-17 12:55:49 --> Total execution time: 0.2051
DEBUG - 2012-09-17 12:56:01 --> Config Class Initialized
DEBUG - 2012-09-17 12:56:01 --> Hooks Class Initialized
DEBUG - 2012-09-17 12:56:01 --> Utf8 Class Initialized
DEBUG - 2012-09-17 12:56:01 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 12:56:01 --> URI Class Initialized
DEBUG - 2012-09-17 12:56:01 --> Router Class Initialized
DEBUG - 2012-09-17 12:56:01 --> Output Class Initialized
DEBUG - 2012-09-17 12:56:01 --> Security Class Initialized
DEBUG - 2012-09-17 12:56:01 --> Input Class Initialized
DEBUG - 2012-09-17 12:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 12:56:01 --> Language Class Initialized
DEBUG - 2012-09-17 12:56:01 --> Loader Class Initialized
DEBUG - 2012-09-17 12:56:01 --> Helper loaded: url_helper
DEBUG - 2012-09-17 12:56:01 --> Controller Class Initialized
DEBUG - 2012-09-17 12:56:01 --> Model Class Initialized
DEBUG - 2012-09-17 12:56:01 --> Database Driver Class Initialized
DEBUG - 2012-09-17 12:56:01 --> Helper loaded: form_helper
DEBUG - 2012-09-17 12:56:01 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 12:56:01 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-17 12:56:01 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-17 12:56:01 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 12:56:01 --> Final output sent to browser
DEBUG - 2012-09-17 12:56:01 --> Total execution time: 0.0596
DEBUG - 2012-09-17 12:56:07 --> Config Class Initialized
DEBUG - 2012-09-17 12:56:07 --> Hooks Class Initialized
DEBUG - 2012-09-17 12:56:07 --> Utf8 Class Initialized
DEBUG - 2012-09-17 12:56:07 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 12:56:07 --> URI Class Initialized
DEBUG - 2012-09-17 12:56:07 --> Router Class Initialized
DEBUG - 2012-09-17 12:56:07 --> Output Class Initialized
DEBUG - 2012-09-17 12:56:07 --> Security Class Initialized
DEBUG - 2012-09-17 12:56:07 --> Input Class Initialized
DEBUG - 2012-09-17 12:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 12:56:07 --> Language Class Initialized
DEBUG - 2012-09-17 12:56:07 --> Loader Class Initialized
DEBUG - 2012-09-17 12:56:07 --> Helper loaded: url_helper
DEBUG - 2012-09-17 12:56:07 --> Controller Class Initialized
DEBUG - 2012-09-17 12:56:07 --> Model Class Initialized
DEBUG - 2012-09-17 12:56:07 --> Database Driver Class Initialized
DEBUG - 2012-09-17 12:56:07 --> Final output sent to browser
DEBUG - 2012-09-17 12:56:07 --> Total execution time: 0.1610
DEBUG - 2012-09-17 12:56:12 --> Config Class Initialized
DEBUG - 2012-09-17 12:56:12 --> Hooks Class Initialized
DEBUG - 2012-09-17 12:56:12 --> Utf8 Class Initialized
DEBUG - 2012-09-17 12:56:12 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 12:56:12 --> URI Class Initialized
DEBUG - 2012-09-17 12:56:12 --> Router Class Initialized
DEBUG - 2012-09-17 12:56:12 --> Output Class Initialized
DEBUG - 2012-09-17 12:56:12 --> Security Class Initialized
DEBUG - 2012-09-17 12:56:12 --> Input Class Initialized
DEBUG - 2012-09-17 12:56:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 12:56:12 --> Language Class Initialized
DEBUG - 2012-09-17 12:56:12 --> Loader Class Initialized
DEBUG - 2012-09-17 12:56:12 --> Helper loaded: url_helper
DEBUG - 2012-09-17 12:56:12 --> Controller Class Initialized
DEBUG - 2012-09-17 12:56:12 --> Model Class Initialized
DEBUG - 2012-09-17 12:56:12 --> Database Driver Class Initialized
ERROR - 2012-09-17 12:56:12 --> 404 Page Not Found --> pricing/ajax_mount_update
DEBUG - 2012-09-17 12:56:31 --> Config Class Initialized
DEBUG - 2012-09-17 12:56:31 --> Hooks Class Initialized
DEBUG - 2012-09-17 12:56:31 --> Utf8 Class Initialized
DEBUG - 2012-09-17 12:56:31 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 12:56:31 --> URI Class Initialized
DEBUG - 2012-09-17 12:56:31 --> Router Class Initialized
DEBUG - 2012-09-17 12:56:31 --> Output Class Initialized
DEBUG - 2012-09-17 12:56:31 --> Security Class Initialized
DEBUG - 2012-09-17 12:56:31 --> Input Class Initialized
DEBUG - 2012-09-17 12:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 12:56:31 --> Language Class Initialized
DEBUG - 2012-09-17 12:56:31 --> Loader Class Initialized
DEBUG - 2012-09-17 12:56:31 --> Helper loaded: url_helper
DEBUG - 2012-09-17 12:56:31 --> Controller Class Initialized
DEBUG - 2012-09-17 12:56:31 --> Model Class Initialized
DEBUG - 2012-09-17 12:56:31 --> Database Driver Class Initialized
DEBUG - 2012-09-17 12:56:31 --> Final output sent to browser
DEBUG - 2012-09-17 12:56:31 --> Total execution time: 0.3555
DEBUG - 2012-09-17 12:56:36 --> Config Class Initialized
DEBUG - 2012-09-17 12:56:36 --> Hooks Class Initialized
DEBUG - 2012-09-17 12:56:36 --> Utf8 Class Initialized
DEBUG - 2012-09-17 12:56:36 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 12:56:36 --> URI Class Initialized
DEBUG - 2012-09-17 12:56:36 --> Router Class Initialized
DEBUG - 2012-09-17 12:56:36 --> Output Class Initialized
DEBUG - 2012-09-17 12:56:36 --> Security Class Initialized
DEBUG - 2012-09-17 12:56:36 --> Input Class Initialized
DEBUG - 2012-09-17 12:56:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 12:56:36 --> Language Class Initialized
DEBUG - 2012-09-17 12:56:36 --> Loader Class Initialized
DEBUG - 2012-09-17 12:56:36 --> Helper loaded: url_helper
DEBUG - 2012-09-17 12:56:36 --> Controller Class Initialized
DEBUG - 2012-09-17 12:56:36 --> Model Class Initialized
DEBUG - 2012-09-17 12:56:36 --> Database Driver Class Initialized
DEBUG - 2012-09-17 12:56:36 --> Final output sent to browser
DEBUG - 2012-09-17 12:56:36 --> Total execution time: 0.1526
DEBUG - 2012-09-17 12:56:40 --> Config Class Initialized
DEBUG - 2012-09-17 12:56:40 --> Hooks Class Initialized
DEBUG - 2012-09-17 12:56:40 --> Utf8 Class Initialized
DEBUG - 2012-09-17 12:56:40 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 12:56:40 --> URI Class Initialized
DEBUG - 2012-09-17 12:56:40 --> Router Class Initialized
DEBUG - 2012-09-17 12:56:40 --> Output Class Initialized
DEBUG - 2012-09-17 12:56:40 --> Security Class Initialized
DEBUG - 2012-09-17 12:56:40 --> Input Class Initialized
DEBUG - 2012-09-17 12:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 12:56:40 --> Language Class Initialized
DEBUG - 2012-09-17 12:56:40 --> Loader Class Initialized
DEBUG - 2012-09-17 12:56:40 --> Helper loaded: url_helper
DEBUG - 2012-09-17 12:56:40 --> Controller Class Initialized
DEBUG - 2012-09-17 12:56:40 --> Model Class Initialized
DEBUG - 2012-09-17 12:56:40 --> Database Driver Class Initialized
ERROR - 2012-09-17 12:56:40 --> 404 Page Not Found --> pricing/ajax_mount_update
DEBUG - 2012-09-17 12:58:21 --> Config Class Initialized
DEBUG - 2012-09-17 12:58:21 --> Hooks Class Initialized
DEBUG - 2012-09-17 12:58:21 --> Utf8 Class Initialized
DEBUG - 2012-09-17 12:58:21 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 12:58:21 --> URI Class Initialized
DEBUG - 2012-09-17 12:58:21 --> Router Class Initialized
DEBUG - 2012-09-17 12:58:21 --> Output Class Initialized
DEBUG - 2012-09-17 12:58:21 --> Security Class Initialized
DEBUG - 2012-09-17 12:58:21 --> Input Class Initialized
DEBUG - 2012-09-17 12:58:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 12:58:21 --> Language Class Initialized
DEBUG - 2012-09-17 12:58:21 --> Loader Class Initialized
DEBUG - 2012-09-17 12:58:21 --> Helper loaded: url_helper
DEBUG - 2012-09-17 12:58:21 --> Controller Class Initialized
DEBUG - 2012-09-17 12:58:21 --> Model Class Initialized
DEBUG - 2012-09-17 12:58:21 --> Database Driver Class Initialized
ERROR - 2012-09-17 12:58:21 --> 404 Page Not Found --> pricing/ajax_mount_update
DEBUG - 2012-09-17 13:05:23 --> Config Class Initialized
DEBUG - 2012-09-17 13:05:23 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:05:23 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:05:23 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:05:23 --> URI Class Initialized
DEBUG - 2012-09-17 13:05:23 --> Router Class Initialized
DEBUG - 2012-09-17 13:05:23 --> Output Class Initialized
DEBUG - 2012-09-17 13:05:23 --> Security Class Initialized
DEBUG - 2012-09-17 13:05:23 --> Input Class Initialized
DEBUG - 2012-09-17 13:05:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:05:23 --> Language Class Initialized
DEBUG - 2012-09-17 13:05:23 --> Loader Class Initialized
DEBUG - 2012-09-17 13:05:23 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:05:23 --> Controller Class Initialized
DEBUG - 2012-09-17 13:05:23 --> Model Class Initialized
DEBUG - 2012-09-17 13:05:23 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:05:23 --> Final output sent to browser
DEBUG - 2012-09-17 13:05:23 --> Total execution time: 0.1951
DEBUG - 2012-09-17 13:05:25 --> Config Class Initialized
DEBUG - 2012-09-17 13:05:25 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:05:25 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:05:25 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:05:25 --> URI Class Initialized
DEBUG - 2012-09-17 13:05:25 --> Router Class Initialized
DEBUG - 2012-09-17 13:05:25 --> Output Class Initialized
DEBUG - 2012-09-17 13:05:25 --> Security Class Initialized
DEBUG - 2012-09-17 13:05:25 --> Input Class Initialized
DEBUG - 2012-09-17 13:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:05:25 --> Language Class Initialized
DEBUG - 2012-09-17 13:05:25 --> Loader Class Initialized
DEBUG - 2012-09-17 13:05:25 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:05:25 --> Controller Class Initialized
DEBUG - 2012-09-17 13:05:25 --> Model Class Initialized
DEBUG - 2012-09-17 13:05:25 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:05:25 --> Final output sent to browser
DEBUG - 2012-09-17 13:05:25 --> Total execution time: 0.1805
DEBUG - 2012-09-17 13:05:26 --> Config Class Initialized
DEBUG - 2012-09-17 13:05:26 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:05:26 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:05:26 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:05:26 --> URI Class Initialized
DEBUG - 2012-09-17 13:05:26 --> Router Class Initialized
DEBUG - 2012-09-17 13:05:26 --> Output Class Initialized
DEBUG - 2012-09-17 13:05:26 --> Security Class Initialized
DEBUG - 2012-09-17 13:05:26 --> Input Class Initialized
DEBUG - 2012-09-17 13:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:05:26 --> Language Class Initialized
DEBUG - 2012-09-17 13:05:26 --> Loader Class Initialized
DEBUG - 2012-09-17 13:05:26 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:05:26 --> Controller Class Initialized
DEBUG - 2012-09-17 13:05:26 --> Model Class Initialized
DEBUG - 2012-09-17 13:05:26 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:05:26 --> Final output sent to browser
DEBUG - 2012-09-17 13:05:26 --> Total execution time: 0.1553
DEBUG - 2012-09-17 13:07:14 --> Config Class Initialized
DEBUG - 2012-09-17 13:07:14 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:07:14 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:07:14 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:07:14 --> URI Class Initialized
DEBUG - 2012-09-17 13:07:14 --> Router Class Initialized
DEBUG - 2012-09-17 13:07:14 --> Output Class Initialized
DEBUG - 2012-09-17 13:07:14 --> Security Class Initialized
DEBUG - 2012-09-17 13:07:14 --> Input Class Initialized
DEBUG - 2012-09-17 13:07:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:07:14 --> Language Class Initialized
DEBUG - 2012-09-17 13:07:14 --> Loader Class Initialized
DEBUG - 2012-09-17 13:07:14 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:07:14 --> Controller Class Initialized
DEBUG - 2012-09-17 13:07:14 --> Model Class Initialized
DEBUG - 2012-09-17 13:07:14 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:07:14 --> Final output sent to browser
DEBUG - 2012-09-17 13:07:14 --> Total execution time: 0.1367
DEBUG - 2012-09-17 13:07:19 --> Config Class Initialized
DEBUG - 2012-09-17 13:07:19 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:07:19 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:07:19 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:07:19 --> URI Class Initialized
DEBUG - 2012-09-17 13:07:19 --> Router Class Initialized
DEBUG - 2012-09-17 13:07:19 --> Output Class Initialized
DEBUG - 2012-09-17 13:07:19 --> Security Class Initialized
DEBUG - 2012-09-17 13:07:19 --> Input Class Initialized
DEBUG - 2012-09-17 13:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:07:19 --> Language Class Initialized
DEBUG - 2012-09-17 13:07:19 --> Loader Class Initialized
DEBUG - 2012-09-17 13:07:19 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:07:19 --> Controller Class Initialized
DEBUG - 2012-09-17 13:07:19 --> Model Class Initialized
DEBUG - 2012-09-17 13:07:19 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:07:19 --> Helper loaded: form_helper
DEBUG - 2012-09-17 13:07:19 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 13:07:19 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-17 13:07:19 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-17 13:07:19 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 13:07:19 --> Final output sent to browser
DEBUG - 2012-09-17 13:07:19 --> Total execution time: 0.0433
DEBUG - 2012-09-17 13:32:04 --> Config Class Initialized
DEBUG - 2012-09-17 13:32:04 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:32:04 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:32:04 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:32:04 --> URI Class Initialized
DEBUG - 2012-09-17 13:32:04 --> Router Class Initialized
DEBUG - 2012-09-17 13:32:04 --> Output Class Initialized
DEBUG - 2012-09-17 13:32:04 --> Security Class Initialized
DEBUG - 2012-09-17 13:32:04 --> Input Class Initialized
DEBUG - 2012-09-17 13:32:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:32:04 --> Language Class Initialized
DEBUG - 2012-09-17 13:32:04 --> Loader Class Initialized
DEBUG - 2012-09-17 13:32:04 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:32:04 --> Controller Class Initialized
DEBUG - 2012-09-17 13:32:04 --> Model Class Initialized
DEBUG - 2012-09-17 13:32:04 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:32:04 --> Helper loaded: form_helper
DEBUG - 2012-09-17 13:32:04 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 13:32:04 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-17 13:32:04 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-17 13:32:04 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 13:32:04 --> Final output sent to browser
DEBUG - 2012-09-17 13:32:04 --> Total execution time: 0.0389
DEBUG - 2012-09-17 13:32:07 --> Config Class Initialized
DEBUG - 2012-09-17 13:32:07 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:32:07 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:32:07 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:32:07 --> URI Class Initialized
DEBUG - 2012-09-17 13:32:07 --> Router Class Initialized
DEBUG - 2012-09-17 13:32:07 --> Output Class Initialized
DEBUG - 2012-09-17 13:32:07 --> Security Class Initialized
DEBUG - 2012-09-17 13:32:07 --> Input Class Initialized
DEBUG - 2012-09-17 13:32:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:32:07 --> Language Class Initialized
DEBUG - 2012-09-17 13:32:07 --> Loader Class Initialized
DEBUG - 2012-09-17 13:32:07 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:32:07 --> Controller Class Initialized
DEBUG - 2012-09-17 13:32:07 --> Model Class Initialized
DEBUG - 2012-09-17 13:32:07 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:32:07 --> Helper loaded: form_helper
DEBUG - 2012-09-17 13:32:07 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 13:32:07 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-17 13:32:07 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-17 13:32:07 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 13:32:07 --> Final output sent to browser
DEBUG - 2012-09-17 13:32:07 --> Total execution time: 0.0430
DEBUG - 2012-09-17 13:32:12 --> Config Class Initialized
DEBUG - 2012-09-17 13:32:12 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:32:12 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:32:12 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:32:12 --> URI Class Initialized
DEBUG - 2012-09-17 13:32:12 --> Router Class Initialized
DEBUG - 2012-09-17 13:32:12 --> Output Class Initialized
DEBUG - 2012-09-17 13:32:12 --> Security Class Initialized
DEBUG - 2012-09-17 13:32:12 --> Input Class Initialized
DEBUG - 2012-09-17 13:32:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:32:12 --> Language Class Initialized
DEBUG - 2012-09-17 13:32:12 --> Loader Class Initialized
DEBUG - 2012-09-17 13:32:12 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:32:12 --> Controller Class Initialized
DEBUG - 2012-09-17 13:32:12 --> Model Class Initialized
DEBUG - 2012-09-17 13:32:12 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:32:12 --> Helper loaded: form_helper
DEBUG - 2012-09-17 13:32:12 --> Form Validation Class Initialized
DEBUG - 2012-09-17 13:33:23 --> Config Class Initialized
DEBUG - 2012-09-17 13:33:23 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:33:23 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:33:23 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:33:23 --> URI Class Initialized
DEBUG - 2012-09-17 13:33:23 --> Router Class Initialized
DEBUG - 2012-09-17 13:33:23 --> Output Class Initialized
DEBUG - 2012-09-17 13:33:23 --> Security Class Initialized
DEBUG - 2012-09-17 13:33:23 --> Input Class Initialized
DEBUG - 2012-09-17 13:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:33:23 --> Language Class Initialized
DEBUG - 2012-09-17 13:33:23 --> Loader Class Initialized
DEBUG - 2012-09-17 13:33:23 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:33:23 --> Controller Class Initialized
DEBUG - 2012-09-17 13:33:23 --> Model Class Initialized
DEBUG - 2012-09-17 13:33:23 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:33:23 --> Helper loaded: form_helper
DEBUG - 2012-09-17 13:33:23 --> Form Validation Class Initialized
DEBUG - 2012-09-17 13:33:25 --> Config Class Initialized
DEBUG - 2012-09-17 13:33:25 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:33:25 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:33:25 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:33:25 --> URI Class Initialized
DEBUG - 2012-09-17 13:33:25 --> Router Class Initialized
DEBUG - 2012-09-17 13:33:25 --> Output Class Initialized
DEBUG - 2012-09-17 13:33:25 --> Security Class Initialized
DEBUG - 2012-09-17 13:33:25 --> Input Class Initialized
DEBUG - 2012-09-17 13:33:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:33:25 --> Language Class Initialized
DEBUG - 2012-09-17 13:33:25 --> Loader Class Initialized
DEBUG - 2012-09-17 13:33:25 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:33:25 --> Controller Class Initialized
DEBUG - 2012-09-17 13:33:25 --> Model Class Initialized
DEBUG - 2012-09-17 13:33:25 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:33:25 --> Helper loaded: form_helper
DEBUG - 2012-09-17 13:33:25 --> Form Validation Class Initialized
DEBUG - 2012-09-17 13:33:44 --> Config Class Initialized
DEBUG - 2012-09-17 13:33:44 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:33:44 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:33:44 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:33:44 --> URI Class Initialized
DEBUG - 2012-09-17 13:33:44 --> Router Class Initialized
DEBUG - 2012-09-17 13:33:44 --> Output Class Initialized
DEBUG - 2012-09-17 13:33:44 --> Security Class Initialized
DEBUG - 2012-09-17 13:33:44 --> Input Class Initialized
DEBUG - 2012-09-17 13:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:33:44 --> Language Class Initialized
DEBUG - 2012-09-17 13:33:44 --> Loader Class Initialized
DEBUG - 2012-09-17 13:33:44 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:33:44 --> Controller Class Initialized
DEBUG - 2012-09-17 13:33:44 --> Model Class Initialized
DEBUG - 2012-09-17 13:33:44 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:33:44 --> Helper loaded: form_helper
DEBUG - 2012-09-17 13:33:44 --> Form Validation Class Initialized
DEBUG - 2012-09-17 13:36:15 --> Config Class Initialized
DEBUG - 2012-09-17 13:36:15 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:36:15 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:36:15 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:36:15 --> URI Class Initialized
DEBUG - 2012-09-17 13:36:15 --> Router Class Initialized
DEBUG - 2012-09-17 13:36:15 --> Output Class Initialized
DEBUG - 2012-09-17 13:36:15 --> Security Class Initialized
DEBUG - 2012-09-17 13:36:15 --> Input Class Initialized
DEBUG - 2012-09-17 13:36:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:36:15 --> Language Class Initialized
DEBUG - 2012-09-17 13:36:15 --> Loader Class Initialized
DEBUG - 2012-09-17 13:36:15 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:36:15 --> Controller Class Initialized
DEBUG - 2012-09-17 13:36:15 --> Model Class Initialized
DEBUG - 2012-09-17 13:36:15 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:36:15 --> Helper loaded: form_helper
DEBUG - 2012-09-17 13:36:15 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 13:36:15 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-17 13:36:15 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-17 13:36:15 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 13:36:15 --> Final output sent to browser
DEBUG - 2012-09-17 13:36:15 --> Total execution time: 0.0455
DEBUG - 2012-09-17 13:36:17 --> Config Class Initialized
DEBUG - 2012-09-17 13:36:17 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:36:17 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:36:17 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:36:17 --> URI Class Initialized
DEBUG - 2012-09-17 13:36:17 --> Router Class Initialized
ERROR - 2012-09-17 13:36:17 --> 404 Page Not Found --> css
DEBUG - 2012-09-17 13:36:17 --> Config Class Initialized
DEBUG - 2012-09-17 13:36:17 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:36:17 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:36:17 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:36:17 --> URI Class Initialized
DEBUG - 2012-09-17 13:36:17 --> Router Class Initialized
ERROR - 2012-09-17 13:36:17 --> 404 Page Not Found --> css
DEBUG - 2012-09-17 13:36:17 --> Config Class Initialized
DEBUG - 2012-09-17 13:36:17 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:36:17 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:36:17 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:36:17 --> URI Class Initialized
DEBUG - 2012-09-17 13:36:17 --> Router Class Initialized
ERROR - 2012-09-17 13:36:17 --> 404 Page Not Found --> css
DEBUG - 2012-09-17 13:36:24 --> Config Class Initialized
DEBUG - 2012-09-17 13:36:24 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:36:24 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:36:24 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:36:24 --> URI Class Initialized
DEBUG - 2012-09-17 13:36:24 --> Router Class Initialized
DEBUG - 2012-09-17 13:36:24 --> Output Class Initialized
DEBUG - 2012-09-17 13:36:24 --> Security Class Initialized
DEBUG - 2012-09-17 13:36:24 --> Input Class Initialized
DEBUG - 2012-09-17 13:36:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:36:24 --> Language Class Initialized
DEBUG - 2012-09-17 13:36:24 --> Loader Class Initialized
DEBUG - 2012-09-17 13:36:24 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:36:24 --> Controller Class Initialized
DEBUG - 2012-09-17 13:36:24 --> Model Class Initialized
DEBUG - 2012-09-17 13:36:24 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:36:24 --> Helper loaded: form_helper
DEBUG - 2012-09-17 13:36:24 --> Form Validation Class Initialized
DEBUG - 2012-09-17 13:40:40 --> Config Class Initialized
DEBUG - 2012-09-17 13:40:40 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:40:40 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:40:40 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:40:40 --> URI Class Initialized
DEBUG - 2012-09-17 13:40:40 --> Router Class Initialized
DEBUG - 2012-09-17 13:40:40 --> Output Class Initialized
DEBUG - 2012-09-17 13:40:40 --> Security Class Initialized
DEBUG - 2012-09-17 13:40:40 --> Input Class Initialized
DEBUG - 2012-09-17 13:40:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:40:40 --> Language Class Initialized
DEBUG - 2012-09-17 13:40:40 --> Loader Class Initialized
DEBUG - 2012-09-17 13:40:40 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:40:40 --> Controller Class Initialized
DEBUG - 2012-09-17 13:40:40 --> Model Class Initialized
DEBUG - 2012-09-17 13:40:40 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:40:40 --> Helper loaded: form_helper
DEBUG - 2012-09-17 13:40:40 --> Form Validation Class Initialized
DEBUG - 2012-09-17 13:47:00 --> Config Class Initialized
DEBUG - 2012-09-17 13:47:00 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:47:00 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:47:00 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:47:00 --> URI Class Initialized
DEBUG - 2012-09-17 13:47:00 --> Router Class Initialized
DEBUG - 2012-09-17 13:47:00 --> Output Class Initialized
DEBUG - 2012-09-17 13:47:00 --> Security Class Initialized
DEBUG - 2012-09-17 13:47:00 --> Input Class Initialized
DEBUG - 2012-09-17 13:47:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:47:00 --> Language Class Initialized
DEBUG - 2012-09-17 13:47:00 --> Loader Class Initialized
DEBUG - 2012-09-17 13:47:00 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:47:00 --> Controller Class Initialized
DEBUG - 2012-09-17 13:47:00 --> Model Class Initialized
DEBUG - 2012-09-17 13:47:00 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:47:00 --> Helper loaded: form_helper
DEBUG - 2012-09-17 13:47:00 --> Form Validation Class Initialized
DEBUG - 2012-09-17 13:47:00 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 13:48:10 --> Config Class Initialized
DEBUG - 2012-09-17 13:48:10 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:48:10 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:48:10 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:48:10 --> URI Class Initialized
DEBUG - 2012-09-17 13:48:10 --> Router Class Initialized
DEBUG - 2012-09-17 13:48:10 --> Output Class Initialized
DEBUG - 2012-09-17 13:48:10 --> Security Class Initialized
DEBUG - 2012-09-17 13:48:10 --> Input Class Initialized
DEBUG - 2012-09-17 13:48:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:48:10 --> Language Class Initialized
DEBUG - 2012-09-17 13:48:10 --> Loader Class Initialized
DEBUG - 2012-09-17 13:48:10 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:48:10 --> Controller Class Initialized
DEBUG - 2012-09-17 13:48:10 --> Model Class Initialized
DEBUG - 2012-09-17 13:48:10 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:48:10 --> Helper loaded: form_helper
DEBUG - 2012-09-17 13:48:10 --> Form Validation Class Initialized
DEBUG - 2012-09-17 13:48:10 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 13:51:45 --> Config Class Initialized
DEBUG - 2012-09-17 13:51:45 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:51:45 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:51:45 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:51:45 --> URI Class Initialized
DEBUG - 2012-09-17 13:51:45 --> Router Class Initialized
DEBUG - 2012-09-17 13:51:45 --> Output Class Initialized
DEBUG - 2012-09-17 13:51:45 --> Security Class Initialized
DEBUG - 2012-09-17 13:51:45 --> Input Class Initialized
DEBUG - 2012-09-17 13:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:51:45 --> Language Class Initialized
DEBUG - 2012-09-17 13:51:45 --> Loader Class Initialized
DEBUG - 2012-09-17 13:51:45 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:51:45 --> Controller Class Initialized
DEBUG - 2012-09-17 13:51:45 --> Model Class Initialized
DEBUG - 2012-09-17 13:51:45 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:51:45 --> Helper loaded: form_helper
DEBUG - 2012-09-17 13:51:45 --> Form Validation Class Initialized
DEBUG - 2012-09-17 13:51:45 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 13:53:16 --> Config Class Initialized
DEBUG - 2012-09-17 13:53:16 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:53:16 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:53:16 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:53:16 --> URI Class Initialized
DEBUG - 2012-09-17 13:53:16 --> Router Class Initialized
DEBUG - 2012-09-17 13:53:16 --> Output Class Initialized
DEBUG - 2012-09-17 13:53:16 --> Security Class Initialized
DEBUG - 2012-09-17 13:53:16 --> Input Class Initialized
DEBUG - 2012-09-17 13:53:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:53:16 --> Language Class Initialized
DEBUG - 2012-09-17 13:53:16 --> Loader Class Initialized
DEBUG - 2012-09-17 13:53:16 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:53:16 --> Controller Class Initialized
DEBUG - 2012-09-17 13:53:16 --> Model Class Initialized
DEBUG - 2012-09-17 13:53:16 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:53:16 --> Helper loaded: form_helper
DEBUG - 2012-09-17 13:53:16 --> Form Validation Class Initialized
DEBUG - 2012-09-17 13:53:16 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 13:53:58 --> Config Class Initialized
DEBUG - 2012-09-17 13:53:58 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:53:58 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:53:58 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:53:58 --> URI Class Initialized
DEBUG - 2012-09-17 13:53:58 --> Router Class Initialized
DEBUG - 2012-09-17 13:53:58 --> Output Class Initialized
DEBUG - 2012-09-17 13:53:58 --> Security Class Initialized
DEBUG - 2012-09-17 13:53:58 --> Input Class Initialized
DEBUG - 2012-09-17 13:53:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:53:58 --> Language Class Initialized
DEBUG - 2012-09-17 13:53:58 --> Loader Class Initialized
DEBUG - 2012-09-17 13:53:58 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:53:58 --> Controller Class Initialized
DEBUG - 2012-09-17 13:53:58 --> Model Class Initialized
DEBUG - 2012-09-17 13:53:58 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:53:58 --> Helper loaded: form_helper
DEBUG - 2012-09-17 13:53:58 --> Form Validation Class Initialized
DEBUG - 2012-09-17 13:53:58 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 13:54:03 --> Config Class Initialized
DEBUG - 2012-09-17 13:54:03 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:54:03 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:54:03 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:54:03 --> URI Class Initialized
DEBUG - 2012-09-17 13:54:03 --> Router Class Initialized
DEBUG - 2012-09-17 13:54:03 --> Output Class Initialized
DEBUG - 2012-09-17 13:54:03 --> Security Class Initialized
DEBUG - 2012-09-17 13:54:03 --> Input Class Initialized
DEBUG - 2012-09-17 13:54:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:54:03 --> Language Class Initialized
DEBUG - 2012-09-17 13:54:03 --> Loader Class Initialized
DEBUG - 2012-09-17 13:54:03 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:54:03 --> Controller Class Initialized
DEBUG - 2012-09-17 13:54:03 --> Model Class Initialized
DEBUG - 2012-09-17 13:54:03 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:54:03 --> Helper loaded: form_helper
DEBUG - 2012-09-17 13:54:03 --> Form Validation Class Initialized
DEBUG - 2012-09-17 13:54:03 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 13:54:58 --> Config Class Initialized
DEBUG - 2012-09-17 13:54:58 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:54:58 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:54:58 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:54:58 --> URI Class Initialized
DEBUG - 2012-09-17 13:54:58 --> Router Class Initialized
DEBUG - 2012-09-17 13:54:58 --> Output Class Initialized
DEBUG - 2012-09-17 13:54:58 --> Security Class Initialized
DEBUG - 2012-09-17 13:54:58 --> Input Class Initialized
DEBUG - 2012-09-17 13:54:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:54:58 --> Language Class Initialized
DEBUG - 2012-09-17 13:54:58 --> Loader Class Initialized
DEBUG - 2012-09-17 13:54:58 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:54:58 --> Controller Class Initialized
DEBUG - 2012-09-17 13:54:58 --> Model Class Initialized
DEBUG - 2012-09-17 13:54:58 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:54:58 --> Helper loaded: form_helper
DEBUG - 2012-09-17 13:54:58 --> Form Validation Class Initialized
DEBUG - 2012-09-17 13:54:58 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 13:55:22 --> Config Class Initialized
DEBUG - 2012-09-17 13:55:22 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:55:22 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:55:22 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:55:22 --> URI Class Initialized
DEBUG - 2012-09-17 13:55:22 --> Router Class Initialized
DEBUG - 2012-09-17 13:55:22 --> Output Class Initialized
DEBUG - 2012-09-17 13:55:22 --> Security Class Initialized
DEBUG - 2012-09-17 13:55:22 --> Input Class Initialized
DEBUG - 2012-09-17 13:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:55:22 --> Language Class Initialized
DEBUG - 2012-09-17 13:55:22 --> Loader Class Initialized
DEBUG - 2012-09-17 13:55:22 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:55:22 --> Controller Class Initialized
DEBUG - 2012-09-17 13:55:22 --> Model Class Initialized
DEBUG - 2012-09-17 13:55:22 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:55:22 --> Helper loaded: form_helper
DEBUG - 2012-09-17 13:55:22 --> Form Validation Class Initialized
DEBUG - 2012-09-17 13:55:22 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 13:58:45 --> Config Class Initialized
DEBUG - 2012-09-17 13:58:45 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:58:45 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:58:45 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:58:45 --> URI Class Initialized
DEBUG - 2012-09-17 13:58:45 --> Router Class Initialized
DEBUG - 2012-09-17 13:58:45 --> Output Class Initialized
DEBUG - 2012-09-17 13:58:45 --> Security Class Initialized
DEBUG - 2012-09-17 13:58:45 --> Input Class Initialized
DEBUG - 2012-09-17 13:58:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:58:45 --> Language Class Initialized
DEBUG - 2012-09-17 13:58:45 --> Loader Class Initialized
DEBUG - 2012-09-17 13:58:45 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:58:45 --> Controller Class Initialized
DEBUG - 2012-09-17 13:58:45 --> Model Class Initialized
DEBUG - 2012-09-17 13:58:45 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:58:45 --> Helper loaded: form_helper
DEBUG - 2012-09-17 13:58:45 --> Form Validation Class Initialized
DEBUG - 2012-09-17 13:58:45 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 13:59:00 --> Config Class Initialized
DEBUG - 2012-09-17 13:59:00 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:59:00 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:59:00 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:59:00 --> URI Class Initialized
DEBUG - 2012-09-17 13:59:00 --> Router Class Initialized
DEBUG - 2012-09-17 13:59:00 --> Output Class Initialized
DEBUG - 2012-09-17 13:59:00 --> Security Class Initialized
DEBUG - 2012-09-17 13:59:00 --> Input Class Initialized
DEBUG - 2012-09-17 13:59:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:59:00 --> Language Class Initialized
DEBUG - 2012-09-17 13:59:00 --> Loader Class Initialized
DEBUG - 2012-09-17 13:59:00 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:59:00 --> Controller Class Initialized
DEBUG - 2012-09-17 13:59:00 --> Model Class Initialized
DEBUG - 2012-09-17 13:59:00 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:59:00 --> Helper loaded: form_helper
DEBUG - 2012-09-17 13:59:00 --> Form Validation Class Initialized
DEBUG - 2012-09-17 13:59:00 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 13:59:11 --> Config Class Initialized
DEBUG - 2012-09-17 13:59:11 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:59:11 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:59:11 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:59:11 --> URI Class Initialized
DEBUG - 2012-09-17 13:59:11 --> Router Class Initialized
DEBUG - 2012-09-17 13:59:11 --> Output Class Initialized
DEBUG - 2012-09-17 13:59:11 --> Security Class Initialized
DEBUG - 2012-09-17 13:59:11 --> Input Class Initialized
DEBUG - 2012-09-17 13:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:59:11 --> Language Class Initialized
DEBUG - 2012-09-17 13:59:11 --> Loader Class Initialized
DEBUG - 2012-09-17 13:59:11 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:59:11 --> Controller Class Initialized
DEBUG - 2012-09-17 13:59:11 --> Model Class Initialized
DEBUG - 2012-09-17 13:59:11 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:59:11 --> Helper loaded: form_helper
DEBUG - 2012-09-17 13:59:11 --> Form Validation Class Initialized
DEBUG - 2012-09-17 13:59:11 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 13:59:25 --> Config Class Initialized
DEBUG - 2012-09-17 13:59:25 --> Hooks Class Initialized
DEBUG - 2012-09-17 13:59:25 --> Utf8 Class Initialized
DEBUG - 2012-09-17 13:59:25 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 13:59:25 --> URI Class Initialized
DEBUG - 2012-09-17 13:59:25 --> Router Class Initialized
DEBUG - 2012-09-17 13:59:25 --> Output Class Initialized
DEBUG - 2012-09-17 13:59:25 --> Security Class Initialized
DEBUG - 2012-09-17 13:59:25 --> Input Class Initialized
DEBUG - 2012-09-17 13:59:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 13:59:25 --> Language Class Initialized
DEBUG - 2012-09-17 13:59:25 --> Loader Class Initialized
DEBUG - 2012-09-17 13:59:25 --> Helper loaded: url_helper
DEBUG - 2012-09-17 13:59:25 --> Controller Class Initialized
DEBUG - 2012-09-17 13:59:25 --> Model Class Initialized
DEBUG - 2012-09-17 13:59:25 --> Database Driver Class Initialized
DEBUG - 2012-09-17 13:59:25 --> Helper loaded: form_helper
DEBUG - 2012-09-17 13:59:25 --> Form Validation Class Initialized
DEBUG - 2012-09-17 13:59:25 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:00:05 --> Config Class Initialized
DEBUG - 2012-09-17 14:00:05 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:00:05 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:00:05 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:00:05 --> URI Class Initialized
DEBUG - 2012-09-17 14:00:05 --> Router Class Initialized
DEBUG - 2012-09-17 14:00:05 --> Output Class Initialized
DEBUG - 2012-09-17 14:00:05 --> Security Class Initialized
DEBUG - 2012-09-17 14:00:05 --> Input Class Initialized
DEBUG - 2012-09-17 14:00:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:00:05 --> Language Class Initialized
DEBUG - 2012-09-17 14:00:05 --> Loader Class Initialized
DEBUG - 2012-09-17 14:00:05 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:00:05 --> Controller Class Initialized
DEBUG - 2012-09-17 14:00:05 --> Model Class Initialized
DEBUG - 2012-09-17 14:00:05 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:00:05 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:00:05 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:00:05 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:00:45 --> Config Class Initialized
DEBUG - 2012-09-17 14:00:45 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:00:45 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:00:45 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:00:45 --> URI Class Initialized
DEBUG - 2012-09-17 14:00:45 --> Router Class Initialized
DEBUG - 2012-09-17 14:00:45 --> Output Class Initialized
DEBUG - 2012-09-17 14:00:45 --> Security Class Initialized
DEBUG - 2012-09-17 14:00:45 --> Input Class Initialized
DEBUG - 2012-09-17 14:00:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:00:45 --> Language Class Initialized
DEBUG - 2012-09-17 14:00:45 --> Loader Class Initialized
DEBUG - 2012-09-17 14:00:45 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:00:45 --> Controller Class Initialized
DEBUG - 2012-09-17 14:00:45 --> Model Class Initialized
DEBUG - 2012-09-17 14:00:45 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:00:45 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:00:45 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:00:45 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:01:26 --> Config Class Initialized
DEBUG - 2012-09-17 14:01:26 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:01:26 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:01:26 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:01:26 --> URI Class Initialized
DEBUG - 2012-09-17 14:01:26 --> Router Class Initialized
DEBUG - 2012-09-17 14:01:26 --> Output Class Initialized
DEBUG - 2012-09-17 14:01:26 --> Security Class Initialized
DEBUG - 2012-09-17 14:01:26 --> Input Class Initialized
DEBUG - 2012-09-17 14:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:01:26 --> Language Class Initialized
DEBUG - 2012-09-17 14:01:26 --> Loader Class Initialized
DEBUG - 2012-09-17 14:01:26 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:01:26 --> Controller Class Initialized
DEBUG - 2012-09-17 14:01:26 --> Model Class Initialized
DEBUG - 2012-09-17 14:01:26 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:01:26 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:01:26 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:01:26 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:04:05 --> Config Class Initialized
DEBUG - 2012-09-17 14:04:05 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:04:05 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:04:05 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:04:05 --> URI Class Initialized
DEBUG - 2012-09-17 14:04:05 --> Router Class Initialized
DEBUG - 2012-09-17 14:04:05 --> Output Class Initialized
DEBUG - 2012-09-17 14:04:05 --> Security Class Initialized
DEBUG - 2012-09-17 14:04:05 --> Input Class Initialized
DEBUG - 2012-09-17 14:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:04:05 --> Language Class Initialized
DEBUG - 2012-09-17 14:04:05 --> Loader Class Initialized
DEBUG - 2012-09-17 14:04:05 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:04:05 --> Controller Class Initialized
DEBUG - 2012-09-17 14:04:05 --> Model Class Initialized
DEBUG - 2012-09-17 14:04:05 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:04:05 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:04:05 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:04:05 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:08:03 --> Config Class Initialized
DEBUG - 2012-09-17 14:08:03 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:08:03 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:08:03 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:08:03 --> URI Class Initialized
DEBUG - 2012-09-17 14:08:03 --> Router Class Initialized
DEBUG - 2012-09-17 14:08:03 --> Output Class Initialized
DEBUG - 2012-09-17 14:08:03 --> Security Class Initialized
DEBUG - 2012-09-17 14:08:03 --> Input Class Initialized
DEBUG - 2012-09-17 14:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:08:03 --> Language Class Initialized
DEBUG - 2012-09-17 14:08:03 --> Loader Class Initialized
DEBUG - 2012-09-17 14:08:03 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:08:03 --> Controller Class Initialized
DEBUG - 2012-09-17 14:08:03 --> Model Class Initialized
DEBUG - 2012-09-17 14:08:03 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:08:03 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:08:03 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:08:03 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:08:11 --> Config Class Initialized
DEBUG - 2012-09-17 14:08:11 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:08:11 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:08:11 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:08:11 --> URI Class Initialized
DEBUG - 2012-09-17 14:08:11 --> Router Class Initialized
DEBUG - 2012-09-17 14:08:11 --> Output Class Initialized
DEBUG - 2012-09-17 14:08:11 --> Security Class Initialized
DEBUG - 2012-09-17 14:08:11 --> Input Class Initialized
DEBUG - 2012-09-17 14:08:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:08:11 --> Language Class Initialized
DEBUG - 2012-09-17 14:08:11 --> Loader Class Initialized
DEBUG - 2012-09-17 14:08:11 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:08:11 --> Controller Class Initialized
DEBUG - 2012-09-17 14:08:11 --> Model Class Initialized
DEBUG - 2012-09-17 14:08:11 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:08:11 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:08:11 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 14:08:11 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-17 14:08:11 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-17 14:08:11 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 14:08:11 --> Final output sent to browser
DEBUG - 2012-09-17 14:08:11 --> Total execution time: 0.0390
DEBUG - 2012-09-17 14:08:15 --> Config Class Initialized
DEBUG - 2012-09-17 14:08:15 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:08:15 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:08:15 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:08:15 --> URI Class Initialized
DEBUG - 2012-09-17 14:08:15 --> Router Class Initialized
DEBUG - 2012-09-17 14:08:15 --> Output Class Initialized
DEBUG - 2012-09-17 14:08:15 --> Security Class Initialized
DEBUG - 2012-09-17 14:08:15 --> Input Class Initialized
DEBUG - 2012-09-17 14:08:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:08:15 --> Language Class Initialized
DEBUG - 2012-09-17 14:08:15 --> Loader Class Initialized
DEBUG - 2012-09-17 14:08:15 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:08:15 --> Controller Class Initialized
DEBUG - 2012-09-17 14:08:15 --> Model Class Initialized
DEBUG - 2012-09-17 14:08:15 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:08:15 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:08:15 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:08:15 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:08:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:08:16 --> Final output sent to browser
DEBUG - 2012-09-17 14:08:16 --> Total execution time: 0.2966
DEBUG - 2012-09-17 14:08:23 --> Config Class Initialized
DEBUG - 2012-09-17 14:08:23 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:08:23 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:08:23 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:08:23 --> URI Class Initialized
DEBUG - 2012-09-17 14:08:23 --> Router Class Initialized
DEBUG - 2012-09-17 14:08:23 --> Output Class Initialized
DEBUG - 2012-09-17 14:08:23 --> Security Class Initialized
DEBUG - 2012-09-17 14:08:23 --> Input Class Initialized
DEBUG - 2012-09-17 14:08:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:08:23 --> Language Class Initialized
DEBUG - 2012-09-17 14:08:23 --> Loader Class Initialized
DEBUG - 2012-09-17 14:08:23 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:08:23 --> Controller Class Initialized
DEBUG - 2012-09-17 14:08:23 --> Model Class Initialized
DEBUG - 2012-09-17 14:08:23 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:08:23 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:08:23 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:08:23 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:08:23 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:12:02 --> Config Class Initialized
DEBUG - 2012-09-17 14:12:02 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:12:02 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:12:02 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:12:02 --> URI Class Initialized
DEBUG - 2012-09-17 14:12:02 --> Router Class Initialized
DEBUG - 2012-09-17 14:12:02 --> Output Class Initialized
DEBUG - 2012-09-17 14:12:02 --> Security Class Initialized
DEBUG - 2012-09-17 14:12:02 --> Input Class Initialized
DEBUG - 2012-09-17 14:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:12:02 --> Language Class Initialized
DEBUG - 2012-09-17 14:12:02 --> Loader Class Initialized
DEBUG - 2012-09-17 14:12:02 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:12:02 --> Controller Class Initialized
DEBUG - 2012-09-17 14:12:02 --> Model Class Initialized
DEBUG - 2012-09-17 14:12:02 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:12:02 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:12:02 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 14:12:02 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-17 14:12:02 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-17 14:12:02 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 14:12:02 --> Final output sent to browser
DEBUG - 2012-09-17 14:12:02 --> Total execution time: 0.0417
DEBUG - 2012-09-17 14:12:14 --> Config Class Initialized
DEBUG - 2012-09-17 14:12:14 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:12:14 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:12:14 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:12:14 --> URI Class Initialized
DEBUG - 2012-09-17 14:12:14 --> Router Class Initialized
DEBUG - 2012-09-17 14:12:14 --> Output Class Initialized
DEBUG - 2012-09-17 14:12:14 --> Security Class Initialized
DEBUG - 2012-09-17 14:12:14 --> Input Class Initialized
DEBUG - 2012-09-17 14:12:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:12:14 --> Language Class Initialized
DEBUG - 2012-09-17 14:12:14 --> Loader Class Initialized
DEBUG - 2012-09-17 14:12:14 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:12:14 --> Controller Class Initialized
DEBUG - 2012-09-17 14:12:14 --> Model Class Initialized
DEBUG - 2012-09-17 14:12:14 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:12:14 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:12:14 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:12:14 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:12:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:14:08 --> Config Class Initialized
DEBUG - 2012-09-17 14:14:08 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:14:08 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:14:08 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:14:08 --> URI Class Initialized
DEBUG - 2012-09-17 14:14:08 --> Router Class Initialized
DEBUG - 2012-09-17 14:14:08 --> Output Class Initialized
DEBUG - 2012-09-17 14:14:08 --> Security Class Initialized
DEBUG - 2012-09-17 14:14:08 --> Input Class Initialized
DEBUG - 2012-09-17 14:14:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:14:08 --> Language Class Initialized
DEBUG - 2012-09-17 14:14:08 --> Loader Class Initialized
DEBUG - 2012-09-17 14:14:08 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:14:08 --> Controller Class Initialized
DEBUG - 2012-09-17 14:14:08 --> Model Class Initialized
DEBUG - 2012-09-17 14:14:08 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:14:08 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:14:08 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 14:14:08 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-17 14:14:08 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-17 14:14:08 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 14:14:08 --> Final output sent to browser
DEBUG - 2012-09-17 14:14:08 --> Total execution time: 0.0384
DEBUG - 2012-09-17 14:14:11 --> Config Class Initialized
DEBUG - 2012-09-17 14:14:11 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:14:11 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:14:11 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:14:11 --> URI Class Initialized
DEBUG - 2012-09-17 14:14:11 --> Router Class Initialized
DEBUG - 2012-09-17 14:14:11 --> Output Class Initialized
DEBUG - 2012-09-17 14:14:11 --> Security Class Initialized
DEBUG - 2012-09-17 14:14:11 --> Input Class Initialized
DEBUG - 2012-09-17 14:14:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:14:11 --> Language Class Initialized
DEBUG - 2012-09-17 14:14:11 --> Loader Class Initialized
DEBUG - 2012-09-17 14:14:11 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:14:11 --> Controller Class Initialized
DEBUG - 2012-09-17 14:14:11 --> Model Class Initialized
DEBUG - 2012-09-17 14:14:11 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:14:11 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:14:11 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:14:11 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:14:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:14:16 --> Config Class Initialized
DEBUG - 2012-09-17 14:14:16 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:14:16 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:14:16 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:14:16 --> URI Class Initialized
DEBUG - 2012-09-17 14:14:16 --> Router Class Initialized
DEBUG - 2012-09-17 14:14:16 --> Output Class Initialized
DEBUG - 2012-09-17 14:14:16 --> Security Class Initialized
DEBUG - 2012-09-17 14:14:16 --> Input Class Initialized
DEBUG - 2012-09-17 14:14:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:14:16 --> Language Class Initialized
DEBUG - 2012-09-17 14:14:16 --> Loader Class Initialized
DEBUG - 2012-09-17 14:14:16 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:14:16 --> Controller Class Initialized
DEBUG - 2012-09-17 14:14:16 --> Model Class Initialized
DEBUG - 2012-09-17 14:14:16 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:14:16 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:14:16 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:14:16 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:14:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:14:20 --> Config Class Initialized
DEBUG - 2012-09-17 14:14:20 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:14:20 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:14:20 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:14:20 --> URI Class Initialized
DEBUG - 2012-09-17 14:14:20 --> Router Class Initialized
DEBUG - 2012-09-17 14:14:20 --> Output Class Initialized
DEBUG - 2012-09-17 14:14:20 --> Security Class Initialized
DEBUG - 2012-09-17 14:14:20 --> Input Class Initialized
DEBUG - 2012-09-17 14:14:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:14:20 --> Language Class Initialized
DEBUG - 2012-09-17 14:14:20 --> Loader Class Initialized
DEBUG - 2012-09-17 14:14:20 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:14:20 --> Controller Class Initialized
DEBUG - 2012-09-17 14:14:20 --> Model Class Initialized
DEBUG - 2012-09-17 14:14:20 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:14:20 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:14:20 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:14:20 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:14:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:14:29 --> Config Class Initialized
DEBUG - 2012-09-17 14:14:29 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:14:29 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:14:29 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:14:29 --> URI Class Initialized
DEBUG - 2012-09-17 14:14:29 --> Router Class Initialized
DEBUG - 2012-09-17 14:14:29 --> Output Class Initialized
DEBUG - 2012-09-17 14:14:29 --> Security Class Initialized
DEBUG - 2012-09-17 14:14:29 --> Input Class Initialized
DEBUG - 2012-09-17 14:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:14:29 --> Language Class Initialized
DEBUG - 2012-09-17 14:14:29 --> Loader Class Initialized
DEBUG - 2012-09-17 14:14:29 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:14:29 --> Controller Class Initialized
DEBUG - 2012-09-17 14:14:29 --> Model Class Initialized
DEBUG - 2012-09-17 14:14:29 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:14:29 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:14:29 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:14:29 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:14:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:14:29 --> Final output sent to browser
DEBUG - 2012-09-17 14:14:29 --> Total execution time: 0.0876
DEBUG - 2012-09-17 14:14:33 --> Config Class Initialized
DEBUG - 2012-09-17 14:14:33 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:14:33 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:14:33 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:14:33 --> URI Class Initialized
DEBUG - 2012-09-17 14:14:33 --> Router Class Initialized
DEBUG - 2012-09-17 14:14:33 --> Output Class Initialized
DEBUG - 2012-09-17 14:14:33 --> Security Class Initialized
DEBUG - 2012-09-17 14:14:33 --> Input Class Initialized
DEBUG - 2012-09-17 14:14:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:14:33 --> Language Class Initialized
DEBUG - 2012-09-17 14:14:33 --> Loader Class Initialized
DEBUG - 2012-09-17 14:14:33 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:14:33 --> Controller Class Initialized
DEBUG - 2012-09-17 14:14:33 --> Model Class Initialized
DEBUG - 2012-09-17 14:14:33 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:14:33 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:14:33 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 14:14:33 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-17 14:14:33 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-17 14:14:33 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 14:14:33 --> Final output sent to browser
DEBUG - 2012-09-17 14:14:33 --> Total execution time: 0.0385
DEBUG - 2012-09-17 14:19:51 --> Config Class Initialized
DEBUG - 2012-09-17 14:19:51 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:19:51 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:19:51 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:19:51 --> URI Class Initialized
DEBUG - 2012-09-17 14:19:51 --> Router Class Initialized
DEBUG - 2012-09-17 14:19:51 --> Output Class Initialized
DEBUG - 2012-09-17 14:19:51 --> Security Class Initialized
DEBUG - 2012-09-17 14:19:51 --> Input Class Initialized
DEBUG - 2012-09-17 14:19:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:19:51 --> Language Class Initialized
DEBUG - 2012-09-17 14:19:51 --> Loader Class Initialized
DEBUG - 2012-09-17 14:19:51 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:19:51 --> Controller Class Initialized
DEBUG - 2012-09-17 14:19:51 --> Model Class Initialized
DEBUG - 2012-09-17 14:19:51 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:19:51 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:19:51 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 14:19:51 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-17 14:19:51 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-17 14:19:51 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 14:19:51 --> Final output sent to browser
DEBUG - 2012-09-17 14:19:51 --> Total execution time: 0.0388
DEBUG - 2012-09-17 14:19:56 --> Config Class Initialized
DEBUG - 2012-09-17 14:19:56 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:19:56 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:19:56 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:19:56 --> URI Class Initialized
DEBUG - 2012-09-17 14:19:56 --> Router Class Initialized
DEBUG - 2012-09-17 14:19:56 --> Output Class Initialized
DEBUG - 2012-09-17 14:19:56 --> Security Class Initialized
DEBUG - 2012-09-17 14:19:56 --> Input Class Initialized
DEBUG - 2012-09-17 14:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:19:56 --> Language Class Initialized
DEBUG - 2012-09-17 14:19:56 --> Loader Class Initialized
DEBUG - 2012-09-17 14:19:56 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:19:56 --> Controller Class Initialized
DEBUG - 2012-09-17 14:19:56 --> Model Class Initialized
DEBUG - 2012-09-17 14:19:56 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:19:56 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:19:56 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:19:56 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:19:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:21:12 --> Config Class Initialized
DEBUG - 2012-09-17 14:21:12 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:21:12 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:21:12 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:21:12 --> URI Class Initialized
DEBUG - 2012-09-17 14:21:12 --> Router Class Initialized
DEBUG - 2012-09-17 14:21:12 --> Output Class Initialized
DEBUG - 2012-09-17 14:21:12 --> Security Class Initialized
DEBUG - 2012-09-17 14:21:12 --> Input Class Initialized
DEBUG - 2012-09-17 14:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:21:12 --> Language Class Initialized
DEBUG - 2012-09-17 14:21:12 --> Loader Class Initialized
DEBUG - 2012-09-17 14:21:12 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:21:12 --> Controller Class Initialized
DEBUG - 2012-09-17 14:21:12 --> Model Class Initialized
DEBUG - 2012-09-17 14:21:12 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:21:12 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:21:12 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:21:12 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:21:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:21:31 --> Config Class Initialized
DEBUG - 2012-09-17 14:21:31 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:21:31 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:21:31 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:21:31 --> URI Class Initialized
DEBUG - 2012-09-17 14:21:31 --> Router Class Initialized
DEBUG - 2012-09-17 14:21:31 --> Output Class Initialized
DEBUG - 2012-09-17 14:21:31 --> Security Class Initialized
DEBUG - 2012-09-17 14:21:31 --> Input Class Initialized
DEBUG - 2012-09-17 14:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:21:31 --> Language Class Initialized
DEBUG - 2012-09-17 14:21:31 --> Loader Class Initialized
DEBUG - 2012-09-17 14:21:31 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:21:31 --> Controller Class Initialized
DEBUG - 2012-09-17 14:21:31 --> Model Class Initialized
DEBUG - 2012-09-17 14:21:31 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:21:31 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:21:31 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:21:31 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:21:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:21:31 --> Final output sent to browser
DEBUG - 2012-09-17 14:21:31 --> Total execution time: 0.0417
DEBUG - 2012-09-17 14:21:38 --> Config Class Initialized
DEBUG - 2012-09-17 14:21:38 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:21:38 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:21:38 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:21:38 --> URI Class Initialized
DEBUG - 2012-09-17 14:21:38 --> Router Class Initialized
DEBUG - 2012-09-17 14:21:38 --> Output Class Initialized
DEBUG - 2012-09-17 14:21:38 --> Security Class Initialized
DEBUG - 2012-09-17 14:21:38 --> Input Class Initialized
DEBUG - 2012-09-17 14:21:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:21:38 --> Language Class Initialized
DEBUG - 2012-09-17 14:21:38 --> Loader Class Initialized
DEBUG - 2012-09-17 14:21:38 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:21:38 --> Controller Class Initialized
DEBUG - 2012-09-17 14:21:38 --> Model Class Initialized
DEBUG - 2012-09-17 14:21:38 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:21:38 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:21:38 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:21:38 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:21:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:21:38 --> Final output sent to browser
DEBUG - 2012-09-17 14:21:38 --> Total execution time: 0.0393
DEBUG - 2012-09-17 14:21:45 --> Config Class Initialized
DEBUG - 2012-09-17 14:21:45 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:21:45 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:21:45 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:21:45 --> URI Class Initialized
DEBUG - 2012-09-17 14:21:45 --> Router Class Initialized
DEBUG - 2012-09-17 14:21:45 --> Output Class Initialized
DEBUG - 2012-09-17 14:21:45 --> Security Class Initialized
DEBUG - 2012-09-17 14:21:45 --> Input Class Initialized
DEBUG - 2012-09-17 14:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:21:45 --> Language Class Initialized
DEBUG - 2012-09-17 14:21:45 --> Loader Class Initialized
DEBUG - 2012-09-17 14:21:45 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:21:45 --> Controller Class Initialized
DEBUG - 2012-09-17 14:21:45 --> Model Class Initialized
DEBUG - 2012-09-17 14:21:45 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:21:45 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:21:45 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 14:21:45 --> File loaded: application/views/admin/templates/left_menu.php
ERROR - 2012-09-17 14:21:45 --> Severity: Notice  --> Undefined property: stdClass::$name /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/mount_types.php 22
ERROR - 2012-09-17 14:21:45 --> Severity: Notice  --> Undefined property: stdClass::$name /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/mount_types.php 22
ERROR - 2012-09-17 14:21:45 --> Severity: Notice  --> Undefined property: stdClass::$name /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/mount_types.php 22
ERROR - 2012-09-17 14:21:45 --> Severity: Notice  --> Undefined property: stdClass::$name /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/mount_types.php 22
ERROR - 2012-09-17 14:21:45 --> Severity: Notice  --> Undefined property: stdClass::$name /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/mount_types.php 22
ERROR - 2012-09-17 14:21:45 --> Severity: Notice  --> Undefined property: stdClass::$name /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/mount_types.php 22
ERROR - 2012-09-17 14:21:45 --> Severity: Notice  --> Undefined property: stdClass::$name /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/mount_types.php 22
DEBUG - 2012-09-17 14:21:45 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-17 14:21:45 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 14:21:45 --> Final output sent to browser
DEBUG - 2012-09-17 14:21:45 --> Total execution time: 0.0606
DEBUG - 2012-09-17 14:21:56 --> Config Class Initialized
DEBUG - 2012-09-17 14:21:56 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:21:56 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:21:56 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:21:56 --> URI Class Initialized
DEBUG - 2012-09-17 14:21:56 --> Router Class Initialized
DEBUG - 2012-09-17 14:21:56 --> Output Class Initialized
DEBUG - 2012-09-17 14:21:56 --> Security Class Initialized
DEBUG - 2012-09-17 14:21:56 --> Input Class Initialized
DEBUG - 2012-09-17 14:21:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:21:56 --> Language Class Initialized
DEBUG - 2012-09-17 14:21:56 --> Loader Class Initialized
DEBUG - 2012-09-17 14:21:56 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:21:56 --> Controller Class Initialized
DEBUG - 2012-09-17 14:21:56 --> Model Class Initialized
DEBUG - 2012-09-17 14:21:56 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:21:56 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:21:56 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 14:21:56 --> File loaded: application/views/admin/templates/left_menu.php
ERROR - 2012-09-17 14:21:56 --> Severity: Notice  --> Undefined property: stdClass::$name /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/mount_types.php 22
ERROR - 2012-09-17 14:21:56 --> Severity: Notice  --> Undefined property: stdClass::$name /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/mount_types.php 22
ERROR - 2012-09-17 14:21:56 --> Severity: Notice  --> Undefined property: stdClass::$name /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/mount_types.php 22
ERROR - 2012-09-17 14:21:56 --> Severity: Notice  --> Undefined property: stdClass::$name /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/mount_types.php 22
ERROR - 2012-09-17 14:21:56 --> Severity: Notice  --> Undefined property: stdClass::$name /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/mount_types.php 22
ERROR - 2012-09-17 14:21:56 --> Severity: Notice  --> Undefined property: stdClass::$name /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/mount_types.php 22
ERROR - 2012-09-17 14:21:56 --> Severity: Notice  --> Undefined property: stdClass::$name /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/mount_types.php 22
DEBUG - 2012-09-17 14:21:56 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-17 14:21:56 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 14:21:56 --> Final output sent to browser
DEBUG - 2012-09-17 14:21:56 --> Total execution time: 0.0416
DEBUG - 2012-09-17 14:25:28 --> Config Class Initialized
DEBUG - 2012-09-17 14:25:28 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:25:28 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:25:28 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:25:28 --> URI Class Initialized
DEBUG - 2012-09-17 14:25:28 --> Router Class Initialized
DEBUG - 2012-09-17 14:25:28 --> Output Class Initialized
DEBUG - 2012-09-17 14:25:28 --> Security Class Initialized
DEBUG - 2012-09-17 14:25:28 --> Input Class Initialized
DEBUG - 2012-09-17 14:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:25:28 --> Language Class Initialized
DEBUG - 2012-09-17 14:25:28 --> Loader Class Initialized
DEBUG - 2012-09-17 14:25:28 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:25:28 --> Controller Class Initialized
DEBUG - 2012-09-17 14:25:28 --> Model Class Initialized
DEBUG - 2012-09-17 14:25:28 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:25:28 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:25:28 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 14:25:28 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-17 14:25:28 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-17 14:25:28 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 14:25:28 --> Final output sent to browser
DEBUG - 2012-09-17 14:25:28 --> Total execution time: 0.0422
DEBUG - 2012-09-17 14:25:39 --> Config Class Initialized
DEBUG - 2012-09-17 14:25:39 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:25:39 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:25:39 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:25:39 --> URI Class Initialized
DEBUG - 2012-09-17 14:25:39 --> Router Class Initialized
DEBUG - 2012-09-17 14:25:39 --> Output Class Initialized
DEBUG - 2012-09-17 14:25:39 --> Security Class Initialized
DEBUG - 2012-09-17 14:25:39 --> Input Class Initialized
DEBUG - 2012-09-17 14:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:25:39 --> Language Class Initialized
DEBUG - 2012-09-17 14:25:39 --> Loader Class Initialized
DEBUG - 2012-09-17 14:25:39 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:25:39 --> Controller Class Initialized
DEBUG - 2012-09-17 14:25:39 --> Model Class Initialized
DEBUG - 2012-09-17 14:25:39 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:25:39 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:25:39 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:25:39 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:25:39 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:25:39 --> Final output sent to browser
DEBUG - 2012-09-17 14:25:39 --> Total execution time: 0.0530
DEBUG - 2012-09-17 14:25:49 --> Config Class Initialized
DEBUG - 2012-09-17 14:25:49 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:25:49 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:25:49 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:25:49 --> URI Class Initialized
DEBUG - 2012-09-17 14:25:49 --> Router Class Initialized
DEBUG - 2012-09-17 14:25:49 --> Output Class Initialized
DEBUG - 2012-09-17 14:25:49 --> Security Class Initialized
DEBUG - 2012-09-17 14:25:49 --> Input Class Initialized
DEBUG - 2012-09-17 14:25:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:25:49 --> Language Class Initialized
DEBUG - 2012-09-17 14:25:49 --> Loader Class Initialized
DEBUG - 2012-09-17 14:25:49 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:25:49 --> Controller Class Initialized
DEBUG - 2012-09-17 14:25:49 --> Model Class Initialized
DEBUG - 2012-09-17 14:25:49 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:25:49 --> Final output sent to browser
DEBUG - 2012-09-17 14:25:49 --> Total execution time: 0.1183
DEBUG - 2012-09-17 14:25:50 --> Config Class Initialized
DEBUG - 2012-09-17 14:25:50 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:25:50 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:25:50 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:25:50 --> URI Class Initialized
DEBUG - 2012-09-17 14:25:50 --> Router Class Initialized
DEBUG - 2012-09-17 14:25:50 --> Output Class Initialized
DEBUG - 2012-09-17 14:25:50 --> Security Class Initialized
DEBUG - 2012-09-17 14:25:50 --> Input Class Initialized
DEBUG - 2012-09-17 14:25:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:25:50 --> Language Class Initialized
DEBUG - 2012-09-17 14:25:50 --> Loader Class Initialized
DEBUG - 2012-09-17 14:25:50 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:25:50 --> Controller Class Initialized
DEBUG - 2012-09-17 14:25:50 --> Model Class Initialized
DEBUG - 2012-09-17 14:25:50 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:25:50 --> Final output sent to browser
DEBUG - 2012-09-17 14:25:50 --> Total execution time: 0.1171
DEBUG - 2012-09-17 14:25:51 --> Config Class Initialized
DEBUG - 2012-09-17 14:25:51 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:25:51 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:25:51 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:25:51 --> URI Class Initialized
DEBUG - 2012-09-17 14:25:51 --> Router Class Initialized
DEBUG - 2012-09-17 14:25:51 --> Output Class Initialized
DEBUG - 2012-09-17 14:25:51 --> Security Class Initialized
DEBUG - 2012-09-17 14:25:51 --> Input Class Initialized
DEBUG - 2012-09-17 14:25:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:25:51 --> Language Class Initialized
DEBUG - 2012-09-17 14:25:51 --> Loader Class Initialized
DEBUG - 2012-09-17 14:25:51 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:25:51 --> Controller Class Initialized
DEBUG - 2012-09-17 14:25:51 --> Model Class Initialized
DEBUG - 2012-09-17 14:25:51 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:25:51 --> Final output sent to browser
DEBUG - 2012-09-17 14:25:51 --> Total execution time: 0.0837
DEBUG - 2012-09-17 14:25:51 --> Config Class Initialized
DEBUG - 2012-09-17 14:25:51 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:25:51 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:25:51 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:25:51 --> URI Class Initialized
DEBUG - 2012-09-17 14:25:51 --> Router Class Initialized
DEBUG - 2012-09-17 14:25:51 --> Output Class Initialized
DEBUG - 2012-09-17 14:25:51 --> Security Class Initialized
DEBUG - 2012-09-17 14:25:51 --> Input Class Initialized
DEBUG - 2012-09-17 14:25:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:25:51 --> Language Class Initialized
DEBUG - 2012-09-17 14:25:51 --> Loader Class Initialized
DEBUG - 2012-09-17 14:25:51 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:25:51 --> Controller Class Initialized
DEBUG - 2012-09-17 14:25:51 --> Model Class Initialized
DEBUG - 2012-09-17 14:25:51 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:25:51 --> Final output sent to browser
DEBUG - 2012-09-17 14:25:51 --> Total execution time: 0.0745
DEBUG - 2012-09-17 14:25:55 --> Config Class Initialized
DEBUG - 2012-09-17 14:25:55 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:25:55 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:25:55 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:25:55 --> URI Class Initialized
DEBUG - 2012-09-17 14:25:55 --> Router Class Initialized
DEBUG - 2012-09-17 14:25:55 --> Output Class Initialized
DEBUG - 2012-09-17 14:25:55 --> Security Class Initialized
DEBUG - 2012-09-17 14:25:55 --> Input Class Initialized
DEBUG - 2012-09-17 14:25:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:25:55 --> Language Class Initialized
DEBUG - 2012-09-17 14:25:55 --> Loader Class Initialized
DEBUG - 2012-09-17 14:25:55 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:25:55 --> Controller Class Initialized
DEBUG - 2012-09-17 14:25:55 --> Model Class Initialized
DEBUG - 2012-09-17 14:25:55 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:25:55 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:25:55 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:25:55 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:25:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:25:55 --> Final output sent to browser
DEBUG - 2012-09-17 14:25:55 --> Total execution time: 0.0544
DEBUG - 2012-09-17 14:26:00 --> Config Class Initialized
DEBUG - 2012-09-17 14:26:00 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:26:00 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:26:00 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:26:00 --> URI Class Initialized
DEBUG - 2012-09-17 14:26:00 --> Router Class Initialized
DEBUG - 2012-09-17 14:26:00 --> Output Class Initialized
DEBUG - 2012-09-17 14:26:00 --> Security Class Initialized
DEBUG - 2012-09-17 14:26:00 --> Input Class Initialized
DEBUG - 2012-09-17 14:26:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:26:00 --> Language Class Initialized
DEBUG - 2012-09-17 14:26:00 --> Loader Class Initialized
DEBUG - 2012-09-17 14:26:00 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:26:00 --> Controller Class Initialized
DEBUG - 2012-09-17 14:26:00 --> Model Class Initialized
DEBUG - 2012-09-17 14:26:00 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:26:00 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:26:00 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:26:00 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:26:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:26:00 --> Final output sent to browser
DEBUG - 2012-09-17 14:26:00 --> Total execution time: 0.0376
DEBUG - 2012-09-17 14:32:43 --> Config Class Initialized
DEBUG - 2012-09-17 14:32:43 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:32:43 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:32:43 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:32:43 --> URI Class Initialized
DEBUG - 2012-09-17 14:32:43 --> Router Class Initialized
DEBUG - 2012-09-17 14:32:43 --> Output Class Initialized
DEBUG - 2012-09-17 14:32:43 --> Security Class Initialized
DEBUG - 2012-09-17 14:32:43 --> Input Class Initialized
DEBUG - 2012-09-17 14:32:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:32:43 --> Language Class Initialized
DEBUG - 2012-09-17 14:32:43 --> Loader Class Initialized
DEBUG - 2012-09-17 14:32:43 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:32:43 --> Controller Class Initialized
DEBUG - 2012-09-17 14:32:43 --> Model Class Initialized
DEBUG - 2012-09-17 14:32:43 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:32:43 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:32:43 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:32:43 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:32:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:34:14 --> Config Class Initialized
DEBUG - 2012-09-17 14:34:14 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:34:14 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:34:14 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:34:14 --> URI Class Initialized
DEBUG - 2012-09-17 14:34:14 --> Router Class Initialized
DEBUG - 2012-09-17 14:34:14 --> Output Class Initialized
DEBUG - 2012-09-17 14:34:14 --> Security Class Initialized
DEBUG - 2012-09-17 14:34:14 --> Input Class Initialized
DEBUG - 2012-09-17 14:34:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:34:14 --> Language Class Initialized
DEBUG - 2012-09-17 14:34:14 --> Loader Class Initialized
DEBUG - 2012-09-17 14:34:14 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:34:14 --> Controller Class Initialized
DEBUG - 2012-09-17 14:34:14 --> Model Class Initialized
DEBUG - 2012-09-17 14:34:14 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:34:14 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:34:14 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:34:14 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:34:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:35:35 --> Config Class Initialized
DEBUG - 2012-09-17 14:35:35 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:35:35 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:35:35 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:35:35 --> URI Class Initialized
DEBUG - 2012-09-17 14:35:35 --> Router Class Initialized
DEBUG - 2012-09-17 14:35:35 --> Output Class Initialized
DEBUG - 2012-09-17 14:35:35 --> Security Class Initialized
DEBUG - 2012-09-17 14:35:35 --> Input Class Initialized
DEBUG - 2012-09-17 14:35:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:35:35 --> Language Class Initialized
DEBUG - 2012-09-17 14:35:35 --> Loader Class Initialized
DEBUG - 2012-09-17 14:35:35 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:35:35 --> Controller Class Initialized
DEBUG - 2012-09-17 14:35:35 --> Model Class Initialized
DEBUG - 2012-09-17 14:35:35 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:35:35 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:35:55 --> Config Class Initialized
DEBUG - 2012-09-17 14:35:55 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:35:55 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:35:55 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:35:55 --> URI Class Initialized
DEBUG - 2012-09-17 14:35:55 --> Router Class Initialized
DEBUG - 2012-09-17 14:35:55 --> Output Class Initialized
DEBUG - 2012-09-17 14:35:55 --> Security Class Initialized
DEBUG - 2012-09-17 14:35:55 --> Input Class Initialized
DEBUG - 2012-09-17 14:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:35:55 --> Language Class Initialized
DEBUG - 2012-09-17 14:35:55 --> Loader Class Initialized
DEBUG - 2012-09-17 14:35:55 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:35:55 --> Controller Class Initialized
DEBUG - 2012-09-17 14:35:55 --> Model Class Initialized
DEBUG - 2012-09-17 14:35:55 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:35:55 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:35:55 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 14:35:55 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-17 14:35:55 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-17 14:35:55 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 14:35:55 --> Final output sent to browser
DEBUG - 2012-09-17 14:35:55 --> Total execution time: 0.0392
DEBUG - 2012-09-17 14:36:00 --> Config Class Initialized
DEBUG - 2012-09-17 14:36:00 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:36:00 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:36:00 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:36:00 --> URI Class Initialized
DEBUG - 2012-09-17 14:36:00 --> Router Class Initialized
DEBUG - 2012-09-17 14:36:00 --> Output Class Initialized
DEBUG - 2012-09-17 14:36:00 --> Security Class Initialized
DEBUG - 2012-09-17 14:36:00 --> Input Class Initialized
DEBUG - 2012-09-17 14:36:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:36:00 --> Language Class Initialized
DEBUG - 2012-09-17 14:36:00 --> Loader Class Initialized
DEBUG - 2012-09-17 14:36:00 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:36:00 --> Controller Class Initialized
DEBUG - 2012-09-17 14:36:00 --> Model Class Initialized
DEBUG - 2012-09-17 14:36:00 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:36:00 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:37:07 --> Config Class Initialized
DEBUG - 2012-09-17 14:37:07 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:37:07 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:37:07 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:37:07 --> URI Class Initialized
DEBUG - 2012-09-17 14:37:07 --> Router Class Initialized
DEBUG - 2012-09-17 14:37:07 --> Output Class Initialized
DEBUG - 2012-09-17 14:37:07 --> Security Class Initialized
DEBUG - 2012-09-17 14:37:07 --> Input Class Initialized
DEBUG - 2012-09-17 14:37:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:37:07 --> Language Class Initialized
DEBUG - 2012-09-17 14:37:07 --> Loader Class Initialized
DEBUG - 2012-09-17 14:37:07 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:37:07 --> Controller Class Initialized
DEBUG - 2012-09-17 14:37:07 --> Model Class Initialized
DEBUG - 2012-09-17 14:37:07 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:37:07 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:37:07 --> Helper loaded: language_helper
DEBUG - 2012-09-17 14:37:07 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:37:07 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:37:07 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:37:07 --> Final output sent to browser
DEBUG - 2012-09-17 14:37:07 --> Total execution time: 0.0563
DEBUG - 2012-09-17 14:40:15 --> Config Class Initialized
DEBUG - 2012-09-17 14:40:15 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:40:15 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:40:15 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:40:15 --> URI Class Initialized
DEBUG - 2012-09-17 14:40:15 --> Router Class Initialized
DEBUG - 2012-09-17 14:40:15 --> Output Class Initialized
DEBUG - 2012-09-17 14:40:15 --> Security Class Initialized
DEBUG - 2012-09-17 14:40:15 --> Input Class Initialized
DEBUG - 2012-09-17 14:40:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:40:15 --> Language Class Initialized
DEBUG - 2012-09-17 14:40:15 --> Loader Class Initialized
DEBUG - 2012-09-17 14:40:15 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:40:15 --> Controller Class Initialized
DEBUG - 2012-09-17 14:40:15 --> Model Class Initialized
DEBUG - 2012-09-17 14:40:15 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:40:15 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:40:15 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 14:40:15 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-17 14:40:15 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-17 14:40:15 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 14:40:15 --> Final output sent to browser
DEBUG - 2012-09-17 14:40:15 --> Total execution time: 0.0391
DEBUG - 2012-09-17 14:40:19 --> Config Class Initialized
DEBUG - 2012-09-17 14:40:19 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:40:19 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:40:19 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:40:19 --> URI Class Initialized
DEBUG - 2012-09-17 14:40:19 --> Router Class Initialized
DEBUG - 2012-09-17 14:40:19 --> Output Class Initialized
DEBUG - 2012-09-17 14:40:19 --> Security Class Initialized
DEBUG - 2012-09-17 14:40:19 --> Input Class Initialized
DEBUG - 2012-09-17 14:40:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:40:19 --> Language Class Initialized
DEBUG - 2012-09-17 14:40:19 --> Loader Class Initialized
DEBUG - 2012-09-17 14:40:19 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:40:19 --> Controller Class Initialized
DEBUG - 2012-09-17 14:40:19 --> Model Class Initialized
DEBUG - 2012-09-17 14:40:19 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:40:19 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:40:19 --> Helper loaded: language_helper
DEBUG - 2012-09-17 14:40:19 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:40:19 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:40:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:40:19 --> Final output sent to browser
DEBUG - 2012-09-17 14:40:19 --> Total execution time: 0.0375
DEBUG - 2012-09-17 14:42:36 --> Config Class Initialized
DEBUG - 2012-09-17 14:42:36 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:42:36 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:42:36 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:42:36 --> URI Class Initialized
DEBUG - 2012-09-17 14:42:36 --> Router Class Initialized
DEBUG - 2012-09-17 14:42:36 --> Output Class Initialized
DEBUG - 2012-09-17 14:42:36 --> Security Class Initialized
DEBUG - 2012-09-17 14:42:36 --> Input Class Initialized
DEBUG - 2012-09-17 14:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:42:36 --> Language Class Initialized
DEBUG - 2012-09-17 14:42:36 --> Loader Class Initialized
DEBUG - 2012-09-17 14:42:36 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:42:36 --> Controller Class Initialized
DEBUG - 2012-09-17 14:42:36 --> Model Class Initialized
DEBUG - 2012-09-17 14:42:36 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:42:36 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:42:36 --> Helper loaded: language_helper
DEBUG - 2012-09-17 14:42:36 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:42:36 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:42:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:42:36 --> Final output sent to browser
DEBUG - 2012-09-17 14:42:36 --> Total execution time: 0.1568
DEBUG - 2012-09-17 14:42:39 --> Config Class Initialized
DEBUG - 2012-09-17 14:42:39 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:42:39 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:42:39 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:42:39 --> URI Class Initialized
DEBUG - 2012-09-17 14:42:39 --> Router Class Initialized
DEBUG - 2012-09-17 14:42:39 --> Output Class Initialized
DEBUG - 2012-09-17 14:42:39 --> Security Class Initialized
DEBUG - 2012-09-17 14:42:39 --> Input Class Initialized
DEBUG - 2012-09-17 14:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:42:39 --> Language Class Initialized
DEBUG - 2012-09-17 14:42:39 --> Loader Class Initialized
DEBUG - 2012-09-17 14:42:39 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:42:39 --> Controller Class Initialized
DEBUG - 2012-09-17 14:42:39 --> Model Class Initialized
DEBUG - 2012-09-17 14:42:39 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:42:39 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:42:39 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 14:42:39 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-17 14:42:39 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-17 14:42:39 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 14:42:39 --> Final output sent to browser
DEBUG - 2012-09-17 14:42:39 --> Total execution time: 0.0378
DEBUG - 2012-09-17 14:42:46 --> Config Class Initialized
DEBUG - 2012-09-17 14:42:46 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:42:46 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:42:46 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:42:46 --> URI Class Initialized
DEBUG - 2012-09-17 14:42:46 --> Router Class Initialized
DEBUG - 2012-09-17 14:42:46 --> Output Class Initialized
DEBUG - 2012-09-17 14:42:46 --> Security Class Initialized
DEBUG - 2012-09-17 14:42:46 --> Input Class Initialized
DEBUG - 2012-09-17 14:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:42:46 --> Language Class Initialized
DEBUG - 2012-09-17 14:42:46 --> Loader Class Initialized
DEBUG - 2012-09-17 14:42:46 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:42:46 --> Controller Class Initialized
DEBUG - 2012-09-17 14:42:46 --> Model Class Initialized
DEBUG - 2012-09-17 14:42:46 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:42:46 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:42:46 --> Helper loaded: language_helper
DEBUG - 2012-09-17 14:42:46 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:42:46 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:42:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:42:48 --> Config Class Initialized
DEBUG - 2012-09-17 14:42:48 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:42:48 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:42:48 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:42:48 --> URI Class Initialized
DEBUG - 2012-09-17 14:42:48 --> Router Class Initialized
DEBUG - 2012-09-17 14:42:48 --> Output Class Initialized
DEBUG - 2012-09-17 14:42:48 --> Security Class Initialized
DEBUG - 2012-09-17 14:42:48 --> Input Class Initialized
DEBUG - 2012-09-17 14:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:42:48 --> Language Class Initialized
DEBUG - 2012-09-17 14:42:48 --> Loader Class Initialized
DEBUG - 2012-09-17 14:42:48 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:42:48 --> Controller Class Initialized
DEBUG - 2012-09-17 14:42:48 --> Model Class Initialized
DEBUG - 2012-09-17 14:42:48 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:42:48 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:42:48 --> Helper loaded: language_helper
DEBUG - 2012-09-17 14:42:48 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:42:48 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:42:48 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:42:49 --> Config Class Initialized
DEBUG - 2012-09-17 14:42:49 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:42:49 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:42:49 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:42:49 --> URI Class Initialized
DEBUG - 2012-09-17 14:42:49 --> Router Class Initialized
DEBUG - 2012-09-17 14:42:49 --> Output Class Initialized
DEBUG - 2012-09-17 14:42:49 --> Security Class Initialized
DEBUG - 2012-09-17 14:42:49 --> Input Class Initialized
DEBUG - 2012-09-17 14:42:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:42:49 --> Language Class Initialized
DEBUG - 2012-09-17 14:42:49 --> Loader Class Initialized
DEBUG - 2012-09-17 14:42:49 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:42:49 --> Controller Class Initialized
DEBUG - 2012-09-17 14:42:49 --> Model Class Initialized
DEBUG - 2012-09-17 14:42:49 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:42:49 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:42:49 --> Helper loaded: language_helper
DEBUG - 2012-09-17 14:42:49 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:42:49 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:42:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:42:55 --> Config Class Initialized
DEBUG - 2012-09-17 14:42:55 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:42:55 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:42:55 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:42:55 --> URI Class Initialized
DEBUG - 2012-09-17 14:42:55 --> Router Class Initialized
DEBUG - 2012-09-17 14:42:55 --> Output Class Initialized
DEBUG - 2012-09-17 14:42:55 --> Security Class Initialized
DEBUG - 2012-09-17 14:42:55 --> Input Class Initialized
DEBUG - 2012-09-17 14:42:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:42:55 --> Language Class Initialized
DEBUG - 2012-09-17 14:42:55 --> Loader Class Initialized
DEBUG - 2012-09-17 14:42:55 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:42:55 --> Controller Class Initialized
DEBUG - 2012-09-17 14:42:55 --> Model Class Initialized
DEBUG - 2012-09-17 14:42:55 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:42:55 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:42:55 --> Helper loaded: language_helper
DEBUG - 2012-09-17 14:42:55 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:42:55 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:42:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:42:55 --> Final output sent to browser
DEBUG - 2012-09-17 14:42:55 --> Total execution time: 0.0768
DEBUG - 2012-09-17 14:44:36 --> Config Class Initialized
DEBUG - 2012-09-17 14:44:36 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:44:36 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:44:36 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:44:36 --> URI Class Initialized
DEBUG - 2012-09-17 14:44:36 --> Router Class Initialized
DEBUG - 2012-09-17 14:44:36 --> Output Class Initialized
DEBUG - 2012-09-17 14:44:36 --> Security Class Initialized
DEBUG - 2012-09-17 14:44:36 --> Input Class Initialized
DEBUG - 2012-09-17 14:44:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:44:36 --> Language Class Initialized
DEBUG - 2012-09-17 14:44:36 --> Loader Class Initialized
DEBUG - 2012-09-17 14:44:36 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:44:36 --> Controller Class Initialized
DEBUG - 2012-09-17 14:44:36 --> Model Class Initialized
DEBUG - 2012-09-17 14:44:36 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:44:36 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:44:36 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 14:44:36 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-17 14:44:36 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-17 14:44:36 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 14:44:36 --> Final output sent to browser
DEBUG - 2012-09-17 14:44:36 --> Total execution time: 0.0389
DEBUG - 2012-09-17 14:44:42 --> Config Class Initialized
DEBUG - 2012-09-17 14:44:42 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:44:42 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:44:42 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:44:42 --> URI Class Initialized
DEBUG - 2012-09-17 14:44:42 --> Router Class Initialized
DEBUG - 2012-09-17 14:44:42 --> Output Class Initialized
DEBUG - 2012-09-17 14:44:42 --> Security Class Initialized
DEBUG - 2012-09-17 14:44:42 --> Input Class Initialized
DEBUG - 2012-09-17 14:44:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:44:42 --> Language Class Initialized
DEBUG - 2012-09-17 14:44:42 --> Loader Class Initialized
DEBUG - 2012-09-17 14:44:42 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:44:42 --> Controller Class Initialized
DEBUG - 2012-09-17 14:44:42 --> Model Class Initialized
DEBUG - 2012-09-17 14:44:42 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:44:42 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:44:42 --> Helper loaded: language_helper
DEBUG - 2012-09-17 14:44:42 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:44:42 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:44:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:45:03 --> Config Class Initialized
DEBUG - 2012-09-17 14:45:03 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:45:03 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:45:03 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:45:03 --> URI Class Initialized
DEBUG - 2012-09-17 14:45:03 --> Router Class Initialized
DEBUG - 2012-09-17 14:45:03 --> Output Class Initialized
DEBUG - 2012-09-17 14:45:03 --> Security Class Initialized
DEBUG - 2012-09-17 14:45:03 --> Input Class Initialized
DEBUG - 2012-09-17 14:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:45:03 --> Language Class Initialized
DEBUG - 2012-09-17 14:45:03 --> Loader Class Initialized
DEBUG - 2012-09-17 14:45:03 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:45:03 --> Controller Class Initialized
DEBUG - 2012-09-17 14:45:03 --> Model Class Initialized
DEBUG - 2012-09-17 14:45:03 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:45:03 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:45:03 --> Helper loaded: language_helper
DEBUG - 2012-09-17 14:45:03 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:45:03 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:45:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:45:28 --> Config Class Initialized
DEBUG - 2012-09-17 14:45:28 --> Hooks Class Initialized
DEBUG - 2012-09-17 14:45:28 --> Utf8 Class Initialized
DEBUG - 2012-09-17 14:45:28 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 14:45:28 --> URI Class Initialized
DEBUG - 2012-09-17 14:45:28 --> Router Class Initialized
DEBUG - 2012-09-17 14:45:28 --> Output Class Initialized
DEBUG - 2012-09-17 14:45:28 --> Security Class Initialized
DEBUG - 2012-09-17 14:45:28 --> Input Class Initialized
DEBUG - 2012-09-17 14:45:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 14:45:28 --> Language Class Initialized
DEBUG - 2012-09-17 14:45:28 --> Loader Class Initialized
DEBUG - 2012-09-17 14:45:28 --> Helper loaded: url_helper
DEBUG - 2012-09-17 14:45:28 --> Controller Class Initialized
DEBUG - 2012-09-17 14:45:28 --> Model Class Initialized
DEBUG - 2012-09-17 14:45:28 --> Database Driver Class Initialized
DEBUG - 2012-09-17 14:45:28 --> Helper loaded: form_helper
DEBUG - 2012-09-17 14:45:28 --> Helper loaded: language_helper
DEBUG - 2012-09-17 14:45:28 --> Form Validation Class Initialized
DEBUG - 2012-09-17 14:45:28 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 14:45:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-09-17 14:45:29 --> Final output sent to browser
DEBUG - 2012-09-17 14:45:29 --> Total execution time: 0.1854
DEBUG - 2012-09-17 15:31:04 --> Config Class Initialized
DEBUG - 2012-09-17 15:31:04 --> Hooks Class Initialized
DEBUG - 2012-09-17 15:31:04 --> Utf8 Class Initialized
DEBUG - 2012-09-17 15:31:04 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 15:31:04 --> URI Class Initialized
DEBUG - 2012-09-17 15:31:04 --> Router Class Initialized
DEBUG - 2012-09-17 15:31:04 --> Output Class Initialized
DEBUG - 2012-09-17 15:31:04 --> Security Class Initialized
DEBUG - 2012-09-17 15:31:04 --> Input Class Initialized
DEBUG - 2012-09-17 15:31:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 15:31:04 --> Language Class Initialized
DEBUG - 2012-09-17 15:31:04 --> Loader Class Initialized
DEBUG - 2012-09-17 15:31:04 --> Helper loaded: url_helper
DEBUG - 2012-09-17 15:31:04 --> Controller Class Initialized
DEBUG - 2012-09-17 15:31:04 --> Model Class Initialized
DEBUG - 2012-09-17 15:31:04 --> Database Driver Class Initialized
ERROR - 2012-09-17 15:31:04 --> 404 Page Not Found --> pricing/ajax_mount_update
DEBUG - 2012-09-17 15:31:20 --> Config Class Initialized
DEBUG - 2012-09-17 15:31:20 --> Hooks Class Initialized
DEBUG - 2012-09-17 15:31:20 --> Utf8 Class Initialized
DEBUG - 2012-09-17 15:31:20 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 15:31:20 --> URI Class Initialized
DEBUG - 2012-09-17 15:31:20 --> Router Class Initialized
DEBUG - 2012-09-17 15:31:20 --> Output Class Initialized
DEBUG - 2012-09-17 15:31:20 --> Security Class Initialized
DEBUG - 2012-09-17 15:31:20 --> Input Class Initialized
DEBUG - 2012-09-17 15:31:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 15:31:20 --> Language Class Initialized
DEBUG - 2012-09-17 15:31:20 --> Loader Class Initialized
DEBUG - 2012-09-17 15:31:20 --> Helper loaded: url_helper
DEBUG - 2012-09-17 15:31:20 --> Controller Class Initialized
DEBUG - 2012-09-17 15:31:20 --> Model Class Initialized
DEBUG - 2012-09-17 15:31:20 --> Database Driver Class Initialized
ERROR - 2012-09-17 15:31:20 --> 404 Page Not Found --> pricing/ajax_mount_update
DEBUG - 2012-09-17 15:31:35 --> Config Class Initialized
DEBUG - 2012-09-17 15:31:35 --> Hooks Class Initialized
DEBUG - 2012-09-17 15:31:35 --> Utf8 Class Initialized
DEBUG - 2012-09-17 15:31:35 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 15:31:35 --> URI Class Initialized
DEBUG - 2012-09-17 15:31:35 --> Router Class Initialized
DEBUG - 2012-09-17 15:31:35 --> Output Class Initialized
DEBUG - 2012-09-17 15:31:35 --> Security Class Initialized
DEBUG - 2012-09-17 15:31:35 --> Input Class Initialized
DEBUG - 2012-09-17 15:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 15:31:35 --> Language Class Initialized
DEBUG - 2012-09-17 15:31:35 --> Loader Class Initialized
DEBUG - 2012-09-17 15:31:35 --> Helper loaded: url_helper
DEBUG - 2012-09-17 15:31:35 --> Controller Class Initialized
DEBUG - 2012-09-17 15:31:35 --> Model Class Initialized
DEBUG - 2012-09-17 15:31:35 --> Database Driver Class Initialized
DEBUG - 2012-09-17 15:31:35 --> Helper loaded: form_helper
DEBUG - 2012-09-17 15:31:35 --> Form Validation Class Initialized
DEBUG - 2012-09-17 15:33:37 --> Config Class Initialized
DEBUG - 2012-09-17 15:33:37 --> Hooks Class Initialized
DEBUG - 2012-09-17 15:33:37 --> Utf8 Class Initialized
DEBUG - 2012-09-17 15:33:37 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 15:33:37 --> URI Class Initialized
DEBUG - 2012-09-17 15:33:37 --> Router Class Initialized
DEBUG - 2012-09-17 15:33:37 --> Output Class Initialized
DEBUG - 2012-09-17 15:33:37 --> Security Class Initialized
DEBUG - 2012-09-17 15:33:37 --> Input Class Initialized
DEBUG - 2012-09-17 15:33:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 15:33:37 --> Language Class Initialized
DEBUG - 2012-09-17 15:33:37 --> Loader Class Initialized
DEBUG - 2012-09-17 15:33:37 --> Helper loaded: url_helper
DEBUG - 2012-09-17 15:33:37 --> Controller Class Initialized
DEBUG - 2012-09-17 15:33:37 --> Model Class Initialized
DEBUG - 2012-09-17 15:33:37 --> Database Driver Class Initialized
DEBUG - 2012-09-17 15:33:37 --> Helper loaded: form_helper
DEBUG - 2012-09-17 15:34:26 --> Config Class Initialized
DEBUG - 2012-09-17 15:34:26 --> Hooks Class Initialized
DEBUG - 2012-09-17 15:34:26 --> Utf8 Class Initialized
DEBUG - 2012-09-17 15:34:26 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 15:34:26 --> URI Class Initialized
DEBUG - 2012-09-17 15:34:26 --> Router Class Initialized
DEBUG - 2012-09-17 15:34:26 --> Output Class Initialized
DEBUG - 2012-09-17 15:34:26 --> Security Class Initialized
DEBUG - 2012-09-17 15:34:26 --> Input Class Initialized
DEBUG - 2012-09-17 15:34:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 15:34:26 --> Language Class Initialized
DEBUG - 2012-09-17 15:34:26 --> Loader Class Initialized
DEBUG - 2012-09-17 15:34:26 --> Helper loaded: url_helper
DEBUG - 2012-09-17 15:34:26 --> Controller Class Initialized
DEBUG - 2012-09-17 15:34:26 --> Model Class Initialized
DEBUG - 2012-09-17 15:34:26 --> Database Driver Class Initialized
DEBUG - 2012-09-17 15:34:26 --> Helper loaded: form_helper
DEBUG - 2012-09-17 15:34:26 --> Helper loaded: language_helper
DEBUG - 2012-09-17 15:34:26 --> Form Validation Class Initialized
ERROR - 2012-09-17 15:34:26 --> Could not find the language line "database_error"
DEBUG - 2012-09-17 15:35:25 --> Config Class Initialized
DEBUG - 2012-09-17 15:35:25 --> Hooks Class Initialized
DEBUG - 2012-09-17 15:35:25 --> Utf8 Class Initialized
DEBUG - 2012-09-17 15:35:25 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 15:35:25 --> URI Class Initialized
DEBUG - 2012-09-17 15:35:25 --> Router Class Initialized
DEBUG - 2012-09-17 15:35:25 --> Output Class Initialized
DEBUG - 2012-09-17 15:35:25 --> Security Class Initialized
DEBUG - 2012-09-17 15:35:25 --> Input Class Initialized
DEBUG - 2012-09-17 15:35:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 15:35:25 --> Language Class Initialized
DEBUG - 2012-09-17 15:35:25 --> Loader Class Initialized
DEBUG - 2012-09-17 15:35:25 --> Helper loaded: url_helper
DEBUG - 2012-09-17 15:35:25 --> Controller Class Initialized
DEBUG - 2012-09-17 15:35:25 --> Model Class Initialized
DEBUG - 2012-09-17 15:35:25 --> Database Driver Class Initialized
DEBUG - 2012-09-17 15:35:25 --> Helper loaded: form_helper
DEBUG - 2012-09-17 15:35:25 --> Helper loaded: language_helper
DEBUG - 2012-09-17 15:35:25 --> Form Validation Class Initialized
DEBUG - 2012-09-17 15:35:25 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 15:45:35 --> Config Class Initialized
DEBUG - 2012-09-17 15:45:35 --> Hooks Class Initialized
DEBUG - 2012-09-17 15:45:35 --> Utf8 Class Initialized
DEBUG - 2012-09-17 15:45:35 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 15:45:35 --> URI Class Initialized
DEBUG - 2012-09-17 15:45:35 --> Router Class Initialized
DEBUG - 2012-09-17 15:45:35 --> Output Class Initialized
DEBUG - 2012-09-17 15:45:35 --> Security Class Initialized
DEBUG - 2012-09-17 15:45:35 --> Input Class Initialized
DEBUG - 2012-09-17 15:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 15:45:35 --> Language Class Initialized
DEBUG - 2012-09-17 15:45:35 --> Loader Class Initialized
DEBUG - 2012-09-17 15:45:35 --> Helper loaded: url_helper
DEBUG - 2012-09-17 15:45:35 --> Controller Class Initialized
DEBUG - 2012-09-17 15:45:35 --> Model Class Initialized
DEBUG - 2012-09-17 15:45:35 --> Database Driver Class Initialized
DEBUG - 2012-09-17 15:45:35 --> Helper loaded: form_helper
DEBUG - 2012-09-17 15:45:35 --> Helper loaded: language_helper
DEBUG - 2012-09-17 15:45:35 --> Form Validation Class Initialized
DEBUG - 2012-09-17 15:45:35 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 15:47:54 --> Config Class Initialized
DEBUG - 2012-09-17 15:47:54 --> Hooks Class Initialized
DEBUG - 2012-09-17 15:47:54 --> Utf8 Class Initialized
DEBUG - 2012-09-17 15:47:54 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 15:47:54 --> URI Class Initialized
DEBUG - 2012-09-17 15:47:54 --> Router Class Initialized
DEBUG - 2012-09-17 15:47:54 --> Output Class Initialized
DEBUG - 2012-09-17 15:47:54 --> Security Class Initialized
DEBUG - 2012-09-17 15:47:54 --> Input Class Initialized
DEBUG - 2012-09-17 15:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 15:47:54 --> Language Class Initialized
DEBUG - 2012-09-17 15:47:54 --> Loader Class Initialized
DEBUG - 2012-09-17 15:47:54 --> Helper loaded: url_helper
DEBUG - 2012-09-17 15:47:54 --> Controller Class Initialized
DEBUG - 2012-09-17 15:47:54 --> Model Class Initialized
DEBUG - 2012-09-17 15:47:54 --> Database Driver Class Initialized
DEBUG - 2012-09-17 15:47:54 --> Helper loaded: form_helper
DEBUG - 2012-09-17 15:47:54 --> Helper loaded: language_helper
DEBUG - 2012-09-17 15:47:54 --> Form Validation Class Initialized
DEBUG - 2012-09-17 15:47:54 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 15:49:53 --> Config Class Initialized
DEBUG - 2012-09-17 15:49:53 --> Hooks Class Initialized
DEBUG - 2012-09-17 15:49:53 --> Utf8 Class Initialized
DEBUG - 2012-09-17 15:49:53 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 15:49:53 --> URI Class Initialized
DEBUG - 2012-09-17 15:49:53 --> Router Class Initialized
DEBUG - 2012-09-17 15:49:53 --> Output Class Initialized
DEBUG - 2012-09-17 15:49:53 --> Security Class Initialized
DEBUG - 2012-09-17 15:49:53 --> Input Class Initialized
DEBUG - 2012-09-17 15:49:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 15:49:53 --> Language Class Initialized
DEBUG - 2012-09-17 15:49:53 --> Loader Class Initialized
DEBUG - 2012-09-17 15:49:53 --> Helper loaded: url_helper
DEBUG - 2012-09-17 15:49:53 --> Controller Class Initialized
DEBUG - 2012-09-17 15:49:53 --> Model Class Initialized
DEBUG - 2012-09-17 15:49:53 --> Database Driver Class Initialized
DEBUG - 2012-09-17 15:49:53 --> Helper loaded: form_helper
DEBUG - 2012-09-17 15:49:53 --> Helper loaded: language_helper
DEBUG - 2012-09-17 15:49:53 --> Form Validation Class Initialized
DEBUG - 2012-09-17 15:49:53 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 15:52:34 --> Config Class Initialized
DEBUG - 2012-09-17 15:52:34 --> Hooks Class Initialized
DEBUG - 2012-09-17 15:52:34 --> Utf8 Class Initialized
DEBUG - 2012-09-17 15:52:34 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 15:52:34 --> URI Class Initialized
DEBUG - 2012-09-17 15:52:34 --> Router Class Initialized
DEBUG - 2012-09-17 15:52:34 --> Output Class Initialized
DEBUG - 2012-09-17 15:52:34 --> Security Class Initialized
DEBUG - 2012-09-17 15:52:34 --> Input Class Initialized
DEBUG - 2012-09-17 15:52:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 15:52:34 --> Language Class Initialized
DEBUG - 2012-09-17 15:52:34 --> Loader Class Initialized
DEBUG - 2012-09-17 15:52:34 --> Helper loaded: url_helper
DEBUG - 2012-09-17 15:52:34 --> Controller Class Initialized
DEBUG - 2012-09-17 15:52:34 --> Model Class Initialized
DEBUG - 2012-09-17 15:52:34 --> Database Driver Class Initialized
DEBUG - 2012-09-17 15:52:34 --> Helper loaded: form_helper
DEBUG - 2012-09-17 15:52:34 --> Helper loaded: language_helper
DEBUG - 2012-09-17 15:52:34 --> Form Validation Class Initialized
DEBUG - 2012-09-17 15:52:34 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 15:52:34 --> Final output sent to browser
DEBUG - 2012-09-17 15:52:34 --> Total execution time: 0.0388
DEBUG - 2012-09-17 15:53:57 --> Config Class Initialized
DEBUG - 2012-09-17 15:53:57 --> Hooks Class Initialized
DEBUG - 2012-09-17 15:53:57 --> Utf8 Class Initialized
DEBUG - 2012-09-17 15:53:57 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 15:53:57 --> URI Class Initialized
DEBUG - 2012-09-17 15:53:57 --> Router Class Initialized
DEBUG - 2012-09-17 15:53:57 --> Output Class Initialized
DEBUG - 2012-09-17 15:53:57 --> Security Class Initialized
DEBUG - 2012-09-17 15:53:57 --> Input Class Initialized
DEBUG - 2012-09-17 15:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 15:53:57 --> Language Class Initialized
DEBUG - 2012-09-17 15:53:57 --> Loader Class Initialized
DEBUG - 2012-09-17 15:53:57 --> Helper loaded: url_helper
DEBUG - 2012-09-17 15:53:57 --> Controller Class Initialized
DEBUG - 2012-09-17 15:53:57 --> Model Class Initialized
DEBUG - 2012-09-17 15:53:57 --> Database Driver Class Initialized
DEBUG - 2012-09-17 15:53:57 --> Helper loaded: form_helper
DEBUG - 2012-09-17 15:53:57 --> Helper loaded: language_helper
DEBUG - 2012-09-17 15:53:57 --> Form Validation Class Initialized
DEBUG - 2012-09-17 15:53:57 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 15:53:57 --> Final output sent to browser
DEBUG - 2012-09-17 15:53:57 --> Total execution time: 0.3019
DEBUG - 2012-09-17 15:54:42 --> Config Class Initialized
DEBUG - 2012-09-17 15:54:42 --> Hooks Class Initialized
DEBUG - 2012-09-17 15:54:42 --> Utf8 Class Initialized
DEBUG - 2012-09-17 15:54:42 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 15:54:42 --> URI Class Initialized
DEBUG - 2012-09-17 15:54:42 --> Router Class Initialized
DEBUG - 2012-09-17 15:54:42 --> Output Class Initialized
DEBUG - 2012-09-17 15:54:42 --> Security Class Initialized
DEBUG - 2012-09-17 15:54:42 --> Input Class Initialized
DEBUG - 2012-09-17 15:54:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 15:54:42 --> Language Class Initialized
DEBUG - 2012-09-17 15:54:42 --> Loader Class Initialized
DEBUG - 2012-09-17 15:54:42 --> Helper loaded: url_helper
DEBUG - 2012-09-17 15:54:42 --> Controller Class Initialized
DEBUG - 2012-09-17 15:54:42 --> Model Class Initialized
DEBUG - 2012-09-17 15:54:43 --> Database Driver Class Initialized
DEBUG - 2012-09-17 15:54:43 --> Helper loaded: form_helper
DEBUG - 2012-09-17 15:54:43 --> Helper loaded: language_helper
DEBUG - 2012-09-17 15:54:43 --> Form Validation Class Initialized
DEBUG - 2012-09-17 15:54:43 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 15:54:43 --> Final output sent to browser
DEBUG - 2012-09-17 15:54:43 --> Total execution time: 0.0480
DEBUG - 2012-09-17 15:57:30 --> Config Class Initialized
DEBUG - 2012-09-17 15:57:30 --> Hooks Class Initialized
DEBUG - 2012-09-17 15:57:30 --> Utf8 Class Initialized
DEBUG - 2012-09-17 15:57:30 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 15:57:30 --> URI Class Initialized
DEBUG - 2012-09-17 15:57:30 --> Router Class Initialized
DEBUG - 2012-09-17 15:57:30 --> Output Class Initialized
DEBUG - 2012-09-17 15:57:30 --> Security Class Initialized
DEBUG - 2012-09-17 15:57:30 --> Input Class Initialized
DEBUG - 2012-09-17 15:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 15:57:30 --> Language Class Initialized
DEBUG - 2012-09-17 15:57:30 --> Loader Class Initialized
DEBUG - 2012-09-17 15:57:30 --> Helper loaded: url_helper
DEBUG - 2012-09-17 15:57:30 --> Controller Class Initialized
DEBUG - 2012-09-17 15:57:30 --> Model Class Initialized
DEBUG - 2012-09-17 15:57:30 --> Database Driver Class Initialized
DEBUG - 2012-09-17 15:58:22 --> Config Class Initialized
DEBUG - 2012-09-17 15:58:22 --> Hooks Class Initialized
DEBUG - 2012-09-17 15:58:22 --> Utf8 Class Initialized
DEBUG - 2012-09-17 15:58:22 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 15:58:22 --> URI Class Initialized
DEBUG - 2012-09-17 15:58:22 --> Router Class Initialized
DEBUG - 2012-09-17 15:58:22 --> Output Class Initialized
DEBUG - 2012-09-17 15:58:22 --> Security Class Initialized
DEBUG - 2012-09-17 15:58:22 --> Input Class Initialized
DEBUG - 2012-09-17 15:58:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 15:58:22 --> Language Class Initialized
DEBUG - 2012-09-17 15:58:22 --> Loader Class Initialized
DEBUG - 2012-09-17 15:58:22 --> Helper loaded: url_helper
DEBUG - 2012-09-17 15:58:22 --> Controller Class Initialized
DEBUG - 2012-09-17 15:58:22 --> Model Class Initialized
DEBUG - 2012-09-17 15:58:22 --> Database Driver Class Initialized
DEBUG - 2012-09-17 15:58:22 --> Helper loaded: form_helper
DEBUG - 2012-09-17 15:58:22 --> Helper loaded: language_helper
DEBUG - 2012-09-17 15:58:22 --> Form Validation Class Initialized
DEBUG - 2012-09-17 15:58:22 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 15:58:22 --> Final output sent to browser
DEBUG - 2012-09-17 15:58:22 --> Total execution time: 0.0551
DEBUG - 2012-09-17 15:59:37 --> Config Class Initialized
DEBUG - 2012-09-17 15:59:37 --> Hooks Class Initialized
DEBUG - 2012-09-17 15:59:37 --> Utf8 Class Initialized
DEBUG - 2012-09-17 15:59:37 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 15:59:37 --> URI Class Initialized
DEBUG - 2012-09-17 15:59:37 --> Router Class Initialized
DEBUG - 2012-09-17 15:59:37 --> Output Class Initialized
DEBUG - 2012-09-17 15:59:37 --> Security Class Initialized
DEBUG - 2012-09-17 15:59:37 --> Input Class Initialized
DEBUG - 2012-09-17 15:59:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 15:59:37 --> Language Class Initialized
DEBUG - 2012-09-17 15:59:37 --> Loader Class Initialized
DEBUG - 2012-09-17 15:59:37 --> Helper loaded: url_helper
DEBUG - 2012-09-17 15:59:37 --> Controller Class Initialized
DEBUG - 2012-09-17 15:59:37 --> Model Class Initialized
DEBUG - 2012-09-17 15:59:37 --> Database Driver Class Initialized
DEBUG - 2012-09-17 15:59:37 --> Helper loaded: form_helper
DEBUG - 2012-09-17 15:59:37 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 15:59:37 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-17 15:59:37 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-17 15:59:37 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 15:59:37 --> Final output sent to browser
DEBUG - 2012-09-17 15:59:37 --> Total execution time: 0.0384
DEBUG - 2012-09-17 15:59:39 --> Config Class Initialized
DEBUG - 2012-09-17 15:59:39 --> Hooks Class Initialized
DEBUG - 2012-09-17 15:59:39 --> Utf8 Class Initialized
DEBUG - 2012-09-17 15:59:39 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 15:59:39 --> URI Class Initialized
DEBUG - 2012-09-17 15:59:39 --> Router Class Initialized
DEBUG - 2012-09-17 15:59:39 --> Output Class Initialized
DEBUG - 2012-09-17 15:59:39 --> Security Class Initialized
DEBUG - 2012-09-17 15:59:39 --> Input Class Initialized
DEBUG - 2012-09-17 15:59:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 15:59:39 --> Language Class Initialized
DEBUG - 2012-09-17 15:59:39 --> Loader Class Initialized
DEBUG - 2012-09-17 15:59:39 --> Helper loaded: url_helper
DEBUG - 2012-09-17 15:59:39 --> Controller Class Initialized
DEBUG - 2012-09-17 15:59:39 --> Model Class Initialized
DEBUG - 2012-09-17 15:59:39 --> Database Driver Class Initialized
DEBUG - 2012-09-17 15:59:39 --> Helper loaded: form_helper
DEBUG - 2012-09-17 15:59:39 --> Helper loaded: language_helper
DEBUG - 2012-09-17 15:59:39 --> Form Validation Class Initialized
DEBUG - 2012-09-17 15:59:39 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 15:59:39 --> Final output sent to browser
DEBUG - 2012-09-17 15:59:39 --> Total execution time: 0.0403
DEBUG - 2012-09-17 15:59:54 --> Config Class Initialized
DEBUG - 2012-09-17 15:59:54 --> Hooks Class Initialized
DEBUG - 2012-09-17 15:59:54 --> Utf8 Class Initialized
DEBUG - 2012-09-17 15:59:54 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 15:59:54 --> URI Class Initialized
DEBUG - 2012-09-17 15:59:54 --> Router Class Initialized
DEBUG - 2012-09-17 15:59:54 --> Output Class Initialized
DEBUG - 2012-09-17 15:59:54 --> Security Class Initialized
DEBUG - 2012-09-17 15:59:54 --> Input Class Initialized
DEBUG - 2012-09-17 15:59:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 15:59:54 --> Language Class Initialized
DEBUG - 2012-09-17 15:59:54 --> Loader Class Initialized
DEBUG - 2012-09-17 15:59:54 --> Helper loaded: url_helper
DEBUG - 2012-09-17 15:59:54 --> Controller Class Initialized
DEBUG - 2012-09-17 15:59:54 --> Model Class Initialized
DEBUG - 2012-09-17 15:59:54 --> Database Driver Class Initialized
DEBUG - 2012-09-17 15:59:54 --> Helper loaded: form_helper
DEBUG - 2012-09-17 15:59:54 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 15:59:54 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-17 15:59:54 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-17 15:59:54 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 15:59:54 --> Final output sent to browser
DEBUG - 2012-09-17 15:59:54 --> Total execution time: 0.0428
DEBUG - 2012-09-17 15:59:56 --> Config Class Initialized
DEBUG - 2012-09-17 15:59:56 --> Hooks Class Initialized
DEBUG - 2012-09-17 15:59:56 --> Utf8 Class Initialized
DEBUG - 2012-09-17 15:59:56 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 15:59:56 --> URI Class Initialized
DEBUG - 2012-09-17 15:59:56 --> Router Class Initialized
DEBUG - 2012-09-17 15:59:56 --> Output Class Initialized
DEBUG - 2012-09-17 15:59:56 --> Security Class Initialized
DEBUG - 2012-09-17 15:59:56 --> Input Class Initialized
DEBUG - 2012-09-17 15:59:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 15:59:56 --> Language Class Initialized
DEBUG - 2012-09-17 15:59:56 --> Loader Class Initialized
DEBUG - 2012-09-17 15:59:56 --> Helper loaded: url_helper
DEBUG - 2012-09-17 15:59:56 --> Controller Class Initialized
DEBUG - 2012-09-17 15:59:56 --> Model Class Initialized
DEBUG - 2012-09-17 15:59:56 --> Database Driver Class Initialized
DEBUG - 2012-09-17 15:59:56 --> Helper loaded: form_helper
DEBUG - 2012-09-17 15:59:56 --> Helper loaded: language_helper
DEBUG - 2012-09-17 15:59:56 --> Form Validation Class Initialized
DEBUG - 2012-09-17 15:59:56 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 15:59:56 --> Final output sent to browser
DEBUG - 2012-09-17 15:59:56 --> Total execution time: 0.0457
DEBUG - 2012-09-17 16:03:50 --> Config Class Initialized
DEBUG - 2012-09-17 16:03:50 --> Hooks Class Initialized
DEBUG - 2012-09-17 16:03:50 --> Utf8 Class Initialized
DEBUG - 2012-09-17 16:03:50 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 16:03:50 --> URI Class Initialized
DEBUG - 2012-09-17 16:03:50 --> Router Class Initialized
DEBUG - 2012-09-17 16:03:50 --> Output Class Initialized
DEBUG - 2012-09-17 16:03:50 --> Security Class Initialized
DEBUG - 2012-09-17 16:03:50 --> Input Class Initialized
DEBUG - 2012-09-17 16:03:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 16:03:50 --> Language Class Initialized
DEBUG - 2012-09-17 16:03:50 --> Loader Class Initialized
DEBUG - 2012-09-17 16:03:50 --> Helper loaded: url_helper
DEBUG - 2012-09-17 16:03:50 --> Controller Class Initialized
DEBUG - 2012-09-17 16:03:50 --> Model Class Initialized
DEBUG - 2012-09-17 16:03:50 --> Database Driver Class Initialized
DEBUG - 2012-09-17 16:03:50 --> Helper loaded: form_helper
DEBUG - 2012-09-17 16:03:50 --> Helper loaded: language_helper
DEBUG - 2012-09-17 16:03:50 --> Form Validation Class Initialized
DEBUG - 2012-09-17 16:03:50 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 16:03:50 --> Final output sent to browser
DEBUG - 2012-09-17 16:03:50 --> Total execution time: 0.1869
DEBUG - 2012-09-17 16:05:06 --> Config Class Initialized
DEBUG - 2012-09-17 16:05:06 --> Hooks Class Initialized
DEBUG - 2012-09-17 16:05:06 --> Utf8 Class Initialized
DEBUG - 2012-09-17 16:05:06 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 16:05:06 --> URI Class Initialized
DEBUG - 2012-09-17 16:05:06 --> Router Class Initialized
DEBUG - 2012-09-17 16:05:06 --> Output Class Initialized
DEBUG - 2012-09-17 16:05:06 --> Security Class Initialized
DEBUG - 2012-09-17 16:05:06 --> Input Class Initialized
DEBUG - 2012-09-17 16:05:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 16:05:06 --> Language Class Initialized
DEBUG - 2012-09-17 16:05:06 --> Loader Class Initialized
DEBUG - 2012-09-17 16:05:06 --> Helper loaded: url_helper
DEBUG - 2012-09-17 16:05:06 --> Controller Class Initialized
DEBUG - 2012-09-17 16:05:06 --> Model Class Initialized
DEBUG - 2012-09-17 16:05:06 --> Database Driver Class Initialized
DEBUG - 2012-09-17 16:05:06 --> Helper loaded: form_helper
DEBUG - 2012-09-17 16:05:06 --> Helper loaded: language_helper
DEBUG - 2012-09-17 16:05:06 --> Form Validation Class Initialized
DEBUG - 2012-09-17 16:05:06 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 16:05:30 --> Config Class Initialized
DEBUG - 2012-09-17 16:05:30 --> Hooks Class Initialized
DEBUG - 2012-09-17 16:05:30 --> Utf8 Class Initialized
DEBUG - 2012-09-17 16:05:30 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 16:05:30 --> URI Class Initialized
DEBUG - 2012-09-17 16:05:30 --> Router Class Initialized
DEBUG - 2012-09-17 16:05:30 --> Output Class Initialized
DEBUG - 2012-09-17 16:05:30 --> Security Class Initialized
DEBUG - 2012-09-17 16:05:30 --> Input Class Initialized
DEBUG - 2012-09-17 16:05:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 16:05:30 --> Language Class Initialized
DEBUG - 2012-09-17 16:05:30 --> Loader Class Initialized
DEBUG - 2012-09-17 16:05:30 --> Helper loaded: url_helper
DEBUG - 2012-09-17 16:05:30 --> Controller Class Initialized
DEBUG - 2012-09-17 16:05:30 --> Model Class Initialized
DEBUG - 2012-09-17 16:05:30 --> Database Driver Class Initialized
DEBUG - 2012-09-17 16:05:30 --> Helper loaded: form_helper
DEBUG - 2012-09-17 16:05:30 --> Helper loaded: language_helper
DEBUG - 2012-09-17 16:05:30 --> Form Validation Class Initialized
DEBUG - 2012-09-17 16:05:30 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-09-17 16:05:31 --> Final output sent to browser
DEBUG - 2012-09-17 16:05:31 --> Total execution time: 0.7954
DEBUG - 2012-09-17 16:05:43 --> Config Class Initialized
DEBUG - 2012-09-17 16:05:43 --> Hooks Class Initialized
DEBUG - 2012-09-17 16:05:43 --> Utf8 Class Initialized
DEBUG - 2012-09-17 16:05:43 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 16:05:43 --> URI Class Initialized
DEBUG - 2012-09-17 16:05:43 --> Router Class Initialized
DEBUG - 2012-09-17 16:05:43 --> Output Class Initialized
DEBUG - 2012-09-17 16:05:43 --> Security Class Initialized
DEBUG - 2012-09-17 16:05:43 --> Input Class Initialized
DEBUG - 2012-09-17 16:05:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 16:05:43 --> Language Class Initialized
DEBUG - 2012-09-17 16:05:43 --> Loader Class Initialized
DEBUG - 2012-09-17 16:05:43 --> Helper loaded: url_helper
DEBUG - 2012-09-17 16:05:43 --> Controller Class Initialized
DEBUG - 2012-09-17 16:05:43 --> Model Class Initialized
DEBUG - 2012-09-17 16:05:43 --> Database Driver Class Initialized
DEBUG - 2012-09-17 16:05:44 --> Final output sent to browser
DEBUG - 2012-09-17 16:05:44 --> Total execution time: 0.7455
DEBUG - 2012-09-17 16:06:00 --> Config Class Initialized
DEBUG - 2012-09-17 16:06:00 --> Hooks Class Initialized
DEBUG - 2012-09-17 16:06:00 --> Utf8 Class Initialized
DEBUG - 2012-09-17 16:06:00 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 16:06:00 --> URI Class Initialized
DEBUG - 2012-09-17 16:06:00 --> Router Class Initialized
DEBUG - 2012-09-17 16:06:00 --> Output Class Initialized
DEBUG - 2012-09-17 16:06:00 --> Security Class Initialized
DEBUG - 2012-09-17 16:06:00 --> Input Class Initialized
DEBUG - 2012-09-17 16:06:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 16:06:00 --> Language Class Initialized
DEBUG - 2012-09-17 16:06:00 --> Loader Class Initialized
DEBUG - 2012-09-17 16:06:00 --> Helper loaded: url_helper
DEBUG - 2012-09-17 16:06:00 --> Controller Class Initialized
DEBUG - 2012-09-17 16:06:00 --> Model Class Initialized
DEBUG - 2012-09-17 16:06:00 --> Database Driver Class Initialized
ERROR - 2012-09-17 16:06:00 --> 404 Page Not Found --> pricing/frames
DEBUG - 2012-09-17 16:09:49 --> Config Class Initialized
DEBUG - 2012-09-17 16:09:49 --> Hooks Class Initialized
DEBUG - 2012-09-17 16:09:49 --> Utf8 Class Initialized
DEBUG - 2012-09-17 16:09:49 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 16:09:49 --> URI Class Initialized
DEBUG - 2012-09-17 16:09:49 --> Router Class Initialized
DEBUG - 2012-09-17 16:09:49 --> Output Class Initialized
DEBUG - 2012-09-17 16:09:49 --> Security Class Initialized
DEBUG - 2012-09-17 16:09:49 --> Input Class Initialized
DEBUG - 2012-09-17 16:09:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 16:09:49 --> Language Class Initialized
DEBUG - 2012-09-17 16:09:49 --> Loader Class Initialized
DEBUG - 2012-09-17 16:09:49 --> Helper loaded: url_helper
DEBUG - 2012-09-17 16:09:49 --> Controller Class Initialized
DEBUG - 2012-09-17 16:09:49 --> Model Class Initialized
DEBUG - 2012-09-17 16:09:49 --> Database Driver Class Initialized
DEBUG - 2012-09-17 16:09:49 --> Helper loaded: form_helper
DEBUG - 2012-09-17 16:09:49 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 16:09:49 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-17 16:09:49 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-17 16:09:49 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 16:09:49 --> Final output sent to browser
DEBUG - 2012-09-17 16:09:49 --> Total execution time: 0.0425
DEBUG - 2012-09-17 16:09:54 --> Config Class Initialized
DEBUG - 2012-09-17 16:09:54 --> Hooks Class Initialized
DEBUG - 2012-09-17 16:09:54 --> Utf8 Class Initialized
DEBUG - 2012-09-17 16:09:54 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 16:09:54 --> URI Class Initialized
DEBUG - 2012-09-17 16:09:54 --> Router Class Initialized
DEBUG - 2012-09-17 16:09:54 --> Output Class Initialized
DEBUG - 2012-09-17 16:09:54 --> Security Class Initialized
DEBUG - 2012-09-17 16:09:54 --> Input Class Initialized
DEBUG - 2012-09-17 16:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 16:09:54 --> Language Class Initialized
DEBUG - 2012-09-17 16:09:54 --> Loader Class Initialized
DEBUG - 2012-09-17 16:09:54 --> Helper loaded: url_helper
DEBUG - 2012-09-17 16:09:54 --> Controller Class Initialized
DEBUG - 2012-09-17 16:09:54 --> Model Class Initialized
DEBUG - 2012-09-17 16:09:54 --> Database Driver Class Initialized
DEBUG - 2012-09-17 16:09:54 --> Helper loaded: form_helper
DEBUG - 2012-09-17 16:09:54 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 16:09:54 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-17 16:09:54 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-09-17 16:09:54 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 16:09:54 --> Final output sent to browser
DEBUG - 2012-09-17 16:09:54 --> Total execution time: 0.0375
DEBUG - 2012-09-17 17:50:33 --> Config Class Initialized
DEBUG - 2012-09-17 17:50:33 --> Hooks Class Initialized
DEBUG - 2012-09-17 17:50:33 --> Utf8 Class Initialized
DEBUG - 2012-09-17 17:50:33 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 17:50:33 --> URI Class Initialized
DEBUG - 2012-09-17 17:50:33 --> Router Class Initialized
DEBUG - 2012-09-17 17:50:33 --> Output Class Initialized
DEBUG - 2012-09-17 17:50:33 --> Security Class Initialized
DEBUG - 2012-09-17 17:50:33 --> Input Class Initialized
DEBUG - 2012-09-17 17:50:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 17:50:33 --> Language Class Initialized
DEBUG - 2012-09-17 17:50:33 --> Loader Class Initialized
DEBUG - 2012-09-17 17:50:33 --> Helper loaded: url_helper
DEBUG - 2012-09-17 17:50:33 --> Controller Class Initialized
DEBUG - 2012-09-17 17:50:33 --> Model Class Initialized
DEBUG - 2012-09-17 17:50:33 --> Database Driver Class Initialized
DEBUG - 2012-09-17 17:50:33 --> Helper loaded: form_helper
DEBUG - 2012-09-17 17:50:33 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 17:50:33 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-17 17:50:33 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-17 17:50:33 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 17:50:33 --> Final output sent to browser
DEBUG - 2012-09-17 17:50:33 --> Total execution time: 0.0839
DEBUG - 2012-09-17 18:47:06 --> Config Class Initialized
DEBUG - 2012-09-17 18:47:06 --> Hooks Class Initialized
DEBUG - 2012-09-17 18:47:06 --> Utf8 Class Initialized
DEBUG - 2012-09-17 18:47:06 --> UTF-8 Support Disabled
DEBUG - 2012-09-17 18:47:06 --> URI Class Initialized
DEBUG - 2012-09-17 18:47:06 --> Router Class Initialized
DEBUG - 2012-09-17 18:47:06 --> Output Class Initialized
DEBUG - 2012-09-17 18:47:06 --> Security Class Initialized
DEBUG - 2012-09-17 18:47:06 --> Input Class Initialized
DEBUG - 2012-09-17 18:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 18:47:06 --> Language Class Initialized
DEBUG - 2012-09-17 18:47:06 --> Loader Class Initialized
DEBUG - 2012-09-17 18:47:06 --> Helper loaded: url_helper
DEBUG - 2012-09-17 18:47:06 --> Controller Class Initialized
DEBUG - 2012-09-17 18:47:06 --> Model Class Initialized
DEBUG - 2012-09-17 18:47:06 --> Database Driver Class Initialized
DEBUG - 2012-09-17 18:47:06 --> Helper loaded: form_helper
DEBUG - 2012-09-17 18:47:06 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-09-17 18:47:06 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-09-17 18:47:06 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-09-17 18:47:06 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-09-17 18:47:06 --> Final output sent to browser
DEBUG - 2012-09-17 18:47:06 --> Total execution time: 0.0539
