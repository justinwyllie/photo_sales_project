<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-10-02 00:22:12 --> Config Class Initialized
DEBUG - 2012-10-02 00:22:12 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:22:12 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:22:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:22:12 --> URI Class Initialized
DEBUG - 2012-10-02 00:22:12 --> Router Class Initialized
DEBUG - 2012-10-02 00:22:12 --> Output Class Initialized
DEBUG - 2012-10-02 00:22:12 --> Security Class Initialized
DEBUG - 2012-10-02 00:22:12 --> Input Class Initialized
DEBUG - 2012-10-02 00:22:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:22:12 --> Language Class Initialized
DEBUG - 2012-10-02 00:22:12 --> Loader Class Initialized
DEBUG - 2012-10-02 00:22:12 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:22:12 --> Controller Class Initialized
DEBUG - 2012-10-02 00:22:12 --> Model Class Initialized
DEBUG - 2012-10-02 00:22:12 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:22:12 --> Helper loaded: form_helper
DEBUG - 2012-10-02 00:22:12 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 00:22:12 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 00:22:12 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 00:22:12 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 00:22:12 --> Final output sent to browser
DEBUG - 2012-10-02 00:22:12 --> Total execution time: 0.0540
DEBUG - 2012-10-02 00:22:22 --> Config Class Initialized
DEBUG - 2012-10-02 00:22:22 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:22:22 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:22:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:22:22 --> URI Class Initialized
DEBUG - 2012-10-02 00:22:22 --> Router Class Initialized
DEBUG - 2012-10-02 00:22:22 --> Output Class Initialized
DEBUG - 2012-10-02 00:22:22 --> Security Class Initialized
DEBUG - 2012-10-02 00:22:22 --> Input Class Initialized
DEBUG - 2012-10-02 00:22:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:22:22 --> Language Class Initialized
DEBUG - 2012-10-02 00:22:23 --> Loader Class Initialized
DEBUG - 2012-10-02 00:22:23 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:22:23 --> Controller Class Initialized
DEBUG - 2012-10-02 00:22:23 --> Model Class Initialized
DEBUG - 2012-10-02 00:22:23 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:22:40 --> Config Class Initialized
DEBUG - 2012-10-02 00:22:40 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:22:40 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:22:40 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:22:40 --> URI Class Initialized
DEBUG - 2012-10-02 00:22:40 --> Router Class Initialized
DEBUG - 2012-10-02 00:22:40 --> Output Class Initialized
DEBUG - 2012-10-02 00:22:40 --> Security Class Initialized
DEBUG - 2012-10-02 00:22:40 --> Input Class Initialized
DEBUG - 2012-10-02 00:22:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:22:40 --> Language Class Initialized
DEBUG - 2012-10-02 00:22:40 --> Loader Class Initialized
DEBUG - 2012-10-02 00:22:40 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:22:40 --> Controller Class Initialized
DEBUG - 2012-10-02 00:22:40 --> Model Class Initialized
DEBUG - 2012-10-02 00:22:40 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:22:40 --> Helper loaded: form_helper
DEBUG - 2012-10-02 00:22:40 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 00:22:40 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 00:22:40 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 00:22:40 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 00:22:40 --> Final output sent to browser
DEBUG - 2012-10-02 00:22:40 --> Total execution time: 0.0390
DEBUG - 2012-10-02 00:22:44 --> Config Class Initialized
DEBUG - 2012-10-02 00:22:44 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:22:44 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:22:44 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:22:44 --> URI Class Initialized
DEBUG - 2012-10-02 00:22:44 --> Router Class Initialized
DEBUG - 2012-10-02 00:22:44 --> Output Class Initialized
DEBUG - 2012-10-02 00:22:44 --> Security Class Initialized
DEBUG - 2012-10-02 00:22:44 --> Input Class Initialized
DEBUG - 2012-10-02 00:22:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:22:44 --> Language Class Initialized
DEBUG - 2012-10-02 00:22:44 --> Loader Class Initialized
DEBUG - 2012-10-02 00:22:44 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:22:44 --> Controller Class Initialized
DEBUG - 2012-10-02 00:22:44 --> Model Class Initialized
DEBUG - 2012-10-02 00:22:44 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:23:22 --> Config Class Initialized
DEBUG - 2012-10-02 00:23:22 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:23:22 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:23:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:23:22 --> URI Class Initialized
DEBUG - 2012-10-02 00:23:22 --> Router Class Initialized
DEBUG - 2012-10-02 00:23:22 --> Output Class Initialized
DEBUG - 2012-10-02 00:23:22 --> Security Class Initialized
DEBUG - 2012-10-02 00:23:22 --> Input Class Initialized
DEBUG - 2012-10-02 00:23:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:23:22 --> Language Class Initialized
DEBUG - 2012-10-02 00:23:22 --> Loader Class Initialized
DEBUG - 2012-10-02 00:23:22 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:23:22 --> Controller Class Initialized
DEBUG - 2012-10-02 00:23:22 --> Model Class Initialized
DEBUG - 2012-10-02 00:23:22 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:23:22 --> Helper loaded: form_helper
DEBUG - 2012-10-02 00:23:22 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 00:23:22 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 00:23:22 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 00:23:22 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 00:23:22 --> Final output sent to browser
DEBUG - 2012-10-02 00:23:22 --> Total execution time: 0.0438
DEBUG - 2012-10-02 00:23:28 --> Config Class Initialized
DEBUG - 2012-10-02 00:23:28 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:23:28 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:23:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:23:28 --> URI Class Initialized
DEBUG - 2012-10-02 00:23:28 --> Router Class Initialized
DEBUG - 2012-10-02 00:23:28 --> Output Class Initialized
DEBUG - 2012-10-02 00:23:28 --> Security Class Initialized
DEBUG - 2012-10-02 00:23:28 --> Input Class Initialized
DEBUG - 2012-10-02 00:23:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:23:28 --> Language Class Initialized
DEBUG - 2012-10-02 00:23:28 --> Loader Class Initialized
DEBUG - 2012-10-02 00:23:28 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:23:28 --> Controller Class Initialized
DEBUG - 2012-10-02 00:23:28 --> Model Class Initialized
DEBUG - 2012-10-02 00:23:28 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:24:19 --> Config Class Initialized
DEBUG - 2012-10-02 00:24:19 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:24:19 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:24:19 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:24:19 --> URI Class Initialized
DEBUG - 2012-10-02 00:24:19 --> Router Class Initialized
DEBUG - 2012-10-02 00:24:19 --> Output Class Initialized
DEBUG - 2012-10-02 00:24:19 --> Security Class Initialized
DEBUG - 2012-10-02 00:24:19 --> Input Class Initialized
DEBUG - 2012-10-02 00:24:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:24:19 --> Language Class Initialized
DEBUG - 2012-10-02 00:24:19 --> Loader Class Initialized
DEBUG - 2012-10-02 00:24:19 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:24:19 --> Controller Class Initialized
DEBUG - 2012-10-02 00:24:19 --> Model Class Initialized
DEBUG - 2012-10-02 00:24:19 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:24:19 --> Helper loaded: form_helper
DEBUG - 2012-10-02 00:24:19 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 00:24:19 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 00:24:19 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 00:24:19 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 00:24:19 --> Final output sent to browser
DEBUG - 2012-10-02 00:24:19 --> Total execution time: 0.0457
DEBUG - 2012-10-02 00:24:58 --> Config Class Initialized
DEBUG - 2012-10-02 00:24:58 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:24:58 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:24:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:24:58 --> URI Class Initialized
DEBUG - 2012-10-02 00:24:58 --> Router Class Initialized
DEBUG - 2012-10-02 00:24:58 --> Output Class Initialized
DEBUG - 2012-10-02 00:24:58 --> Security Class Initialized
DEBUG - 2012-10-02 00:24:58 --> Input Class Initialized
DEBUG - 2012-10-02 00:24:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:24:58 --> Language Class Initialized
DEBUG - 2012-10-02 00:24:58 --> Loader Class Initialized
DEBUG - 2012-10-02 00:24:58 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:24:58 --> Controller Class Initialized
DEBUG - 2012-10-02 00:24:58 --> Model Class Initialized
DEBUG - 2012-10-02 00:24:58 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:24:58 --> Helper loaded: form_helper
DEBUG - 2012-10-02 00:24:58 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 00:24:58 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 00:24:58 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 00:24:58 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 00:24:58 --> Final output sent to browser
DEBUG - 2012-10-02 00:24:58 --> Total execution time: 0.0441
DEBUG - 2012-10-02 00:25:34 --> Config Class Initialized
DEBUG - 2012-10-02 00:25:34 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:25:34 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:25:34 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:25:34 --> URI Class Initialized
DEBUG - 2012-10-02 00:25:34 --> Router Class Initialized
DEBUG - 2012-10-02 00:25:34 --> Output Class Initialized
DEBUG - 2012-10-02 00:25:34 --> Security Class Initialized
DEBUG - 2012-10-02 00:25:34 --> Input Class Initialized
DEBUG - 2012-10-02 00:25:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:25:34 --> Language Class Initialized
DEBUG - 2012-10-02 00:25:34 --> Loader Class Initialized
DEBUG - 2012-10-02 00:25:34 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:25:34 --> Controller Class Initialized
DEBUG - 2012-10-02 00:25:34 --> Model Class Initialized
DEBUG - 2012-10-02 00:25:34 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:25:34 --> Helper loaded: form_helper
DEBUG - 2012-10-02 00:25:34 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 00:25:34 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 00:25:34 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 00:25:34 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 00:25:34 --> Final output sent to browser
DEBUG - 2012-10-02 00:25:34 --> Total execution time: 0.0442
DEBUG - 2012-10-02 00:26:22 --> Config Class Initialized
DEBUG - 2012-10-02 00:26:22 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:26:22 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:26:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:26:22 --> URI Class Initialized
DEBUG - 2012-10-02 00:26:22 --> Router Class Initialized
DEBUG - 2012-10-02 00:26:22 --> Output Class Initialized
DEBUG - 2012-10-02 00:26:22 --> Security Class Initialized
DEBUG - 2012-10-02 00:26:22 --> Input Class Initialized
DEBUG - 2012-10-02 00:26:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:26:22 --> Language Class Initialized
DEBUG - 2012-10-02 00:26:22 --> Loader Class Initialized
DEBUG - 2012-10-02 00:26:22 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:26:22 --> Controller Class Initialized
DEBUG - 2012-10-02 00:26:22 --> Model Class Initialized
DEBUG - 2012-10-02 00:26:22 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:26:22 --> Helper loaded: form_helper
DEBUG - 2012-10-02 00:26:22 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 00:26:22 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 00:26:22 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 00:26:22 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 00:26:22 --> Final output sent to browser
DEBUG - 2012-10-02 00:26:22 --> Total execution time: 0.0455
DEBUG - 2012-10-02 00:27:12 --> Config Class Initialized
DEBUG - 2012-10-02 00:27:12 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:27:12 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:27:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:27:12 --> URI Class Initialized
DEBUG - 2012-10-02 00:27:12 --> Router Class Initialized
DEBUG - 2012-10-02 00:27:12 --> Output Class Initialized
DEBUG - 2012-10-02 00:27:12 --> Security Class Initialized
DEBUG - 2012-10-02 00:27:12 --> Input Class Initialized
DEBUG - 2012-10-02 00:27:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:27:12 --> Language Class Initialized
DEBUG - 2012-10-02 00:27:12 --> Loader Class Initialized
DEBUG - 2012-10-02 00:27:12 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:27:12 --> Controller Class Initialized
DEBUG - 2012-10-02 00:27:12 --> Model Class Initialized
DEBUG - 2012-10-02 00:27:12 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:27:12 --> Helper loaded: form_helper
DEBUG - 2012-10-02 00:27:12 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 00:27:12 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 00:27:12 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 00:27:12 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 00:27:12 --> Final output sent to browser
DEBUG - 2012-10-02 00:27:12 --> Total execution time: 0.0506
DEBUG - 2012-10-02 00:27:25 --> Config Class Initialized
DEBUG - 2012-10-02 00:27:25 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:27:25 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:27:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:27:25 --> URI Class Initialized
DEBUG - 2012-10-02 00:27:25 --> Router Class Initialized
DEBUG - 2012-10-02 00:27:25 --> Output Class Initialized
DEBUG - 2012-10-02 00:27:25 --> Security Class Initialized
DEBUG - 2012-10-02 00:27:25 --> Input Class Initialized
DEBUG - 2012-10-02 00:27:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:27:25 --> Language Class Initialized
DEBUG - 2012-10-02 00:27:25 --> Loader Class Initialized
DEBUG - 2012-10-02 00:27:25 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:27:25 --> Controller Class Initialized
DEBUG - 2012-10-02 00:27:25 --> Model Class Initialized
DEBUG - 2012-10-02 00:27:25 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:27:36 --> Config Class Initialized
DEBUG - 2012-10-02 00:27:36 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:27:36 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:27:36 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:27:36 --> URI Class Initialized
DEBUG - 2012-10-02 00:27:36 --> Router Class Initialized
DEBUG - 2012-10-02 00:27:36 --> Output Class Initialized
DEBUG - 2012-10-02 00:27:36 --> Security Class Initialized
DEBUG - 2012-10-02 00:27:36 --> Input Class Initialized
DEBUG - 2012-10-02 00:27:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:27:36 --> Language Class Initialized
DEBUG - 2012-10-02 00:27:36 --> Loader Class Initialized
DEBUG - 2012-10-02 00:27:36 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:27:36 --> Controller Class Initialized
DEBUG - 2012-10-02 00:27:36 --> Model Class Initialized
DEBUG - 2012-10-02 00:27:36 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:29:03 --> Config Class Initialized
DEBUG - 2012-10-02 00:29:03 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:29:03 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:29:03 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:29:03 --> URI Class Initialized
DEBUG - 2012-10-02 00:29:03 --> Router Class Initialized
DEBUG - 2012-10-02 00:29:03 --> Output Class Initialized
DEBUG - 2012-10-02 00:29:03 --> Security Class Initialized
DEBUG - 2012-10-02 00:29:03 --> Input Class Initialized
DEBUG - 2012-10-02 00:29:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:29:03 --> Language Class Initialized
DEBUG - 2012-10-02 00:29:03 --> Loader Class Initialized
DEBUG - 2012-10-02 00:29:03 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:29:03 --> Controller Class Initialized
DEBUG - 2012-10-02 00:29:03 --> Model Class Initialized
DEBUG - 2012-10-02 00:29:03 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:30:01 --> Config Class Initialized
DEBUG - 2012-10-02 00:30:01 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:30:01 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:30:01 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:30:01 --> URI Class Initialized
DEBUG - 2012-10-02 00:30:01 --> Router Class Initialized
DEBUG - 2012-10-02 00:30:01 --> Output Class Initialized
DEBUG - 2012-10-02 00:30:01 --> Security Class Initialized
DEBUG - 2012-10-02 00:30:01 --> Input Class Initialized
DEBUG - 2012-10-02 00:30:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:30:01 --> Language Class Initialized
DEBUG - 2012-10-02 00:30:01 --> Loader Class Initialized
DEBUG - 2012-10-02 00:30:01 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:30:01 --> Controller Class Initialized
DEBUG - 2012-10-02 00:30:01 --> Model Class Initialized
DEBUG - 2012-10-02 00:30:01 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:30:01 --> Helper loaded: form_helper
DEBUG - 2012-10-02 00:30:01 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 00:30:01 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 00:30:01 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 00:30:01 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 00:30:01 --> Final output sent to browser
DEBUG - 2012-10-02 00:30:01 --> Total execution time: 0.0417
DEBUG - 2012-10-02 00:30:18 --> Config Class Initialized
DEBUG - 2012-10-02 00:30:18 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:30:18 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:30:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:30:18 --> URI Class Initialized
DEBUG - 2012-10-02 00:30:18 --> Router Class Initialized
DEBUG - 2012-10-02 00:30:18 --> Output Class Initialized
DEBUG - 2012-10-02 00:30:18 --> Security Class Initialized
DEBUG - 2012-10-02 00:30:18 --> Input Class Initialized
DEBUG - 2012-10-02 00:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:30:18 --> Language Class Initialized
DEBUG - 2012-10-02 00:30:18 --> Loader Class Initialized
DEBUG - 2012-10-02 00:30:18 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:30:18 --> Controller Class Initialized
DEBUG - 2012-10-02 00:30:18 --> Model Class Initialized
DEBUG - 2012-10-02 00:30:18 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:33:43 --> Config Class Initialized
DEBUG - 2012-10-02 00:33:43 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:33:43 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:33:43 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:33:43 --> URI Class Initialized
DEBUG - 2012-10-02 00:33:43 --> Router Class Initialized
DEBUG - 2012-10-02 00:33:43 --> Output Class Initialized
DEBUG - 2012-10-02 00:33:43 --> Security Class Initialized
DEBUG - 2012-10-02 00:33:43 --> Input Class Initialized
DEBUG - 2012-10-02 00:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:33:43 --> Language Class Initialized
DEBUG - 2012-10-02 00:33:43 --> Loader Class Initialized
DEBUG - 2012-10-02 00:33:43 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:33:43 --> Controller Class Initialized
DEBUG - 2012-10-02 00:33:43 --> Model Class Initialized
DEBUG - 2012-10-02 00:33:43 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:34:19 --> Config Class Initialized
DEBUG - 2012-10-02 00:34:19 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:34:19 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:34:19 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:34:19 --> URI Class Initialized
DEBUG - 2012-10-02 00:34:19 --> Router Class Initialized
DEBUG - 2012-10-02 00:34:19 --> Output Class Initialized
DEBUG - 2012-10-02 00:34:19 --> Security Class Initialized
DEBUG - 2012-10-02 00:34:19 --> Input Class Initialized
DEBUG - 2012-10-02 00:34:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:34:19 --> Language Class Initialized
DEBUG - 2012-10-02 00:34:19 --> Loader Class Initialized
DEBUG - 2012-10-02 00:34:19 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:34:19 --> Controller Class Initialized
DEBUG - 2012-10-02 00:34:19 --> Model Class Initialized
DEBUG - 2012-10-02 00:34:19 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:43:13 --> Config Class Initialized
DEBUG - 2012-10-02 00:43:13 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:43:13 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:43:13 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:43:13 --> URI Class Initialized
DEBUG - 2012-10-02 00:43:13 --> Router Class Initialized
DEBUG - 2012-10-02 00:43:13 --> Output Class Initialized
DEBUG - 2012-10-02 00:43:13 --> Security Class Initialized
DEBUG - 2012-10-02 00:43:13 --> Input Class Initialized
DEBUG - 2012-10-02 00:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:43:13 --> Language Class Initialized
DEBUG - 2012-10-02 00:43:13 --> Loader Class Initialized
DEBUG - 2012-10-02 00:43:13 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:43:13 --> Controller Class Initialized
DEBUG - 2012-10-02 00:43:13 --> Model Class Initialized
DEBUG - 2012-10-02 00:43:13 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:43:13 --> Helper loaded: form_helper
DEBUG - 2012-10-02 00:43:13 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 00:43:13 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 00:43:13 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 00:43:13 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 00:43:13 --> Final output sent to browser
DEBUG - 2012-10-02 00:43:13 --> Total execution time: 0.0600
DEBUG - 2012-10-02 00:43:24 --> Config Class Initialized
DEBUG - 2012-10-02 00:43:24 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:43:24 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:43:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:43:24 --> URI Class Initialized
DEBUG - 2012-10-02 00:43:24 --> Router Class Initialized
DEBUG - 2012-10-02 00:43:24 --> Output Class Initialized
DEBUG - 2012-10-02 00:43:24 --> Security Class Initialized
DEBUG - 2012-10-02 00:43:24 --> Input Class Initialized
DEBUG - 2012-10-02 00:43:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:43:24 --> Language Class Initialized
DEBUG - 2012-10-02 00:43:24 --> Loader Class Initialized
DEBUG - 2012-10-02 00:43:24 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:43:24 --> Controller Class Initialized
DEBUG - 2012-10-02 00:43:24 --> Model Class Initialized
DEBUG - 2012-10-02 00:43:24 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:47:51 --> Config Class Initialized
DEBUG - 2012-10-02 00:47:51 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:47:51 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:47:51 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:47:51 --> URI Class Initialized
DEBUG - 2012-10-02 00:47:51 --> Router Class Initialized
DEBUG - 2012-10-02 00:47:51 --> Output Class Initialized
DEBUG - 2012-10-02 00:47:51 --> Security Class Initialized
DEBUG - 2012-10-02 00:47:51 --> Input Class Initialized
DEBUG - 2012-10-02 00:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:47:51 --> Language Class Initialized
DEBUG - 2012-10-02 00:47:51 --> Loader Class Initialized
DEBUG - 2012-10-02 00:47:51 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:47:51 --> Controller Class Initialized
DEBUG - 2012-10-02 00:47:51 --> Model Class Initialized
DEBUG - 2012-10-02 00:47:51 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:47:51 --> Helper loaded: form_helper
DEBUG - 2012-10-02 00:47:51 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 00:47:51 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 00:47:51 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 00:47:51 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 00:47:51 --> Final output sent to browser
DEBUG - 2012-10-02 00:47:51 --> Total execution time: 0.0396
DEBUG - 2012-10-02 00:48:00 --> Config Class Initialized
DEBUG - 2012-10-02 00:48:00 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:48:00 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:48:00 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:48:00 --> URI Class Initialized
DEBUG - 2012-10-02 00:48:00 --> Router Class Initialized
DEBUG - 2012-10-02 00:48:00 --> Output Class Initialized
DEBUG - 2012-10-02 00:48:00 --> Security Class Initialized
DEBUG - 2012-10-02 00:48:00 --> Input Class Initialized
DEBUG - 2012-10-02 00:48:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:48:00 --> Language Class Initialized
DEBUG - 2012-10-02 00:48:00 --> Loader Class Initialized
DEBUG - 2012-10-02 00:48:00 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:48:00 --> Controller Class Initialized
DEBUG - 2012-10-02 00:48:00 --> Model Class Initialized
DEBUG - 2012-10-02 00:48:00 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:48:00 --> Upload Class Initialized
DEBUG - 2012-10-02 00:48:00 --> Language file loaded: language/english/upload_lang.php
ERROR - 2012-10-02 00:48:00 --> You did not select a file to upload.
DEBUG - 2012-10-02 00:53:28 --> Config Class Initialized
DEBUG - 2012-10-02 00:53:28 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:53:28 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:53:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:53:28 --> URI Class Initialized
DEBUG - 2012-10-02 00:53:28 --> Router Class Initialized
DEBUG - 2012-10-02 00:53:28 --> Output Class Initialized
DEBUG - 2012-10-02 00:53:28 --> Security Class Initialized
DEBUG - 2012-10-02 00:53:28 --> Input Class Initialized
DEBUG - 2012-10-02 00:53:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:53:28 --> Language Class Initialized
DEBUG - 2012-10-02 00:53:28 --> Loader Class Initialized
DEBUG - 2012-10-02 00:53:28 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:53:28 --> Controller Class Initialized
DEBUG - 2012-10-02 00:53:28 --> Model Class Initialized
DEBUG - 2012-10-02 00:53:28 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:53:28 --> Helper loaded: form_helper
DEBUG - 2012-10-02 00:53:28 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 00:53:28 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 00:53:28 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 00:53:28 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 00:53:28 --> Final output sent to browser
DEBUG - 2012-10-02 00:53:28 --> Total execution time: 0.0456
DEBUG - 2012-10-02 00:53:35 --> Config Class Initialized
DEBUG - 2012-10-02 00:53:35 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:53:35 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:53:35 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:53:35 --> URI Class Initialized
DEBUG - 2012-10-02 00:53:35 --> Router Class Initialized
DEBUG - 2012-10-02 00:53:35 --> Output Class Initialized
DEBUG - 2012-10-02 00:53:35 --> Security Class Initialized
DEBUG - 2012-10-02 00:53:35 --> Input Class Initialized
DEBUG - 2012-10-02 00:53:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:53:35 --> Language Class Initialized
DEBUG - 2012-10-02 00:53:35 --> Loader Class Initialized
DEBUG - 2012-10-02 00:53:35 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:53:35 --> Controller Class Initialized
DEBUG - 2012-10-02 00:53:35 --> Model Class Initialized
DEBUG - 2012-10-02 00:53:35 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:53:35 --> Helper loaded: form_helper
DEBUG - 2012-10-02 00:53:35 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 00:53:35 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 00:53:35 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 00:53:35 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 00:53:35 --> Final output sent to browser
DEBUG - 2012-10-02 00:53:35 --> Total execution time: 0.0453
DEBUG - 2012-10-02 00:58:59 --> Config Class Initialized
DEBUG - 2012-10-02 00:58:59 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:58:59 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:58:59 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:58:59 --> URI Class Initialized
DEBUG - 2012-10-02 00:58:59 --> Router Class Initialized
DEBUG - 2012-10-02 00:58:59 --> Output Class Initialized
DEBUG - 2012-10-02 00:58:59 --> Security Class Initialized
DEBUG - 2012-10-02 00:58:59 --> Input Class Initialized
DEBUG - 2012-10-02 00:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:58:59 --> Language Class Initialized
DEBUG - 2012-10-02 00:58:59 --> Loader Class Initialized
DEBUG - 2012-10-02 00:58:59 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:58:59 --> Controller Class Initialized
DEBUG - 2012-10-02 00:58:59 --> Model Class Initialized
DEBUG - 2012-10-02 00:58:59 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:58:59 --> Helper loaded: form_helper
DEBUG - 2012-10-02 00:58:59 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 00:58:59 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 00:58:59 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 00:58:59 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 00:58:59 --> Final output sent to browser
DEBUG - 2012-10-02 00:58:59 --> Total execution time: 0.2145
DEBUG - 2012-10-02 00:59:00 --> Config Class Initialized
DEBUG - 2012-10-02 00:59:00 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:59:00 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:59:00 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:59:00 --> URI Class Initialized
DEBUG - 2012-10-02 00:59:00 --> Router Class Initialized
DEBUG - 2012-10-02 00:59:04 --> Config Class Initialized
DEBUG - 2012-10-02 00:59:04 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:59:04 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:59:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:59:04 --> URI Class Initialized
DEBUG - 2012-10-02 00:59:04 --> Router Class Initialized
DEBUG - 2012-10-02 00:59:06 --> Config Class Initialized
DEBUG - 2012-10-02 00:59:06 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:59:06 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:59:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:59:06 --> URI Class Initialized
DEBUG - 2012-10-02 00:59:06 --> Router Class Initialized
DEBUG - 2012-10-02 00:59:14 --> Config Class Initialized
DEBUG - 2012-10-02 00:59:14 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:59:14 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:59:14 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:59:14 --> URI Class Initialized
DEBUG - 2012-10-02 00:59:14 --> Router Class Initialized
DEBUG - 2012-10-02 00:59:14 --> Output Class Initialized
DEBUG - 2012-10-02 00:59:14 --> Security Class Initialized
DEBUG - 2012-10-02 00:59:14 --> Input Class Initialized
DEBUG - 2012-10-02 00:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:59:14 --> Language Class Initialized
DEBUG - 2012-10-02 00:59:14 --> Loader Class Initialized
DEBUG - 2012-10-02 00:59:14 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:59:14 --> Controller Class Initialized
DEBUG - 2012-10-02 00:59:14 --> Model Class Initialized
DEBUG - 2012-10-02 00:59:14 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:59:14 --> Helper loaded: form_helper
DEBUG - 2012-10-02 00:59:14 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 00:59:14 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-10-02 00:59:14 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 00:59:14 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-10-02 00:59:14 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 00:59:14 --> Final output sent to browser
DEBUG - 2012-10-02 00:59:14 --> Total execution time: 0.2173
DEBUG - 2012-10-02 00:59:17 --> Config Class Initialized
DEBUG - 2012-10-02 00:59:17 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:59:17 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:59:17 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:59:17 --> URI Class Initialized
DEBUG - 2012-10-02 00:59:17 --> Router Class Initialized
DEBUG - 2012-10-02 00:59:17 --> Output Class Initialized
DEBUG - 2012-10-02 00:59:17 --> Security Class Initialized
DEBUG - 2012-10-02 00:59:17 --> Input Class Initialized
DEBUG - 2012-10-02 00:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:59:17 --> Language Class Initialized
DEBUG - 2012-10-02 00:59:17 --> Loader Class Initialized
DEBUG - 2012-10-02 00:59:17 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:59:17 --> Controller Class Initialized
DEBUG - 2012-10-02 00:59:17 --> Model Class Initialized
DEBUG - 2012-10-02 00:59:17 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:59:17 --> Helper loaded: form_helper
DEBUG - 2012-10-02 00:59:17 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 00:59:17 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 00:59:17 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 00:59:17 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 00:59:17 --> Final output sent to browser
DEBUG - 2012-10-02 00:59:17 --> Total execution time: 0.0393
DEBUG - 2012-10-02 00:59:18 --> Config Class Initialized
DEBUG - 2012-10-02 00:59:18 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:59:18 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:59:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:59:18 --> URI Class Initialized
DEBUG - 2012-10-02 00:59:18 --> Router Class Initialized
DEBUG - 2012-10-02 00:59:53 --> Config Class Initialized
DEBUG - 2012-10-02 00:59:53 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:59:53 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:59:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:59:53 --> URI Class Initialized
DEBUG - 2012-10-02 00:59:53 --> Router Class Initialized
DEBUG - 2012-10-02 00:59:53 --> Output Class Initialized
DEBUG - 2012-10-02 00:59:53 --> Security Class Initialized
DEBUG - 2012-10-02 00:59:53 --> Input Class Initialized
DEBUG - 2012-10-02 00:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:59:53 --> Language Class Initialized
DEBUG - 2012-10-02 00:59:53 --> Loader Class Initialized
DEBUG - 2012-10-02 00:59:53 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:59:53 --> Controller Class Initialized
DEBUG - 2012-10-02 00:59:53 --> Model Class Initialized
DEBUG - 2012-10-02 00:59:53 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:59:53 --> Helper loaded: form_helper
DEBUG - 2012-10-02 00:59:54 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 00:59:54 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-10-02 00:59:54 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 00:59:54 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-10-02 00:59:54 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 00:59:54 --> Final output sent to browser
DEBUG - 2012-10-02 00:59:54 --> Total execution time: 0.0605
DEBUG - 2012-10-02 00:59:57 --> Config Class Initialized
DEBUG - 2012-10-02 00:59:57 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:59:57 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:59:57 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:59:57 --> URI Class Initialized
DEBUG - 2012-10-02 00:59:57 --> Router Class Initialized
DEBUG - 2012-10-02 00:59:57 --> Output Class Initialized
DEBUG - 2012-10-02 00:59:57 --> Security Class Initialized
DEBUG - 2012-10-02 00:59:57 --> Input Class Initialized
DEBUG - 2012-10-02 00:59:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 00:59:57 --> Language Class Initialized
DEBUG - 2012-10-02 00:59:57 --> Loader Class Initialized
DEBUG - 2012-10-02 00:59:57 --> Helper loaded: url_helper
DEBUG - 2012-10-02 00:59:57 --> Controller Class Initialized
DEBUG - 2012-10-02 00:59:57 --> Model Class Initialized
DEBUG - 2012-10-02 00:59:57 --> Database Driver Class Initialized
DEBUG - 2012-10-02 00:59:57 --> Helper loaded: form_helper
DEBUG - 2012-10-02 00:59:57 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 00:59:57 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 00:59:57 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 00:59:57 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 00:59:57 --> Final output sent to browser
DEBUG - 2012-10-02 00:59:57 --> Total execution time: 0.0386
DEBUG - 2012-10-02 00:59:58 --> Config Class Initialized
DEBUG - 2012-10-02 00:59:58 --> Hooks Class Initialized
DEBUG - 2012-10-02 00:59:58 --> Utf8 Class Initialized
DEBUG - 2012-10-02 00:59:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 00:59:58 --> URI Class Initialized
DEBUG - 2012-10-02 00:59:58 --> Router Class Initialized
DEBUG - 2012-10-02 01:02:55 --> Config Class Initialized
DEBUG - 2012-10-02 01:02:55 --> Hooks Class Initialized
DEBUG - 2012-10-02 01:02:55 --> Utf8 Class Initialized
DEBUG - 2012-10-02 01:02:55 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 01:02:55 --> URI Class Initialized
DEBUG - 2012-10-02 01:02:55 --> Router Class Initialized
DEBUG - 2012-10-02 01:02:55 --> Output Class Initialized
DEBUG - 2012-10-02 01:02:55 --> Security Class Initialized
DEBUG - 2012-10-02 01:02:55 --> Input Class Initialized
DEBUG - 2012-10-02 01:02:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 01:02:55 --> Language Class Initialized
DEBUG - 2012-10-02 01:02:55 --> Loader Class Initialized
DEBUG - 2012-10-02 01:02:55 --> Helper loaded: url_helper
DEBUG - 2012-10-02 01:02:55 --> Controller Class Initialized
DEBUG - 2012-10-02 01:02:55 --> Model Class Initialized
DEBUG - 2012-10-02 01:02:55 --> Database Driver Class Initialized
DEBUG - 2012-10-02 01:02:55 --> Helper loaded: form_helper
DEBUG - 2012-10-02 01:02:55 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 01:02:55 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 01:02:55 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 01:02:55 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 01:02:55 --> Final output sent to browser
DEBUG - 2012-10-02 01:02:55 --> Total execution time: 0.0392
DEBUG - 2012-10-02 01:02:56 --> Config Class Initialized
DEBUG - 2012-10-02 01:02:56 --> Hooks Class Initialized
DEBUG - 2012-10-02 01:02:56 --> Utf8 Class Initialized
DEBUG - 2012-10-02 01:02:56 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 01:02:56 --> URI Class Initialized
DEBUG - 2012-10-02 01:02:56 --> Router Class Initialized
DEBUG - 2012-10-02 01:02:56 --> Output Class Initialized
DEBUG - 2012-10-02 01:02:56 --> Security Class Initialized
DEBUG - 2012-10-02 01:02:56 --> Input Class Initialized
DEBUG - 2012-10-02 01:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 01:02:56 --> Language Class Initialized
DEBUG - 2012-10-02 01:02:56 --> Loader Class Initialized
DEBUG - 2012-10-02 01:02:56 --> Helper loaded: url_helper
DEBUG - 2012-10-02 01:02:56 --> Controller Class Initialized
DEBUG - 2012-10-02 01:02:56 --> Model Class Initialized
DEBUG - 2012-10-02 01:02:56 --> Database Driver Class Initialized
DEBUG - 2012-10-02 01:02:56 --> Upload Class Initialized
DEBUG - 2012-10-02 01:02:56 --> Language file loaded: language/english/upload_lang.php
ERROR - 2012-10-02 01:02:56 --> You did not select a file to upload.
DEBUG - 2012-10-02 01:06:06 --> Config Class Initialized
DEBUG - 2012-10-02 01:06:06 --> Hooks Class Initialized
DEBUG - 2012-10-02 01:06:06 --> Utf8 Class Initialized
DEBUG - 2012-10-02 01:06:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 01:06:06 --> URI Class Initialized
DEBUG - 2012-10-02 01:06:06 --> Router Class Initialized
DEBUG - 2012-10-02 01:06:06 --> Output Class Initialized
DEBUG - 2012-10-02 01:06:06 --> Security Class Initialized
DEBUG - 2012-10-02 01:06:06 --> Input Class Initialized
DEBUG - 2012-10-02 01:06:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 01:06:06 --> Language Class Initialized
DEBUG - 2012-10-02 01:06:06 --> Loader Class Initialized
DEBUG - 2012-10-02 01:06:06 --> Helper loaded: url_helper
DEBUG - 2012-10-02 01:06:06 --> Controller Class Initialized
DEBUG - 2012-10-02 01:06:06 --> Model Class Initialized
DEBUG - 2012-10-02 01:06:06 --> Database Driver Class Initialized
DEBUG - 2012-10-02 01:06:06 --> Helper loaded: form_helper
DEBUG - 2012-10-02 01:06:06 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 01:06:06 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 01:06:06 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 01:06:06 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 01:06:06 --> Final output sent to browser
DEBUG - 2012-10-02 01:06:06 --> Total execution time: 0.0404
DEBUG - 2012-10-02 01:06:07 --> Config Class Initialized
DEBUG - 2012-10-02 01:06:07 --> Hooks Class Initialized
DEBUG - 2012-10-02 01:06:07 --> Utf8 Class Initialized
DEBUG - 2012-10-02 01:06:07 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 01:06:07 --> URI Class Initialized
DEBUG - 2012-10-02 01:06:07 --> Router Class Initialized
DEBUG - 2012-10-02 01:06:07 --> Output Class Initialized
DEBUG - 2012-10-02 01:06:07 --> Security Class Initialized
DEBUG - 2012-10-02 01:06:07 --> Input Class Initialized
DEBUG - 2012-10-02 01:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 01:06:07 --> Language Class Initialized
DEBUG - 2012-10-02 01:06:07 --> Loader Class Initialized
DEBUG - 2012-10-02 01:06:07 --> Helper loaded: url_helper
DEBUG - 2012-10-02 01:06:07 --> Controller Class Initialized
DEBUG - 2012-10-02 01:06:07 --> Model Class Initialized
DEBUG - 2012-10-02 01:06:07 --> Database Driver Class Initialized
DEBUG - 2012-10-02 01:06:07 --> Upload Class Initialized
DEBUG - 2012-10-02 01:06:07 --> Language file loaded: language/english/upload_lang.php
ERROR - 2012-10-02 01:06:07 --> You did not select a file to upload.
DEBUG - 2012-10-02 01:06:28 --> Config Class Initialized
DEBUG - 2012-10-02 01:06:28 --> Hooks Class Initialized
DEBUG - 2012-10-02 01:06:28 --> Utf8 Class Initialized
DEBUG - 2012-10-02 01:06:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 01:06:28 --> URI Class Initialized
DEBUG - 2012-10-02 01:06:28 --> Router Class Initialized
DEBUG - 2012-10-02 01:06:28 --> Output Class Initialized
DEBUG - 2012-10-02 01:06:28 --> Security Class Initialized
DEBUG - 2012-10-02 01:06:28 --> Input Class Initialized
DEBUG - 2012-10-02 01:06:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 01:06:28 --> Language Class Initialized
DEBUG - 2012-10-02 01:06:28 --> Loader Class Initialized
DEBUG - 2012-10-02 01:06:28 --> Helper loaded: url_helper
DEBUG - 2012-10-02 01:06:28 --> Controller Class Initialized
DEBUG - 2012-10-02 01:06:28 --> Model Class Initialized
DEBUG - 2012-10-02 01:06:28 --> Database Driver Class Initialized
DEBUG - 2012-10-02 01:06:28 --> Helper loaded: form_helper
DEBUG - 2012-10-02 01:06:28 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 01:06:28 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 01:06:28 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 01:06:28 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 01:06:28 --> Final output sent to browser
DEBUG - 2012-10-02 01:06:28 --> Total execution time: 0.0396
DEBUG - 2012-10-02 01:06:28 --> Config Class Initialized
DEBUG - 2012-10-02 01:06:28 --> Hooks Class Initialized
DEBUG - 2012-10-02 01:06:28 --> Utf8 Class Initialized
DEBUG - 2012-10-02 01:06:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 01:06:28 --> URI Class Initialized
DEBUG - 2012-10-02 01:06:28 --> Router Class Initialized
DEBUG - 2012-10-02 01:06:28 --> Output Class Initialized
DEBUG - 2012-10-02 01:06:28 --> Security Class Initialized
DEBUG - 2012-10-02 01:06:28 --> Input Class Initialized
DEBUG - 2012-10-02 01:06:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 01:06:28 --> Language Class Initialized
DEBUG - 2012-10-02 01:06:28 --> Loader Class Initialized
DEBUG - 2012-10-02 01:06:28 --> Helper loaded: url_helper
DEBUG - 2012-10-02 01:06:28 --> Controller Class Initialized
DEBUG - 2012-10-02 01:06:28 --> Model Class Initialized
DEBUG - 2012-10-02 01:06:28 --> Database Driver Class Initialized
ERROR - 2012-10-02 01:06:28 --> 404 Page Not Found --> pricing/pxost_new_frame_type
DEBUG - 2012-10-02 01:07:56 --> Config Class Initialized
DEBUG - 2012-10-02 01:07:56 --> Hooks Class Initialized
DEBUG - 2012-10-02 01:07:56 --> Utf8 Class Initialized
DEBUG - 2012-10-02 01:07:56 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 01:07:56 --> URI Class Initialized
DEBUG - 2012-10-02 01:07:56 --> Router Class Initialized
DEBUG - 2012-10-02 01:07:56 --> Output Class Initialized
DEBUG - 2012-10-02 01:07:56 --> Security Class Initialized
DEBUG - 2012-10-02 01:07:56 --> Input Class Initialized
DEBUG - 2012-10-02 01:07:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 01:07:56 --> Language Class Initialized
DEBUG - 2012-10-02 01:07:56 --> Loader Class Initialized
DEBUG - 2012-10-02 01:07:56 --> Helper loaded: url_helper
DEBUG - 2012-10-02 01:07:56 --> Controller Class Initialized
DEBUG - 2012-10-02 01:07:56 --> Model Class Initialized
DEBUG - 2012-10-02 01:07:56 --> Database Driver Class Initialized
DEBUG - 2012-10-02 01:07:56 --> Helper loaded: form_helper
DEBUG - 2012-10-02 01:07:56 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 01:07:56 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 01:07:56 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 01:07:56 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 01:07:56 --> Final output sent to browser
DEBUG - 2012-10-02 01:07:56 --> Total execution time: 0.0393
DEBUG - 2012-10-02 01:08:01 --> Config Class Initialized
DEBUG - 2012-10-02 01:08:01 --> Hooks Class Initialized
DEBUG - 2012-10-02 01:08:01 --> Utf8 Class Initialized
DEBUG - 2012-10-02 01:08:01 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 01:08:01 --> URI Class Initialized
DEBUG - 2012-10-02 01:08:01 --> Router Class Initialized
DEBUG - 2012-10-02 01:08:01 --> Output Class Initialized
DEBUG - 2012-10-02 01:08:01 --> Security Class Initialized
DEBUG - 2012-10-02 01:08:01 --> Input Class Initialized
DEBUG - 2012-10-02 01:08:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 01:08:01 --> Language Class Initialized
DEBUG - 2012-10-02 01:08:01 --> Loader Class Initialized
DEBUG - 2012-10-02 01:08:01 --> Helper loaded: url_helper
DEBUG - 2012-10-02 01:08:01 --> Controller Class Initialized
DEBUG - 2012-10-02 01:08:01 --> Model Class Initialized
DEBUG - 2012-10-02 01:08:01 --> Database Driver Class Initialized
DEBUG - 2012-10-02 01:08:01 --> Helper loaded: form_helper
DEBUG - 2012-10-02 01:08:01 --> Helper loaded: language_helper
DEBUG - 2012-10-02 01:08:01 --> Form Validation Class Initialized
DEBUG - 2012-10-02 01:08:01 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 01:08:01 --> Upload Class Initialized
DEBUG - 2012-10-02 01:08:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 01:08:14 --> Config Class Initialized
DEBUG - 2012-10-02 01:08:14 --> Hooks Class Initialized
DEBUG - 2012-10-02 01:08:14 --> Utf8 Class Initialized
DEBUG - 2012-10-02 01:08:14 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 01:08:14 --> URI Class Initialized
DEBUG - 2012-10-02 01:08:14 --> Router Class Initialized
DEBUG - 2012-10-02 01:08:14 --> Output Class Initialized
DEBUG - 2012-10-02 01:08:14 --> Security Class Initialized
DEBUG - 2012-10-02 01:08:14 --> Input Class Initialized
DEBUG - 2012-10-02 01:08:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 01:08:14 --> Language Class Initialized
DEBUG - 2012-10-02 01:08:14 --> Loader Class Initialized
DEBUG - 2012-10-02 01:08:14 --> Helper loaded: url_helper
DEBUG - 2012-10-02 01:08:14 --> Controller Class Initialized
DEBUG - 2012-10-02 01:08:14 --> Model Class Initialized
DEBUG - 2012-10-02 01:08:14 --> Database Driver Class Initialized
DEBUG - 2012-10-02 01:08:14 --> Helper loaded: form_helper
DEBUG - 2012-10-02 01:08:14 --> Helper loaded: language_helper
DEBUG - 2012-10-02 01:08:14 --> Form Validation Class Initialized
DEBUG - 2012-10-02 01:08:14 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 01:08:14 --> Upload Class Initialized
DEBUG - 2012-10-02 01:08:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 01:08:14 --> Language file loaded: language/english/upload_lang.php
ERROR - 2012-10-02 01:08:14 --> You did not select a file to upload.
DEBUG - 2012-10-02 01:10:11 --> Config Class Initialized
DEBUG - 2012-10-02 01:10:11 --> Hooks Class Initialized
DEBUG - 2012-10-02 01:10:11 --> Utf8 Class Initialized
DEBUG - 2012-10-02 01:10:11 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 01:10:11 --> URI Class Initialized
DEBUG - 2012-10-02 01:10:11 --> Router Class Initialized
DEBUG - 2012-10-02 01:10:11 --> Output Class Initialized
DEBUG - 2012-10-02 01:10:11 --> Security Class Initialized
DEBUG - 2012-10-02 01:10:11 --> Input Class Initialized
DEBUG - 2012-10-02 01:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 01:10:11 --> Language Class Initialized
DEBUG - 2012-10-02 01:10:11 --> Loader Class Initialized
DEBUG - 2012-10-02 01:10:11 --> Helper loaded: url_helper
DEBUG - 2012-10-02 01:10:11 --> Controller Class Initialized
DEBUG - 2012-10-02 01:10:11 --> Model Class Initialized
DEBUG - 2012-10-02 01:10:12 --> Database Driver Class Initialized
DEBUG - 2012-10-02 11:38:23 --> Config Class Initialized
DEBUG - 2012-10-02 11:38:23 --> Hooks Class Initialized
DEBUG - 2012-10-02 11:38:23 --> Utf8 Class Initialized
DEBUG - 2012-10-02 11:38:23 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 11:38:23 --> URI Class Initialized
DEBUG - 2012-10-02 11:38:23 --> Router Class Initialized
DEBUG - 2012-10-02 11:38:23 --> Output Class Initialized
DEBUG - 2012-10-02 11:38:23 --> Security Class Initialized
DEBUG - 2012-10-02 11:38:23 --> Input Class Initialized
DEBUG - 2012-10-02 11:38:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 11:38:23 --> Language Class Initialized
DEBUG - 2012-10-02 11:38:23 --> Loader Class Initialized
DEBUG - 2012-10-02 11:38:23 --> Helper loaded: url_helper
DEBUG - 2012-10-02 11:38:23 --> Controller Class Initialized
DEBUG - 2012-10-02 11:38:23 --> Model Class Initialized
DEBUG - 2012-10-02 11:38:24 --> Database Driver Class Initialized
DEBUG - 2012-10-02 11:38:24 --> Helper loaded: form_helper
DEBUG - 2012-10-02 11:38:24 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 11:38:24 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 11:38:24 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 11:38:24 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 11:38:24 --> Final output sent to browser
DEBUG - 2012-10-02 11:38:24 --> Total execution time: 0.8550
DEBUG - 2012-10-02 11:38:26 --> Config Class Initialized
DEBUG - 2012-10-02 11:38:26 --> Hooks Class Initialized
DEBUG - 2012-10-02 11:38:26 --> Utf8 Class Initialized
DEBUG - 2012-10-02 11:38:26 --> Config Class Initialized
DEBUG - 2012-10-02 11:38:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 11:38:26 --> Hooks Class Initialized
DEBUG - 2012-10-02 11:38:26 --> Utf8 Class Initialized
DEBUG - 2012-10-02 11:38:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 11:38:26 --> URI Class Initialized
DEBUG - 2012-10-02 11:38:26 --> URI Class Initialized
DEBUG - 2012-10-02 11:38:26 --> Router Class Initialized
DEBUG - 2012-10-02 11:38:26 --> Router Class Initialized
DEBUG - 2012-10-02 11:38:26 --> Config Class Initialized
DEBUG - 2012-10-02 11:38:26 --> Hooks Class Initialized
DEBUG - 2012-10-02 11:38:26 --> Utf8 Class Initialized
DEBUG - 2012-10-02 11:38:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 11:38:26 --> URI Class Initialized
DEBUG - 2012-10-02 11:38:26 --> Router Class Initialized
ERROR - 2012-10-02 11:38:26 --> 404 Page Not Found --> css
ERROR - 2012-10-02 11:38:26 --> 404 Page Not Found --> css
ERROR - 2012-10-02 11:38:26 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 15:55:12 --> Config Class Initialized
DEBUG - 2012-10-02 15:55:12 --> Hooks Class Initialized
DEBUG - 2012-10-02 15:55:12 --> Utf8 Class Initialized
DEBUG - 2012-10-02 15:55:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 15:55:12 --> URI Class Initialized
DEBUG - 2012-10-02 15:55:12 --> Router Class Initialized
DEBUG - 2012-10-02 15:55:12 --> Output Class Initialized
DEBUG - 2012-10-02 15:55:12 --> Security Class Initialized
DEBUG - 2012-10-02 15:55:12 --> Input Class Initialized
DEBUG - 2012-10-02 15:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 15:55:12 --> Language Class Initialized
DEBUG - 2012-10-02 15:55:12 --> Loader Class Initialized
DEBUG - 2012-10-02 15:55:12 --> Helper loaded: url_helper
DEBUG - 2012-10-02 15:55:12 --> Controller Class Initialized
DEBUG - 2012-10-02 15:55:12 --> Model Class Initialized
DEBUG - 2012-10-02 15:55:12 --> Database Driver Class Initialized
DEBUG - 2012-10-02 15:55:13 --> Helper loaded: form_helper
DEBUG - 2012-10-02 15:55:13 --> Helper loaded: language_helper
DEBUG - 2012-10-02 15:55:13 --> Form Validation Class Initialized
DEBUG - 2012-10-02 15:55:13 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 15:55:13 --> Upload Class Initialized
DEBUG - 2012-10-02 15:55:33 --> Config Class Initialized
DEBUG - 2012-10-02 15:55:33 --> Hooks Class Initialized
DEBUG - 2012-10-02 15:55:33 --> Utf8 Class Initialized
DEBUG - 2012-10-02 15:55:33 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 15:55:33 --> URI Class Initialized
DEBUG - 2012-10-02 15:55:33 --> Router Class Initialized
DEBUG - 2012-10-02 15:55:33 --> Output Class Initialized
DEBUG - 2012-10-02 15:55:33 --> Security Class Initialized
DEBUG - 2012-10-02 15:55:33 --> Input Class Initialized
DEBUG - 2012-10-02 15:55:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 15:55:33 --> Language Class Initialized
DEBUG - 2012-10-02 15:55:33 --> Loader Class Initialized
DEBUG - 2012-10-02 15:55:33 --> Helper loaded: url_helper
DEBUG - 2012-10-02 15:55:33 --> Controller Class Initialized
DEBUG - 2012-10-02 15:55:33 --> Model Class Initialized
DEBUG - 2012-10-02 15:55:33 --> Database Driver Class Initialized
DEBUG - 2012-10-02 15:55:33 --> Helper loaded: form_helper
DEBUG - 2012-10-02 15:55:33 --> Helper loaded: language_helper
DEBUG - 2012-10-02 15:55:33 --> Form Validation Class Initialized
DEBUG - 2012-10-02 15:55:33 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 15:55:33 --> Upload Class Initialized
DEBUG - 2012-10-02 15:55:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 15:55:33 --> Language file loaded: language/english/upload_lang.php
ERROR - 2012-10-02 15:55:33 --> The image you are attempting to upload exceedes the maximum height or width.
DEBUG - 2012-10-02 15:57:27 --> Config Class Initialized
DEBUG - 2012-10-02 15:57:27 --> Hooks Class Initialized
DEBUG - 2012-10-02 15:57:27 --> Utf8 Class Initialized
DEBUG - 2012-10-02 15:57:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 15:57:27 --> URI Class Initialized
DEBUG - 2012-10-02 15:57:27 --> Router Class Initialized
DEBUG - 2012-10-02 15:57:27 --> Output Class Initialized
DEBUG - 2012-10-02 15:57:27 --> Security Class Initialized
DEBUG - 2012-10-02 15:57:27 --> Input Class Initialized
DEBUG - 2012-10-02 15:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 15:57:27 --> Language Class Initialized
DEBUG - 2012-10-02 15:57:27 --> Loader Class Initialized
DEBUG - 2012-10-02 15:57:27 --> Helper loaded: url_helper
DEBUG - 2012-10-02 15:57:27 --> Controller Class Initialized
DEBUG - 2012-10-02 15:57:27 --> Model Class Initialized
DEBUG - 2012-10-02 15:57:27 --> Database Driver Class Initialized
DEBUG - 2012-10-02 15:57:27 --> Helper loaded: form_helper
DEBUG - 2012-10-02 15:57:27 --> Helper loaded: language_helper
DEBUG - 2012-10-02 15:57:27 --> Form Validation Class Initialized
DEBUG - 2012-10-02 15:57:27 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 15:57:27 --> Upload Class Initialized
DEBUG - 2012-10-02 15:57:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 15:57:27 --> Final output sent to browser
DEBUG - 2012-10-02 15:57:27 --> Total execution time: 0.1428
DEBUG - 2012-10-02 15:59:51 --> Config Class Initialized
DEBUG - 2012-10-02 15:59:51 --> Hooks Class Initialized
DEBUG - 2012-10-02 15:59:51 --> Utf8 Class Initialized
DEBUG - 2012-10-02 15:59:51 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 15:59:51 --> URI Class Initialized
DEBUG - 2012-10-02 15:59:51 --> Router Class Initialized
DEBUG - 2012-10-02 15:59:51 --> Output Class Initialized
DEBUG - 2012-10-02 15:59:51 --> Security Class Initialized
DEBUG - 2012-10-02 15:59:51 --> Input Class Initialized
DEBUG - 2012-10-02 15:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 15:59:51 --> Language Class Initialized
DEBUG - 2012-10-02 15:59:51 --> Loader Class Initialized
DEBUG - 2012-10-02 15:59:51 --> Helper loaded: url_helper
DEBUG - 2012-10-02 15:59:51 --> Controller Class Initialized
DEBUG - 2012-10-02 15:59:51 --> Model Class Initialized
DEBUG - 2012-10-02 15:59:51 --> Database Driver Class Initialized
DEBUG - 2012-10-02 15:59:51 --> Helper loaded: form_helper
DEBUG - 2012-10-02 15:59:51 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 15:59:51 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 15:59:51 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 15:59:51 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 15:59:51 --> Final output sent to browser
DEBUG - 2012-10-02 15:59:51 --> Total execution time: 0.1059
DEBUG - 2012-10-02 15:59:53 --> Config Class Initialized
DEBUG - 2012-10-02 15:59:53 --> Hooks Class Initialized
DEBUG - 2012-10-02 15:59:53 --> Utf8 Class Initialized
DEBUG - 2012-10-02 15:59:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 15:59:53 --> URI Class Initialized
DEBUG - 2012-10-02 15:59:53 --> Config Class Initialized
DEBUG - 2012-10-02 15:59:53 --> Hooks Class Initialized
DEBUG - 2012-10-02 15:59:53 --> Router Class Initialized
DEBUG - 2012-10-02 15:59:53 --> Utf8 Class Initialized
DEBUG - 2012-10-02 15:59:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 15:59:53 --> URI Class Initialized
ERROR - 2012-10-02 15:59:53 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 15:59:53 --> Router Class Initialized
ERROR - 2012-10-02 15:59:53 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 15:59:53 --> Config Class Initialized
DEBUG - 2012-10-02 15:59:53 --> Hooks Class Initialized
DEBUG - 2012-10-02 15:59:53 --> Utf8 Class Initialized
DEBUG - 2012-10-02 15:59:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 15:59:53 --> URI Class Initialized
DEBUG - 2012-10-02 15:59:53 --> Router Class Initialized
ERROR - 2012-10-02 15:59:53 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 16:01:40 --> Config Class Initialized
DEBUG - 2012-10-02 16:01:40 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:01:40 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:01:40 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:01:40 --> URI Class Initialized
DEBUG - 2012-10-02 16:01:40 --> Router Class Initialized
DEBUG - 2012-10-02 16:01:40 --> Output Class Initialized
DEBUG - 2012-10-02 16:01:40 --> Security Class Initialized
DEBUG - 2012-10-02 16:01:40 --> Input Class Initialized
DEBUG - 2012-10-02 16:01:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 16:01:40 --> Language Class Initialized
DEBUG - 2012-10-02 16:01:40 --> Loader Class Initialized
DEBUG - 2012-10-02 16:01:40 --> Helper loaded: url_helper
DEBUG - 2012-10-02 16:01:40 --> Controller Class Initialized
DEBUG - 2012-10-02 16:01:40 --> Model Class Initialized
DEBUG - 2012-10-02 16:01:40 --> Database Driver Class Initialized
DEBUG - 2012-10-02 16:01:40 --> Helper loaded: form_helper
DEBUG - 2012-10-02 16:01:40 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 16:01:40 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 16:01:40 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 16:01:40 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 16:01:40 --> Final output sent to browser
DEBUG - 2012-10-02 16:01:40 --> Total execution time: 0.0406
DEBUG - 2012-10-02 16:01:42 --> Config Class Initialized
DEBUG - 2012-10-02 16:01:42 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:01:42 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:01:42 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:01:42 --> URI Class Initialized
DEBUG - 2012-10-02 16:01:42 --> Router Class Initialized
ERROR - 2012-10-02 16:01:42 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 16:01:42 --> Config Class Initialized
DEBUG - 2012-10-02 16:01:42 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:01:42 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:01:42 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:01:42 --> URI Class Initialized
DEBUG - 2012-10-02 16:01:42 --> Router Class Initialized
ERROR - 2012-10-02 16:01:42 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 16:01:42 --> Config Class Initialized
DEBUG - 2012-10-02 16:01:42 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:01:42 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:01:42 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:01:42 --> URI Class Initialized
DEBUG - 2012-10-02 16:01:42 --> Router Class Initialized
ERROR - 2012-10-02 16:01:42 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 16:04:53 --> Config Class Initialized
DEBUG - 2012-10-02 16:04:53 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:04:53 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:04:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:04:53 --> URI Class Initialized
DEBUG - 2012-10-02 16:04:53 --> Router Class Initialized
DEBUG - 2012-10-02 16:04:53 --> Output Class Initialized
DEBUG - 2012-10-02 16:04:53 --> Security Class Initialized
DEBUG - 2012-10-02 16:04:53 --> Input Class Initialized
DEBUG - 2012-10-02 16:04:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 16:04:53 --> Language Class Initialized
DEBUG - 2012-10-02 16:04:53 --> Loader Class Initialized
DEBUG - 2012-10-02 16:04:53 --> Helper loaded: url_helper
DEBUG - 2012-10-02 16:04:53 --> Controller Class Initialized
DEBUG - 2012-10-02 16:04:53 --> Model Class Initialized
DEBUG - 2012-10-02 16:04:53 --> Database Driver Class Initialized
DEBUG - 2012-10-02 16:04:53 --> Helper loaded: form_helper
DEBUG - 2012-10-02 16:04:53 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 16:04:53 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 16:04:53 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 16:04:53 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 16:04:53 --> Final output sent to browser
DEBUG - 2012-10-02 16:04:53 --> Total execution time: 0.0393
DEBUG - 2012-10-02 16:04:55 --> Config Class Initialized
DEBUG - 2012-10-02 16:04:55 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:04:55 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:04:55 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:04:55 --> URI Class Initialized
DEBUG - 2012-10-02 16:04:55 --> Router Class Initialized
ERROR - 2012-10-02 16:04:55 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 16:04:55 --> Config Class Initialized
DEBUG - 2012-10-02 16:04:55 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:04:55 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:04:55 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:04:55 --> URI Class Initialized
DEBUG - 2012-10-02 16:04:55 --> Router Class Initialized
ERROR - 2012-10-02 16:04:55 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 16:04:55 --> Config Class Initialized
DEBUG - 2012-10-02 16:04:55 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:04:55 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:04:55 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:04:55 --> URI Class Initialized
DEBUG - 2012-10-02 16:04:55 --> Router Class Initialized
ERROR - 2012-10-02 16:04:55 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 16:05:02 --> Config Class Initialized
DEBUG - 2012-10-02 16:05:02 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:05:02 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:05:02 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:05:02 --> URI Class Initialized
DEBUG - 2012-10-02 16:05:02 --> Router Class Initialized
DEBUG - 2012-10-02 16:05:02 --> Output Class Initialized
DEBUG - 2012-10-02 16:05:02 --> Security Class Initialized
DEBUG - 2012-10-02 16:05:02 --> Input Class Initialized
DEBUG - 2012-10-02 16:05:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 16:05:02 --> Language Class Initialized
DEBUG - 2012-10-02 16:05:02 --> Loader Class Initialized
DEBUG - 2012-10-02 16:05:02 --> Helper loaded: url_helper
DEBUG - 2012-10-02 16:05:02 --> Controller Class Initialized
DEBUG - 2012-10-02 16:05:02 --> Model Class Initialized
DEBUG - 2012-10-02 16:05:02 --> Database Driver Class Initialized
DEBUG - 2012-10-02 16:05:02 --> Helper loaded: form_helper
DEBUG - 2012-10-02 16:05:02 --> Helper loaded: language_helper
DEBUG - 2012-10-02 16:05:02 --> Form Validation Class Initialized
DEBUG - 2012-10-02 16:05:02 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 16:05:02 --> Upload Class Initialized
DEBUG - 2012-10-02 16:05:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 16:05:02 --> Final output sent to browser
DEBUG - 2012-10-02 16:05:02 --> Total execution time: 0.2416
DEBUG - 2012-10-02 16:09:24 --> Config Class Initialized
DEBUG - 2012-10-02 16:09:24 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:09:24 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:09:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:09:24 --> URI Class Initialized
DEBUG - 2012-10-02 16:09:24 --> Router Class Initialized
DEBUG - 2012-10-02 16:09:24 --> Output Class Initialized
DEBUG - 2012-10-02 16:09:24 --> Security Class Initialized
DEBUG - 2012-10-02 16:09:24 --> Input Class Initialized
DEBUG - 2012-10-02 16:09:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 16:09:24 --> Language Class Initialized
DEBUG - 2012-10-02 16:09:24 --> Loader Class Initialized
DEBUG - 2012-10-02 16:09:24 --> Helper loaded: url_helper
DEBUG - 2012-10-02 16:09:24 --> Controller Class Initialized
DEBUG - 2012-10-02 16:09:24 --> Model Class Initialized
DEBUG - 2012-10-02 16:09:24 --> Database Driver Class Initialized
DEBUG - 2012-10-02 16:09:24 --> Helper loaded: form_helper
DEBUG - 2012-10-02 16:09:24 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 16:09:24 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 16:09:24 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 16:09:24 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 16:09:24 --> Final output sent to browser
DEBUG - 2012-10-02 16:09:24 --> Total execution time: 0.0570
DEBUG - 2012-10-02 16:09:26 --> Config Class Initialized
DEBUG - 2012-10-02 16:09:26 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:09:26 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:09:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:09:26 --> URI Class Initialized
DEBUG - 2012-10-02 16:09:26 --> Router Class Initialized
ERROR - 2012-10-02 16:09:26 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 16:09:26 --> Config Class Initialized
DEBUG - 2012-10-02 16:09:26 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:09:26 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:09:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:09:26 --> URI Class Initialized
DEBUG - 2012-10-02 16:09:26 --> Router Class Initialized
ERROR - 2012-10-02 16:09:26 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 16:09:26 --> Config Class Initialized
DEBUG - 2012-10-02 16:09:26 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:09:26 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:09:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:09:26 --> URI Class Initialized
DEBUG - 2012-10-02 16:09:26 --> Router Class Initialized
ERROR - 2012-10-02 16:09:26 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 16:09:29 --> Config Class Initialized
DEBUG - 2012-10-02 16:09:29 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:09:29 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:09:29 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:09:29 --> URI Class Initialized
DEBUG - 2012-10-02 16:09:29 --> Router Class Initialized
DEBUG - 2012-10-02 16:09:29 --> Output Class Initialized
DEBUG - 2012-10-02 16:09:29 --> Security Class Initialized
DEBUG - 2012-10-02 16:09:29 --> Input Class Initialized
DEBUG - 2012-10-02 16:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 16:09:29 --> Language Class Initialized
DEBUG - 2012-10-02 16:09:29 --> Loader Class Initialized
DEBUG - 2012-10-02 16:09:29 --> Helper loaded: url_helper
DEBUG - 2012-10-02 16:09:29 --> Controller Class Initialized
DEBUG - 2012-10-02 16:09:29 --> Model Class Initialized
DEBUG - 2012-10-02 16:09:29 --> Database Driver Class Initialized
DEBUG - 2012-10-02 16:09:30 --> Final output sent to browser
DEBUG - 2012-10-02 16:09:30 --> Total execution time: 0.1504
DEBUG - 2012-10-02 16:12:58 --> Config Class Initialized
DEBUG - 2012-10-02 16:12:58 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:12:58 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:12:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:12:58 --> URI Class Initialized
DEBUG - 2012-10-02 16:12:58 --> Router Class Initialized
DEBUG - 2012-10-02 16:12:58 --> Output Class Initialized
DEBUG - 2012-10-02 16:12:58 --> Security Class Initialized
DEBUG - 2012-10-02 16:12:58 --> Input Class Initialized
DEBUG - 2012-10-02 16:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 16:12:58 --> Language Class Initialized
DEBUG - 2012-10-02 16:12:58 --> Loader Class Initialized
DEBUG - 2012-10-02 16:12:58 --> Helper loaded: url_helper
DEBUG - 2012-10-02 16:12:58 --> Controller Class Initialized
DEBUG - 2012-10-02 16:12:58 --> Model Class Initialized
DEBUG - 2012-10-02 16:12:58 --> Database Driver Class Initialized
DEBUG - 2012-10-02 16:12:58 --> Helper loaded: form_helper
DEBUG - 2012-10-02 16:12:58 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 16:12:58 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 16:12:58 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 16:12:58 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 16:12:58 --> Final output sent to browser
DEBUG - 2012-10-02 16:12:58 --> Total execution time: 0.0550
DEBUG - 2012-10-02 16:13:00 --> Config Class Initialized
DEBUG - 2012-10-02 16:13:00 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:13:00 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:13:00 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:13:00 --> URI Class Initialized
DEBUG - 2012-10-02 16:13:00 --> Router Class Initialized
ERROR - 2012-10-02 16:13:00 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 16:13:00 --> Config Class Initialized
DEBUG - 2012-10-02 16:13:00 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:13:00 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:13:00 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:13:00 --> URI Class Initialized
DEBUG - 2012-10-02 16:13:00 --> Router Class Initialized
ERROR - 2012-10-02 16:13:00 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 16:13:00 --> Config Class Initialized
DEBUG - 2012-10-02 16:13:00 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:13:00 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:13:00 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:13:00 --> URI Class Initialized
DEBUG - 2012-10-02 16:13:00 --> Router Class Initialized
ERROR - 2012-10-02 16:13:00 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 16:13:16 --> Config Class Initialized
DEBUG - 2012-10-02 16:13:16 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:13:16 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:13:16 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:13:16 --> URI Class Initialized
DEBUG - 2012-10-02 16:13:16 --> Router Class Initialized
DEBUG - 2012-10-02 16:13:16 --> Output Class Initialized
DEBUG - 2012-10-02 16:13:16 --> Security Class Initialized
DEBUG - 2012-10-02 16:13:16 --> Input Class Initialized
DEBUG - 2012-10-02 16:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 16:13:16 --> Language Class Initialized
DEBUG - 2012-10-02 16:13:16 --> Loader Class Initialized
DEBUG - 2012-10-02 16:13:16 --> Helper loaded: url_helper
DEBUG - 2012-10-02 16:13:16 --> Controller Class Initialized
DEBUG - 2012-10-02 16:13:16 --> Model Class Initialized
DEBUG - 2012-10-02 16:13:16 --> Database Driver Class Initialized
DEBUG - 2012-10-02 16:13:16 --> Helper loaded: form_helper
DEBUG - 2012-10-02 16:13:16 --> Helper loaded: language_helper
DEBUG - 2012-10-02 16:13:16 --> Form Validation Class Initialized
DEBUG - 2012-10-02 16:13:16 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 16:13:16 --> Upload Class Initialized
DEBUG - 2012-10-02 16:13:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 16:13:16 --> Final output sent to browser
DEBUG - 2012-10-02 16:13:16 --> Total execution time: 0.2200
DEBUG - 2012-10-02 16:28:41 --> Config Class Initialized
DEBUG - 2012-10-02 16:28:41 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:28:41 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:28:41 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:28:41 --> URI Class Initialized
DEBUG - 2012-10-02 16:28:41 --> Router Class Initialized
DEBUG - 2012-10-02 16:28:41 --> Output Class Initialized
DEBUG - 2012-10-02 16:28:41 --> Security Class Initialized
DEBUG - 2012-10-02 16:28:41 --> Input Class Initialized
DEBUG - 2012-10-02 16:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 16:28:41 --> Language Class Initialized
DEBUG - 2012-10-02 16:28:41 --> Loader Class Initialized
DEBUG - 2012-10-02 16:28:41 --> Helper loaded: url_helper
DEBUG - 2012-10-02 16:28:41 --> Controller Class Initialized
DEBUG - 2012-10-02 16:28:41 --> Model Class Initialized
DEBUG - 2012-10-02 16:28:41 --> Database Driver Class Initialized
DEBUG - 2012-10-02 16:28:41 --> Helper loaded: form_helper
DEBUG - 2012-10-02 16:28:41 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 16:28:41 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 16:28:41 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 16:28:41 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 16:28:41 --> Final output sent to browser
DEBUG - 2012-10-02 16:28:41 --> Total execution time: 0.0391
DEBUG - 2012-10-02 16:28:43 --> Config Class Initialized
DEBUG - 2012-10-02 16:28:43 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:28:43 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:28:43 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:28:43 --> URI Class Initialized
DEBUG - 2012-10-02 16:28:43 --> Router Class Initialized
ERROR - 2012-10-02 16:28:43 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 16:28:43 --> Config Class Initialized
DEBUG - 2012-10-02 16:28:43 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:28:43 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:28:43 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:28:43 --> URI Class Initialized
DEBUG - 2012-10-02 16:28:43 --> Router Class Initialized
ERROR - 2012-10-02 16:28:43 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 16:28:43 --> Config Class Initialized
DEBUG - 2012-10-02 16:28:43 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:28:43 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:28:43 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:28:43 --> URI Class Initialized
DEBUG - 2012-10-02 16:28:43 --> Router Class Initialized
ERROR - 2012-10-02 16:28:43 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 16:28:45 --> Config Class Initialized
DEBUG - 2012-10-02 16:28:45 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:28:45 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:28:45 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:28:45 --> URI Class Initialized
DEBUG - 2012-10-02 16:28:45 --> Router Class Initialized
DEBUG - 2012-10-02 16:28:45 --> Output Class Initialized
DEBUG - 2012-10-02 16:28:45 --> Security Class Initialized
DEBUG - 2012-10-02 16:28:45 --> Input Class Initialized
DEBUG - 2012-10-02 16:28:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 16:28:45 --> Language Class Initialized
DEBUG - 2012-10-02 16:28:45 --> Loader Class Initialized
DEBUG - 2012-10-02 16:28:45 --> Helper loaded: url_helper
DEBUG - 2012-10-02 16:28:45 --> Controller Class Initialized
DEBUG - 2012-10-02 16:28:45 --> Model Class Initialized
DEBUG - 2012-10-02 16:28:45 --> Database Driver Class Initialized
DEBUG - 2012-10-02 16:35:22 --> Config Class Initialized
DEBUG - 2012-10-02 16:35:22 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:35:22 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:35:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:35:22 --> URI Class Initialized
DEBUG - 2012-10-02 16:35:22 --> Router Class Initialized
DEBUG - 2012-10-02 16:35:22 --> Output Class Initialized
DEBUG - 2012-10-02 16:35:22 --> Security Class Initialized
DEBUG - 2012-10-02 16:35:22 --> Input Class Initialized
DEBUG - 2012-10-02 16:35:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 16:35:22 --> Language Class Initialized
DEBUG - 2012-10-02 16:35:22 --> Loader Class Initialized
DEBUG - 2012-10-02 16:35:22 --> Helper loaded: url_helper
DEBUG - 2012-10-02 16:35:22 --> Controller Class Initialized
DEBUG - 2012-10-02 16:35:22 --> Model Class Initialized
DEBUG - 2012-10-02 16:35:22 --> Database Driver Class Initialized
DEBUG - 2012-10-02 16:35:22 --> Final output sent to browser
DEBUG - 2012-10-02 16:35:22 --> Total execution time: 0.1052
DEBUG - 2012-10-02 16:37:39 --> Config Class Initialized
DEBUG - 2012-10-02 16:37:39 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:37:39 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:37:39 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:37:39 --> URI Class Initialized
DEBUG - 2012-10-02 16:37:39 --> Router Class Initialized
DEBUG - 2012-10-02 16:37:39 --> Output Class Initialized
DEBUG - 2012-10-02 16:37:39 --> Security Class Initialized
DEBUG - 2012-10-02 16:37:39 --> Input Class Initialized
DEBUG - 2012-10-02 16:37:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 16:37:39 --> Language Class Initialized
DEBUG - 2012-10-02 16:37:39 --> Loader Class Initialized
DEBUG - 2012-10-02 16:37:39 --> Helper loaded: url_helper
DEBUG - 2012-10-02 16:37:39 --> Controller Class Initialized
DEBUG - 2012-10-02 16:37:39 --> Model Class Initialized
DEBUG - 2012-10-02 16:37:39 --> Database Driver Class Initialized
DEBUG - 2012-10-02 16:37:39 --> Helper loaded: form_helper
DEBUG - 2012-10-02 16:37:39 --> Helper loaded: language_helper
DEBUG - 2012-10-02 16:37:39 --> Form Validation Class Initialized
DEBUG - 2012-10-02 16:37:39 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 16:37:39 --> Upload Class Initialized
DEBUG - 2012-10-02 16:37:39 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 16:37:39 --> Final output sent to browser
DEBUG - 2012-10-02 16:37:39 --> Total execution time: 0.1934
DEBUG - 2012-10-02 16:39:02 --> Config Class Initialized
DEBUG - 2012-10-02 16:39:02 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:39:02 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:39:02 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:39:02 --> URI Class Initialized
DEBUG - 2012-10-02 16:39:02 --> Router Class Initialized
DEBUG - 2012-10-02 16:39:02 --> Output Class Initialized
DEBUG - 2012-10-02 16:39:02 --> Security Class Initialized
DEBUG - 2012-10-02 16:39:02 --> Input Class Initialized
DEBUG - 2012-10-02 16:39:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 16:39:02 --> Language Class Initialized
DEBUG - 2012-10-02 16:39:02 --> Loader Class Initialized
DEBUG - 2012-10-02 16:39:02 --> Helper loaded: url_helper
DEBUG - 2012-10-02 16:39:02 --> Controller Class Initialized
DEBUG - 2012-10-02 16:39:02 --> Model Class Initialized
DEBUG - 2012-10-02 16:39:02 --> Database Driver Class Initialized
DEBUG - 2012-10-02 16:39:02 --> Helper loaded: form_helper
DEBUG - 2012-10-02 16:39:02 --> Helper loaded: language_helper
DEBUG - 2012-10-02 16:39:02 --> Form Validation Class Initialized
DEBUG - 2012-10-02 16:39:02 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 16:39:02 --> Upload Class Initialized
DEBUG - 2012-10-02 16:39:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 16:39:02 --> Language file loaded: language/english/upload_lang.php
ERROR - 2012-10-02 16:39:02 --> The image you are attempting to upload exceedes the maximum height or width.
DEBUG - 2012-10-02 16:39:31 --> Config Class Initialized
DEBUG - 2012-10-02 16:39:31 --> Hooks Class Initialized
DEBUG - 2012-10-02 16:39:31 --> Utf8 Class Initialized
DEBUG - 2012-10-02 16:39:31 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 16:39:31 --> URI Class Initialized
DEBUG - 2012-10-02 16:39:31 --> Router Class Initialized
DEBUG - 2012-10-02 16:39:31 --> Output Class Initialized
DEBUG - 2012-10-02 16:39:31 --> Security Class Initialized
DEBUG - 2012-10-02 16:39:31 --> Input Class Initialized
DEBUG - 2012-10-02 16:39:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 16:39:31 --> Language Class Initialized
DEBUG - 2012-10-02 16:39:31 --> Loader Class Initialized
DEBUG - 2012-10-02 16:39:31 --> Helper loaded: url_helper
DEBUG - 2012-10-02 16:39:31 --> Controller Class Initialized
DEBUG - 2012-10-02 16:39:31 --> Model Class Initialized
DEBUG - 2012-10-02 16:39:31 --> Database Driver Class Initialized
DEBUG - 2012-10-02 16:39:31 --> Helper loaded: form_helper
DEBUG - 2012-10-02 16:39:31 --> Helper loaded: language_helper
DEBUG - 2012-10-02 16:39:31 --> Form Validation Class Initialized
DEBUG - 2012-10-02 16:39:31 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 16:39:31 --> Upload Class Initialized
DEBUG - 2012-10-02 16:39:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 16:39:31 --> Final output sent to browser
DEBUG - 2012-10-02 16:39:31 --> Total execution time: 0.1506
DEBUG - 2012-10-02 17:32:09 --> Config Class Initialized
DEBUG - 2012-10-02 17:32:09 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:32:09 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:32:09 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:32:09 --> URI Class Initialized
DEBUG - 2012-10-02 17:32:09 --> Router Class Initialized
DEBUG - 2012-10-02 17:32:09 --> Output Class Initialized
DEBUG - 2012-10-02 17:32:09 --> Security Class Initialized
DEBUG - 2012-10-02 17:32:09 --> Input Class Initialized
DEBUG - 2012-10-02 17:32:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 17:32:09 --> Language Class Initialized
DEBUG - 2012-10-02 17:32:20 --> Config Class Initialized
DEBUG - 2012-10-02 17:32:20 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:32:20 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:32:20 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:32:20 --> URI Class Initialized
DEBUG - 2012-10-02 17:32:20 --> Router Class Initialized
DEBUG - 2012-10-02 17:32:21 --> Output Class Initialized
DEBUG - 2012-10-02 17:32:21 --> Security Class Initialized
DEBUG - 2012-10-02 17:32:21 --> Input Class Initialized
DEBUG - 2012-10-02 17:32:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 17:32:21 --> Language Class Initialized
DEBUG - 2012-10-02 17:32:25 --> Config Class Initialized
DEBUG - 2012-10-02 17:32:25 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:32:25 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:32:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:32:25 --> URI Class Initialized
DEBUG - 2012-10-02 17:32:25 --> Router Class Initialized
DEBUG - 2012-10-02 17:32:25 --> Output Class Initialized
DEBUG - 2012-10-02 17:32:25 --> Security Class Initialized
DEBUG - 2012-10-02 17:32:25 --> Input Class Initialized
DEBUG - 2012-10-02 17:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 17:32:25 --> Language Class Initialized
DEBUG - 2012-10-02 17:33:48 --> Config Class Initialized
DEBUG - 2012-10-02 17:33:48 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:33:48 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:33:48 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:33:48 --> URI Class Initialized
DEBUG - 2012-10-02 17:33:48 --> Router Class Initialized
DEBUG - 2012-10-02 17:33:48 --> Output Class Initialized
DEBUG - 2012-10-02 17:33:48 --> Security Class Initialized
DEBUG - 2012-10-02 17:33:48 --> Input Class Initialized
DEBUG - 2012-10-02 17:33:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 17:33:48 --> Language Class Initialized
DEBUG - 2012-10-02 17:33:48 --> Loader Class Initialized
DEBUG - 2012-10-02 17:33:48 --> Helper loaded: url_helper
DEBUG - 2012-10-02 17:33:48 --> Controller Class Initialized
DEBUG - 2012-10-02 17:33:48 --> Model Class Initialized
DEBUG - 2012-10-02 17:33:48 --> Database Driver Class Initialized
DEBUG - 2012-10-02 17:33:48 --> Helper loaded: form_helper
DEBUG - 2012-10-02 17:33:48 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 17:33:48 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 17:33:50 --> Config Class Initialized
DEBUG - 2012-10-02 17:33:50 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:33:50 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:33:50 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:33:50 --> URI Class Initialized
DEBUG - 2012-10-02 17:33:50 --> Router Class Initialized
DEBUG - 2012-10-02 17:33:50 --> Output Class Initialized
DEBUG - 2012-10-02 17:33:50 --> Security Class Initialized
DEBUG - 2012-10-02 17:33:50 --> Input Class Initialized
DEBUG - 2012-10-02 17:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 17:33:50 --> Language Class Initialized
DEBUG - 2012-10-02 17:33:50 --> Loader Class Initialized
DEBUG - 2012-10-02 17:33:50 --> Helper loaded: url_helper
DEBUG - 2012-10-02 17:33:50 --> Controller Class Initialized
DEBUG - 2012-10-02 17:33:50 --> Model Class Initialized
DEBUG - 2012-10-02 17:33:50 --> Database Driver Class Initialized
DEBUG - 2012-10-02 17:33:50 --> Helper loaded: form_helper
DEBUG - 2012-10-02 17:33:50 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 17:33:50 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 17:34:37 --> Config Class Initialized
DEBUG - 2012-10-02 17:34:37 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:34:37 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:34:37 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:34:37 --> URI Class Initialized
DEBUG - 2012-10-02 17:34:37 --> Router Class Initialized
DEBUG - 2012-10-02 17:34:38 --> Output Class Initialized
DEBUG - 2012-10-02 17:34:38 --> Security Class Initialized
DEBUG - 2012-10-02 17:34:38 --> Input Class Initialized
DEBUG - 2012-10-02 17:34:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 17:34:38 --> Language Class Initialized
DEBUG - 2012-10-02 17:34:38 --> Loader Class Initialized
DEBUG - 2012-10-02 17:34:38 --> Helper loaded: url_helper
DEBUG - 2012-10-02 17:34:38 --> Controller Class Initialized
DEBUG - 2012-10-02 17:34:38 --> Model Class Initialized
DEBUG - 2012-10-02 17:34:38 --> Database Driver Class Initialized
DEBUG - 2012-10-02 17:34:38 --> Helper loaded: form_helper
DEBUG - 2012-10-02 17:34:38 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 17:34:38 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 17:34:38 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 17:34:38 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 17:34:38 --> Final output sent to browser
DEBUG - 2012-10-02 17:34:38 --> Total execution time: 0.0399
DEBUG - 2012-10-02 17:34:40 --> Config Class Initialized
DEBUG - 2012-10-02 17:34:40 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:34:40 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:34:40 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:34:40 --> URI Class Initialized
DEBUG - 2012-10-02 17:34:40 --> Router Class Initialized
ERROR - 2012-10-02 17:34:40 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 17:34:40 --> Config Class Initialized
DEBUG - 2012-10-02 17:34:40 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:34:40 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:34:40 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:34:40 --> URI Class Initialized
DEBUG - 2012-10-02 17:34:40 --> Router Class Initialized
ERROR - 2012-10-02 17:34:40 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 17:34:40 --> Config Class Initialized
DEBUG - 2012-10-02 17:34:40 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:34:40 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:34:40 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:34:40 --> URI Class Initialized
DEBUG - 2012-10-02 17:34:40 --> Router Class Initialized
ERROR - 2012-10-02 17:34:40 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 17:34:40 --> Config Class Initialized
DEBUG - 2012-10-02 17:34:40 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:34:40 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:34:40 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:34:40 --> URI Class Initialized
DEBUG - 2012-10-02 17:34:40 --> Router Class Initialized
ERROR - 2012-10-02 17:34:40 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 17:35:03 --> Config Class Initialized
DEBUG - 2012-10-02 17:35:03 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:35:03 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:35:03 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:35:03 --> URI Class Initialized
DEBUG - 2012-10-02 17:35:03 --> Router Class Initialized
DEBUG - 2012-10-02 17:35:03 --> Output Class Initialized
DEBUG - 2012-10-02 17:35:03 --> Security Class Initialized
DEBUG - 2012-10-02 17:35:03 --> Input Class Initialized
DEBUG - 2012-10-02 17:35:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 17:35:03 --> Language Class Initialized
DEBUG - 2012-10-02 17:35:03 --> Loader Class Initialized
DEBUG - 2012-10-02 17:35:03 --> Helper loaded: url_helper
DEBUG - 2012-10-02 17:35:03 --> Controller Class Initialized
DEBUG - 2012-10-02 17:35:03 --> Model Class Initialized
DEBUG - 2012-10-02 17:35:03 --> Database Driver Class Initialized
DEBUG - 2012-10-02 17:35:03 --> Helper loaded: form_helper
DEBUG - 2012-10-02 17:35:03 --> Helper loaded: language_helper
DEBUG - 2012-10-02 17:35:03 --> Form Validation Class Initialized
DEBUG - 2012-10-02 17:35:03 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 17:35:03 --> Upload Class Initialized
DEBUG - 2012-10-02 17:35:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 17:35:04 --> Final output sent to browser
DEBUG - 2012-10-02 17:35:04 --> Total execution time: 0.2061
DEBUG - 2012-10-02 17:38:56 --> Config Class Initialized
DEBUG - 2012-10-02 17:38:56 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:38:56 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:38:56 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:38:56 --> URI Class Initialized
DEBUG - 2012-10-02 17:38:56 --> Router Class Initialized
DEBUG - 2012-10-02 17:38:56 --> Output Class Initialized
DEBUG - 2012-10-02 17:38:56 --> Security Class Initialized
DEBUG - 2012-10-02 17:38:56 --> Input Class Initialized
DEBUG - 2012-10-02 17:38:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 17:38:56 --> Language Class Initialized
DEBUG - 2012-10-02 17:38:56 --> Loader Class Initialized
DEBUG - 2012-10-02 17:38:56 --> Helper loaded: url_helper
DEBUG - 2012-10-02 17:38:56 --> Controller Class Initialized
DEBUG - 2012-10-02 17:38:56 --> Model Class Initialized
DEBUG - 2012-10-02 17:38:56 --> Database Driver Class Initialized
DEBUG - 2012-10-02 17:38:56 --> Helper loaded: form_helper
DEBUG - 2012-10-02 17:38:56 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 17:38:56 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 17:38:56 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 17:38:56 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 17:38:56 --> Final output sent to browser
DEBUG - 2012-10-02 17:38:56 --> Total execution time: 0.0402
DEBUG - 2012-10-02 17:38:58 --> Config Class Initialized
DEBUG - 2012-10-02 17:38:58 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:38:58 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:38:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:38:58 --> URI Class Initialized
DEBUG - 2012-10-02 17:38:58 --> Router Class Initialized
ERROR - 2012-10-02 17:38:58 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 17:38:58 --> Config Class Initialized
DEBUG - 2012-10-02 17:38:58 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:38:58 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:38:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:38:58 --> URI Class Initialized
DEBUG - 2012-10-02 17:38:58 --> Router Class Initialized
ERROR - 2012-10-02 17:38:58 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 17:38:58 --> Config Class Initialized
DEBUG - 2012-10-02 17:38:58 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:38:58 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:38:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:38:58 --> URI Class Initialized
DEBUG - 2012-10-02 17:38:58 --> Router Class Initialized
ERROR - 2012-10-02 17:38:58 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 17:38:58 --> Config Class Initialized
DEBUG - 2012-10-02 17:38:58 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:38:58 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:38:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:38:58 --> URI Class Initialized
DEBUG - 2012-10-02 17:38:58 --> Router Class Initialized
ERROR - 2012-10-02 17:38:58 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 17:38:58 --> Config Class Initialized
DEBUG - 2012-10-02 17:38:58 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:38:58 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:38:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:38:58 --> URI Class Initialized
DEBUG - 2012-10-02 17:38:58 --> Router Class Initialized
ERROR - 2012-10-02 17:38:58 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 17:38:59 --> Config Class Initialized
DEBUG - 2012-10-02 17:38:59 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:38:59 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:38:59 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:38:59 --> URI Class Initialized
DEBUG - 2012-10-02 17:38:59 --> Router Class Initialized
ERROR - 2012-10-02 17:38:59 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 17:38:59 --> Config Class Initialized
DEBUG - 2012-10-02 17:38:59 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:38:59 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:38:59 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:38:59 --> URI Class Initialized
DEBUG - 2012-10-02 17:38:59 --> Router Class Initialized
ERROR - 2012-10-02 17:38:59 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 17:39:56 --> Config Class Initialized
DEBUG - 2012-10-02 17:39:56 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:39:56 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:39:56 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:39:56 --> URI Class Initialized
DEBUG - 2012-10-02 17:39:56 --> Router Class Initialized
DEBUG - 2012-10-02 17:39:56 --> Output Class Initialized
DEBUG - 2012-10-02 17:39:56 --> Security Class Initialized
DEBUG - 2012-10-02 17:39:56 --> Input Class Initialized
DEBUG - 2012-10-02 17:39:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 17:39:56 --> Language Class Initialized
DEBUG - 2012-10-02 17:39:56 --> Loader Class Initialized
DEBUG - 2012-10-02 17:39:56 --> Helper loaded: url_helper
DEBUG - 2012-10-02 17:39:56 --> Controller Class Initialized
DEBUG - 2012-10-02 17:39:56 --> Model Class Initialized
DEBUG - 2012-10-02 17:39:56 --> Database Driver Class Initialized
DEBUG - 2012-10-02 17:39:56 --> Helper loaded: form_helper
DEBUG - 2012-10-02 17:39:56 --> Helper loaded: language_helper
DEBUG - 2012-10-02 17:39:56 --> Form Validation Class Initialized
DEBUG - 2012-10-02 17:39:56 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 17:39:56 --> Upload Class Initialized
DEBUG - 2012-10-02 17:39:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 17:39:56 --> Final output sent to browser
DEBUG - 2012-10-02 17:39:56 --> Total execution time: 0.1222
DEBUG - 2012-10-02 17:40:31 --> Config Class Initialized
DEBUG - 2012-10-02 17:40:31 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:40:31 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:40:31 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:40:31 --> URI Class Initialized
DEBUG - 2012-10-02 17:40:31 --> Router Class Initialized
DEBUG - 2012-10-02 17:40:31 --> Output Class Initialized
DEBUG - 2012-10-02 17:40:31 --> Security Class Initialized
DEBUG - 2012-10-02 17:40:31 --> Input Class Initialized
DEBUG - 2012-10-02 17:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 17:40:31 --> Language Class Initialized
DEBUG - 2012-10-02 17:40:31 --> Loader Class Initialized
DEBUG - 2012-10-02 17:40:31 --> Helper loaded: url_helper
DEBUG - 2012-10-02 17:40:31 --> Controller Class Initialized
DEBUG - 2012-10-02 17:40:31 --> Model Class Initialized
DEBUG - 2012-10-02 17:40:31 --> Database Driver Class Initialized
DEBUG - 2012-10-02 17:40:31 --> Helper loaded: form_helper
DEBUG - 2012-10-02 17:40:31 --> Helper loaded: language_helper
DEBUG - 2012-10-02 17:40:31 --> Form Validation Class Initialized
DEBUG - 2012-10-02 17:40:31 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 17:40:31 --> Upload Class Initialized
DEBUG - 2012-10-02 17:40:31 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2012-10-02 17:40:31 --> Severity: Notice  --> Undefined variable: thumns /home/jwp/www/justinwylliephotography.com/clients/application/controllers/admin/pricing.php 349
ERROR - 2012-10-02 17:40:31 --> Severity: Warning  --> mkdir(): No such file or directory /home/jwp/www/justinwylliephotography.com/clients/application/controllers/admin/pricing.php 349
DEBUG - 2012-10-02 17:41:22 --> Config Class Initialized
DEBUG - 2012-10-02 17:41:22 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:41:22 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:41:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:41:22 --> URI Class Initialized
DEBUG - 2012-10-02 17:41:22 --> Router Class Initialized
DEBUG - 2012-10-02 17:41:22 --> Output Class Initialized
DEBUG - 2012-10-02 17:41:22 --> Security Class Initialized
DEBUG - 2012-10-02 17:41:22 --> Input Class Initialized
DEBUG - 2012-10-02 17:41:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 17:41:22 --> Language Class Initialized
DEBUG - 2012-10-02 17:41:22 --> Loader Class Initialized
DEBUG - 2012-10-02 17:41:22 --> Helper loaded: url_helper
DEBUG - 2012-10-02 17:41:22 --> Controller Class Initialized
DEBUG - 2012-10-02 17:41:22 --> Model Class Initialized
DEBUG - 2012-10-02 17:41:22 --> Database Driver Class Initialized
DEBUG - 2012-10-02 17:41:22 --> Helper loaded: form_helper
DEBUG - 2012-10-02 17:41:22 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 17:41:22 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 17:41:22 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 17:41:22 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 17:41:22 --> Final output sent to browser
DEBUG - 2012-10-02 17:41:22 --> Total execution time: 0.0401
DEBUG - 2012-10-02 17:41:24 --> Config Class Initialized
DEBUG - 2012-10-02 17:41:24 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:41:24 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:41:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:41:24 --> URI Class Initialized
DEBUG - 2012-10-02 17:41:24 --> Router Class Initialized
ERROR - 2012-10-02 17:41:24 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 17:41:24 --> Config Class Initialized
DEBUG - 2012-10-02 17:41:24 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:41:24 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:41:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:41:24 --> URI Class Initialized
DEBUG - 2012-10-02 17:41:24 --> Router Class Initialized
ERROR - 2012-10-02 17:41:24 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 17:41:24 --> Config Class Initialized
DEBUG - 2012-10-02 17:41:24 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:41:24 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:41:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:41:24 --> URI Class Initialized
DEBUG - 2012-10-02 17:41:24 --> Router Class Initialized
ERROR - 2012-10-02 17:41:24 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 17:41:24 --> Config Class Initialized
DEBUG - 2012-10-02 17:41:24 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:41:24 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:41:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:41:24 --> URI Class Initialized
DEBUG - 2012-10-02 17:41:24 --> Router Class Initialized
ERROR - 2012-10-02 17:41:24 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 17:41:24 --> Config Class Initialized
DEBUG - 2012-10-02 17:41:24 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:41:24 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:41:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:41:24 --> URI Class Initialized
DEBUG - 2012-10-02 17:41:24 --> Router Class Initialized
ERROR - 2012-10-02 17:41:24 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 17:41:24 --> Config Class Initialized
DEBUG - 2012-10-02 17:41:24 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:41:24 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:41:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:41:24 --> URI Class Initialized
DEBUG - 2012-10-02 17:41:24 --> Router Class Initialized
ERROR - 2012-10-02 17:41:24 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 17:41:24 --> Config Class Initialized
DEBUG - 2012-10-02 17:41:24 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:41:24 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:41:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:41:24 --> URI Class Initialized
DEBUG - 2012-10-02 17:41:24 --> Router Class Initialized
ERROR - 2012-10-02 17:41:24 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 17:41:31 --> Config Class Initialized
DEBUG - 2012-10-02 17:41:31 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:41:31 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:41:31 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:41:31 --> URI Class Initialized
DEBUG - 2012-10-02 17:41:31 --> Router Class Initialized
DEBUG - 2012-10-02 17:41:31 --> Output Class Initialized
DEBUG - 2012-10-02 17:41:31 --> Security Class Initialized
DEBUG - 2012-10-02 17:41:31 --> Input Class Initialized
DEBUG - 2012-10-02 17:41:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 17:41:31 --> Language Class Initialized
DEBUG - 2012-10-02 17:41:31 --> Loader Class Initialized
DEBUG - 2012-10-02 17:41:31 --> Helper loaded: url_helper
DEBUG - 2012-10-02 17:41:31 --> Controller Class Initialized
DEBUG - 2012-10-02 17:41:31 --> Model Class Initialized
DEBUG - 2012-10-02 17:41:31 --> Database Driver Class Initialized
DEBUG - 2012-10-02 17:41:31 --> Helper loaded: form_helper
DEBUG - 2012-10-02 17:41:31 --> Helper loaded: language_helper
DEBUG - 2012-10-02 17:41:31 --> Form Validation Class Initialized
DEBUG - 2012-10-02 17:41:31 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 17:41:31 --> Upload Class Initialized
DEBUG - 2012-10-02 17:41:31 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2012-10-02 17:41:31 --> Severity: Warning  --> mkdir(): Permission denied /home/jwp/www/justinwylliephotography.com/clients/application/controllers/admin/pricing.php 349
DEBUG - 2012-10-02 17:42:27 --> Config Class Initialized
DEBUG - 2012-10-02 17:42:27 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:42:27 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:42:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:42:27 --> URI Class Initialized
DEBUG - 2012-10-02 17:42:27 --> Router Class Initialized
DEBUG - 2012-10-02 17:42:27 --> Output Class Initialized
DEBUG - 2012-10-02 17:42:27 --> Security Class Initialized
DEBUG - 2012-10-02 17:42:27 --> Input Class Initialized
DEBUG - 2012-10-02 17:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 17:42:27 --> Language Class Initialized
DEBUG - 2012-10-02 17:42:28 --> Loader Class Initialized
DEBUG - 2012-10-02 17:42:28 --> Helper loaded: url_helper
DEBUG - 2012-10-02 17:42:28 --> Controller Class Initialized
DEBUG - 2012-10-02 17:42:28 --> Model Class Initialized
DEBUG - 2012-10-02 17:42:28 --> Database Driver Class Initialized
DEBUG - 2012-10-02 17:42:28 --> Helper loaded: form_helper
DEBUG - 2012-10-02 17:42:28 --> Helper loaded: language_helper
DEBUG - 2012-10-02 17:42:28 --> Form Validation Class Initialized
DEBUG - 2012-10-02 17:42:28 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 17:42:28 --> Upload Class Initialized
DEBUG - 2012-10-02 17:42:28 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2012-10-02 17:42:28 --> Severity: Warning  --> mkdir(): Permission denied /home/jwp/www/justinwylliephotography.com/clients/application/controllers/admin/pricing.php 347
DEBUG - 2012-10-02 17:49:23 --> Config Class Initialized
DEBUG - 2012-10-02 17:49:23 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:49:23 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:49:23 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:49:23 --> URI Class Initialized
DEBUG - 2012-10-02 17:49:23 --> Router Class Initialized
DEBUG - 2012-10-02 17:49:23 --> Output Class Initialized
DEBUG - 2012-10-02 17:49:23 --> Security Class Initialized
DEBUG - 2012-10-02 17:49:23 --> Input Class Initialized
DEBUG - 2012-10-02 17:49:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 17:49:23 --> Language Class Initialized
DEBUG - 2012-10-02 17:49:23 --> Loader Class Initialized
DEBUG - 2012-10-02 17:49:23 --> Helper loaded: url_helper
DEBUG - 2012-10-02 17:49:23 --> Controller Class Initialized
DEBUG - 2012-10-02 17:49:23 --> Model Class Initialized
DEBUG - 2012-10-02 17:49:23 --> Database Driver Class Initialized
DEBUG - 2012-10-02 17:49:23 --> Helper loaded: form_helper
DEBUG - 2012-10-02 17:49:23 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 17:49:23 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 17:49:23 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 17:49:23 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 17:49:23 --> Final output sent to browser
DEBUG - 2012-10-02 17:49:23 --> Total execution time: 0.0740
DEBUG - 2012-10-02 17:49:25 --> Config Class Initialized
DEBUG - 2012-10-02 17:49:25 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:49:25 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:49:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:49:25 --> URI Class Initialized
DEBUG - 2012-10-02 17:49:25 --> Router Class Initialized
ERROR - 2012-10-02 17:49:25 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 17:49:25 --> Config Class Initialized
DEBUG - 2012-10-02 17:49:25 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:49:25 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:49:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:49:25 --> URI Class Initialized
DEBUG - 2012-10-02 17:49:25 --> Router Class Initialized
ERROR - 2012-10-02 17:49:25 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 17:49:25 --> Config Class Initialized
DEBUG - 2012-10-02 17:49:25 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:49:25 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:49:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:49:25 --> URI Class Initialized
DEBUG - 2012-10-02 17:49:25 --> Router Class Initialized
ERROR - 2012-10-02 17:49:25 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 17:49:25 --> Config Class Initialized
DEBUG - 2012-10-02 17:49:25 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:49:25 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:49:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:49:25 --> URI Class Initialized
DEBUG - 2012-10-02 17:49:25 --> Router Class Initialized
ERROR - 2012-10-02 17:49:25 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 17:49:25 --> Config Class Initialized
DEBUG - 2012-10-02 17:49:25 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:49:25 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:49:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:49:25 --> URI Class Initialized
DEBUG - 2012-10-02 17:49:25 --> Router Class Initialized
ERROR - 2012-10-02 17:49:25 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 17:49:25 --> Config Class Initialized
DEBUG - 2012-10-02 17:49:25 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:49:25 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:49:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:49:25 --> URI Class Initialized
DEBUG - 2012-10-02 17:49:25 --> Router Class Initialized
ERROR - 2012-10-02 17:49:25 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 17:49:25 --> Config Class Initialized
DEBUG - 2012-10-02 17:49:25 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:49:25 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:49:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:49:25 --> URI Class Initialized
DEBUG - 2012-10-02 17:49:25 --> Router Class Initialized
ERROR - 2012-10-02 17:49:25 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 17:49:25 --> Config Class Initialized
DEBUG - 2012-10-02 17:49:25 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:49:25 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:49:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:49:25 --> URI Class Initialized
DEBUG - 2012-10-02 17:49:25 --> Router Class Initialized
ERROR - 2012-10-02 17:49:25 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 17:49:33 --> Config Class Initialized
DEBUG - 2012-10-02 17:49:33 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:49:33 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:49:33 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:49:33 --> URI Class Initialized
DEBUG - 2012-10-02 17:49:33 --> Router Class Initialized
DEBUG - 2012-10-02 17:49:33 --> Output Class Initialized
DEBUG - 2012-10-02 17:49:33 --> Security Class Initialized
DEBUG - 2012-10-02 17:49:33 --> Input Class Initialized
DEBUG - 2012-10-02 17:49:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 17:49:33 --> Language Class Initialized
DEBUG - 2012-10-02 17:49:33 --> Loader Class Initialized
DEBUG - 2012-10-02 17:49:33 --> Helper loaded: url_helper
DEBUG - 2012-10-02 17:49:33 --> Controller Class Initialized
DEBUG - 2012-10-02 17:49:33 --> Model Class Initialized
DEBUG - 2012-10-02 17:49:33 --> Database Driver Class Initialized
DEBUG - 2012-10-02 17:49:33 --> Helper loaded: form_helper
DEBUG - 2012-10-02 17:49:33 --> Helper loaded: language_helper
DEBUG - 2012-10-02 17:49:33 --> Form Validation Class Initialized
DEBUG - 2012-10-02 17:49:33 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 17:49:33 --> Upload Class Initialized
DEBUG - 2012-10-02 17:49:33 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2012-10-02 17:49:33 --> Severity: Warning  --> mkdir(): Permission denied /home/jwp/www/justinwylliephotography.com/clients/application/controllers/admin/pricing.php 347
DEBUG - 2012-10-02 17:55:27 --> Config Class Initialized
DEBUG - 2012-10-02 17:55:27 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:55:27 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:55:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:55:27 --> URI Class Initialized
DEBUG - 2012-10-02 17:55:27 --> Router Class Initialized
DEBUG - 2012-10-02 17:55:27 --> Output Class Initialized
DEBUG - 2012-10-02 17:55:27 --> Security Class Initialized
DEBUG - 2012-10-02 17:55:27 --> Input Class Initialized
DEBUG - 2012-10-02 17:55:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 17:55:27 --> Language Class Initialized
DEBUG - 2012-10-02 17:55:27 --> Loader Class Initialized
DEBUG - 2012-10-02 17:55:27 --> Helper loaded: url_helper
DEBUG - 2012-10-02 17:55:27 --> Controller Class Initialized
DEBUG - 2012-10-02 17:55:27 --> Model Class Initialized
DEBUG - 2012-10-02 17:55:27 --> Database Driver Class Initialized
DEBUG - 2012-10-02 17:55:27 --> Helper loaded: form_helper
DEBUG - 2012-10-02 17:55:27 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 17:55:27 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 17:55:27 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 17:55:27 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 17:55:27 --> Final output sent to browser
DEBUG - 2012-10-02 17:55:27 --> Total execution time: 0.0500
DEBUG - 2012-10-02 17:55:29 --> Config Class Initialized
DEBUG - 2012-10-02 17:55:29 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:55:29 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:55:29 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:55:29 --> URI Class Initialized
DEBUG - 2012-10-02 17:55:29 --> Router Class Initialized
ERROR - 2012-10-02 17:55:29 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 17:55:29 --> Config Class Initialized
DEBUG - 2012-10-02 17:55:29 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:55:29 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:55:29 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:55:29 --> URI Class Initialized
DEBUG - 2012-10-02 17:55:29 --> Router Class Initialized
ERROR - 2012-10-02 17:55:29 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 17:55:29 --> Config Class Initialized
DEBUG - 2012-10-02 17:55:29 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:55:29 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:55:29 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:55:29 --> URI Class Initialized
DEBUG - 2012-10-02 17:55:29 --> Router Class Initialized
ERROR - 2012-10-02 17:55:29 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 17:55:29 --> Config Class Initialized
DEBUG - 2012-10-02 17:55:29 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:55:29 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:55:29 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:55:29 --> URI Class Initialized
DEBUG - 2012-10-02 17:55:29 --> Router Class Initialized
ERROR - 2012-10-02 17:55:29 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 17:55:29 --> Config Class Initialized
DEBUG - 2012-10-02 17:55:29 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:55:29 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:55:29 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:55:29 --> URI Class Initialized
DEBUG - 2012-10-02 17:55:29 --> Router Class Initialized
ERROR - 2012-10-02 17:55:29 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 17:55:29 --> Config Class Initialized
DEBUG - 2012-10-02 17:55:29 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:55:29 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:55:29 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:55:29 --> URI Class Initialized
DEBUG - 2012-10-02 17:55:29 --> Router Class Initialized
ERROR - 2012-10-02 17:55:29 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 17:55:29 --> Config Class Initialized
DEBUG - 2012-10-02 17:55:29 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:55:29 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:55:29 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:55:29 --> URI Class Initialized
DEBUG - 2012-10-02 17:55:29 --> Router Class Initialized
ERROR - 2012-10-02 17:55:29 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 17:55:29 --> Config Class Initialized
DEBUG - 2012-10-02 17:55:29 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:55:29 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:55:29 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:55:29 --> URI Class Initialized
DEBUG - 2012-10-02 17:55:29 --> Router Class Initialized
ERROR - 2012-10-02 17:55:29 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 17:55:37 --> Config Class Initialized
DEBUG - 2012-10-02 17:55:37 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:55:37 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:55:37 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:55:37 --> URI Class Initialized
DEBUG - 2012-10-02 17:55:37 --> Router Class Initialized
DEBUG - 2012-10-02 17:55:37 --> Output Class Initialized
DEBUG - 2012-10-02 17:55:37 --> Security Class Initialized
DEBUG - 2012-10-02 17:55:37 --> Input Class Initialized
DEBUG - 2012-10-02 17:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 17:55:37 --> Language Class Initialized
DEBUG - 2012-10-02 17:55:37 --> Loader Class Initialized
DEBUG - 2012-10-02 17:55:37 --> Helper loaded: url_helper
DEBUG - 2012-10-02 17:55:37 --> Controller Class Initialized
DEBUG - 2012-10-02 17:55:37 --> Model Class Initialized
DEBUG - 2012-10-02 17:55:37 --> Database Driver Class Initialized
DEBUG - 2012-10-02 17:55:37 --> Helper loaded: form_helper
DEBUG - 2012-10-02 17:55:37 --> Helper loaded: language_helper
DEBUG - 2012-10-02 17:55:37 --> Form Validation Class Initialized
DEBUG - 2012-10-02 17:55:37 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 17:55:37 --> Upload Class Initialized
DEBUG - 2012-10-02 17:55:37 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2012-10-02 17:55:37 --> Severity: Warning  --> mkdir(): Permission denied /home/jwp/www/justinwylliephotography.com/clients/application/controllers/admin/pricing.php 347
DEBUG - 2012-10-02 17:56:31 --> Config Class Initialized
DEBUG - 2012-10-02 17:56:31 --> Hooks Class Initialized
DEBUG - 2012-10-02 17:56:31 --> Utf8 Class Initialized
DEBUG - 2012-10-02 17:56:31 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 17:56:31 --> URI Class Initialized
DEBUG - 2012-10-02 17:56:31 --> Router Class Initialized
DEBUG - 2012-10-02 17:56:31 --> Output Class Initialized
DEBUG - 2012-10-02 17:56:31 --> Security Class Initialized
DEBUG - 2012-10-02 17:56:31 --> Input Class Initialized
DEBUG - 2012-10-02 17:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 17:56:31 --> Language Class Initialized
DEBUG - 2012-10-02 17:56:31 --> Loader Class Initialized
DEBUG - 2012-10-02 17:56:31 --> Helper loaded: url_helper
DEBUG - 2012-10-02 17:56:31 --> Controller Class Initialized
DEBUG - 2012-10-02 17:56:31 --> Model Class Initialized
DEBUG - 2012-10-02 17:56:31 --> Database Driver Class Initialized
DEBUG - 2012-10-02 17:56:31 --> Helper loaded: form_helper
DEBUG - 2012-10-02 17:56:31 --> Helper loaded: language_helper
DEBUG - 2012-10-02 17:56:31 --> Form Validation Class Initialized
DEBUG - 2012-10-02 17:56:31 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 17:56:31 --> Upload Class Initialized
DEBUG - 2012-10-02 17:56:31 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2012-10-02 17:56:31 --> Severity: Warning  --> mkdir(): Permission denied /home/jwp/www/justinwylliephotography.com/clients/application/controllers/admin/pricing.php 347
DEBUG - 2012-10-02 18:00:49 --> Config Class Initialized
DEBUG - 2012-10-02 18:00:49 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:00:49 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:00:49 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:00:49 --> URI Class Initialized
DEBUG - 2012-10-02 18:00:49 --> Router Class Initialized
DEBUG - 2012-10-02 18:00:49 --> Output Class Initialized
DEBUG - 2012-10-02 18:00:49 --> Security Class Initialized
DEBUG - 2012-10-02 18:00:49 --> Input Class Initialized
DEBUG - 2012-10-02 18:00:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:00:49 --> Language Class Initialized
DEBUG - 2012-10-02 18:00:49 --> Loader Class Initialized
DEBUG - 2012-10-02 18:00:49 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:00:49 --> Controller Class Initialized
DEBUG - 2012-10-02 18:00:49 --> Model Class Initialized
DEBUG - 2012-10-02 18:00:50 --> Database Driver Class Initialized
DEBUG - 2012-10-02 18:00:50 --> Helper loaded: form_helper
DEBUG - 2012-10-02 18:00:50 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 18:00:50 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 18:00:50 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 18:00:50 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 18:00:50 --> Final output sent to browser
DEBUG - 2012-10-02 18:00:50 --> Total execution time: 0.0415
DEBUG - 2012-10-02 18:00:52 --> Config Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:00:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:00:52 --> URI Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Router Class Initialized
ERROR - 2012-10-02 18:00:52 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 18:00:52 --> Config Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:00:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:00:52 --> URI Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Router Class Initialized
ERROR - 2012-10-02 18:00:52 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 18:00:52 --> Config Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:00:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:00:52 --> URI Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Router Class Initialized
ERROR - 2012-10-02 18:00:52 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 18:00:52 --> Config Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:00:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:00:52 --> URI Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Router Class Initialized
ERROR - 2012-10-02 18:00:52 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:00:52 --> Config Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:00:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:00:52 --> URI Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Router Class Initialized
ERROR - 2012-10-02 18:00:52 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:00:52 --> Config Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:00:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:00:52 --> URI Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Router Class Initialized
ERROR - 2012-10-02 18:00:52 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:00:52 --> Config Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:00:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:00:52 --> URI Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Router Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Config Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:00:52 --> UTF-8 Support Enabled
ERROR - 2012-10-02 18:00:52 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:00:52 --> URI Class Initialized
DEBUG - 2012-10-02 18:00:52 --> Router Class Initialized
ERROR - 2012-10-02 18:00:52 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:01:00 --> Config Class Initialized
DEBUG - 2012-10-02 18:01:00 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:01:00 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:01:00 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:01:00 --> URI Class Initialized
DEBUG - 2012-10-02 18:01:00 --> Router Class Initialized
DEBUG - 2012-10-02 18:01:00 --> Output Class Initialized
DEBUG - 2012-10-02 18:01:00 --> Security Class Initialized
DEBUG - 2012-10-02 18:01:00 --> Input Class Initialized
DEBUG - 2012-10-02 18:01:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:01:00 --> Language Class Initialized
DEBUG - 2012-10-02 18:01:00 --> Loader Class Initialized
DEBUG - 2012-10-02 18:01:00 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:01:00 --> Controller Class Initialized
DEBUG - 2012-10-02 18:01:00 --> Model Class Initialized
DEBUG - 2012-10-02 18:01:00 --> Database Driver Class Initialized
DEBUG - 2012-10-02 18:01:00 --> Helper loaded: form_helper
DEBUG - 2012-10-02 18:01:00 --> Helper loaded: language_helper
DEBUG - 2012-10-02 18:01:00 --> Form Validation Class Initialized
DEBUG - 2012-10-02 18:01:00 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 18:01:00 --> Upload Class Initialized
DEBUG - 2012-10-02 18:01:00 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2012-10-02 18:01:00 --> Severity: Warning  --> mkdir(): Permission denied /home/jwp/www/justinwylliephotography.com/clients/application/controllers/admin/pricing.php 347
DEBUG - 2012-10-02 18:01:53 --> Config Class Initialized
DEBUG - 2012-10-02 18:01:53 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:01:53 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:01:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:01:53 --> URI Class Initialized
DEBUG - 2012-10-02 18:01:53 --> Router Class Initialized
DEBUG - 2012-10-02 18:01:53 --> Output Class Initialized
DEBUG - 2012-10-02 18:01:53 --> Security Class Initialized
DEBUG - 2012-10-02 18:01:53 --> Input Class Initialized
DEBUG - 2012-10-02 18:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:01:53 --> Language Class Initialized
DEBUG - 2012-10-02 18:01:53 --> Loader Class Initialized
DEBUG - 2012-10-02 18:01:53 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:01:53 --> Controller Class Initialized
DEBUG - 2012-10-02 18:01:53 --> Model Class Initialized
DEBUG - 2012-10-02 18:01:53 --> Database Driver Class Initialized
DEBUG - 2012-10-02 18:01:53 --> Helper loaded: form_helper
DEBUG - 2012-10-02 18:01:53 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 18:01:53 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 18:01:53 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 18:01:53 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 18:01:53 --> Final output sent to browser
DEBUG - 2012-10-02 18:01:53 --> Total execution time: 0.0398
DEBUG - 2012-10-02 18:01:55 --> Config Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:01:55 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:01:55 --> URI Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Router Class Initialized
ERROR - 2012-10-02 18:01:55 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 18:01:55 --> Config Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:01:55 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:01:55 --> URI Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Router Class Initialized
ERROR - 2012-10-02 18:01:55 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 18:01:55 --> Config Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:01:55 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:01:55 --> URI Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Router Class Initialized
ERROR - 2012-10-02 18:01:55 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 18:01:55 --> Config Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:01:55 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:01:55 --> URI Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Router Class Initialized
ERROR - 2012-10-02 18:01:55 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:01:55 --> Config Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:01:55 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:01:55 --> URI Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Router Class Initialized
ERROR - 2012-10-02 18:01:55 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:01:55 --> Config Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:01:55 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:01:55 --> URI Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Router Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Config Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:01:55 --> UTF-8 Support Enabled
ERROR - 2012-10-02 18:01:55 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:01:55 --> URI Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Router Class Initialized
ERROR - 2012-10-02 18:01:55 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:01:55 --> Config Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:01:55 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:01:55 --> URI Class Initialized
DEBUG - 2012-10-02 18:01:55 --> Router Class Initialized
ERROR - 2012-10-02 18:01:55 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:02:02 --> Config Class Initialized
DEBUG - 2012-10-02 18:02:02 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:02:02 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:02:02 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:02:02 --> URI Class Initialized
DEBUG - 2012-10-02 18:02:02 --> Router Class Initialized
DEBUG - 2012-10-02 18:02:02 --> Output Class Initialized
DEBUG - 2012-10-02 18:02:02 --> Security Class Initialized
DEBUG - 2012-10-02 18:02:02 --> Input Class Initialized
DEBUG - 2012-10-02 18:02:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:02:02 --> Language Class Initialized
DEBUG - 2012-10-02 18:02:02 --> Loader Class Initialized
DEBUG - 2012-10-02 18:02:02 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:02:02 --> Controller Class Initialized
DEBUG - 2012-10-02 18:02:02 --> Model Class Initialized
DEBUG - 2012-10-02 18:02:02 --> Database Driver Class Initialized
DEBUG - 2012-10-02 18:02:02 --> Helper loaded: form_helper
DEBUG - 2012-10-02 18:02:02 --> Helper loaded: language_helper
DEBUG - 2012-10-02 18:02:02 --> Form Validation Class Initialized
DEBUG - 2012-10-02 18:02:02 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 18:02:02 --> Upload Class Initialized
DEBUG - 2012-10-02 18:02:02 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2012-10-02 18:02:02 --> Severity: Warning  --> mkdir(): Permission denied /home/jwp/www/justinwylliephotography.com/clients/application/controllers/admin/pricing.php 347
DEBUG - 2012-10-02 18:05:46 --> Config Class Initialized
DEBUG - 2012-10-02 18:05:46 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:05:46 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:05:46 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:05:46 --> URI Class Initialized
DEBUG - 2012-10-02 18:05:46 --> Router Class Initialized
DEBUG - 2012-10-02 18:05:46 --> Output Class Initialized
DEBUG - 2012-10-02 18:05:46 --> Security Class Initialized
DEBUG - 2012-10-02 18:05:46 --> Input Class Initialized
DEBUG - 2012-10-02 18:05:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:05:46 --> Language Class Initialized
DEBUG - 2012-10-02 18:05:46 --> Loader Class Initialized
DEBUG - 2012-10-02 18:05:46 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:05:46 --> Controller Class Initialized
DEBUG - 2012-10-02 18:05:46 --> Model Class Initialized
DEBUG - 2012-10-02 18:05:46 --> Database Driver Class Initialized
DEBUG - 2012-10-02 18:05:46 --> Helper loaded: form_helper
DEBUG - 2012-10-02 18:05:46 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 18:05:46 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 18:05:46 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 18:05:46 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 18:05:46 --> Final output sent to browser
DEBUG - 2012-10-02 18:05:46 --> Total execution time: 0.0462
DEBUG - 2012-10-02 18:05:48 --> Config Class Initialized
DEBUG - 2012-10-02 18:05:48 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:05:48 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:05:48 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:05:48 --> URI Class Initialized
DEBUG - 2012-10-02 18:05:48 --> Router Class Initialized
ERROR - 2012-10-02 18:05:48 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 18:05:48 --> Config Class Initialized
DEBUG - 2012-10-02 18:05:48 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:05:48 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:05:48 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:05:48 --> URI Class Initialized
DEBUG - 2012-10-02 18:05:48 --> Router Class Initialized
ERROR - 2012-10-02 18:05:48 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 18:05:48 --> Config Class Initialized
DEBUG - 2012-10-02 18:05:48 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:05:48 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:05:48 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:05:48 --> URI Class Initialized
DEBUG - 2012-10-02 18:05:48 --> Router Class Initialized
ERROR - 2012-10-02 18:05:48 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 18:05:48 --> Config Class Initialized
DEBUG - 2012-10-02 18:05:48 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:05:48 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:05:48 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:05:48 --> URI Class Initialized
DEBUG - 2012-10-02 18:05:48 --> Router Class Initialized
ERROR - 2012-10-02 18:05:48 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:05:48 --> Config Class Initialized
DEBUG - 2012-10-02 18:05:48 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:05:48 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:05:48 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:05:48 --> URI Class Initialized
DEBUG - 2012-10-02 18:05:48 --> Router Class Initialized
ERROR - 2012-10-02 18:05:48 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:05:48 --> Config Class Initialized
DEBUG - 2012-10-02 18:05:48 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:05:48 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:05:48 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:05:48 --> URI Class Initialized
DEBUG - 2012-10-02 18:05:48 --> Router Class Initialized
ERROR - 2012-10-02 18:05:48 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:05:48 --> Config Class Initialized
DEBUG - 2012-10-02 18:05:48 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:05:48 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:05:48 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:05:48 --> URI Class Initialized
DEBUG - 2012-10-02 18:05:48 --> Router Class Initialized
ERROR - 2012-10-02 18:05:48 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:05:48 --> Config Class Initialized
DEBUG - 2012-10-02 18:05:48 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:05:48 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:05:48 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:05:48 --> URI Class Initialized
DEBUG - 2012-10-02 18:05:48 --> Router Class Initialized
ERROR - 2012-10-02 18:05:48 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:05:56 --> Config Class Initialized
DEBUG - 2012-10-02 18:05:56 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:05:56 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:05:56 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:05:56 --> URI Class Initialized
DEBUG - 2012-10-02 18:05:56 --> Router Class Initialized
DEBUG - 2012-10-02 18:05:56 --> Output Class Initialized
DEBUG - 2012-10-02 18:05:56 --> Security Class Initialized
DEBUG - 2012-10-02 18:05:56 --> Input Class Initialized
DEBUG - 2012-10-02 18:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:05:56 --> Language Class Initialized
DEBUG - 2012-10-02 18:05:56 --> Loader Class Initialized
DEBUG - 2012-10-02 18:05:56 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:05:56 --> Controller Class Initialized
DEBUG - 2012-10-02 18:05:56 --> Model Class Initialized
DEBUG - 2012-10-02 18:05:56 --> Database Driver Class Initialized
DEBUG - 2012-10-02 18:05:56 --> Helper loaded: form_helper
DEBUG - 2012-10-02 18:05:56 --> Helper loaded: language_helper
DEBUG - 2012-10-02 18:05:56 --> Form Validation Class Initialized
DEBUG - 2012-10-02 18:05:56 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 18:05:56 --> Upload Class Initialized
DEBUG - 2012-10-02 18:05:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2012-10-02 18:05:56 --> Severity: Warning  --> mkdir(): Permission denied /home/jwp/www/justinwylliephotography.com/clients/application/controllers/admin/pricing.php 347
DEBUG - 2012-10-02 18:20:04 --> Config Class Initialized
DEBUG - 2012-10-02 18:20:04 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:20:04 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:20:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:20:04 --> URI Class Initialized
DEBUG - 2012-10-02 18:20:04 --> Router Class Initialized
DEBUG - 2012-10-02 18:20:04 --> Output Class Initialized
DEBUG - 2012-10-02 18:20:04 --> Security Class Initialized
DEBUG - 2012-10-02 18:20:04 --> Input Class Initialized
DEBUG - 2012-10-02 18:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:20:04 --> Language Class Initialized
DEBUG - 2012-10-02 18:20:04 --> Loader Class Initialized
DEBUG - 2012-10-02 18:20:04 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:20:04 --> Controller Class Initialized
DEBUG - 2012-10-02 18:20:04 --> Model Class Initialized
DEBUG - 2012-10-02 18:20:04 --> Database Driver Class Initialized
DEBUG - 2012-10-02 18:20:04 --> Helper loaded: form_helper
DEBUG - 2012-10-02 18:20:04 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 18:20:04 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 18:20:04 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 18:20:04 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 18:20:04 --> Final output sent to browser
DEBUG - 2012-10-02 18:20:04 --> Total execution time: 0.4246
DEBUG - 2012-10-02 18:20:05 --> Config Class Initialized
DEBUG - 2012-10-02 18:20:05 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:20:05 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:20:05 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:20:05 --> URI Class Initialized
DEBUG - 2012-10-02 18:20:05 --> Router Class Initialized
ERROR - 2012-10-02 18:20:05 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:20:05 --> Config Class Initialized
DEBUG - 2012-10-02 18:20:05 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:20:05 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:20:05 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:20:05 --> URI Class Initialized
DEBUG - 2012-10-02 18:20:05 --> Router Class Initialized
ERROR - 2012-10-02 18:20:05 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:20:05 --> Config Class Initialized
DEBUG - 2012-10-02 18:20:05 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:20:05 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:20:05 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:20:05 --> URI Class Initialized
DEBUG - 2012-10-02 18:20:05 --> Router Class Initialized
ERROR - 2012-10-02 18:20:05 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:20:05 --> Config Class Initialized
DEBUG - 2012-10-02 18:20:05 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:20:05 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:20:05 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:20:05 --> URI Class Initialized
DEBUG - 2012-10-02 18:20:05 --> Router Class Initialized
ERROR - 2012-10-02 18:20:05 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:20:06 --> Config Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:20:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:20:06 --> URI Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Router Class Initialized
ERROR - 2012-10-02 18:20:06 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:20:06 --> Config Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:20:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:20:06 --> URI Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Router Class Initialized
ERROR - 2012-10-02 18:20:06 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 18:20:06 --> Config Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:20:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:20:06 --> URI Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Router Class Initialized
ERROR - 2012-10-02 18:20:06 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 18:20:06 --> Config Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:20:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:20:06 --> URI Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Router Class Initialized
ERROR - 2012-10-02 18:20:06 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 18:20:06 --> Config Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:20:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:20:06 --> URI Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Router Class Initialized
ERROR - 2012-10-02 18:20:06 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:20:06 --> Config Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:20:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:20:06 --> URI Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Router Class Initialized
ERROR - 2012-10-02 18:20:06 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:20:06 --> Config Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:20:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:20:06 --> URI Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Router Class Initialized
ERROR - 2012-10-02 18:20:06 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:20:06 --> Config Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:20:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:20:06 --> URI Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Router Class Initialized
ERROR - 2012-10-02 18:20:06 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:20:06 --> Config Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:20:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:20:06 --> URI Class Initialized
DEBUG - 2012-10-02 18:20:06 --> Router Class Initialized
ERROR - 2012-10-02 18:20:06 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:28:36 --> Config Class Initialized
DEBUG - 2012-10-02 18:28:36 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:28:36 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:28:36 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:28:36 --> URI Class Initialized
DEBUG - 2012-10-02 18:28:36 --> Router Class Initialized
DEBUG - 2012-10-02 18:28:36 --> Output Class Initialized
DEBUG - 2012-10-02 18:28:36 --> Security Class Initialized
DEBUG - 2012-10-02 18:28:36 --> Input Class Initialized
DEBUG - 2012-10-02 18:28:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:28:36 --> Language Class Initialized
DEBUG - 2012-10-02 18:28:36 --> Loader Class Initialized
DEBUG - 2012-10-02 18:28:36 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:28:36 --> Controller Class Initialized
DEBUG - 2012-10-02 18:28:36 --> Model Class Initialized
DEBUG - 2012-10-02 18:28:36 --> Database Driver Class Initialized
DEBUG - 2012-10-02 18:28:36 --> Helper loaded: form_helper
DEBUG - 2012-10-02 18:28:36 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 18:28:36 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-10-02 18:28:36 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 18:28:36 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-10-02 18:28:36 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 18:28:36 --> Final output sent to browser
DEBUG - 2012-10-02 18:28:36 --> Total execution time: 0.1129
DEBUG - 2012-10-02 18:28:38 --> Config Class Initialized
DEBUG - 2012-10-02 18:28:38 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:28:38 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:28:38 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:28:38 --> URI Class Initialized
DEBUG - 2012-10-02 18:28:38 --> Router Class Initialized
ERROR - 2012-10-02 18:28:38 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 18:28:38 --> Config Class Initialized
DEBUG - 2012-10-02 18:28:38 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:28:38 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:28:38 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:28:38 --> URI Class Initialized
DEBUG - 2012-10-02 18:28:38 --> Router Class Initialized
ERROR - 2012-10-02 18:28:38 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 18:28:38 --> Config Class Initialized
DEBUG - 2012-10-02 18:28:38 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:28:38 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:28:38 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:28:38 --> URI Class Initialized
DEBUG - 2012-10-02 18:28:38 --> Router Class Initialized
ERROR - 2012-10-02 18:28:38 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 18:28:39 --> Config Class Initialized
DEBUG - 2012-10-02 18:28:39 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:28:39 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:28:39 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:28:39 --> URI Class Initialized
DEBUG - 2012-10-02 18:28:39 --> Router Class Initialized
DEBUG - 2012-10-02 18:28:39 --> Output Class Initialized
DEBUG - 2012-10-02 18:28:39 --> Security Class Initialized
DEBUG - 2012-10-02 18:28:39 --> Input Class Initialized
DEBUG - 2012-10-02 18:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:28:39 --> Language Class Initialized
DEBUG - 2012-10-02 18:28:39 --> Loader Class Initialized
DEBUG - 2012-10-02 18:28:39 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:28:39 --> Controller Class Initialized
DEBUG - 2012-10-02 18:28:39 --> Model Class Initialized
DEBUG - 2012-10-02 18:28:39 --> Database Driver Class Initialized
DEBUG - 2012-10-02 18:28:39 --> Helper loaded: form_helper
DEBUG - 2012-10-02 18:28:39 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 18:28:39 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 18:28:39 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 18:28:39 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 18:28:39 --> Final output sent to browser
DEBUG - 2012-10-02 18:28:39 --> Total execution time: 0.0504
DEBUG - 2012-10-02 18:28:41 --> Config Class Initialized
DEBUG - 2012-10-02 18:28:41 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:28:41 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:28:41 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:28:41 --> URI Class Initialized
DEBUG - 2012-10-02 18:28:41 --> Router Class Initialized
ERROR - 2012-10-02 18:28:41 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 18:28:41 --> Config Class Initialized
DEBUG - 2012-10-02 18:28:41 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:28:41 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:28:41 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:28:41 --> URI Class Initialized
DEBUG - 2012-10-02 18:28:41 --> Router Class Initialized
ERROR - 2012-10-02 18:28:41 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 18:28:41 --> Config Class Initialized
DEBUG - 2012-10-02 18:28:41 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:28:41 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:28:41 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:28:41 --> URI Class Initialized
DEBUG - 2012-10-02 18:28:41 --> Router Class Initialized
ERROR - 2012-10-02 18:28:41 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 18:28:41 --> Config Class Initialized
DEBUG - 2012-10-02 18:28:41 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:28:41 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:28:41 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:28:41 --> URI Class Initialized
DEBUG - 2012-10-02 18:28:41 --> Router Class Initialized
ERROR - 2012-10-02 18:28:41 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:28:41 --> Config Class Initialized
DEBUG - 2012-10-02 18:28:41 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:28:41 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:28:41 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:28:41 --> URI Class Initialized
DEBUG - 2012-10-02 18:28:41 --> Router Class Initialized
ERROR - 2012-10-02 18:28:41 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:28:41 --> Config Class Initialized
DEBUG - 2012-10-02 18:28:41 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:28:41 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:28:41 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:28:41 --> URI Class Initialized
DEBUG - 2012-10-02 18:28:41 --> Router Class Initialized
ERROR - 2012-10-02 18:28:41 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:28:41 --> Config Class Initialized
DEBUG - 2012-10-02 18:28:41 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:28:41 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:28:41 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:28:41 --> URI Class Initialized
DEBUG - 2012-10-02 18:28:41 --> Router Class Initialized
ERROR - 2012-10-02 18:28:41 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:28:41 --> Config Class Initialized
DEBUG - 2012-10-02 18:28:41 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:28:41 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:28:41 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:28:41 --> URI Class Initialized
DEBUG - 2012-10-02 18:28:41 --> Router Class Initialized
ERROR - 2012-10-02 18:28:41 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:28:53 --> Config Class Initialized
DEBUG - 2012-10-02 18:28:53 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:28:53 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:28:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:28:53 --> URI Class Initialized
DEBUG - 2012-10-02 18:28:53 --> Router Class Initialized
DEBUG - 2012-10-02 18:28:53 --> Output Class Initialized
DEBUG - 2012-10-02 18:28:53 --> Security Class Initialized
DEBUG - 2012-10-02 18:28:53 --> Input Class Initialized
DEBUG - 2012-10-02 18:28:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:28:53 --> Language Class Initialized
DEBUG - 2012-10-02 18:28:53 --> Loader Class Initialized
DEBUG - 2012-10-02 18:28:53 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:28:53 --> Controller Class Initialized
DEBUG - 2012-10-02 18:28:53 --> Model Class Initialized
DEBUG - 2012-10-02 18:28:53 --> Database Driver Class Initialized
DEBUG - 2012-10-02 18:28:53 --> Helper loaded: form_helper
DEBUG - 2012-10-02 18:28:53 --> Helper loaded: language_helper
DEBUG - 2012-10-02 18:28:53 --> Form Validation Class Initialized
DEBUG - 2012-10-02 18:28:53 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 18:28:53 --> Upload Class Initialized
DEBUG - 2012-10-02 18:28:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 18:28:53 --> Image Lib Class Initialized
ERROR - 2012-10-02 18:28:53 --> Severity: Warning  --> imagejpeg(): Unable to open '/uploads/thumbs//oak1_thumb.jpg' for writing: No such file or directory /home/jwp/www/justinwylliephotography.com/clients/system/libraries/Image_lib.php 1209
DEBUG - 2012-10-02 18:28:53 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2012-10-02 18:28:53 --> Unable to save the image.  Please make sure the image and file directory are writable.
DEBUG - 2012-10-02 18:28:53 --> Final output sent to browser
DEBUG - 2012-10-02 18:28:53 --> Total execution time: 0.2229
DEBUG - 2012-10-02 18:31:10 --> Config Class Initialized
DEBUG - 2012-10-02 18:31:10 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:31:10 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:31:10 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:31:10 --> URI Class Initialized
DEBUG - 2012-10-02 18:31:10 --> Router Class Initialized
DEBUG - 2012-10-02 18:31:10 --> Output Class Initialized
DEBUG - 2012-10-02 18:31:10 --> Security Class Initialized
DEBUG - 2012-10-02 18:31:10 --> Input Class Initialized
DEBUG - 2012-10-02 18:31:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:31:10 --> Language Class Initialized
DEBUG - 2012-10-02 18:31:10 --> Loader Class Initialized
DEBUG - 2012-10-02 18:31:10 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:31:10 --> Controller Class Initialized
DEBUG - 2012-10-02 18:31:10 --> Model Class Initialized
DEBUG - 2012-10-02 18:31:10 --> Database Driver Class Initialized
DEBUG - 2012-10-02 18:31:10 --> Helper loaded: form_helper
DEBUG - 2012-10-02 18:31:10 --> Helper loaded: language_helper
DEBUG - 2012-10-02 18:31:10 --> Form Validation Class Initialized
DEBUG - 2012-10-02 18:31:10 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 18:31:10 --> Upload Class Initialized
DEBUG - 2012-10-02 18:31:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 18:31:10 --> Image Lib Class Initialized
DEBUG - 2012-10-02 18:31:10 --> Final output sent to browser
DEBUG - 2012-10-02 18:31:10 --> Total execution time: 0.1621
DEBUG - 2012-10-02 18:31:58 --> Config Class Initialized
DEBUG - 2012-10-02 18:31:58 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:31:58 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:31:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:31:58 --> URI Class Initialized
DEBUG - 2012-10-02 18:31:58 --> Router Class Initialized
DEBUG - 2012-10-02 18:31:58 --> Output Class Initialized
DEBUG - 2012-10-02 18:31:58 --> Security Class Initialized
DEBUG - 2012-10-02 18:31:58 --> Input Class Initialized
DEBUG - 2012-10-02 18:31:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:31:58 --> Language Class Initialized
DEBUG - 2012-10-02 18:31:58 --> Loader Class Initialized
DEBUG - 2012-10-02 18:31:58 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:31:58 --> Controller Class Initialized
DEBUG - 2012-10-02 18:31:58 --> Model Class Initialized
DEBUG - 2012-10-02 18:31:58 --> Database Driver Class Initialized
DEBUG - 2012-10-02 18:31:58 --> Helper loaded: form_helper
DEBUG - 2012-10-02 18:31:58 --> Helper loaded: language_helper
DEBUG - 2012-10-02 18:31:58 --> Form Validation Class Initialized
DEBUG - 2012-10-02 18:31:58 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 18:31:58 --> Upload Class Initialized
DEBUG - 2012-10-02 18:31:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 18:31:58 --> Image Lib Class Initialized
DEBUG - 2012-10-02 18:31:58 --> Final output sent to browser
DEBUG - 2012-10-02 18:31:58 --> Total execution time: 0.1304
DEBUG - 2012-10-02 18:33:16 --> Config Class Initialized
DEBUG - 2012-10-02 18:33:16 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:33:16 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:33:16 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:33:16 --> URI Class Initialized
DEBUG - 2012-10-02 18:33:16 --> Router Class Initialized
DEBUG - 2012-10-02 18:33:16 --> Output Class Initialized
DEBUG - 2012-10-02 18:33:16 --> Security Class Initialized
DEBUG - 2012-10-02 18:33:16 --> Input Class Initialized
DEBUG - 2012-10-02 18:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:33:16 --> Language Class Initialized
DEBUG - 2012-10-02 18:33:16 --> Loader Class Initialized
DEBUG - 2012-10-02 18:33:16 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:33:16 --> Controller Class Initialized
DEBUG - 2012-10-02 18:33:16 --> Model Class Initialized
DEBUG - 2012-10-02 18:33:16 --> Database Driver Class Initialized
DEBUG - 2012-10-02 18:33:16 --> Helper loaded: form_helper
DEBUG - 2012-10-02 18:33:16 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 18:33:16 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 18:33:16 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 18:33:16 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 18:33:16 --> Final output sent to browser
DEBUG - 2012-10-02 18:33:16 --> Total execution time: 0.0406
DEBUG - 2012-10-02 18:33:18 --> Config Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:33:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:33:18 --> URI Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Router Class Initialized
ERROR - 2012-10-02 18:33:18 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 18:33:18 --> Config Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:33:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:33:18 --> URI Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Router Class Initialized
ERROR - 2012-10-02 18:33:18 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 18:33:18 --> Config Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:33:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:33:18 --> URI Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Router Class Initialized
ERROR - 2012-10-02 18:33:18 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 18:33:18 --> Config Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:33:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:33:18 --> URI Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Router Class Initialized
ERROR - 2012-10-02 18:33:18 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:33:18 --> Config Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:33:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:33:18 --> URI Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Router Class Initialized
ERROR - 2012-10-02 18:33:18 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:33:18 --> Config Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:33:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:33:18 --> URI Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Router Class Initialized
ERROR - 2012-10-02 18:33:18 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:33:18 --> Config Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:33:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:33:18 --> URI Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Router Class Initialized
ERROR - 2012-10-02 18:33:18 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:33:18 --> Config Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:33:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:33:18 --> URI Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Router Class Initialized
ERROR - 2012-10-02 18:33:18 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:33:18 --> Config Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:33:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:33:18 --> URI Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Router Class Initialized
ERROR - 2012-10-02 18:33:18 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:33:18 --> Config Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:33:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:33:18 --> URI Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Router Class Initialized
ERROR - 2012-10-02 18:33:18 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:33:18 --> Config Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:33:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:33:18 --> URI Class Initialized
DEBUG - 2012-10-02 18:33:18 --> Router Class Initialized
ERROR - 2012-10-02 18:33:18 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:33:35 --> Config Class Initialized
DEBUG - 2012-10-02 18:33:35 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:33:35 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:33:35 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:33:35 --> URI Class Initialized
DEBUG - 2012-10-02 18:33:35 --> Router Class Initialized
DEBUG - 2012-10-02 18:33:35 --> Output Class Initialized
DEBUG - 2012-10-02 18:33:35 --> Security Class Initialized
DEBUG - 2012-10-02 18:33:35 --> Input Class Initialized
DEBUG - 2012-10-02 18:33:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:33:35 --> Language Class Initialized
DEBUG - 2012-10-02 18:33:35 --> Loader Class Initialized
DEBUG - 2012-10-02 18:33:35 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:33:35 --> Controller Class Initialized
DEBUG - 2012-10-02 18:33:35 --> Model Class Initialized
DEBUG - 2012-10-02 18:33:35 --> Database Driver Class Initialized
DEBUG - 2012-10-02 18:33:35 --> Helper loaded: form_helper
DEBUG - 2012-10-02 18:33:35 --> Helper loaded: language_helper
DEBUG - 2012-10-02 18:33:35 --> Form Validation Class Initialized
DEBUG - 2012-10-02 18:33:35 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 18:33:35 --> Upload Class Initialized
DEBUG - 2012-10-02 18:33:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 18:33:35 --> Image Lib Class Initialized
DEBUG - 2012-10-02 18:33:36 --> Final output sent to browser
DEBUG - 2012-10-02 18:33:36 --> Total execution time: 0.2130
DEBUG - 2012-10-02 18:37:27 --> Config Class Initialized
DEBUG - 2012-10-02 18:37:27 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:37:27 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:37:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:37:27 --> URI Class Initialized
DEBUG - 2012-10-02 18:37:27 --> Router Class Initialized
DEBUG - 2012-10-02 18:37:27 --> Output Class Initialized
DEBUG - 2012-10-02 18:37:27 --> Security Class Initialized
DEBUG - 2012-10-02 18:37:27 --> Input Class Initialized
DEBUG - 2012-10-02 18:37:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:37:27 --> Language Class Initialized
DEBUG - 2012-10-02 18:37:27 --> Loader Class Initialized
DEBUG - 2012-10-02 18:37:27 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:37:27 --> Controller Class Initialized
DEBUG - 2012-10-02 18:37:27 --> Model Class Initialized
DEBUG - 2012-10-02 18:37:27 --> Database Driver Class Initialized
DEBUG - 2012-10-02 18:37:27 --> Helper loaded: form_helper
DEBUG - 2012-10-02 18:37:27 --> Helper loaded: language_helper
DEBUG - 2012-10-02 18:37:27 --> Form Validation Class Initialized
DEBUG - 2012-10-02 18:37:27 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 18:37:27 --> Upload Class Initialized
DEBUG - 2012-10-02 18:37:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 18:37:27 --> Image Lib Class Initialized
DEBUG - 2012-10-02 18:37:27 --> Final output sent to browser
DEBUG - 2012-10-02 18:37:27 --> Total execution time: 0.1295
DEBUG - 2012-10-02 18:39:35 --> Config Class Initialized
DEBUG - 2012-10-02 18:39:35 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:39:35 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:39:35 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:39:35 --> URI Class Initialized
DEBUG - 2012-10-02 18:39:35 --> Router Class Initialized
DEBUG - 2012-10-02 18:39:35 --> Output Class Initialized
DEBUG - 2012-10-02 18:39:35 --> Security Class Initialized
DEBUG - 2012-10-02 18:39:35 --> Input Class Initialized
DEBUG - 2012-10-02 18:39:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:39:35 --> Language Class Initialized
DEBUG - 2012-10-02 18:39:35 --> Loader Class Initialized
DEBUG - 2012-10-02 18:39:35 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:39:35 --> Controller Class Initialized
DEBUG - 2012-10-02 18:39:35 --> Model Class Initialized
DEBUG - 2012-10-02 18:39:35 --> Database Driver Class Initialized
DEBUG - 2012-10-02 18:39:35 --> Helper loaded: form_helper
DEBUG - 2012-10-02 18:39:35 --> Helper loaded: language_helper
DEBUG - 2012-10-02 18:39:35 --> Form Validation Class Initialized
DEBUG - 2012-10-02 18:39:35 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 18:39:35 --> Upload Class Initialized
DEBUG - 2012-10-02 18:39:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 18:39:35 --> Image Lib Class Initialized
DEBUG - 2012-10-02 18:39:35 --> Final output sent to browser
DEBUG - 2012-10-02 18:39:35 --> Total execution time: 0.2016
DEBUG - 2012-10-02 18:41:54 --> Config Class Initialized
DEBUG - 2012-10-02 18:41:54 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:41:54 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:41:54 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:41:54 --> URI Class Initialized
DEBUG - 2012-10-02 18:41:54 --> Router Class Initialized
DEBUG - 2012-10-02 18:41:54 --> Output Class Initialized
DEBUG - 2012-10-02 18:41:54 --> Security Class Initialized
DEBUG - 2012-10-02 18:41:54 --> Input Class Initialized
DEBUG - 2012-10-02 18:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:41:54 --> Language Class Initialized
DEBUG - 2012-10-02 18:41:54 --> Loader Class Initialized
DEBUG - 2012-10-02 18:41:54 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:41:54 --> Controller Class Initialized
DEBUG - 2012-10-02 18:41:54 --> Model Class Initialized
DEBUG - 2012-10-02 18:41:54 --> Database Driver Class Initialized
DEBUG - 2012-10-02 18:41:54 --> Helper loaded: form_helper
DEBUG - 2012-10-02 18:41:54 --> Helper loaded: language_helper
DEBUG - 2012-10-02 18:41:54 --> Form Validation Class Initialized
DEBUG - 2012-10-02 18:41:54 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 18:41:54 --> Upload Class Initialized
DEBUG - 2012-10-02 18:41:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 18:41:54 --> Image Lib Class Initialized
DEBUG - 2012-10-02 18:41:54 --> Final output sent to browser
DEBUG - 2012-10-02 18:41:54 --> Total execution time: 0.1589
DEBUG - 2012-10-02 18:55:56 --> Config Class Initialized
DEBUG - 2012-10-02 18:55:56 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:55:56 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:55:56 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:55:56 --> URI Class Initialized
DEBUG - 2012-10-02 18:55:56 --> Router Class Initialized
ERROR - 2012-10-02 18:55:56 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 18:57:14 --> Config Class Initialized
DEBUG - 2012-10-02 18:57:14 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:57:14 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:57:14 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:57:14 --> URI Class Initialized
DEBUG - 2012-10-02 18:57:14 --> Router Class Initialized
DEBUG - 2012-10-02 18:57:14 --> Output Class Initialized
DEBUG - 2012-10-02 18:57:14 --> Security Class Initialized
DEBUG - 2012-10-02 18:57:14 --> Input Class Initialized
DEBUG - 2012-10-02 18:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:57:14 --> Language Class Initialized
DEBUG - 2012-10-02 18:57:14 --> Loader Class Initialized
DEBUG - 2012-10-02 18:57:14 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:57:14 --> Controller Class Initialized
DEBUG - 2012-10-02 18:57:14 --> Model Class Initialized
DEBUG - 2012-10-02 18:57:14 --> Database Driver Class Initialized
DEBUG - 2012-10-02 18:57:14 --> Final output sent to browser
DEBUG - 2012-10-02 18:57:14 --> Total execution time: 0.0989
DEBUG - 2012-10-02 18:57:15 --> Config Class Initialized
DEBUG - 2012-10-02 18:57:15 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:57:15 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:57:15 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:57:15 --> URI Class Initialized
DEBUG - 2012-10-02 18:57:15 --> Router Class Initialized
DEBUG - 2012-10-02 18:57:15 --> Output Class Initialized
DEBUG - 2012-10-02 18:57:15 --> Security Class Initialized
DEBUG - 2012-10-02 18:57:15 --> Input Class Initialized
DEBUG - 2012-10-02 18:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:57:15 --> Language Class Initialized
DEBUG - 2012-10-02 18:57:15 --> Loader Class Initialized
DEBUG - 2012-10-02 18:57:15 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:57:15 --> Controller Class Initialized
DEBUG - 2012-10-02 18:57:15 --> Model Class Initialized
DEBUG - 2012-10-02 18:57:15 --> Database Driver Class Initialized
DEBUG - 2012-10-02 18:57:15 --> Final output sent to browser
DEBUG - 2012-10-02 18:57:15 --> Total execution time: 0.0810
DEBUG - 2012-10-02 18:57:16 --> Config Class Initialized
DEBUG - 2012-10-02 18:57:16 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:57:16 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:57:16 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:57:16 --> URI Class Initialized
DEBUG - 2012-10-02 18:57:16 --> Router Class Initialized
DEBUG - 2012-10-02 18:57:16 --> Output Class Initialized
DEBUG - 2012-10-02 18:57:16 --> Security Class Initialized
DEBUG - 2012-10-02 18:57:16 --> Input Class Initialized
DEBUG - 2012-10-02 18:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:57:16 --> Language Class Initialized
DEBUG - 2012-10-02 18:57:16 --> Loader Class Initialized
DEBUG - 2012-10-02 18:57:16 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:57:16 --> Controller Class Initialized
DEBUG - 2012-10-02 18:57:16 --> Model Class Initialized
DEBUG - 2012-10-02 18:57:16 --> Database Driver Class Initialized
ERROR - 2012-10-02 18:57:16 --> Severity: Warning  --> unlink(./uploads/thumbs/red1.jpg): No such file or directory /home/jwp/www/justinwylliephotography.com/clients/application/models/pricing_model.php 262
DEBUG - 2012-10-02 18:57:17 --> Final output sent to browser
DEBUG - 2012-10-02 18:57:17 --> Total execution time: 0.1329
DEBUG - 2012-10-02 18:57:18 --> Config Class Initialized
DEBUG - 2012-10-02 18:57:18 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:57:18 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:57:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:57:18 --> URI Class Initialized
DEBUG - 2012-10-02 18:57:18 --> Router Class Initialized
DEBUG - 2012-10-02 18:57:18 --> Output Class Initialized
DEBUG - 2012-10-02 18:57:18 --> Security Class Initialized
DEBUG - 2012-10-02 18:57:18 --> Input Class Initialized
DEBUG - 2012-10-02 18:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:57:18 --> Language Class Initialized
DEBUG - 2012-10-02 18:57:18 --> Loader Class Initialized
DEBUG - 2012-10-02 18:57:18 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:57:18 --> Controller Class Initialized
DEBUG - 2012-10-02 18:57:18 --> Model Class Initialized
DEBUG - 2012-10-02 18:57:18 --> Database Driver Class Initialized
ERROR - 2012-10-02 18:57:18 --> Severity: Warning  --> unlink(./uploads/thumbs/green.jpg): No such file or directory /home/jwp/www/justinwylliephotography.com/clients/application/models/pricing_model.php 262
DEBUG - 2012-10-02 18:57:18 --> Final output sent to browser
DEBUG - 2012-10-02 18:57:18 --> Total execution time: 0.1131
DEBUG - 2012-10-02 18:57:19 --> Config Class Initialized
DEBUG - 2012-10-02 18:57:19 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:57:19 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:57:19 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:57:19 --> URI Class Initialized
DEBUG - 2012-10-02 18:57:19 --> Router Class Initialized
DEBUG - 2012-10-02 18:57:19 --> Output Class Initialized
DEBUG - 2012-10-02 18:57:19 --> Security Class Initialized
DEBUG - 2012-10-02 18:57:19 --> Input Class Initialized
DEBUG - 2012-10-02 18:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:57:19 --> Language Class Initialized
DEBUG - 2012-10-02 18:57:19 --> Loader Class Initialized
DEBUG - 2012-10-02 18:57:19 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:57:19 --> Controller Class Initialized
DEBUG - 2012-10-02 18:57:19 --> Model Class Initialized
DEBUG - 2012-10-02 18:57:19 --> Database Driver Class Initialized
ERROR - 2012-10-02 18:57:19 --> Severity: Warning  --> unlink(./uploads/thumbs/green1.jpg): No such file or directory /home/jwp/www/justinwylliephotography.com/clients/application/models/pricing_model.php 262
DEBUG - 2012-10-02 18:57:19 --> Final output sent to browser
DEBUG - 2012-10-02 18:57:19 --> Total execution time: 0.1062
DEBUG - 2012-10-02 18:57:20 --> Config Class Initialized
DEBUG - 2012-10-02 18:57:20 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:57:20 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:57:20 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:57:20 --> URI Class Initialized
DEBUG - 2012-10-02 18:57:20 --> Router Class Initialized
DEBUG - 2012-10-02 18:57:20 --> Output Class Initialized
DEBUG - 2012-10-02 18:57:20 --> Security Class Initialized
DEBUG - 2012-10-02 18:57:20 --> Input Class Initialized
DEBUG - 2012-10-02 18:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:57:20 --> Language Class Initialized
DEBUG - 2012-10-02 18:57:20 --> Loader Class Initialized
DEBUG - 2012-10-02 18:57:20 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:57:20 --> Controller Class Initialized
DEBUG - 2012-10-02 18:57:20 --> Model Class Initialized
DEBUG - 2012-10-02 18:57:20 --> Database Driver Class Initialized
ERROR - 2012-10-02 18:57:20 --> Severity: Warning  --> unlink(./uploads/thumbs/red2.jpg): No such file or directory /home/jwp/www/justinwylliephotography.com/clients/application/models/pricing_model.php 262
DEBUG - 2012-10-02 18:57:20 --> Final output sent to browser
DEBUG - 2012-10-02 18:57:20 --> Total execution time: 0.1258
DEBUG - 2012-10-02 18:57:21 --> Config Class Initialized
DEBUG - 2012-10-02 18:57:21 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:57:21 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:57:21 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:57:21 --> URI Class Initialized
DEBUG - 2012-10-02 18:57:21 --> Router Class Initialized
DEBUG - 2012-10-02 18:57:21 --> Output Class Initialized
DEBUG - 2012-10-02 18:57:21 --> Security Class Initialized
DEBUG - 2012-10-02 18:57:21 --> Input Class Initialized
DEBUG - 2012-10-02 18:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:57:21 --> Language Class Initialized
DEBUG - 2012-10-02 18:57:21 --> Loader Class Initialized
DEBUG - 2012-10-02 18:57:21 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:57:21 --> Controller Class Initialized
DEBUG - 2012-10-02 18:57:21 --> Model Class Initialized
DEBUG - 2012-10-02 18:57:21 --> Database Driver Class Initialized
ERROR - 2012-10-02 18:57:21 --> Severity: Warning  --> unlink(./uploads/thumbs/oak.jpg): No such file or directory /home/jwp/www/justinwylliephotography.com/clients/application/models/pricing_model.php 262
DEBUG - 2012-10-02 18:57:21 --> Final output sent to browser
DEBUG - 2012-10-02 18:57:21 --> Total execution time: 0.1264
DEBUG - 2012-10-02 18:57:22 --> Config Class Initialized
DEBUG - 2012-10-02 18:57:22 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:57:22 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:57:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:57:22 --> URI Class Initialized
DEBUG - 2012-10-02 18:57:22 --> Router Class Initialized
DEBUG - 2012-10-02 18:57:22 --> Output Class Initialized
DEBUG - 2012-10-02 18:57:22 --> Security Class Initialized
DEBUG - 2012-10-02 18:57:22 --> Input Class Initialized
DEBUG - 2012-10-02 18:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:57:22 --> Language Class Initialized
DEBUG - 2012-10-02 18:57:22 --> Loader Class Initialized
DEBUG - 2012-10-02 18:57:22 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:57:22 --> Controller Class Initialized
DEBUG - 2012-10-02 18:57:22 --> Model Class Initialized
DEBUG - 2012-10-02 18:57:22 --> Database Driver Class Initialized
ERROR - 2012-10-02 18:57:22 --> Severity: Warning  --> unlink(./uploads/thumbs/oak1.jpg): No such file or directory /home/jwp/www/justinwylliephotography.com/clients/application/models/pricing_model.php 262
DEBUG - 2012-10-02 18:57:22 --> Final output sent to browser
DEBUG - 2012-10-02 18:57:22 --> Total execution time: 0.1108
DEBUG - 2012-10-02 18:57:22 --> Config Class Initialized
DEBUG - 2012-10-02 18:57:22 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:57:22 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:57:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:57:22 --> URI Class Initialized
DEBUG - 2012-10-02 18:57:22 --> Router Class Initialized
DEBUG - 2012-10-02 18:57:22 --> Output Class Initialized
DEBUG - 2012-10-02 18:57:22 --> Security Class Initialized
DEBUG - 2012-10-02 18:57:22 --> Input Class Initialized
DEBUG - 2012-10-02 18:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:57:22 --> Language Class Initialized
DEBUG - 2012-10-02 18:57:22 --> Loader Class Initialized
DEBUG - 2012-10-02 18:57:22 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:57:22 --> Controller Class Initialized
DEBUG - 2012-10-02 18:57:22 --> Model Class Initialized
DEBUG - 2012-10-02 18:57:22 --> Database Driver Class Initialized
ERROR - 2012-10-02 18:57:22 --> Severity: Warning  --> unlink(./uploads/thumbs/red3.jpg): No such file or directory /home/jwp/www/justinwylliephotography.com/clients/application/models/pricing_model.php 262
DEBUG - 2012-10-02 18:57:22 --> Final output sent to browser
DEBUG - 2012-10-02 18:57:22 --> Total execution time: 0.0918
DEBUG - 2012-10-02 18:57:24 --> Config Class Initialized
DEBUG - 2012-10-02 18:57:24 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:57:24 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:57:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:57:24 --> URI Class Initialized
DEBUG - 2012-10-02 18:57:24 --> Router Class Initialized
DEBUG - 2012-10-02 18:57:24 --> Output Class Initialized
DEBUG - 2012-10-02 18:57:24 --> Security Class Initialized
DEBUG - 2012-10-02 18:57:24 --> Input Class Initialized
DEBUG - 2012-10-02 18:57:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:57:24 --> Language Class Initialized
DEBUG - 2012-10-02 18:57:24 --> Loader Class Initialized
DEBUG - 2012-10-02 18:57:24 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:57:24 --> Controller Class Initialized
DEBUG - 2012-10-02 18:57:24 --> Model Class Initialized
DEBUG - 2012-10-02 18:57:24 --> Database Driver Class Initialized
ERROR - 2012-10-02 18:57:24 --> Severity: Warning  --> unlink(./uploads/thumbs/red4.jpg): No such file or directory /home/jwp/www/justinwylliephotography.com/clients/application/models/pricing_model.php 262
DEBUG - 2012-10-02 18:57:24 --> Final output sent to browser
DEBUG - 2012-10-02 18:57:24 --> Total execution time: 0.3784
DEBUG - 2012-10-02 18:57:25 --> Config Class Initialized
DEBUG - 2012-10-02 18:57:25 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:57:25 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:57:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:57:25 --> URI Class Initialized
DEBUG - 2012-10-02 18:57:25 --> Router Class Initialized
DEBUG - 2012-10-02 18:57:25 --> Output Class Initialized
DEBUG - 2012-10-02 18:57:25 --> Security Class Initialized
DEBUG - 2012-10-02 18:57:25 --> Input Class Initialized
DEBUG - 2012-10-02 18:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:57:25 --> Language Class Initialized
DEBUG - 2012-10-02 18:57:25 --> Loader Class Initialized
DEBUG - 2012-10-02 18:57:25 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:57:25 --> Controller Class Initialized
DEBUG - 2012-10-02 18:57:25 --> Model Class Initialized
DEBUG - 2012-10-02 18:57:25 --> Database Driver Class Initialized
DEBUG - 2012-10-02 18:57:25 --> Final output sent to browser
DEBUG - 2012-10-02 18:57:25 --> Total execution time: 0.0798
DEBUG - 2012-10-02 18:58:24 --> Config Class Initialized
DEBUG - 2012-10-02 18:58:24 --> Hooks Class Initialized
DEBUG - 2012-10-02 18:58:24 --> Utf8 Class Initialized
DEBUG - 2012-10-02 18:58:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 18:58:24 --> URI Class Initialized
DEBUG - 2012-10-02 18:58:24 --> Router Class Initialized
DEBUG - 2012-10-02 18:58:24 --> Output Class Initialized
DEBUG - 2012-10-02 18:58:24 --> Security Class Initialized
DEBUG - 2012-10-02 18:58:24 --> Input Class Initialized
DEBUG - 2012-10-02 18:58:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 18:58:24 --> Language Class Initialized
DEBUG - 2012-10-02 18:58:24 --> Loader Class Initialized
DEBUG - 2012-10-02 18:58:24 --> Helper loaded: url_helper
DEBUG - 2012-10-02 18:58:24 --> Controller Class Initialized
DEBUG - 2012-10-02 18:58:24 --> Model Class Initialized
DEBUG - 2012-10-02 18:58:24 --> Database Driver Class Initialized
DEBUG - 2012-10-02 18:58:24 --> Helper loaded: form_helper
DEBUG - 2012-10-02 18:58:24 --> Helper loaded: language_helper
DEBUG - 2012-10-02 18:58:24 --> Form Validation Class Initialized
DEBUG - 2012-10-02 18:58:24 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 18:58:24 --> Upload Class Initialized
DEBUG - 2012-10-02 18:58:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 18:58:24 --> Image Lib Class Initialized
DEBUG - 2012-10-02 18:58:25 --> Final output sent to browser
DEBUG - 2012-10-02 18:58:25 --> Total execution time: 0.2437
DEBUG - 2012-10-02 19:10:26 --> Config Class Initialized
DEBUG - 2012-10-02 19:10:26 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:10:26 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:10:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:10:26 --> URI Class Initialized
DEBUG - 2012-10-02 19:10:26 --> Router Class Initialized
DEBUG - 2012-10-02 19:10:26 --> Output Class Initialized
DEBUG - 2012-10-02 19:10:26 --> Security Class Initialized
DEBUG - 2012-10-02 19:10:26 --> Input Class Initialized
DEBUG - 2012-10-02 19:10:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 19:10:26 --> Language Class Initialized
DEBUG - 2012-10-02 19:10:26 --> Loader Class Initialized
DEBUG - 2012-10-02 19:10:26 --> Helper loaded: url_helper
DEBUG - 2012-10-02 19:10:26 --> Controller Class Initialized
DEBUG - 2012-10-02 19:10:26 --> Model Class Initialized
DEBUG - 2012-10-02 19:10:26 --> Database Driver Class Initialized
DEBUG - 2012-10-02 19:10:26 --> Helper loaded: form_helper
DEBUG - 2012-10-02 19:10:26 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 19:10:26 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 19:10:26 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 19:10:26 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 19:10:26 --> Final output sent to browser
DEBUG - 2012-10-02 19:10:26 --> Total execution time: 0.0395
DEBUG - 2012-10-02 19:10:28 --> Config Class Initialized
DEBUG - 2012-10-02 19:10:28 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:10:28 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:10:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:10:28 --> URI Class Initialized
DEBUG - 2012-10-02 19:10:28 --> Router Class Initialized
ERROR - 2012-10-02 19:10:28 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 19:10:28 --> Config Class Initialized
DEBUG - 2012-10-02 19:10:28 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:10:28 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:10:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:10:28 --> URI Class Initialized
DEBUG - 2012-10-02 19:10:28 --> Router Class Initialized
ERROR - 2012-10-02 19:10:28 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 19:10:28 --> Config Class Initialized
DEBUG - 2012-10-02 19:10:28 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:10:28 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:10:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:10:28 --> URI Class Initialized
DEBUG - 2012-10-02 19:10:28 --> Router Class Initialized
ERROR - 2012-10-02 19:10:28 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 19:10:28 --> Config Class Initialized
DEBUG - 2012-10-02 19:10:28 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:10:28 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:10:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:10:28 --> URI Class Initialized
DEBUG - 2012-10-02 19:10:28 --> Router Class Initialized
ERROR - 2012-10-02 19:10:28 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-02 19:10:35 --> Config Class Initialized
DEBUG - 2012-10-02 19:10:35 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:10:35 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:10:35 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:10:35 --> URI Class Initialized
DEBUG - 2012-10-02 19:10:35 --> Router Class Initialized
DEBUG - 2012-10-02 19:10:35 --> Output Class Initialized
DEBUG - 2012-10-02 19:10:35 --> Security Class Initialized
DEBUG - 2012-10-02 19:10:35 --> Input Class Initialized
DEBUG - 2012-10-02 19:10:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 19:10:35 --> Language Class Initialized
DEBUG - 2012-10-02 19:10:35 --> Loader Class Initialized
DEBUG - 2012-10-02 19:10:35 --> Helper loaded: url_helper
DEBUG - 2012-10-02 19:10:35 --> Controller Class Initialized
DEBUG - 2012-10-02 19:10:35 --> Model Class Initialized
DEBUG - 2012-10-02 19:10:35 --> Database Driver Class Initialized
ERROR - 2012-10-02 19:10:35 --> Severity: Warning  --> unlink(./uploads/thumbs/red5.jpg): No such file or directory /home/jwp/www/justinwylliephotography.com/clients/application/models/pricing_model.php 262
DEBUG - 2012-10-02 19:10:36 --> Final output sent to browser
DEBUG - 2012-10-02 19:10:36 --> Total execution time: 0.1503
DEBUG - 2012-10-02 19:10:39 --> Config Class Initialized
DEBUG - 2012-10-02 19:10:39 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:10:39 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:10:39 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:10:39 --> URI Class Initialized
DEBUG - 2012-10-02 19:10:39 --> Router Class Initialized
DEBUG - 2012-10-02 19:10:39 --> Output Class Initialized
DEBUG - 2012-10-02 19:10:39 --> Security Class Initialized
DEBUG - 2012-10-02 19:10:39 --> Input Class Initialized
DEBUG - 2012-10-02 19:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 19:10:39 --> Language Class Initialized
DEBUG - 2012-10-02 19:10:39 --> Loader Class Initialized
DEBUG - 2012-10-02 19:10:39 --> Helper loaded: url_helper
DEBUG - 2012-10-02 19:10:39 --> Controller Class Initialized
DEBUG - 2012-10-02 19:10:39 --> Model Class Initialized
DEBUG - 2012-10-02 19:10:39 --> Database Driver Class Initialized
DEBUG - 2012-10-02 19:10:40 --> Final output sent to browser
DEBUG - 2012-10-02 19:10:40 --> Total execution time: 0.1633
DEBUG - 2012-10-02 19:10:41 --> Config Class Initialized
DEBUG - 2012-10-02 19:10:41 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:10:41 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:10:41 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:10:41 --> URI Class Initialized
DEBUG - 2012-10-02 19:10:41 --> Router Class Initialized
DEBUG - 2012-10-02 19:10:41 --> Output Class Initialized
DEBUG - 2012-10-02 19:10:41 --> Security Class Initialized
DEBUG - 2012-10-02 19:10:41 --> Input Class Initialized
DEBUG - 2012-10-02 19:10:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 19:10:41 --> Language Class Initialized
DEBUG - 2012-10-02 19:10:41 --> Loader Class Initialized
DEBUG - 2012-10-02 19:10:41 --> Helper loaded: url_helper
DEBUG - 2012-10-02 19:10:41 --> Controller Class Initialized
DEBUG - 2012-10-02 19:10:41 --> Model Class Initialized
DEBUG - 2012-10-02 19:10:41 --> Database Driver Class Initialized
DEBUG - 2012-10-02 19:10:41 --> Final output sent to browser
DEBUG - 2012-10-02 19:10:41 --> Total execution time: 0.0805
DEBUG - 2012-10-02 19:10:42 --> Config Class Initialized
DEBUG - 2012-10-02 19:10:42 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:10:42 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:10:42 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:10:42 --> URI Class Initialized
DEBUG - 2012-10-02 19:10:42 --> Router Class Initialized
DEBUG - 2012-10-02 19:10:42 --> Output Class Initialized
DEBUG - 2012-10-02 19:10:42 --> Security Class Initialized
DEBUG - 2012-10-02 19:10:42 --> Input Class Initialized
DEBUG - 2012-10-02 19:10:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 19:10:42 --> Language Class Initialized
DEBUG - 2012-10-02 19:10:42 --> Loader Class Initialized
DEBUG - 2012-10-02 19:10:42 --> Helper loaded: url_helper
DEBUG - 2012-10-02 19:10:42 --> Controller Class Initialized
DEBUG - 2012-10-02 19:10:42 --> Model Class Initialized
DEBUG - 2012-10-02 19:10:42 --> Database Driver Class Initialized
DEBUG - 2012-10-02 19:10:43 --> Final output sent to browser
DEBUG - 2012-10-02 19:10:43 --> Total execution time: 0.1254
DEBUG - 2012-10-02 19:10:59 --> Config Class Initialized
DEBUG - 2012-10-02 19:10:59 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:10:59 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:10:59 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:10:59 --> URI Class Initialized
DEBUG - 2012-10-02 19:10:59 --> Router Class Initialized
DEBUG - 2012-10-02 19:10:59 --> Output Class Initialized
DEBUG - 2012-10-02 19:10:59 --> Security Class Initialized
DEBUG - 2012-10-02 19:10:59 --> Input Class Initialized
DEBUG - 2012-10-02 19:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 19:10:59 --> Language Class Initialized
DEBUG - 2012-10-02 19:10:59 --> Loader Class Initialized
DEBUG - 2012-10-02 19:10:59 --> Helper loaded: url_helper
DEBUG - 2012-10-02 19:10:59 --> Controller Class Initialized
DEBUG - 2012-10-02 19:10:59 --> Model Class Initialized
DEBUG - 2012-10-02 19:10:59 --> Database Driver Class Initialized
DEBUG - 2012-10-02 19:10:59 --> Helper loaded: form_helper
DEBUG - 2012-10-02 19:10:59 --> Helper loaded: language_helper
DEBUG - 2012-10-02 19:10:59 --> Form Validation Class Initialized
DEBUG - 2012-10-02 19:10:59 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 19:10:59 --> Upload Class Initialized
DEBUG - 2012-10-02 19:10:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 19:10:59 --> Image Lib Class Initialized
DEBUG - 2012-10-02 19:10:59 --> Final output sent to browser
DEBUG - 2012-10-02 19:10:59 --> Total execution time: 0.2672
DEBUG - 2012-10-02 19:11:26 --> Config Class Initialized
DEBUG - 2012-10-02 19:11:26 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:11:26 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:11:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:11:26 --> URI Class Initialized
DEBUG - 2012-10-02 19:11:26 --> Router Class Initialized
DEBUG - 2012-10-02 19:11:26 --> Output Class Initialized
DEBUG - 2012-10-02 19:11:26 --> Security Class Initialized
DEBUG - 2012-10-02 19:11:26 --> Input Class Initialized
DEBUG - 2012-10-02 19:11:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 19:11:26 --> Language Class Initialized
DEBUG - 2012-10-02 19:11:26 --> Loader Class Initialized
DEBUG - 2012-10-02 19:11:26 --> Helper loaded: url_helper
DEBUG - 2012-10-02 19:11:26 --> Controller Class Initialized
DEBUG - 2012-10-02 19:11:26 --> Model Class Initialized
DEBUG - 2012-10-02 19:11:26 --> Database Driver Class Initialized
DEBUG - 2012-10-02 19:11:26 --> Helper loaded: form_helper
DEBUG - 2012-10-02 19:11:26 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 19:11:26 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 19:11:26 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 19:11:26 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 19:11:26 --> Final output sent to browser
DEBUG - 2012-10-02 19:11:26 --> Total execution time: 0.0394
DEBUG - 2012-10-02 19:11:28 --> Config Class Initialized
DEBUG - 2012-10-02 19:11:28 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:11:28 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:11:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:11:28 --> URI Class Initialized
DEBUG - 2012-10-02 19:11:28 --> Router Class Initialized
ERROR - 2012-10-02 19:11:28 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 19:11:28 --> Config Class Initialized
DEBUG - 2012-10-02 19:11:28 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:11:28 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:11:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:11:28 --> URI Class Initialized
DEBUG - 2012-10-02 19:11:28 --> Router Class Initialized
ERROR - 2012-10-02 19:11:28 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 19:11:28 --> Config Class Initialized
DEBUG - 2012-10-02 19:11:28 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:11:28 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:11:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:11:28 --> URI Class Initialized
DEBUG - 2012-10-02 19:11:28 --> Router Class Initialized
ERROR - 2012-10-02 19:11:28 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 19:11:30 --> Config Class Initialized
DEBUG - 2012-10-02 19:11:30 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:11:30 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:11:30 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:11:30 --> URI Class Initialized
DEBUG - 2012-10-02 19:11:30 --> Router Class Initialized
DEBUG - 2012-10-02 19:11:30 --> Output Class Initialized
DEBUG - 2012-10-02 19:11:30 --> Security Class Initialized
DEBUG - 2012-10-02 19:11:30 --> Input Class Initialized
DEBUG - 2012-10-02 19:11:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 19:11:30 --> Language Class Initialized
DEBUG - 2012-10-02 19:11:30 --> Loader Class Initialized
DEBUG - 2012-10-02 19:11:30 --> Helper loaded: url_helper
DEBUG - 2012-10-02 19:11:30 --> Controller Class Initialized
DEBUG - 2012-10-02 19:11:30 --> Model Class Initialized
DEBUG - 2012-10-02 19:11:30 --> Database Driver Class Initialized
DEBUG - 2012-10-02 19:11:30 --> Final output sent to browser
DEBUG - 2012-10-02 19:11:30 --> Total execution time: 0.1560
DEBUG - 2012-10-02 19:11:42 --> Config Class Initialized
DEBUG - 2012-10-02 19:11:42 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:11:42 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:11:42 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:11:42 --> URI Class Initialized
DEBUG - 2012-10-02 19:11:42 --> Router Class Initialized
DEBUG - 2012-10-02 19:11:42 --> Output Class Initialized
DEBUG - 2012-10-02 19:11:42 --> Security Class Initialized
DEBUG - 2012-10-02 19:11:42 --> Input Class Initialized
DEBUG - 2012-10-02 19:11:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 19:11:42 --> Language Class Initialized
DEBUG - 2012-10-02 19:11:42 --> Loader Class Initialized
DEBUG - 2012-10-02 19:11:42 --> Helper loaded: url_helper
DEBUG - 2012-10-02 19:11:42 --> Controller Class Initialized
DEBUG - 2012-10-02 19:11:42 --> Model Class Initialized
DEBUG - 2012-10-02 19:11:42 --> Database Driver Class Initialized
DEBUG - 2012-10-02 19:11:42 --> Helper loaded: form_helper
DEBUG - 2012-10-02 19:11:42 --> Helper loaded: language_helper
DEBUG - 2012-10-02 19:11:42 --> Form Validation Class Initialized
DEBUG - 2012-10-02 19:11:42 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 19:11:42 --> Upload Class Initialized
DEBUG - 2012-10-02 19:11:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 19:11:42 --> Image Lib Class Initialized
DEBUG - 2012-10-02 19:11:42 --> Final output sent to browser
DEBUG - 2012-10-02 19:11:42 --> Total execution time: 0.1698
DEBUG - 2012-10-02 19:19:01 --> Config Class Initialized
DEBUG - 2012-10-02 19:19:01 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:19:01 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:19:01 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:19:01 --> URI Class Initialized
DEBUG - 2012-10-02 19:19:01 --> Router Class Initialized
DEBUG - 2012-10-02 19:19:01 --> Output Class Initialized
DEBUG - 2012-10-02 19:19:01 --> Security Class Initialized
DEBUG - 2012-10-02 19:19:01 --> Input Class Initialized
DEBUG - 2012-10-02 19:19:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 19:19:01 --> Language Class Initialized
DEBUG - 2012-10-02 19:19:01 --> Loader Class Initialized
DEBUG - 2012-10-02 19:19:01 --> Helper loaded: url_helper
DEBUG - 2012-10-02 19:19:01 --> Controller Class Initialized
DEBUG - 2012-10-02 19:19:01 --> Model Class Initialized
DEBUG - 2012-10-02 19:19:01 --> Database Driver Class Initialized
DEBUG - 2012-10-02 19:19:01 --> Final output sent to browser
DEBUG - 2012-10-02 19:19:01 --> Total execution time: 0.2443
DEBUG - 2012-10-02 19:19:09 --> Config Class Initialized
DEBUG - 2012-10-02 19:19:09 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:19:09 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:19:09 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:19:09 --> URI Class Initialized
DEBUG - 2012-10-02 19:19:09 --> Router Class Initialized
DEBUG - 2012-10-02 19:19:09 --> Output Class Initialized
DEBUG - 2012-10-02 19:19:09 --> Security Class Initialized
DEBUG - 2012-10-02 19:19:09 --> Input Class Initialized
DEBUG - 2012-10-02 19:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 19:19:09 --> Language Class Initialized
DEBUG - 2012-10-02 19:19:09 --> Loader Class Initialized
DEBUG - 2012-10-02 19:19:09 --> Helper loaded: url_helper
DEBUG - 2012-10-02 19:19:09 --> Controller Class Initialized
DEBUG - 2012-10-02 19:19:09 --> Model Class Initialized
DEBUG - 2012-10-02 19:19:09 --> Database Driver Class Initialized
DEBUG - 2012-10-02 19:19:09 --> Helper loaded: form_helper
DEBUG - 2012-10-02 19:19:09 --> Helper loaded: language_helper
DEBUG - 2012-10-02 19:19:09 --> Form Validation Class Initialized
DEBUG - 2012-10-02 19:19:09 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 19:19:09 --> Upload Class Initialized
DEBUG - 2012-10-02 19:19:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 19:19:09 --> Image Lib Class Initialized
DEBUG - 2012-10-02 19:19:09 --> Final output sent to browser
DEBUG - 2012-10-02 19:19:09 --> Total execution time: 0.1764
DEBUG - 2012-10-02 19:19:16 --> Config Class Initialized
DEBUG - 2012-10-02 19:19:16 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:19:16 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:19:16 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:19:16 --> URI Class Initialized
DEBUG - 2012-10-02 19:19:16 --> Router Class Initialized
DEBUG - 2012-10-02 19:19:16 --> Output Class Initialized
DEBUG - 2012-10-02 19:19:16 --> Security Class Initialized
DEBUG - 2012-10-02 19:19:16 --> Input Class Initialized
DEBUG - 2012-10-02 19:19:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 19:19:16 --> Language Class Initialized
DEBUG - 2012-10-02 19:19:16 --> Loader Class Initialized
DEBUG - 2012-10-02 19:19:16 --> Helper loaded: url_helper
DEBUG - 2012-10-02 19:19:16 --> Controller Class Initialized
DEBUG - 2012-10-02 19:19:16 --> Model Class Initialized
DEBUG - 2012-10-02 19:19:16 --> Database Driver Class Initialized
DEBUG - 2012-10-02 19:19:16 --> Helper loaded: form_helper
DEBUG - 2012-10-02 19:19:16 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 19:19:16 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 19:19:16 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 19:19:16 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 19:19:16 --> Final output sent to browser
DEBUG - 2012-10-02 19:19:16 --> Total execution time: 0.0395
DEBUG - 2012-10-02 19:19:18 --> Config Class Initialized
DEBUG - 2012-10-02 19:19:18 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:19:18 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:19:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:19:18 --> URI Class Initialized
DEBUG - 2012-10-02 19:19:18 --> Router Class Initialized
ERROR - 2012-10-02 19:19:18 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 19:19:18 --> Config Class Initialized
DEBUG - 2012-10-02 19:19:18 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:19:18 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:19:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:19:18 --> URI Class Initialized
DEBUG - 2012-10-02 19:19:18 --> Router Class Initialized
ERROR - 2012-10-02 19:19:18 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 19:19:18 --> Config Class Initialized
DEBUG - 2012-10-02 19:19:18 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:19:18 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:19:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:19:18 --> URI Class Initialized
DEBUG - 2012-10-02 19:19:18 --> Router Class Initialized
ERROR - 2012-10-02 19:19:18 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 19:33:41 --> Config Class Initialized
DEBUG - 2012-10-02 19:33:41 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:33:41 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:33:41 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:33:41 --> URI Class Initialized
DEBUG - 2012-10-02 19:33:41 --> Router Class Initialized
DEBUG - 2012-10-02 19:33:41 --> Output Class Initialized
DEBUG - 2012-10-02 19:33:41 --> Security Class Initialized
DEBUG - 2012-10-02 19:33:41 --> Input Class Initialized
DEBUG - 2012-10-02 19:33:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 19:33:41 --> Language Class Initialized
DEBUG - 2012-10-02 19:33:41 --> Loader Class Initialized
DEBUG - 2012-10-02 19:33:41 --> Helper loaded: url_helper
DEBUG - 2012-10-02 19:33:41 --> Controller Class Initialized
DEBUG - 2012-10-02 19:33:41 --> Model Class Initialized
DEBUG - 2012-10-02 19:33:41 --> Database Driver Class Initialized
DEBUG - 2012-10-02 19:33:41 --> Helper loaded: form_helper
DEBUG - 2012-10-02 19:33:41 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 19:33:41 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 19:33:41 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 19:33:41 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 19:33:41 --> Final output sent to browser
DEBUG - 2012-10-02 19:33:41 --> Total execution time: 0.0389
DEBUG - 2012-10-02 19:33:42 --> Config Class Initialized
DEBUG - 2012-10-02 19:33:42 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:33:42 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:33:42 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:33:42 --> URI Class Initialized
DEBUG - 2012-10-02 19:33:42 --> Router Class Initialized
ERROR - 2012-10-02 19:33:42 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 19:33:42 --> Config Class Initialized
DEBUG - 2012-10-02 19:33:42 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:33:42 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:33:42 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:33:42 --> URI Class Initialized
DEBUG - 2012-10-02 19:33:42 --> Router Class Initialized
ERROR - 2012-10-02 19:33:42 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 19:33:42 --> Config Class Initialized
DEBUG - 2012-10-02 19:33:42 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:33:42 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:33:42 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:33:42 --> URI Class Initialized
DEBUG - 2012-10-02 19:33:42 --> Router Class Initialized
ERROR - 2012-10-02 19:33:42 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 19:33:52 --> Config Class Initialized
DEBUG - 2012-10-02 19:33:52 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:33:52 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:33:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:33:52 --> URI Class Initialized
DEBUG - 2012-10-02 19:33:52 --> Router Class Initialized
DEBUG - 2012-10-02 19:33:52 --> Output Class Initialized
DEBUG - 2012-10-02 19:33:52 --> Security Class Initialized
DEBUG - 2012-10-02 19:33:52 --> Input Class Initialized
DEBUG - 2012-10-02 19:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 19:33:52 --> Language Class Initialized
DEBUG - 2012-10-02 19:33:52 --> Loader Class Initialized
DEBUG - 2012-10-02 19:33:52 --> Helper loaded: url_helper
DEBUG - 2012-10-02 19:33:52 --> Controller Class Initialized
DEBUG - 2012-10-02 19:33:52 --> Model Class Initialized
DEBUG - 2012-10-02 19:33:52 --> Database Driver Class Initialized
DEBUG - 2012-10-02 19:33:52 --> Final output sent to browser
DEBUG - 2012-10-02 19:33:52 --> Total execution time: 0.1392
DEBUG - 2012-10-02 19:34:05 --> Config Class Initialized
DEBUG - 2012-10-02 19:34:05 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:34:05 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:34:05 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:34:05 --> URI Class Initialized
DEBUG - 2012-10-02 19:34:05 --> Router Class Initialized
DEBUG - 2012-10-02 19:34:05 --> Output Class Initialized
DEBUG - 2012-10-02 19:34:05 --> Security Class Initialized
DEBUG - 2012-10-02 19:34:05 --> Input Class Initialized
DEBUG - 2012-10-02 19:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 19:34:05 --> Language Class Initialized
DEBUG - 2012-10-02 19:34:05 --> Loader Class Initialized
DEBUG - 2012-10-02 19:34:05 --> Helper loaded: url_helper
DEBUG - 2012-10-02 19:34:05 --> Controller Class Initialized
DEBUG - 2012-10-02 19:34:05 --> Model Class Initialized
DEBUG - 2012-10-02 19:34:05 --> Database Driver Class Initialized
DEBUG - 2012-10-02 19:34:05 --> Helper loaded: form_helper
DEBUG - 2012-10-02 19:34:05 --> Helper loaded: language_helper
DEBUG - 2012-10-02 19:34:05 --> Form Validation Class Initialized
DEBUG - 2012-10-02 19:34:05 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 19:34:05 --> Upload Class Initialized
DEBUG - 2012-10-02 19:34:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 19:34:05 --> Image Lib Class Initialized
DEBUG - 2012-10-02 19:34:05 --> Final output sent to browser
DEBUG - 2012-10-02 19:34:05 --> Total execution time: 0.1757
DEBUG - 2012-10-02 19:35:15 --> Config Class Initialized
DEBUG - 2012-10-02 19:35:15 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:35:15 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:35:15 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:35:15 --> URI Class Initialized
DEBUG - 2012-10-02 19:35:15 --> Router Class Initialized
DEBUG - 2012-10-02 19:35:15 --> Output Class Initialized
DEBUG - 2012-10-02 19:35:15 --> Security Class Initialized
DEBUG - 2012-10-02 19:35:15 --> Input Class Initialized
DEBUG - 2012-10-02 19:35:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 19:35:15 --> Language Class Initialized
DEBUG - 2012-10-02 19:35:15 --> Loader Class Initialized
DEBUG - 2012-10-02 19:35:15 --> Helper loaded: url_helper
DEBUG - 2012-10-02 19:35:15 --> Controller Class Initialized
DEBUG - 2012-10-02 19:35:15 --> Model Class Initialized
DEBUG - 2012-10-02 19:35:15 --> Database Driver Class Initialized
DEBUG - 2012-10-02 19:35:15 --> Helper loaded: form_helper
DEBUG - 2012-10-02 19:35:15 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-02 19:35:15 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-02 19:35:15 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-02 19:35:15 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-02 19:35:15 --> Final output sent to browser
DEBUG - 2012-10-02 19:35:15 --> Total execution time: 0.0396
DEBUG - 2012-10-02 19:35:17 --> Config Class Initialized
DEBUG - 2012-10-02 19:35:17 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:35:17 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:35:17 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:35:17 --> URI Class Initialized
DEBUG - 2012-10-02 19:35:17 --> Router Class Initialized
ERROR - 2012-10-02 19:35:17 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 19:35:17 --> Config Class Initialized
DEBUG - 2012-10-02 19:35:17 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:35:17 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:35:17 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:35:17 --> URI Class Initialized
DEBUG - 2012-10-02 19:35:17 --> Router Class Initialized
ERROR - 2012-10-02 19:35:17 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 19:35:17 --> Config Class Initialized
DEBUG - 2012-10-02 19:35:17 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:35:17 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:35:17 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:35:17 --> URI Class Initialized
DEBUG - 2012-10-02 19:35:17 --> Router Class Initialized
ERROR - 2012-10-02 19:35:17 --> 404 Page Not Found --> css
DEBUG - 2012-10-02 19:35:27 --> Config Class Initialized
DEBUG - 2012-10-02 19:35:27 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:35:27 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:35:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:35:27 --> URI Class Initialized
DEBUG - 2012-10-02 19:35:27 --> Router Class Initialized
DEBUG - 2012-10-02 19:35:27 --> Output Class Initialized
DEBUG - 2012-10-02 19:35:27 --> Security Class Initialized
DEBUG - 2012-10-02 19:35:27 --> Input Class Initialized
DEBUG - 2012-10-02 19:35:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 19:35:27 --> Language Class Initialized
DEBUG - 2012-10-02 19:35:27 --> Loader Class Initialized
DEBUG - 2012-10-02 19:35:27 --> Helper loaded: url_helper
DEBUG - 2012-10-02 19:35:27 --> Controller Class Initialized
DEBUG - 2012-10-02 19:35:27 --> Model Class Initialized
DEBUG - 2012-10-02 19:35:27 --> Database Driver Class Initialized
DEBUG - 2012-10-02 19:35:27 --> Final output sent to browser
DEBUG - 2012-10-02 19:35:27 --> Total execution time: 0.1005
DEBUG - 2012-10-02 19:35:39 --> Config Class Initialized
DEBUG - 2012-10-02 19:35:39 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:35:39 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:35:39 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:35:39 --> URI Class Initialized
DEBUG - 2012-10-02 19:35:39 --> Router Class Initialized
DEBUG - 2012-10-02 19:35:39 --> Output Class Initialized
DEBUG - 2012-10-02 19:35:39 --> Security Class Initialized
DEBUG - 2012-10-02 19:35:39 --> Input Class Initialized
DEBUG - 2012-10-02 19:35:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 19:35:39 --> Language Class Initialized
DEBUG - 2012-10-02 19:35:39 --> Loader Class Initialized
DEBUG - 2012-10-02 19:35:39 --> Helper loaded: url_helper
DEBUG - 2012-10-02 19:35:39 --> Controller Class Initialized
DEBUG - 2012-10-02 19:35:39 --> Model Class Initialized
DEBUG - 2012-10-02 19:35:39 --> Database Driver Class Initialized
DEBUG - 2012-10-02 19:35:39 --> Helper loaded: form_helper
DEBUG - 2012-10-02 19:35:39 --> Helper loaded: language_helper
DEBUG - 2012-10-02 19:35:39 --> Form Validation Class Initialized
DEBUG - 2012-10-02 19:35:39 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 19:35:39 --> Upload Class Initialized
DEBUG - 2012-10-02 19:35:39 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 19:35:39 --> Image Lib Class Initialized
DEBUG - 2012-10-02 19:35:39 --> Final output sent to browser
DEBUG - 2012-10-02 19:35:39 --> Total execution time: 0.1786
DEBUG - 2012-10-02 19:36:06 --> Config Class Initialized
DEBUG - 2012-10-02 19:36:06 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:36:06 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:36:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:36:06 --> URI Class Initialized
DEBUG - 2012-10-02 19:36:06 --> Router Class Initialized
DEBUG - 2012-10-02 19:36:06 --> Output Class Initialized
DEBUG - 2012-10-02 19:36:06 --> Security Class Initialized
DEBUG - 2012-10-02 19:36:06 --> Input Class Initialized
DEBUG - 2012-10-02 19:36:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 19:36:06 --> Language Class Initialized
DEBUG - 2012-10-02 19:36:06 --> Loader Class Initialized
DEBUG - 2012-10-02 19:36:06 --> Helper loaded: url_helper
DEBUG - 2012-10-02 19:36:06 --> Controller Class Initialized
DEBUG - 2012-10-02 19:36:06 --> Model Class Initialized
DEBUG - 2012-10-02 19:36:06 --> Database Driver Class Initialized
DEBUG - 2012-10-02 19:36:06 --> Helper loaded: form_helper
DEBUG - 2012-10-02 19:36:06 --> Helper loaded: language_helper
DEBUG - 2012-10-02 19:36:06 --> Form Validation Class Initialized
DEBUG - 2012-10-02 19:36:06 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 19:36:06 --> Upload Class Initialized
DEBUG - 2012-10-02 19:36:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 19:36:06 --> Image Lib Class Initialized
DEBUG - 2012-10-02 19:36:06 --> Final output sent to browser
DEBUG - 2012-10-02 19:36:06 --> Total execution time: 0.1741
DEBUG - 2012-10-02 19:37:17 --> Config Class Initialized
DEBUG - 2012-10-02 19:37:17 --> Hooks Class Initialized
DEBUG - 2012-10-02 19:37:17 --> Utf8 Class Initialized
DEBUG - 2012-10-02 19:37:17 --> UTF-8 Support Enabled
DEBUG - 2012-10-02 19:37:17 --> URI Class Initialized
DEBUG - 2012-10-02 19:37:17 --> Router Class Initialized
DEBUG - 2012-10-02 19:37:17 --> Output Class Initialized
DEBUG - 2012-10-02 19:37:17 --> Security Class Initialized
DEBUG - 2012-10-02 19:37:17 --> Input Class Initialized
DEBUG - 2012-10-02 19:37:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-02 19:37:17 --> Language Class Initialized
DEBUG - 2012-10-02 19:37:17 --> Loader Class Initialized
DEBUG - 2012-10-02 19:37:17 --> Helper loaded: url_helper
DEBUG - 2012-10-02 19:37:17 --> Controller Class Initialized
DEBUG - 2012-10-02 19:37:17 --> Model Class Initialized
DEBUG - 2012-10-02 19:37:17 --> Database Driver Class Initialized
DEBUG - 2012-10-02 19:37:17 --> Helper loaded: form_helper
DEBUG - 2012-10-02 19:37:17 --> Helper loaded: language_helper
DEBUG - 2012-10-02 19:37:17 --> Form Validation Class Initialized
DEBUG - 2012-10-02 19:37:17 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-02 19:37:17 --> Upload Class Initialized
DEBUG - 2012-10-02 19:37:17 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-02 19:37:17 --> Image Lib Class Initialized
DEBUG - 2012-10-02 19:37:17 --> Final output sent to browser
DEBUG - 2012-10-02 19:37:17 --> Total execution time: 0.1488
