<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-10-03 14:41:19 --> Config Class Initialized
DEBUG - 2012-10-03 14:41:19 --> Hooks Class Initialized
DEBUG - 2012-10-03 14:41:19 --> Utf8 Class Initialized
DEBUG - 2012-10-03 14:41:19 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 14:41:19 --> URI Class Initialized
DEBUG - 2012-10-03 14:41:19 --> Router Class Initialized
DEBUG - 2012-10-03 14:41:19 --> Output Class Initialized
DEBUG - 2012-10-03 14:41:19 --> Security Class Initialized
DEBUG - 2012-10-03 14:41:19 --> Input Class Initialized
DEBUG - 2012-10-03 14:41:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 14:41:19 --> Language Class Initialized
DEBUG - 2012-10-03 14:41:19 --> Loader Class Initialized
DEBUG - 2012-10-03 14:41:19 --> Helper loaded: url_helper
DEBUG - 2012-10-03 14:41:19 --> Controller Class Initialized
DEBUG - 2012-10-03 14:41:19 --> Model Class Initialized
DEBUG - 2012-10-03 14:41:19 --> Database Driver Class Initialized
DEBUG - 2012-10-03 14:41:19 --> Helper loaded: form_helper
DEBUG - 2012-10-03 14:41:20 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 14:41:20 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-10-03 14:41:20 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 14:41:20 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-10-03 14:41:20 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 14:41:20 --> Final output sent to browser
DEBUG - 2012-10-03 14:41:20 --> Total execution time: 0.7835
DEBUG - 2012-10-03 14:41:22 --> Config Class Initialized
DEBUG - 2012-10-03 14:41:22 --> Hooks Class Initialized
DEBUG - 2012-10-03 14:41:22 --> Utf8 Class Initialized
DEBUG - 2012-10-03 14:41:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 14:41:22 --> URI Class Initialized
DEBUG - 2012-10-03 14:41:22 --> Config Class Initialized
DEBUG - 2012-10-03 14:41:22 --> Config Class Initialized
DEBUG - 2012-10-03 14:41:22 --> Hooks Class Initialized
DEBUG - 2012-10-03 14:41:22 --> Hooks Class Initialized
DEBUG - 2012-10-03 14:41:22 --> Router Class Initialized
DEBUG - 2012-10-03 14:41:22 --> Utf8 Class Initialized
DEBUG - 2012-10-03 14:41:22 --> Utf8 Class Initialized
DEBUG - 2012-10-03 14:41:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 14:41:22 --> UTF-8 Support Enabled
ERROR - 2012-10-03 14:41:22 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 14:41:22 --> URI Class Initialized
DEBUG - 2012-10-03 14:41:22 --> URI Class Initialized
DEBUG - 2012-10-03 14:41:22 --> Router Class Initialized
DEBUG - 2012-10-03 14:41:22 --> Router Class Initialized
ERROR - 2012-10-03 14:41:22 --> 404 Page Not Found --> css
ERROR - 2012-10-03 14:41:22 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 14:41:24 --> Config Class Initialized
DEBUG - 2012-10-03 14:41:24 --> Hooks Class Initialized
DEBUG - 2012-10-03 14:41:24 --> Utf8 Class Initialized
DEBUG - 2012-10-03 14:41:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 14:41:24 --> URI Class Initialized
DEBUG - 2012-10-03 14:41:24 --> Router Class Initialized
DEBUG - 2012-10-03 14:41:24 --> Output Class Initialized
DEBUG - 2012-10-03 14:41:24 --> Security Class Initialized
DEBUG - 2012-10-03 14:41:24 --> Input Class Initialized
DEBUG - 2012-10-03 14:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 14:41:24 --> Language Class Initialized
DEBUG - 2012-10-03 14:41:24 --> Loader Class Initialized
DEBUG - 2012-10-03 14:41:24 --> Helper loaded: url_helper
DEBUG - 2012-10-03 14:41:24 --> Controller Class Initialized
DEBUG - 2012-10-03 14:41:24 --> Model Class Initialized
DEBUG - 2012-10-03 14:41:24 --> Database Driver Class Initialized
DEBUG - 2012-10-03 14:41:24 --> Helper loaded: form_helper
DEBUG - 2012-10-03 14:41:24 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 14:41:24 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 14:41:24 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 14:41:24 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 14:41:24 --> Final output sent to browser
DEBUG - 2012-10-03 14:41:24 --> Total execution time: 0.1543
DEBUG - 2012-10-03 15:32:41 --> Config Class Initialized
DEBUG - 2012-10-03 15:32:41 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:32:41 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:32:41 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:32:41 --> URI Class Initialized
DEBUG - 2012-10-03 15:32:41 --> Router Class Initialized
DEBUG - 2012-10-03 15:32:41 --> Output Class Initialized
DEBUG - 2012-10-03 15:32:41 --> Security Class Initialized
DEBUG - 2012-10-03 15:32:41 --> Input Class Initialized
DEBUG - 2012-10-03 15:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 15:32:41 --> Language Class Initialized
DEBUG - 2012-10-03 15:32:41 --> Loader Class Initialized
DEBUG - 2012-10-03 15:32:41 --> Helper loaded: url_helper
DEBUG - 2012-10-03 15:32:41 --> Controller Class Initialized
DEBUG - 2012-10-03 15:32:41 --> Model Class Initialized
DEBUG - 2012-10-03 15:32:41 --> Database Driver Class Initialized
DEBUG - 2012-10-03 15:32:41 --> Helper loaded: form_helper
DEBUG - 2012-10-03 15:32:41 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 15:32:41 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 15:32:41 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 15:32:41 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 15:32:41 --> Final output sent to browser
DEBUG - 2012-10-03 15:32:41 --> Total execution time: 0.0435
DEBUG - 2012-10-03 15:32:58 --> Config Class Initialized
DEBUG - 2012-10-03 15:32:58 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:32:58 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:32:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:32:58 --> URI Class Initialized
DEBUG - 2012-10-03 15:32:58 --> Router Class Initialized
DEBUG - 2012-10-03 15:32:58 --> Output Class Initialized
DEBUG - 2012-10-03 15:32:58 --> Security Class Initialized
DEBUG - 2012-10-03 15:32:58 --> Input Class Initialized
DEBUG - 2012-10-03 15:32:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 15:32:58 --> Language Class Initialized
DEBUG - 2012-10-03 15:32:58 --> Loader Class Initialized
DEBUG - 2012-10-03 15:32:58 --> Helper loaded: url_helper
DEBUG - 2012-10-03 15:32:58 --> Controller Class Initialized
DEBUG - 2012-10-03 15:32:58 --> Model Class Initialized
DEBUG - 2012-10-03 15:32:58 --> Database Driver Class Initialized
DEBUG - 2012-10-03 15:32:58 --> Helper loaded: form_helper
DEBUG - 2012-10-03 15:32:58 --> Helper loaded: language_helper
DEBUG - 2012-10-03 15:32:58 --> Form Validation Class Initialized
DEBUG - 2012-10-03 15:32:58 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-03 15:32:58 --> Upload Class Initialized
DEBUG - 2012-10-03 15:32:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-03 15:32:58 --> Image Lib Class Initialized
DEBUG - 2012-10-03 15:32:59 --> Final output sent to browser
DEBUG - 2012-10-03 15:32:59 --> Total execution time: 0.4535
DEBUG - 2012-10-03 15:35:32 --> Config Class Initialized
DEBUG - 2012-10-03 15:35:32 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:35:32 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:35:32 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:35:32 --> URI Class Initialized
DEBUG - 2012-10-03 15:35:32 --> Router Class Initialized
DEBUG - 2012-10-03 15:35:32 --> Output Class Initialized
DEBUG - 2012-10-03 15:35:32 --> Security Class Initialized
DEBUG - 2012-10-03 15:35:32 --> Input Class Initialized
DEBUG - 2012-10-03 15:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 15:35:32 --> Language Class Initialized
DEBUG - 2012-10-03 15:35:32 --> Loader Class Initialized
DEBUG - 2012-10-03 15:35:32 --> Helper loaded: url_helper
DEBUG - 2012-10-03 15:35:32 --> Controller Class Initialized
DEBUG - 2012-10-03 15:35:32 --> Model Class Initialized
DEBUG - 2012-10-03 15:35:32 --> Database Driver Class Initialized
DEBUG - 2012-10-03 15:35:32 --> Helper loaded: form_helper
DEBUG - 2012-10-03 15:35:32 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 15:35:32 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 15:35:32 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 15:35:32 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 15:35:32 --> Final output sent to browser
DEBUG - 2012-10-03 15:35:32 --> Total execution time: 0.1606
DEBUG - 2012-10-03 15:35:33 --> Config Class Initialized
DEBUG - 2012-10-03 15:35:33 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:35:33 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:35:33 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:35:33 --> URI Class Initialized
DEBUG - 2012-10-03 15:35:33 --> Router Class Initialized
ERROR - 2012-10-03 15:35:33 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 15:35:33 --> Config Class Initialized
DEBUG - 2012-10-03 15:35:33 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:35:33 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:35:33 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:35:33 --> URI Class Initialized
DEBUG - 2012-10-03 15:35:33 --> Router Class Initialized
ERROR - 2012-10-03 15:35:33 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 15:35:33 --> Config Class Initialized
DEBUG - 2012-10-03 15:35:33 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:35:33 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:35:33 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:35:33 --> URI Class Initialized
DEBUG - 2012-10-03 15:35:33 --> Router Class Initialized
ERROR - 2012-10-03 15:35:33 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 15:35:45 --> Config Class Initialized
DEBUG - 2012-10-03 15:35:45 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:35:45 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:35:45 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:35:45 --> URI Class Initialized
DEBUG - 2012-10-03 15:35:45 --> Router Class Initialized
DEBUG - 2012-10-03 15:35:45 --> Output Class Initialized
DEBUG - 2012-10-03 15:35:45 --> Security Class Initialized
DEBUG - 2012-10-03 15:35:45 --> Input Class Initialized
DEBUG - 2012-10-03 15:35:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 15:35:45 --> Language Class Initialized
DEBUG - 2012-10-03 15:35:45 --> Loader Class Initialized
DEBUG - 2012-10-03 15:35:45 --> Helper loaded: url_helper
DEBUG - 2012-10-03 15:35:45 --> Controller Class Initialized
DEBUG - 2012-10-03 15:35:45 --> Model Class Initialized
DEBUG - 2012-10-03 15:35:45 --> Database Driver Class Initialized
DEBUG - 2012-10-03 15:35:45 --> Helper loaded: form_helper
DEBUG - 2012-10-03 15:35:45 --> Helper loaded: language_helper
DEBUG - 2012-10-03 15:35:45 --> Form Validation Class Initialized
DEBUG - 2012-10-03 15:35:45 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-03 15:35:45 --> Upload Class Initialized
DEBUG - 2012-10-03 15:35:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-03 15:35:45 --> Image Lib Class Initialized
DEBUG - 2012-10-03 15:35:45 --> Final output sent to browser
DEBUG - 2012-10-03 15:35:45 --> Total execution time: 0.2239
DEBUG - 2012-10-03 15:36:46 --> Config Class Initialized
DEBUG - 2012-10-03 15:36:46 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:36:46 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:36:46 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:36:46 --> URI Class Initialized
DEBUG - 2012-10-03 15:36:46 --> Router Class Initialized
DEBUG - 2012-10-03 15:36:46 --> Output Class Initialized
DEBUG - 2012-10-03 15:36:46 --> Security Class Initialized
DEBUG - 2012-10-03 15:36:46 --> Input Class Initialized
DEBUG - 2012-10-03 15:36:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 15:36:46 --> Language Class Initialized
DEBUG - 2012-10-03 15:36:46 --> Loader Class Initialized
DEBUG - 2012-10-03 15:36:46 --> Helper loaded: url_helper
DEBUG - 2012-10-03 15:36:46 --> Controller Class Initialized
DEBUG - 2012-10-03 15:36:46 --> Model Class Initialized
DEBUG - 2012-10-03 15:36:46 --> Database Driver Class Initialized
DEBUG - 2012-10-03 15:36:46 --> Helper loaded: form_helper
DEBUG - 2012-10-03 15:36:46 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 15:36:46 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 15:36:46 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 15:36:46 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 15:36:46 --> Final output sent to browser
DEBUG - 2012-10-03 15:36:46 --> Total execution time: 0.0437
DEBUG - 2012-10-03 15:36:48 --> Config Class Initialized
DEBUG - 2012-10-03 15:36:48 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:36:48 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:36:48 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:36:48 --> URI Class Initialized
DEBUG - 2012-10-03 15:36:48 --> Router Class Initialized
ERROR - 2012-10-03 15:36:48 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 15:36:48 --> Config Class Initialized
DEBUG - 2012-10-03 15:36:48 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:36:48 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:36:48 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:36:48 --> URI Class Initialized
DEBUG - 2012-10-03 15:36:48 --> Router Class Initialized
ERROR - 2012-10-03 15:36:48 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 15:36:48 --> Config Class Initialized
DEBUG - 2012-10-03 15:36:48 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:36:48 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:36:48 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:36:48 --> URI Class Initialized
DEBUG - 2012-10-03 15:36:48 --> Router Class Initialized
ERROR - 2012-10-03 15:36:48 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 15:37:06 --> Config Class Initialized
DEBUG - 2012-10-03 15:37:06 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:37:06 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:37:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:37:06 --> URI Class Initialized
DEBUG - 2012-10-03 15:37:06 --> Router Class Initialized
DEBUG - 2012-10-03 15:37:06 --> Output Class Initialized
DEBUG - 2012-10-03 15:37:06 --> Security Class Initialized
DEBUG - 2012-10-03 15:37:06 --> Input Class Initialized
DEBUG - 2012-10-03 15:37:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 15:37:06 --> Language Class Initialized
DEBUG - 2012-10-03 15:37:06 --> Loader Class Initialized
DEBUG - 2012-10-03 15:37:06 --> Helper loaded: url_helper
DEBUG - 2012-10-03 15:37:06 --> Controller Class Initialized
DEBUG - 2012-10-03 15:37:06 --> Model Class Initialized
DEBUG - 2012-10-03 15:37:06 --> Database Driver Class Initialized
DEBUG - 2012-10-03 15:37:06 --> Final output sent to browser
DEBUG - 2012-10-03 15:37:06 --> Total execution time: 0.1103
DEBUG - 2012-10-03 15:37:09 --> Config Class Initialized
DEBUG - 2012-10-03 15:37:09 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:37:09 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:37:09 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:37:09 --> URI Class Initialized
DEBUG - 2012-10-03 15:37:09 --> Router Class Initialized
DEBUG - 2012-10-03 15:37:09 --> Output Class Initialized
DEBUG - 2012-10-03 15:37:09 --> Security Class Initialized
DEBUG - 2012-10-03 15:37:09 --> Input Class Initialized
DEBUG - 2012-10-03 15:37:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 15:37:09 --> Language Class Initialized
DEBUG - 2012-10-03 15:37:09 --> Loader Class Initialized
DEBUG - 2012-10-03 15:37:09 --> Helper loaded: url_helper
DEBUG - 2012-10-03 15:37:09 --> Controller Class Initialized
DEBUG - 2012-10-03 15:37:09 --> Model Class Initialized
DEBUG - 2012-10-03 15:37:09 --> Database Driver Class Initialized
ERROR - 2012-10-03 15:37:09 --> Severity: Notice  --> Undefined offset: 0 /home/jwp/www/justinwylliephotography.com/clients/application/models/pricing_model.php 256
ERROR - 2012-10-03 15:37:09 --> Severity: Notice  --> Trying to get property of non-object /home/jwp/www/justinwylliephotography.com/clients/application/models/pricing_model.php 256
DEBUG - 2012-10-03 15:37:09 --> Final output sent to browser
DEBUG - 2012-10-03 15:37:09 --> Total execution time: 0.0559
DEBUG - 2012-10-03 15:37:09 --> Config Class Initialized
DEBUG - 2012-10-03 15:37:09 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:37:09 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:37:09 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:37:09 --> URI Class Initialized
DEBUG - 2012-10-03 15:37:09 --> Router Class Initialized
DEBUG - 2012-10-03 15:37:09 --> Output Class Initialized
DEBUG - 2012-10-03 15:37:09 --> Security Class Initialized
DEBUG - 2012-10-03 15:37:09 --> Input Class Initialized
DEBUG - 2012-10-03 15:37:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 15:37:09 --> Language Class Initialized
DEBUG - 2012-10-03 15:37:09 --> Loader Class Initialized
DEBUG - 2012-10-03 15:37:09 --> Helper loaded: url_helper
DEBUG - 2012-10-03 15:37:09 --> Controller Class Initialized
DEBUG - 2012-10-03 15:37:09 --> Model Class Initialized
DEBUG - 2012-10-03 15:37:09 --> Database Driver Class Initialized
ERROR - 2012-10-03 15:37:09 --> Severity: Notice  --> Undefined offset: 0 /home/jwp/www/justinwylliephotography.com/clients/application/models/pricing_model.php 256
ERROR - 2012-10-03 15:37:09 --> Severity: Notice  --> Trying to get property of non-object /home/jwp/www/justinwylliephotography.com/clients/application/models/pricing_model.php 256
DEBUG - 2012-10-03 15:37:09 --> Final output sent to browser
DEBUG - 2012-10-03 15:37:09 --> Total execution time: 0.0361
DEBUG - 2012-10-03 15:40:12 --> Config Class Initialized
DEBUG - 2012-10-03 15:40:12 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:40:12 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:40:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:40:12 --> URI Class Initialized
DEBUG - 2012-10-03 15:40:12 --> Router Class Initialized
DEBUG - 2012-10-03 15:40:12 --> Output Class Initialized
DEBUG - 2012-10-03 15:40:12 --> Security Class Initialized
DEBUG - 2012-10-03 15:40:12 --> Input Class Initialized
DEBUG - 2012-10-03 15:40:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 15:40:12 --> Language Class Initialized
DEBUG - 2012-10-03 15:40:12 --> Loader Class Initialized
DEBUG - 2012-10-03 15:40:12 --> Helper loaded: url_helper
DEBUG - 2012-10-03 15:40:12 --> Controller Class Initialized
DEBUG - 2012-10-03 15:40:12 --> Model Class Initialized
DEBUG - 2012-10-03 15:40:12 --> Database Driver Class Initialized
DEBUG - 2012-10-03 15:40:12 --> Helper loaded: form_helper
DEBUG - 2012-10-03 15:40:12 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 15:40:12 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 15:40:12 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 15:40:12 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 15:40:12 --> Final output sent to browser
DEBUG - 2012-10-03 15:40:12 --> Total execution time: 0.0405
DEBUG - 2012-10-03 15:40:14 --> Config Class Initialized
DEBUG - 2012-10-03 15:40:14 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:40:14 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:40:14 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:40:14 --> URI Class Initialized
DEBUG - 2012-10-03 15:40:14 --> Router Class Initialized
ERROR - 2012-10-03 15:40:14 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 15:40:14 --> Config Class Initialized
DEBUG - 2012-10-03 15:40:14 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:40:14 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:40:14 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:40:14 --> URI Class Initialized
DEBUG - 2012-10-03 15:40:14 --> Router Class Initialized
ERROR - 2012-10-03 15:40:14 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 15:40:14 --> Config Class Initialized
DEBUG - 2012-10-03 15:40:14 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:40:14 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:40:14 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:40:14 --> URI Class Initialized
DEBUG - 2012-10-03 15:40:14 --> Router Class Initialized
ERROR - 2012-10-03 15:40:14 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 15:40:17 --> Config Class Initialized
DEBUG - 2012-10-03 15:40:17 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:40:17 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:40:17 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:40:17 --> URI Class Initialized
DEBUG - 2012-10-03 15:40:17 --> Router Class Initialized
DEBUG - 2012-10-03 15:40:17 --> Output Class Initialized
DEBUG - 2012-10-03 15:40:17 --> Security Class Initialized
DEBUG - 2012-10-03 15:40:17 --> Input Class Initialized
DEBUG - 2012-10-03 15:40:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 15:40:17 --> Language Class Initialized
DEBUG - 2012-10-03 15:40:17 --> Loader Class Initialized
DEBUG - 2012-10-03 15:40:17 --> Helper loaded: url_helper
DEBUG - 2012-10-03 15:40:17 --> Controller Class Initialized
DEBUG - 2012-10-03 15:40:17 --> Model Class Initialized
DEBUG - 2012-10-03 15:40:17 --> Database Driver Class Initialized
DEBUG - 2012-10-03 15:40:17 --> Final output sent to browser
DEBUG - 2012-10-03 15:40:17 --> Total execution time: 0.0974
DEBUG - 2012-10-03 15:40:28 --> Config Class Initialized
DEBUG - 2012-10-03 15:40:28 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:40:28 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:40:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:40:28 --> URI Class Initialized
DEBUG - 2012-10-03 15:40:28 --> Router Class Initialized
DEBUG - 2012-10-03 15:40:28 --> Output Class Initialized
DEBUG - 2012-10-03 15:40:28 --> Security Class Initialized
DEBUG - 2012-10-03 15:40:28 --> Input Class Initialized
DEBUG - 2012-10-03 15:40:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 15:40:28 --> Language Class Initialized
DEBUG - 2012-10-03 15:40:28 --> Loader Class Initialized
DEBUG - 2012-10-03 15:40:28 --> Helper loaded: url_helper
DEBUG - 2012-10-03 15:40:28 --> Controller Class Initialized
DEBUG - 2012-10-03 15:40:28 --> Model Class Initialized
DEBUG - 2012-10-03 15:40:28 --> Database Driver Class Initialized
DEBUG - 2012-10-03 15:40:28 --> Helper loaded: form_helper
DEBUG - 2012-10-03 15:40:28 --> Helper loaded: language_helper
DEBUG - 2012-10-03 15:40:28 --> Form Validation Class Initialized
DEBUG - 2012-10-03 15:40:28 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-03 15:40:28 --> Upload Class Initialized
DEBUG - 2012-10-03 15:40:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-03 15:40:28 --> Image Lib Class Initialized
DEBUG - 2012-10-03 15:40:28 --> Final output sent to browser
DEBUG - 2012-10-03 15:40:28 --> Total execution time: 0.1676
DEBUG - 2012-10-03 15:40:31 --> Config Class Initialized
DEBUG - 2012-10-03 15:40:31 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:40:31 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:40:31 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:40:31 --> URI Class Initialized
DEBUG - 2012-10-03 15:40:31 --> Router Class Initialized
DEBUG - 2012-10-03 15:40:31 --> Output Class Initialized
DEBUG - 2012-10-03 15:40:31 --> Security Class Initialized
DEBUG - 2012-10-03 15:40:31 --> Input Class Initialized
DEBUG - 2012-10-03 15:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 15:40:31 --> Language Class Initialized
DEBUG - 2012-10-03 15:40:31 --> Loader Class Initialized
DEBUG - 2012-10-03 15:40:31 --> Helper loaded: url_helper
DEBUG - 2012-10-03 15:40:31 --> Controller Class Initialized
DEBUG - 2012-10-03 15:40:31 --> Model Class Initialized
DEBUG - 2012-10-03 15:40:31 --> Database Driver Class Initialized
DEBUG - 2012-10-03 15:40:31 --> Final output sent to browser
DEBUG - 2012-10-03 15:40:31 --> Total execution time: 0.0963
DEBUG - 2012-10-03 15:45:49 --> Config Class Initialized
DEBUG - 2012-10-03 15:45:49 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:45:49 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:45:49 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:45:49 --> URI Class Initialized
DEBUG - 2012-10-03 15:45:49 --> Router Class Initialized
DEBUG - 2012-10-03 15:45:49 --> Output Class Initialized
DEBUG - 2012-10-03 15:45:49 --> Security Class Initialized
DEBUG - 2012-10-03 15:45:49 --> Input Class Initialized
DEBUG - 2012-10-03 15:45:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 15:45:49 --> Language Class Initialized
DEBUG - 2012-10-03 15:45:49 --> Loader Class Initialized
DEBUG - 2012-10-03 15:45:49 --> Helper loaded: url_helper
DEBUG - 2012-10-03 15:45:49 --> Controller Class Initialized
DEBUG - 2012-10-03 15:45:49 --> Model Class Initialized
DEBUG - 2012-10-03 15:45:49 --> Database Driver Class Initialized
DEBUG - 2012-10-03 15:45:49 --> Helper loaded: form_helper
DEBUG - 2012-10-03 15:45:49 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 15:45:49 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 15:45:49 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 15:45:49 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 15:45:49 --> Final output sent to browser
DEBUG - 2012-10-03 15:45:49 --> Total execution time: 0.0395
DEBUG - 2012-10-03 15:45:51 --> Config Class Initialized
DEBUG - 2012-10-03 15:45:51 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:45:51 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:45:51 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:45:51 --> URI Class Initialized
DEBUG - 2012-10-03 15:45:51 --> Router Class Initialized
ERROR - 2012-10-03 15:45:51 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 15:45:51 --> Config Class Initialized
DEBUG - 2012-10-03 15:45:51 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:45:51 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:45:51 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:45:51 --> URI Class Initialized
DEBUG - 2012-10-03 15:45:51 --> Router Class Initialized
ERROR - 2012-10-03 15:45:51 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 15:45:51 --> Config Class Initialized
DEBUG - 2012-10-03 15:45:51 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:45:51 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:45:51 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:45:51 --> URI Class Initialized
DEBUG - 2012-10-03 15:45:51 --> Router Class Initialized
ERROR - 2012-10-03 15:45:51 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 15:49:02 --> Config Class Initialized
DEBUG - 2012-10-03 15:49:02 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:49:02 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:49:02 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:49:02 --> URI Class Initialized
DEBUG - 2012-10-03 15:49:02 --> Router Class Initialized
DEBUG - 2012-10-03 15:49:02 --> Output Class Initialized
DEBUG - 2012-10-03 15:49:02 --> Security Class Initialized
DEBUG - 2012-10-03 15:49:02 --> Input Class Initialized
DEBUG - 2012-10-03 15:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 15:49:02 --> Language Class Initialized
DEBUG - 2012-10-03 15:49:02 --> Loader Class Initialized
DEBUG - 2012-10-03 15:49:02 --> Helper loaded: url_helper
DEBUG - 2012-10-03 15:49:02 --> Controller Class Initialized
DEBUG - 2012-10-03 15:49:02 --> Model Class Initialized
DEBUG - 2012-10-03 15:49:02 --> Database Driver Class Initialized
DEBUG - 2012-10-03 15:49:02 --> Helper loaded: form_helper
DEBUG - 2012-10-03 15:49:02 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 15:49:02 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 15:49:02 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 15:49:02 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 15:49:02 --> Final output sent to browser
DEBUG - 2012-10-03 15:49:02 --> Total execution time: 0.0405
DEBUG - 2012-10-03 15:49:04 --> Config Class Initialized
DEBUG - 2012-10-03 15:49:04 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:49:04 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:49:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:49:04 --> URI Class Initialized
DEBUG - 2012-10-03 15:49:04 --> Router Class Initialized
ERROR - 2012-10-03 15:49:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 15:49:04 --> Config Class Initialized
DEBUG - 2012-10-03 15:49:04 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:49:04 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:49:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:49:04 --> URI Class Initialized
DEBUG - 2012-10-03 15:49:04 --> Router Class Initialized
ERROR - 2012-10-03 15:49:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 15:49:04 --> Config Class Initialized
DEBUG - 2012-10-03 15:49:04 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:49:04 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:49:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:49:04 --> URI Class Initialized
DEBUG - 2012-10-03 15:49:04 --> Router Class Initialized
ERROR - 2012-10-03 15:49:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 15:50:28 --> Config Class Initialized
DEBUG - 2012-10-03 15:50:28 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:50:28 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:50:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:50:28 --> URI Class Initialized
DEBUG - 2012-10-03 15:50:28 --> Router Class Initialized
DEBUG - 2012-10-03 15:50:28 --> Output Class Initialized
DEBUG - 2012-10-03 15:50:28 --> Security Class Initialized
DEBUG - 2012-10-03 15:50:28 --> Input Class Initialized
DEBUG - 2012-10-03 15:50:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 15:50:28 --> Language Class Initialized
DEBUG - 2012-10-03 15:50:28 --> Loader Class Initialized
DEBUG - 2012-10-03 15:50:28 --> Helper loaded: url_helper
DEBUG - 2012-10-03 15:50:28 --> Controller Class Initialized
DEBUG - 2012-10-03 15:50:28 --> Model Class Initialized
DEBUG - 2012-10-03 15:50:28 --> Database Driver Class Initialized
DEBUG - 2012-10-03 15:50:28 --> Helper loaded: form_helper
DEBUG - 2012-10-03 15:50:28 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 15:50:28 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 15:50:28 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 15:50:28 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 15:50:28 --> Final output sent to browser
DEBUG - 2012-10-03 15:50:28 --> Total execution time: 0.0445
DEBUG - 2012-10-03 15:50:30 --> Config Class Initialized
DEBUG - 2012-10-03 15:50:30 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:50:30 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:50:30 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:50:30 --> URI Class Initialized
DEBUG - 2012-10-03 15:50:30 --> Router Class Initialized
ERROR - 2012-10-03 15:50:30 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 15:50:30 --> Config Class Initialized
DEBUG - 2012-10-03 15:50:30 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:50:30 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:50:30 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:50:30 --> URI Class Initialized
DEBUG - 2012-10-03 15:50:30 --> Router Class Initialized
ERROR - 2012-10-03 15:50:30 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 15:50:30 --> Config Class Initialized
DEBUG - 2012-10-03 15:50:30 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:50:30 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:50:30 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:50:30 --> URI Class Initialized
DEBUG - 2012-10-03 15:50:30 --> Router Class Initialized
ERROR - 2012-10-03 15:50:30 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 15:50:43 --> Config Class Initialized
DEBUG - 2012-10-03 15:50:43 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:50:43 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:50:43 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:50:43 --> URI Class Initialized
DEBUG - 2012-10-03 15:50:43 --> Router Class Initialized
DEBUG - 2012-10-03 15:50:43 --> Output Class Initialized
DEBUG - 2012-10-03 15:50:43 --> Security Class Initialized
DEBUG - 2012-10-03 15:50:43 --> Input Class Initialized
DEBUG - 2012-10-03 15:50:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 15:50:43 --> Language Class Initialized
DEBUG - 2012-10-03 15:50:43 --> Loader Class Initialized
DEBUG - 2012-10-03 15:50:43 --> Helper loaded: url_helper
DEBUG - 2012-10-03 15:50:43 --> Controller Class Initialized
DEBUG - 2012-10-03 15:50:43 --> Model Class Initialized
DEBUG - 2012-10-03 15:50:43 --> Database Driver Class Initialized
DEBUG - 2012-10-03 15:50:43 --> Helper loaded: form_helper
DEBUG - 2012-10-03 15:50:43 --> Helper loaded: language_helper
DEBUG - 2012-10-03 15:50:43 --> Form Validation Class Initialized
DEBUG - 2012-10-03 15:50:43 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-03 15:50:43 --> Upload Class Initialized
DEBUG - 2012-10-03 15:50:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-03 15:50:43 --> Image Lib Class Initialized
DEBUG - 2012-10-03 15:50:43 --> Final output sent to browser
DEBUG - 2012-10-03 15:50:43 --> Total execution time: 0.1251
DEBUG - 2012-10-03 15:51:15 --> Config Class Initialized
DEBUG - 2012-10-03 15:51:15 --> Hooks Class Initialized
DEBUG - 2012-10-03 15:51:15 --> Utf8 Class Initialized
DEBUG - 2012-10-03 15:51:15 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 15:51:15 --> URI Class Initialized
DEBUG - 2012-10-03 15:51:15 --> Router Class Initialized
DEBUG - 2012-10-03 15:51:15 --> Output Class Initialized
DEBUG - 2012-10-03 15:51:15 --> Security Class Initialized
DEBUG - 2012-10-03 15:51:15 --> Input Class Initialized
DEBUG - 2012-10-03 15:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 15:51:15 --> Language Class Initialized
DEBUG - 2012-10-03 15:51:15 --> Loader Class Initialized
DEBUG - 2012-10-03 15:51:15 --> Helper loaded: url_helper
DEBUG - 2012-10-03 15:51:15 --> Controller Class Initialized
DEBUG - 2012-10-03 15:51:15 --> Model Class Initialized
DEBUG - 2012-10-03 15:51:15 --> Database Driver Class Initialized
DEBUG - 2012-10-03 15:51:16 --> Final output sent to browser
DEBUG - 2012-10-03 15:51:16 --> Total execution time: 0.1655
DEBUG - 2012-10-03 16:15:54 --> Config Class Initialized
DEBUG - 2012-10-03 16:15:54 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:15:54 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:15:54 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:15:54 --> URI Class Initialized
DEBUG - 2012-10-03 16:15:54 --> Router Class Initialized
DEBUG - 2012-10-03 16:15:54 --> Output Class Initialized
DEBUG - 2012-10-03 16:15:54 --> Security Class Initialized
DEBUG - 2012-10-03 16:15:54 --> Input Class Initialized
DEBUG - 2012-10-03 16:15:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 16:15:54 --> Language Class Initialized
DEBUG - 2012-10-03 16:15:54 --> Loader Class Initialized
DEBUG - 2012-10-03 16:15:54 --> Helper loaded: url_helper
DEBUG - 2012-10-03 16:15:54 --> Controller Class Initialized
DEBUG - 2012-10-03 16:15:54 --> Model Class Initialized
DEBUG - 2012-10-03 16:15:54 --> Database Driver Class Initialized
DEBUG - 2012-10-03 16:15:54 --> Helper loaded: form_helper
DEBUG - 2012-10-03 16:15:54 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 16:15:54 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 16:15:54 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 16:15:54 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 16:15:54 --> Final output sent to browser
DEBUG - 2012-10-03 16:15:54 --> Total execution time: 0.0443
DEBUG - 2012-10-03 16:15:56 --> Config Class Initialized
DEBUG - 2012-10-03 16:15:56 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:15:56 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:15:56 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:15:56 --> URI Class Initialized
DEBUG - 2012-10-03 16:15:56 --> Router Class Initialized
ERROR - 2012-10-03 16:15:56 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:15:56 --> Config Class Initialized
DEBUG - 2012-10-03 16:15:56 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:15:56 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:15:56 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:15:56 --> URI Class Initialized
DEBUG - 2012-10-03 16:15:56 --> Router Class Initialized
ERROR - 2012-10-03 16:15:56 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:15:56 --> Config Class Initialized
DEBUG - 2012-10-03 16:15:56 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:15:56 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:15:56 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:15:56 --> URI Class Initialized
DEBUG - 2012-10-03 16:15:56 --> Router Class Initialized
ERROR - 2012-10-03 16:15:56 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:16:04 --> Config Class Initialized
DEBUG - 2012-10-03 16:16:04 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:16:04 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:16:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:16:04 --> URI Class Initialized
DEBUG - 2012-10-03 16:16:04 --> Router Class Initialized
DEBUG - 2012-10-03 16:16:04 --> Output Class Initialized
DEBUG - 2012-10-03 16:16:04 --> Security Class Initialized
DEBUG - 2012-10-03 16:16:04 --> Input Class Initialized
DEBUG - 2012-10-03 16:16:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 16:16:04 --> Language Class Initialized
DEBUG - 2012-10-03 16:16:04 --> Loader Class Initialized
DEBUG - 2012-10-03 16:16:04 --> Helper loaded: url_helper
DEBUG - 2012-10-03 16:16:04 --> Controller Class Initialized
DEBUG - 2012-10-03 16:16:04 --> Model Class Initialized
DEBUG - 2012-10-03 16:16:04 --> Database Driver Class Initialized
DEBUG - 2012-10-03 16:16:04 --> Helper loaded: form_helper
DEBUG - 2012-10-03 16:16:04 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 16:16:04 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 16:16:04 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 16:16:04 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 16:16:04 --> Final output sent to browser
DEBUG - 2012-10-03 16:16:04 --> Total execution time: 0.0456
DEBUG - 2012-10-03 16:16:06 --> Config Class Initialized
DEBUG - 2012-10-03 16:16:06 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:16:06 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:16:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:16:06 --> URI Class Initialized
DEBUG - 2012-10-03 16:16:06 --> Router Class Initialized
ERROR - 2012-10-03 16:16:06 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:16:06 --> Config Class Initialized
DEBUG - 2012-10-03 16:16:06 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:16:06 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:16:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:16:06 --> URI Class Initialized
DEBUG - 2012-10-03 16:16:06 --> Router Class Initialized
ERROR - 2012-10-03 16:16:06 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:16:06 --> Config Class Initialized
DEBUG - 2012-10-03 16:16:06 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:16:06 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:16:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:16:06 --> URI Class Initialized
DEBUG - 2012-10-03 16:16:06 --> Router Class Initialized
ERROR - 2012-10-03 16:16:06 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:17:24 --> Config Class Initialized
DEBUG - 2012-10-03 16:17:24 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:17:24 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:17:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:17:24 --> URI Class Initialized
DEBUG - 2012-10-03 16:17:24 --> Router Class Initialized
DEBUG - 2012-10-03 16:17:24 --> Output Class Initialized
DEBUG - 2012-10-03 16:17:24 --> Security Class Initialized
DEBUG - 2012-10-03 16:17:24 --> Input Class Initialized
DEBUG - 2012-10-03 16:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 16:17:24 --> Language Class Initialized
DEBUG - 2012-10-03 16:17:24 --> Loader Class Initialized
DEBUG - 2012-10-03 16:17:24 --> Helper loaded: url_helper
DEBUG - 2012-10-03 16:17:24 --> Controller Class Initialized
DEBUG - 2012-10-03 16:17:24 --> Model Class Initialized
DEBUG - 2012-10-03 16:17:24 --> Database Driver Class Initialized
DEBUG - 2012-10-03 16:17:24 --> Helper loaded: form_helper
DEBUG - 2012-10-03 16:17:24 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 16:17:24 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 16:17:24 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 16:17:24 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 16:17:24 --> Final output sent to browser
DEBUG - 2012-10-03 16:17:24 --> Total execution time: 0.0436
DEBUG - 2012-10-03 16:17:25 --> Config Class Initialized
DEBUG - 2012-10-03 16:17:25 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:17:25 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:17:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:17:25 --> URI Class Initialized
DEBUG - 2012-10-03 16:17:25 --> Router Class Initialized
ERROR - 2012-10-03 16:17:25 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:17:26 --> Config Class Initialized
DEBUG - 2012-10-03 16:17:26 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:17:26 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:17:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:17:26 --> URI Class Initialized
DEBUG - 2012-10-03 16:17:26 --> Router Class Initialized
ERROR - 2012-10-03 16:17:26 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:17:26 --> Config Class Initialized
DEBUG - 2012-10-03 16:17:26 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:17:26 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:17:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:17:26 --> URI Class Initialized
DEBUG - 2012-10-03 16:17:26 --> Router Class Initialized
ERROR - 2012-10-03 16:17:26 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:20:20 --> Config Class Initialized
DEBUG - 2012-10-03 16:20:20 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:20:20 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:20:20 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:20:20 --> URI Class Initialized
DEBUG - 2012-10-03 16:20:20 --> Router Class Initialized
DEBUG - 2012-10-03 16:20:20 --> Output Class Initialized
DEBUG - 2012-10-03 16:20:20 --> Security Class Initialized
DEBUG - 2012-10-03 16:20:20 --> Input Class Initialized
DEBUG - 2012-10-03 16:20:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 16:20:20 --> Language Class Initialized
DEBUG - 2012-10-03 16:20:20 --> Loader Class Initialized
DEBUG - 2012-10-03 16:20:20 --> Helper loaded: url_helper
DEBUG - 2012-10-03 16:20:20 --> Controller Class Initialized
DEBUG - 2012-10-03 16:20:20 --> Model Class Initialized
DEBUG - 2012-10-03 16:20:20 --> Database Driver Class Initialized
DEBUG - 2012-10-03 16:20:20 --> Helper loaded: form_helper
DEBUG - 2012-10-03 16:20:20 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 16:20:20 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 16:20:20 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 16:20:20 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 16:20:20 --> Final output sent to browser
DEBUG - 2012-10-03 16:20:20 --> Total execution time: 0.0409
DEBUG - 2012-10-03 16:20:22 --> Config Class Initialized
DEBUG - 2012-10-03 16:20:22 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:20:22 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:20:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:20:22 --> URI Class Initialized
DEBUG - 2012-10-03 16:20:22 --> Router Class Initialized
ERROR - 2012-10-03 16:20:22 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:20:22 --> Config Class Initialized
DEBUG - 2012-10-03 16:20:22 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:20:22 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:20:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:20:22 --> URI Class Initialized
DEBUG - 2012-10-03 16:20:22 --> Router Class Initialized
ERROR - 2012-10-03 16:20:22 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:20:22 --> Config Class Initialized
DEBUG - 2012-10-03 16:20:22 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:20:22 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:20:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:20:22 --> URI Class Initialized
DEBUG - 2012-10-03 16:20:22 --> Router Class Initialized
ERROR - 2012-10-03 16:20:22 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:23:11 --> Config Class Initialized
DEBUG - 2012-10-03 16:23:11 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:23:11 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:23:11 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:23:11 --> URI Class Initialized
DEBUG - 2012-10-03 16:23:11 --> Router Class Initialized
DEBUG - 2012-10-03 16:23:11 --> Output Class Initialized
DEBUG - 2012-10-03 16:23:11 --> Security Class Initialized
DEBUG - 2012-10-03 16:23:11 --> Input Class Initialized
DEBUG - 2012-10-03 16:23:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 16:23:11 --> Language Class Initialized
DEBUG - 2012-10-03 16:23:11 --> Loader Class Initialized
DEBUG - 2012-10-03 16:23:11 --> Helper loaded: url_helper
DEBUG - 2012-10-03 16:23:11 --> Controller Class Initialized
DEBUG - 2012-10-03 16:23:11 --> Model Class Initialized
DEBUG - 2012-10-03 16:23:11 --> Database Driver Class Initialized
DEBUG - 2012-10-03 16:23:11 --> Helper loaded: form_helper
DEBUG - 2012-10-03 16:23:11 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 16:23:11 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 16:23:11 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 16:23:11 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 16:23:11 --> Final output sent to browser
DEBUG - 2012-10-03 16:23:11 --> Total execution time: 0.0403
DEBUG - 2012-10-03 16:23:13 --> Config Class Initialized
DEBUG - 2012-10-03 16:23:13 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:23:13 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:23:13 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:23:13 --> URI Class Initialized
DEBUG - 2012-10-03 16:23:13 --> Router Class Initialized
ERROR - 2012-10-03 16:23:13 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:23:13 --> Config Class Initialized
DEBUG - 2012-10-03 16:23:13 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:23:13 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:23:13 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:23:13 --> URI Class Initialized
DEBUG - 2012-10-03 16:23:13 --> Router Class Initialized
ERROR - 2012-10-03 16:23:13 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:23:13 --> Config Class Initialized
DEBUG - 2012-10-03 16:23:13 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:23:13 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:23:13 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:23:13 --> URI Class Initialized
DEBUG - 2012-10-03 16:23:13 --> Router Class Initialized
ERROR - 2012-10-03 16:23:13 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:23:52 --> Config Class Initialized
DEBUG - 2012-10-03 16:23:52 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:23:52 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:23:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:23:52 --> URI Class Initialized
DEBUG - 2012-10-03 16:23:52 --> Router Class Initialized
DEBUG - 2012-10-03 16:23:52 --> Output Class Initialized
DEBUG - 2012-10-03 16:23:52 --> Security Class Initialized
DEBUG - 2012-10-03 16:23:52 --> Input Class Initialized
DEBUG - 2012-10-03 16:23:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 16:23:52 --> Language Class Initialized
DEBUG - 2012-10-03 16:23:52 --> Loader Class Initialized
DEBUG - 2012-10-03 16:23:52 --> Helper loaded: url_helper
DEBUG - 2012-10-03 16:23:52 --> Controller Class Initialized
DEBUG - 2012-10-03 16:23:52 --> Model Class Initialized
DEBUG - 2012-10-03 16:23:52 --> Database Driver Class Initialized
DEBUG - 2012-10-03 16:23:52 --> Helper loaded: form_helper
DEBUG - 2012-10-03 16:23:52 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 16:23:52 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 16:23:52 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 16:23:52 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 16:23:52 --> Final output sent to browser
DEBUG - 2012-10-03 16:23:52 --> Total execution time: 0.0393
DEBUG - 2012-10-03 16:23:54 --> Config Class Initialized
DEBUG - 2012-10-03 16:23:54 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:23:54 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:23:54 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:23:54 --> URI Class Initialized
DEBUG - 2012-10-03 16:23:54 --> Router Class Initialized
ERROR - 2012-10-03 16:23:54 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:23:54 --> Config Class Initialized
DEBUG - 2012-10-03 16:23:54 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:23:54 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:23:54 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:23:54 --> URI Class Initialized
DEBUG - 2012-10-03 16:23:54 --> Router Class Initialized
ERROR - 2012-10-03 16:23:54 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:23:54 --> Config Class Initialized
DEBUG - 2012-10-03 16:23:54 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:23:54 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:23:54 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:23:54 --> URI Class Initialized
DEBUG - 2012-10-03 16:23:54 --> Router Class Initialized
ERROR - 2012-10-03 16:23:54 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:25:11 --> Config Class Initialized
DEBUG - 2012-10-03 16:25:11 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:25:11 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:25:11 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:25:11 --> URI Class Initialized
DEBUG - 2012-10-03 16:25:11 --> Router Class Initialized
DEBUG - 2012-10-03 16:25:11 --> Output Class Initialized
DEBUG - 2012-10-03 16:25:11 --> Security Class Initialized
DEBUG - 2012-10-03 16:25:11 --> Input Class Initialized
DEBUG - 2012-10-03 16:25:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 16:25:11 --> Language Class Initialized
DEBUG - 2012-10-03 16:25:11 --> Loader Class Initialized
DEBUG - 2012-10-03 16:25:11 --> Helper loaded: url_helper
DEBUG - 2012-10-03 16:25:11 --> Controller Class Initialized
DEBUG - 2012-10-03 16:25:11 --> Model Class Initialized
DEBUG - 2012-10-03 16:25:11 --> Database Driver Class Initialized
DEBUG - 2012-10-03 16:25:11 --> Helper loaded: form_helper
DEBUG - 2012-10-03 16:25:11 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 16:25:11 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 16:25:11 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 16:25:11 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 16:25:11 --> Final output sent to browser
DEBUG - 2012-10-03 16:25:11 --> Total execution time: 0.0395
DEBUG - 2012-10-03 16:25:13 --> Config Class Initialized
DEBUG - 2012-10-03 16:25:13 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:25:13 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:25:13 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:25:13 --> URI Class Initialized
DEBUG - 2012-10-03 16:25:13 --> Router Class Initialized
ERROR - 2012-10-03 16:25:13 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:25:13 --> Config Class Initialized
DEBUG - 2012-10-03 16:25:13 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:25:13 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:25:13 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:25:13 --> URI Class Initialized
DEBUG - 2012-10-03 16:25:13 --> Router Class Initialized
ERROR - 2012-10-03 16:25:13 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:25:13 --> Config Class Initialized
DEBUG - 2012-10-03 16:25:13 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:25:13 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:25:13 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:25:13 --> URI Class Initialized
DEBUG - 2012-10-03 16:25:13 --> Router Class Initialized
ERROR - 2012-10-03 16:25:13 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:25:22 --> Config Class Initialized
DEBUG - 2012-10-03 16:25:22 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:25:22 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:25:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:25:22 --> URI Class Initialized
DEBUG - 2012-10-03 16:25:22 --> Router Class Initialized
DEBUG - 2012-10-03 16:25:22 --> Output Class Initialized
DEBUG - 2012-10-03 16:25:22 --> Security Class Initialized
DEBUG - 2012-10-03 16:25:22 --> Input Class Initialized
DEBUG - 2012-10-03 16:25:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 16:25:22 --> Language Class Initialized
DEBUG - 2012-10-03 16:25:22 --> Loader Class Initialized
DEBUG - 2012-10-03 16:25:22 --> Helper loaded: url_helper
DEBUG - 2012-10-03 16:25:22 --> Controller Class Initialized
DEBUG - 2012-10-03 16:25:22 --> Model Class Initialized
DEBUG - 2012-10-03 16:25:22 --> Database Driver Class Initialized
DEBUG - 2012-10-03 16:25:22 --> Helper loaded: form_helper
DEBUG - 2012-10-03 16:25:22 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 16:25:22 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 16:25:22 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 16:25:22 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 16:25:22 --> Final output sent to browser
DEBUG - 2012-10-03 16:25:22 --> Total execution time: 0.0457
DEBUG - 2012-10-03 16:25:24 --> Config Class Initialized
DEBUG - 2012-10-03 16:25:24 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:25:24 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:25:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:25:24 --> URI Class Initialized
DEBUG - 2012-10-03 16:25:24 --> Router Class Initialized
ERROR - 2012-10-03 16:25:24 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:25:24 --> Config Class Initialized
DEBUG - 2012-10-03 16:25:24 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:25:24 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:25:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:25:24 --> URI Class Initialized
DEBUG - 2012-10-03 16:25:24 --> Router Class Initialized
ERROR - 2012-10-03 16:25:24 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:25:24 --> Config Class Initialized
DEBUG - 2012-10-03 16:25:24 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:25:24 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:25:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:25:24 --> URI Class Initialized
DEBUG - 2012-10-03 16:25:24 --> Router Class Initialized
ERROR - 2012-10-03 16:25:24 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:25:28 --> Config Class Initialized
DEBUG - 2012-10-03 16:25:28 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:25:28 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:25:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:25:28 --> URI Class Initialized
DEBUG - 2012-10-03 16:25:28 --> Router Class Initialized
DEBUG - 2012-10-03 16:25:28 --> Output Class Initialized
DEBUG - 2012-10-03 16:25:28 --> Security Class Initialized
DEBUG - 2012-10-03 16:25:28 --> Input Class Initialized
DEBUG - 2012-10-03 16:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 16:25:28 --> Language Class Initialized
DEBUG - 2012-10-03 16:25:28 --> Loader Class Initialized
DEBUG - 2012-10-03 16:25:28 --> Helper loaded: url_helper
DEBUG - 2012-10-03 16:25:28 --> Controller Class Initialized
DEBUG - 2012-10-03 16:25:28 --> Model Class Initialized
DEBUG - 2012-10-03 16:25:28 --> Database Driver Class Initialized
DEBUG - 2012-10-03 16:25:28 --> Helper loaded: form_helper
DEBUG - 2012-10-03 16:25:28 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 16:25:28 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 16:25:28 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 16:25:28 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 16:25:28 --> Final output sent to browser
DEBUG - 2012-10-03 16:25:28 --> Total execution time: 0.0466
DEBUG - 2012-10-03 16:25:37 --> Config Class Initialized
DEBUG - 2012-10-03 16:25:37 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:25:37 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:25:37 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:25:37 --> URI Class Initialized
DEBUG - 2012-10-03 16:25:37 --> Router Class Initialized
DEBUG - 2012-10-03 16:25:37 --> Output Class Initialized
DEBUG - 2012-10-03 16:25:37 --> Security Class Initialized
DEBUG - 2012-10-03 16:25:37 --> Input Class Initialized
DEBUG - 2012-10-03 16:25:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 16:25:37 --> Language Class Initialized
DEBUG - 2012-10-03 16:25:37 --> Loader Class Initialized
DEBUG - 2012-10-03 16:25:37 --> Helper loaded: url_helper
DEBUG - 2012-10-03 16:25:37 --> Controller Class Initialized
DEBUG - 2012-10-03 16:25:37 --> Model Class Initialized
DEBUG - 2012-10-03 16:25:37 --> Database Driver Class Initialized
DEBUG - 2012-10-03 16:25:37 --> Helper loaded: form_helper
DEBUG - 2012-10-03 16:25:37 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 16:25:37 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 16:25:37 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 16:25:37 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 16:25:37 --> Final output sent to browser
DEBUG - 2012-10-03 16:25:37 --> Total execution time: 0.0397
DEBUG - 2012-10-03 16:25:39 --> Config Class Initialized
DEBUG - 2012-10-03 16:25:39 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:25:39 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:25:39 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:25:39 --> URI Class Initialized
DEBUG - 2012-10-03 16:25:39 --> Router Class Initialized
ERROR - 2012-10-03 16:25:39 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:25:39 --> Config Class Initialized
DEBUG - 2012-10-03 16:25:39 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:25:39 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:25:39 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:25:39 --> URI Class Initialized
DEBUG - 2012-10-03 16:25:39 --> Router Class Initialized
ERROR - 2012-10-03 16:25:39 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:25:39 --> Config Class Initialized
DEBUG - 2012-10-03 16:25:39 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:25:39 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:25:39 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:25:39 --> URI Class Initialized
DEBUG - 2012-10-03 16:25:39 --> Router Class Initialized
ERROR - 2012-10-03 16:25:39 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:26:49 --> Config Class Initialized
DEBUG - 2012-10-03 16:26:49 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:26:49 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:26:49 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:26:49 --> URI Class Initialized
DEBUG - 2012-10-03 16:26:49 --> Router Class Initialized
DEBUG - 2012-10-03 16:26:49 --> Output Class Initialized
DEBUG - 2012-10-03 16:26:49 --> Security Class Initialized
DEBUG - 2012-10-03 16:26:49 --> Input Class Initialized
DEBUG - 2012-10-03 16:26:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 16:26:49 --> Language Class Initialized
DEBUG - 2012-10-03 16:26:49 --> Loader Class Initialized
DEBUG - 2012-10-03 16:26:49 --> Helper loaded: url_helper
DEBUG - 2012-10-03 16:26:49 --> Controller Class Initialized
DEBUG - 2012-10-03 16:26:49 --> Model Class Initialized
DEBUG - 2012-10-03 16:26:49 --> Database Driver Class Initialized
DEBUG - 2012-10-03 16:26:49 --> Helper loaded: form_helper
DEBUG - 2012-10-03 16:26:49 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 16:26:49 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 16:26:49 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 16:26:49 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 16:26:49 --> Final output sent to browser
DEBUG - 2012-10-03 16:26:49 --> Total execution time: 0.0442
DEBUG - 2012-10-03 16:26:51 --> Config Class Initialized
DEBUG - 2012-10-03 16:26:51 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:26:51 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:26:51 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:26:51 --> URI Class Initialized
DEBUG - 2012-10-03 16:26:51 --> Router Class Initialized
ERROR - 2012-10-03 16:26:51 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:26:51 --> Config Class Initialized
DEBUG - 2012-10-03 16:26:51 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:26:51 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:26:51 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:26:51 --> URI Class Initialized
DEBUG - 2012-10-03 16:26:51 --> Router Class Initialized
ERROR - 2012-10-03 16:26:51 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:26:51 --> Config Class Initialized
DEBUG - 2012-10-03 16:26:51 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:26:51 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:26:51 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:26:51 --> URI Class Initialized
DEBUG - 2012-10-03 16:26:51 --> Router Class Initialized
ERROR - 2012-10-03 16:26:51 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:27:02 --> Config Class Initialized
DEBUG - 2012-10-03 16:27:02 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:27:02 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:27:02 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:27:02 --> URI Class Initialized
DEBUG - 2012-10-03 16:27:02 --> Router Class Initialized
DEBUG - 2012-10-03 16:27:02 --> Output Class Initialized
DEBUG - 2012-10-03 16:27:02 --> Security Class Initialized
DEBUG - 2012-10-03 16:27:02 --> Input Class Initialized
DEBUG - 2012-10-03 16:27:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 16:27:02 --> Language Class Initialized
DEBUG - 2012-10-03 16:27:02 --> Loader Class Initialized
DEBUG - 2012-10-03 16:27:02 --> Helper loaded: url_helper
DEBUG - 2012-10-03 16:27:02 --> Controller Class Initialized
DEBUG - 2012-10-03 16:27:02 --> Model Class Initialized
DEBUG - 2012-10-03 16:27:02 --> Database Driver Class Initialized
DEBUG - 2012-10-03 16:27:02 --> Helper loaded: form_helper
DEBUG - 2012-10-03 16:27:02 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 16:27:02 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 16:27:02 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 16:27:02 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 16:27:02 --> Final output sent to browser
DEBUG - 2012-10-03 16:27:02 --> Total execution time: 0.0416
DEBUG - 2012-10-03 16:27:04 --> Config Class Initialized
DEBUG - 2012-10-03 16:27:04 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:27:04 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:27:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:27:04 --> URI Class Initialized
DEBUG - 2012-10-03 16:27:04 --> Router Class Initialized
ERROR - 2012-10-03 16:27:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:27:04 --> Config Class Initialized
DEBUG - 2012-10-03 16:27:04 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:27:04 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:27:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:27:04 --> URI Class Initialized
DEBUG - 2012-10-03 16:27:04 --> Router Class Initialized
ERROR - 2012-10-03 16:27:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:27:04 --> Config Class Initialized
DEBUG - 2012-10-03 16:27:04 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:27:04 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:27:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:27:04 --> URI Class Initialized
DEBUG - 2012-10-03 16:27:04 --> Router Class Initialized
ERROR - 2012-10-03 16:27:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:29:48 --> Config Class Initialized
DEBUG - 2012-10-03 16:29:48 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:29:48 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:29:48 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:29:48 --> URI Class Initialized
DEBUG - 2012-10-03 16:29:48 --> Router Class Initialized
DEBUG - 2012-10-03 16:29:48 --> Output Class Initialized
DEBUG - 2012-10-03 16:29:48 --> Security Class Initialized
DEBUG - 2012-10-03 16:29:48 --> Input Class Initialized
DEBUG - 2012-10-03 16:29:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 16:29:48 --> Language Class Initialized
DEBUG - 2012-10-03 16:29:48 --> Loader Class Initialized
DEBUG - 2012-10-03 16:29:48 --> Helper loaded: url_helper
DEBUG - 2012-10-03 16:29:48 --> Controller Class Initialized
DEBUG - 2012-10-03 16:29:48 --> Model Class Initialized
DEBUG - 2012-10-03 16:29:48 --> Database Driver Class Initialized
DEBUG - 2012-10-03 16:29:48 --> Helper loaded: form_helper
DEBUG - 2012-10-03 16:29:48 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 16:29:48 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 16:29:48 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 16:29:48 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 16:29:48 --> Final output sent to browser
DEBUG - 2012-10-03 16:29:48 --> Total execution time: 0.0457
DEBUG - 2012-10-03 16:29:50 --> Config Class Initialized
DEBUG - 2012-10-03 16:29:50 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:29:50 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:29:50 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:29:50 --> URI Class Initialized
DEBUG - 2012-10-03 16:29:50 --> Router Class Initialized
ERROR - 2012-10-03 16:29:50 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:29:50 --> Config Class Initialized
DEBUG - 2012-10-03 16:29:50 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:29:50 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:29:50 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:29:50 --> URI Class Initialized
DEBUG - 2012-10-03 16:29:50 --> Router Class Initialized
ERROR - 2012-10-03 16:29:50 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:29:50 --> Config Class Initialized
DEBUG - 2012-10-03 16:29:50 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:29:50 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:29:50 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:29:50 --> URI Class Initialized
DEBUG - 2012-10-03 16:29:50 --> Router Class Initialized
ERROR - 2012-10-03 16:29:50 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:30:18 --> Config Class Initialized
DEBUG - 2012-10-03 16:30:18 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:30:18 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:30:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:30:18 --> URI Class Initialized
DEBUG - 2012-10-03 16:30:18 --> Router Class Initialized
DEBUG - 2012-10-03 16:30:18 --> Output Class Initialized
DEBUG - 2012-10-03 16:30:18 --> Security Class Initialized
DEBUG - 2012-10-03 16:30:18 --> Input Class Initialized
DEBUG - 2012-10-03 16:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 16:30:18 --> Language Class Initialized
DEBUG - 2012-10-03 16:30:18 --> Loader Class Initialized
DEBUG - 2012-10-03 16:30:18 --> Helper loaded: url_helper
DEBUG - 2012-10-03 16:30:18 --> Controller Class Initialized
DEBUG - 2012-10-03 16:30:18 --> Model Class Initialized
DEBUG - 2012-10-03 16:30:18 --> Database Driver Class Initialized
DEBUG - 2012-10-03 16:30:18 --> Helper loaded: form_helper
DEBUG - 2012-10-03 16:30:18 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 16:30:18 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 16:30:18 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 16:30:18 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 16:30:18 --> Final output sent to browser
DEBUG - 2012-10-03 16:30:18 --> Total execution time: 0.0392
DEBUG - 2012-10-03 16:46:02 --> Config Class Initialized
DEBUG - 2012-10-03 16:46:02 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:46:02 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:46:02 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:46:02 --> URI Class Initialized
DEBUG - 2012-10-03 16:46:02 --> Router Class Initialized
DEBUG - 2012-10-03 16:46:02 --> Output Class Initialized
DEBUG - 2012-10-03 16:46:02 --> Security Class Initialized
DEBUG - 2012-10-03 16:46:02 --> Input Class Initialized
DEBUG - 2012-10-03 16:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 16:46:02 --> Language Class Initialized
DEBUG - 2012-10-03 16:46:02 --> Loader Class Initialized
DEBUG - 2012-10-03 16:46:02 --> Helper loaded: url_helper
DEBUG - 2012-10-03 16:46:02 --> Controller Class Initialized
DEBUG - 2012-10-03 16:46:02 --> Model Class Initialized
DEBUG - 2012-10-03 16:46:02 --> Database Driver Class Initialized
DEBUG - 2012-10-03 16:46:02 --> Helper loaded: form_helper
DEBUG - 2012-10-03 16:46:02 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 16:46:02 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 16:46:02 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 16:46:02 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 16:46:02 --> Final output sent to browser
DEBUG - 2012-10-03 16:46:02 --> Total execution time: 0.0391
DEBUG - 2012-10-03 16:46:04 --> Config Class Initialized
DEBUG - 2012-10-03 16:46:04 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:46:04 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:46:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:46:04 --> URI Class Initialized
DEBUG - 2012-10-03 16:46:04 --> Router Class Initialized
ERROR - 2012-10-03 16:46:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:46:04 --> Config Class Initialized
DEBUG - 2012-10-03 16:46:04 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:46:04 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:46:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:46:04 --> URI Class Initialized
DEBUG - 2012-10-03 16:46:04 --> Router Class Initialized
ERROR - 2012-10-03 16:46:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:46:04 --> Config Class Initialized
DEBUG - 2012-10-03 16:46:04 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:46:04 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:46:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:46:04 --> URI Class Initialized
DEBUG - 2012-10-03 16:46:04 --> Router Class Initialized
ERROR - 2012-10-03 16:46:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:46:11 --> Config Class Initialized
DEBUG - 2012-10-03 16:46:11 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:46:11 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:46:11 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:46:11 --> URI Class Initialized
DEBUG - 2012-10-03 16:46:11 --> Router Class Initialized
DEBUG - 2012-10-03 16:46:11 --> Output Class Initialized
DEBUG - 2012-10-03 16:46:11 --> Security Class Initialized
DEBUG - 2012-10-03 16:46:11 --> Input Class Initialized
DEBUG - 2012-10-03 16:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 16:46:11 --> Language Class Initialized
DEBUG - 2012-10-03 16:46:11 --> Loader Class Initialized
DEBUG - 2012-10-03 16:46:11 --> Helper loaded: url_helper
DEBUG - 2012-10-03 16:46:11 --> Controller Class Initialized
DEBUG - 2012-10-03 16:46:11 --> Model Class Initialized
DEBUG - 2012-10-03 16:46:11 --> Database Driver Class Initialized
DEBUG - 2012-10-03 16:46:11 --> Helper loaded: form_helper
DEBUG - 2012-10-03 16:46:11 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 16:46:11 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 16:46:11 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 16:46:11 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 16:46:11 --> Final output sent to browser
DEBUG - 2012-10-03 16:46:11 --> Total execution time: 0.0390
DEBUG - 2012-10-03 16:47:23 --> Config Class Initialized
DEBUG - 2012-10-03 16:47:23 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:47:23 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:47:23 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:47:23 --> URI Class Initialized
DEBUG - 2012-10-03 16:47:23 --> Router Class Initialized
DEBUG - 2012-10-03 16:47:23 --> Output Class Initialized
DEBUG - 2012-10-03 16:47:23 --> Security Class Initialized
DEBUG - 2012-10-03 16:47:23 --> Input Class Initialized
DEBUG - 2012-10-03 16:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 16:47:23 --> Language Class Initialized
DEBUG - 2012-10-03 16:47:23 --> Loader Class Initialized
DEBUG - 2012-10-03 16:47:23 --> Helper loaded: url_helper
DEBUG - 2012-10-03 16:47:23 --> Controller Class Initialized
DEBUG - 2012-10-03 16:47:23 --> Model Class Initialized
DEBUG - 2012-10-03 16:47:23 --> Database Driver Class Initialized
DEBUG - 2012-10-03 16:47:23 --> Helper loaded: form_helper
DEBUG - 2012-10-03 16:47:23 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 16:47:23 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 16:47:23 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 16:47:23 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 16:47:23 --> Final output sent to browser
DEBUG - 2012-10-03 16:47:23 --> Total execution time: 0.0504
DEBUG - 2012-10-03 16:47:50 --> Config Class Initialized
DEBUG - 2012-10-03 16:47:50 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:47:50 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:47:50 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:47:50 --> URI Class Initialized
DEBUG - 2012-10-03 16:47:50 --> Router Class Initialized
DEBUG - 2012-10-03 16:47:50 --> Output Class Initialized
DEBUG - 2012-10-03 16:47:50 --> Security Class Initialized
DEBUG - 2012-10-03 16:47:50 --> Input Class Initialized
DEBUG - 2012-10-03 16:47:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 16:47:50 --> Language Class Initialized
DEBUG - 2012-10-03 16:47:50 --> Loader Class Initialized
DEBUG - 2012-10-03 16:47:50 --> Helper loaded: url_helper
DEBUG - 2012-10-03 16:47:50 --> Controller Class Initialized
DEBUG - 2012-10-03 16:47:50 --> Model Class Initialized
DEBUG - 2012-10-03 16:47:50 --> Database Driver Class Initialized
DEBUG - 2012-10-03 16:47:50 --> Helper loaded: form_helper
DEBUG - 2012-10-03 16:47:50 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 16:47:50 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 16:47:50 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 16:47:50 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 16:47:50 --> Final output sent to browser
DEBUG - 2012-10-03 16:47:50 --> Total execution time: 0.0399
DEBUG - 2012-10-03 16:47:52 --> Config Class Initialized
DEBUG - 2012-10-03 16:47:52 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:47:52 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:47:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:47:52 --> URI Class Initialized
DEBUG - 2012-10-03 16:47:52 --> Router Class Initialized
ERROR - 2012-10-03 16:47:52 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:47:52 --> Config Class Initialized
DEBUG - 2012-10-03 16:47:52 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:47:52 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:47:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:47:52 --> URI Class Initialized
DEBUG - 2012-10-03 16:47:52 --> Router Class Initialized
ERROR - 2012-10-03 16:47:52 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:47:52 --> Config Class Initialized
DEBUG - 2012-10-03 16:47:52 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:47:52 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:47:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:47:52 --> URI Class Initialized
DEBUG - 2012-10-03 16:47:52 --> Router Class Initialized
ERROR - 2012-10-03 16:47:52 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:47:55 --> Config Class Initialized
DEBUG - 2012-10-03 16:47:55 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:47:55 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:47:55 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:47:55 --> URI Class Initialized
DEBUG - 2012-10-03 16:47:55 --> Router Class Initialized
DEBUG - 2012-10-03 16:47:55 --> Output Class Initialized
DEBUG - 2012-10-03 16:47:55 --> Security Class Initialized
DEBUG - 2012-10-03 16:47:55 --> Input Class Initialized
DEBUG - 2012-10-03 16:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 16:47:55 --> Language Class Initialized
DEBUG - 2012-10-03 16:47:55 --> Loader Class Initialized
DEBUG - 2012-10-03 16:47:55 --> Helper loaded: url_helper
DEBUG - 2012-10-03 16:47:55 --> Controller Class Initialized
DEBUG - 2012-10-03 16:47:55 --> Model Class Initialized
DEBUG - 2012-10-03 16:47:55 --> Database Driver Class Initialized
DEBUG - 2012-10-03 16:47:55 --> Final output sent to browser
DEBUG - 2012-10-03 16:47:55 --> Total execution time: 0.1151
DEBUG - 2012-10-03 16:47:59 --> Config Class Initialized
DEBUG - 2012-10-03 16:47:59 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:47:59 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:47:59 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:47:59 --> URI Class Initialized
DEBUG - 2012-10-03 16:47:59 --> Router Class Initialized
DEBUG - 2012-10-03 16:47:59 --> Output Class Initialized
DEBUG - 2012-10-03 16:47:59 --> Security Class Initialized
DEBUG - 2012-10-03 16:47:59 --> Input Class Initialized
DEBUG - 2012-10-03 16:47:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 16:47:59 --> Language Class Initialized
DEBUG - 2012-10-03 16:47:59 --> Loader Class Initialized
DEBUG - 2012-10-03 16:47:59 --> Helper loaded: url_helper
DEBUG - 2012-10-03 16:47:59 --> Controller Class Initialized
DEBUG - 2012-10-03 16:47:59 --> Model Class Initialized
DEBUG - 2012-10-03 16:47:59 --> Database Driver Class Initialized
DEBUG - 2012-10-03 16:48:00 --> Final output sent to browser
DEBUG - 2012-10-03 16:48:00 --> Total execution time: 0.2773
DEBUG - 2012-10-03 16:50:12 --> Config Class Initialized
DEBUG - 2012-10-03 16:50:12 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:50:12 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:50:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:50:12 --> URI Class Initialized
DEBUG - 2012-10-03 16:50:12 --> Router Class Initialized
DEBUG - 2012-10-03 16:50:12 --> Output Class Initialized
DEBUG - 2012-10-03 16:50:12 --> Security Class Initialized
DEBUG - 2012-10-03 16:50:12 --> Input Class Initialized
DEBUG - 2012-10-03 16:50:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 16:50:12 --> Language Class Initialized
DEBUG - 2012-10-03 16:50:12 --> Loader Class Initialized
DEBUG - 2012-10-03 16:50:12 --> Helper loaded: url_helper
DEBUG - 2012-10-03 16:50:12 --> Controller Class Initialized
DEBUG - 2012-10-03 16:50:12 --> Model Class Initialized
DEBUG - 2012-10-03 16:50:12 --> Database Driver Class Initialized
DEBUG - 2012-10-03 16:50:12 --> Helper loaded: form_helper
DEBUG - 2012-10-03 16:50:12 --> Helper loaded: language_helper
DEBUG - 2012-10-03 16:50:12 --> Form Validation Class Initialized
DEBUG - 2012-10-03 16:50:12 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-03 16:50:12 --> Upload Class Initialized
DEBUG - 2012-10-03 16:50:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-03 16:50:12 --> Image Lib Class Initialized
DEBUG - 2012-10-03 16:50:12 --> Final output sent to browser
DEBUG - 2012-10-03 16:50:12 --> Total execution time: 0.3376
DEBUG - 2012-10-03 16:55:46 --> Config Class Initialized
DEBUG - 2012-10-03 16:55:46 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:55:46 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:55:46 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:55:46 --> URI Class Initialized
DEBUG - 2012-10-03 16:55:46 --> Router Class Initialized
DEBUG - 2012-10-03 16:55:46 --> Output Class Initialized
DEBUG - 2012-10-03 16:55:46 --> Security Class Initialized
DEBUG - 2012-10-03 16:55:46 --> Input Class Initialized
DEBUG - 2012-10-03 16:55:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 16:55:46 --> Language Class Initialized
DEBUG - 2012-10-03 16:55:46 --> Loader Class Initialized
DEBUG - 2012-10-03 16:55:46 --> Helper loaded: url_helper
DEBUG - 2012-10-03 16:55:46 --> Controller Class Initialized
DEBUG - 2012-10-03 16:55:46 --> Model Class Initialized
DEBUG - 2012-10-03 16:55:46 --> Database Driver Class Initialized
DEBUG - 2012-10-03 16:55:46 --> Helper loaded: form_helper
DEBUG - 2012-10-03 16:55:46 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 16:55:46 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 16:55:46 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 16:55:46 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 16:55:46 --> Final output sent to browser
DEBUG - 2012-10-03 16:55:46 --> Total execution time: 0.0447
DEBUG - 2012-10-03 16:55:48 --> Config Class Initialized
DEBUG - 2012-10-03 16:55:48 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:55:48 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:55:48 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:55:48 --> URI Class Initialized
DEBUG - 2012-10-03 16:55:48 --> Router Class Initialized
ERROR - 2012-10-03 16:55:48 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:55:48 --> Config Class Initialized
DEBUG - 2012-10-03 16:55:48 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:55:48 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:55:48 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:55:48 --> URI Class Initialized
DEBUG - 2012-10-03 16:55:48 --> Router Class Initialized
ERROR - 2012-10-03 16:55:48 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:55:48 --> Config Class Initialized
DEBUG - 2012-10-03 16:55:48 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:55:48 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:55:48 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:55:48 --> URI Class Initialized
DEBUG - 2012-10-03 16:55:48 --> Router Class Initialized
ERROR - 2012-10-03 16:55:48 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:56:41 --> Config Class Initialized
DEBUG - 2012-10-03 16:56:41 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:56:41 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:56:41 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:56:41 --> URI Class Initialized
DEBUG - 2012-10-03 16:56:41 --> Router Class Initialized
DEBUG - 2012-10-03 16:56:41 --> Output Class Initialized
DEBUG - 2012-10-03 16:56:41 --> Security Class Initialized
DEBUG - 2012-10-03 16:56:41 --> Input Class Initialized
DEBUG - 2012-10-03 16:56:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 16:56:41 --> Language Class Initialized
DEBUG - 2012-10-03 16:56:41 --> Loader Class Initialized
DEBUG - 2012-10-03 16:56:41 --> Helper loaded: url_helper
DEBUG - 2012-10-03 16:56:41 --> Controller Class Initialized
DEBUG - 2012-10-03 16:56:41 --> Model Class Initialized
DEBUG - 2012-10-03 16:56:41 --> Database Driver Class Initialized
DEBUG - 2012-10-03 16:56:41 --> Helper loaded: form_helper
DEBUG - 2012-10-03 16:56:41 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 16:56:41 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 16:56:41 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 16:56:41 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 16:56:41 --> Final output sent to browser
DEBUG - 2012-10-03 16:56:41 --> Total execution time: 0.0429
DEBUG - 2012-10-03 16:56:42 --> Config Class Initialized
DEBUG - 2012-10-03 16:56:42 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:56:42 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:56:42 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:56:42 --> URI Class Initialized
DEBUG - 2012-10-03 16:56:42 --> Router Class Initialized
ERROR - 2012-10-03 16:56:42 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:56:42 --> Config Class Initialized
DEBUG - 2012-10-03 16:56:42 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:56:42 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:56:42 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:56:42 --> URI Class Initialized
DEBUG - 2012-10-03 16:56:42 --> Router Class Initialized
ERROR - 2012-10-03 16:56:42 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:56:42 --> Config Class Initialized
DEBUG - 2012-10-03 16:56:42 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:56:42 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:56:42 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:56:42 --> URI Class Initialized
DEBUG - 2012-10-03 16:56:42 --> Router Class Initialized
ERROR - 2012-10-03 16:56:42 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:57:24 --> Config Class Initialized
DEBUG - 2012-10-03 16:57:24 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:57:24 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:57:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:57:24 --> URI Class Initialized
DEBUG - 2012-10-03 16:57:24 --> Router Class Initialized
DEBUG - 2012-10-03 16:57:24 --> Output Class Initialized
DEBUG - 2012-10-03 16:57:24 --> Security Class Initialized
DEBUG - 2012-10-03 16:57:24 --> Input Class Initialized
DEBUG - 2012-10-03 16:57:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 16:57:24 --> Language Class Initialized
DEBUG - 2012-10-03 16:57:24 --> Loader Class Initialized
DEBUG - 2012-10-03 16:57:24 --> Helper loaded: url_helper
DEBUG - 2012-10-03 16:57:24 --> Controller Class Initialized
DEBUG - 2012-10-03 16:57:24 --> Model Class Initialized
DEBUG - 2012-10-03 16:57:24 --> Database Driver Class Initialized
DEBUG - 2012-10-03 16:57:24 --> Helper loaded: form_helper
DEBUG - 2012-10-03 16:57:24 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 16:57:24 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 16:57:24 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 16:57:24 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 16:57:24 --> Final output sent to browser
DEBUG - 2012-10-03 16:57:24 --> Total execution time: 0.0395
DEBUG - 2012-10-03 16:57:26 --> Config Class Initialized
DEBUG - 2012-10-03 16:57:26 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:57:26 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:57:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:57:26 --> URI Class Initialized
DEBUG - 2012-10-03 16:57:26 --> Router Class Initialized
ERROR - 2012-10-03 16:57:26 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:57:26 --> Config Class Initialized
DEBUG - 2012-10-03 16:57:26 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:57:26 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:57:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:57:26 --> URI Class Initialized
DEBUG - 2012-10-03 16:57:26 --> Router Class Initialized
ERROR - 2012-10-03 16:57:26 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 16:57:26 --> Config Class Initialized
DEBUG - 2012-10-03 16:57:26 --> Hooks Class Initialized
DEBUG - 2012-10-03 16:57:26 --> Utf8 Class Initialized
DEBUG - 2012-10-03 16:57:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 16:57:26 --> URI Class Initialized
DEBUG - 2012-10-03 16:57:26 --> Router Class Initialized
ERROR - 2012-10-03 16:57:26 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 17:07:09 --> Config Class Initialized
DEBUG - 2012-10-03 17:07:09 --> Hooks Class Initialized
DEBUG - 2012-10-03 17:07:09 --> Utf8 Class Initialized
DEBUG - 2012-10-03 17:07:09 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 17:07:09 --> URI Class Initialized
DEBUG - 2012-10-03 17:07:09 --> Router Class Initialized
DEBUG - 2012-10-03 17:07:09 --> Output Class Initialized
DEBUG - 2012-10-03 17:07:09 --> Security Class Initialized
DEBUG - 2012-10-03 17:07:09 --> Input Class Initialized
DEBUG - 2012-10-03 17:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 17:07:09 --> Language Class Initialized
DEBUG - 2012-10-03 17:07:09 --> Loader Class Initialized
DEBUG - 2012-10-03 17:07:09 --> Helper loaded: url_helper
DEBUG - 2012-10-03 17:07:09 --> Controller Class Initialized
DEBUG - 2012-10-03 17:07:09 --> Model Class Initialized
DEBUG - 2012-10-03 17:07:09 --> Database Driver Class Initialized
DEBUG - 2012-10-03 17:07:09 --> Helper loaded: form_helper
DEBUG - 2012-10-03 17:07:09 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 17:07:09 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 17:07:09 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 17:07:09 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 17:07:09 --> Final output sent to browser
DEBUG - 2012-10-03 17:07:09 --> Total execution time: 0.0462
DEBUG - 2012-10-03 17:07:11 --> Config Class Initialized
DEBUG - 2012-10-03 17:07:11 --> Hooks Class Initialized
DEBUG - 2012-10-03 17:07:11 --> Utf8 Class Initialized
DEBUG - 2012-10-03 17:07:11 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 17:07:11 --> URI Class Initialized
DEBUG - 2012-10-03 17:07:11 --> Router Class Initialized
ERROR - 2012-10-03 17:07:11 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 17:07:11 --> Config Class Initialized
DEBUG - 2012-10-03 17:07:11 --> Hooks Class Initialized
DEBUG - 2012-10-03 17:07:11 --> Utf8 Class Initialized
DEBUG - 2012-10-03 17:07:11 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 17:07:11 --> URI Class Initialized
DEBUG - 2012-10-03 17:07:11 --> Router Class Initialized
ERROR - 2012-10-03 17:07:11 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 17:07:11 --> Config Class Initialized
DEBUG - 2012-10-03 17:07:11 --> Hooks Class Initialized
DEBUG - 2012-10-03 17:07:11 --> Utf8 Class Initialized
DEBUG - 2012-10-03 17:07:11 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 17:07:11 --> URI Class Initialized
DEBUG - 2012-10-03 17:07:11 --> Router Class Initialized
ERROR - 2012-10-03 17:07:11 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 17:07:27 --> Config Class Initialized
DEBUG - 2012-10-03 17:07:27 --> Hooks Class Initialized
DEBUG - 2012-10-03 17:07:27 --> Utf8 Class Initialized
DEBUG - 2012-10-03 17:07:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 17:07:27 --> URI Class Initialized
DEBUG - 2012-10-03 17:07:27 --> Router Class Initialized
DEBUG - 2012-10-03 17:07:27 --> Output Class Initialized
DEBUG - 2012-10-03 17:07:27 --> Security Class Initialized
DEBUG - 2012-10-03 17:07:27 --> Input Class Initialized
DEBUG - 2012-10-03 17:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 17:07:27 --> Language Class Initialized
DEBUG - 2012-10-03 17:07:27 --> Loader Class Initialized
DEBUG - 2012-10-03 17:07:27 --> Helper loaded: url_helper
DEBUG - 2012-10-03 17:07:27 --> Controller Class Initialized
DEBUG - 2012-10-03 17:07:27 --> Model Class Initialized
DEBUG - 2012-10-03 17:07:27 --> Database Driver Class Initialized
DEBUG - 2012-10-03 17:07:27 --> Helper loaded: form_helper
DEBUG - 2012-10-03 17:07:27 --> Helper loaded: language_helper
DEBUG - 2012-10-03 17:07:27 --> Form Validation Class Initialized
DEBUG - 2012-10-03 17:07:27 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-03 17:07:27 --> Upload Class Initialized
DEBUG - 2012-10-03 17:07:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-03 17:07:27 --> Image Lib Class Initialized
DEBUG - 2012-10-03 17:07:27 --> Final output sent to browser
DEBUG - 2012-10-03 17:07:27 --> Total execution time: 0.2033
DEBUG - 2012-10-03 17:09:33 --> Config Class Initialized
DEBUG - 2012-10-03 17:09:33 --> Hooks Class Initialized
DEBUG - 2012-10-03 17:09:33 --> Utf8 Class Initialized
DEBUG - 2012-10-03 17:09:33 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 17:09:33 --> URI Class Initialized
DEBUG - 2012-10-03 17:09:33 --> Router Class Initialized
DEBUG - 2012-10-03 17:09:33 --> Output Class Initialized
DEBUG - 2012-10-03 17:09:33 --> Security Class Initialized
DEBUG - 2012-10-03 17:09:33 --> Input Class Initialized
DEBUG - 2012-10-03 17:09:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 17:09:33 --> Language Class Initialized
DEBUG - 2012-10-03 17:09:33 --> Loader Class Initialized
DEBUG - 2012-10-03 17:09:33 --> Helper loaded: url_helper
DEBUG - 2012-10-03 17:09:33 --> Controller Class Initialized
DEBUG - 2012-10-03 17:09:33 --> Model Class Initialized
DEBUG - 2012-10-03 17:09:33 --> Database Driver Class Initialized
DEBUG - 2012-10-03 17:09:33 --> Helper loaded: form_helper
DEBUG - 2012-10-03 17:09:33 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 17:09:33 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 17:09:33 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 17:09:33 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 17:09:33 --> Final output sent to browser
DEBUG - 2012-10-03 17:09:33 --> Total execution time: 0.0395
DEBUG - 2012-10-03 17:09:35 --> Config Class Initialized
DEBUG - 2012-10-03 17:09:35 --> Hooks Class Initialized
DEBUG - 2012-10-03 17:09:35 --> Utf8 Class Initialized
DEBUG - 2012-10-03 17:09:35 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 17:09:35 --> URI Class Initialized
DEBUG - 2012-10-03 17:09:35 --> Router Class Initialized
ERROR - 2012-10-03 17:09:35 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 17:09:35 --> Config Class Initialized
DEBUG - 2012-10-03 17:09:35 --> Hooks Class Initialized
DEBUG - 2012-10-03 17:09:35 --> Utf8 Class Initialized
DEBUG - 2012-10-03 17:09:35 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 17:09:35 --> URI Class Initialized
DEBUG - 2012-10-03 17:09:35 --> Router Class Initialized
ERROR - 2012-10-03 17:09:35 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 17:09:35 --> Config Class Initialized
DEBUG - 2012-10-03 17:09:35 --> Hooks Class Initialized
DEBUG - 2012-10-03 17:09:35 --> Utf8 Class Initialized
DEBUG - 2012-10-03 17:09:35 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 17:09:35 --> URI Class Initialized
DEBUG - 2012-10-03 17:09:35 --> Router Class Initialized
ERROR - 2012-10-03 17:09:35 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 17:09:39 --> Config Class Initialized
DEBUG - 2012-10-03 17:09:39 --> Hooks Class Initialized
DEBUG - 2012-10-03 17:09:39 --> Utf8 Class Initialized
DEBUG - 2012-10-03 17:09:39 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 17:09:39 --> URI Class Initialized
DEBUG - 2012-10-03 17:09:39 --> Router Class Initialized
DEBUG - 2012-10-03 17:09:39 --> Output Class Initialized
DEBUG - 2012-10-03 17:09:39 --> Security Class Initialized
DEBUG - 2012-10-03 17:09:39 --> Input Class Initialized
DEBUG - 2012-10-03 17:09:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 17:09:39 --> Language Class Initialized
DEBUG - 2012-10-03 17:09:39 --> Loader Class Initialized
DEBUG - 2012-10-03 17:09:39 --> Helper loaded: url_helper
DEBUG - 2012-10-03 17:09:39 --> Controller Class Initialized
DEBUG - 2012-10-03 17:09:39 --> Model Class Initialized
DEBUG - 2012-10-03 17:09:39 --> Database Driver Class Initialized
DEBUG - 2012-10-03 17:09:42 --> Final output sent to browser
DEBUG - 2012-10-03 17:09:42 --> Total execution time: 3.2272
DEBUG - 2012-10-03 17:13:54 --> Config Class Initialized
DEBUG - 2012-10-03 17:13:54 --> Hooks Class Initialized
DEBUG - 2012-10-03 17:13:54 --> Utf8 Class Initialized
DEBUG - 2012-10-03 17:13:54 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 17:13:54 --> URI Class Initialized
DEBUG - 2012-10-03 17:13:54 --> Router Class Initialized
DEBUG - 2012-10-03 17:13:54 --> Output Class Initialized
DEBUG - 2012-10-03 17:13:54 --> Security Class Initialized
DEBUG - 2012-10-03 17:13:54 --> Input Class Initialized
DEBUG - 2012-10-03 17:13:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 17:13:54 --> Language Class Initialized
DEBUG - 2012-10-03 17:13:54 --> Loader Class Initialized
DEBUG - 2012-10-03 17:13:54 --> Helper loaded: url_helper
DEBUG - 2012-10-03 17:13:54 --> Controller Class Initialized
DEBUG - 2012-10-03 17:13:54 --> Model Class Initialized
DEBUG - 2012-10-03 17:13:54 --> Database Driver Class Initialized
DEBUG - 2012-10-03 17:13:54 --> Helper loaded: form_helper
DEBUG - 2012-10-03 17:13:54 --> Helper loaded: language_helper
DEBUG - 2012-10-03 17:13:54 --> Form Validation Class Initialized
DEBUG - 2012-10-03 17:13:54 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-03 17:13:54 --> Upload Class Initialized
DEBUG - 2012-10-03 17:13:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-03 17:13:54 --> Image Lib Class Initialized
DEBUG - 2012-10-03 17:13:54 --> Final output sent to browser
DEBUG - 2012-10-03 17:13:54 --> Total execution time: 0.1471
DEBUG - 2012-10-03 17:14:01 --> Config Class Initialized
DEBUG - 2012-10-03 17:14:01 --> Hooks Class Initialized
DEBUG - 2012-10-03 17:14:01 --> Utf8 Class Initialized
DEBUG - 2012-10-03 17:14:01 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 17:14:01 --> URI Class Initialized
DEBUG - 2012-10-03 17:14:01 --> Router Class Initialized
DEBUG - 2012-10-03 17:14:01 --> Output Class Initialized
DEBUG - 2012-10-03 17:14:01 --> Security Class Initialized
DEBUG - 2012-10-03 17:14:01 --> Input Class Initialized
DEBUG - 2012-10-03 17:14:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 17:14:01 --> Language Class Initialized
DEBUG - 2012-10-03 17:14:01 --> Loader Class Initialized
DEBUG - 2012-10-03 17:14:01 --> Helper loaded: url_helper
DEBUG - 2012-10-03 17:14:01 --> Controller Class Initialized
DEBUG - 2012-10-03 17:14:01 --> Model Class Initialized
DEBUG - 2012-10-03 17:14:01 --> Database Driver Class Initialized
DEBUG - 2012-10-03 17:14:02 --> Final output sent to browser
DEBUG - 2012-10-03 17:14:02 --> Total execution time: 0.1629
DEBUG - 2012-10-03 20:20:23 --> Config Class Initialized
DEBUG - 2012-10-03 20:20:23 --> Hooks Class Initialized
DEBUG - 2012-10-03 20:20:23 --> Utf8 Class Initialized
DEBUG - 2012-10-03 20:20:23 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 20:20:23 --> URI Class Initialized
DEBUG - 2012-10-03 20:20:23 --> Router Class Initialized
ERROR - 2012-10-03 20:20:23 --> 404 Page Not Found --> familysociety
DEBUG - 2012-10-03 20:59:10 --> Config Class Initialized
DEBUG - 2012-10-03 20:59:10 --> Hooks Class Initialized
DEBUG - 2012-10-03 20:59:10 --> Utf8 Class Initialized
DEBUG - 2012-10-03 20:59:10 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 20:59:10 --> URI Class Initialized
DEBUG - 2012-10-03 20:59:10 --> Router Class Initialized
DEBUG - 2012-10-03 20:59:10 --> Output Class Initialized
DEBUG - 2012-10-03 20:59:10 --> Security Class Initialized
DEBUG - 2012-10-03 20:59:10 --> Input Class Initialized
DEBUG - 2012-10-03 20:59:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 20:59:10 --> Language Class Initialized
DEBUG - 2012-10-03 20:59:49 --> Config Class Initialized
DEBUG - 2012-10-03 20:59:49 --> Hooks Class Initialized
DEBUG - 2012-10-03 20:59:49 --> Utf8 Class Initialized
DEBUG - 2012-10-03 20:59:49 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 20:59:49 --> URI Class Initialized
DEBUG - 2012-10-03 20:59:49 --> Router Class Initialized
DEBUG - 2012-10-03 20:59:49 --> Output Class Initialized
DEBUG - 2012-10-03 20:59:49 --> Security Class Initialized
DEBUG - 2012-10-03 20:59:49 --> Input Class Initialized
DEBUG - 2012-10-03 20:59:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 20:59:49 --> Language Class Initialized
DEBUG - 2012-10-03 21:00:33 --> Config Class Initialized
DEBUG - 2012-10-03 21:00:33 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:00:33 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:00:33 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:00:33 --> URI Class Initialized
DEBUG - 2012-10-03 21:00:33 --> Router Class Initialized
DEBUG - 2012-10-03 21:00:33 --> Output Class Initialized
DEBUG - 2012-10-03 21:00:33 --> Security Class Initialized
DEBUG - 2012-10-03 21:00:33 --> Input Class Initialized
DEBUG - 2012-10-03 21:00:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:00:33 --> Language Class Initialized
DEBUG - 2012-10-03 21:00:33 --> Loader Class Initialized
DEBUG - 2012-10-03 21:00:33 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:00:33 --> Controller Class Initialized
DEBUG - 2012-10-03 21:00:33 --> Model Class Initialized
DEBUG - 2012-10-03 21:00:33 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:00:33 --> Helper loaded: language_helper
DEBUG - 2012-10-03 21:00:33 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-03 21:01:27 --> Config Class Initialized
DEBUG - 2012-10-03 21:01:27 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:01:27 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:01:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:01:27 --> URI Class Initialized
DEBUG - 2012-10-03 21:01:27 --> Router Class Initialized
DEBUG - 2012-10-03 21:01:27 --> Output Class Initialized
DEBUG - 2012-10-03 21:01:27 --> Security Class Initialized
DEBUG - 2012-10-03 21:01:27 --> Input Class Initialized
DEBUG - 2012-10-03 21:01:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:01:27 --> Language Class Initialized
DEBUG - 2012-10-03 21:01:27 --> Loader Class Initialized
DEBUG - 2012-10-03 21:01:27 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:01:27 --> Controller Class Initialized
DEBUG - 2012-10-03 21:01:27 --> Model Class Initialized
DEBUG - 2012-10-03 21:01:27 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:01:27 --> Helper loaded: language_helper
DEBUG - 2012-10-03 21:01:27 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-03 21:02:44 --> Config Class Initialized
DEBUG - 2012-10-03 21:02:44 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:02:44 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:02:44 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:02:44 --> URI Class Initialized
DEBUG - 2012-10-03 21:02:44 --> Router Class Initialized
DEBUG - 2012-10-03 21:02:44 --> Output Class Initialized
DEBUG - 2012-10-03 21:02:44 --> Security Class Initialized
DEBUG - 2012-10-03 21:02:44 --> Input Class Initialized
DEBUG - 2012-10-03 21:02:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:02:44 --> Language Class Initialized
DEBUG - 2012-10-03 21:02:44 --> Loader Class Initialized
DEBUG - 2012-10-03 21:02:44 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:02:44 --> Controller Class Initialized
DEBUG - 2012-10-03 21:02:44 --> Model Class Initialized
DEBUG - 2012-10-03 21:02:44 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:02:44 --> Helper loaded: language_helper
DEBUG - 2012-10-03 21:02:44 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-03 21:02:56 --> Config Class Initialized
DEBUG - 2012-10-03 21:02:56 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:02:56 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:02:56 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:02:56 --> URI Class Initialized
DEBUG - 2012-10-03 21:02:56 --> Router Class Initialized
DEBUG - 2012-10-03 21:02:56 --> Output Class Initialized
DEBUG - 2012-10-03 21:02:56 --> Security Class Initialized
DEBUG - 2012-10-03 21:02:56 --> Input Class Initialized
DEBUG - 2012-10-03 21:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:02:56 --> Language Class Initialized
DEBUG - 2012-10-03 21:02:56 --> Loader Class Initialized
DEBUG - 2012-10-03 21:02:56 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:02:56 --> Controller Class Initialized
DEBUG - 2012-10-03 21:02:56 --> Model Class Initialized
DEBUG - 2012-10-03 21:02:56 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:02:56 --> Helper loaded: language_helper
DEBUG - 2012-10-03 21:02:56 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-03 21:03:10 --> Config Class Initialized
DEBUG - 2012-10-03 21:03:10 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:03:10 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:03:10 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:03:10 --> URI Class Initialized
DEBUG - 2012-10-03 21:03:10 --> Router Class Initialized
DEBUG - 2012-10-03 21:03:10 --> Output Class Initialized
DEBUG - 2012-10-03 21:03:10 --> Security Class Initialized
DEBUG - 2012-10-03 21:03:10 --> Input Class Initialized
DEBUG - 2012-10-03 21:03:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:03:10 --> Language Class Initialized
DEBUG - 2012-10-03 21:03:10 --> Loader Class Initialized
DEBUG - 2012-10-03 21:03:10 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:03:10 --> Controller Class Initialized
DEBUG - 2012-10-03 21:03:10 --> Model Class Initialized
DEBUG - 2012-10-03 21:03:10 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:03:10 --> Helper loaded: form_helper
DEBUG - 2012-10-03 21:03:10 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 21:03:10 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 21:03:10 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 21:03:10 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 21:03:10 --> Final output sent to browser
DEBUG - 2012-10-03 21:03:10 --> Total execution time: 0.0396
DEBUG - 2012-10-03 21:03:12 --> Config Class Initialized
DEBUG - 2012-10-03 21:03:12 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:03:12 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:03:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:03:12 --> URI Class Initialized
DEBUG - 2012-10-03 21:03:12 --> Router Class Initialized
ERROR - 2012-10-03 21:03:12 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:03:12 --> Config Class Initialized
DEBUG - 2012-10-03 21:03:12 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:03:12 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:03:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:03:12 --> URI Class Initialized
DEBUG - 2012-10-03 21:03:12 --> Router Class Initialized
ERROR - 2012-10-03 21:03:12 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:03:12 --> Config Class Initialized
DEBUG - 2012-10-03 21:03:12 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:03:12 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:03:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:03:12 --> URI Class Initialized
DEBUG - 2012-10-03 21:03:12 --> Router Class Initialized
ERROR - 2012-10-03 21:03:12 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:04:02 --> Config Class Initialized
DEBUG - 2012-10-03 21:04:02 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:04:02 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:04:02 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:04:02 --> URI Class Initialized
DEBUG - 2012-10-03 21:04:02 --> Router Class Initialized
DEBUG - 2012-10-03 21:04:02 --> Output Class Initialized
DEBUG - 2012-10-03 21:04:02 --> Security Class Initialized
DEBUG - 2012-10-03 21:04:02 --> Input Class Initialized
DEBUG - 2012-10-03 21:04:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:04:02 --> Language Class Initialized
DEBUG - 2012-10-03 21:04:02 --> Loader Class Initialized
DEBUG - 2012-10-03 21:04:02 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:04:02 --> Controller Class Initialized
DEBUG - 2012-10-03 21:04:02 --> Model Class Initialized
DEBUG - 2012-10-03 21:04:02 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:04:02 --> Helper loaded: form_helper
DEBUG - 2012-10-03 21:04:02 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 21:04:02 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 21:04:02 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 21:04:02 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 21:04:02 --> Final output sent to browser
DEBUG - 2012-10-03 21:04:02 --> Total execution time: 0.0391
DEBUG - 2012-10-03 21:04:04 --> Config Class Initialized
DEBUG - 2012-10-03 21:04:04 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:04:04 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:04:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:04:04 --> URI Class Initialized
DEBUG - 2012-10-03 21:04:04 --> Router Class Initialized
ERROR - 2012-10-03 21:04:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:04:04 --> Config Class Initialized
DEBUG - 2012-10-03 21:04:04 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:04:04 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:04:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:04:04 --> URI Class Initialized
DEBUG - 2012-10-03 21:04:04 --> Router Class Initialized
ERROR - 2012-10-03 21:04:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:04:04 --> Config Class Initialized
DEBUG - 2012-10-03 21:04:04 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:04:04 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:04:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:04:04 --> URI Class Initialized
DEBUG - 2012-10-03 21:04:04 --> Router Class Initialized
ERROR - 2012-10-03 21:04:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:04:26 --> Config Class Initialized
DEBUG - 2012-10-03 21:04:26 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:04:26 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:04:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:04:26 --> URI Class Initialized
DEBUG - 2012-10-03 21:04:26 --> Router Class Initialized
DEBUG - 2012-10-03 21:04:26 --> Output Class Initialized
DEBUG - 2012-10-03 21:04:26 --> Security Class Initialized
DEBUG - 2012-10-03 21:04:26 --> Input Class Initialized
DEBUG - 2012-10-03 21:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:04:26 --> Language Class Initialized
DEBUG - 2012-10-03 21:04:26 --> Loader Class Initialized
DEBUG - 2012-10-03 21:04:26 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:04:26 --> Controller Class Initialized
DEBUG - 2012-10-03 21:04:26 --> Model Class Initialized
DEBUG - 2012-10-03 21:04:26 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:04:26 --> Helper loaded: form_helper
DEBUG - 2012-10-03 21:04:26 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 21:04:26 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 21:04:26 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 21:04:26 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 21:04:26 --> Final output sent to browser
DEBUG - 2012-10-03 21:04:26 --> Total execution time: 0.0398
DEBUG - 2012-10-03 21:04:27 --> Config Class Initialized
DEBUG - 2012-10-03 21:04:27 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:04:27 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:04:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:04:27 --> URI Class Initialized
DEBUG - 2012-10-03 21:04:27 --> Router Class Initialized
ERROR - 2012-10-03 21:04:27 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:04:27 --> Config Class Initialized
DEBUG - 2012-10-03 21:04:27 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:04:27 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:04:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:04:27 --> URI Class Initialized
DEBUG - 2012-10-03 21:04:27 --> Router Class Initialized
ERROR - 2012-10-03 21:04:27 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:04:28 --> Config Class Initialized
DEBUG - 2012-10-03 21:04:28 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:04:28 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:04:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:04:28 --> URI Class Initialized
DEBUG - 2012-10-03 21:04:28 --> Router Class Initialized
ERROR - 2012-10-03 21:04:28 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:07:02 --> Config Class Initialized
DEBUG - 2012-10-03 21:07:02 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:07:02 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:07:02 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:07:02 --> URI Class Initialized
DEBUG - 2012-10-03 21:07:02 --> Router Class Initialized
DEBUG - 2012-10-03 21:07:02 --> Output Class Initialized
DEBUG - 2012-10-03 21:07:02 --> Security Class Initialized
DEBUG - 2012-10-03 21:07:02 --> Input Class Initialized
DEBUG - 2012-10-03 21:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:07:02 --> Language Class Initialized
DEBUG - 2012-10-03 21:07:02 --> Loader Class Initialized
DEBUG - 2012-10-03 21:07:02 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:07:02 --> Controller Class Initialized
DEBUG - 2012-10-03 21:07:02 --> Model Class Initialized
DEBUG - 2012-10-03 21:07:02 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:07:02 --> Helper loaded: form_helper
DEBUG - 2012-10-03 21:07:02 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 21:07:02 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 21:07:02 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 21:07:02 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 21:07:02 --> Final output sent to browser
DEBUG - 2012-10-03 21:07:02 --> Total execution time: 0.0468
DEBUG - 2012-10-03 21:07:04 --> Config Class Initialized
DEBUG - 2012-10-03 21:07:04 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:07:04 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:07:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:07:04 --> URI Class Initialized
DEBUG - 2012-10-03 21:07:04 --> Router Class Initialized
ERROR - 2012-10-03 21:07:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:07:04 --> Config Class Initialized
DEBUG - 2012-10-03 21:07:04 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:07:04 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:07:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:07:04 --> URI Class Initialized
DEBUG - 2012-10-03 21:07:04 --> Router Class Initialized
ERROR - 2012-10-03 21:07:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:07:04 --> Config Class Initialized
DEBUG - 2012-10-03 21:07:04 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:07:04 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:07:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:07:04 --> URI Class Initialized
DEBUG - 2012-10-03 21:07:04 --> Router Class Initialized
ERROR - 2012-10-03 21:07:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:14:04 --> Config Class Initialized
DEBUG - 2012-10-03 21:14:04 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:14:04 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:14:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:14:04 --> URI Class Initialized
DEBUG - 2012-10-03 21:14:04 --> Router Class Initialized
DEBUG - 2012-10-03 21:14:04 --> Output Class Initialized
DEBUG - 2012-10-03 21:14:04 --> Security Class Initialized
DEBUG - 2012-10-03 21:14:04 --> Input Class Initialized
DEBUG - 2012-10-03 21:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:14:04 --> Language Class Initialized
DEBUG - 2012-10-03 21:14:04 --> Loader Class Initialized
DEBUG - 2012-10-03 21:14:04 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:14:04 --> Controller Class Initialized
DEBUG - 2012-10-03 21:14:04 --> Model Class Initialized
DEBUG - 2012-10-03 21:14:04 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:14:04 --> Helper loaded: form_helper
DEBUG - 2012-10-03 21:14:04 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 21:14:04 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 21:14:04 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 21:14:04 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 21:14:04 --> Final output sent to browser
DEBUG - 2012-10-03 21:14:04 --> Total execution time: 0.0446
DEBUG - 2012-10-03 21:14:06 --> Config Class Initialized
DEBUG - 2012-10-03 21:14:06 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:14:06 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:14:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:14:06 --> URI Class Initialized
DEBUG - 2012-10-03 21:14:06 --> Router Class Initialized
ERROR - 2012-10-03 21:14:06 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:14:06 --> Config Class Initialized
DEBUG - 2012-10-03 21:14:06 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:14:06 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:14:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:14:06 --> URI Class Initialized
DEBUG - 2012-10-03 21:14:06 --> Router Class Initialized
ERROR - 2012-10-03 21:14:06 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:14:06 --> Config Class Initialized
DEBUG - 2012-10-03 21:14:06 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:14:06 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:14:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:14:06 --> URI Class Initialized
DEBUG - 2012-10-03 21:14:06 --> Router Class Initialized
ERROR - 2012-10-03 21:14:06 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:14:53 --> Config Class Initialized
DEBUG - 2012-10-03 21:14:53 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:14:53 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:14:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:14:53 --> URI Class Initialized
DEBUG - 2012-10-03 21:14:53 --> Router Class Initialized
DEBUG - 2012-10-03 21:14:53 --> Output Class Initialized
DEBUG - 2012-10-03 21:14:53 --> Security Class Initialized
DEBUG - 2012-10-03 21:14:53 --> Input Class Initialized
DEBUG - 2012-10-03 21:14:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:14:53 --> Language Class Initialized
DEBUG - 2012-10-03 21:14:53 --> Loader Class Initialized
DEBUG - 2012-10-03 21:14:53 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:14:53 --> Controller Class Initialized
DEBUG - 2012-10-03 21:14:53 --> Model Class Initialized
DEBUG - 2012-10-03 21:14:53 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:14:53 --> Helper loaded: form_helper
DEBUG - 2012-10-03 21:14:53 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 21:14:53 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 21:14:53 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 21:14:53 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 21:14:53 --> Final output sent to browser
DEBUG - 2012-10-03 21:14:53 --> Total execution time: 0.7438
DEBUG - 2012-10-03 21:14:58 --> Config Class Initialized
DEBUG - 2012-10-03 21:14:58 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:14:58 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:14:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:14:58 --> URI Class Initialized
DEBUG - 2012-10-03 21:14:58 --> Router Class Initialized
DEBUG - 2012-10-03 21:14:58 --> Output Class Initialized
DEBUG - 2012-10-03 21:14:58 --> Security Class Initialized
DEBUG - 2012-10-03 21:14:58 --> Input Class Initialized
DEBUG - 2012-10-03 21:14:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:14:58 --> Language Class Initialized
DEBUG - 2012-10-03 21:14:58 --> Loader Class Initialized
DEBUG - 2012-10-03 21:14:58 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:14:58 --> Controller Class Initialized
DEBUG - 2012-10-03 21:14:58 --> Model Class Initialized
DEBUG - 2012-10-03 21:14:58 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:15:00 --> Helper loaded: form_helper
DEBUG - 2012-10-03 21:15:00 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 21:15:00 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 21:15:00 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 21:15:00 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 21:15:00 --> Final output sent to browser
DEBUG - 2012-10-03 21:15:00 --> Total execution time: 2.0265
DEBUG - 2012-10-03 21:15:03 --> Config Class Initialized
DEBUG - 2012-10-03 21:15:03 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:15:03 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:15:03 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:15:03 --> URI Class Initialized
DEBUG - 2012-10-03 21:15:03 --> Config Class Initialized
DEBUG - 2012-10-03 21:15:03 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:15:03 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:15:03 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:15:03 --> URI Class Initialized
DEBUG - 2012-10-03 21:15:03 --> Router Class Initialized
ERROR - 2012-10-03 21:15:03 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:15:03 --> Router Class Initialized
ERROR - 2012-10-03 21:15:03 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:15:03 --> Config Class Initialized
DEBUG - 2012-10-03 21:15:03 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:15:03 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:15:03 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:15:03 --> URI Class Initialized
DEBUG - 2012-10-03 21:15:03 --> Router Class Initialized
ERROR - 2012-10-03 21:15:03 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:15:44 --> Config Class Initialized
DEBUG - 2012-10-03 21:15:44 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:15:44 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:15:44 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:15:44 --> URI Class Initialized
DEBUG - 2012-10-03 21:15:44 --> Router Class Initialized
DEBUG - 2012-10-03 21:15:44 --> Output Class Initialized
DEBUG - 2012-10-03 21:15:44 --> Security Class Initialized
DEBUG - 2012-10-03 21:15:44 --> Input Class Initialized
DEBUG - 2012-10-03 21:15:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:15:44 --> Language Class Initialized
DEBUG - 2012-10-03 21:15:44 --> Loader Class Initialized
DEBUG - 2012-10-03 21:15:44 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:15:44 --> Controller Class Initialized
DEBUG - 2012-10-03 21:15:44 --> Model Class Initialized
DEBUG - 2012-10-03 21:15:44 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:15:44 --> Helper loaded: form_helper
DEBUG - 2012-10-03 21:15:44 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 21:15:44 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 21:15:44 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 21:15:44 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 21:15:44 --> Final output sent to browser
DEBUG - 2012-10-03 21:15:44 --> Total execution time: 0.0421
DEBUG - 2012-10-03 21:15:46 --> Config Class Initialized
DEBUG - 2012-10-03 21:15:46 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:15:46 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:15:46 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:15:46 --> URI Class Initialized
DEBUG - 2012-10-03 21:15:46 --> Config Class Initialized
DEBUG - 2012-10-03 21:15:46 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:15:46 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:15:46 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:15:46 --> URI Class Initialized
DEBUG - 2012-10-03 21:15:46 --> Config Class Initialized
DEBUG - 2012-10-03 21:15:46 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:15:46 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:15:46 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:15:46 --> URI Class Initialized
DEBUG - 2012-10-03 21:15:46 --> Router Class Initialized
ERROR - 2012-10-03 21:15:46 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:15:46 --> Router Class Initialized
ERROR - 2012-10-03 21:15:46 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:15:46 --> Router Class Initialized
ERROR - 2012-10-03 21:15:46 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:17:23 --> Config Class Initialized
DEBUG - 2012-10-03 21:17:23 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:17:23 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:17:23 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:17:23 --> URI Class Initialized
DEBUG - 2012-10-03 21:17:23 --> Router Class Initialized
DEBUG - 2012-10-03 21:17:23 --> Output Class Initialized
DEBUG - 2012-10-03 21:17:23 --> Security Class Initialized
DEBUG - 2012-10-03 21:17:23 --> Input Class Initialized
DEBUG - 2012-10-03 21:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:17:23 --> Language Class Initialized
DEBUG - 2012-10-03 21:17:23 --> Loader Class Initialized
DEBUG - 2012-10-03 21:17:23 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:17:23 --> Controller Class Initialized
DEBUG - 2012-10-03 21:17:23 --> Model Class Initialized
DEBUG - 2012-10-03 21:17:23 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:17:23 --> Helper loaded: form_helper
DEBUG - 2012-10-03 21:17:23 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 21:17:23 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 21:17:23 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 21:17:23 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 21:17:23 --> Final output sent to browser
DEBUG - 2012-10-03 21:17:23 --> Total execution time: 0.0442
DEBUG - 2012-10-03 21:17:25 --> Config Class Initialized
DEBUG - 2012-10-03 21:17:25 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:17:25 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:17:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:17:25 --> URI Class Initialized
DEBUG - 2012-10-03 21:17:25 --> Router Class Initialized
ERROR - 2012-10-03 21:17:25 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:17:25 --> Config Class Initialized
DEBUG - 2012-10-03 21:17:25 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:17:25 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:17:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:17:25 --> URI Class Initialized
DEBUG - 2012-10-03 21:17:25 --> Router Class Initialized
ERROR - 2012-10-03 21:17:25 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:17:25 --> Config Class Initialized
DEBUG - 2012-10-03 21:17:25 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:17:25 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:17:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:17:25 --> URI Class Initialized
DEBUG - 2012-10-03 21:17:25 --> Router Class Initialized
ERROR - 2012-10-03 21:17:25 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:20:02 --> Config Class Initialized
DEBUG - 2012-10-03 21:20:02 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:20:02 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:20:02 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:20:02 --> URI Class Initialized
DEBUG - 2012-10-03 21:20:02 --> Router Class Initialized
DEBUG - 2012-10-03 21:20:02 --> Output Class Initialized
DEBUG - 2012-10-03 21:20:02 --> Security Class Initialized
DEBUG - 2012-10-03 21:20:02 --> Input Class Initialized
DEBUG - 2012-10-03 21:20:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:20:02 --> Language Class Initialized
DEBUG - 2012-10-03 21:20:02 --> Loader Class Initialized
DEBUG - 2012-10-03 21:20:02 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:20:02 --> Controller Class Initialized
DEBUG - 2012-10-03 21:20:02 --> Model Class Initialized
DEBUG - 2012-10-03 21:20:02 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:20:02 --> Helper loaded: form_helper
DEBUG - 2012-10-03 21:20:02 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 21:20:02 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 21:20:02 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 21:20:02 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 21:20:02 --> Final output sent to browser
DEBUG - 2012-10-03 21:20:02 --> Total execution time: 0.4257
DEBUG - 2012-10-03 21:20:04 --> Config Class Initialized
DEBUG - 2012-10-03 21:20:04 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:20:04 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:20:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:20:04 --> URI Class Initialized
DEBUG - 2012-10-03 21:20:04 --> Router Class Initialized
ERROR - 2012-10-03 21:20:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:20:04 --> Config Class Initialized
DEBUG - 2012-10-03 21:20:04 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:20:04 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:20:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:20:04 --> URI Class Initialized
DEBUG - 2012-10-03 21:20:04 --> Config Class Initialized
DEBUG - 2012-10-03 21:20:04 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:20:04 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:20:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:20:04 --> URI Class Initialized
DEBUG - 2012-10-03 21:20:04 --> Router Class Initialized
ERROR - 2012-10-03 21:20:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:20:04 --> Router Class Initialized
ERROR - 2012-10-03 21:20:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:20:24 --> Config Class Initialized
DEBUG - 2012-10-03 21:20:24 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:20:24 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:20:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:20:24 --> URI Class Initialized
DEBUG - 2012-10-03 21:20:24 --> Router Class Initialized
DEBUG - 2012-10-03 21:20:24 --> Output Class Initialized
DEBUG - 2012-10-03 21:20:24 --> Security Class Initialized
DEBUG - 2012-10-03 21:20:24 --> Input Class Initialized
DEBUG - 2012-10-03 21:20:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:20:24 --> Language Class Initialized
DEBUG - 2012-10-03 21:20:24 --> Loader Class Initialized
DEBUG - 2012-10-03 21:20:24 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:20:24 --> Controller Class Initialized
DEBUG - 2012-10-03 21:20:24 --> Model Class Initialized
DEBUG - 2012-10-03 21:20:24 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:20:24 --> Helper loaded: form_helper
DEBUG - 2012-10-03 21:20:24 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 21:20:24 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 21:20:24 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 21:20:24 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 21:20:24 --> Final output sent to browser
DEBUG - 2012-10-03 21:20:24 --> Total execution time: 0.0394
DEBUG - 2012-10-03 21:20:26 --> Config Class Initialized
DEBUG - 2012-10-03 21:20:26 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:20:26 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:20:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:20:26 --> URI Class Initialized
DEBUG - 2012-10-03 21:20:26 --> Router Class Initialized
ERROR - 2012-10-03 21:20:26 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:20:26 --> Config Class Initialized
DEBUG - 2012-10-03 21:20:26 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:20:26 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:20:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:20:26 --> URI Class Initialized
DEBUG - 2012-10-03 21:20:26 --> Router Class Initialized
ERROR - 2012-10-03 21:20:26 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:20:26 --> Config Class Initialized
DEBUG - 2012-10-03 21:20:26 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:20:26 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:20:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:20:26 --> URI Class Initialized
DEBUG - 2012-10-03 21:20:26 --> Router Class Initialized
ERROR - 2012-10-03 21:20:26 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:22:45 --> Config Class Initialized
DEBUG - 2012-10-03 21:22:45 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:22:45 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:22:45 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:22:45 --> URI Class Initialized
DEBUG - 2012-10-03 21:22:45 --> Router Class Initialized
DEBUG - 2012-10-03 21:22:45 --> Output Class Initialized
DEBUG - 2012-10-03 21:22:45 --> Security Class Initialized
DEBUG - 2012-10-03 21:22:45 --> Input Class Initialized
DEBUG - 2012-10-03 21:22:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:22:45 --> Language Class Initialized
DEBUG - 2012-10-03 21:22:45 --> Loader Class Initialized
DEBUG - 2012-10-03 21:22:45 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:22:45 --> Controller Class Initialized
DEBUG - 2012-10-03 21:22:45 --> Model Class Initialized
DEBUG - 2012-10-03 21:22:45 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:22:45 --> Helper loaded: form_helper
DEBUG - 2012-10-03 21:22:45 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 21:22:45 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 21:22:45 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 21:22:45 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 21:22:45 --> Final output sent to browser
DEBUG - 2012-10-03 21:22:45 --> Total execution time: 0.0397
DEBUG - 2012-10-03 21:22:47 --> Config Class Initialized
DEBUG - 2012-10-03 21:22:47 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:22:47 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:22:47 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:22:47 --> URI Class Initialized
DEBUG - 2012-10-03 21:22:47 --> Router Class Initialized
ERROR - 2012-10-03 21:22:47 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:22:47 --> Config Class Initialized
DEBUG - 2012-10-03 21:22:47 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:22:47 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:22:47 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:22:47 --> URI Class Initialized
DEBUG - 2012-10-03 21:22:47 --> Router Class Initialized
ERROR - 2012-10-03 21:22:47 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:22:47 --> Config Class Initialized
DEBUG - 2012-10-03 21:22:47 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:22:47 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:22:47 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:22:47 --> URI Class Initialized
DEBUG - 2012-10-03 21:22:47 --> Router Class Initialized
ERROR - 2012-10-03 21:22:47 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:28:32 --> Config Class Initialized
DEBUG - 2012-10-03 21:28:32 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:28:32 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:28:32 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:28:32 --> URI Class Initialized
DEBUG - 2012-10-03 21:28:32 --> Router Class Initialized
DEBUG - 2012-10-03 21:28:32 --> Output Class Initialized
DEBUG - 2012-10-03 21:28:32 --> Security Class Initialized
DEBUG - 2012-10-03 21:28:32 --> Input Class Initialized
DEBUG - 2012-10-03 21:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:28:32 --> Language Class Initialized
DEBUG - 2012-10-03 21:28:32 --> Loader Class Initialized
DEBUG - 2012-10-03 21:28:32 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:28:32 --> Controller Class Initialized
DEBUG - 2012-10-03 21:28:32 --> Model Class Initialized
DEBUG - 2012-10-03 21:28:32 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:28:32 --> Helper loaded: form_helper
DEBUG - 2012-10-03 21:28:32 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 21:28:32 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 21:28:32 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 21:28:32 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 21:28:32 --> Final output sent to browser
DEBUG - 2012-10-03 21:28:32 --> Total execution time: 0.0405
DEBUG - 2012-10-03 21:28:34 --> Config Class Initialized
DEBUG - 2012-10-03 21:28:34 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:28:34 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:28:34 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:28:34 --> URI Class Initialized
DEBUG - 2012-10-03 21:28:34 --> Router Class Initialized
ERROR - 2012-10-03 21:28:34 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:28:34 --> Config Class Initialized
DEBUG - 2012-10-03 21:28:34 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:28:34 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:28:34 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:28:34 --> URI Class Initialized
DEBUG - 2012-10-03 21:28:34 --> Router Class Initialized
ERROR - 2012-10-03 21:28:34 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:28:34 --> Config Class Initialized
DEBUG - 2012-10-03 21:28:34 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:28:34 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:28:34 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:28:34 --> URI Class Initialized
DEBUG - 2012-10-03 21:28:34 --> Router Class Initialized
ERROR - 2012-10-03 21:28:34 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:30:15 --> Config Class Initialized
DEBUG - 2012-10-03 21:30:15 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:30:15 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:30:15 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:30:15 --> URI Class Initialized
DEBUG - 2012-10-03 21:30:15 --> Router Class Initialized
DEBUG - 2012-10-03 21:30:15 --> Output Class Initialized
DEBUG - 2012-10-03 21:30:15 --> Security Class Initialized
DEBUG - 2012-10-03 21:30:15 --> Input Class Initialized
DEBUG - 2012-10-03 21:30:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:30:15 --> Language Class Initialized
DEBUG - 2012-10-03 21:30:15 --> Loader Class Initialized
DEBUG - 2012-10-03 21:30:15 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:30:15 --> Controller Class Initialized
DEBUG - 2012-10-03 21:30:15 --> Model Class Initialized
DEBUG - 2012-10-03 21:30:15 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:30:15 --> Helper loaded: form_helper
DEBUG - 2012-10-03 21:30:15 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 21:30:15 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 21:30:15 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 21:30:15 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 21:30:15 --> Final output sent to browser
DEBUG - 2012-10-03 21:30:15 --> Total execution time: 0.0494
DEBUG - 2012-10-03 21:30:17 --> Config Class Initialized
DEBUG - 2012-10-03 21:30:17 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:30:17 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:30:17 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:30:17 --> URI Class Initialized
DEBUG - 2012-10-03 21:30:17 --> Router Class Initialized
ERROR - 2012-10-03 21:30:17 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:30:17 --> Config Class Initialized
DEBUG - 2012-10-03 21:30:17 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:30:17 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:30:17 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:30:17 --> URI Class Initialized
DEBUG - 2012-10-03 21:30:17 --> Router Class Initialized
ERROR - 2012-10-03 21:30:17 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:30:17 --> Config Class Initialized
DEBUG - 2012-10-03 21:30:17 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:30:17 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:30:17 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:30:17 --> URI Class Initialized
DEBUG - 2012-10-03 21:30:17 --> Router Class Initialized
ERROR - 2012-10-03 21:30:17 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:31:12 --> Config Class Initialized
DEBUG - 2012-10-03 21:31:12 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:31:12 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:31:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:31:12 --> URI Class Initialized
DEBUG - 2012-10-03 21:31:12 --> Router Class Initialized
DEBUG - 2012-10-03 21:31:12 --> Output Class Initialized
DEBUG - 2012-10-03 21:31:12 --> Security Class Initialized
DEBUG - 2012-10-03 21:31:12 --> Input Class Initialized
DEBUG - 2012-10-03 21:31:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:31:12 --> Language Class Initialized
DEBUG - 2012-10-03 21:31:12 --> Loader Class Initialized
DEBUG - 2012-10-03 21:31:12 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:31:12 --> Controller Class Initialized
DEBUG - 2012-10-03 21:31:12 --> Model Class Initialized
DEBUG - 2012-10-03 21:31:12 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:31:12 --> Helper loaded: form_helper
DEBUG - 2012-10-03 21:31:12 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 21:31:12 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 21:31:12 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 21:31:12 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 21:31:12 --> Final output sent to browser
DEBUG - 2012-10-03 21:31:12 --> Total execution time: 0.0401
DEBUG - 2012-10-03 21:31:14 --> Config Class Initialized
DEBUG - 2012-10-03 21:31:14 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:31:14 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:31:14 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:31:14 --> URI Class Initialized
DEBUG - 2012-10-03 21:31:14 --> Router Class Initialized
ERROR - 2012-10-03 21:31:14 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:31:14 --> Config Class Initialized
DEBUG - 2012-10-03 21:31:14 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:31:14 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:31:14 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:31:14 --> URI Class Initialized
DEBUG - 2012-10-03 21:31:14 --> Router Class Initialized
ERROR - 2012-10-03 21:31:14 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:31:14 --> Config Class Initialized
DEBUG - 2012-10-03 21:31:14 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:31:14 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:31:14 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:31:14 --> URI Class Initialized
DEBUG - 2012-10-03 21:31:14 --> Router Class Initialized
ERROR - 2012-10-03 21:31:14 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:31:18 --> Config Class Initialized
DEBUG - 2012-10-03 21:31:18 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:31:18 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:31:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:31:18 --> URI Class Initialized
DEBUG - 2012-10-03 21:31:18 --> Router Class Initialized
DEBUG - 2012-10-03 21:31:18 --> Output Class Initialized
DEBUG - 2012-10-03 21:31:18 --> Security Class Initialized
DEBUG - 2012-10-03 21:31:18 --> Input Class Initialized
DEBUG - 2012-10-03 21:31:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:31:18 --> Language Class Initialized
DEBUG - 2012-10-03 21:31:18 --> Loader Class Initialized
DEBUG - 2012-10-03 21:31:18 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:31:18 --> Controller Class Initialized
DEBUG - 2012-10-03 21:31:18 --> Model Class Initialized
DEBUG - 2012-10-03 21:31:18 --> Database Driver Class Initialized
ERROR - 2012-10-03 21:31:18 --> 404 Page Not Found --> pricing/ajax_frame_types_get
DEBUG - 2012-10-03 21:32:59 --> Config Class Initialized
DEBUG - 2012-10-03 21:32:59 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:32:59 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:32:59 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:32:59 --> URI Class Initialized
DEBUG - 2012-10-03 21:32:59 --> Router Class Initialized
DEBUG - 2012-10-03 21:32:59 --> Output Class Initialized
DEBUG - 2012-10-03 21:32:59 --> Security Class Initialized
DEBUG - 2012-10-03 21:32:59 --> Input Class Initialized
DEBUG - 2012-10-03 21:32:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:32:59 --> Language Class Initialized
DEBUG - 2012-10-03 21:32:59 --> Loader Class Initialized
DEBUG - 2012-10-03 21:32:59 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:32:59 --> Controller Class Initialized
DEBUG - 2012-10-03 21:32:59 --> Model Class Initialized
DEBUG - 2012-10-03 21:32:59 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:32:59 --> Helper loaded: form_helper
DEBUG - 2012-10-03 21:32:59 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 21:32:59 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 21:32:59 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 21:32:59 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 21:32:59 --> Final output sent to browser
DEBUG - 2012-10-03 21:32:59 --> Total execution time: 0.0401
DEBUG - 2012-10-03 21:33:01 --> Config Class Initialized
DEBUG - 2012-10-03 21:33:01 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:33:01 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:33:01 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:33:01 --> URI Class Initialized
DEBUG - 2012-10-03 21:33:01 --> Router Class Initialized
ERROR - 2012-10-03 21:33:01 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:33:01 --> Config Class Initialized
DEBUG - 2012-10-03 21:33:01 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:33:01 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:33:01 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:33:01 --> URI Class Initialized
DEBUG - 2012-10-03 21:33:01 --> Router Class Initialized
ERROR - 2012-10-03 21:33:01 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:33:01 --> Config Class Initialized
DEBUG - 2012-10-03 21:33:01 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:33:01 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:33:01 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:33:01 --> URI Class Initialized
DEBUG - 2012-10-03 21:33:01 --> Router Class Initialized
ERROR - 2012-10-03 21:33:01 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:33:03 --> Config Class Initialized
DEBUG - 2012-10-03 21:33:03 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:33:03 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:33:03 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:33:03 --> URI Class Initialized
DEBUG - 2012-10-03 21:33:03 --> Router Class Initialized
DEBUG - 2012-10-03 21:33:03 --> Output Class Initialized
DEBUG - 2012-10-03 21:33:03 --> Security Class Initialized
DEBUG - 2012-10-03 21:33:03 --> Input Class Initialized
DEBUG - 2012-10-03 21:33:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:33:03 --> Language Class Initialized
DEBUG - 2012-10-03 21:33:03 --> Loader Class Initialized
DEBUG - 2012-10-03 21:33:03 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:33:03 --> Controller Class Initialized
DEBUG - 2012-10-03 21:33:03 --> Model Class Initialized
DEBUG - 2012-10-03 21:33:03 --> Database Driver Class Initialized
ERROR - 2012-10-03 21:33:03 --> 404 Page Not Found --> pricing/ajax_frame_types_get
DEBUG - 2012-10-03 21:33:24 --> Config Class Initialized
DEBUG - 2012-10-03 21:33:24 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:33:24 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:33:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:33:24 --> URI Class Initialized
DEBUG - 2012-10-03 21:33:24 --> Router Class Initialized
DEBUG - 2012-10-03 21:33:24 --> Output Class Initialized
DEBUG - 2012-10-03 21:33:24 --> Security Class Initialized
DEBUG - 2012-10-03 21:33:24 --> Input Class Initialized
DEBUG - 2012-10-03 21:33:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:33:24 --> Language Class Initialized
DEBUG - 2012-10-03 21:33:24 --> Loader Class Initialized
DEBUG - 2012-10-03 21:33:24 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:33:24 --> Controller Class Initialized
DEBUG - 2012-10-03 21:33:24 --> Model Class Initialized
DEBUG - 2012-10-03 21:33:24 --> Database Driver Class Initialized
ERROR - 2012-10-03 21:33:24 --> 404 Page Not Found --> pricing/ajax_frame_types_get
DEBUG - 2012-10-03 21:35:53 --> Config Class Initialized
DEBUG - 2012-10-03 21:35:53 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:35:53 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:35:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:35:53 --> URI Class Initialized
DEBUG - 2012-10-03 21:35:53 --> Router Class Initialized
DEBUG - 2012-10-03 21:35:53 --> Output Class Initialized
DEBUG - 2012-10-03 21:35:53 --> Security Class Initialized
DEBUG - 2012-10-03 21:35:53 --> Input Class Initialized
DEBUG - 2012-10-03 21:35:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:35:53 --> Language Class Initialized
DEBUG - 2012-10-03 21:35:53 --> Loader Class Initialized
DEBUG - 2012-10-03 21:35:53 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:35:53 --> Controller Class Initialized
DEBUG - 2012-10-03 21:35:53 --> Model Class Initialized
DEBUG - 2012-10-03 21:35:53 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:35:53 --> Helper loaded: form_helper
DEBUG - 2012-10-03 21:35:53 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 21:35:53 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 21:35:53 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 21:35:53 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 21:35:53 --> Final output sent to browser
DEBUG - 2012-10-03 21:35:53 --> Total execution time: 0.0405
DEBUG - 2012-10-03 21:35:55 --> Config Class Initialized
DEBUG - 2012-10-03 21:35:55 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:35:55 --> Config Class Initialized
DEBUG - 2012-10-03 21:35:55 --> Config Class Initialized
DEBUG - 2012-10-03 21:35:55 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:35:55 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:35:55 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:35:55 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:35:55 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:35:55 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:35:55 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:35:55 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:35:55 --> URI Class Initialized
DEBUG - 2012-10-03 21:35:55 --> URI Class Initialized
DEBUG - 2012-10-03 21:35:55 --> URI Class Initialized
DEBUG - 2012-10-03 21:35:55 --> Router Class Initialized
DEBUG - 2012-10-03 21:35:55 --> Router Class Initialized
DEBUG - 2012-10-03 21:35:55 --> Router Class Initialized
ERROR - 2012-10-03 21:35:55 --> 404 Page Not Found --> css
ERROR - 2012-10-03 21:35:55 --> 404 Page Not Found --> css
ERROR - 2012-10-03 21:35:55 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:36:43 --> Config Class Initialized
DEBUG - 2012-10-03 21:36:43 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:36:43 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:36:43 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:36:43 --> URI Class Initialized
DEBUG - 2012-10-03 21:36:43 --> Router Class Initialized
DEBUG - 2012-10-03 21:36:43 --> Output Class Initialized
DEBUG - 2012-10-03 21:36:43 --> Security Class Initialized
DEBUG - 2012-10-03 21:36:43 --> Input Class Initialized
DEBUG - 2012-10-03 21:36:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:36:43 --> Language Class Initialized
DEBUG - 2012-10-03 21:36:43 --> Loader Class Initialized
DEBUG - 2012-10-03 21:36:43 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:36:43 --> Controller Class Initialized
DEBUG - 2012-10-03 21:36:43 --> Model Class Initialized
DEBUG - 2012-10-03 21:36:43 --> Database Driver Class Initialized
ERROR - 2012-10-03 21:36:43 --> 404 Page Not Found --> pricing/ajax_frame_types_get
DEBUG - 2012-10-03 21:38:16 --> Config Class Initialized
DEBUG - 2012-10-03 21:38:16 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:38:16 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:38:16 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:38:16 --> URI Class Initialized
DEBUG - 2012-10-03 21:38:16 --> Router Class Initialized
DEBUG - 2012-10-03 21:38:16 --> Output Class Initialized
DEBUG - 2012-10-03 21:38:16 --> Security Class Initialized
DEBUG - 2012-10-03 21:38:16 --> Input Class Initialized
DEBUG - 2012-10-03 21:38:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:38:16 --> Language Class Initialized
DEBUG - 2012-10-03 21:38:16 --> Loader Class Initialized
DEBUG - 2012-10-03 21:38:16 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:38:16 --> Controller Class Initialized
DEBUG - 2012-10-03 21:38:16 --> Model Class Initialized
DEBUG - 2012-10-03 21:38:16 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:38:16 --> Helper loaded: form_helper
DEBUG - 2012-10-03 21:38:16 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 21:38:16 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 21:38:16 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 21:38:16 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 21:38:16 --> Final output sent to browser
DEBUG - 2012-10-03 21:38:16 --> Total execution time: 0.0391
DEBUG - 2012-10-03 21:38:18 --> Config Class Initialized
DEBUG - 2012-10-03 21:38:18 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:38:18 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:38:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:38:18 --> URI Class Initialized
DEBUG - 2012-10-03 21:38:18 --> Router Class Initialized
ERROR - 2012-10-03 21:38:18 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:38:18 --> Config Class Initialized
DEBUG - 2012-10-03 21:38:18 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:38:18 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:38:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:38:18 --> URI Class Initialized
DEBUG - 2012-10-03 21:38:18 --> Router Class Initialized
ERROR - 2012-10-03 21:38:18 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:38:18 --> Config Class Initialized
DEBUG - 2012-10-03 21:38:18 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:38:18 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:38:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:38:18 --> URI Class Initialized
DEBUG - 2012-10-03 21:38:18 --> Router Class Initialized
ERROR - 2012-10-03 21:38:18 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:38:26 --> Config Class Initialized
DEBUG - 2012-10-03 21:38:26 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:38:26 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:38:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:38:26 --> URI Class Initialized
DEBUG - 2012-10-03 21:38:26 --> Router Class Initialized
DEBUG - 2012-10-03 21:38:26 --> Output Class Initialized
DEBUG - 2012-10-03 21:38:26 --> Security Class Initialized
DEBUG - 2012-10-03 21:38:26 --> Input Class Initialized
DEBUG - 2012-10-03 21:38:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:38:26 --> Language Class Initialized
DEBUG - 2012-10-03 21:38:26 --> Loader Class Initialized
DEBUG - 2012-10-03 21:38:26 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:38:26 --> Controller Class Initialized
DEBUG - 2012-10-03 21:38:26 --> Model Class Initialized
DEBUG - 2012-10-03 21:38:26 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:38:26 --> Helper loaded: language_helper
DEBUG - 2012-10-03 21:38:26 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-03 21:39:12 --> Config Class Initialized
DEBUG - 2012-10-03 21:39:12 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:39:12 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:39:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:39:12 --> URI Class Initialized
DEBUG - 2012-10-03 21:39:12 --> Router Class Initialized
DEBUG - 2012-10-03 21:39:12 --> Output Class Initialized
DEBUG - 2012-10-03 21:39:12 --> Security Class Initialized
DEBUG - 2012-10-03 21:39:12 --> Input Class Initialized
DEBUG - 2012-10-03 21:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:39:12 --> Language Class Initialized
DEBUG - 2012-10-03 21:39:12 --> Loader Class Initialized
DEBUG - 2012-10-03 21:39:12 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:39:12 --> Controller Class Initialized
DEBUG - 2012-10-03 21:39:12 --> Model Class Initialized
DEBUG - 2012-10-03 21:39:12 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:39:12 --> Helper loaded: language_helper
DEBUG - 2012-10-03 21:39:12 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-03 21:47:30 --> Config Class Initialized
DEBUG - 2012-10-03 21:47:30 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:47:30 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:47:30 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:47:30 --> URI Class Initialized
DEBUG - 2012-10-03 21:47:30 --> Router Class Initialized
DEBUG - 2012-10-03 21:47:30 --> Output Class Initialized
DEBUG - 2012-10-03 21:47:30 --> Security Class Initialized
DEBUG - 2012-10-03 21:47:30 --> Input Class Initialized
DEBUG - 2012-10-03 21:47:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:47:30 --> Language Class Initialized
DEBUG - 2012-10-03 21:47:30 --> Loader Class Initialized
DEBUG - 2012-10-03 21:47:30 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:47:30 --> Controller Class Initialized
DEBUG - 2012-10-03 21:47:30 --> Model Class Initialized
DEBUG - 2012-10-03 21:47:30 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:47:30 --> Helper loaded: form_helper
DEBUG - 2012-10-03 21:47:30 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 21:47:30 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 21:47:30 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 21:47:30 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 21:47:30 --> Final output sent to browser
DEBUG - 2012-10-03 21:47:30 --> Total execution time: 0.0395
DEBUG - 2012-10-03 21:47:37 --> Config Class Initialized
DEBUG - 2012-10-03 21:47:37 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:47:37 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:47:37 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:47:37 --> URI Class Initialized
DEBUG - 2012-10-03 21:47:37 --> Router Class Initialized
DEBUG - 2012-10-03 21:47:37 --> Output Class Initialized
DEBUG - 2012-10-03 21:47:37 --> Security Class Initialized
DEBUG - 2012-10-03 21:47:37 --> Input Class Initialized
DEBUG - 2012-10-03 21:47:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:47:37 --> Language Class Initialized
DEBUG - 2012-10-03 21:47:37 --> Loader Class Initialized
DEBUG - 2012-10-03 21:47:37 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:47:37 --> Controller Class Initialized
DEBUG - 2012-10-03 21:47:37 --> Model Class Initialized
DEBUG - 2012-10-03 21:47:37 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:47:37 --> Helper loaded: form_helper
DEBUG - 2012-10-03 21:47:37 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 21:47:37 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 21:47:37 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 21:47:37 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 21:47:37 --> Final output sent to browser
DEBUG - 2012-10-03 21:47:37 --> Total execution time: 0.0396
DEBUG - 2012-10-03 21:47:39 --> Config Class Initialized
DEBUG - 2012-10-03 21:47:39 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:47:39 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:47:39 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:47:39 --> URI Class Initialized
DEBUG - 2012-10-03 21:47:39 --> Router Class Initialized
ERROR - 2012-10-03 21:47:39 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:47:39 --> Config Class Initialized
DEBUG - 2012-10-03 21:47:39 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:47:39 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:47:39 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:47:39 --> URI Class Initialized
DEBUG - 2012-10-03 21:47:39 --> Router Class Initialized
ERROR - 2012-10-03 21:47:39 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:47:39 --> Config Class Initialized
DEBUG - 2012-10-03 21:47:39 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:47:39 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:47:39 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:47:39 --> URI Class Initialized
DEBUG - 2012-10-03 21:47:39 --> Router Class Initialized
ERROR - 2012-10-03 21:47:39 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:48:15 --> Config Class Initialized
DEBUG - 2012-10-03 21:48:15 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:48:15 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:48:15 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:48:15 --> URI Class Initialized
DEBUG - 2012-10-03 21:48:15 --> Router Class Initialized
DEBUG - 2012-10-03 21:48:15 --> Output Class Initialized
DEBUG - 2012-10-03 21:48:15 --> Security Class Initialized
DEBUG - 2012-10-03 21:48:15 --> Input Class Initialized
DEBUG - 2012-10-03 21:48:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:48:15 --> Language Class Initialized
DEBUG - 2012-10-03 21:48:15 --> Loader Class Initialized
DEBUG - 2012-10-03 21:48:15 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:48:15 --> Controller Class Initialized
DEBUG - 2012-10-03 21:48:15 --> Model Class Initialized
DEBUG - 2012-10-03 21:48:15 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:48:15 --> Helper loaded: language_helper
DEBUG - 2012-10-03 21:48:15 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-03 21:53:52 --> Config Class Initialized
DEBUG - 2012-10-03 21:53:52 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:53:52 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:53:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:53:52 --> URI Class Initialized
DEBUG - 2012-10-03 21:53:52 --> Router Class Initialized
DEBUG - 2012-10-03 21:53:52 --> Output Class Initialized
DEBUG - 2012-10-03 21:53:52 --> Security Class Initialized
DEBUG - 2012-10-03 21:53:52 --> Input Class Initialized
DEBUG - 2012-10-03 21:53:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:53:52 --> Language Class Initialized
DEBUG - 2012-10-03 21:53:52 --> Loader Class Initialized
DEBUG - 2012-10-03 21:53:52 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:53:52 --> Controller Class Initialized
DEBUG - 2012-10-03 21:53:52 --> Model Class Initialized
DEBUG - 2012-10-03 21:53:52 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:53:52 --> Helper loaded: form_helper
DEBUG - 2012-10-03 21:53:52 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-03 21:53:52 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-03 21:53:52 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-03 21:53:52 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-03 21:53:52 --> Final output sent to browser
DEBUG - 2012-10-03 21:53:52 --> Total execution time: 0.0398
DEBUG - 2012-10-03 21:53:54 --> Config Class Initialized
DEBUG - 2012-10-03 21:53:54 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:53:54 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:53:54 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:53:54 --> URI Class Initialized
DEBUG - 2012-10-03 21:53:54 --> Router Class Initialized
ERROR - 2012-10-03 21:53:54 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:53:54 --> Config Class Initialized
DEBUG - 2012-10-03 21:53:54 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:53:54 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:53:54 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:53:54 --> URI Class Initialized
DEBUG - 2012-10-03 21:53:54 --> Router Class Initialized
ERROR - 2012-10-03 21:53:54 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:53:54 --> Config Class Initialized
DEBUG - 2012-10-03 21:53:54 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:53:54 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:53:54 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:53:54 --> URI Class Initialized
DEBUG - 2012-10-03 21:53:54 --> Router Class Initialized
ERROR - 2012-10-03 21:53:54 --> 404 Page Not Found --> css
DEBUG - 2012-10-03 21:53:56 --> Config Class Initialized
DEBUG - 2012-10-03 21:53:56 --> Hooks Class Initialized
DEBUG - 2012-10-03 21:53:56 --> Utf8 Class Initialized
DEBUG - 2012-10-03 21:53:56 --> UTF-8 Support Enabled
DEBUG - 2012-10-03 21:53:56 --> URI Class Initialized
DEBUG - 2012-10-03 21:53:56 --> Router Class Initialized
DEBUG - 2012-10-03 21:53:56 --> Output Class Initialized
DEBUG - 2012-10-03 21:53:56 --> Security Class Initialized
DEBUG - 2012-10-03 21:53:56 --> Input Class Initialized
DEBUG - 2012-10-03 21:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-03 21:53:56 --> Language Class Initialized
DEBUG - 2012-10-03 21:53:56 --> Loader Class Initialized
DEBUG - 2012-10-03 21:53:56 --> Helper loaded: url_helper
DEBUG - 2012-10-03 21:53:56 --> Controller Class Initialized
DEBUG - 2012-10-03 21:53:56 --> Model Class Initialized
DEBUG - 2012-10-03 21:53:56 --> Database Driver Class Initialized
DEBUG - 2012-10-03 21:53:56 --> Helper loaded: language_helper
DEBUG - 2012-10-03 21:53:56 --> Language file loaded: language/english/message_lang.php
