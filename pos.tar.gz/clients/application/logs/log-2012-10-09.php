<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-10-09 14:31:46 --> Config Class Initialized
DEBUG - 2012-10-09 14:31:46 --> Hooks Class Initialized
DEBUG - 2012-10-09 14:31:46 --> Utf8 Class Initialized
DEBUG - 2012-10-09 14:31:46 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 14:31:46 --> URI Class Initialized
DEBUG - 2012-10-09 14:31:46 --> Router Class Initialized
DEBUG - 2012-10-09 14:31:46 --> Output Class Initialized
DEBUG - 2012-10-09 14:31:46 --> Security Class Initialized
DEBUG - 2012-10-09 14:31:46 --> Input Class Initialized
DEBUG - 2012-10-09 14:31:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 14:31:46 --> Language Class Initialized
DEBUG - 2012-10-09 14:31:46 --> Loader Class Initialized
DEBUG - 2012-10-09 14:31:46 --> Helper loaded: url_helper
DEBUG - 2012-10-09 14:31:46 --> Controller Class Initialized
DEBUG - 2012-10-09 14:31:46 --> Model Class Initialized
DEBUG - 2012-10-09 14:31:47 --> Database Driver Class Initialized
DEBUG - 2012-10-09 14:31:47 --> Helper loaded: form_helper
DEBUG - 2012-10-09 14:31:48 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 14:31:48 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-10-09 14:31:48 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 14:31:48 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-10-09 14:31:48 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 14:31:48 --> Final output sent to browser
DEBUG - 2012-10-09 14:31:48 --> Total execution time: 1.3040
DEBUG - 2012-10-09 14:31:50 --> Config Class Initialized
DEBUG - 2012-10-09 14:31:50 --> Hooks Class Initialized
DEBUG - 2012-10-09 14:31:50 --> Utf8 Class Initialized
DEBUG - 2012-10-09 14:31:50 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 14:31:50 --> URI Class Initialized
DEBUG - 2012-10-09 14:31:50 --> Router Class Initialized
DEBUG - 2012-10-09 14:31:50 --> Config Class Initialized
DEBUG - 2012-10-09 14:31:50 --> Hooks Class Initialized
DEBUG - 2012-10-09 14:31:50 --> Utf8 Class Initialized
DEBUG - 2012-10-09 14:31:50 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 14:31:50 --> Config Class Initialized
DEBUG - 2012-10-09 14:31:50 --> Hooks Class Initialized
DEBUG - 2012-10-09 14:31:50 --> URI Class Initialized
DEBUG - 2012-10-09 14:31:50 --> Utf8 Class Initialized
DEBUG - 2012-10-09 14:31:50 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 14:31:50 --> Router Class Initialized
DEBUG - 2012-10-09 14:31:50 --> URI Class Initialized
DEBUG - 2012-10-09 14:31:50 --> Router Class Initialized
ERROR - 2012-10-09 14:31:50 --> 404 Page Not Found --> css
ERROR - 2012-10-09 14:31:50 --> 404 Page Not Found --> css
ERROR - 2012-10-09 14:31:50 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 14:31:52 --> Config Class Initialized
DEBUG - 2012-10-09 14:31:52 --> Hooks Class Initialized
DEBUG - 2012-10-09 14:31:52 --> Utf8 Class Initialized
DEBUG - 2012-10-09 14:31:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 14:31:52 --> URI Class Initialized
DEBUG - 2012-10-09 14:31:52 --> Router Class Initialized
DEBUG - 2012-10-09 14:31:52 --> Output Class Initialized
DEBUG - 2012-10-09 14:31:52 --> Security Class Initialized
DEBUG - 2012-10-09 14:31:52 --> Input Class Initialized
DEBUG - 2012-10-09 14:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 14:31:52 --> Language Class Initialized
DEBUG - 2012-10-09 14:31:52 --> Loader Class Initialized
DEBUG - 2012-10-09 14:31:52 --> Helper loaded: url_helper
DEBUG - 2012-10-09 14:31:52 --> Controller Class Initialized
DEBUG - 2012-10-09 14:31:52 --> Model Class Initialized
DEBUG - 2012-10-09 14:31:52 --> Database Driver Class Initialized
DEBUG - 2012-10-09 14:31:52 --> Helper loaded: form_helper
DEBUG - 2012-10-09 14:31:52 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 14:31:52 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 14:31:52 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 14:31:52 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 14:31:52 --> Final output sent to browser
DEBUG - 2012-10-09 14:31:52 --> Total execution time: 0.1539
DEBUG - 2012-10-09 14:34:49 --> Config Class Initialized
DEBUG - 2012-10-09 14:34:49 --> Hooks Class Initialized
DEBUG - 2012-10-09 14:34:49 --> Utf8 Class Initialized
DEBUG - 2012-10-09 14:34:49 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 14:34:49 --> URI Class Initialized
DEBUG - 2012-10-09 14:34:49 --> Router Class Initialized
DEBUG - 2012-10-09 14:34:49 --> Output Class Initialized
DEBUG - 2012-10-09 14:34:49 --> Security Class Initialized
DEBUG - 2012-10-09 14:34:49 --> Input Class Initialized
DEBUG - 2012-10-09 14:34:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 14:34:49 --> Language Class Initialized
DEBUG - 2012-10-09 14:34:49 --> Loader Class Initialized
DEBUG - 2012-10-09 14:34:49 --> Helper loaded: url_helper
DEBUG - 2012-10-09 14:34:49 --> Controller Class Initialized
DEBUG - 2012-10-09 14:34:49 --> Model Class Initialized
DEBUG - 2012-10-09 14:34:49 --> Database Driver Class Initialized
DEBUG - 2012-10-09 14:34:49 --> Helper loaded: language_helper
DEBUG - 2012-10-09 14:34:49 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 14:39:40 --> Config Class Initialized
DEBUG - 2012-10-09 14:39:40 --> Hooks Class Initialized
DEBUG - 2012-10-09 14:39:40 --> Utf8 Class Initialized
DEBUG - 2012-10-09 14:39:40 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 14:39:40 --> URI Class Initialized
DEBUG - 2012-10-09 14:39:40 --> Router Class Initialized
DEBUG - 2012-10-09 14:39:40 --> Output Class Initialized
DEBUG - 2012-10-09 14:39:40 --> Security Class Initialized
DEBUG - 2012-10-09 14:39:40 --> Input Class Initialized
DEBUG - 2012-10-09 14:39:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 14:39:40 --> Language Class Initialized
DEBUG - 2012-10-09 14:39:40 --> Loader Class Initialized
DEBUG - 2012-10-09 14:39:40 --> Helper loaded: url_helper
DEBUG - 2012-10-09 14:39:40 --> Controller Class Initialized
DEBUG - 2012-10-09 14:39:40 --> Model Class Initialized
DEBUG - 2012-10-09 14:39:40 --> Database Driver Class Initialized
DEBUG - 2012-10-09 14:39:40 --> Helper loaded: form_helper
DEBUG - 2012-10-09 14:39:40 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 14:39:40 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 14:39:40 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 14:39:40 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 14:39:40 --> Final output sent to browser
DEBUG - 2012-10-09 14:39:40 --> Total execution time: 0.0486
DEBUG - 2012-10-09 14:39:42 --> Config Class Initialized
DEBUG - 2012-10-09 14:39:42 --> Hooks Class Initialized
DEBUG - 2012-10-09 14:39:42 --> Utf8 Class Initialized
DEBUG - 2012-10-09 14:39:42 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 14:39:42 --> URI Class Initialized
DEBUG - 2012-10-09 14:39:42 --> Router Class Initialized
ERROR - 2012-10-09 14:39:42 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 14:39:42 --> Config Class Initialized
DEBUG - 2012-10-09 14:39:42 --> Hooks Class Initialized
DEBUG - 2012-10-09 14:39:42 --> Utf8 Class Initialized
DEBUG - 2012-10-09 14:39:42 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 14:39:42 --> URI Class Initialized
DEBUG - 2012-10-09 14:39:42 --> Router Class Initialized
ERROR - 2012-10-09 14:39:42 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 14:39:42 --> Config Class Initialized
DEBUG - 2012-10-09 14:39:42 --> Hooks Class Initialized
DEBUG - 2012-10-09 14:39:42 --> Utf8 Class Initialized
DEBUG - 2012-10-09 14:39:42 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 14:39:42 --> URI Class Initialized
DEBUG - 2012-10-09 14:39:42 --> Router Class Initialized
ERROR - 2012-10-09 14:39:42 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 14:39:52 --> Config Class Initialized
DEBUG - 2012-10-09 14:39:52 --> Hooks Class Initialized
DEBUG - 2012-10-09 14:39:52 --> Utf8 Class Initialized
DEBUG - 2012-10-09 14:39:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 14:39:52 --> URI Class Initialized
DEBUG - 2012-10-09 14:39:52 --> Router Class Initialized
DEBUG - 2012-10-09 14:39:52 --> Output Class Initialized
DEBUG - 2012-10-09 14:39:52 --> Security Class Initialized
DEBUG - 2012-10-09 14:39:52 --> Input Class Initialized
DEBUG - 2012-10-09 14:39:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 14:39:52 --> Language Class Initialized
DEBUG - 2012-10-09 14:39:52 --> Loader Class Initialized
DEBUG - 2012-10-09 14:39:52 --> Helper loaded: url_helper
DEBUG - 2012-10-09 14:39:52 --> Controller Class Initialized
DEBUG - 2012-10-09 14:39:52 --> Model Class Initialized
DEBUG - 2012-10-09 14:39:52 --> Database Driver Class Initialized
DEBUG - 2012-10-09 14:39:52 --> Helper loaded: language_helper
DEBUG - 2012-10-09 14:39:52 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 14:40:03 --> Config Class Initialized
DEBUG - 2012-10-09 14:40:03 --> Hooks Class Initialized
DEBUG - 2012-10-09 14:40:03 --> Utf8 Class Initialized
DEBUG - 2012-10-09 14:40:03 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 14:40:03 --> URI Class Initialized
DEBUG - 2012-10-09 14:40:03 --> Router Class Initialized
DEBUG - 2012-10-09 14:40:03 --> Output Class Initialized
DEBUG - 2012-10-09 14:40:03 --> Security Class Initialized
DEBUG - 2012-10-09 14:40:03 --> Input Class Initialized
DEBUG - 2012-10-09 14:40:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 14:40:03 --> Language Class Initialized
DEBUG - 2012-10-09 14:40:03 --> Loader Class Initialized
DEBUG - 2012-10-09 14:40:03 --> Helper loaded: url_helper
DEBUG - 2012-10-09 14:40:03 --> Controller Class Initialized
DEBUG - 2012-10-09 14:40:03 --> Model Class Initialized
DEBUG - 2012-10-09 14:40:03 --> Database Driver Class Initialized
ERROR - 2012-10-09 14:40:03 --> 404 Page Not Found --> pricing/ajax_frame_type_save_edit
DEBUG - 2012-10-09 14:53:31 --> Config Class Initialized
DEBUG - 2012-10-09 14:53:31 --> Hooks Class Initialized
DEBUG - 2012-10-09 14:53:31 --> Utf8 Class Initialized
DEBUG - 2012-10-09 14:53:31 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 14:53:31 --> URI Class Initialized
DEBUG - 2012-10-09 14:53:31 --> Router Class Initialized
DEBUG - 2012-10-09 14:53:31 --> Output Class Initialized
DEBUG - 2012-10-09 14:53:31 --> Security Class Initialized
DEBUG - 2012-10-09 14:53:31 --> Input Class Initialized
DEBUG - 2012-10-09 14:53:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 14:53:31 --> Language Class Initialized
DEBUG - 2012-10-09 14:54:16 --> Config Class Initialized
DEBUG - 2012-10-09 14:54:16 --> Hooks Class Initialized
DEBUG - 2012-10-09 14:54:16 --> Utf8 Class Initialized
DEBUG - 2012-10-09 14:54:16 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 14:54:16 --> URI Class Initialized
DEBUG - 2012-10-09 14:54:16 --> Router Class Initialized
DEBUG - 2012-10-09 14:54:16 --> Output Class Initialized
DEBUG - 2012-10-09 14:54:16 --> Security Class Initialized
DEBUG - 2012-10-09 14:54:16 --> Input Class Initialized
DEBUG - 2012-10-09 14:54:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 14:54:16 --> Language Class Initialized
DEBUG - 2012-10-09 14:54:16 --> Loader Class Initialized
DEBUG - 2012-10-09 14:54:16 --> Helper loaded: url_helper
DEBUG - 2012-10-09 14:54:16 --> Controller Class Initialized
DEBUG - 2012-10-09 14:54:16 --> Model Class Initialized
DEBUG - 2012-10-09 14:54:16 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:01:21 --> Config Class Initialized
DEBUG - 2012-10-09 15:01:21 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:01:21 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:01:21 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:01:21 --> URI Class Initialized
DEBUG - 2012-10-09 15:01:21 --> Router Class Initialized
DEBUG - 2012-10-09 15:01:21 --> Output Class Initialized
DEBUG - 2012-10-09 15:01:21 --> Security Class Initialized
DEBUG - 2012-10-09 15:01:21 --> Input Class Initialized
DEBUG - 2012-10-09 15:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:01:21 --> Language Class Initialized
DEBUG - 2012-10-09 15:01:21 --> Loader Class Initialized
DEBUG - 2012-10-09 15:01:21 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:01:21 --> Controller Class Initialized
DEBUG - 2012-10-09 15:01:21 --> Model Class Initialized
DEBUG - 2012-10-09 15:01:21 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:01:21 --> Helper loaded: form_helper
DEBUG - 2012-10-09 15:01:21 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 15:01:21 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 15:01:21 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 15:01:21 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 15:01:21 --> Final output sent to browser
DEBUG - 2012-10-09 15:01:21 --> Total execution time: 0.0496
DEBUG - 2012-10-09 15:01:23 --> Config Class Initialized
DEBUG - 2012-10-09 15:01:23 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:01:23 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:01:23 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:01:23 --> URI Class Initialized
DEBUG - 2012-10-09 15:01:23 --> Router Class Initialized
ERROR - 2012-10-09 15:01:23 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:01:23 --> Config Class Initialized
DEBUG - 2012-10-09 15:01:23 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:01:23 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:01:23 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:01:23 --> URI Class Initialized
DEBUG - 2012-10-09 15:01:23 --> Router Class Initialized
ERROR - 2012-10-09 15:01:23 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:01:23 --> Config Class Initialized
DEBUG - 2012-10-09 15:01:23 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:01:23 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:01:23 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:01:23 --> URI Class Initialized
DEBUG - 2012-10-09 15:01:23 --> Router Class Initialized
ERROR - 2012-10-09 15:01:23 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:01:25 --> Config Class Initialized
DEBUG - 2012-10-09 15:01:25 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:01:25 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:01:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:01:25 --> URI Class Initialized
DEBUG - 2012-10-09 15:01:25 --> Router Class Initialized
DEBUG - 2012-10-09 15:01:25 --> Output Class Initialized
DEBUG - 2012-10-09 15:01:25 --> Security Class Initialized
DEBUG - 2012-10-09 15:01:25 --> Input Class Initialized
DEBUG - 2012-10-09 15:01:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:01:25 --> Language Class Initialized
DEBUG - 2012-10-09 15:01:25 --> Loader Class Initialized
DEBUG - 2012-10-09 15:01:25 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:01:25 --> Controller Class Initialized
DEBUG - 2012-10-09 15:01:25 --> Model Class Initialized
DEBUG - 2012-10-09 15:01:25 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:01:25 --> Helper loaded: language_helper
DEBUG - 2012-10-09 15:01:25 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 15:01:30 --> Config Class Initialized
DEBUG - 2012-10-09 15:01:30 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:01:30 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:01:30 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:01:30 --> URI Class Initialized
DEBUG - 2012-10-09 15:01:30 --> Router Class Initialized
DEBUG - 2012-10-09 15:01:30 --> Output Class Initialized
DEBUG - 2012-10-09 15:01:30 --> Security Class Initialized
DEBUG - 2012-10-09 15:01:30 --> Input Class Initialized
DEBUG - 2012-10-09 15:01:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:01:30 --> Language Class Initialized
DEBUG - 2012-10-09 15:01:30 --> Loader Class Initialized
DEBUG - 2012-10-09 15:01:30 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:01:30 --> Controller Class Initialized
DEBUG - 2012-10-09 15:01:30 --> Model Class Initialized
DEBUG - 2012-10-09 15:01:30 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:04:11 --> Config Class Initialized
DEBUG - 2012-10-09 15:04:11 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:04:11 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:04:11 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:04:11 --> URI Class Initialized
DEBUG - 2012-10-09 15:04:11 --> Router Class Initialized
DEBUG - 2012-10-09 15:04:11 --> Output Class Initialized
DEBUG - 2012-10-09 15:04:11 --> Security Class Initialized
DEBUG - 2012-10-09 15:04:11 --> Input Class Initialized
DEBUG - 2012-10-09 15:04:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:04:11 --> Language Class Initialized
DEBUG - 2012-10-09 15:04:11 --> Loader Class Initialized
DEBUG - 2012-10-09 15:04:11 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:04:11 --> Controller Class Initialized
DEBUG - 2012-10-09 15:04:11 --> Model Class Initialized
DEBUG - 2012-10-09 15:04:11 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:04:21 --> Config Class Initialized
DEBUG - 2012-10-09 15:04:21 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:04:21 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:04:21 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:04:21 --> URI Class Initialized
DEBUG - 2012-10-09 15:04:21 --> Router Class Initialized
DEBUG - 2012-10-09 15:04:21 --> Output Class Initialized
DEBUG - 2012-10-09 15:04:21 --> Security Class Initialized
DEBUG - 2012-10-09 15:04:21 --> Input Class Initialized
DEBUG - 2012-10-09 15:04:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:04:21 --> Language Class Initialized
DEBUG - 2012-10-09 15:04:21 --> Loader Class Initialized
DEBUG - 2012-10-09 15:04:21 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:04:21 --> Controller Class Initialized
DEBUG - 2012-10-09 15:04:21 --> Model Class Initialized
DEBUG - 2012-10-09 15:04:21 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:19:19 --> Config Class Initialized
DEBUG - 2012-10-09 15:19:19 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:19:19 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:19:19 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:19:19 --> URI Class Initialized
DEBUG - 2012-10-09 15:19:19 --> Router Class Initialized
DEBUG - 2012-10-09 15:19:19 --> Output Class Initialized
DEBUG - 2012-10-09 15:19:19 --> Security Class Initialized
DEBUG - 2012-10-09 15:19:19 --> Input Class Initialized
DEBUG - 2012-10-09 15:19:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:19:19 --> Language Class Initialized
DEBUG - 2012-10-09 15:19:19 --> Loader Class Initialized
DEBUG - 2012-10-09 15:19:19 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:19:19 --> Controller Class Initialized
DEBUG - 2012-10-09 15:19:19 --> Model Class Initialized
DEBUG - 2012-10-09 15:19:19 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:19:19 --> Helper loaded: form_helper
DEBUG - 2012-10-09 15:19:19 --> Helper loaded: language_helper
DEBUG - 2012-10-09 15:19:19 --> Form Validation Class Initialized
DEBUG - 2012-10-09 15:19:19 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 15:19:19 --> Upload Class Initialized
DEBUG - 2012-10-09 15:19:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 15:19:19 --> Image Lib Class Initialized
ERROR - 2012-10-09 15:19:19 --> Severity: Notice  --> Undefined variable: post /home/jwp/www/justinwylliephotography.com/clients/application/models/pricing_model.php 281
ERROR - 2012-10-09 15:19:19 --> Severity: Notice  --> Trying to get property of non-object /home/jwp/www/justinwylliephotography.com/clients/application/models/pricing_model.php 281
DEBUG - 2012-10-09 15:19:56 --> Config Class Initialized
DEBUG - 2012-10-09 15:19:56 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:19:56 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:19:56 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:19:56 --> URI Class Initialized
DEBUG - 2012-10-09 15:19:56 --> Router Class Initialized
DEBUG - 2012-10-09 15:19:56 --> Output Class Initialized
DEBUG - 2012-10-09 15:19:56 --> Security Class Initialized
DEBUG - 2012-10-09 15:19:56 --> Input Class Initialized
DEBUG - 2012-10-09 15:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:19:56 --> Language Class Initialized
DEBUG - 2012-10-09 15:19:56 --> Loader Class Initialized
DEBUG - 2012-10-09 15:19:56 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:19:56 --> Controller Class Initialized
DEBUG - 2012-10-09 15:19:56 --> Model Class Initialized
DEBUG - 2012-10-09 15:19:56 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:19:56 --> Helper loaded: form_helper
DEBUG - 2012-10-09 15:19:56 --> Helper loaded: language_helper
DEBUG - 2012-10-09 15:19:56 --> Form Validation Class Initialized
DEBUG - 2012-10-09 15:19:56 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 15:19:56 --> Upload Class Initialized
DEBUG - 2012-10-09 15:19:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 15:19:56 --> Image Lib Class Initialized
DEBUG - 2012-10-09 15:19:56 --> Final output sent to browser
DEBUG - 2012-10-09 15:19:56 --> Total execution time: 0.1984
DEBUG - 2012-10-09 15:20:06 --> Config Class Initialized
DEBUG - 2012-10-09 15:20:06 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:20:06 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:20:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:20:06 --> URI Class Initialized
DEBUG - 2012-10-09 15:20:06 --> Router Class Initialized
DEBUG - 2012-10-09 15:20:06 --> Output Class Initialized
DEBUG - 2012-10-09 15:20:06 --> Security Class Initialized
DEBUG - 2012-10-09 15:20:06 --> Input Class Initialized
DEBUG - 2012-10-09 15:20:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:20:06 --> Language Class Initialized
DEBUG - 2012-10-09 15:20:06 --> Loader Class Initialized
DEBUG - 2012-10-09 15:20:06 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:20:06 --> Controller Class Initialized
DEBUG - 2012-10-09 15:20:06 --> Model Class Initialized
DEBUG - 2012-10-09 15:20:06 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:20:06 --> Helper loaded: language_helper
DEBUG - 2012-10-09 15:20:06 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 15:20:10 --> Config Class Initialized
DEBUG - 2012-10-09 15:20:10 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:20:10 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:20:10 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:20:10 --> URI Class Initialized
DEBUG - 2012-10-09 15:20:10 --> Router Class Initialized
DEBUG - 2012-10-09 15:20:10 --> Output Class Initialized
DEBUG - 2012-10-09 15:20:10 --> Security Class Initialized
DEBUG - 2012-10-09 15:20:10 --> Input Class Initialized
DEBUG - 2012-10-09 15:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:20:10 --> Language Class Initialized
DEBUG - 2012-10-09 15:20:10 --> Loader Class Initialized
DEBUG - 2012-10-09 15:20:10 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:20:10 --> Controller Class Initialized
DEBUG - 2012-10-09 15:20:10 --> Model Class Initialized
DEBUG - 2012-10-09 15:20:10 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:20:10 --> Helper loaded: form_helper
DEBUG - 2012-10-09 15:20:10 --> Helper loaded: language_helper
DEBUG - 2012-10-09 15:20:10 --> Form Validation Class Initialized
DEBUG - 2012-10-09 15:20:10 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 15:20:10 --> Upload Class Initialized
DEBUG - 2012-10-09 15:20:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 15:20:10 --> Image Lib Class Initialized
DEBUG - 2012-10-09 15:20:10 --> Final output sent to browser
DEBUG - 2012-10-09 15:20:10 --> Total execution time: 0.1383
DEBUG - 2012-10-09 15:20:25 --> Config Class Initialized
DEBUG - 2012-10-09 15:20:25 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:20:25 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:20:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:20:25 --> URI Class Initialized
DEBUG - 2012-10-09 15:20:25 --> Router Class Initialized
DEBUG - 2012-10-09 15:20:25 --> Output Class Initialized
DEBUG - 2012-10-09 15:20:25 --> Security Class Initialized
DEBUG - 2012-10-09 15:20:25 --> Input Class Initialized
DEBUG - 2012-10-09 15:20:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:20:25 --> Language Class Initialized
DEBUG - 2012-10-09 15:20:25 --> Loader Class Initialized
DEBUG - 2012-10-09 15:20:25 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:20:25 --> Controller Class Initialized
DEBUG - 2012-10-09 15:20:25 --> Model Class Initialized
DEBUG - 2012-10-09 15:20:25 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:20:25 --> Helper loaded: language_helper
DEBUG - 2012-10-09 15:20:25 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 15:20:38 --> Config Class Initialized
DEBUG - 2012-10-09 15:20:38 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:20:38 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:20:38 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:20:38 --> URI Class Initialized
DEBUG - 2012-10-09 15:20:38 --> Router Class Initialized
DEBUG - 2012-10-09 15:20:38 --> Output Class Initialized
DEBUG - 2012-10-09 15:20:38 --> Security Class Initialized
DEBUG - 2012-10-09 15:20:38 --> Input Class Initialized
DEBUG - 2012-10-09 15:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:20:38 --> Language Class Initialized
DEBUG - 2012-10-09 15:20:38 --> Loader Class Initialized
DEBUG - 2012-10-09 15:20:38 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:20:38 --> Controller Class Initialized
DEBUG - 2012-10-09 15:20:38 --> Model Class Initialized
DEBUG - 2012-10-09 15:20:38 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:20:38 --> Helper loaded: form_helper
DEBUG - 2012-10-09 15:20:38 --> Helper loaded: language_helper
DEBUG - 2012-10-09 15:20:38 --> Form Validation Class Initialized
DEBUG - 2012-10-09 15:20:38 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 15:20:38 --> Upload Class Initialized
DEBUG - 2012-10-09 15:20:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 15:20:38 --> Image Lib Class Initialized
DEBUG - 2012-10-09 15:20:38 --> Final output sent to browser
DEBUG - 2012-10-09 15:20:38 --> Total execution time: 0.2284
DEBUG - 2012-10-09 15:21:12 --> Config Class Initialized
DEBUG - 2012-10-09 15:21:12 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:21:12 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:21:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:21:12 --> URI Class Initialized
DEBUG - 2012-10-09 15:21:12 --> Router Class Initialized
DEBUG - 2012-10-09 15:21:12 --> Output Class Initialized
DEBUG - 2012-10-09 15:21:12 --> Security Class Initialized
DEBUG - 2012-10-09 15:21:12 --> Input Class Initialized
DEBUG - 2012-10-09 15:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:21:12 --> Language Class Initialized
DEBUG - 2012-10-09 15:21:12 --> Loader Class Initialized
DEBUG - 2012-10-09 15:21:12 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:21:12 --> Controller Class Initialized
DEBUG - 2012-10-09 15:21:12 --> Model Class Initialized
DEBUG - 2012-10-09 15:21:12 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:21:12 --> Helper loaded: language_helper
DEBUG - 2012-10-09 15:21:12 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 15:21:14 --> Config Class Initialized
DEBUG - 2012-10-09 15:21:14 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:21:14 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:21:14 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:21:14 --> URI Class Initialized
DEBUG - 2012-10-09 15:21:14 --> Router Class Initialized
DEBUG - 2012-10-09 15:21:14 --> Output Class Initialized
DEBUG - 2012-10-09 15:21:14 --> Security Class Initialized
DEBUG - 2012-10-09 15:21:14 --> Input Class Initialized
DEBUG - 2012-10-09 15:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:21:14 --> Language Class Initialized
DEBUG - 2012-10-09 15:21:14 --> Loader Class Initialized
DEBUG - 2012-10-09 15:21:14 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:21:14 --> Controller Class Initialized
DEBUG - 2012-10-09 15:21:14 --> Model Class Initialized
DEBUG - 2012-10-09 15:21:14 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:21:14 --> Helper loaded: form_helper
DEBUG - 2012-10-09 15:21:14 --> Helper loaded: language_helper
DEBUG - 2012-10-09 15:21:14 --> Form Validation Class Initialized
DEBUG - 2012-10-09 15:21:14 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 15:21:14 --> Upload Class Initialized
DEBUG - 2012-10-09 15:21:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 15:21:14 --> Image Lib Class Initialized
DEBUG - 2012-10-09 15:21:14 --> Final output sent to browser
DEBUG - 2012-10-09 15:21:14 --> Total execution time: 0.4160
DEBUG - 2012-10-09 15:23:43 --> Config Class Initialized
DEBUG - 2012-10-09 15:23:43 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:23:43 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:23:43 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:23:43 --> URI Class Initialized
DEBUG - 2012-10-09 15:23:43 --> Router Class Initialized
DEBUG - 2012-10-09 15:23:43 --> Output Class Initialized
DEBUG - 2012-10-09 15:23:43 --> Security Class Initialized
DEBUG - 2012-10-09 15:23:43 --> Input Class Initialized
DEBUG - 2012-10-09 15:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:23:43 --> Language Class Initialized
DEBUG - 2012-10-09 15:23:43 --> Loader Class Initialized
DEBUG - 2012-10-09 15:23:43 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:23:43 --> Controller Class Initialized
DEBUG - 2012-10-09 15:23:43 --> Model Class Initialized
DEBUG - 2012-10-09 15:23:43 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:23:43 --> Helper loaded: form_helper
DEBUG - 2012-10-09 15:23:43 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 15:23:43 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 15:23:43 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 15:23:43 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 15:23:43 --> Final output sent to browser
DEBUG - 2012-10-09 15:23:43 --> Total execution time: 0.0884
DEBUG - 2012-10-09 15:23:45 --> Config Class Initialized
DEBUG - 2012-10-09 15:23:45 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:23:45 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:23:45 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:23:45 --> URI Class Initialized
DEBUG - 2012-10-09 15:23:45 --> Router Class Initialized
ERROR - 2012-10-09 15:23:45 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:23:45 --> Config Class Initialized
DEBUG - 2012-10-09 15:23:45 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:23:45 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:23:45 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:23:45 --> URI Class Initialized
DEBUG - 2012-10-09 15:23:45 --> Router Class Initialized
ERROR - 2012-10-09 15:23:45 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:23:45 --> Config Class Initialized
DEBUG - 2012-10-09 15:23:45 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:23:45 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:23:45 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:23:45 --> URI Class Initialized
DEBUG - 2012-10-09 15:23:45 --> Router Class Initialized
ERROR - 2012-10-09 15:23:45 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:23:47 --> Config Class Initialized
DEBUG - 2012-10-09 15:23:47 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:23:47 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:23:47 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:23:47 --> URI Class Initialized
DEBUG - 2012-10-09 15:23:47 --> Router Class Initialized
DEBUG - 2012-10-09 15:23:47 --> Output Class Initialized
DEBUG - 2012-10-09 15:23:47 --> Security Class Initialized
DEBUG - 2012-10-09 15:23:47 --> Input Class Initialized
DEBUG - 2012-10-09 15:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:23:47 --> Language Class Initialized
DEBUG - 2012-10-09 15:23:47 --> Loader Class Initialized
DEBUG - 2012-10-09 15:23:47 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:23:47 --> Controller Class Initialized
DEBUG - 2012-10-09 15:23:47 --> Model Class Initialized
DEBUG - 2012-10-09 15:23:47 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:23:47 --> Helper loaded: language_helper
DEBUG - 2012-10-09 15:23:47 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 15:23:57 --> Config Class Initialized
DEBUG - 2012-10-09 15:23:57 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:23:57 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:23:57 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:23:57 --> URI Class Initialized
DEBUG - 2012-10-09 15:23:57 --> Router Class Initialized
DEBUG - 2012-10-09 15:23:57 --> Output Class Initialized
DEBUG - 2012-10-09 15:23:57 --> Security Class Initialized
DEBUG - 2012-10-09 15:23:57 --> Input Class Initialized
DEBUG - 2012-10-09 15:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:23:57 --> Language Class Initialized
DEBUG - 2012-10-09 15:23:57 --> Loader Class Initialized
DEBUG - 2012-10-09 15:23:57 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:23:57 --> Controller Class Initialized
DEBUG - 2012-10-09 15:23:57 --> Model Class Initialized
DEBUG - 2012-10-09 15:23:57 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:24:52 --> Config Class Initialized
DEBUG - 2012-10-09 15:24:52 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:24:52 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:24:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:24:52 --> URI Class Initialized
DEBUG - 2012-10-09 15:24:52 --> Router Class Initialized
DEBUG - 2012-10-09 15:24:52 --> Output Class Initialized
DEBUG - 2012-10-09 15:24:52 --> Security Class Initialized
DEBUG - 2012-10-09 15:24:52 --> Input Class Initialized
DEBUG - 2012-10-09 15:24:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:24:52 --> Language Class Initialized
DEBUG - 2012-10-09 15:24:52 --> Loader Class Initialized
DEBUG - 2012-10-09 15:24:52 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:24:52 --> Controller Class Initialized
DEBUG - 2012-10-09 15:24:52 --> Model Class Initialized
DEBUG - 2012-10-09 15:24:52 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:24:52 --> Helper loaded: form_helper
DEBUG - 2012-10-09 15:24:52 --> Helper loaded: language_helper
DEBUG - 2012-10-09 15:24:52 --> Form Validation Class Initialized
DEBUG - 2012-10-09 15:24:52 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 15:24:52 --> Upload Class Initialized
DEBUG - 2012-10-09 15:24:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 15:24:52 --> Language file loaded: language/english/upload_lang.php
ERROR - 2012-10-09 15:24:52 --> You did not select a file to upload.
DEBUG - 2012-10-09 15:25:54 --> Config Class Initialized
DEBUG - 2012-10-09 15:25:54 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:25:54 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:25:54 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:25:54 --> URI Class Initialized
DEBUG - 2012-10-09 15:25:54 --> Router Class Initialized
DEBUG - 2012-10-09 15:25:54 --> Output Class Initialized
DEBUG - 2012-10-09 15:25:54 --> Security Class Initialized
DEBUG - 2012-10-09 15:25:54 --> Input Class Initialized
DEBUG - 2012-10-09 15:25:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:25:54 --> Language Class Initialized
DEBUG - 2012-10-09 15:25:54 --> Loader Class Initialized
DEBUG - 2012-10-09 15:25:54 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:25:54 --> Controller Class Initialized
DEBUG - 2012-10-09 15:25:54 --> Model Class Initialized
DEBUG - 2012-10-09 15:25:54 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:25:55 --> Helper loaded: form_helper
DEBUG - 2012-10-09 15:25:55 --> Helper loaded: language_helper
DEBUG - 2012-10-09 15:25:55 --> Form Validation Class Initialized
DEBUG - 2012-10-09 15:25:55 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 15:25:55 --> Upload Class Initialized
DEBUG - 2012-10-09 15:25:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 15:25:55 --> Image Lib Class Initialized
DEBUG - 2012-10-09 15:25:55 --> Final output sent to browser
DEBUG - 2012-10-09 15:25:55 --> Total execution time: 0.2936
DEBUG - 2012-10-09 15:29:06 --> Config Class Initialized
DEBUG - 2012-10-09 15:29:06 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:29:06 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:29:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:29:06 --> URI Class Initialized
DEBUG - 2012-10-09 15:29:06 --> Router Class Initialized
DEBUG - 2012-10-09 15:29:06 --> Output Class Initialized
DEBUG - 2012-10-09 15:29:06 --> Security Class Initialized
DEBUG - 2012-10-09 15:29:06 --> Input Class Initialized
DEBUG - 2012-10-09 15:29:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:29:06 --> Language Class Initialized
DEBUG - 2012-10-09 15:29:06 --> Loader Class Initialized
DEBUG - 2012-10-09 15:29:06 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:29:06 --> Controller Class Initialized
DEBUG - 2012-10-09 15:29:06 --> Model Class Initialized
DEBUG - 2012-10-09 15:29:06 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:29:06 --> Helper loaded: form_helper
DEBUG - 2012-10-09 15:29:06 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 15:29:06 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 15:29:06 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 15:29:06 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 15:29:06 --> Final output sent to browser
DEBUG - 2012-10-09 15:29:06 --> Total execution time: 0.0459
DEBUG - 2012-10-09 15:29:08 --> Config Class Initialized
DEBUG - 2012-10-09 15:29:08 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:29:08 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:29:08 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:29:08 --> URI Class Initialized
DEBUG - 2012-10-09 15:29:08 --> Router Class Initialized
ERROR - 2012-10-09 15:29:08 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:29:08 --> Config Class Initialized
DEBUG - 2012-10-09 15:29:08 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:29:08 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:29:08 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:29:08 --> URI Class Initialized
DEBUG - 2012-10-09 15:29:08 --> Router Class Initialized
ERROR - 2012-10-09 15:29:08 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:29:08 --> Config Class Initialized
DEBUG - 2012-10-09 15:29:08 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:29:08 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:29:08 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:29:08 --> URI Class Initialized
DEBUG - 2012-10-09 15:29:08 --> Router Class Initialized
ERROR - 2012-10-09 15:29:08 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:29:20 --> Config Class Initialized
DEBUG - 2012-10-09 15:29:20 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:29:20 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:29:20 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:29:20 --> URI Class Initialized
DEBUG - 2012-10-09 15:29:20 --> Router Class Initialized
DEBUG - 2012-10-09 15:29:20 --> Output Class Initialized
DEBUG - 2012-10-09 15:29:20 --> Security Class Initialized
DEBUG - 2012-10-09 15:29:20 --> Input Class Initialized
DEBUG - 2012-10-09 15:29:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:29:20 --> Language Class Initialized
DEBUG - 2012-10-09 15:29:20 --> Loader Class Initialized
DEBUG - 2012-10-09 15:29:20 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:29:20 --> Controller Class Initialized
DEBUG - 2012-10-09 15:29:20 --> Model Class Initialized
DEBUG - 2012-10-09 15:29:20 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:29:20 --> Helper loaded: language_helper
DEBUG - 2012-10-09 15:29:20 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 15:29:25 --> Config Class Initialized
DEBUG - 2012-10-09 15:29:25 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:29:25 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:29:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:29:25 --> URI Class Initialized
DEBUG - 2012-10-09 15:29:25 --> Router Class Initialized
DEBUG - 2012-10-09 15:29:25 --> Output Class Initialized
DEBUG - 2012-10-09 15:29:25 --> Security Class Initialized
DEBUG - 2012-10-09 15:29:25 --> Input Class Initialized
DEBUG - 2012-10-09 15:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:29:25 --> Language Class Initialized
DEBUG - 2012-10-09 15:29:25 --> Loader Class Initialized
DEBUG - 2012-10-09 15:29:25 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:29:25 --> Controller Class Initialized
DEBUG - 2012-10-09 15:29:25 --> Model Class Initialized
DEBUG - 2012-10-09 15:29:25 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:29:25 --> Helper loaded: form_helper
DEBUG - 2012-10-09 15:29:25 --> Helper loaded: language_helper
DEBUG - 2012-10-09 15:29:25 --> Form Validation Class Initialized
DEBUG - 2012-10-09 15:29:25 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 15:29:25 --> Upload Class Initialized
DEBUG - 2012-10-09 15:29:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 15:29:25 --> Image Lib Class Initialized
DEBUG - 2012-10-09 15:29:26 --> Final output sent to browser
DEBUG - 2012-10-09 15:29:26 --> Total execution time: 0.3857
DEBUG - 2012-10-09 15:32:43 --> Config Class Initialized
DEBUG - 2012-10-09 15:32:43 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:32:43 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:32:43 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:32:43 --> URI Class Initialized
DEBUG - 2012-10-09 15:32:43 --> Router Class Initialized
DEBUG - 2012-10-09 15:32:43 --> Output Class Initialized
DEBUG - 2012-10-09 15:32:43 --> Security Class Initialized
DEBUG - 2012-10-09 15:32:43 --> Input Class Initialized
DEBUG - 2012-10-09 15:32:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:32:43 --> Language Class Initialized
DEBUG - 2012-10-09 15:32:43 --> Loader Class Initialized
DEBUG - 2012-10-09 15:32:43 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:32:43 --> Controller Class Initialized
DEBUG - 2012-10-09 15:32:43 --> Model Class Initialized
DEBUG - 2012-10-09 15:32:43 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:32:43 --> Helper loaded: form_helper
DEBUG - 2012-10-09 15:32:43 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 15:32:43 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 15:32:43 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 15:32:43 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 15:32:43 --> Final output sent to browser
DEBUG - 2012-10-09 15:32:43 --> Total execution time: 0.0517
DEBUG - 2012-10-09 15:32:45 --> Config Class Initialized
DEBUG - 2012-10-09 15:32:45 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:32:45 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:32:45 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:32:45 --> URI Class Initialized
DEBUG - 2012-10-09 15:32:45 --> Router Class Initialized
ERROR - 2012-10-09 15:32:45 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:32:45 --> Config Class Initialized
DEBUG - 2012-10-09 15:32:45 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:32:45 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:32:45 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:32:45 --> URI Class Initialized
DEBUG - 2012-10-09 15:32:45 --> Router Class Initialized
ERROR - 2012-10-09 15:32:45 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:32:45 --> Config Class Initialized
DEBUG - 2012-10-09 15:32:45 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:32:45 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:32:45 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:32:45 --> URI Class Initialized
DEBUG - 2012-10-09 15:32:45 --> Router Class Initialized
ERROR - 2012-10-09 15:32:45 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:32:52 --> Config Class Initialized
DEBUG - 2012-10-09 15:32:52 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:32:52 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:32:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:32:52 --> URI Class Initialized
DEBUG - 2012-10-09 15:32:52 --> Router Class Initialized
DEBUG - 2012-10-09 15:32:52 --> Output Class Initialized
DEBUG - 2012-10-09 15:32:52 --> Security Class Initialized
DEBUG - 2012-10-09 15:32:52 --> Input Class Initialized
DEBUG - 2012-10-09 15:32:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:32:52 --> Language Class Initialized
DEBUG - 2012-10-09 15:32:52 --> Loader Class Initialized
DEBUG - 2012-10-09 15:32:52 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:32:52 --> Controller Class Initialized
DEBUG - 2012-10-09 15:32:52 --> Model Class Initialized
DEBUG - 2012-10-09 15:32:52 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:32:52 --> Helper loaded: language_helper
DEBUG - 2012-10-09 15:32:52 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 15:33:16 --> Config Class Initialized
DEBUG - 2012-10-09 15:33:16 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:33:16 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:33:16 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:33:16 --> URI Class Initialized
DEBUG - 2012-10-09 15:33:16 --> Router Class Initialized
DEBUG - 2012-10-09 15:33:16 --> Output Class Initialized
DEBUG - 2012-10-09 15:33:16 --> Security Class Initialized
DEBUG - 2012-10-09 15:33:16 --> Input Class Initialized
DEBUG - 2012-10-09 15:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:33:16 --> Language Class Initialized
DEBUG - 2012-10-09 15:33:16 --> Loader Class Initialized
DEBUG - 2012-10-09 15:33:16 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:33:16 --> Controller Class Initialized
DEBUG - 2012-10-09 15:33:16 --> Model Class Initialized
DEBUG - 2012-10-09 15:33:16 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:33:16 --> Helper loaded: form_helper
DEBUG - 2012-10-09 15:33:16 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 15:33:16 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 15:33:16 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 15:33:16 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 15:33:16 --> Final output sent to browser
DEBUG - 2012-10-09 15:33:16 --> Total execution time: 0.0406
DEBUG - 2012-10-09 15:33:17 --> Config Class Initialized
DEBUG - 2012-10-09 15:33:17 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:33:17 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:33:17 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:33:17 --> URI Class Initialized
DEBUG - 2012-10-09 15:33:17 --> Router Class Initialized
ERROR - 2012-10-09 15:33:17 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:33:17 --> Config Class Initialized
DEBUG - 2012-10-09 15:33:17 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:33:17 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:33:17 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:33:17 --> URI Class Initialized
DEBUG - 2012-10-09 15:33:17 --> Router Class Initialized
ERROR - 2012-10-09 15:33:17 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:33:17 --> Config Class Initialized
DEBUG - 2012-10-09 15:33:17 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:33:17 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:33:17 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:33:17 --> URI Class Initialized
DEBUG - 2012-10-09 15:33:17 --> Router Class Initialized
ERROR - 2012-10-09 15:33:17 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:34:13 --> Config Class Initialized
DEBUG - 2012-10-09 15:34:13 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:34:13 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:34:13 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:34:13 --> URI Class Initialized
DEBUG - 2012-10-09 15:34:13 --> Router Class Initialized
DEBUG - 2012-10-09 15:34:13 --> Output Class Initialized
DEBUG - 2012-10-09 15:34:13 --> Security Class Initialized
DEBUG - 2012-10-09 15:34:13 --> Input Class Initialized
DEBUG - 2012-10-09 15:34:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:34:13 --> Language Class Initialized
DEBUG - 2012-10-09 15:34:13 --> Loader Class Initialized
DEBUG - 2012-10-09 15:34:13 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:34:13 --> Controller Class Initialized
DEBUG - 2012-10-09 15:34:13 --> Model Class Initialized
DEBUG - 2012-10-09 15:34:13 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:34:13 --> Helper loaded: language_helper
DEBUG - 2012-10-09 15:34:13 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 15:38:38 --> Config Class Initialized
DEBUG - 2012-10-09 15:38:38 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:38:38 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:38:38 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:38:38 --> URI Class Initialized
DEBUG - 2012-10-09 15:38:38 --> Router Class Initialized
DEBUG - 2012-10-09 15:38:38 --> Output Class Initialized
DEBUG - 2012-10-09 15:38:38 --> Security Class Initialized
DEBUG - 2012-10-09 15:38:38 --> Input Class Initialized
DEBUG - 2012-10-09 15:38:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:38:38 --> Language Class Initialized
DEBUG - 2012-10-09 15:38:38 --> Loader Class Initialized
DEBUG - 2012-10-09 15:38:38 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:38:38 --> Controller Class Initialized
DEBUG - 2012-10-09 15:38:38 --> Model Class Initialized
DEBUG - 2012-10-09 15:38:38 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:38:38 --> Helper loaded: form_helper
DEBUG - 2012-10-09 15:38:38 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 15:38:38 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 15:38:38 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 15:38:38 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 15:38:38 --> Final output sent to browser
DEBUG - 2012-10-09 15:38:38 --> Total execution time: 0.0398
DEBUG - 2012-10-09 15:38:40 --> Config Class Initialized
DEBUG - 2012-10-09 15:38:40 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:38:40 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:38:40 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:38:40 --> URI Class Initialized
DEBUG - 2012-10-09 15:38:40 --> Router Class Initialized
ERROR - 2012-10-09 15:38:40 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:38:40 --> Config Class Initialized
DEBUG - 2012-10-09 15:38:40 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:38:40 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:38:40 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:38:40 --> URI Class Initialized
DEBUG - 2012-10-09 15:38:40 --> Router Class Initialized
ERROR - 2012-10-09 15:38:40 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:38:40 --> Config Class Initialized
DEBUG - 2012-10-09 15:38:40 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:38:40 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:38:40 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:38:40 --> URI Class Initialized
DEBUG - 2012-10-09 15:38:40 --> Router Class Initialized
ERROR - 2012-10-09 15:38:40 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:38:53 --> Config Class Initialized
DEBUG - 2012-10-09 15:38:53 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:38:53 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:38:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:38:53 --> URI Class Initialized
DEBUG - 2012-10-09 15:38:53 --> Router Class Initialized
DEBUG - 2012-10-09 15:38:53 --> Output Class Initialized
DEBUG - 2012-10-09 15:38:53 --> Security Class Initialized
DEBUG - 2012-10-09 15:38:53 --> Input Class Initialized
DEBUG - 2012-10-09 15:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:38:53 --> Language Class Initialized
DEBUG - 2012-10-09 15:38:53 --> Loader Class Initialized
DEBUG - 2012-10-09 15:38:53 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:38:53 --> Controller Class Initialized
DEBUG - 2012-10-09 15:38:53 --> Model Class Initialized
DEBUG - 2012-10-09 15:38:53 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:38:53 --> Helper loaded: language_helper
DEBUG - 2012-10-09 15:38:53 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 15:39:35 --> Config Class Initialized
DEBUG - 2012-10-09 15:39:35 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:39:35 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:39:35 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:39:35 --> URI Class Initialized
DEBUG - 2012-10-09 15:39:35 --> Router Class Initialized
DEBUG - 2012-10-09 15:39:35 --> Output Class Initialized
DEBUG - 2012-10-09 15:39:35 --> Security Class Initialized
DEBUG - 2012-10-09 15:39:35 --> Input Class Initialized
DEBUG - 2012-10-09 15:39:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:39:35 --> Language Class Initialized
DEBUG - 2012-10-09 15:39:35 --> Loader Class Initialized
DEBUG - 2012-10-09 15:39:35 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:39:35 --> Controller Class Initialized
DEBUG - 2012-10-09 15:39:35 --> Model Class Initialized
DEBUG - 2012-10-09 15:39:35 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:39:35 --> Helper loaded: form_helper
DEBUG - 2012-10-09 15:39:35 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 15:39:35 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 15:39:35 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 15:39:35 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 15:39:35 --> Final output sent to browser
DEBUG - 2012-10-09 15:39:35 --> Total execution time: 0.0404
DEBUG - 2012-10-09 15:39:37 --> Config Class Initialized
DEBUG - 2012-10-09 15:39:37 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:39:37 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:39:37 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:39:37 --> URI Class Initialized
DEBUG - 2012-10-09 15:39:37 --> Router Class Initialized
ERROR - 2012-10-09 15:39:37 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:39:37 --> Config Class Initialized
DEBUG - 2012-10-09 15:39:37 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:39:37 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:39:37 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:39:37 --> URI Class Initialized
DEBUG - 2012-10-09 15:39:37 --> Router Class Initialized
ERROR - 2012-10-09 15:39:37 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:39:37 --> Config Class Initialized
DEBUG - 2012-10-09 15:39:37 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:39:37 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:39:37 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:39:37 --> URI Class Initialized
DEBUG - 2012-10-09 15:39:37 --> Router Class Initialized
ERROR - 2012-10-09 15:39:37 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:39:40 --> Config Class Initialized
DEBUG - 2012-10-09 15:39:40 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:39:40 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:39:40 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:39:40 --> URI Class Initialized
DEBUG - 2012-10-09 15:39:40 --> Router Class Initialized
DEBUG - 2012-10-09 15:39:40 --> Output Class Initialized
DEBUG - 2012-10-09 15:39:40 --> Security Class Initialized
DEBUG - 2012-10-09 15:39:40 --> Input Class Initialized
DEBUG - 2012-10-09 15:39:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:39:40 --> Language Class Initialized
DEBUG - 2012-10-09 15:39:40 --> Loader Class Initialized
DEBUG - 2012-10-09 15:39:40 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:39:40 --> Controller Class Initialized
DEBUG - 2012-10-09 15:39:40 --> Model Class Initialized
DEBUG - 2012-10-09 15:39:40 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:39:40 --> Helper loaded: language_helper
DEBUG - 2012-10-09 15:39:40 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 15:41:41 --> Config Class Initialized
DEBUG - 2012-10-09 15:41:41 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:41:41 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:41:41 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:41:41 --> URI Class Initialized
DEBUG - 2012-10-09 15:41:41 --> Router Class Initialized
DEBUG - 2012-10-09 15:41:41 --> Output Class Initialized
DEBUG - 2012-10-09 15:41:41 --> Security Class Initialized
DEBUG - 2012-10-09 15:41:41 --> Input Class Initialized
DEBUG - 2012-10-09 15:41:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:41:41 --> Language Class Initialized
DEBUG - 2012-10-09 15:41:41 --> Loader Class Initialized
DEBUG - 2012-10-09 15:41:41 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:41:41 --> Controller Class Initialized
DEBUG - 2012-10-09 15:41:41 --> Model Class Initialized
DEBUG - 2012-10-09 15:41:41 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:41:41 --> Helper loaded: form_helper
DEBUG - 2012-10-09 15:41:41 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 15:41:41 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 15:41:41 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 15:41:41 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 15:41:41 --> Final output sent to browser
DEBUG - 2012-10-09 15:41:41 --> Total execution time: 0.0428
DEBUG - 2012-10-09 15:41:43 --> Config Class Initialized
DEBUG - 2012-10-09 15:41:43 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:41:43 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:41:43 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:41:43 --> URI Class Initialized
DEBUG - 2012-10-09 15:41:43 --> Router Class Initialized
ERROR - 2012-10-09 15:41:43 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:41:43 --> Config Class Initialized
DEBUG - 2012-10-09 15:41:43 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:41:43 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:41:43 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:41:43 --> URI Class Initialized
DEBUG - 2012-10-09 15:41:43 --> Router Class Initialized
ERROR - 2012-10-09 15:41:43 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:41:43 --> Config Class Initialized
DEBUG - 2012-10-09 15:41:43 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:41:43 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:41:43 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:41:43 --> URI Class Initialized
DEBUG - 2012-10-09 15:41:43 --> Router Class Initialized
ERROR - 2012-10-09 15:41:43 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:41:44 --> Config Class Initialized
DEBUG - 2012-10-09 15:41:44 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:41:44 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:41:44 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:41:44 --> URI Class Initialized
DEBUG - 2012-10-09 15:41:44 --> Router Class Initialized
DEBUG - 2012-10-09 15:41:44 --> Output Class Initialized
DEBUG - 2012-10-09 15:41:44 --> Security Class Initialized
DEBUG - 2012-10-09 15:41:44 --> Input Class Initialized
DEBUG - 2012-10-09 15:41:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:41:44 --> Language Class Initialized
DEBUG - 2012-10-09 15:41:44 --> Loader Class Initialized
DEBUG - 2012-10-09 15:41:44 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:41:44 --> Controller Class Initialized
DEBUG - 2012-10-09 15:41:44 --> Model Class Initialized
DEBUG - 2012-10-09 15:41:44 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:41:44 --> Helper loaded: language_helper
DEBUG - 2012-10-09 15:41:44 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 15:44:10 --> Config Class Initialized
DEBUG - 2012-10-09 15:44:10 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:44:10 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:44:10 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:44:10 --> URI Class Initialized
DEBUG - 2012-10-09 15:44:10 --> Router Class Initialized
DEBUG - 2012-10-09 15:44:10 --> Output Class Initialized
DEBUG - 2012-10-09 15:44:10 --> Security Class Initialized
DEBUG - 2012-10-09 15:44:10 --> Input Class Initialized
DEBUG - 2012-10-09 15:44:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:44:10 --> Language Class Initialized
DEBUG - 2012-10-09 15:44:10 --> Loader Class Initialized
DEBUG - 2012-10-09 15:44:10 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:44:10 --> Controller Class Initialized
DEBUG - 2012-10-09 15:44:10 --> Model Class Initialized
DEBUG - 2012-10-09 15:44:10 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:44:10 --> Helper loaded: form_helper
DEBUG - 2012-10-09 15:44:10 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 15:44:10 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 15:44:10 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 15:44:10 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 15:44:10 --> Final output sent to browser
DEBUG - 2012-10-09 15:44:10 --> Total execution time: 0.0503
DEBUG - 2012-10-09 15:44:12 --> Config Class Initialized
DEBUG - 2012-10-09 15:44:12 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:44:12 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:44:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:44:12 --> URI Class Initialized
DEBUG - 2012-10-09 15:44:12 --> Router Class Initialized
ERROR - 2012-10-09 15:44:12 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:44:12 --> Config Class Initialized
DEBUG - 2012-10-09 15:44:12 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:44:12 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:44:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:44:12 --> URI Class Initialized
DEBUG - 2012-10-09 15:44:12 --> Router Class Initialized
ERROR - 2012-10-09 15:44:12 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:44:12 --> Config Class Initialized
DEBUG - 2012-10-09 15:44:12 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:44:12 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:44:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:44:12 --> URI Class Initialized
DEBUG - 2012-10-09 15:44:12 --> Router Class Initialized
ERROR - 2012-10-09 15:44:12 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:44:32 --> Config Class Initialized
DEBUG - 2012-10-09 15:44:32 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:44:32 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:44:32 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:44:32 --> URI Class Initialized
DEBUG - 2012-10-09 15:44:32 --> Router Class Initialized
DEBUG - 2012-10-09 15:44:32 --> Output Class Initialized
DEBUG - 2012-10-09 15:44:32 --> Security Class Initialized
DEBUG - 2012-10-09 15:44:32 --> Input Class Initialized
DEBUG - 2012-10-09 15:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:44:32 --> Language Class Initialized
DEBUG - 2012-10-09 15:44:32 --> Loader Class Initialized
DEBUG - 2012-10-09 15:44:32 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:44:32 --> Controller Class Initialized
DEBUG - 2012-10-09 15:44:32 --> Model Class Initialized
DEBUG - 2012-10-09 15:44:32 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:44:32 --> Helper loaded: language_helper
DEBUG - 2012-10-09 15:44:32 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 15:44:48 --> Config Class Initialized
DEBUG - 2012-10-09 15:44:48 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:44:48 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:44:48 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:44:48 --> URI Class Initialized
DEBUG - 2012-10-09 15:44:48 --> Router Class Initialized
DEBUG - 2012-10-09 15:44:48 --> Output Class Initialized
DEBUG - 2012-10-09 15:44:48 --> Security Class Initialized
DEBUG - 2012-10-09 15:44:48 --> Input Class Initialized
DEBUG - 2012-10-09 15:44:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:44:48 --> Language Class Initialized
DEBUG - 2012-10-09 15:44:48 --> Loader Class Initialized
DEBUG - 2012-10-09 15:44:48 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:44:48 --> Controller Class Initialized
DEBUG - 2012-10-09 15:44:48 --> Model Class Initialized
DEBUG - 2012-10-09 15:44:48 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:44:48 --> Helper loaded: form_helper
DEBUG - 2012-10-09 15:44:48 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 15:44:48 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 15:44:48 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 15:44:48 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 15:44:48 --> Final output sent to browser
DEBUG - 2012-10-09 15:44:48 --> Total execution time: 0.0434
DEBUG - 2012-10-09 15:44:49 --> Config Class Initialized
DEBUG - 2012-10-09 15:44:49 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:44:49 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:44:49 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:44:49 --> URI Class Initialized
DEBUG - 2012-10-09 15:44:49 --> Router Class Initialized
ERROR - 2012-10-09 15:44:49 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:44:49 --> Config Class Initialized
DEBUG - 2012-10-09 15:44:49 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:44:49 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:44:49 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:44:49 --> URI Class Initialized
DEBUG - 2012-10-09 15:44:50 --> Config Class Initialized
DEBUG - 2012-10-09 15:44:50 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:44:50 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:44:50 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:44:50 --> URI Class Initialized
DEBUG - 2012-10-09 15:44:50 --> Router Class Initialized
ERROR - 2012-10-09 15:44:50 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:44:50 --> Router Class Initialized
ERROR - 2012-10-09 15:44:50 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:53:40 --> Config Class Initialized
DEBUG - 2012-10-09 15:53:40 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:53:40 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:53:40 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:53:40 --> URI Class Initialized
DEBUG - 2012-10-09 15:53:40 --> Router Class Initialized
DEBUG - 2012-10-09 15:53:40 --> Output Class Initialized
DEBUG - 2012-10-09 15:53:40 --> Security Class Initialized
DEBUG - 2012-10-09 15:53:40 --> Input Class Initialized
DEBUG - 2012-10-09 15:53:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:53:40 --> Language Class Initialized
DEBUG - 2012-10-09 15:53:40 --> Loader Class Initialized
DEBUG - 2012-10-09 15:53:40 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:53:40 --> Controller Class Initialized
DEBUG - 2012-10-09 15:53:40 --> Model Class Initialized
DEBUG - 2012-10-09 15:53:40 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:53:40 --> Helper loaded: form_helper
DEBUG - 2012-10-09 15:53:40 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 15:53:40 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 15:53:40 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 15:53:40 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 15:53:40 --> Final output sent to browser
DEBUG - 2012-10-09 15:53:40 --> Total execution time: 0.0504
DEBUG - 2012-10-09 15:53:42 --> Config Class Initialized
DEBUG - 2012-10-09 15:53:42 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:53:42 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:53:42 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:53:42 --> URI Class Initialized
DEBUG - 2012-10-09 15:53:42 --> Router Class Initialized
ERROR - 2012-10-09 15:53:42 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:53:42 --> Config Class Initialized
DEBUG - 2012-10-09 15:53:42 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:53:42 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:53:42 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:53:42 --> URI Class Initialized
DEBUG - 2012-10-09 15:53:42 --> Router Class Initialized
ERROR - 2012-10-09 15:53:42 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:53:42 --> Config Class Initialized
DEBUG - 2012-10-09 15:53:42 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:53:42 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:53:42 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:53:42 --> URI Class Initialized
DEBUG - 2012-10-09 15:53:42 --> Router Class Initialized
ERROR - 2012-10-09 15:53:42 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:54:11 --> Config Class Initialized
DEBUG - 2012-10-09 15:54:11 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:54:11 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:54:11 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:54:11 --> URI Class Initialized
DEBUG - 2012-10-09 15:54:11 --> Router Class Initialized
DEBUG - 2012-10-09 15:54:11 --> Output Class Initialized
DEBUG - 2012-10-09 15:54:11 --> Security Class Initialized
DEBUG - 2012-10-09 15:54:11 --> Input Class Initialized
DEBUG - 2012-10-09 15:54:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:54:11 --> Language Class Initialized
DEBUG - 2012-10-09 15:54:11 --> Loader Class Initialized
DEBUG - 2012-10-09 15:54:11 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:54:11 --> Controller Class Initialized
DEBUG - 2012-10-09 15:54:11 --> Model Class Initialized
DEBUG - 2012-10-09 15:54:11 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:54:11 --> Helper loaded: form_helper
DEBUG - 2012-10-09 15:54:11 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 15:54:11 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 15:54:11 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 15:54:11 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 15:54:11 --> Final output sent to browser
DEBUG - 2012-10-09 15:54:11 --> Total execution time: 0.0408
DEBUG - 2012-10-09 15:54:13 --> Config Class Initialized
DEBUG - 2012-10-09 15:54:13 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:54:13 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:54:13 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:54:13 --> URI Class Initialized
DEBUG - 2012-10-09 15:54:13 --> Router Class Initialized
ERROR - 2012-10-09 15:54:13 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:54:13 --> Config Class Initialized
DEBUG - 2012-10-09 15:54:13 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:54:13 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:54:13 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:54:13 --> URI Class Initialized
DEBUG - 2012-10-09 15:54:13 --> Router Class Initialized
ERROR - 2012-10-09 15:54:13 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:54:13 --> Config Class Initialized
DEBUG - 2012-10-09 15:54:13 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:54:13 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:54:13 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:54:13 --> URI Class Initialized
DEBUG - 2012-10-09 15:54:13 --> Router Class Initialized
ERROR - 2012-10-09 15:54:13 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:54:14 --> Config Class Initialized
DEBUG - 2012-10-09 15:54:14 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:54:14 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:54:14 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:54:14 --> URI Class Initialized
DEBUG - 2012-10-09 15:54:14 --> Router Class Initialized
DEBUG - 2012-10-09 15:54:14 --> Output Class Initialized
DEBUG - 2012-10-09 15:54:14 --> Security Class Initialized
DEBUG - 2012-10-09 15:54:14 --> Input Class Initialized
DEBUG - 2012-10-09 15:54:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:54:14 --> Language Class Initialized
DEBUG - 2012-10-09 15:54:14 --> Loader Class Initialized
DEBUG - 2012-10-09 15:54:14 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:54:14 --> Controller Class Initialized
DEBUG - 2012-10-09 15:54:14 --> Model Class Initialized
DEBUG - 2012-10-09 15:54:14 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:54:14 --> Helper loaded: language_helper
DEBUG - 2012-10-09 15:54:14 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 15:56:23 --> Config Class Initialized
DEBUG - 2012-10-09 15:56:23 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:56:23 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:56:23 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:56:23 --> URI Class Initialized
DEBUG - 2012-10-09 15:56:23 --> Router Class Initialized
DEBUG - 2012-10-09 15:56:23 --> Output Class Initialized
DEBUG - 2012-10-09 15:56:23 --> Security Class Initialized
DEBUG - 2012-10-09 15:56:23 --> Input Class Initialized
DEBUG - 2012-10-09 15:56:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:56:23 --> Language Class Initialized
DEBUG - 2012-10-09 15:56:23 --> Loader Class Initialized
DEBUG - 2012-10-09 15:56:23 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:56:23 --> Controller Class Initialized
DEBUG - 2012-10-09 15:56:23 --> Model Class Initialized
DEBUG - 2012-10-09 15:56:23 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:56:23 --> Helper loaded: form_helper
DEBUG - 2012-10-09 15:56:23 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 15:56:23 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 15:56:23 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 15:56:23 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 15:56:23 --> Final output sent to browser
DEBUG - 2012-10-09 15:56:23 --> Total execution time: 0.0398
DEBUG - 2012-10-09 15:56:25 --> Config Class Initialized
DEBUG - 2012-10-09 15:56:25 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:56:25 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:56:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:56:25 --> URI Class Initialized
DEBUG - 2012-10-09 15:56:25 --> Router Class Initialized
ERROR - 2012-10-09 15:56:25 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:56:25 --> Config Class Initialized
DEBUG - 2012-10-09 15:56:25 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:56:25 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:56:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:56:25 --> URI Class Initialized
DEBUG - 2012-10-09 15:56:25 --> Router Class Initialized
ERROR - 2012-10-09 15:56:25 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:56:25 --> Config Class Initialized
DEBUG - 2012-10-09 15:56:25 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:56:25 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:56:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:56:25 --> URI Class Initialized
DEBUG - 2012-10-09 15:56:25 --> Router Class Initialized
ERROR - 2012-10-09 15:56:25 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:57:14 --> Config Class Initialized
DEBUG - 2012-10-09 15:57:14 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:57:14 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:57:14 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:57:14 --> URI Class Initialized
DEBUG - 2012-10-09 15:57:14 --> Router Class Initialized
DEBUG - 2012-10-09 15:57:14 --> Output Class Initialized
DEBUG - 2012-10-09 15:57:14 --> Security Class Initialized
DEBUG - 2012-10-09 15:57:14 --> Input Class Initialized
DEBUG - 2012-10-09 15:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:57:14 --> Language Class Initialized
DEBUG - 2012-10-09 15:57:14 --> Loader Class Initialized
DEBUG - 2012-10-09 15:57:14 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:57:14 --> Controller Class Initialized
DEBUG - 2012-10-09 15:57:14 --> Model Class Initialized
DEBUG - 2012-10-09 15:57:14 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:57:14 --> Helper loaded: form_helper
DEBUG - 2012-10-09 15:57:14 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 15:57:14 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 15:57:14 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 15:57:14 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 15:57:14 --> Final output sent to browser
DEBUG - 2012-10-09 15:57:14 --> Total execution time: 0.0403
DEBUG - 2012-10-09 15:57:16 --> Config Class Initialized
DEBUG - 2012-10-09 15:57:16 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:57:16 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:57:16 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:57:16 --> URI Class Initialized
DEBUG - 2012-10-09 15:57:16 --> Router Class Initialized
ERROR - 2012-10-09 15:57:16 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:57:16 --> Config Class Initialized
DEBUG - 2012-10-09 15:57:16 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:57:16 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:57:16 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:57:16 --> URI Class Initialized
DEBUG - 2012-10-09 15:57:16 --> Router Class Initialized
ERROR - 2012-10-09 15:57:16 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:57:16 --> Config Class Initialized
DEBUG - 2012-10-09 15:57:16 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:57:16 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:57:16 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:57:16 --> URI Class Initialized
DEBUG - 2012-10-09 15:57:16 --> Router Class Initialized
ERROR - 2012-10-09 15:57:16 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:57:19 --> Config Class Initialized
DEBUG - 2012-10-09 15:57:19 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:57:19 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:57:19 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:57:19 --> URI Class Initialized
DEBUG - 2012-10-09 15:57:19 --> Router Class Initialized
DEBUG - 2012-10-09 15:57:19 --> Output Class Initialized
DEBUG - 2012-10-09 15:57:19 --> Security Class Initialized
DEBUG - 2012-10-09 15:57:19 --> Input Class Initialized
DEBUG - 2012-10-09 15:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:57:19 --> Language Class Initialized
DEBUG - 2012-10-09 15:57:19 --> Loader Class Initialized
DEBUG - 2012-10-09 15:57:19 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:57:19 --> Controller Class Initialized
DEBUG - 2012-10-09 15:57:19 --> Model Class Initialized
DEBUG - 2012-10-09 15:57:19 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:57:19 --> Helper loaded: language_helper
DEBUG - 2012-10-09 15:57:19 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 15:58:42 --> Config Class Initialized
DEBUG - 2012-10-09 15:58:42 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:58:42 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:58:42 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:58:42 --> URI Class Initialized
DEBUG - 2012-10-09 15:58:42 --> Router Class Initialized
DEBUG - 2012-10-09 15:58:42 --> Output Class Initialized
DEBUG - 2012-10-09 15:58:42 --> Security Class Initialized
DEBUG - 2012-10-09 15:58:42 --> Input Class Initialized
DEBUG - 2012-10-09 15:58:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:58:42 --> Language Class Initialized
DEBUG - 2012-10-09 15:58:42 --> Loader Class Initialized
DEBUG - 2012-10-09 15:58:42 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:58:42 --> Controller Class Initialized
DEBUG - 2012-10-09 15:58:42 --> Model Class Initialized
DEBUG - 2012-10-09 15:58:42 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:58:42 --> Helper loaded: form_helper
DEBUG - 2012-10-09 15:58:42 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 15:58:42 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 15:58:42 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 15:58:42 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 15:58:42 --> Final output sent to browser
DEBUG - 2012-10-09 15:58:42 --> Total execution time: 0.0416
DEBUG - 2012-10-09 15:58:44 --> Config Class Initialized
DEBUG - 2012-10-09 15:58:44 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:58:44 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:58:44 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:58:44 --> URI Class Initialized
DEBUG - 2012-10-09 15:58:44 --> Router Class Initialized
ERROR - 2012-10-09 15:58:44 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:58:44 --> Config Class Initialized
DEBUG - 2012-10-09 15:58:44 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:58:44 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:58:44 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:58:44 --> URI Class Initialized
DEBUG - 2012-10-09 15:58:44 --> Router Class Initialized
ERROR - 2012-10-09 15:58:44 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:58:44 --> Config Class Initialized
DEBUG - 2012-10-09 15:58:44 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:58:44 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:58:44 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:58:44 --> URI Class Initialized
DEBUG - 2012-10-09 15:58:44 --> Router Class Initialized
ERROR - 2012-10-09 15:58:44 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 15:58:46 --> Config Class Initialized
DEBUG - 2012-10-09 15:58:46 --> Hooks Class Initialized
DEBUG - 2012-10-09 15:58:46 --> Utf8 Class Initialized
DEBUG - 2012-10-09 15:58:46 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 15:58:46 --> URI Class Initialized
DEBUG - 2012-10-09 15:58:46 --> Router Class Initialized
DEBUG - 2012-10-09 15:58:46 --> Output Class Initialized
DEBUG - 2012-10-09 15:58:46 --> Security Class Initialized
DEBUG - 2012-10-09 15:58:46 --> Input Class Initialized
DEBUG - 2012-10-09 15:58:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 15:58:46 --> Language Class Initialized
DEBUG - 2012-10-09 15:58:46 --> Loader Class Initialized
DEBUG - 2012-10-09 15:58:46 --> Helper loaded: url_helper
DEBUG - 2012-10-09 15:58:46 --> Controller Class Initialized
DEBUG - 2012-10-09 15:58:46 --> Model Class Initialized
DEBUG - 2012-10-09 15:58:46 --> Database Driver Class Initialized
DEBUG - 2012-10-09 15:58:46 --> Helper loaded: language_helper
DEBUG - 2012-10-09 15:58:46 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:01:32 --> Config Class Initialized
DEBUG - 2012-10-09 16:01:32 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:01:32 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:01:32 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:01:32 --> URI Class Initialized
DEBUG - 2012-10-09 16:01:32 --> Router Class Initialized
DEBUG - 2012-10-09 16:01:32 --> Output Class Initialized
DEBUG - 2012-10-09 16:01:32 --> Security Class Initialized
DEBUG - 2012-10-09 16:01:32 --> Input Class Initialized
DEBUG - 2012-10-09 16:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:01:32 --> Language Class Initialized
DEBUG - 2012-10-09 16:01:32 --> Loader Class Initialized
DEBUG - 2012-10-09 16:01:32 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:01:32 --> Controller Class Initialized
DEBUG - 2012-10-09 16:01:32 --> Model Class Initialized
DEBUG - 2012-10-09 16:01:32 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:01:32 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:01:32 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 16:01:32 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 16:01:32 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 16:01:32 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 16:01:32 --> Final output sent to browser
DEBUG - 2012-10-09 16:01:32 --> Total execution time: 0.0589
DEBUG - 2012-10-09 16:01:34 --> Config Class Initialized
DEBUG - 2012-10-09 16:01:34 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:01:34 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:01:34 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:01:34 --> URI Class Initialized
DEBUG - 2012-10-09 16:01:34 --> Router Class Initialized
ERROR - 2012-10-09 16:01:34 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:01:34 --> Config Class Initialized
DEBUG - 2012-10-09 16:01:34 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:01:34 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:01:34 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:01:34 --> URI Class Initialized
DEBUG - 2012-10-09 16:01:34 --> Router Class Initialized
ERROR - 2012-10-09 16:01:34 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:01:34 --> Config Class Initialized
DEBUG - 2012-10-09 16:01:34 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:01:34 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:01:34 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:01:34 --> URI Class Initialized
DEBUG - 2012-10-09 16:01:34 --> Router Class Initialized
ERROR - 2012-10-09 16:01:34 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:01:35 --> Config Class Initialized
DEBUG - 2012-10-09 16:01:35 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:01:35 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:01:35 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:01:35 --> URI Class Initialized
DEBUG - 2012-10-09 16:01:35 --> Router Class Initialized
DEBUG - 2012-10-09 16:01:35 --> Output Class Initialized
DEBUG - 2012-10-09 16:01:35 --> Security Class Initialized
DEBUG - 2012-10-09 16:01:35 --> Input Class Initialized
DEBUG - 2012-10-09 16:01:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:01:35 --> Language Class Initialized
DEBUG - 2012-10-09 16:01:35 --> Loader Class Initialized
DEBUG - 2012-10-09 16:01:35 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:01:35 --> Controller Class Initialized
DEBUG - 2012-10-09 16:01:35 --> Model Class Initialized
DEBUG - 2012-10-09 16:01:35 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:01:35 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:01:35 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:01:58 --> Config Class Initialized
DEBUG - 2012-10-09 16:01:58 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:01:58 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:01:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:01:58 --> URI Class Initialized
DEBUG - 2012-10-09 16:01:58 --> Router Class Initialized
DEBUG - 2012-10-09 16:01:58 --> Output Class Initialized
DEBUG - 2012-10-09 16:01:58 --> Security Class Initialized
DEBUG - 2012-10-09 16:01:58 --> Input Class Initialized
DEBUG - 2012-10-09 16:01:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:01:58 --> Language Class Initialized
DEBUG - 2012-10-09 16:01:58 --> Loader Class Initialized
DEBUG - 2012-10-09 16:01:58 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:01:58 --> Controller Class Initialized
DEBUG - 2012-10-09 16:01:58 --> Model Class Initialized
DEBUG - 2012-10-09 16:01:58 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:01:58 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:01:58 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 16:01:58 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 16:01:58 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 16:01:58 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 16:01:58 --> Final output sent to browser
DEBUG - 2012-10-09 16:01:58 --> Total execution time: 0.0409
DEBUG - 2012-10-09 16:02:01 --> Config Class Initialized
DEBUG - 2012-10-09 16:02:01 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:02:01 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:02:01 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:02:01 --> URI Class Initialized
DEBUG - 2012-10-09 16:02:01 --> Router Class Initialized
DEBUG - 2012-10-09 16:02:01 --> Output Class Initialized
DEBUG - 2012-10-09 16:02:01 --> Security Class Initialized
DEBUG - 2012-10-09 16:02:01 --> Input Class Initialized
DEBUG - 2012-10-09 16:02:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:02:01 --> Language Class Initialized
DEBUG - 2012-10-09 16:02:01 --> Loader Class Initialized
DEBUG - 2012-10-09 16:02:01 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:02:01 --> Controller Class Initialized
DEBUG - 2012-10-09 16:02:01 --> Model Class Initialized
DEBUG - 2012-10-09 16:02:01 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:02:01 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:02:01 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:02:12 --> Config Class Initialized
DEBUG - 2012-10-09 16:02:12 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:02:12 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:02:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:02:12 --> URI Class Initialized
DEBUG - 2012-10-09 16:02:12 --> Router Class Initialized
DEBUG - 2012-10-09 16:02:12 --> Output Class Initialized
DEBUG - 2012-10-09 16:02:12 --> Security Class Initialized
DEBUG - 2012-10-09 16:02:12 --> Input Class Initialized
DEBUG - 2012-10-09 16:02:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:02:12 --> Language Class Initialized
DEBUG - 2012-10-09 16:02:12 --> Loader Class Initialized
DEBUG - 2012-10-09 16:02:12 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:02:12 --> Controller Class Initialized
DEBUG - 2012-10-09 16:02:12 --> Model Class Initialized
DEBUG - 2012-10-09 16:02:12 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:02:12 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:02:13 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 16:02:13 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 16:02:13 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 16:02:13 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 16:02:13 --> Final output sent to browser
DEBUG - 2012-10-09 16:02:13 --> Total execution time: 0.0402
DEBUG - 2012-10-09 16:02:22 --> Config Class Initialized
DEBUG - 2012-10-09 16:02:22 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:02:22 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:02:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:02:22 --> URI Class Initialized
DEBUG - 2012-10-09 16:02:22 --> Router Class Initialized
DEBUG - 2012-10-09 16:02:22 --> Output Class Initialized
DEBUG - 2012-10-09 16:02:22 --> Security Class Initialized
DEBUG - 2012-10-09 16:02:22 --> Input Class Initialized
DEBUG - 2012-10-09 16:02:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:02:22 --> Language Class Initialized
DEBUG - 2012-10-09 16:02:22 --> Loader Class Initialized
DEBUG - 2012-10-09 16:02:22 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:02:22 --> Controller Class Initialized
DEBUG - 2012-10-09 16:02:22 --> Model Class Initialized
DEBUG - 2012-10-09 16:02:22 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:02:22 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:02:22 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:03:07 --> Config Class Initialized
DEBUG - 2012-10-09 16:03:07 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:03:07 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:03:07 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:03:07 --> URI Class Initialized
DEBUG - 2012-10-09 16:03:07 --> Router Class Initialized
DEBUG - 2012-10-09 16:03:07 --> Output Class Initialized
DEBUG - 2012-10-09 16:03:07 --> Security Class Initialized
DEBUG - 2012-10-09 16:03:07 --> Input Class Initialized
DEBUG - 2012-10-09 16:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:03:07 --> Language Class Initialized
DEBUG - 2012-10-09 16:03:07 --> Loader Class Initialized
DEBUG - 2012-10-09 16:03:07 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:03:07 --> Controller Class Initialized
DEBUG - 2012-10-09 16:03:07 --> Model Class Initialized
DEBUG - 2012-10-09 16:03:07 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:03:07 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:03:07 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 16:03:07 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 16:03:07 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 16:03:07 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 16:03:07 --> Final output sent to browser
DEBUG - 2012-10-09 16:03:07 --> Total execution time: 0.0410
DEBUG - 2012-10-09 16:03:15 --> Config Class Initialized
DEBUG - 2012-10-09 16:03:15 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:03:15 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:03:15 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:03:15 --> URI Class Initialized
DEBUG - 2012-10-09 16:03:15 --> Router Class Initialized
DEBUG - 2012-10-09 16:03:15 --> Output Class Initialized
DEBUG - 2012-10-09 16:03:15 --> Security Class Initialized
DEBUG - 2012-10-09 16:03:15 --> Input Class Initialized
DEBUG - 2012-10-09 16:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:03:15 --> Language Class Initialized
DEBUG - 2012-10-09 16:03:15 --> Loader Class Initialized
DEBUG - 2012-10-09 16:03:15 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:03:15 --> Controller Class Initialized
DEBUG - 2012-10-09 16:03:15 --> Model Class Initialized
DEBUG - 2012-10-09 16:03:15 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:03:15 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:03:15 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:03:40 --> Config Class Initialized
DEBUG - 2012-10-09 16:03:40 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:03:40 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:03:40 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:03:40 --> URI Class Initialized
DEBUG - 2012-10-09 16:03:40 --> Router Class Initialized
DEBUG - 2012-10-09 16:03:40 --> Output Class Initialized
DEBUG - 2012-10-09 16:03:40 --> Security Class Initialized
DEBUG - 2012-10-09 16:03:40 --> Input Class Initialized
DEBUG - 2012-10-09 16:03:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:03:40 --> Language Class Initialized
DEBUG - 2012-10-09 16:03:40 --> Loader Class Initialized
DEBUG - 2012-10-09 16:03:40 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:03:40 --> Controller Class Initialized
DEBUG - 2012-10-09 16:03:40 --> Model Class Initialized
DEBUG - 2012-10-09 16:03:40 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:03:40 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:03:40 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:09:09 --> Config Class Initialized
DEBUG - 2012-10-09 16:09:09 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:09:09 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:09:09 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:09:09 --> URI Class Initialized
DEBUG - 2012-10-09 16:09:09 --> Router Class Initialized
DEBUG - 2012-10-09 16:09:09 --> Output Class Initialized
DEBUG - 2012-10-09 16:09:09 --> Security Class Initialized
DEBUG - 2012-10-09 16:09:09 --> Input Class Initialized
DEBUG - 2012-10-09 16:09:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:09:09 --> Language Class Initialized
DEBUG - 2012-10-09 16:09:09 --> Loader Class Initialized
DEBUG - 2012-10-09 16:09:09 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:09:09 --> Controller Class Initialized
DEBUG - 2012-10-09 16:09:09 --> Model Class Initialized
DEBUG - 2012-10-09 16:09:09 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:09:09 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:09:09 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 16:09:09 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 16:09:09 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 16:09:09 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 16:09:09 --> Final output sent to browser
DEBUG - 2012-10-09 16:09:09 --> Total execution time: 0.0484
DEBUG - 2012-10-09 16:09:11 --> Config Class Initialized
DEBUG - 2012-10-09 16:09:11 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:09:11 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:09:11 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:09:11 --> URI Class Initialized
DEBUG - 2012-10-09 16:09:11 --> Router Class Initialized
ERROR - 2012-10-09 16:09:11 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:09:11 --> Config Class Initialized
DEBUG - 2012-10-09 16:09:11 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:09:11 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:09:11 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:09:11 --> URI Class Initialized
DEBUG - 2012-10-09 16:09:11 --> Router Class Initialized
ERROR - 2012-10-09 16:09:11 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:09:11 --> Config Class Initialized
DEBUG - 2012-10-09 16:09:11 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:09:11 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:09:11 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:09:11 --> URI Class Initialized
DEBUG - 2012-10-09 16:09:11 --> Router Class Initialized
ERROR - 2012-10-09 16:09:11 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:09:22 --> Config Class Initialized
DEBUG - 2012-10-09 16:09:22 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:09:22 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:09:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:09:22 --> URI Class Initialized
DEBUG - 2012-10-09 16:09:22 --> Router Class Initialized
DEBUG - 2012-10-09 16:09:22 --> Output Class Initialized
DEBUG - 2012-10-09 16:09:22 --> Security Class Initialized
DEBUG - 2012-10-09 16:09:22 --> Input Class Initialized
DEBUG - 2012-10-09 16:09:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:09:22 --> Language Class Initialized
DEBUG - 2012-10-09 16:09:22 --> Loader Class Initialized
DEBUG - 2012-10-09 16:09:22 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:09:22 --> Controller Class Initialized
DEBUG - 2012-10-09 16:09:22 --> Model Class Initialized
DEBUG - 2012-10-09 16:09:22 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:09:22 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:09:22 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 16:09:22 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 16:09:22 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 16:09:22 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 16:09:22 --> Final output sent to browser
DEBUG - 2012-10-09 16:09:22 --> Total execution time: 0.0397
DEBUG - 2012-10-09 16:09:24 --> Config Class Initialized
DEBUG - 2012-10-09 16:09:24 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:09:24 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:09:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:09:24 --> URI Class Initialized
DEBUG - 2012-10-09 16:09:24 --> Router Class Initialized
ERROR - 2012-10-09 16:09:24 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:09:24 --> Config Class Initialized
DEBUG - 2012-10-09 16:09:24 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:09:24 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:09:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:09:24 --> URI Class Initialized
DEBUG - 2012-10-09 16:09:24 --> Router Class Initialized
ERROR - 2012-10-09 16:09:24 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:09:24 --> Config Class Initialized
DEBUG - 2012-10-09 16:09:24 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:09:24 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:09:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:09:24 --> URI Class Initialized
DEBUG - 2012-10-09 16:09:24 --> Router Class Initialized
ERROR - 2012-10-09 16:09:24 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:09:25 --> Config Class Initialized
DEBUG - 2012-10-09 16:09:25 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:09:25 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:09:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:09:25 --> URI Class Initialized
DEBUG - 2012-10-09 16:09:25 --> Router Class Initialized
DEBUG - 2012-10-09 16:09:25 --> Output Class Initialized
DEBUG - 2012-10-09 16:09:25 --> Security Class Initialized
DEBUG - 2012-10-09 16:09:25 --> Input Class Initialized
DEBUG - 2012-10-09 16:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:09:25 --> Language Class Initialized
DEBUG - 2012-10-09 16:09:25 --> Loader Class Initialized
DEBUG - 2012-10-09 16:09:25 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:09:25 --> Controller Class Initialized
DEBUG - 2012-10-09 16:09:25 --> Model Class Initialized
DEBUG - 2012-10-09 16:09:25 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:09:25 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:09:25 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:10:56 --> Config Class Initialized
DEBUG - 2012-10-09 16:10:56 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:10:56 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:10:56 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:10:56 --> URI Class Initialized
DEBUG - 2012-10-09 16:10:56 --> Router Class Initialized
DEBUG - 2012-10-09 16:10:56 --> Output Class Initialized
DEBUG - 2012-10-09 16:10:56 --> Security Class Initialized
DEBUG - 2012-10-09 16:10:56 --> Input Class Initialized
DEBUG - 2012-10-09 16:10:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:10:56 --> Language Class Initialized
DEBUG - 2012-10-09 16:10:56 --> Loader Class Initialized
DEBUG - 2012-10-09 16:10:56 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:10:56 --> Controller Class Initialized
DEBUG - 2012-10-09 16:10:56 --> Model Class Initialized
DEBUG - 2012-10-09 16:10:56 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:10:56 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:10:56 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 16:10:56 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 16:10:56 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 16:10:56 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 16:10:56 --> Final output sent to browser
DEBUG - 2012-10-09 16:10:56 --> Total execution time: 0.0403
DEBUG - 2012-10-09 16:10:58 --> Config Class Initialized
DEBUG - 2012-10-09 16:10:58 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:10:58 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:10:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:10:58 --> URI Class Initialized
DEBUG - 2012-10-09 16:10:58 --> Router Class Initialized
ERROR - 2012-10-09 16:10:58 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:10:58 --> Config Class Initialized
DEBUG - 2012-10-09 16:10:58 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:10:58 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:10:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:10:58 --> URI Class Initialized
DEBUG - 2012-10-09 16:10:58 --> Router Class Initialized
ERROR - 2012-10-09 16:10:58 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:10:58 --> Config Class Initialized
DEBUG - 2012-10-09 16:10:58 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:10:58 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:10:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:10:58 --> URI Class Initialized
DEBUG - 2012-10-09 16:10:58 --> Router Class Initialized
ERROR - 2012-10-09 16:10:58 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:12:24 --> Config Class Initialized
DEBUG - 2012-10-09 16:12:25 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:12:25 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:12:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:12:25 --> URI Class Initialized
DEBUG - 2012-10-09 16:12:25 --> Router Class Initialized
DEBUG - 2012-10-09 16:12:25 --> Output Class Initialized
DEBUG - 2012-10-09 16:12:25 --> Security Class Initialized
DEBUG - 2012-10-09 16:12:25 --> Input Class Initialized
DEBUG - 2012-10-09 16:12:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:12:25 --> Language Class Initialized
DEBUG - 2012-10-09 16:12:25 --> Loader Class Initialized
DEBUG - 2012-10-09 16:12:25 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:12:25 --> Controller Class Initialized
DEBUG - 2012-10-09 16:12:25 --> Model Class Initialized
DEBUG - 2012-10-09 16:12:25 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:12:25 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:12:25 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 16:12:25 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 16:12:25 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 16:12:25 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 16:12:25 --> Final output sent to browser
DEBUG - 2012-10-09 16:12:25 --> Total execution time: 0.0401
DEBUG - 2012-10-09 16:12:27 --> Config Class Initialized
DEBUG - 2012-10-09 16:12:27 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:12:27 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:12:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:12:27 --> URI Class Initialized
DEBUG - 2012-10-09 16:12:27 --> Router Class Initialized
ERROR - 2012-10-09 16:12:27 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:12:27 --> Config Class Initialized
DEBUG - 2012-10-09 16:12:27 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:12:27 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:12:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:12:27 --> URI Class Initialized
DEBUG - 2012-10-09 16:12:27 --> Router Class Initialized
ERROR - 2012-10-09 16:12:27 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:12:27 --> Config Class Initialized
DEBUG - 2012-10-09 16:12:27 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:12:27 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:12:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:12:27 --> URI Class Initialized
DEBUG - 2012-10-09 16:12:27 --> Router Class Initialized
ERROR - 2012-10-09 16:12:27 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:12:28 --> Config Class Initialized
DEBUG - 2012-10-09 16:12:28 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:12:28 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:12:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:12:28 --> URI Class Initialized
DEBUG - 2012-10-09 16:12:28 --> Router Class Initialized
DEBUG - 2012-10-09 16:12:28 --> Output Class Initialized
DEBUG - 2012-10-09 16:12:28 --> Security Class Initialized
DEBUG - 2012-10-09 16:12:28 --> Input Class Initialized
DEBUG - 2012-10-09 16:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:12:28 --> Language Class Initialized
DEBUG - 2012-10-09 16:12:28 --> Loader Class Initialized
DEBUG - 2012-10-09 16:12:28 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:12:28 --> Controller Class Initialized
DEBUG - 2012-10-09 16:12:28 --> Model Class Initialized
DEBUG - 2012-10-09 16:12:28 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:12:28 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:12:28 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:13:11 --> Config Class Initialized
DEBUG - 2012-10-09 16:13:11 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:13:11 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:13:11 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:13:11 --> URI Class Initialized
DEBUG - 2012-10-09 16:13:11 --> Router Class Initialized
DEBUG - 2012-10-09 16:13:11 --> Output Class Initialized
DEBUG - 2012-10-09 16:13:11 --> Security Class Initialized
DEBUG - 2012-10-09 16:13:11 --> Input Class Initialized
DEBUG - 2012-10-09 16:13:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:13:11 --> Language Class Initialized
DEBUG - 2012-10-09 16:13:11 --> Loader Class Initialized
DEBUG - 2012-10-09 16:13:11 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:13:11 --> Controller Class Initialized
DEBUG - 2012-10-09 16:13:11 --> Model Class Initialized
DEBUG - 2012-10-09 16:13:11 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:13:11 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:13:11 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 16:13:11 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 16:13:11 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 16:13:11 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 16:13:11 --> Final output sent to browser
DEBUG - 2012-10-09 16:13:11 --> Total execution time: 0.0404
DEBUG - 2012-10-09 16:13:12 --> Config Class Initialized
DEBUG - 2012-10-09 16:13:12 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:13:12 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:13:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:13:12 --> URI Class Initialized
DEBUG - 2012-10-09 16:13:12 --> Router Class Initialized
ERROR - 2012-10-09 16:13:12 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:13:12 --> Config Class Initialized
DEBUG - 2012-10-09 16:13:12 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:13:12 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:13:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:13:12 --> URI Class Initialized
DEBUG - 2012-10-09 16:13:12 --> Router Class Initialized
ERROR - 2012-10-09 16:13:12 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:13:12 --> Config Class Initialized
DEBUG - 2012-10-09 16:13:12 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:13:12 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:13:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:13:12 --> URI Class Initialized
DEBUG - 2012-10-09 16:13:12 --> Router Class Initialized
ERROR - 2012-10-09 16:13:12 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:13:13 --> Config Class Initialized
DEBUG - 2012-10-09 16:13:13 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:13:13 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:13:13 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:13:13 --> URI Class Initialized
DEBUG - 2012-10-09 16:13:13 --> Router Class Initialized
DEBUG - 2012-10-09 16:13:13 --> Output Class Initialized
DEBUG - 2012-10-09 16:13:13 --> Security Class Initialized
DEBUG - 2012-10-09 16:13:13 --> Input Class Initialized
DEBUG - 2012-10-09 16:13:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:13:13 --> Language Class Initialized
DEBUG - 2012-10-09 16:13:13 --> Loader Class Initialized
DEBUG - 2012-10-09 16:13:13 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:13:13 --> Controller Class Initialized
DEBUG - 2012-10-09 16:13:13 --> Model Class Initialized
DEBUG - 2012-10-09 16:13:14 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:13:14 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:13:14 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:20:12 --> Config Class Initialized
DEBUG - 2012-10-09 16:20:12 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:20:12 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:20:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:20:12 --> URI Class Initialized
DEBUG - 2012-10-09 16:20:12 --> Router Class Initialized
DEBUG - 2012-10-09 16:20:12 --> Output Class Initialized
DEBUG - 2012-10-09 16:20:12 --> Security Class Initialized
DEBUG - 2012-10-09 16:20:12 --> Input Class Initialized
DEBUG - 2012-10-09 16:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:20:12 --> Language Class Initialized
DEBUG - 2012-10-09 16:20:12 --> Loader Class Initialized
DEBUG - 2012-10-09 16:20:12 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:20:12 --> Controller Class Initialized
DEBUG - 2012-10-09 16:20:12 --> Model Class Initialized
DEBUG - 2012-10-09 16:20:12 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:20:12 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:20:12 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 16:20:12 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 16:20:12 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 16:20:12 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 16:20:12 --> Final output sent to browser
DEBUG - 2012-10-09 16:20:12 --> Total execution time: 0.0543
DEBUG - 2012-10-09 16:20:14 --> Config Class Initialized
DEBUG - 2012-10-09 16:20:14 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:20:14 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:20:14 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:20:14 --> URI Class Initialized
DEBUG - 2012-10-09 16:20:14 --> Router Class Initialized
ERROR - 2012-10-09 16:20:14 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:20:14 --> Config Class Initialized
DEBUG - 2012-10-09 16:20:14 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:20:14 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:20:14 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:20:14 --> URI Class Initialized
DEBUG - 2012-10-09 16:20:14 --> Router Class Initialized
ERROR - 2012-10-09 16:20:14 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:20:14 --> Config Class Initialized
DEBUG - 2012-10-09 16:20:14 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:20:14 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:20:14 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:20:14 --> URI Class Initialized
DEBUG - 2012-10-09 16:20:14 --> Router Class Initialized
ERROR - 2012-10-09 16:20:14 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:20:26 --> Config Class Initialized
DEBUG - 2012-10-09 16:20:26 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:20:26 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:20:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:20:26 --> URI Class Initialized
DEBUG - 2012-10-09 16:20:26 --> Router Class Initialized
DEBUG - 2012-10-09 16:20:26 --> Output Class Initialized
DEBUG - 2012-10-09 16:20:26 --> Security Class Initialized
DEBUG - 2012-10-09 16:20:26 --> Input Class Initialized
DEBUG - 2012-10-09 16:20:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:20:26 --> Language Class Initialized
DEBUG - 2012-10-09 16:20:26 --> Loader Class Initialized
DEBUG - 2012-10-09 16:20:26 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:20:26 --> Controller Class Initialized
DEBUG - 2012-10-09 16:20:26 --> Model Class Initialized
DEBUG - 2012-10-09 16:20:26 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:20:26 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:20:26 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:20:26 --> Form Validation Class Initialized
DEBUG - 2012-10-09 16:20:26 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:20:26 --> Upload Class Initialized
DEBUG - 2012-10-09 16:20:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 16:20:26 --> Image Lib Class Initialized
DEBUG - 2012-10-09 16:20:26 --> Final output sent to browser
DEBUG - 2012-10-09 16:20:26 --> Total execution time: 0.1941
DEBUG - 2012-10-09 16:20:52 --> Config Class Initialized
DEBUG - 2012-10-09 16:20:52 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:20:52 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:20:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:20:52 --> URI Class Initialized
DEBUG - 2012-10-09 16:20:52 --> Router Class Initialized
DEBUG - 2012-10-09 16:20:52 --> Output Class Initialized
DEBUG - 2012-10-09 16:20:52 --> Security Class Initialized
DEBUG - 2012-10-09 16:20:52 --> Input Class Initialized
DEBUG - 2012-10-09 16:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:20:52 --> Language Class Initialized
DEBUG - 2012-10-09 16:20:52 --> Loader Class Initialized
DEBUG - 2012-10-09 16:20:52 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:20:52 --> Controller Class Initialized
DEBUG - 2012-10-09 16:20:52 --> Model Class Initialized
DEBUG - 2012-10-09 16:20:52 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:20:52 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:20:52 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:27:49 --> Config Class Initialized
DEBUG - 2012-10-09 16:27:49 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:27:49 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:27:49 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:27:49 --> URI Class Initialized
DEBUG - 2012-10-09 16:27:49 --> Router Class Initialized
DEBUG - 2012-10-09 16:27:49 --> Output Class Initialized
DEBUG - 2012-10-09 16:27:49 --> Security Class Initialized
DEBUG - 2012-10-09 16:27:49 --> Input Class Initialized
DEBUG - 2012-10-09 16:27:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:27:49 --> Language Class Initialized
DEBUG - 2012-10-09 16:27:49 --> Loader Class Initialized
DEBUG - 2012-10-09 16:27:49 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:27:49 --> Controller Class Initialized
DEBUG - 2012-10-09 16:27:49 --> Model Class Initialized
DEBUG - 2012-10-09 16:27:49 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:27:49 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:27:49 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 16:27:49 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 16:27:49 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 16:27:49 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 16:27:49 --> Final output sent to browser
DEBUG - 2012-10-09 16:27:49 --> Total execution time: 0.0409
DEBUG - 2012-10-09 16:27:51 --> Config Class Initialized
DEBUG - 2012-10-09 16:27:51 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:27:51 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:27:51 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:27:51 --> URI Class Initialized
DEBUG - 2012-10-09 16:27:51 --> Router Class Initialized
ERROR - 2012-10-09 16:27:51 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:27:51 --> Config Class Initialized
DEBUG - 2012-10-09 16:27:51 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:27:51 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:27:51 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:27:51 --> URI Class Initialized
DEBUG - 2012-10-09 16:27:51 --> Router Class Initialized
ERROR - 2012-10-09 16:27:51 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:27:51 --> Config Class Initialized
DEBUG - 2012-10-09 16:27:51 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:27:51 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:27:51 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:27:51 --> URI Class Initialized
DEBUG - 2012-10-09 16:27:51 --> Router Class Initialized
ERROR - 2012-10-09 16:27:51 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:27:52 --> Config Class Initialized
DEBUG - 2012-10-09 16:27:52 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:27:52 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:27:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:27:52 --> URI Class Initialized
DEBUG - 2012-10-09 16:27:52 --> Router Class Initialized
DEBUG - 2012-10-09 16:27:52 --> Output Class Initialized
DEBUG - 2012-10-09 16:27:52 --> Security Class Initialized
DEBUG - 2012-10-09 16:27:52 --> Input Class Initialized
DEBUG - 2012-10-09 16:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:27:52 --> Language Class Initialized
DEBUG - 2012-10-09 16:27:52 --> Loader Class Initialized
DEBUG - 2012-10-09 16:27:52 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:27:52 --> Controller Class Initialized
DEBUG - 2012-10-09 16:27:52 --> Model Class Initialized
DEBUG - 2012-10-09 16:27:52 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:27:52 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:27:52 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:28:26 --> Config Class Initialized
DEBUG - 2012-10-09 16:28:26 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:28:26 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:28:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:28:26 --> URI Class Initialized
DEBUG - 2012-10-09 16:28:26 --> Router Class Initialized
DEBUG - 2012-10-09 16:28:26 --> Output Class Initialized
DEBUG - 2012-10-09 16:28:26 --> Security Class Initialized
DEBUG - 2012-10-09 16:28:26 --> Input Class Initialized
DEBUG - 2012-10-09 16:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:28:26 --> Language Class Initialized
DEBUG - 2012-10-09 16:28:26 --> Loader Class Initialized
DEBUG - 2012-10-09 16:28:26 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:28:26 --> Controller Class Initialized
DEBUG - 2012-10-09 16:28:26 --> Model Class Initialized
DEBUG - 2012-10-09 16:28:26 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:28:26 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:28:26 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 16:28:26 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 16:28:26 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 16:28:26 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 16:28:26 --> Final output sent to browser
DEBUG - 2012-10-09 16:28:26 --> Total execution time: 0.0401
DEBUG - 2012-10-09 16:28:28 --> Config Class Initialized
DEBUG - 2012-10-09 16:28:28 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:28:28 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:28:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:28:28 --> URI Class Initialized
DEBUG - 2012-10-09 16:28:28 --> Router Class Initialized
ERROR - 2012-10-09 16:28:28 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:28:28 --> Config Class Initialized
DEBUG - 2012-10-09 16:28:28 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:28:28 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:28:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:28:28 --> URI Class Initialized
DEBUG - 2012-10-09 16:28:28 --> Router Class Initialized
ERROR - 2012-10-09 16:28:28 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:28:28 --> Config Class Initialized
DEBUG - 2012-10-09 16:28:28 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:28:28 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:28:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:28:28 --> URI Class Initialized
DEBUG - 2012-10-09 16:28:28 --> Router Class Initialized
ERROR - 2012-10-09 16:28:28 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:28:40 --> Config Class Initialized
DEBUG - 2012-10-09 16:28:40 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:28:40 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:28:40 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:28:40 --> URI Class Initialized
DEBUG - 2012-10-09 16:28:40 --> Router Class Initialized
DEBUG - 2012-10-09 16:28:40 --> Output Class Initialized
DEBUG - 2012-10-09 16:28:40 --> Security Class Initialized
DEBUG - 2012-10-09 16:28:40 --> Input Class Initialized
DEBUG - 2012-10-09 16:28:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:28:40 --> Language Class Initialized
DEBUG - 2012-10-09 16:28:40 --> Loader Class Initialized
DEBUG - 2012-10-09 16:28:40 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:28:40 --> Controller Class Initialized
DEBUG - 2012-10-09 16:28:40 --> Model Class Initialized
DEBUG - 2012-10-09 16:28:40 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:28:40 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:28:40 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:29:19 --> Config Class Initialized
DEBUG - 2012-10-09 16:29:19 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:29:19 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:29:19 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:29:19 --> URI Class Initialized
DEBUG - 2012-10-09 16:29:19 --> Router Class Initialized
DEBUG - 2012-10-09 16:29:19 --> Output Class Initialized
DEBUG - 2012-10-09 16:29:19 --> Security Class Initialized
DEBUG - 2012-10-09 16:29:19 --> Input Class Initialized
DEBUG - 2012-10-09 16:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:29:19 --> Language Class Initialized
DEBUG - 2012-10-09 16:29:19 --> Loader Class Initialized
DEBUG - 2012-10-09 16:29:19 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:29:19 --> Controller Class Initialized
DEBUG - 2012-10-09 16:29:19 --> Model Class Initialized
DEBUG - 2012-10-09 16:29:19 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:29:19 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:29:19 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 16:29:19 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 16:29:19 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 16:29:19 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 16:29:19 --> Final output sent to browser
DEBUG - 2012-10-09 16:29:19 --> Total execution time: 0.0427
DEBUG - 2012-10-09 16:29:21 --> Config Class Initialized
DEBUG - 2012-10-09 16:29:21 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:29:21 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:29:21 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:29:21 --> URI Class Initialized
DEBUG - 2012-10-09 16:29:21 --> Router Class Initialized
ERROR - 2012-10-09 16:29:21 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:29:21 --> Config Class Initialized
DEBUG - 2012-10-09 16:29:21 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:29:21 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:29:21 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:29:21 --> URI Class Initialized
DEBUG - 2012-10-09 16:29:21 --> Router Class Initialized
ERROR - 2012-10-09 16:29:21 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:29:21 --> Config Class Initialized
DEBUG - 2012-10-09 16:29:21 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:29:21 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:29:21 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:29:21 --> URI Class Initialized
DEBUG - 2012-10-09 16:29:21 --> Router Class Initialized
ERROR - 2012-10-09 16:29:21 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:29:22 --> Config Class Initialized
DEBUG - 2012-10-09 16:29:22 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:29:22 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:29:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:29:22 --> URI Class Initialized
DEBUG - 2012-10-09 16:29:22 --> Router Class Initialized
DEBUG - 2012-10-09 16:29:22 --> Output Class Initialized
DEBUG - 2012-10-09 16:29:22 --> Security Class Initialized
DEBUG - 2012-10-09 16:29:22 --> Input Class Initialized
DEBUG - 2012-10-09 16:29:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:29:22 --> Language Class Initialized
DEBUG - 2012-10-09 16:29:22 --> Loader Class Initialized
DEBUG - 2012-10-09 16:29:22 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:29:22 --> Controller Class Initialized
DEBUG - 2012-10-09 16:29:22 --> Model Class Initialized
DEBUG - 2012-10-09 16:29:22 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:29:22 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:29:22 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:30:23 --> Config Class Initialized
DEBUG - 2012-10-09 16:30:23 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:30:23 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:30:23 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:30:23 --> URI Class Initialized
DEBUG - 2012-10-09 16:30:23 --> Router Class Initialized
DEBUG - 2012-10-09 16:30:23 --> Output Class Initialized
DEBUG - 2012-10-09 16:30:23 --> Security Class Initialized
DEBUG - 2012-10-09 16:30:23 --> Input Class Initialized
DEBUG - 2012-10-09 16:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:30:23 --> Language Class Initialized
DEBUG - 2012-10-09 16:30:23 --> Loader Class Initialized
DEBUG - 2012-10-09 16:30:23 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:30:23 --> Controller Class Initialized
DEBUG - 2012-10-09 16:30:23 --> Model Class Initialized
DEBUG - 2012-10-09 16:30:23 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:30:23 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:30:23 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 16:30:23 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 16:30:23 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 16:30:23 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 16:30:23 --> Final output sent to browser
DEBUG - 2012-10-09 16:30:23 --> Total execution time: 0.0396
DEBUG - 2012-10-09 16:30:25 --> Config Class Initialized
DEBUG - 2012-10-09 16:30:25 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:30:25 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:30:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:30:25 --> URI Class Initialized
DEBUG - 2012-10-09 16:30:25 --> Router Class Initialized
ERROR - 2012-10-09 16:30:25 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:30:25 --> Config Class Initialized
DEBUG - 2012-10-09 16:30:25 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:30:25 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:30:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:30:25 --> URI Class Initialized
DEBUG - 2012-10-09 16:30:25 --> Router Class Initialized
ERROR - 2012-10-09 16:30:25 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:30:25 --> Config Class Initialized
DEBUG - 2012-10-09 16:30:25 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:30:25 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:30:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:30:25 --> URI Class Initialized
DEBUG - 2012-10-09 16:30:25 --> Router Class Initialized
ERROR - 2012-10-09 16:30:25 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:30:26 --> Config Class Initialized
DEBUG - 2012-10-09 16:30:26 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:30:26 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:30:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:30:26 --> URI Class Initialized
DEBUG - 2012-10-09 16:30:26 --> Router Class Initialized
DEBUG - 2012-10-09 16:30:26 --> Output Class Initialized
DEBUG - 2012-10-09 16:30:26 --> Security Class Initialized
DEBUG - 2012-10-09 16:30:26 --> Input Class Initialized
DEBUG - 2012-10-09 16:30:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:30:26 --> Language Class Initialized
DEBUG - 2012-10-09 16:30:26 --> Loader Class Initialized
DEBUG - 2012-10-09 16:30:26 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:30:26 --> Controller Class Initialized
DEBUG - 2012-10-09 16:30:26 --> Model Class Initialized
DEBUG - 2012-10-09 16:30:26 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:30:26 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:30:26 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:32:27 --> Config Class Initialized
DEBUG - 2012-10-09 16:32:27 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:32:27 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:32:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:32:27 --> URI Class Initialized
DEBUG - 2012-10-09 16:32:27 --> Router Class Initialized
DEBUG - 2012-10-09 16:32:27 --> Output Class Initialized
DEBUG - 2012-10-09 16:32:27 --> Security Class Initialized
DEBUG - 2012-10-09 16:32:27 --> Input Class Initialized
DEBUG - 2012-10-09 16:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:32:27 --> Language Class Initialized
DEBUG - 2012-10-09 16:32:27 --> Loader Class Initialized
DEBUG - 2012-10-09 16:32:27 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:32:27 --> Controller Class Initialized
DEBUG - 2012-10-09 16:32:27 --> Model Class Initialized
DEBUG - 2012-10-09 16:32:27 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:32:27 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:32:27 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:32:53 --> Config Class Initialized
DEBUG - 2012-10-09 16:32:53 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:32:53 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:32:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:32:53 --> URI Class Initialized
DEBUG - 2012-10-09 16:32:53 --> Router Class Initialized
DEBUG - 2012-10-09 16:32:53 --> Output Class Initialized
DEBUG - 2012-10-09 16:32:53 --> Security Class Initialized
DEBUG - 2012-10-09 16:32:53 --> Input Class Initialized
DEBUG - 2012-10-09 16:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:32:53 --> Language Class Initialized
DEBUG - 2012-10-09 16:32:53 --> Loader Class Initialized
DEBUG - 2012-10-09 16:32:53 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:32:53 --> Controller Class Initialized
DEBUG - 2012-10-09 16:32:53 --> Model Class Initialized
DEBUG - 2012-10-09 16:32:53 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:32:53 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:32:53 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:32:53 --> Form Validation Class Initialized
DEBUG - 2012-10-09 16:32:53 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:32:53 --> Upload Class Initialized
DEBUG - 2012-10-09 16:32:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 16:32:53 --> Image Lib Class Initialized
DEBUG - 2012-10-09 16:32:53 --> Final output sent to browser
DEBUG - 2012-10-09 16:32:53 --> Total execution time: 0.1866
DEBUG - 2012-10-09 16:36:30 --> Config Class Initialized
DEBUG - 2012-10-09 16:36:30 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:36:30 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:36:30 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:36:30 --> URI Class Initialized
DEBUG - 2012-10-09 16:36:30 --> Router Class Initialized
DEBUG - 2012-10-09 16:36:30 --> Output Class Initialized
DEBUG - 2012-10-09 16:36:30 --> Security Class Initialized
DEBUG - 2012-10-09 16:36:30 --> Input Class Initialized
DEBUG - 2012-10-09 16:36:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:36:30 --> Language Class Initialized
DEBUG - 2012-10-09 16:36:30 --> Loader Class Initialized
DEBUG - 2012-10-09 16:36:30 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:36:30 --> Controller Class Initialized
DEBUG - 2012-10-09 16:36:30 --> Model Class Initialized
DEBUG - 2012-10-09 16:36:30 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:36:30 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:36:30 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 16:36:30 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 16:36:30 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 16:36:30 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 16:36:30 --> Final output sent to browser
DEBUG - 2012-10-09 16:36:30 --> Total execution time: 0.0409
DEBUG - 2012-10-09 16:36:32 --> Config Class Initialized
DEBUG - 2012-10-09 16:36:32 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:36:32 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:36:32 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:36:32 --> URI Class Initialized
DEBUG - 2012-10-09 16:36:32 --> Router Class Initialized
ERROR - 2012-10-09 16:36:32 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:36:32 --> Config Class Initialized
DEBUG - 2012-10-09 16:36:32 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:36:32 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:36:32 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:36:32 --> URI Class Initialized
DEBUG - 2012-10-09 16:36:32 --> Router Class Initialized
ERROR - 2012-10-09 16:36:32 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:36:32 --> Config Class Initialized
DEBUG - 2012-10-09 16:36:32 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:36:32 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:36:32 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:36:32 --> URI Class Initialized
DEBUG - 2012-10-09 16:36:32 --> Router Class Initialized
ERROR - 2012-10-09 16:36:32 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:36:33 --> Config Class Initialized
DEBUG - 2012-10-09 16:36:33 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:36:33 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:36:33 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:36:33 --> URI Class Initialized
DEBUG - 2012-10-09 16:36:33 --> Router Class Initialized
DEBUG - 2012-10-09 16:36:33 --> Output Class Initialized
DEBUG - 2012-10-09 16:36:33 --> Security Class Initialized
DEBUG - 2012-10-09 16:36:33 --> Input Class Initialized
DEBUG - 2012-10-09 16:36:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:36:33 --> Language Class Initialized
DEBUG - 2012-10-09 16:36:33 --> Loader Class Initialized
DEBUG - 2012-10-09 16:36:33 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:36:33 --> Controller Class Initialized
DEBUG - 2012-10-09 16:36:33 --> Model Class Initialized
DEBUG - 2012-10-09 16:36:33 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:36:33 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:36:33 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:36:39 --> Config Class Initialized
DEBUG - 2012-10-09 16:36:39 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:36:39 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:36:39 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:36:39 --> URI Class Initialized
DEBUG - 2012-10-09 16:36:39 --> Router Class Initialized
DEBUG - 2012-10-09 16:36:39 --> Output Class Initialized
DEBUG - 2012-10-09 16:36:39 --> Security Class Initialized
DEBUG - 2012-10-09 16:36:39 --> Input Class Initialized
DEBUG - 2012-10-09 16:36:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:36:39 --> Language Class Initialized
DEBUG - 2012-10-09 16:36:39 --> Loader Class Initialized
DEBUG - 2012-10-09 16:36:39 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:36:39 --> Controller Class Initialized
DEBUG - 2012-10-09 16:36:39 --> Model Class Initialized
DEBUG - 2012-10-09 16:36:39 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:36:39 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:36:39 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:36:39 --> Form Validation Class Initialized
DEBUG - 2012-10-09 16:36:39 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:36:39 --> Upload Class Initialized
DEBUG - 2012-10-09 16:36:39 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 16:36:39 --> Image Lib Class Initialized
DEBUG - 2012-10-09 16:36:39 --> Final output sent to browser
DEBUG - 2012-10-09 16:36:39 --> Total execution time: 0.1627
DEBUG - 2012-10-09 16:37:45 --> Config Class Initialized
DEBUG - 2012-10-09 16:37:45 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:37:45 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:37:45 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:37:45 --> URI Class Initialized
DEBUG - 2012-10-09 16:37:45 --> Router Class Initialized
DEBUG - 2012-10-09 16:37:45 --> Output Class Initialized
DEBUG - 2012-10-09 16:37:45 --> Security Class Initialized
DEBUG - 2012-10-09 16:37:45 --> Input Class Initialized
DEBUG - 2012-10-09 16:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:37:45 --> Language Class Initialized
DEBUG - 2012-10-09 16:37:45 --> Loader Class Initialized
DEBUG - 2012-10-09 16:37:45 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:37:45 --> Controller Class Initialized
DEBUG - 2012-10-09 16:37:45 --> Model Class Initialized
DEBUG - 2012-10-09 16:37:45 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:37:45 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:37:45 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:37:52 --> Config Class Initialized
DEBUG - 2012-10-09 16:37:52 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:37:52 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:37:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:37:52 --> URI Class Initialized
DEBUG - 2012-10-09 16:37:52 --> Router Class Initialized
DEBUG - 2012-10-09 16:37:52 --> Output Class Initialized
DEBUG - 2012-10-09 16:37:52 --> Security Class Initialized
DEBUG - 2012-10-09 16:37:52 --> Input Class Initialized
DEBUG - 2012-10-09 16:37:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:37:52 --> Language Class Initialized
DEBUG - 2012-10-09 16:37:52 --> Loader Class Initialized
DEBUG - 2012-10-09 16:37:52 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:37:52 --> Controller Class Initialized
DEBUG - 2012-10-09 16:37:52 --> Model Class Initialized
DEBUG - 2012-10-09 16:37:52 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:37:52 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:37:52 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:37:52 --> Form Validation Class Initialized
DEBUG - 2012-10-09 16:37:52 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:37:52 --> Upload Class Initialized
DEBUG - 2012-10-09 16:37:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 16:37:52 --> Image Lib Class Initialized
DEBUG - 2012-10-09 16:37:52 --> Final output sent to browser
DEBUG - 2012-10-09 16:37:52 --> Total execution time: 0.2328
DEBUG - 2012-10-09 16:39:13 --> Config Class Initialized
DEBUG - 2012-10-09 16:39:13 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:39:13 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:39:13 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:39:13 --> URI Class Initialized
DEBUG - 2012-10-09 16:39:13 --> Router Class Initialized
DEBUG - 2012-10-09 16:39:13 --> Output Class Initialized
DEBUG - 2012-10-09 16:39:13 --> Security Class Initialized
DEBUG - 2012-10-09 16:39:13 --> Input Class Initialized
DEBUG - 2012-10-09 16:39:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:39:13 --> Language Class Initialized
DEBUG - 2012-10-09 16:39:13 --> Loader Class Initialized
DEBUG - 2012-10-09 16:39:13 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:39:13 --> Controller Class Initialized
DEBUG - 2012-10-09 16:39:13 --> Model Class Initialized
DEBUG - 2012-10-09 16:39:13 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:39:13 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:39:13 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 16:39:13 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 16:39:13 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 16:39:13 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 16:39:13 --> Final output sent to browser
DEBUG - 2012-10-09 16:39:13 --> Total execution time: 0.0409
DEBUG - 2012-10-09 16:39:17 --> Config Class Initialized
DEBUG - 2012-10-09 16:39:17 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:39:17 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:39:17 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:39:17 --> URI Class Initialized
DEBUG - 2012-10-09 16:39:17 --> Router Class Initialized
ERROR - 2012-10-09 16:39:17 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:39:17 --> Config Class Initialized
DEBUG - 2012-10-09 16:39:17 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:39:17 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:39:17 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:39:17 --> URI Class Initialized
DEBUG - 2012-10-09 16:39:17 --> Router Class Initialized
ERROR - 2012-10-09 16:39:17 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:39:17 --> Config Class Initialized
DEBUG - 2012-10-09 16:39:17 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:39:17 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:39:17 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:39:17 --> URI Class Initialized
DEBUG - 2012-10-09 16:39:17 --> Router Class Initialized
ERROR - 2012-10-09 16:39:17 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:39:28 --> Config Class Initialized
DEBUG - 2012-10-09 16:39:28 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:39:28 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:39:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:39:28 --> URI Class Initialized
DEBUG - 2012-10-09 16:39:28 --> Router Class Initialized
DEBUG - 2012-10-09 16:39:28 --> Output Class Initialized
DEBUG - 2012-10-09 16:39:28 --> Security Class Initialized
DEBUG - 2012-10-09 16:39:28 --> Input Class Initialized
DEBUG - 2012-10-09 16:39:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:39:28 --> Language Class Initialized
DEBUG - 2012-10-09 16:39:28 --> Loader Class Initialized
DEBUG - 2012-10-09 16:39:28 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:39:28 --> Controller Class Initialized
DEBUG - 2012-10-09 16:39:28 --> Model Class Initialized
DEBUG - 2012-10-09 16:39:28 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:39:28 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:39:28 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:39:34 --> Config Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:39:34 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:39:34 --> URI Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Router Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Output Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Security Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Input Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:39:34 --> Language Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Loader Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:39:34 --> Controller Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Model Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:39:34 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:39:34 --> Form Validation Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:39:34 --> Upload Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 16:39:34 --> Image Lib Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Final output sent to browser
DEBUG - 2012-10-09 16:39:34 --> Total execution time: 0.1800
DEBUG - 2012-10-09 16:39:34 --> Config Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:39:34 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:39:34 --> URI Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Router Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Output Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Security Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Input Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:39:34 --> Language Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Loader Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:39:34 --> Controller Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Model Class Initialized
DEBUG - 2012-10-09 16:39:34 --> Database Driver Class Initialized
ERROR - 2012-10-09 16:39:34 --> 404 Page Not Found --> pricing/red4.jpg
DEBUG - 2012-10-09 16:42:53 --> Config Class Initialized
DEBUG - 2012-10-09 16:42:53 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:42:53 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:42:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:42:53 --> URI Class Initialized
DEBUG - 2012-10-09 16:42:53 --> Router Class Initialized
DEBUG - 2012-10-09 16:42:53 --> Output Class Initialized
DEBUG - 2012-10-09 16:42:53 --> Security Class Initialized
DEBUG - 2012-10-09 16:42:53 --> Input Class Initialized
DEBUG - 2012-10-09 16:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:42:53 --> Language Class Initialized
DEBUG - 2012-10-09 16:42:53 --> Loader Class Initialized
DEBUG - 2012-10-09 16:42:53 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:42:53 --> Controller Class Initialized
DEBUG - 2012-10-09 16:42:53 --> Model Class Initialized
DEBUG - 2012-10-09 16:42:53 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:42:53 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:42:53 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 16:42:53 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 16:42:53 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 16:42:53 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 16:42:53 --> Final output sent to browser
DEBUG - 2012-10-09 16:42:53 --> Total execution time: 0.0866
DEBUG - 2012-10-09 16:42:55 --> Config Class Initialized
DEBUG - 2012-10-09 16:42:55 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:42:55 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:42:55 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:42:55 --> URI Class Initialized
DEBUG - 2012-10-09 16:42:55 --> Router Class Initialized
ERROR - 2012-10-09 16:42:55 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:42:55 --> Config Class Initialized
DEBUG - 2012-10-09 16:42:55 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:42:55 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:42:55 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:42:55 --> URI Class Initialized
DEBUG - 2012-10-09 16:42:55 --> Router Class Initialized
ERROR - 2012-10-09 16:42:55 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:42:55 --> Config Class Initialized
DEBUG - 2012-10-09 16:42:55 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:42:55 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:42:55 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:42:55 --> URI Class Initialized
DEBUG - 2012-10-09 16:42:55 --> Router Class Initialized
ERROR - 2012-10-09 16:42:55 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:42:56 --> Config Class Initialized
DEBUG - 2012-10-09 16:42:56 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:42:56 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:42:56 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:42:56 --> URI Class Initialized
DEBUG - 2012-10-09 16:42:56 --> Router Class Initialized
DEBUG - 2012-10-09 16:42:56 --> Output Class Initialized
DEBUG - 2012-10-09 16:42:56 --> Security Class Initialized
DEBUG - 2012-10-09 16:42:56 --> Input Class Initialized
DEBUG - 2012-10-09 16:42:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:42:56 --> Language Class Initialized
DEBUG - 2012-10-09 16:42:56 --> Loader Class Initialized
DEBUG - 2012-10-09 16:42:56 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:42:56 --> Controller Class Initialized
DEBUG - 2012-10-09 16:42:56 --> Model Class Initialized
DEBUG - 2012-10-09 16:42:56 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:42:56 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:42:56 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:43:01 --> Config Class Initialized
DEBUG - 2012-10-09 16:43:01 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:43:01 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:43:01 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:43:01 --> URI Class Initialized
DEBUG - 2012-10-09 16:43:01 --> Router Class Initialized
DEBUG - 2012-10-09 16:43:01 --> Output Class Initialized
DEBUG - 2012-10-09 16:43:01 --> Security Class Initialized
DEBUG - 2012-10-09 16:43:01 --> Input Class Initialized
DEBUG - 2012-10-09 16:43:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:43:01 --> Language Class Initialized
DEBUG - 2012-10-09 16:43:01 --> Loader Class Initialized
DEBUG - 2012-10-09 16:43:01 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:43:01 --> Controller Class Initialized
DEBUG - 2012-10-09 16:43:01 --> Model Class Initialized
DEBUG - 2012-10-09 16:43:01 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:43:01 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:43:01 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:43:01 --> Form Validation Class Initialized
DEBUG - 2012-10-09 16:43:01 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:43:01 --> Upload Class Initialized
DEBUG - 2012-10-09 16:43:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 16:43:01 --> Image Lib Class Initialized
DEBUG - 2012-10-09 16:43:01 --> Final output sent to browser
DEBUG - 2012-10-09 16:43:01 --> Total execution time: 0.1878
DEBUG - 2012-10-09 16:43:01 --> Config Class Initialized
DEBUG - 2012-10-09 16:43:01 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:43:01 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:43:01 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:43:01 --> URI Class Initialized
DEBUG - 2012-10-09 16:43:01 --> Router Class Initialized
ERROR - 2012-10-09 16:43:01 --> 404 Page Not Found --> uploads
DEBUG - 2012-10-09 16:43:24 --> Config Class Initialized
DEBUG - 2012-10-09 16:43:24 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:43:24 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:43:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:43:24 --> URI Class Initialized
DEBUG - 2012-10-09 16:43:24 --> Router Class Initialized
DEBUG - 2012-10-09 16:43:24 --> Output Class Initialized
DEBUG - 2012-10-09 16:43:24 --> Security Class Initialized
DEBUG - 2012-10-09 16:43:24 --> Input Class Initialized
DEBUG - 2012-10-09 16:43:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:43:24 --> Language Class Initialized
DEBUG - 2012-10-09 16:43:24 --> Loader Class Initialized
DEBUG - 2012-10-09 16:43:24 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:43:24 --> Controller Class Initialized
DEBUG - 2012-10-09 16:43:24 --> Model Class Initialized
DEBUG - 2012-10-09 16:43:24 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:43:24 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:43:24 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 16:43:24 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 16:43:24 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 16:43:24 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 16:43:24 --> Final output sent to browser
DEBUG - 2012-10-09 16:43:24 --> Total execution time: 0.0469
DEBUG - 2012-10-09 16:43:26 --> Config Class Initialized
DEBUG - 2012-10-09 16:43:26 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:43:26 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:43:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:43:26 --> URI Class Initialized
DEBUG - 2012-10-09 16:43:26 --> Router Class Initialized
ERROR - 2012-10-09 16:43:26 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:43:26 --> Config Class Initialized
DEBUG - 2012-10-09 16:43:26 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:43:26 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:43:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:43:26 --> URI Class Initialized
DEBUG - 2012-10-09 16:43:26 --> Router Class Initialized
ERROR - 2012-10-09 16:43:26 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:43:26 --> Config Class Initialized
DEBUG - 2012-10-09 16:43:26 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:43:26 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:43:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:43:26 --> URI Class Initialized
DEBUG - 2012-10-09 16:43:26 --> Router Class Initialized
ERROR - 2012-10-09 16:43:26 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:43:27 --> Config Class Initialized
DEBUG - 2012-10-09 16:43:27 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:43:27 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:43:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:43:27 --> URI Class Initialized
DEBUG - 2012-10-09 16:43:27 --> Router Class Initialized
DEBUG - 2012-10-09 16:43:27 --> Output Class Initialized
DEBUG - 2012-10-09 16:43:27 --> Security Class Initialized
DEBUG - 2012-10-09 16:43:27 --> Input Class Initialized
DEBUG - 2012-10-09 16:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:43:27 --> Language Class Initialized
DEBUG - 2012-10-09 16:43:27 --> Loader Class Initialized
DEBUG - 2012-10-09 16:43:27 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:43:27 --> Controller Class Initialized
DEBUG - 2012-10-09 16:43:27 --> Model Class Initialized
DEBUG - 2012-10-09 16:43:27 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:43:27 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:43:27 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:43:33 --> Config Class Initialized
DEBUG - 2012-10-09 16:43:33 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:43:33 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:43:33 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:43:33 --> URI Class Initialized
DEBUG - 2012-10-09 16:43:33 --> Router Class Initialized
DEBUG - 2012-10-09 16:43:33 --> Output Class Initialized
DEBUG - 2012-10-09 16:43:33 --> Security Class Initialized
DEBUG - 2012-10-09 16:43:33 --> Input Class Initialized
DEBUG - 2012-10-09 16:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:43:33 --> Language Class Initialized
DEBUG - 2012-10-09 16:43:33 --> Loader Class Initialized
DEBUG - 2012-10-09 16:43:33 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:43:33 --> Controller Class Initialized
DEBUG - 2012-10-09 16:43:33 --> Model Class Initialized
DEBUG - 2012-10-09 16:43:33 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:43:33 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:43:33 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:43:33 --> Form Validation Class Initialized
DEBUG - 2012-10-09 16:43:33 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:43:33 --> Upload Class Initialized
DEBUG - 2012-10-09 16:43:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 16:43:33 --> Image Lib Class Initialized
DEBUG - 2012-10-09 16:43:33 --> Final output sent to browser
DEBUG - 2012-10-09 16:43:33 --> Total execution time: 0.2176
DEBUG - 2012-10-09 16:51:53 --> Config Class Initialized
DEBUG - 2012-10-09 16:51:53 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:51:53 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:51:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:51:53 --> URI Class Initialized
DEBUG - 2012-10-09 16:51:53 --> Router Class Initialized
DEBUG - 2012-10-09 16:51:53 --> Output Class Initialized
DEBUG - 2012-10-09 16:51:53 --> Security Class Initialized
DEBUG - 2012-10-09 16:51:53 --> Input Class Initialized
DEBUG - 2012-10-09 16:51:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:51:53 --> Language Class Initialized
DEBUG - 2012-10-09 16:51:53 --> Loader Class Initialized
DEBUG - 2012-10-09 16:51:53 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:51:53 --> Controller Class Initialized
DEBUG - 2012-10-09 16:51:53 --> Model Class Initialized
DEBUG - 2012-10-09 16:51:53 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:51:53 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:51:53 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:52:14 --> Config Class Initialized
DEBUG - 2012-10-09 16:52:14 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:52:14 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:52:14 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:52:14 --> URI Class Initialized
DEBUG - 2012-10-09 16:52:14 --> Router Class Initialized
DEBUG - 2012-10-09 16:52:14 --> Output Class Initialized
DEBUG - 2012-10-09 16:52:14 --> Security Class Initialized
DEBUG - 2012-10-09 16:52:14 --> Input Class Initialized
DEBUG - 2012-10-09 16:52:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:52:14 --> Language Class Initialized
DEBUG - 2012-10-09 16:52:14 --> Loader Class Initialized
DEBUG - 2012-10-09 16:52:14 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:52:14 --> Controller Class Initialized
DEBUG - 2012-10-09 16:52:14 --> Model Class Initialized
DEBUG - 2012-10-09 16:52:14 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:52:14 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:52:14 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:52:14 --> Form Validation Class Initialized
DEBUG - 2012-10-09 16:52:14 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:52:14 --> Upload Class Initialized
DEBUG - 2012-10-09 16:52:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 16:52:14 --> Image Lib Class Initialized
DEBUG - 2012-10-09 16:52:14 --> Final output sent to browser
DEBUG - 2012-10-09 16:52:14 --> Total execution time: 0.2389
DEBUG - 2012-10-09 16:52:46 --> Config Class Initialized
DEBUG - 2012-10-09 16:52:46 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:52:46 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:52:46 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:52:46 --> URI Class Initialized
DEBUG - 2012-10-09 16:52:46 --> Router Class Initialized
DEBUG - 2012-10-09 16:52:46 --> Output Class Initialized
DEBUG - 2012-10-09 16:52:46 --> Security Class Initialized
DEBUG - 2012-10-09 16:52:46 --> Input Class Initialized
DEBUG - 2012-10-09 16:52:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:52:46 --> Language Class Initialized
DEBUG - 2012-10-09 16:52:46 --> Loader Class Initialized
DEBUG - 2012-10-09 16:52:46 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:52:46 --> Controller Class Initialized
DEBUG - 2012-10-09 16:52:46 --> Model Class Initialized
DEBUG - 2012-10-09 16:52:46 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:52:46 --> Helper loaded: language_helper
DEBUG - 2012-10-09 16:52:46 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 16:55:57 --> Config Class Initialized
DEBUG - 2012-10-09 16:55:57 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:55:57 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:55:57 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:55:57 --> URI Class Initialized
DEBUG - 2012-10-09 16:55:57 --> Router Class Initialized
DEBUG - 2012-10-09 16:55:57 --> Output Class Initialized
DEBUG - 2012-10-09 16:55:57 --> Security Class Initialized
DEBUG - 2012-10-09 16:55:57 --> Input Class Initialized
DEBUG - 2012-10-09 16:55:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:55:57 --> Language Class Initialized
DEBUG - 2012-10-09 16:55:57 --> Loader Class Initialized
DEBUG - 2012-10-09 16:55:57 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:55:57 --> Controller Class Initialized
DEBUG - 2012-10-09 16:55:57 --> Model Class Initialized
DEBUG - 2012-10-09 16:55:57 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:55:57 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:55:57 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 16:55:57 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 16:55:57 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 16:55:57 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 16:55:57 --> Final output sent to browser
DEBUG - 2012-10-09 16:55:57 --> Total execution time: 0.0410
DEBUG - 2012-10-09 16:55:59 --> Config Class Initialized
DEBUG - 2012-10-09 16:55:59 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:55:59 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:55:59 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:55:59 --> URI Class Initialized
DEBUG - 2012-10-09 16:55:59 --> Router Class Initialized
ERROR - 2012-10-09 16:55:59 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:55:59 --> Config Class Initialized
DEBUG - 2012-10-09 16:55:59 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:55:59 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:55:59 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:55:59 --> URI Class Initialized
DEBUG - 2012-10-09 16:55:59 --> Router Class Initialized
ERROR - 2012-10-09 16:55:59 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:55:59 --> Config Class Initialized
DEBUG - 2012-10-09 16:55:59 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:55:59 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:55:59 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:55:59 --> URI Class Initialized
DEBUG - 2012-10-09 16:55:59 --> Router Class Initialized
ERROR - 2012-10-09 16:55:59 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:57:04 --> Config Class Initialized
DEBUG - 2012-10-09 16:57:04 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:57:04 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:57:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:57:04 --> URI Class Initialized
DEBUG - 2012-10-09 16:57:04 --> Router Class Initialized
DEBUG - 2012-10-09 16:57:04 --> Output Class Initialized
DEBUG - 2012-10-09 16:57:04 --> Security Class Initialized
DEBUG - 2012-10-09 16:57:04 --> Input Class Initialized
DEBUG - 2012-10-09 16:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 16:57:04 --> Language Class Initialized
DEBUG - 2012-10-09 16:57:04 --> Loader Class Initialized
DEBUG - 2012-10-09 16:57:04 --> Helper loaded: url_helper
DEBUG - 2012-10-09 16:57:04 --> Controller Class Initialized
DEBUG - 2012-10-09 16:57:04 --> Model Class Initialized
DEBUG - 2012-10-09 16:57:04 --> Database Driver Class Initialized
DEBUG - 2012-10-09 16:57:04 --> Helper loaded: form_helper
DEBUG - 2012-10-09 16:57:04 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 16:57:04 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 16:57:04 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 16:57:04 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 16:57:04 --> Final output sent to browser
DEBUG - 2012-10-09 16:57:04 --> Total execution time: 0.0452
DEBUG - 2012-10-09 16:57:06 --> Config Class Initialized
DEBUG - 2012-10-09 16:57:06 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:57:06 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:57:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:57:06 --> URI Class Initialized
DEBUG - 2012-10-09 16:57:06 --> Router Class Initialized
ERROR - 2012-10-09 16:57:06 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:57:06 --> Config Class Initialized
DEBUG - 2012-10-09 16:57:06 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:57:06 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:57:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:57:06 --> URI Class Initialized
DEBUG - 2012-10-09 16:57:06 --> Router Class Initialized
ERROR - 2012-10-09 16:57:06 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 16:57:06 --> Config Class Initialized
DEBUG - 2012-10-09 16:57:06 --> Hooks Class Initialized
DEBUG - 2012-10-09 16:57:06 --> Utf8 Class Initialized
DEBUG - 2012-10-09 16:57:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 16:57:06 --> URI Class Initialized
DEBUG - 2012-10-09 16:57:06 --> Router Class Initialized
ERROR - 2012-10-09 16:57:06 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 17:02:33 --> Config Class Initialized
DEBUG - 2012-10-09 17:02:33 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:02:33 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:02:33 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:02:33 --> URI Class Initialized
DEBUG - 2012-10-09 17:02:33 --> Router Class Initialized
DEBUG - 2012-10-09 17:02:33 --> Output Class Initialized
DEBUG - 2012-10-09 17:02:33 --> Security Class Initialized
DEBUG - 2012-10-09 17:02:33 --> Input Class Initialized
DEBUG - 2012-10-09 17:02:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:02:33 --> Language Class Initialized
DEBUG - 2012-10-09 17:02:33 --> Loader Class Initialized
DEBUG - 2012-10-09 17:02:33 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:02:33 --> Controller Class Initialized
DEBUG - 2012-10-09 17:02:33 --> Model Class Initialized
DEBUG - 2012-10-09 17:02:33 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:02:33 --> Helper loaded: form_helper
DEBUG - 2012-10-09 17:02:33 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 17:02:33 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 17:02:33 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 17:02:33 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 17:02:33 --> Final output sent to browser
DEBUG - 2012-10-09 17:02:33 --> Total execution time: 0.0399
DEBUG - 2012-10-09 17:02:35 --> Config Class Initialized
DEBUG - 2012-10-09 17:02:35 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:02:35 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:02:35 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:02:35 --> URI Class Initialized
DEBUG - 2012-10-09 17:02:35 --> Router Class Initialized
ERROR - 2012-10-09 17:02:35 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 17:02:35 --> Config Class Initialized
DEBUG - 2012-10-09 17:02:35 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:02:35 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:02:35 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:02:35 --> URI Class Initialized
DEBUG - 2012-10-09 17:02:35 --> Router Class Initialized
ERROR - 2012-10-09 17:02:35 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 17:02:35 --> Config Class Initialized
DEBUG - 2012-10-09 17:02:35 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:02:35 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:02:35 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:02:35 --> URI Class Initialized
DEBUG - 2012-10-09 17:02:35 --> Router Class Initialized
ERROR - 2012-10-09 17:02:35 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 17:02:59 --> Config Class Initialized
DEBUG - 2012-10-09 17:02:59 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:02:59 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:02:59 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:02:59 --> URI Class Initialized
DEBUG - 2012-10-09 17:02:59 --> Router Class Initialized
DEBUG - 2012-10-09 17:02:59 --> Output Class Initialized
DEBUG - 2012-10-09 17:02:59 --> Security Class Initialized
DEBUG - 2012-10-09 17:02:59 --> Input Class Initialized
DEBUG - 2012-10-09 17:02:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:02:59 --> Language Class Initialized
DEBUG - 2012-10-09 17:02:59 --> Loader Class Initialized
DEBUG - 2012-10-09 17:02:59 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:02:59 --> Controller Class Initialized
DEBUG - 2012-10-09 17:02:59 --> Model Class Initialized
DEBUG - 2012-10-09 17:02:59 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:02:59 --> Helper loaded: language_helper
DEBUG - 2012-10-09 17:02:59 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 17:03:14 --> Config Class Initialized
DEBUG - 2012-10-09 17:03:14 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:03:14 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:03:14 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:03:14 --> URI Class Initialized
DEBUG - 2012-10-09 17:03:14 --> Router Class Initialized
DEBUG - 2012-10-09 17:03:14 --> Output Class Initialized
DEBUG - 2012-10-09 17:03:14 --> Security Class Initialized
DEBUG - 2012-10-09 17:03:14 --> Input Class Initialized
DEBUG - 2012-10-09 17:03:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:03:14 --> Language Class Initialized
DEBUG - 2012-10-09 17:03:14 --> Loader Class Initialized
DEBUG - 2012-10-09 17:03:14 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:03:14 --> Controller Class Initialized
DEBUG - 2012-10-09 17:03:14 --> Model Class Initialized
DEBUG - 2012-10-09 17:03:14 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:03:14 --> Helper loaded: language_helper
DEBUG - 2012-10-09 17:03:14 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 17:03:26 --> Config Class Initialized
DEBUG - 2012-10-09 17:03:26 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:03:26 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:03:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:03:26 --> URI Class Initialized
DEBUG - 2012-10-09 17:03:26 --> Router Class Initialized
DEBUG - 2012-10-09 17:03:26 --> Output Class Initialized
DEBUG - 2012-10-09 17:03:26 --> Security Class Initialized
DEBUG - 2012-10-09 17:03:26 --> Input Class Initialized
DEBUG - 2012-10-09 17:03:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:03:26 --> Language Class Initialized
DEBUG - 2012-10-09 17:03:26 --> Loader Class Initialized
DEBUG - 2012-10-09 17:03:26 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:03:26 --> Controller Class Initialized
DEBUG - 2012-10-09 17:03:26 --> Model Class Initialized
DEBUG - 2012-10-09 17:03:26 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:03:26 --> Helper loaded: form_helper
DEBUG - 2012-10-09 17:03:26 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 17:03:26 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 17:03:26 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 17:03:26 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 17:03:26 --> Final output sent to browser
DEBUG - 2012-10-09 17:03:26 --> Total execution time: 0.0402
DEBUG - 2012-10-09 17:03:28 --> Config Class Initialized
DEBUG - 2012-10-09 17:03:28 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:03:28 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:03:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:03:28 --> URI Class Initialized
DEBUG - 2012-10-09 17:03:28 --> Router Class Initialized
ERROR - 2012-10-09 17:03:28 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 17:03:28 --> Config Class Initialized
DEBUG - 2012-10-09 17:03:28 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:03:28 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:03:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:03:28 --> URI Class Initialized
DEBUG - 2012-10-09 17:03:28 --> Router Class Initialized
ERROR - 2012-10-09 17:03:28 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 17:03:28 --> Config Class Initialized
DEBUG - 2012-10-09 17:03:28 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:03:28 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:03:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:03:28 --> URI Class Initialized
DEBUG - 2012-10-09 17:03:28 --> Router Class Initialized
ERROR - 2012-10-09 17:03:28 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 17:03:33 --> Config Class Initialized
DEBUG - 2012-10-09 17:03:33 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:03:33 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:03:33 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:03:33 --> URI Class Initialized
DEBUG - 2012-10-09 17:03:33 --> Router Class Initialized
DEBUG - 2012-10-09 17:03:33 --> Output Class Initialized
DEBUG - 2012-10-09 17:03:33 --> Security Class Initialized
DEBUG - 2012-10-09 17:03:33 --> Input Class Initialized
DEBUG - 2012-10-09 17:03:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:03:33 --> Language Class Initialized
DEBUG - 2012-10-09 17:03:33 --> Loader Class Initialized
DEBUG - 2012-10-09 17:03:33 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:03:33 --> Controller Class Initialized
DEBUG - 2012-10-09 17:03:33 --> Model Class Initialized
DEBUG - 2012-10-09 17:03:33 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:03:33 --> Helper loaded: language_helper
DEBUG - 2012-10-09 17:03:33 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 17:07:30 --> Config Class Initialized
DEBUG - 2012-10-09 17:07:30 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:07:30 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:07:30 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:07:30 --> URI Class Initialized
DEBUG - 2012-10-09 17:07:30 --> Router Class Initialized
DEBUG - 2012-10-09 17:07:30 --> Output Class Initialized
DEBUG - 2012-10-09 17:07:30 --> Security Class Initialized
DEBUG - 2012-10-09 17:07:30 --> Input Class Initialized
DEBUG - 2012-10-09 17:07:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:07:30 --> Language Class Initialized
DEBUG - 2012-10-09 17:07:30 --> Loader Class Initialized
DEBUG - 2012-10-09 17:07:30 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:07:30 --> Controller Class Initialized
DEBUG - 2012-10-09 17:07:30 --> Model Class Initialized
DEBUG - 2012-10-09 17:07:30 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:07:30 --> Helper loaded: form_helper
DEBUG - 2012-10-09 17:07:30 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 17:07:30 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 17:07:30 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 17:07:30 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 17:07:30 --> Final output sent to browser
DEBUG - 2012-10-09 17:07:30 --> Total execution time: 0.0598
DEBUG - 2012-10-09 17:07:32 --> Config Class Initialized
DEBUG - 2012-10-09 17:07:32 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:07:32 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:07:32 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:07:32 --> URI Class Initialized
DEBUG - 2012-10-09 17:07:32 --> Router Class Initialized
ERROR - 2012-10-09 17:07:32 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 17:07:32 --> Config Class Initialized
DEBUG - 2012-10-09 17:07:32 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:07:32 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:07:32 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:07:32 --> URI Class Initialized
DEBUG - 2012-10-09 17:07:32 --> Router Class Initialized
ERROR - 2012-10-09 17:07:32 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 17:07:32 --> Config Class Initialized
DEBUG - 2012-10-09 17:07:32 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:07:32 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:07:32 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:07:32 --> URI Class Initialized
DEBUG - 2012-10-09 17:07:32 --> Router Class Initialized
ERROR - 2012-10-09 17:07:32 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 17:07:34 --> Config Class Initialized
DEBUG - 2012-10-09 17:07:34 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:07:34 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:07:34 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:07:34 --> URI Class Initialized
DEBUG - 2012-10-09 17:07:34 --> Router Class Initialized
DEBUG - 2012-10-09 17:07:34 --> Output Class Initialized
DEBUG - 2012-10-09 17:07:34 --> Security Class Initialized
DEBUG - 2012-10-09 17:07:34 --> Input Class Initialized
DEBUG - 2012-10-09 17:07:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:07:34 --> Language Class Initialized
DEBUG - 2012-10-09 17:07:34 --> Loader Class Initialized
DEBUG - 2012-10-09 17:07:34 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:07:34 --> Controller Class Initialized
DEBUG - 2012-10-09 17:07:34 --> Model Class Initialized
DEBUG - 2012-10-09 17:07:34 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:07:34 --> Helper loaded: language_helper
DEBUG - 2012-10-09 17:07:34 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 17:07:40 --> Config Class Initialized
DEBUG - 2012-10-09 17:07:40 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:07:40 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:07:40 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:07:40 --> URI Class Initialized
DEBUG - 2012-10-09 17:07:40 --> Router Class Initialized
DEBUG - 2012-10-09 17:07:40 --> Output Class Initialized
DEBUG - 2012-10-09 17:07:40 --> Security Class Initialized
DEBUG - 2012-10-09 17:07:40 --> Input Class Initialized
DEBUG - 2012-10-09 17:07:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:07:40 --> Language Class Initialized
DEBUG - 2012-10-09 17:07:40 --> Loader Class Initialized
DEBUG - 2012-10-09 17:07:40 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:07:40 --> Controller Class Initialized
DEBUG - 2012-10-09 17:07:40 --> Model Class Initialized
DEBUG - 2012-10-09 17:07:40 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:07:40 --> Helper loaded: form_helper
DEBUG - 2012-10-09 17:07:40 --> Helper loaded: language_helper
DEBUG - 2012-10-09 17:07:40 --> Form Validation Class Initialized
DEBUG - 2012-10-09 17:07:40 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 17:07:40 --> Upload Class Initialized
DEBUG - 2012-10-09 17:07:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 17:07:40 --> Language file loaded: language/english/upload_lang.php
ERROR - 2012-10-09 17:07:40 --> You did not select a file to upload.
DEBUG - 2012-10-09 17:07:56 --> Config Class Initialized
DEBUG - 2012-10-09 17:07:56 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:07:56 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:07:56 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:07:56 --> URI Class Initialized
DEBUG - 2012-10-09 17:07:56 --> Router Class Initialized
DEBUG - 2012-10-09 17:07:56 --> Output Class Initialized
DEBUG - 2012-10-09 17:07:56 --> Security Class Initialized
DEBUG - 2012-10-09 17:07:56 --> Input Class Initialized
DEBUG - 2012-10-09 17:07:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:07:56 --> Language Class Initialized
DEBUG - 2012-10-09 17:07:56 --> Loader Class Initialized
DEBUG - 2012-10-09 17:07:56 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:07:56 --> Controller Class Initialized
DEBUG - 2012-10-09 17:07:56 --> Model Class Initialized
DEBUG - 2012-10-09 17:07:56 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:07:56 --> Helper loaded: form_helper
DEBUG - 2012-10-09 17:07:56 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 17:07:56 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 17:07:56 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 17:07:56 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 17:07:56 --> Final output sent to browser
DEBUG - 2012-10-09 17:07:56 --> Total execution time: 0.0450
DEBUG - 2012-10-09 17:07:58 --> Config Class Initialized
DEBUG - 2012-10-09 17:07:58 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:07:58 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:07:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:07:58 --> URI Class Initialized
DEBUG - 2012-10-09 17:07:58 --> Router Class Initialized
ERROR - 2012-10-09 17:07:58 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 17:07:58 --> Config Class Initialized
DEBUG - 2012-10-09 17:07:58 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:07:58 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:07:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:07:58 --> URI Class Initialized
DEBUG - 2012-10-09 17:07:58 --> Router Class Initialized
ERROR - 2012-10-09 17:07:58 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 17:07:58 --> Config Class Initialized
DEBUG - 2012-10-09 17:07:58 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:07:58 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:07:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:07:58 --> URI Class Initialized
DEBUG - 2012-10-09 17:07:58 --> Router Class Initialized
ERROR - 2012-10-09 17:07:58 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 17:08:01 --> Config Class Initialized
DEBUG - 2012-10-09 17:08:01 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:08:01 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:08:01 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:08:01 --> URI Class Initialized
DEBUG - 2012-10-09 17:08:01 --> Router Class Initialized
DEBUG - 2012-10-09 17:08:01 --> Output Class Initialized
DEBUG - 2012-10-09 17:08:01 --> Security Class Initialized
DEBUG - 2012-10-09 17:08:01 --> Input Class Initialized
DEBUG - 2012-10-09 17:08:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:08:01 --> Language Class Initialized
DEBUG - 2012-10-09 17:08:01 --> Loader Class Initialized
DEBUG - 2012-10-09 17:08:01 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:08:01 --> Controller Class Initialized
DEBUG - 2012-10-09 17:08:01 --> Model Class Initialized
DEBUG - 2012-10-09 17:08:01 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:08:01 --> Helper loaded: language_helper
DEBUG - 2012-10-09 17:08:01 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 17:08:24 --> Config Class Initialized
DEBUG - 2012-10-09 17:08:24 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:08:24 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:08:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:08:24 --> URI Class Initialized
DEBUG - 2012-10-09 17:08:24 --> Router Class Initialized
DEBUG - 2012-10-09 17:08:24 --> Output Class Initialized
DEBUG - 2012-10-09 17:08:24 --> Security Class Initialized
DEBUG - 2012-10-09 17:08:24 --> Input Class Initialized
DEBUG - 2012-10-09 17:08:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:08:24 --> Language Class Initialized
DEBUG - 2012-10-09 17:08:24 --> Loader Class Initialized
DEBUG - 2012-10-09 17:08:24 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:08:24 --> Controller Class Initialized
DEBUG - 2012-10-09 17:08:24 --> Model Class Initialized
DEBUG - 2012-10-09 17:08:24 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:08:24 --> Helper loaded: form_helper
DEBUG - 2012-10-09 17:08:24 --> Helper loaded: language_helper
DEBUG - 2012-10-09 17:08:24 --> Form Validation Class Initialized
DEBUG - 2012-10-09 17:08:24 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 17:08:24 --> Upload Class Initialized
DEBUG - 2012-10-09 17:08:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 17:08:24 --> Image Lib Class Initialized
DEBUG - 2012-10-09 17:08:25 --> Final output sent to browser
DEBUG - 2012-10-09 17:08:25 --> Total execution time: 0.3016
DEBUG - 2012-10-09 17:08:27 --> Config Class Initialized
DEBUG - 2012-10-09 17:08:27 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:08:27 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:08:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:08:27 --> URI Class Initialized
DEBUG - 2012-10-09 17:08:27 --> Router Class Initialized
DEBUG - 2012-10-09 17:08:27 --> Output Class Initialized
DEBUG - 2012-10-09 17:08:27 --> Security Class Initialized
DEBUG - 2012-10-09 17:08:27 --> Input Class Initialized
DEBUG - 2012-10-09 17:08:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:08:27 --> Language Class Initialized
DEBUG - 2012-10-09 17:08:27 --> Loader Class Initialized
DEBUG - 2012-10-09 17:08:27 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:08:27 --> Controller Class Initialized
DEBUG - 2012-10-09 17:08:27 --> Model Class Initialized
DEBUG - 2012-10-09 17:08:27 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:08:27 --> Helper loaded: language_helper
DEBUG - 2012-10-09 17:08:27 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 17:08:32 --> Config Class Initialized
DEBUG - 2012-10-09 17:08:32 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:08:32 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:08:32 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:08:32 --> URI Class Initialized
DEBUG - 2012-10-09 17:08:32 --> Router Class Initialized
DEBUG - 2012-10-09 17:08:32 --> Output Class Initialized
DEBUG - 2012-10-09 17:08:32 --> Security Class Initialized
DEBUG - 2012-10-09 17:08:32 --> Input Class Initialized
DEBUG - 2012-10-09 17:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:08:32 --> Language Class Initialized
DEBUG - 2012-10-09 17:08:32 --> Loader Class Initialized
DEBUG - 2012-10-09 17:08:32 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:08:32 --> Controller Class Initialized
DEBUG - 2012-10-09 17:08:32 --> Model Class Initialized
DEBUG - 2012-10-09 17:08:32 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:08:32 --> Helper loaded: language_helper
DEBUG - 2012-10-09 17:08:32 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 17:10:19 --> Config Class Initialized
DEBUG - 2012-10-09 17:10:19 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:10:19 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:10:19 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:10:19 --> URI Class Initialized
DEBUG - 2012-10-09 17:10:19 --> Router Class Initialized
DEBUG - 2012-10-09 17:10:19 --> Output Class Initialized
DEBUG - 2012-10-09 17:10:19 --> Security Class Initialized
DEBUG - 2012-10-09 17:10:19 --> Input Class Initialized
DEBUG - 2012-10-09 17:10:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:10:19 --> Language Class Initialized
DEBUG - 2012-10-09 17:10:19 --> Loader Class Initialized
DEBUG - 2012-10-09 17:10:19 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:10:19 --> Controller Class Initialized
DEBUG - 2012-10-09 17:10:19 --> Model Class Initialized
DEBUG - 2012-10-09 17:10:19 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:10:19 --> Helper loaded: form_helper
DEBUG - 2012-10-09 17:10:19 --> Helper loaded: language_helper
DEBUG - 2012-10-09 17:10:20 --> Form Validation Class Initialized
DEBUG - 2012-10-09 17:10:20 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 17:10:20 --> Upload Class Initialized
DEBUG - 2012-10-09 17:10:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 17:10:20 --> Language file loaded: language/english/upload_lang.php
ERROR - 2012-10-09 17:10:20 --> You did not select a file to upload.
DEBUG - 2012-10-09 17:17:48 --> Config Class Initialized
DEBUG - 2012-10-09 17:17:48 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:17:48 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:17:48 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:17:48 --> URI Class Initialized
DEBUG - 2012-10-09 17:17:48 --> Router Class Initialized
DEBUG - 2012-10-09 17:17:48 --> Output Class Initialized
DEBUG - 2012-10-09 17:17:48 --> Security Class Initialized
DEBUG - 2012-10-09 17:17:48 --> Input Class Initialized
DEBUG - 2012-10-09 17:17:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:17:48 --> Language Class Initialized
DEBUG - 2012-10-09 17:17:48 --> Loader Class Initialized
DEBUG - 2012-10-09 17:17:48 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:17:48 --> Controller Class Initialized
DEBUG - 2012-10-09 17:17:48 --> Model Class Initialized
DEBUG - 2012-10-09 17:17:48 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:17:48 --> Helper loaded: form_helper
DEBUG - 2012-10-09 17:17:48 --> Helper loaded: language_helper
DEBUG - 2012-10-09 17:17:48 --> Form Validation Class Initialized
DEBUG - 2012-10-09 17:17:48 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 17:17:48 --> Upload Class Initialized
DEBUG - 2012-10-09 17:17:48 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 17:17:48 --> Language file loaded: language/english/upload_lang.php
ERROR - 2012-10-09 17:17:48 --> You did not select a file to upload.
DEBUG - 2012-10-09 17:21:46 --> Config Class Initialized
DEBUG - 2012-10-09 17:21:46 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:21:46 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:21:46 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:21:46 --> URI Class Initialized
DEBUG - 2012-10-09 17:21:46 --> Router Class Initialized
DEBUG - 2012-10-09 17:21:46 --> Output Class Initialized
DEBUG - 2012-10-09 17:21:46 --> Security Class Initialized
DEBUG - 2012-10-09 17:21:46 --> Input Class Initialized
DEBUG - 2012-10-09 17:21:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:21:46 --> Language Class Initialized
DEBUG - 2012-10-09 17:21:46 --> Loader Class Initialized
DEBUG - 2012-10-09 17:21:46 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:21:46 --> Controller Class Initialized
DEBUG - 2012-10-09 17:21:46 --> Model Class Initialized
DEBUG - 2012-10-09 17:21:46 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:21:46 --> Helper loaded: form_helper
DEBUG - 2012-10-09 17:21:46 --> Helper loaded: language_helper
DEBUG - 2012-10-09 17:21:46 --> Form Validation Class Initialized
DEBUG - 2012-10-09 17:21:46 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 17:21:46 --> Upload Class Initialized
DEBUG - 2012-10-09 17:21:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 17:21:46 --> Language file loaded: language/english/upload_lang.php
ERROR - 2012-10-09 17:21:46 --> You did not select a file to upload.
DEBUG - 2012-10-09 17:33:58 --> Config Class Initialized
DEBUG - 2012-10-09 17:33:58 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:33:58 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:33:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:33:58 --> URI Class Initialized
DEBUG - 2012-10-09 17:33:58 --> Router Class Initialized
DEBUG - 2012-10-09 17:33:58 --> Output Class Initialized
DEBUG - 2012-10-09 17:33:58 --> Security Class Initialized
DEBUG - 2012-10-09 17:33:58 --> Input Class Initialized
DEBUG - 2012-10-09 17:33:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:33:58 --> Language Class Initialized
DEBUG - 2012-10-09 17:33:58 --> Loader Class Initialized
DEBUG - 2012-10-09 17:33:58 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:33:58 --> Controller Class Initialized
DEBUG - 2012-10-09 17:33:58 --> Model Class Initialized
DEBUG - 2012-10-09 17:33:58 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:33:58 --> Helper loaded: form_helper
DEBUG - 2012-10-09 17:33:58 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 17:33:58 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 17:33:58 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 17:33:58 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 17:33:58 --> Final output sent to browser
DEBUG - 2012-10-09 17:33:58 --> Total execution time: 0.0477
DEBUG - 2012-10-09 17:34:00 --> Config Class Initialized
DEBUG - 2012-10-09 17:34:00 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:34:00 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:34:00 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:34:00 --> URI Class Initialized
DEBUG - 2012-10-09 17:34:00 --> Router Class Initialized
ERROR - 2012-10-09 17:34:00 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 17:34:00 --> Config Class Initialized
DEBUG - 2012-10-09 17:34:00 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:34:00 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:34:00 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:34:00 --> URI Class Initialized
DEBUG - 2012-10-09 17:34:00 --> Router Class Initialized
ERROR - 2012-10-09 17:34:00 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 17:34:00 --> Config Class Initialized
DEBUG - 2012-10-09 17:34:00 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:34:00 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:34:00 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:34:00 --> URI Class Initialized
DEBUG - 2012-10-09 17:34:00 --> Router Class Initialized
ERROR - 2012-10-09 17:34:00 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 17:34:06 --> Config Class Initialized
DEBUG - 2012-10-09 17:34:06 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:34:06 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:34:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:34:06 --> URI Class Initialized
DEBUG - 2012-10-09 17:34:06 --> Router Class Initialized
DEBUG - 2012-10-09 17:34:06 --> Output Class Initialized
DEBUG - 2012-10-09 17:34:06 --> Security Class Initialized
DEBUG - 2012-10-09 17:34:06 --> Input Class Initialized
DEBUG - 2012-10-09 17:34:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:34:06 --> Language Class Initialized
DEBUG - 2012-10-09 17:34:06 --> Loader Class Initialized
DEBUG - 2012-10-09 17:34:06 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:34:06 --> Controller Class Initialized
DEBUG - 2012-10-09 17:34:06 --> Model Class Initialized
DEBUG - 2012-10-09 17:34:06 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:34:06 --> Helper loaded: language_helper
DEBUG - 2012-10-09 17:34:06 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 17:34:13 --> Config Class Initialized
DEBUG - 2012-10-09 17:34:13 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:34:13 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:34:13 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:34:13 --> URI Class Initialized
DEBUG - 2012-10-09 17:34:13 --> Router Class Initialized
DEBUG - 2012-10-09 17:34:13 --> Output Class Initialized
DEBUG - 2012-10-09 17:34:13 --> Security Class Initialized
DEBUG - 2012-10-09 17:34:13 --> Input Class Initialized
DEBUG - 2012-10-09 17:34:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:34:13 --> Language Class Initialized
DEBUG - 2012-10-09 17:34:13 --> Loader Class Initialized
DEBUG - 2012-10-09 17:34:13 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:34:13 --> Controller Class Initialized
DEBUG - 2012-10-09 17:34:13 --> Model Class Initialized
DEBUG - 2012-10-09 17:34:13 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:34:13 --> Helper loaded: form_helper
DEBUG - 2012-10-09 17:34:13 --> Helper loaded: language_helper
DEBUG - 2012-10-09 17:34:13 --> Form Validation Class Initialized
DEBUG - 2012-10-09 17:34:13 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 17:34:13 --> Upload Class Initialized
DEBUG - 2012-10-09 17:34:13 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 17:34:13 --> Final output sent to browser
DEBUG - 2012-10-09 17:34:13 --> Total execution time: 0.1369
DEBUG - 2012-10-09 17:41:09 --> Config Class Initialized
DEBUG - 2012-10-09 17:41:09 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:41:09 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:41:09 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:41:09 --> URI Class Initialized
DEBUG - 2012-10-09 17:41:09 --> Router Class Initialized
DEBUG - 2012-10-09 17:41:09 --> Output Class Initialized
DEBUG - 2012-10-09 17:41:09 --> Security Class Initialized
DEBUG - 2012-10-09 17:41:09 --> Input Class Initialized
DEBUG - 2012-10-09 17:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:41:09 --> Language Class Initialized
DEBUG - 2012-10-09 17:41:09 --> Loader Class Initialized
DEBUG - 2012-10-09 17:41:09 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:41:09 --> Controller Class Initialized
DEBUG - 2012-10-09 17:41:09 --> Model Class Initialized
DEBUG - 2012-10-09 17:41:09 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:41:09 --> Helper loaded: form_helper
DEBUG - 2012-10-09 17:41:09 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 17:41:09 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 17:41:09 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 17:41:09 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 17:41:09 --> Final output sent to browser
DEBUG - 2012-10-09 17:41:09 --> Total execution time: 0.0397
DEBUG - 2012-10-09 17:41:11 --> Config Class Initialized
DEBUG - 2012-10-09 17:41:11 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:41:11 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:41:11 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:41:11 --> URI Class Initialized
DEBUG - 2012-10-09 17:41:11 --> Router Class Initialized
ERROR - 2012-10-09 17:41:11 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 17:41:11 --> Config Class Initialized
DEBUG - 2012-10-09 17:41:11 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:41:11 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:41:11 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:41:11 --> URI Class Initialized
DEBUG - 2012-10-09 17:41:11 --> Router Class Initialized
ERROR - 2012-10-09 17:41:11 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 17:41:11 --> Config Class Initialized
DEBUG - 2012-10-09 17:41:11 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:41:11 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:41:11 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:41:11 --> URI Class Initialized
DEBUG - 2012-10-09 17:41:11 --> Router Class Initialized
ERROR - 2012-10-09 17:41:11 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 17:41:13 --> Config Class Initialized
DEBUG - 2012-10-09 17:41:13 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:41:13 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:41:13 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:41:13 --> URI Class Initialized
DEBUG - 2012-10-09 17:41:13 --> Router Class Initialized
DEBUG - 2012-10-09 17:41:13 --> Output Class Initialized
DEBUG - 2012-10-09 17:41:13 --> Security Class Initialized
DEBUG - 2012-10-09 17:41:13 --> Input Class Initialized
DEBUG - 2012-10-09 17:41:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:41:13 --> Language Class Initialized
DEBUG - 2012-10-09 17:41:13 --> Loader Class Initialized
DEBUG - 2012-10-09 17:41:13 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:41:13 --> Controller Class Initialized
DEBUG - 2012-10-09 17:41:13 --> Model Class Initialized
DEBUG - 2012-10-09 17:41:13 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:41:13 --> Helper loaded: language_helper
DEBUG - 2012-10-09 17:41:13 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 17:41:18 --> Config Class Initialized
DEBUG - 2012-10-09 17:41:18 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:41:18 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:41:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:41:18 --> URI Class Initialized
DEBUG - 2012-10-09 17:41:18 --> Router Class Initialized
DEBUG - 2012-10-09 17:41:18 --> Output Class Initialized
DEBUG - 2012-10-09 17:41:18 --> Security Class Initialized
DEBUG - 2012-10-09 17:41:18 --> Input Class Initialized
DEBUG - 2012-10-09 17:41:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:41:18 --> Language Class Initialized
DEBUG - 2012-10-09 17:41:18 --> Loader Class Initialized
DEBUG - 2012-10-09 17:41:18 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:41:18 --> Controller Class Initialized
DEBUG - 2012-10-09 17:41:18 --> Model Class Initialized
DEBUG - 2012-10-09 17:41:18 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:41:18 --> Helper loaded: form_helper
DEBUG - 2012-10-09 17:41:18 --> Helper loaded: language_helper
DEBUG - 2012-10-09 17:41:18 --> Form Validation Class Initialized
DEBUG - 2012-10-09 17:41:18 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 17:41:18 --> Upload Class Initialized
DEBUG - 2012-10-09 17:41:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 17:41:18 --> Final output sent to browser
DEBUG - 2012-10-09 17:41:18 --> Total execution time: 0.1676
DEBUG - 2012-10-09 17:41:31 --> Config Class Initialized
DEBUG - 2012-10-09 17:41:31 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:41:31 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:41:31 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:41:31 --> URI Class Initialized
DEBUG - 2012-10-09 17:41:31 --> Router Class Initialized
DEBUG - 2012-10-09 17:41:31 --> Output Class Initialized
DEBUG - 2012-10-09 17:41:31 --> Security Class Initialized
DEBUG - 2012-10-09 17:41:31 --> Input Class Initialized
DEBUG - 2012-10-09 17:41:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:41:31 --> Language Class Initialized
DEBUG - 2012-10-09 17:41:31 --> Loader Class Initialized
DEBUG - 2012-10-09 17:41:31 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:41:31 --> Controller Class Initialized
DEBUG - 2012-10-09 17:41:31 --> Model Class Initialized
DEBUG - 2012-10-09 17:41:31 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:41:31 --> Helper loaded: form_helper
DEBUG - 2012-10-09 17:41:31 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 17:41:31 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 17:41:31 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 17:41:31 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 17:41:31 --> Final output sent to browser
DEBUG - 2012-10-09 17:41:31 --> Total execution time: 0.0411
DEBUG - 2012-10-09 17:41:33 --> Config Class Initialized
DEBUG - 2012-10-09 17:41:33 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:41:33 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:41:33 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:41:33 --> URI Class Initialized
DEBUG - 2012-10-09 17:41:33 --> Router Class Initialized
ERROR - 2012-10-09 17:41:33 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 17:41:33 --> Config Class Initialized
DEBUG - 2012-10-09 17:41:33 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:41:33 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:41:33 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:41:33 --> URI Class Initialized
DEBUG - 2012-10-09 17:41:33 --> Router Class Initialized
ERROR - 2012-10-09 17:41:33 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 17:41:33 --> Config Class Initialized
DEBUG - 2012-10-09 17:41:33 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:41:33 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:41:33 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:41:33 --> URI Class Initialized
DEBUG - 2012-10-09 17:41:33 --> Router Class Initialized
ERROR - 2012-10-09 17:41:33 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 17:41:37 --> Config Class Initialized
DEBUG - 2012-10-09 17:41:37 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:41:37 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:41:37 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:41:37 --> URI Class Initialized
DEBUG - 2012-10-09 17:41:37 --> Router Class Initialized
DEBUG - 2012-10-09 17:41:37 --> Output Class Initialized
DEBUG - 2012-10-09 17:41:37 --> Security Class Initialized
DEBUG - 2012-10-09 17:41:37 --> Input Class Initialized
DEBUG - 2012-10-09 17:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:41:37 --> Language Class Initialized
DEBUG - 2012-10-09 17:41:37 --> Loader Class Initialized
DEBUG - 2012-10-09 17:41:37 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:41:37 --> Controller Class Initialized
DEBUG - 2012-10-09 17:41:37 --> Model Class Initialized
DEBUG - 2012-10-09 17:41:37 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:41:37 --> Helper loaded: language_helper
DEBUG - 2012-10-09 17:41:37 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 17:41:45 --> Config Class Initialized
DEBUG - 2012-10-09 17:41:45 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:41:45 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:41:45 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:41:45 --> URI Class Initialized
DEBUG - 2012-10-09 17:41:45 --> Router Class Initialized
DEBUG - 2012-10-09 17:41:45 --> Output Class Initialized
DEBUG - 2012-10-09 17:41:45 --> Security Class Initialized
DEBUG - 2012-10-09 17:41:45 --> Input Class Initialized
DEBUG - 2012-10-09 17:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:41:45 --> Language Class Initialized
DEBUG - 2012-10-09 17:41:45 --> Loader Class Initialized
DEBUG - 2012-10-09 17:41:45 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:41:45 --> Controller Class Initialized
DEBUG - 2012-10-09 17:41:45 --> Model Class Initialized
DEBUG - 2012-10-09 17:41:45 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:41:45 --> Helper loaded: form_helper
DEBUG - 2012-10-09 17:41:45 --> Helper loaded: language_helper
DEBUG - 2012-10-09 17:41:45 --> Form Validation Class Initialized
DEBUG - 2012-10-09 17:41:45 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 17:41:45 --> Upload Class Initialized
DEBUG - 2012-10-09 17:41:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 17:41:45 --> Image Lib Class Initialized
DEBUG - 2012-10-09 17:41:45 --> Final output sent to browser
DEBUG - 2012-10-09 17:41:45 --> Total execution time: 0.1617
DEBUG - 2012-10-09 17:41:52 --> Config Class Initialized
DEBUG - 2012-10-09 17:41:52 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:41:52 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:41:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:41:52 --> URI Class Initialized
DEBUG - 2012-10-09 17:41:52 --> Router Class Initialized
DEBUG - 2012-10-09 17:41:52 --> Output Class Initialized
DEBUG - 2012-10-09 17:41:52 --> Security Class Initialized
DEBUG - 2012-10-09 17:41:52 --> Input Class Initialized
DEBUG - 2012-10-09 17:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:41:52 --> Language Class Initialized
DEBUG - 2012-10-09 17:41:52 --> Loader Class Initialized
DEBUG - 2012-10-09 17:41:52 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:41:52 --> Controller Class Initialized
DEBUG - 2012-10-09 17:41:52 --> Model Class Initialized
DEBUG - 2012-10-09 17:41:52 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:41:53 --> Final output sent to browser
DEBUG - 2012-10-09 17:41:53 --> Total execution time: 0.1854
DEBUG - 2012-10-09 17:41:57 --> Config Class Initialized
DEBUG - 2012-10-09 17:41:57 --> Hooks Class Initialized
DEBUG - 2012-10-09 17:41:57 --> Utf8 Class Initialized
DEBUG - 2012-10-09 17:41:57 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 17:41:57 --> URI Class Initialized
DEBUG - 2012-10-09 17:41:57 --> Router Class Initialized
DEBUG - 2012-10-09 17:41:57 --> Output Class Initialized
DEBUG - 2012-10-09 17:41:57 --> Security Class Initialized
DEBUG - 2012-10-09 17:41:57 --> Input Class Initialized
DEBUG - 2012-10-09 17:41:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 17:41:57 --> Language Class Initialized
DEBUG - 2012-10-09 17:41:57 --> Loader Class Initialized
DEBUG - 2012-10-09 17:41:57 --> Helper loaded: url_helper
DEBUG - 2012-10-09 17:41:57 --> Controller Class Initialized
DEBUG - 2012-10-09 17:41:57 --> Model Class Initialized
DEBUG - 2012-10-09 17:41:57 --> Database Driver Class Initialized
DEBUG - 2012-10-09 17:41:57 --> Final output sent to browser
DEBUG - 2012-10-09 17:41:57 --> Total execution time: 0.1307
DEBUG - 2012-10-09 19:14:51 --> Config Class Initialized
DEBUG - 2012-10-09 19:14:51 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:14:51 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:14:51 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:14:51 --> URI Class Initialized
DEBUG - 2012-10-09 19:14:51 --> Router Class Initialized
DEBUG - 2012-10-09 19:14:51 --> Output Class Initialized
DEBUG - 2012-10-09 19:14:51 --> Security Class Initialized
DEBUG - 2012-10-09 19:14:51 --> Input Class Initialized
DEBUG - 2012-10-09 19:14:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:14:51 --> Language Class Initialized
DEBUG - 2012-10-09 19:14:51 --> Loader Class Initialized
DEBUG - 2012-10-09 19:14:51 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:14:51 --> Controller Class Initialized
DEBUG - 2012-10-09 19:14:51 --> Model Class Initialized
DEBUG - 2012-10-09 19:14:51 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:14:51 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:14:51 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 19:14:51 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 19:14:51 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 19:14:51 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 19:14:51 --> Final output sent to browser
DEBUG - 2012-10-09 19:14:51 --> Total execution time: 0.0416
DEBUG - 2012-10-09 19:14:53 --> Config Class Initialized
DEBUG - 2012-10-09 19:14:53 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:14:53 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:14:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:14:53 --> URI Class Initialized
DEBUG - 2012-10-09 19:14:53 --> Router Class Initialized
ERROR - 2012-10-09 19:14:53 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:14:53 --> Config Class Initialized
DEBUG - 2012-10-09 19:14:53 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:14:53 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:14:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:14:53 --> URI Class Initialized
DEBUG - 2012-10-09 19:14:53 --> Router Class Initialized
ERROR - 2012-10-09 19:14:53 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:14:53 --> Config Class Initialized
DEBUG - 2012-10-09 19:14:53 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:14:53 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:14:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:14:53 --> URI Class Initialized
DEBUG - 2012-10-09 19:14:53 --> Router Class Initialized
ERROR - 2012-10-09 19:14:53 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:15:04 --> Config Class Initialized
DEBUG - 2012-10-09 19:15:04 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:15:04 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:15:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:15:04 --> URI Class Initialized
DEBUG - 2012-10-09 19:15:04 --> Router Class Initialized
DEBUG - 2012-10-09 19:15:04 --> Output Class Initialized
DEBUG - 2012-10-09 19:15:04 --> Security Class Initialized
DEBUG - 2012-10-09 19:15:04 --> Input Class Initialized
DEBUG - 2012-10-09 19:15:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:15:04 --> Language Class Initialized
DEBUG - 2012-10-09 19:15:04 --> Loader Class Initialized
DEBUG - 2012-10-09 19:15:04 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:15:04 --> Controller Class Initialized
DEBUG - 2012-10-09 19:15:04 --> Model Class Initialized
DEBUG - 2012-10-09 19:15:04 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:15:04 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:15:04 --> Helper loaded: language_helper
DEBUG - 2012-10-09 19:15:04 --> Form Validation Class Initialized
DEBUG - 2012-10-09 19:15:04 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 19:15:04 --> Upload Class Initialized
DEBUG - 2012-10-09 19:15:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 19:15:04 --> Final output sent to browser
DEBUG - 2012-10-09 19:15:04 --> Total execution time: 0.1002
DEBUG - 2012-10-09 19:15:21 --> Config Class Initialized
DEBUG - 2012-10-09 19:15:21 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:15:21 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:15:21 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:15:21 --> URI Class Initialized
DEBUG - 2012-10-09 19:15:21 --> Router Class Initialized
DEBUG - 2012-10-09 19:15:21 --> Output Class Initialized
DEBUG - 2012-10-09 19:15:21 --> Security Class Initialized
DEBUG - 2012-10-09 19:15:21 --> Input Class Initialized
DEBUG - 2012-10-09 19:15:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:15:21 --> Language Class Initialized
DEBUG - 2012-10-09 19:15:21 --> Loader Class Initialized
DEBUG - 2012-10-09 19:15:21 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:15:21 --> Controller Class Initialized
DEBUG - 2012-10-09 19:15:21 --> Model Class Initialized
DEBUG - 2012-10-09 19:15:21 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:15:21 --> Helper loaded: language_helper
DEBUG - 2012-10-09 19:15:21 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 19:15:34 --> Config Class Initialized
DEBUG - 2012-10-09 19:15:34 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:15:34 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:15:34 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:15:34 --> URI Class Initialized
DEBUG - 2012-10-09 19:15:34 --> Router Class Initialized
DEBUG - 2012-10-09 19:15:34 --> Output Class Initialized
DEBUG - 2012-10-09 19:15:34 --> Security Class Initialized
DEBUG - 2012-10-09 19:15:34 --> Input Class Initialized
DEBUG - 2012-10-09 19:15:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:15:34 --> Language Class Initialized
DEBUG - 2012-10-09 19:15:34 --> Loader Class Initialized
DEBUG - 2012-10-09 19:15:34 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:15:34 --> Controller Class Initialized
DEBUG - 2012-10-09 19:15:34 --> Model Class Initialized
DEBUG - 2012-10-09 19:15:34 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:15:34 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:15:34 --> Helper loaded: language_helper
DEBUG - 2012-10-09 19:15:34 --> Form Validation Class Initialized
DEBUG - 2012-10-09 19:15:34 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 19:15:34 --> Upload Class Initialized
DEBUG - 2012-10-09 19:15:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 19:15:34 --> Image Lib Class Initialized
DEBUG - 2012-10-09 19:15:34 --> Final output sent to browser
DEBUG - 2012-10-09 19:15:34 --> Total execution time: 0.6063
DEBUG - 2012-10-09 19:19:28 --> Config Class Initialized
DEBUG - 2012-10-09 19:19:28 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:19:28 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:19:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:19:28 --> URI Class Initialized
DEBUG - 2012-10-09 19:19:28 --> Router Class Initialized
DEBUG - 2012-10-09 19:19:28 --> Output Class Initialized
DEBUG - 2012-10-09 19:19:28 --> Security Class Initialized
DEBUG - 2012-10-09 19:19:28 --> Input Class Initialized
DEBUG - 2012-10-09 19:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:19:28 --> Language Class Initialized
DEBUG - 2012-10-09 19:19:28 --> Loader Class Initialized
DEBUG - 2012-10-09 19:19:28 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:19:28 --> Controller Class Initialized
DEBUG - 2012-10-09 19:19:28 --> Model Class Initialized
DEBUG - 2012-10-09 19:19:28 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:19:28 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:19:28 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 19:19:29 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 19:19:29 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 19:19:29 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 19:19:29 --> Final output sent to browser
DEBUG - 2012-10-09 19:19:29 --> Total execution time: 0.0404
DEBUG - 2012-10-09 19:19:31 --> Config Class Initialized
DEBUG - 2012-10-09 19:19:31 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:19:31 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:19:31 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:19:31 --> URI Class Initialized
DEBUG - 2012-10-09 19:19:31 --> Router Class Initialized
ERROR - 2012-10-09 19:19:31 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:19:31 --> Config Class Initialized
DEBUG - 2012-10-09 19:19:31 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:19:31 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:19:31 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:19:31 --> URI Class Initialized
DEBUG - 2012-10-09 19:19:31 --> Router Class Initialized
ERROR - 2012-10-09 19:19:31 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:19:31 --> Config Class Initialized
DEBUG - 2012-10-09 19:19:31 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:19:31 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:19:31 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:19:31 --> URI Class Initialized
DEBUG - 2012-10-09 19:19:31 --> Router Class Initialized
ERROR - 2012-10-09 19:19:31 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:19:36 --> Config Class Initialized
DEBUG - 2012-10-09 19:19:36 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:19:36 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:19:36 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:19:36 --> URI Class Initialized
DEBUG - 2012-10-09 19:19:36 --> Router Class Initialized
DEBUG - 2012-10-09 19:19:36 --> Output Class Initialized
DEBUG - 2012-10-09 19:19:36 --> Security Class Initialized
DEBUG - 2012-10-09 19:19:36 --> Input Class Initialized
DEBUG - 2012-10-09 19:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:19:36 --> Language Class Initialized
DEBUG - 2012-10-09 19:19:36 --> Loader Class Initialized
DEBUG - 2012-10-09 19:19:36 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:19:36 --> Controller Class Initialized
DEBUG - 2012-10-09 19:19:36 --> Model Class Initialized
DEBUG - 2012-10-09 19:19:36 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:19:36 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:19:36 --> Helper loaded: language_helper
DEBUG - 2012-10-09 19:19:36 --> Form Validation Class Initialized
DEBUG - 2012-10-09 19:19:36 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 19:19:36 --> Upload Class Initialized
DEBUG - 2012-10-09 19:19:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 19:19:36 --> Final output sent to browser
DEBUG - 2012-10-09 19:19:36 --> Total execution time: 0.1649
DEBUG - 2012-10-09 19:19:38 --> Config Class Initialized
DEBUG - 2012-10-09 19:19:38 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:19:38 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:19:38 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:19:38 --> URI Class Initialized
DEBUG - 2012-10-09 19:19:38 --> Router Class Initialized
DEBUG - 2012-10-09 19:19:38 --> Output Class Initialized
DEBUG - 2012-10-09 19:19:38 --> Security Class Initialized
DEBUG - 2012-10-09 19:19:38 --> Input Class Initialized
DEBUG - 2012-10-09 19:19:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:19:38 --> Language Class Initialized
DEBUG - 2012-10-09 19:19:38 --> Loader Class Initialized
DEBUG - 2012-10-09 19:19:38 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:19:38 --> Controller Class Initialized
DEBUG - 2012-10-09 19:19:38 --> Model Class Initialized
DEBUG - 2012-10-09 19:19:39 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:19:39 --> Helper loaded: language_helper
DEBUG - 2012-10-09 19:19:39 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 19:19:45 --> Config Class Initialized
DEBUG - 2012-10-09 19:19:45 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:19:45 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:19:45 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:19:45 --> URI Class Initialized
DEBUG - 2012-10-09 19:19:45 --> Router Class Initialized
DEBUG - 2012-10-09 19:19:45 --> Output Class Initialized
DEBUG - 2012-10-09 19:19:45 --> Security Class Initialized
DEBUG - 2012-10-09 19:19:45 --> Input Class Initialized
DEBUG - 2012-10-09 19:19:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:19:45 --> Language Class Initialized
DEBUG - 2012-10-09 19:19:45 --> Loader Class Initialized
DEBUG - 2012-10-09 19:19:45 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:19:45 --> Controller Class Initialized
DEBUG - 2012-10-09 19:19:45 --> Model Class Initialized
DEBUG - 2012-10-09 19:19:45 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:19:45 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:19:45 --> Helper loaded: language_helper
DEBUG - 2012-10-09 19:19:45 --> Form Validation Class Initialized
DEBUG - 2012-10-09 19:19:45 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 19:19:45 --> Upload Class Initialized
DEBUG - 2012-10-09 19:19:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 19:19:45 --> Image Lib Class Initialized
DEBUG - 2012-10-09 19:19:46 --> Final output sent to browser
DEBUG - 2012-10-09 19:19:46 --> Total execution time: 0.1929
DEBUG - 2012-10-09 19:20:31 --> Config Class Initialized
DEBUG - 2012-10-09 19:20:31 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:20:31 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:20:31 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:20:31 --> URI Class Initialized
DEBUG - 2012-10-09 19:20:31 --> Router Class Initialized
DEBUG - 2012-10-09 19:20:31 --> Output Class Initialized
DEBUG - 2012-10-09 19:20:31 --> Security Class Initialized
DEBUG - 2012-10-09 19:20:31 --> Input Class Initialized
DEBUG - 2012-10-09 19:20:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:20:31 --> Language Class Initialized
DEBUG - 2012-10-09 19:20:31 --> Loader Class Initialized
DEBUG - 2012-10-09 19:20:31 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:20:31 --> Controller Class Initialized
DEBUG - 2012-10-09 19:20:31 --> Model Class Initialized
DEBUG - 2012-10-09 19:20:31 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:20:31 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:20:31 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 19:20:31 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 19:20:31 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 19:20:31 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 19:20:31 --> Final output sent to browser
DEBUG - 2012-10-09 19:20:31 --> Total execution time: 0.0398
DEBUG - 2012-10-09 19:20:33 --> Config Class Initialized
DEBUG - 2012-10-09 19:20:33 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:20:33 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:20:33 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:20:33 --> URI Class Initialized
DEBUG - 2012-10-09 19:20:33 --> Router Class Initialized
ERROR - 2012-10-09 19:20:33 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:20:33 --> Config Class Initialized
DEBUG - 2012-10-09 19:20:33 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:20:33 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:20:33 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:20:33 --> URI Class Initialized
DEBUG - 2012-10-09 19:20:33 --> Router Class Initialized
ERROR - 2012-10-09 19:20:33 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:20:34 --> Config Class Initialized
DEBUG - 2012-10-09 19:20:34 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:20:34 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:20:34 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:20:34 --> URI Class Initialized
DEBUG - 2012-10-09 19:20:34 --> Router Class Initialized
ERROR - 2012-10-09 19:20:34 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:20:38 --> Config Class Initialized
DEBUG - 2012-10-09 19:20:38 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:20:38 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:20:38 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:20:38 --> URI Class Initialized
DEBUG - 2012-10-09 19:20:38 --> Router Class Initialized
DEBUG - 2012-10-09 19:20:38 --> Output Class Initialized
DEBUG - 2012-10-09 19:20:38 --> Security Class Initialized
DEBUG - 2012-10-09 19:20:38 --> Input Class Initialized
DEBUG - 2012-10-09 19:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:20:38 --> Language Class Initialized
DEBUG - 2012-10-09 19:20:38 --> Loader Class Initialized
DEBUG - 2012-10-09 19:20:38 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:20:38 --> Controller Class Initialized
DEBUG - 2012-10-09 19:20:38 --> Model Class Initialized
DEBUG - 2012-10-09 19:20:38 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:20:38 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:20:38 --> Helper loaded: language_helper
DEBUG - 2012-10-09 19:20:38 --> Form Validation Class Initialized
DEBUG - 2012-10-09 19:20:38 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 19:20:38 --> Upload Class Initialized
DEBUG - 2012-10-09 19:20:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 19:20:38 --> Final output sent to browser
DEBUG - 2012-10-09 19:20:38 --> Total execution time: 0.0885
DEBUG - 2012-10-09 19:20:40 --> Config Class Initialized
DEBUG - 2012-10-09 19:20:40 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:20:40 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:20:40 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:20:40 --> URI Class Initialized
DEBUG - 2012-10-09 19:20:40 --> Router Class Initialized
DEBUG - 2012-10-09 19:20:40 --> Output Class Initialized
DEBUG - 2012-10-09 19:20:40 --> Security Class Initialized
DEBUG - 2012-10-09 19:20:40 --> Input Class Initialized
DEBUG - 2012-10-09 19:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:20:40 --> Language Class Initialized
DEBUG - 2012-10-09 19:20:40 --> Loader Class Initialized
DEBUG - 2012-10-09 19:20:40 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:20:40 --> Controller Class Initialized
DEBUG - 2012-10-09 19:20:40 --> Model Class Initialized
DEBUG - 2012-10-09 19:20:40 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:20:40 --> Helper loaded: language_helper
DEBUG - 2012-10-09 19:20:40 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 19:20:45 --> Config Class Initialized
DEBUG - 2012-10-09 19:20:45 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:20:45 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:20:45 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:20:45 --> URI Class Initialized
DEBUG - 2012-10-09 19:20:45 --> Router Class Initialized
DEBUG - 2012-10-09 19:20:45 --> Output Class Initialized
DEBUG - 2012-10-09 19:20:45 --> Security Class Initialized
DEBUG - 2012-10-09 19:20:45 --> Input Class Initialized
DEBUG - 2012-10-09 19:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:20:45 --> Language Class Initialized
DEBUG - 2012-10-09 19:20:45 --> Loader Class Initialized
DEBUG - 2012-10-09 19:20:45 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:20:45 --> Controller Class Initialized
DEBUG - 2012-10-09 19:20:45 --> Model Class Initialized
DEBUG - 2012-10-09 19:20:45 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:20:45 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:20:45 --> Helper loaded: language_helper
DEBUG - 2012-10-09 19:20:45 --> Form Validation Class Initialized
DEBUG - 2012-10-09 19:20:45 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 19:20:45 --> Upload Class Initialized
DEBUG - 2012-10-09 19:20:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 19:20:45 --> Image Lib Class Initialized
DEBUG - 2012-10-09 19:20:46 --> Final output sent to browser
DEBUG - 2012-10-09 19:20:46 --> Total execution time: 0.7025
DEBUG - 2012-10-09 19:26:50 --> Config Class Initialized
DEBUG - 2012-10-09 19:26:50 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:26:50 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:26:50 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:26:50 --> URI Class Initialized
DEBUG - 2012-10-09 19:26:50 --> Router Class Initialized
DEBUG - 2012-10-09 19:26:50 --> Output Class Initialized
DEBUG - 2012-10-09 19:26:50 --> Security Class Initialized
DEBUG - 2012-10-09 19:26:50 --> Input Class Initialized
DEBUG - 2012-10-09 19:26:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:26:50 --> Language Class Initialized
DEBUG - 2012-10-09 19:26:50 --> Loader Class Initialized
DEBUG - 2012-10-09 19:26:50 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:26:50 --> Controller Class Initialized
DEBUG - 2012-10-09 19:26:50 --> Model Class Initialized
DEBUG - 2012-10-09 19:26:50 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:26:50 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:26:50 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 19:26:50 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 19:26:50 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 19:26:50 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 19:26:50 --> Final output sent to browser
DEBUG - 2012-10-09 19:26:50 --> Total execution time: 0.0483
DEBUG - 2012-10-09 19:26:52 --> Config Class Initialized
DEBUG - 2012-10-09 19:26:52 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:26:52 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:26:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:26:52 --> URI Class Initialized
DEBUG - 2012-10-09 19:26:52 --> Router Class Initialized
ERROR - 2012-10-09 19:26:52 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:26:52 --> Config Class Initialized
DEBUG - 2012-10-09 19:26:52 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:26:52 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:26:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:26:52 --> URI Class Initialized
DEBUG - 2012-10-09 19:26:52 --> Router Class Initialized
ERROR - 2012-10-09 19:26:52 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:26:52 --> Config Class Initialized
DEBUG - 2012-10-09 19:26:52 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:26:52 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:26:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:26:52 --> URI Class Initialized
DEBUG - 2012-10-09 19:26:52 --> Router Class Initialized
ERROR - 2012-10-09 19:26:52 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:26:57 --> Config Class Initialized
DEBUG - 2012-10-09 19:26:57 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:26:57 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:26:57 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:26:57 --> URI Class Initialized
DEBUG - 2012-10-09 19:26:57 --> Router Class Initialized
DEBUG - 2012-10-09 19:26:57 --> Output Class Initialized
DEBUG - 2012-10-09 19:26:57 --> Security Class Initialized
DEBUG - 2012-10-09 19:26:57 --> Input Class Initialized
DEBUG - 2012-10-09 19:26:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:26:57 --> Language Class Initialized
DEBUG - 2012-10-09 19:26:57 --> Loader Class Initialized
DEBUG - 2012-10-09 19:26:57 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:26:57 --> Controller Class Initialized
DEBUG - 2012-10-09 19:26:57 --> Model Class Initialized
DEBUG - 2012-10-09 19:26:57 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:26:57 --> Final output sent to browser
DEBUG - 2012-10-09 19:26:57 --> Total execution time: 0.1568
DEBUG - 2012-10-09 19:27:00 --> Config Class Initialized
DEBUG - 2012-10-09 19:27:00 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:27:00 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:27:00 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:27:00 --> URI Class Initialized
DEBUG - 2012-10-09 19:27:00 --> Router Class Initialized
DEBUG - 2012-10-09 19:27:00 --> Output Class Initialized
DEBUG - 2012-10-09 19:27:00 --> Security Class Initialized
DEBUG - 2012-10-09 19:27:00 --> Input Class Initialized
DEBUG - 2012-10-09 19:27:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:27:00 --> Language Class Initialized
DEBUG - 2012-10-09 19:27:00 --> Loader Class Initialized
DEBUG - 2012-10-09 19:27:00 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:27:00 --> Controller Class Initialized
DEBUG - 2012-10-09 19:27:00 --> Model Class Initialized
DEBUG - 2012-10-09 19:27:00 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:27:00 --> Final output sent to browser
DEBUG - 2012-10-09 19:27:00 --> Total execution time: 0.1189
DEBUG - 2012-10-09 19:27:03 --> Config Class Initialized
DEBUG - 2012-10-09 19:27:03 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:27:03 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:27:03 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:27:03 --> URI Class Initialized
DEBUG - 2012-10-09 19:27:03 --> Router Class Initialized
DEBUG - 2012-10-09 19:27:03 --> Output Class Initialized
DEBUG - 2012-10-09 19:27:03 --> Security Class Initialized
DEBUG - 2012-10-09 19:27:03 --> Input Class Initialized
DEBUG - 2012-10-09 19:27:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:27:03 --> Language Class Initialized
DEBUG - 2012-10-09 19:27:03 --> Loader Class Initialized
DEBUG - 2012-10-09 19:27:03 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:27:03 --> Controller Class Initialized
DEBUG - 2012-10-09 19:27:03 --> Model Class Initialized
DEBUG - 2012-10-09 19:27:03 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:27:03 --> Final output sent to browser
DEBUG - 2012-10-09 19:27:03 --> Total execution time: 0.1292
DEBUG - 2012-10-09 19:27:14 --> Config Class Initialized
DEBUG - 2012-10-09 19:27:14 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:27:14 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:27:14 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:27:14 --> URI Class Initialized
DEBUG - 2012-10-09 19:27:14 --> Router Class Initialized
DEBUG - 2012-10-09 19:27:14 --> Output Class Initialized
DEBUG - 2012-10-09 19:27:14 --> Security Class Initialized
DEBUG - 2012-10-09 19:27:14 --> Input Class Initialized
DEBUG - 2012-10-09 19:27:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:27:14 --> Language Class Initialized
DEBUG - 2012-10-09 19:27:14 --> Loader Class Initialized
DEBUG - 2012-10-09 19:27:14 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:27:14 --> Controller Class Initialized
DEBUG - 2012-10-09 19:27:14 --> Model Class Initialized
DEBUG - 2012-10-09 19:27:14 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:27:14 --> Final output sent to browser
DEBUG - 2012-10-09 19:27:14 --> Total execution time: 0.1599
DEBUG - 2012-10-09 19:27:30 --> Config Class Initialized
DEBUG - 2012-10-09 19:27:30 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:27:30 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:27:30 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:27:30 --> URI Class Initialized
DEBUG - 2012-10-09 19:27:30 --> Router Class Initialized
DEBUG - 2012-10-09 19:27:30 --> Output Class Initialized
DEBUG - 2012-10-09 19:27:30 --> Security Class Initialized
DEBUG - 2012-10-09 19:27:30 --> Input Class Initialized
DEBUG - 2012-10-09 19:27:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:27:30 --> Language Class Initialized
DEBUG - 2012-10-09 19:27:30 --> Loader Class Initialized
DEBUG - 2012-10-09 19:27:30 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:27:30 --> Controller Class Initialized
DEBUG - 2012-10-09 19:27:30 --> Model Class Initialized
DEBUG - 2012-10-09 19:27:30 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:27:30 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:27:30 --> Helper loaded: language_helper
DEBUG - 2012-10-09 19:27:30 --> Form Validation Class Initialized
DEBUG - 2012-10-09 19:27:30 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 19:27:30 --> Upload Class Initialized
DEBUG - 2012-10-09 19:27:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 19:27:30 --> Final output sent to browser
DEBUG - 2012-10-09 19:27:30 --> Total execution time: 0.1792
DEBUG - 2012-10-09 19:27:33 --> Config Class Initialized
DEBUG - 2012-10-09 19:27:33 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:27:33 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:27:33 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:27:33 --> URI Class Initialized
DEBUG - 2012-10-09 19:27:33 --> Router Class Initialized
DEBUG - 2012-10-09 19:27:33 --> Output Class Initialized
DEBUG - 2012-10-09 19:27:33 --> Security Class Initialized
DEBUG - 2012-10-09 19:27:33 --> Input Class Initialized
DEBUG - 2012-10-09 19:27:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:27:33 --> Language Class Initialized
DEBUG - 2012-10-09 19:27:33 --> Loader Class Initialized
DEBUG - 2012-10-09 19:27:33 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:27:33 --> Controller Class Initialized
DEBUG - 2012-10-09 19:27:33 --> Model Class Initialized
DEBUG - 2012-10-09 19:27:33 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:27:33 --> Helper loaded: language_helper
DEBUG - 2012-10-09 19:27:33 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 19:27:37 --> Config Class Initialized
DEBUG - 2012-10-09 19:27:37 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:27:37 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:27:37 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:27:37 --> URI Class Initialized
DEBUG - 2012-10-09 19:27:37 --> Router Class Initialized
DEBUG - 2012-10-09 19:27:37 --> Output Class Initialized
DEBUG - 2012-10-09 19:27:37 --> Security Class Initialized
DEBUG - 2012-10-09 19:27:37 --> Input Class Initialized
DEBUG - 2012-10-09 19:27:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:27:37 --> Language Class Initialized
DEBUG - 2012-10-09 19:27:37 --> Loader Class Initialized
DEBUG - 2012-10-09 19:27:37 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:27:37 --> Controller Class Initialized
DEBUG - 2012-10-09 19:27:37 --> Model Class Initialized
DEBUG - 2012-10-09 19:27:37 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:27:37 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:27:37 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 19:27:37 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 19:27:37 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 19:27:37 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 19:27:37 --> Final output sent to browser
DEBUG - 2012-10-09 19:27:37 --> Total execution time: 0.0404
DEBUG - 2012-10-09 19:27:39 --> Config Class Initialized
DEBUG - 2012-10-09 19:27:39 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:27:39 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:27:39 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:27:39 --> URI Class Initialized
DEBUG - 2012-10-09 19:27:39 --> Router Class Initialized
ERROR - 2012-10-09 19:27:39 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:27:39 --> Config Class Initialized
DEBUG - 2012-10-09 19:27:39 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:27:39 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:27:39 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:27:39 --> URI Class Initialized
DEBUG - 2012-10-09 19:27:39 --> Router Class Initialized
ERROR - 2012-10-09 19:27:39 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:27:39 --> Config Class Initialized
DEBUG - 2012-10-09 19:27:39 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:27:39 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:27:39 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:27:39 --> URI Class Initialized
DEBUG - 2012-10-09 19:27:39 --> Router Class Initialized
ERROR - 2012-10-09 19:27:39 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:27:40 --> Config Class Initialized
DEBUG - 2012-10-09 19:27:40 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:27:40 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:27:40 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:27:40 --> URI Class Initialized
DEBUG - 2012-10-09 19:27:40 --> Router Class Initialized
DEBUG - 2012-10-09 19:27:40 --> Output Class Initialized
DEBUG - 2012-10-09 19:27:40 --> Security Class Initialized
DEBUG - 2012-10-09 19:27:40 --> Input Class Initialized
DEBUG - 2012-10-09 19:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:27:40 --> Language Class Initialized
DEBUG - 2012-10-09 19:27:40 --> Loader Class Initialized
DEBUG - 2012-10-09 19:27:40 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:27:40 --> Controller Class Initialized
DEBUG - 2012-10-09 19:27:40 --> Model Class Initialized
DEBUG - 2012-10-09 19:27:40 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:27:40 --> Helper loaded: language_helper
DEBUG - 2012-10-09 19:27:40 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 19:27:46 --> Config Class Initialized
DEBUG - 2012-10-09 19:27:46 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:27:46 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:27:46 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:27:46 --> URI Class Initialized
DEBUG - 2012-10-09 19:27:46 --> Router Class Initialized
DEBUG - 2012-10-09 19:27:46 --> Output Class Initialized
DEBUG - 2012-10-09 19:27:46 --> Security Class Initialized
DEBUG - 2012-10-09 19:27:46 --> Input Class Initialized
DEBUG - 2012-10-09 19:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:27:46 --> Language Class Initialized
DEBUG - 2012-10-09 19:27:46 --> Loader Class Initialized
DEBUG - 2012-10-09 19:27:46 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:27:46 --> Controller Class Initialized
DEBUG - 2012-10-09 19:27:46 --> Model Class Initialized
DEBUG - 2012-10-09 19:27:46 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:27:46 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:27:46 --> Helper loaded: language_helper
DEBUG - 2012-10-09 19:27:46 --> Form Validation Class Initialized
DEBUG - 2012-10-09 19:27:46 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 19:27:46 --> Upload Class Initialized
DEBUG - 2012-10-09 19:27:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 19:27:46 --> Image Lib Class Initialized
DEBUG - 2012-10-09 19:27:46 --> Final output sent to browser
DEBUG - 2012-10-09 19:27:46 --> Total execution time: 0.1644
DEBUG - 2012-10-09 19:28:15 --> Config Class Initialized
DEBUG - 2012-10-09 19:28:15 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:28:15 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:28:15 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:28:15 --> URI Class Initialized
DEBUG - 2012-10-09 19:28:15 --> Router Class Initialized
DEBUG - 2012-10-09 19:28:15 --> Output Class Initialized
DEBUG - 2012-10-09 19:28:15 --> Security Class Initialized
DEBUG - 2012-10-09 19:28:15 --> Input Class Initialized
DEBUG - 2012-10-09 19:28:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:28:15 --> Language Class Initialized
DEBUG - 2012-10-09 19:28:15 --> Loader Class Initialized
DEBUG - 2012-10-09 19:28:15 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:28:15 --> Controller Class Initialized
DEBUG - 2012-10-09 19:28:15 --> Model Class Initialized
DEBUG - 2012-10-09 19:28:15 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:28:15 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:28:15 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 19:28:15 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 19:28:15 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 19:28:15 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 19:28:15 --> Final output sent to browser
DEBUG - 2012-10-09 19:28:15 --> Total execution time: 0.0400
DEBUG - 2012-10-09 19:28:18 --> Config Class Initialized
DEBUG - 2012-10-09 19:28:18 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:28:18 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:28:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:28:18 --> URI Class Initialized
DEBUG - 2012-10-09 19:28:18 --> Router Class Initialized
ERROR - 2012-10-09 19:28:18 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:28:18 --> Config Class Initialized
DEBUG - 2012-10-09 19:28:18 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:28:18 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:28:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:28:18 --> URI Class Initialized
DEBUG - 2012-10-09 19:28:18 --> Router Class Initialized
ERROR - 2012-10-09 19:28:18 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:28:18 --> Config Class Initialized
DEBUG - 2012-10-09 19:28:18 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:28:18 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:28:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:28:18 --> URI Class Initialized
DEBUG - 2012-10-09 19:28:18 --> Router Class Initialized
ERROR - 2012-10-09 19:28:18 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:28:20 --> Config Class Initialized
DEBUG - 2012-10-09 19:28:20 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:28:20 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:28:20 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:28:20 --> URI Class Initialized
DEBUG - 2012-10-09 19:28:20 --> Router Class Initialized
DEBUG - 2012-10-09 19:28:20 --> Output Class Initialized
DEBUG - 2012-10-09 19:28:20 --> Security Class Initialized
DEBUG - 2012-10-09 19:28:20 --> Input Class Initialized
DEBUG - 2012-10-09 19:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:28:20 --> Language Class Initialized
DEBUG - 2012-10-09 19:28:20 --> Loader Class Initialized
DEBUG - 2012-10-09 19:28:20 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:28:20 --> Controller Class Initialized
DEBUG - 2012-10-09 19:28:20 --> Model Class Initialized
DEBUG - 2012-10-09 19:28:20 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:28:20 --> Final output sent to browser
DEBUG - 2012-10-09 19:28:20 --> Total execution time: 0.1005
DEBUG - 2012-10-09 19:28:22 --> Config Class Initialized
DEBUG - 2012-10-09 19:28:22 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:28:22 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:28:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:28:22 --> URI Class Initialized
DEBUG - 2012-10-09 19:28:22 --> Router Class Initialized
DEBUG - 2012-10-09 19:28:22 --> Output Class Initialized
DEBUG - 2012-10-09 19:28:22 --> Security Class Initialized
DEBUG - 2012-10-09 19:28:22 --> Input Class Initialized
DEBUG - 2012-10-09 19:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:28:22 --> Language Class Initialized
DEBUG - 2012-10-09 19:28:22 --> Loader Class Initialized
DEBUG - 2012-10-09 19:28:22 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:28:22 --> Controller Class Initialized
DEBUG - 2012-10-09 19:28:22 --> Model Class Initialized
DEBUG - 2012-10-09 19:28:22 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:28:22 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:28:22 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 19:28:22 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 19:28:22 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 19:28:22 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 19:28:22 --> Final output sent to browser
DEBUG - 2012-10-09 19:28:22 --> Total execution time: 0.0400
DEBUG - 2012-10-09 19:28:24 --> Config Class Initialized
DEBUG - 2012-10-09 19:28:24 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:28:24 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:28:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:28:24 --> URI Class Initialized
DEBUG - 2012-10-09 19:28:24 --> Router Class Initialized
ERROR - 2012-10-09 19:28:24 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:28:24 --> Config Class Initialized
DEBUG - 2012-10-09 19:28:24 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:28:24 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:28:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:28:24 --> URI Class Initialized
DEBUG - 2012-10-09 19:28:24 --> Router Class Initialized
ERROR - 2012-10-09 19:28:24 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:28:24 --> Config Class Initialized
DEBUG - 2012-10-09 19:28:24 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:28:24 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:28:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:28:24 --> URI Class Initialized
DEBUG - 2012-10-09 19:28:24 --> Router Class Initialized
ERROR - 2012-10-09 19:28:24 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:28:42 --> Config Class Initialized
DEBUG - 2012-10-09 19:28:42 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:28:42 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:28:42 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:28:42 --> URI Class Initialized
DEBUG - 2012-10-09 19:28:42 --> Router Class Initialized
DEBUG - 2012-10-09 19:28:42 --> Output Class Initialized
DEBUG - 2012-10-09 19:28:42 --> Security Class Initialized
DEBUG - 2012-10-09 19:28:42 --> Input Class Initialized
DEBUG - 2012-10-09 19:28:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:28:42 --> Language Class Initialized
DEBUG - 2012-10-09 19:28:42 --> Loader Class Initialized
DEBUG - 2012-10-09 19:28:42 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:28:42 --> Controller Class Initialized
DEBUG - 2012-10-09 19:28:42 --> Model Class Initialized
DEBUG - 2012-10-09 19:28:42 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:28:42 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:28:42 --> Helper loaded: language_helper
DEBUG - 2012-10-09 19:28:42 --> Form Validation Class Initialized
DEBUG - 2012-10-09 19:28:42 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 19:28:42 --> Upload Class Initialized
DEBUG - 2012-10-09 19:28:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 19:28:42 --> Final output sent to browser
DEBUG - 2012-10-09 19:28:42 --> Total execution time: 0.1301
DEBUG - 2012-10-09 19:28:44 --> Config Class Initialized
DEBUG - 2012-10-09 19:28:44 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:28:44 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:28:44 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:28:44 --> URI Class Initialized
DEBUG - 2012-10-09 19:28:44 --> Router Class Initialized
DEBUG - 2012-10-09 19:28:44 --> Output Class Initialized
DEBUG - 2012-10-09 19:28:44 --> Security Class Initialized
DEBUG - 2012-10-09 19:28:44 --> Input Class Initialized
DEBUG - 2012-10-09 19:28:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:28:44 --> Language Class Initialized
DEBUG - 2012-10-09 19:28:44 --> Loader Class Initialized
DEBUG - 2012-10-09 19:28:44 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:28:44 --> Controller Class Initialized
DEBUG - 2012-10-09 19:28:44 --> Model Class Initialized
DEBUG - 2012-10-09 19:28:44 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:28:44 --> Helper loaded: language_helper
DEBUG - 2012-10-09 19:28:44 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 19:28:49 --> Config Class Initialized
DEBUG - 2012-10-09 19:28:49 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:28:49 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:28:49 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:28:49 --> URI Class Initialized
DEBUG - 2012-10-09 19:28:49 --> Router Class Initialized
DEBUG - 2012-10-09 19:28:49 --> Output Class Initialized
DEBUG - 2012-10-09 19:28:49 --> Security Class Initialized
DEBUG - 2012-10-09 19:28:49 --> Input Class Initialized
DEBUG - 2012-10-09 19:28:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:28:49 --> Language Class Initialized
DEBUG - 2012-10-09 19:28:49 --> Loader Class Initialized
DEBUG - 2012-10-09 19:28:49 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:28:49 --> Controller Class Initialized
DEBUG - 2012-10-09 19:28:49 --> Model Class Initialized
DEBUG - 2012-10-09 19:28:49 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:28:49 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:28:49 --> Helper loaded: language_helper
DEBUG - 2012-10-09 19:28:49 --> Form Validation Class Initialized
DEBUG - 2012-10-09 19:28:49 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 19:28:49 --> Upload Class Initialized
DEBUG - 2012-10-09 19:28:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 19:28:49 --> Image Lib Class Initialized
DEBUG - 2012-10-09 19:28:50 --> Final output sent to browser
DEBUG - 2012-10-09 19:28:50 --> Total execution time: 0.2469
DEBUG - 2012-10-09 19:28:59 --> Config Class Initialized
DEBUG - 2012-10-09 19:28:59 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:28:59 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:28:59 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:28:59 --> URI Class Initialized
DEBUG - 2012-10-09 19:28:59 --> Router Class Initialized
DEBUG - 2012-10-09 19:28:59 --> Output Class Initialized
DEBUG - 2012-10-09 19:28:59 --> Security Class Initialized
DEBUG - 2012-10-09 19:28:59 --> Input Class Initialized
DEBUG - 2012-10-09 19:28:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:28:59 --> Language Class Initialized
DEBUG - 2012-10-09 19:29:00 --> Loader Class Initialized
DEBUG - 2012-10-09 19:29:00 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:29:00 --> Controller Class Initialized
DEBUG - 2012-10-09 19:29:00 --> Model Class Initialized
DEBUG - 2012-10-09 19:29:00 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:29:00 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:29:00 --> Helper loaded: language_helper
DEBUG - 2012-10-09 19:29:00 --> Form Validation Class Initialized
DEBUG - 2012-10-09 19:29:00 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 19:29:00 --> Upload Class Initialized
DEBUG - 2012-10-09 19:29:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 19:29:00 --> Final output sent to browser
DEBUG - 2012-10-09 19:29:00 --> Total execution time: 0.2021
DEBUG - 2012-10-09 19:29:02 --> Config Class Initialized
DEBUG - 2012-10-09 19:29:02 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:29:02 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:29:02 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:29:02 --> URI Class Initialized
DEBUG - 2012-10-09 19:29:02 --> Router Class Initialized
DEBUG - 2012-10-09 19:29:02 --> Output Class Initialized
DEBUG - 2012-10-09 19:29:02 --> Security Class Initialized
DEBUG - 2012-10-09 19:29:02 --> Input Class Initialized
DEBUG - 2012-10-09 19:29:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:29:02 --> Language Class Initialized
DEBUG - 2012-10-09 19:29:02 --> Loader Class Initialized
DEBUG - 2012-10-09 19:29:02 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:29:02 --> Controller Class Initialized
DEBUG - 2012-10-09 19:29:02 --> Model Class Initialized
DEBUG - 2012-10-09 19:29:02 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:29:02 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:29:02 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 19:29:02 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 19:29:02 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 19:29:02 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 19:29:02 --> Final output sent to browser
DEBUG - 2012-10-09 19:29:02 --> Total execution time: 0.0398
DEBUG - 2012-10-09 19:29:04 --> Config Class Initialized
DEBUG - 2012-10-09 19:29:04 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:29:04 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:29:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:29:04 --> URI Class Initialized
DEBUG - 2012-10-09 19:29:04 --> Router Class Initialized
ERROR - 2012-10-09 19:29:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:29:04 --> Config Class Initialized
DEBUG - 2012-10-09 19:29:04 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:29:04 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:29:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:29:04 --> URI Class Initialized
DEBUG - 2012-10-09 19:29:04 --> Router Class Initialized
ERROR - 2012-10-09 19:29:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:29:04 --> Config Class Initialized
DEBUG - 2012-10-09 19:29:04 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:29:04 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:29:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:29:04 --> URI Class Initialized
DEBUG - 2012-10-09 19:29:04 --> Router Class Initialized
ERROR - 2012-10-09 19:29:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:29:06 --> Config Class Initialized
DEBUG - 2012-10-09 19:29:06 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:29:06 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:29:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:29:06 --> URI Class Initialized
DEBUG - 2012-10-09 19:29:06 --> Router Class Initialized
DEBUG - 2012-10-09 19:29:06 --> Output Class Initialized
DEBUG - 2012-10-09 19:29:06 --> Security Class Initialized
DEBUG - 2012-10-09 19:29:06 --> Input Class Initialized
DEBUG - 2012-10-09 19:29:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:29:06 --> Language Class Initialized
DEBUG - 2012-10-09 19:29:06 --> Loader Class Initialized
DEBUG - 2012-10-09 19:29:06 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:29:06 --> Controller Class Initialized
DEBUG - 2012-10-09 19:29:06 --> Model Class Initialized
DEBUG - 2012-10-09 19:29:06 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:29:06 --> Helper loaded: language_helper
DEBUG - 2012-10-09 19:29:06 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 19:29:11 --> Config Class Initialized
DEBUG - 2012-10-09 19:29:11 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:29:11 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:29:11 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:29:11 --> URI Class Initialized
DEBUG - 2012-10-09 19:29:11 --> Router Class Initialized
DEBUG - 2012-10-09 19:29:11 --> Output Class Initialized
DEBUG - 2012-10-09 19:29:11 --> Security Class Initialized
DEBUG - 2012-10-09 19:29:11 --> Input Class Initialized
DEBUG - 2012-10-09 19:29:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:29:11 --> Language Class Initialized
DEBUG - 2012-10-09 19:29:11 --> Loader Class Initialized
DEBUG - 2012-10-09 19:29:11 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:29:11 --> Controller Class Initialized
DEBUG - 2012-10-09 19:29:11 --> Model Class Initialized
DEBUG - 2012-10-09 19:29:11 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:29:11 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:29:11 --> Helper loaded: language_helper
DEBUG - 2012-10-09 19:29:11 --> Form Validation Class Initialized
DEBUG - 2012-10-09 19:29:11 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 19:29:11 --> Upload Class Initialized
DEBUG - 2012-10-09 19:29:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 19:29:11 --> Image Lib Class Initialized
DEBUG - 2012-10-09 19:29:11 --> Final output sent to browser
DEBUG - 2012-10-09 19:29:11 --> Total execution time: 0.1709
DEBUG - 2012-10-09 19:29:36 --> Config Class Initialized
DEBUG - 2012-10-09 19:29:36 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:29:36 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:29:36 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:29:36 --> URI Class Initialized
DEBUG - 2012-10-09 19:29:36 --> Router Class Initialized
DEBUG - 2012-10-09 19:29:36 --> Output Class Initialized
DEBUG - 2012-10-09 19:29:36 --> Security Class Initialized
DEBUG - 2012-10-09 19:29:36 --> Input Class Initialized
DEBUG - 2012-10-09 19:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:29:36 --> Language Class Initialized
DEBUG - 2012-10-09 19:29:36 --> Loader Class Initialized
DEBUG - 2012-10-09 19:29:36 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:29:36 --> Controller Class Initialized
DEBUG - 2012-10-09 19:29:36 --> Model Class Initialized
DEBUG - 2012-10-09 19:29:36 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:29:36 --> Helper loaded: language_helper
DEBUG - 2012-10-09 19:29:36 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 19:29:41 --> Config Class Initialized
DEBUG - 2012-10-09 19:29:41 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:29:41 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:29:41 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:29:41 --> URI Class Initialized
DEBUG - 2012-10-09 19:29:41 --> Router Class Initialized
DEBUG - 2012-10-09 19:29:41 --> Output Class Initialized
DEBUG - 2012-10-09 19:29:41 --> Security Class Initialized
DEBUG - 2012-10-09 19:29:41 --> Input Class Initialized
DEBUG - 2012-10-09 19:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:29:41 --> Language Class Initialized
DEBUG - 2012-10-09 19:29:41 --> Loader Class Initialized
DEBUG - 2012-10-09 19:29:41 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:29:41 --> Controller Class Initialized
DEBUG - 2012-10-09 19:29:41 --> Model Class Initialized
DEBUG - 2012-10-09 19:29:41 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:29:41 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:29:41 --> Helper loaded: language_helper
DEBUG - 2012-10-09 19:29:41 --> Form Validation Class Initialized
DEBUG - 2012-10-09 19:29:41 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-09 19:29:41 --> Upload Class Initialized
DEBUG - 2012-10-09 19:29:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-09 19:29:41 --> Image Lib Class Initialized
DEBUG - 2012-10-09 19:29:41 --> Final output sent to browser
DEBUG - 2012-10-09 19:29:41 --> Total execution time: 0.1521
DEBUG - 2012-10-09 19:29:50 --> Config Class Initialized
DEBUG - 2012-10-09 19:29:50 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:29:50 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:29:50 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:29:50 --> URI Class Initialized
DEBUG - 2012-10-09 19:29:50 --> Router Class Initialized
DEBUG - 2012-10-09 19:29:50 --> Output Class Initialized
DEBUG - 2012-10-09 19:29:50 --> Security Class Initialized
DEBUG - 2012-10-09 19:29:50 --> Input Class Initialized
DEBUG - 2012-10-09 19:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:29:50 --> Language Class Initialized
DEBUG - 2012-10-09 19:29:50 --> Loader Class Initialized
DEBUG - 2012-10-09 19:29:50 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:29:50 --> Controller Class Initialized
DEBUG - 2012-10-09 19:29:50 --> Model Class Initialized
DEBUG - 2012-10-09 19:29:50 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:29:50 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:29:50 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 19:29:50 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 19:29:50 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-10-09 19:29:50 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 19:29:50 --> Final output sent to browser
DEBUG - 2012-10-09 19:29:50 --> Total execution time: 0.1969
DEBUG - 2012-10-09 19:29:53 --> Config Class Initialized
DEBUG - 2012-10-09 19:29:53 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:29:53 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:29:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:29:53 --> URI Class Initialized
DEBUG - 2012-10-09 19:29:53 --> Router Class Initialized
ERROR - 2012-10-09 19:29:53 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:29:53 --> Config Class Initialized
DEBUG - 2012-10-09 19:29:53 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:29:53 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:29:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:29:53 --> URI Class Initialized
DEBUG - 2012-10-09 19:29:53 --> Router Class Initialized
ERROR - 2012-10-09 19:29:53 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:29:53 --> Config Class Initialized
DEBUG - 2012-10-09 19:29:53 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:29:53 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:29:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:29:53 --> URI Class Initialized
DEBUG - 2012-10-09 19:29:53 --> Router Class Initialized
ERROR - 2012-10-09 19:29:53 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:29:58 --> Config Class Initialized
DEBUG - 2012-10-09 19:29:58 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:29:58 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:29:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:29:58 --> URI Class Initialized
DEBUG - 2012-10-09 19:29:58 --> Router Class Initialized
DEBUG - 2012-10-09 19:29:58 --> Output Class Initialized
DEBUG - 2012-10-09 19:29:58 --> Security Class Initialized
DEBUG - 2012-10-09 19:29:58 --> Input Class Initialized
DEBUG - 2012-10-09 19:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:29:58 --> Language Class Initialized
DEBUG - 2012-10-09 19:29:58 --> Loader Class Initialized
DEBUG - 2012-10-09 19:29:58 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:29:58 --> Controller Class Initialized
DEBUG - 2012-10-09 19:29:58 --> Model Class Initialized
DEBUG - 2012-10-09 19:29:58 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:29:58 --> Final output sent to browser
DEBUG - 2012-10-09 19:29:58 --> Total execution time: 0.1181
DEBUG - 2012-10-09 19:31:43 --> Config Class Initialized
DEBUG - 2012-10-09 19:31:43 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:31:43 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:31:43 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:31:43 --> URI Class Initialized
DEBUG - 2012-10-09 19:31:43 --> Router Class Initialized
DEBUG - 2012-10-09 19:31:43 --> Output Class Initialized
DEBUG - 2012-10-09 19:31:43 --> Security Class Initialized
DEBUG - 2012-10-09 19:31:43 --> Input Class Initialized
DEBUG - 2012-10-09 19:31:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:31:43 --> Language Class Initialized
DEBUG - 2012-10-09 19:31:43 --> Loader Class Initialized
DEBUG - 2012-10-09 19:31:43 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:31:43 --> Controller Class Initialized
DEBUG - 2012-10-09 19:31:43 --> Model Class Initialized
DEBUG - 2012-10-09 19:31:43 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:31:43 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:31:43 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 19:31:43 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 19:31:43 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 19:31:43 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 19:31:43 --> Final output sent to browser
DEBUG - 2012-10-09 19:31:43 --> Total execution time: 0.0395
DEBUG - 2012-10-09 19:31:46 --> Config Class Initialized
DEBUG - 2012-10-09 19:31:46 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:31:46 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:31:46 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:31:46 --> URI Class Initialized
DEBUG - 2012-10-09 19:31:46 --> Router Class Initialized
ERROR - 2012-10-09 19:31:46 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:31:46 --> Config Class Initialized
DEBUG - 2012-10-09 19:31:46 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:31:46 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:31:46 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:31:46 --> URI Class Initialized
DEBUG - 2012-10-09 19:31:46 --> Router Class Initialized
ERROR - 2012-10-09 19:31:46 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:31:46 --> Config Class Initialized
DEBUG - 2012-10-09 19:31:46 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:31:46 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:31:46 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:31:46 --> URI Class Initialized
DEBUG - 2012-10-09 19:31:46 --> Router Class Initialized
ERROR - 2012-10-09 19:31:46 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:32:26 --> Config Class Initialized
DEBUG - 2012-10-09 19:32:26 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:32:26 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:32:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:32:26 --> URI Class Initialized
DEBUG - 2012-10-09 19:32:26 --> Router Class Initialized
DEBUG - 2012-10-09 19:32:26 --> Output Class Initialized
DEBUG - 2012-10-09 19:32:26 --> Security Class Initialized
DEBUG - 2012-10-09 19:32:26 --> Input Class Initialized
DEBUG - 2012-10-09 19:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:32:26 --> Language Class Initialized
DEBUG - 2012-10-09 19:32:26 --> Loader Class Initialized
DEBUG - 2012-10-09 19:32:26 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:32:26 --> Controller Class Initialized
DEBUG - 2012-10-09 19:32:26 --> Model Class Initialized
DEBUG - 2012-10-09 19:32:26 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:32:26 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:32:26 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 19:32:26 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 19:32:26 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-10-09 19:32:26 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 19:32:26 --> Final output sent to browser
DEBUG - 2012-10-09 19:32:26 --> Total execution time: 0.1977
DEBUG - 2012-10-09 19:32:29 --> Config Class Initialized
DEBUG - 2012-10-09 19:32:29 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:32:29 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:32:29 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:32:29 --> URI Class Initialized
DEBUG - 2012-10-09 19:32:29 --> Router Class Initialized
ERROR - 2012-10-09 19:32:29 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:32:29 --> Config Class Initialized
DEBUG - 2012-10-09 19:32:29 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:32:29 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:32:29 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:32:29 --> URI Class Initialized
DEBUG - 2012-10-09 19:32:29 --> Router Class Initialized
ERROR - 2012-10-09 19:32:29 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:32:29 --> Config Class Initialized
DEBUG - 2012-10-09 19:32:29 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:32:29 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:32:29 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:32:29 --> URI Class Initialized
DEBUG - 2012-10-09 19:32:29 --> Router Class Initialized
ERROR - 2012-10-09 19:32:29 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:36:36 --> Config Class Initialized
DEBUG - 2012-10-09 19:36:36 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:36:36 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:36:36 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:36:36 --> URI Class Initialized
DEBUG - 2012-10-09 19:36:36 --> Router Class Initialized
DEBUG - 2012-10-09 19:36:36 --> Output Class Initialized
DEBUG - 2012-10-09 19:36:36 --> Security Class Initialized
DEBUG - 2012-10-09 19:36:36 --> Input Class Initialized
DEBUG - 2012-10-09 19:36:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:36:36 --> Language Class Initialized
DEBUG - 2012-10-09 19:36:36 --> Loader Class Initialized
DEBUG - 2012-10-09 19:36:36 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:36:36 --> Controller Class Initialized
DEBUG - 2012-10-09 19:36:36 --> Model Class Initialized
DEBUG - 2012-10-09 19:36:36 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:36:36 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:36:36 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 19:36:36 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 19:36:36 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 19:36:36 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 19:36:36 --> Final output sent to browser
DEBUG - 2012-10-09 19:36:36 --> Total execution time: 0.0415
DEBUG - 2012-10-09 19:36:43 --> Config Class Initialized
DEBUG - 2012-10-09 19:36:43 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:36:43 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:36:43 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:36:43 --> URI Class Initialized
DEBUG - 2012-10-09 19:36:43 --> Router Class Initialized
ERROR - 2012-10-09 19:36:43 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:36:43 --> Config Class Initialized
DEBUG - 2012-10-09 19:36:43 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:36:43 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:36:43 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:36:43 --> URI Class Initialized
DEBUG - 2012-10-09 19:36:43 --> Router Class Initialized
ERROR - 2012-10-09 19:36:43 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:36:43 --> Config Class Initialized
DEBUG - 2012-10-09 19:36:43 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:36:43 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:36:43 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:36:43 --> URI Class Initialized
DEBUG - 2012-10-09 19:36:43 --> Router Class Initialized
ERROR - 2012-10-09 19:36:43 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:36:51 --> Config Class Initialized
DEBUG - 2012-10-09 19:36:51 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:36:51 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:36:51 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:36:51 --> URI Class Initialized
DEBUG - 2012-10-09 19:36:51 --> Router Class Initialized
DEBUG - 2012-10-09 19:36:51 --> Output Class Initialized
DEBUG - 2012-10-09 19:36:51 --> Security Class Initialized
DEBUG - 2012-10-09 19:36:51 --> Input Class Initialized
DEBUG - 2012-10-09 19:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 19:36:51 --> Language Class Initialized
DEBUG - 2012-10-09 19:36:51 --> Loader Class Initialized
DEBUG - 2012-10-09 19:36:51 --> Helper loaded: url_helper
DEBUG - 2012-10-09 19:36:51 --> Controller Class Initialized
DEBUG - 2012-10-09 19:36:51 --> Model Class Initialized
DEBUG - 2012-10-09 19:36:51 --> Database Driver Class Initialized
DEBUG - 2012-10-09 19:36:51 --> Helper loaded: form_helper
DEBUG - 2012-10-09 19:36:51 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 19:36:51 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 19:36:51 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-10-09 19:36:51 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 19:36:51 --> Final output sent to browser
DEBUG - 2012-10-09 19:36:51 --> Total execution time: 0.0487
DEBUG - 2012-10-09 19:36:53 --> Config Class Initialized
DEBUG - 2012-10-09 19:36:53 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:36:53 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:36:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:36:53 --> URI Class Initialized
DEBUG - 2012-10-09 19:36:53 --> Router Class Initialized
ERROR - 2012-10-09 19:36:53 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:36:53 --> Config Class Initialized
DEBUG - 2012-10-09 19:36:53 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:36:53 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:36:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:36:53 --> URI Class Initialized
DEBUG - 2012-10-09 19:36:53 --> Router Class Initialized
ERROR - 2012-10-09 19:36:53 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 19:36:53 --> Config Class Initialized
DEBUG - 2012-10-09 19:36:53 --> Hooks Class Initialized
DEBUG - 2012-10-09 19:36:53 --> Utf8 Class Initialized
DEBUG - 2012-10-09 19:36:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 19:36:53 --> URI Class Initialized
DEBUG - 2012-10-09 19:36:53 --> Router Class Initialized
ERROR - 2012-10-09 19:36:53 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:00:02 --> Config Class Initialized
DEBUG - 2012-10-09 20:00:02 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:00:02 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:00:02 --> URI Class Initialized
DEBUG - 2012-10-09 20:00:02 --> Router Class Initialized
DEBUG - 2012-10-09 20:00:02 --> Output Class Initialized
DEBUG - 2012-10-09 20:00:02 --> Security Class Initialized
DEBUG - 2012-10-09 20:00:02 --> Input Class Initialized
DEBUG - 2012-10-09 20:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 20:00:02 --> Language Class Initialized
DEBUG - 2012-10-09 20:00:02 --> Loader Class Initialized
DEBUG - 2012-10-09 20:00:02 --> Helper loaded: url_helper
DEBUG - 2012-10-09 20:00:02 --> Controller Class Initialized
DEBUG - 2012-10-09 20:00:02 --> Model Class Initialized
DEBUG - 2012-10-09 20:00:02 --> Database Driver Class Initialized
DEBUG - 2012-10-09 20:00:02 --> Helper loaded: form_helper
DEBUG - 2012-10-09 20:00:02 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 20:00:02 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 20:00:02 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-10-09 20:00:02 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 20:00:02 --> Final output sent to browser
DEBUG - 2012-10-09 20:00:02 --> Total execution time: 0.0578
DEBUG - 2012-10-09 20:00:04 --> Config Class Initialized
DEBUG - 2012-10-09 20:00:04 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:00:04 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:00:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:00:04 --> URI Class Initialized
DEBUG - 2012-10-09 20:00:04 --> Router Class Initialized
ERROR - 2012-10-09 20:00:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:00:04 --> Config Class Initialized
DEBUG - 2012-10-09 20:00:04 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:00:04 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:00:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:00:04 --> URI Class Initialized
DEBUG - 2012-10-09 20:00:04 --> Router Class Initialized
ERROR - 2012-10-09 20:00:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:00:04 --> Config Class Initialized
DEBUG - 2012-10-09 20:00:04 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:00:04 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:00:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:00:04 --> URI Class Initialized
DEBUG - 2012-10-09 20:00:04 --> Router Class Initialized
ERROR - 2012-10-09 20:00:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:03:25 --> Config Class Initialized
DEBUG - 2012-10-09 20:03:25 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:03:25 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:03:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:03:25 --> URI Class Initialized
DEBUG - 2012-10-09 20:03:25 --> Router Class Initialized
DEBUG - 2012-10-09 20:03:25 --> Output Class Initialized
DEBUG - 2012-10-09 20:03:25 --> Security Class Initialized
DEBUG - 2012-10-09 20:03:25 --> Input Class Initialized
DEBUG - 2012-10-09 20:03:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 20:03:25 --> Language Class Initialized
DEBUG - 2012-10-09 20:03:25 --> Loader Class Initialized
DEBUG - 2012-10-09 20:03:25 --> Helper loaded: url_helper
DEBUG - 2012-10-09 20:03:25 --> Controller Class Initialized
DEBUG - 2012-10-09 20:03:25 --> Model Class Initialized
DEBUG - 2012-10-09 20:03:25 --> Database Driver Class Initialized
DEBUG - 2012-10-09 20:03:25 --> Helper loaded: form_helper
DEBUG - 2012-10-09 20:03:25 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 20:03:25 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 20:03:25 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 20:03:25 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 20:03:25 --> Final output sent to browser
DEBUG - 2012-10-09 20:03:25 --> Total execution time: 0.0399
DEBUG - 2012-10-09 20:03:27 --> Config Class Initialized
DEBUG - 2012-10-09 20:03:27 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:03:27 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:03:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:03:27 --> URI Class Initialized
DEBUG - 2012-10-09 20:03:27 --> Router Class Initialized
ERROR - 2012-10-09 20:03:27 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:03:27 --> Config Class Initialized
DEBUG - 2012-10-09 20:03:27 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:03:27 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:03:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:03:27 --> URI Class Initialized
DEBUG - 2012-10-09 20:03:27 --> Router Class Initialized
ERROR - 2012-10-09 20:03:27 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:03:27 --> Config Class Initialized
DEBUG - 2012-10-09 20:03:27 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:03:27 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:03:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:03:27 --> URI Class Initialized
DEBUG - 2012-10-09 20:03:27 --> Router Class Initialized
ERROR - 2012-10-09 20:03:27 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:06:38 --> Config Class Initialized
DEBUG - 2012-10-09 20:06:38 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:06:38 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:06:38 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:06:38 --> URI Class Initialized
DEBUG - 2012-10-09 20:06:38 --> Router Class Initialized
DEBUG - 2012-10-09 20:06:38 --> Output Class Initialized
DEBUG - 2012-10-09 20:06:38 --> Security Class Initialized
DEBUG - 2012-10-09 20:06:38 --> Input Class Initialized
DEBUG - 2012-10-09 20:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 20:06:38 --> Language Class Initialized
DEBUG - 2012-10-09 20:06:38 --> Loader Class Initialized
DEBUG - 2012-10-09 20:06:38 --> Helper loaded: url_helper
DEBUG - 2012-10-09 20:06:38 --> Controller Class Initialized
DEBUG - 2012-10-09 20:06:38 --> Model Class Initialized
DEBUG - 2012-10-09 20:06:38 --> Database Driver Class Initialized
DEBUG - 2012-10-09 20:06:38 --> Helper loaded: form_helper
DEBUG - 2012-10-09 20:06:38 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 20:06:38 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 20:06:38 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-10-09 20:06:38 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 20:06:38 --> Final output sent to browser
DEBUG - 2012-10-09 20:06:38 --> Total execution time: 0.0495
DEBUG - 2012-10-09 20:06:40 --> Config Class Initialized
DEBUG - 2012-10-09 20:06:40 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:06:40 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:06:40 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:06:40 --> URI Class Initialized
DEBUG - 2012-10-09 20:06:40 --> Router Class Initialized
ERROR - 2012-10-09 20:06:40 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:06:40 --> Config Class Initialized
DEBUG - 2012-10-09 20:06:40 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:06:40 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:06:40 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:06:40 --> URI Class Initialized
DEBUG - 2012-10-09 20:06:40 --> Router Class Initialized
ERROR - 2012-10-09 20:06:40 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:06:40 --> Config Class Initialized
DEBUG - 2012-10-09 20:06:40 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:06:40 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:06:40 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:06:40 --> URI Class Initialized
DEBUG - 2012-10-09 20:06:40 --> Router Class Initialized
ERROR - 2012-10-09 20:06:40 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:07:13 --> Config Class Initialized
DEBUG - 2012-10-09 20:07:13 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:07:13 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:07:13 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:07:13 --> URI Class Initialized
DEBUG - 2012-10-09 20:07:13 --> Router Class Initialized
DEBUG - 2012-10-09 20:07:13 --> Output Class Initialized
DEBUG - 2012-10-09 20:07:13 --> Security Class Initialized
DEBUG - 2012-10-09 20:07:13 --> Input Class Initialized
DEBUG - 2012-10-09 20:07:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 20:07:13 --> Language Class Initialized
DEBUG - 2012-10-09 20:07:13 --> Loader Class Initialized
DEBUG - 2012-10-09 20:07:13 --> Helper loaded: url_helper
DEBUG - 2012-10-09 20:07:13 --> Controller Class Initialized
DEBUG - 2012-10-09 20:07:13 --> Model Class Initialized
DEBUG - 2012-10-09 20:07:13 --> Database Driver Class Initialized
DEBUG - 2012-10-09 20:07:13 --> Helper loaded: form_helper
DEBUG - 2012-10-09 20:07:13 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 20:07:13 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 20:07:13 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 20:07:13 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 20:07:13 --> Final output sent to browser
DEBUG - 2012-10-09 20:07:13 --> Total execution time: 0.0401
DEBUG - 2012-10-09 20:07:15 --> Config Class Initialized
DEBUG - 2012-10-09 20:07:15 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:07:15 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:07:15 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:07:15 --> URI Class Initialized
DEBUG - 2012-10-09 20:07:15 --> Router Class Initialized
ERROR - 2012-10-09 20:07:15 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:07:15 --> Config Class Initialized
DEBUG - 2012-10-09 20:07:15 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:07:15 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:07:15 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:07:15 --> URI Class Initialized
DEBUG - 2012-10-09 20:07:15 --> Router Class Initialized
ERROR - 2012-10-09 20:07:15 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:07:15 --> Config Class Initialized
DEBUG - 2012-10-09 20:07:15 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:07:15 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:07:15 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:07:15 --> URI Class Initialized
DEBUG - 2012-10-09 20:07:15 --> Router Class Initialized
ERROR - 2012-10-09 20:07:15 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:11:19 --> Config Class Initialized
DEBUG - 2012-10-09 20:11:19 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:11:19 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:11:19 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:11:19 --> URI Class Initialized
DEBUG - 2012-10-09 20:11:19 --> Router Class Initialized
DEBUG - 2012-10-09 20:11:19 --> Output Class Initialized
DEBUG - 2012-10-09 20:11:19 --> Security Class Initialized
DEBUG - 2012-10-09 20:11:19 --> Input Class Initialized
DEBUG - 2012-10-09 20:11:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 20:11:19 --> Language Class Initialized
DEBUG - 2012-10-09 20:11:19 --> Loader Class Initialized
DEBUG - 2012-10-09 20:11:19 --> Helper loaded: url_helper
DEBUG - 2012-10-09 20:11:19 --> Controller Class Initialized
DEBUG - 2012-10-09 20:11:19 --> Model Class Initialized
DEBUG - 2012-10-09 20:11:19 --> Database Driver Class Initialized
DEBUG - 2012-10-09 20:11:19 --> Helper loaded: form_helper
DEBUG - 2012-10-09 20:11:19 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 20:11:19 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 20:11:19 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 20:11:19 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 20:11:19 --> Final output sent to browser
DEBUG - 2012-10-09 20:11:19 --> Total execution time: 0.0419
DEBUG - 2012-10-09 20:11:22 --> Config Class Initialized
DEBUG - 2012-10-09 20:11:22 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:11:22 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:11:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:11:22 --> URI Class Initialized
DEBUG - 2012-10-09 20:11:22 --> Router Class Initialized
ERROR - 2012-10-09 20:11:22 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:11:22 --> Config Class Initialized
DEBUG - 2012-10-09 20:11:22 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:11:22 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:11:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:11:22 --> URI Class Initialized
DEBUG - 2012-10-09 20:11:22 --> Router Class Initialized
ERROR - 2012-10-09 20:11:22 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:11:22 --> Config Class Initialized
DEBUG - 2012-10-09 20:11:22 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:11:22 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:11:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:11:22 --> URI Class Initialized
DEBUG - 2012-10-09 20:11:22 --> Router Class Initialized
ERROR - 2012-10-09 20:11:22 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:30:37 --> Config Class Initialized
DEBUG - 2012-10-09 20:30:37 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:30:37 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:30:37 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:30:37 --> URI Class Initialized
DEBUG - 2012-10-09 20:30:37 --> Router Class Initialized
DEBUG - 2012-10-09 20:30:37 --> Output Class Initialized
DEBUG - 2012-10-09 20:30:37 --> Security Class Initialized
DEBUG - 2012-10-09 20:30:37 --> Input Class Initialized
DEBUG - 2012-10-09 20:30:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 20:30:37 --> Language Class Initialized
DEBUG - 2012-10-09 20:30:37 --> Loader Class Initialized
DEBUG - 2012-10-09 20:30:37 --> Helper loaded: url_helper
DEBUG - 2012-10-09 20:30:37 --> Controller Class Initialized
DEBUG - 2012-10-09 20:30:37 --> Model Class Initialized
DEBUG - 2012-10-09 20:30:37 --> Database Driver Class Initialized
DEBUG - 2012-10-09 20:30:37 --> Helper loaded: form_helper
DEBUG - 2012-10-09 20:30:37 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 20:30:37 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 20:34:59 --> Config Class Initialized
DEBUG - 2012-10-09 20:34:59 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:34:59 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:34:59 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:34:59 --> URI Class Initialized
DEBUG - 2012-10-09 20:34:59 --> Router Class Initialized
DEBUG - 2012-10-09 20:34:59 --> Output Class Initialized
DEBUG - 2012-10-09 20:34:59 --> Security Class Initialized
DEBUG - 2012-10-09 20:34:59 --> Input Class Initialized
DEBUG - 2012-10-09 20:34:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 20:34:59 --> Language Class Initialized
DEBUG - 2012-10-09 20:34:59 --> Loader Class Initialized
DEBUG - 2012-10-09 20:34:59 --> Helper loaded: url_helper
DEBUG - 2012-10-09 20:34:59 --> Controller Class Initialized
DEBUG - 2012-10-09 20:34:59 --> Model Class Initialized
DEBUG - 2012-10-09 20:34:59 --> Database Driver Class Initialized
DEBUG - 2012-10-09 20:34:59 --> Helper loaded: form_helper
DEBUG - 2012-10-09 20:34:59 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 20:34:59 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 20:35:00 --> Config Class Initialized
DEBUG - 2012-10-09 20:35:00 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:35:00 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:35:00 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:35:00 --> URI Class Initialized
DEBUG - 2012-10-09 20:35:00 --> Router Class Initialized
DEBUG - 2012-10-09 20:35:00 --> Output Class Initialized
DEBUG - 2012-10-09 20:35:00 --> Security Class Initialized
DEBUG - 2012-10-09 20:35:00 --> Input Class Initialized
DEBUG - 2012-10-09 20:35:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 20:35:00 --> Language Class Initialized
DEBUG - 2012-10-09 20:35:00 --> Loader Class Initialized
DEBUG - 2012-10-09 20:35:00 --> Helper loaded: url_helper
DEBUG - 2012-10-09 20:35:00 --> Controller Class Initialized
DEBUG - 2012-10-09 20:35:00 --> Model Class Initialized
DEBUG - 2012-10-09 20:35:00 --> Database Driver Class Initialized
DEBUG - 2012-10-09 20:35:00 --> Helper loaded: form_helper
DEBUG - 2012-10-09 20:35:00 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 20:35:00 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 20:35:56 --> Config Class Initialized
DEBUG - 2012-10-09 20:35:56 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:35:56 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:35:56 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:35:56 --> URI Class Initialized
DEBUG - 2012-10-09 20:35:56 --> Router Class Initialized
DEBUG - 2012-10-09 20:35:56 --> Output Class Initialized
DEBUG - 2012-10-09 20:35:56 --> Security Class Initialized
DEBUG - 2012-10-09 20:35:56 --> Input Class Initialized
DEBUG - 2012-10-09 20:35:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 20:35:56 --> Language Class Initialized
DEBUG - 2012-10-09 20:35:56 --> Loader Class Initialized
DEBUG - 2012-10-09 20:35:56 --> Helper loaded: url_helper
DEBUG - 2012-10-09 20:35:56 --> Controller Class Initialized
DEBUG - 2012-10-09 20:35:56 --> Model Class Initialized
DEBUG - 2012-10-09 20:35:56 --> Database Driver Class Initialized
DEBUG - 2012-10-09 20:35:56 --> Helper loaded: form_helper
DEBUG - 2012-10-09 20:35:56 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 20:35:56 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 20:35:56 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-10-09 20:35:56 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 20:35:56 --> Final output sent to browser
DEBUG - 2012-10-09 20:35:56 --> Total execution time: 0.0417
DEBUG - 2012-10-09 20:35:58 --> Config Class Initialized
DEBUG - 2012-10-09 20:35:58 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:35:58 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:35:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:35:58 --> URI Class Initialized
DEBUG - 2012-10-09 20:35:58 --> Router Class Initialized
ERROR - 2012-10-09 20:35:58 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:35:58 --> Config Class Initialized
DEBUG - 2012-10-09 20:35:58 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:35:58 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:35:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:35:58 --> URI Class Initialized
DEBUG - 2012-10-09 20:35:58 --> Router Class Initialized
ERROR - 2012-10-09 20:35:58 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:35:58 --> Config Class Initialized
DEBUG - 2012-10-09 20:35:58 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:35:58 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:35:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:35:58 --> URI Class Initialized
DEBUG - 2012-10-09 20:35:58 --> Router Class Initialized
ERROR - 2012-10-09 20:35:58 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:36:44 --> Config Class Initialized
DEBUG - 2012-10-09 20:36:44 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:36:44 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:36:44 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:36:44 --> URI Class Initialized
DEBUG - 2012-10-09 20:36:44 --> Router Class Initialized
DEBUG - 2012-10-09 20:36:44 --> Output Class Initialized
DEBUG - 2012-10-09 20:36:44 --> Security Class Initialized
DEBUG - 2012-10-09 20:36:44 --> Input Class Initialized
DEBUG - 2012-10-09 20:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 20:36:44 --> Language Class Initialized
DEBUG - 2012-10-09 20:36:44 --> Loader Class Initialized
DEBUG - 2012-10-09 20:36:44 --> Helper loaded: url_helper
DEBUG - 2012-10-09 20:36:44 --> Controller Class Initialized
DEBUG - 2012-10-09 20:36:44 --> Model Class Initialized
DEBUG - 2012-10-09 20:36:44 --> Database Driver Class Initialized
DEBUG - 2012-10-09 20:36:44 --> Helper loaded: form_helper
DEBUG - 2012-10-09 20:36:44 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 20:36:44 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 20:36:44 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-09 20:36:44 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 20:36:44 --> Final output sent to browser
DEBUG - 2012-10-09 20:36:44 --> Total execution time: 0.0474
DEBUG - 2012-10-09 20:36:47 --> Config Class Initialized
DEBUG - 2012-10-09 20:36:47 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:36:47 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:36:47 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:36:47 --> URI Class Initialized
DEBUG - 2012-10-09 20:36:47 --> Router Class Initialized
ERROR - 2012-10-09 20:36:47 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:36:47 --> Config Class Initialized
DEBUG - 2012-10-09 20:36:47 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:36:47 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:36:47 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:36:47 --> URI Class Initialized
DEBUG - 2012-10-09 20:36:47 --> Router Class Initialized
ERROR - 2012-10-09 20:36:47 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:36:47 --> Config Class Initialized
DEBUG - 2012-10-09 20:36:47 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:36:47 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:36:47 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:36:47 --> URI Class Initialized
DEBUG - 2012-10-09 20:36:47 --> Router Class Initialized
ERROR - 2012-10-09 20:36:47 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:37:12 --> Config Class Initialized
DEBUG - 2012-10-09 20:37:12 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:37:12 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:37:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:37:12 --> URI Class Initialized
DEBUG - 2012-10-09 20:37:12 --> Router Class Initialized
DEBUG - 2012-10-09 20:37:12 --> Output Class Initialized
DEBUG - 2012-10-09 20:37:12 --> Security Class Initialized
DEBUG - 2012-10-09 20:37:12 --> Input Class Initialized
DEBUG - 2012-10-09 20:37:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 20:37:12 --> Language Class Initialized
DEBUG - 2012-10-09 20:37:12 --> Loader Class Initialized
DEBUG - 2012-10-09 20:37:12 --> Helper loaded: url_helper
DEBUG - 2012-10-09 20:37:12 --> Controller Class Initialized
DEBUG - 2012-10-09 20:37:12 --> Model Class Initialized
DEBUG - 2012-10-09 20:37:12 --> Database Driver Class Initialized
DEBUG - 2012-10-09 20:37:12 --> Helper loaded: form_helper
DEBUG - 2012-10-09 20:37:12 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 20:37:12 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 20:37:12 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-10-09 20:37:12 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 20:37:12 --> Final output sent to browser
DEBUG - 2012-10-09 20:37:12 --> Total execution time: 0.0416
DEBUG - 2012-10-09 20:37:15 --> Config Class Initialized
DEBUG - 2012-10-09 20:37:15 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:37:15 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:37:15 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:37:15 --> URI Class Initialized
DEBUG - 2012-10-09 20:37:15 --> Router Class Initialized
ERROR - 2012-10-09 20:37:15 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:37:15 --> Config Class Initialized
DEBUG - 2012-10-09 20:37:15 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:37:15 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:37:15 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:37:15 --> URI Class Initialized
DEBUG - 2012-10-09 20:37:15 --> Router Class Initialized
ERROR - 2012-10-09 20:37:15 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:37:15 --> Config Class Initialized
DEBUG - 2012-10-09 20:37:15 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:37:15 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:37:15 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:37:15 --> URI Class Initialized
DEBUG - 2012-10-09 20:37:15 --> Router Class Initialized
ERROR - 2012-10-09 20:37:15 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:38:49 --> Config Class Initialized
DEBUG - 2012-10-09 20:38:49 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:38:49 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:38:49 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:38:49 --> URI Class Initialized
DEBUG - 2012-10-09 20:38:49 --> Router Class Initialized
DEBUG - 2012-10-09 20:38:49 --> Output Class Initialized
DEBUG - 2012-10-09 20:38:49 --> Security Class Initialized
DEBUG - 2012-10-09 20:38:49 --> Input Class Initialized
DEBUG - 2012-10-09 20:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 20:38:49 --> Language Class Initialized
DEBUG - 2012-10-09 20:38:49 --> Loader Class Initialized
DEBUG - 2012-10-09 20:38:49 --> Helper loaded: url_helper
DEBUG - 2012-10-09 20:38:49 --> Controller Class Initialized
DEBUG - 2012-10-09 20:38:49 --> Model Class Initialized
DEBUG - 2012-10-09 20:38:49 --> Database Driver Class Initialized
DEBUG - 2012-10-09 20:38:49 --> Helper loaded: form_helper
DEBUG - 2012-10-09 20:38:49 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 20:38:49 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 20:38:49 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-10-09 20:38:49 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 20:38:49 --> Final output sent to browser
DEBUG - 2012-10-09 20:38:49 --> Total execution time: 0.0428
DEBUG - 2012-10-09 20:38:52 --> Config Class Initialized
DEBUG - 2012-10-09 20:38:52 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:38:52 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:38:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:38:52 --> URI Class Initialized
DEBUG - 2012-10-09 20:38:52 --> Router Class Initialized
ERROR - 2012-10-09 20:38:52 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:38:52 --> Config Class Initialized
DEBUG - 2012-10-09 20:38:52 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:38:52 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:38:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:38:52 --> URI Class Initialized
DEBUG - 2012-10-09 20:38:52 --> Router Class Initialized
ERROR - 2012-10-09 20:38:52 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:38:52 --> Config Class Initialized
DEBUG - 2012-10-09 20:38:52 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:38:52 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:38:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:38:52 --> URI Class Initialized
DEBUG - 2012-10-09 20:38:52 --> Router Class Initialized
ERROR - 2012-10-09 20:38:52 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:41:15 --> Config Class Initialized
DEBUG - 2012-10-09 20:41:15 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:41:15 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:41:15 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:41:15 --> URI Class Initialized
DEBUG - 2012-10-09 20:41:15 --> Router Class Initialized
DEBUG - 2012-10-09 20:41:15 --> Output Class Initialized
DEBUG - 2012-10-09 20:41:15 --> Security Class Initialized
DEBUG - 2012-10-09 20:41:15 --> Input Class Initialized
DEBUG - 2012-10-09 20:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 20:41:15 --> Language Class Initialized
DEBUG - 2012-10-09 20:41:15 --> Loader Class Initialized
DEBUG - 2012-10-09 20:41:15 --> Helper loaded: url_helper
DEBUG - 2012-10-09 20:41:15 --> Controller Class Initialized
DEBUG - 2012-10-09 20:41:15 --> Model Class Initialized
DEBUG - 2012-10-09 20:41:15 --> Database Driver Class Initialized
DEBUG - 2012-10-09 20:41:15 --> Helper loaded: form_helper
DEBUG - 2012-10-09 20:41:15 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 20:41:15 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 20:41:15 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-10-09 20:41:15 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 20:41:15 --> Final output sent to browser
DEBUG - 2012-10-09 20:41:15 --> Total execution time: 0.0461
DEBUG - 2012-10-09 20:41:17 --> Config Class Initialized
DEBUG - 2012-10-09 20:41:17 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:41:17 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:41:17 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:41:17 --> URI Class Initialized
DEBUG - 2012-10-09 20:41:17 --> Router Class Initialized
ERROR - 2012-10-09 20:41:17 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:41:17 --> Config Class Initialized
DEBUG - 2012-10-09 20:41:17 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:41:17 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:41:17 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:41:17 --> URI Class Initialized
DEBUG - 2012-10-09 20:41:17 --> Router Class Initialized
ERROR - 2012-10-09 20:41:17 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:41:18 --> Config Class Initialized
DEBUG - 2012-10-09 20:41:18 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:41:18 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:41:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:41:18 --> URI Class Initialized
DEBUG - 2012-10-09 20:41:18 --> Router Class Initialized
ERROR - 2012-10-09 20:41:18 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:43:01 --> Config Class Initialized
DEBUG - 2012-10-09 20:43:01 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:43:01 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:43:01 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:43:01 --> URI Class Initialized
DEBUG - 2012-10-09 20:43:01 --> Router Class Initialized
DEBUG - 2012-10-09 20:43:01 --> Output Class Initialized
DEBUG - 2012-10-09 20:43:01 --> Security Class Initialized
DEBUG - 2012-10-09 20:43:01 --> Input Class Initialized
DEBUG - 2012-10-09 20:43:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 20:43:01 --> Language Class Initialized
DEBUG - 2012-10-09 20:43:01 --> Loader Class Initialized
DEBUG - 2012-10-09 20:43:01 --> Helper loaded: url_helper
DEBUG - 2012-10-09 20:43:01 --> Controller Class Initialized
DEBUG - 2012-10-09 20:43:01 --> Model Class Initialized
DEBUG - 2012-10-09 20:43:01 --> Database Driver Class Initialized
DEBUG - 2012-10-09 20:43:01 --> Helper loaded: form_helper
DEBUG - 2012-10-09 20:43:01 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 20:43:01 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 20:43:01 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-10-09 20:43:01 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 20:43:01 --> Final output sent to browser
DEBUG - 2012-10-09 20:43:01 --> Total execution time: 0.0444
DEBUG - 2012-10-09 20:43:03 --> Config Class Initialized
DEBUG - 2012-10-09 20:43:03 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:43:03 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:43:03 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:43:03 --> URI Class Initialized
DEBUG - 2012-10-09 20:43:03 --> Router Class Initialized
ERROR - 2012-10-09 20:43:03 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:43:03 --> Config Class Initialized
DEBUG - 2012-10-09 20:43:03 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:43:03 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:43:03 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:43:03 --> URI Class Initialized
DEBUG - 2012-10-09 20:43:03 --> Router Class Initialized
ERROR - 2012-10-09 20:43:03 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:43:03 --> Config Class Initialized
DEBUG - 2012-10-09 20:43:03 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:43:03 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:43:03 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:43:03 --> URI Class Initialized
DEBUG - 2012-10-09 20:43:03 --> Router Class Initialized
ERROR - 2012-10-09 20:43:03 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:43:19 --> Config Class Initialized
DEBUG - 2012-10-09 20:43:19 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:43:19 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:43:19 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:43:19 --> URI Class Initialized
DEBUG - 2012-10-09 20:43:19 --> Router Class Initialized
DEBUG - 2012-10-09 20:43:19 --> Output Class Initialized
DEBUG - 2012-10-09 20:43:19 --> Security Class Initialized
DEBUG - 2012-10-09 20:43:19 --> Input Class Initialized
DEBUG - 2012-10-09 20:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 20:43:19 --> Language Class Initialized
DEBUG - 2012-10-09 20:43:19 --> Loader Class Initialized
DEBUG - 2012-10-09 20:43:19 --> Helper loaded: url_helper
DEBUG - 2012-10-09 20:43:19 --> Controller Class Initialized
DEBUG - 2012-10-09 20:43:19 --> Model Class Initialized
DEBUG - 2012-10-09 20:43:19 --> Database Driver Class Initialized
DEBUG - 2012-10-09 20:43:19 --> Helper loaded: form_helper
DEBUG - 2012-10-09 20:43:19 --> Form Validation Class Initialized
ERROR - 2012-10-09 20:43:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/libraries/Prices.php 25
DEBUG - 2012-10-09 20:43:19 --> Final output sent to browser
DEBUG - 2012-10-09 20:43:19 --> Total execution time: 0.0498
DEBUG - 2012-10-09 20:44:41 --> Config Class Initialized
DEBUG - 2012-10-09 20:44:41 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:44:41 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:44:41 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:44:41 --> URI Class Initialized
DEBUG - 2012-10-09 20:44:41 --> Router Class Initialized
DEBUG - 2012-10-09 20:44:41 --> Output Class Initialized
DEBUG - 2012-10-09 20:44:41 --> Security Class Initialized
DEBUG - 2012-10-09 20:44:41 --> Input Class Initialized
DEBUG - 2012-10-09 20:44:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 20:44:41 --> Language Class Initialized
DEBUG - 2012-10-09 20:44:41 --> Loader Class Initialized
DEBUG - 2012-10-09 20:44:41 --> Helper loaded: url_helper
DEBUG - 2012-10-09 20:44:41 --> Controller Class Initialized
DEBUG - 2012-10-09 20:44:41 --> Model Class Initialized
DEBUG - 2012-10-09 20:44:41 --> Database Driver Class Initialized
DEBUG - 2012-10-09 20:44:41 --> Helper loaded: form_helper
DEBUG - 2012-10-09 20:44:41 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 20:44:41 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 20:44:41 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-10-09 20:44:41 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 20:44:41 --> Final output sent to browser
DEBUG - 2012-10-09 20:44:41 --> Total execution time: 0.0561
DEBUG - 2012-10-09 20:44:43 --> Config Class Initialized
DEBUG - 2012-10-09 20:44:43 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:44:43 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:44:43 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:44:43 --> URI Class Initialized
DEBUG - 2012-10-09 20:44:43 --> Router Class Initialized
ERROR - 2012-10-09 20:44:43 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:44:43 --> Config Class Initialized
DEBUG - 2012-10-09 20:44:43 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:44:43 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:44:43 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:44:43 --> URI Class Initialized
DEBUG - 2012-10-09 20:44:43 --> Router Class Initialized
ERROR - 2012-10-09 20:44:43 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:44:43 --> Config Class Initialized
DEBUG - 2012-10-09 20:44:43 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:44:43 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:44:43 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:44:43 --> URI Class Initialized
DEBUG - 2012-10-09 20:44:43 --> Router Class Initialized
ERROR - 2012-10-09 20:44:43 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:45:10 --> Config Class Initialized
DEBUG - 2012-10-09 20:45:10 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:45:10 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:45:10 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:45:10 --> URI Class Initialized
DEBUG - 2012-10-09 20:45:10 --> Router Class Initialized
DEBUG - 2012-10-09 20:45:10 --> Output Class Initialized
DEBUG - 2012-10-09 20:45:10 --> Security Class Initialized
DEBUG - 2012-10-09 20:45:10 --> Input Class Initialized
DEBUG - 2012-10-09 20:45:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 20:45:10 --> Language Class Initialized
DEBUG - 2012-10-09 20:45:10 --> Loader Class Initialized
DEBUG - 2012-10-09 20:45:10 --> Helper loaded: url_helper
DEBUG - 2012-10-09 20:45:10 --> Controller Class Initialized
DEBUG - 2012-10-09 20:45:10 --> Model Class Initialized
DEBUG - 2012-10-09 20:45:10 --> Database Driver Class Initialized
DEBUG - 2012-10-09 20:45:10 --> Helper loaded: form_helper
DEBUG - 2012-10-09 20:45:10 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 20:45:10 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 20:45:10 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-10-09 20:45:10 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 20:45:10 --> Final output sent to browser
DEBUG - 2012-10-09 20:45:10 --> Total execution time: 0.0435
DEBUG - 2012-10-09 20:45:12 --> Config Class Initialized
DEBUG - 2012-10-09 20:45:12 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:45:12 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:45:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:45:12 --> URI Class Initialized
DEBUG - 2012-10-09 20:45:12 --> Router Class Initialized
ERROR - 2012-10-09 20:45:12 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:45:12 --> Config Class Initialized
DEBUG - 2012-10-09 20:45:12 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:45:12 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:45:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:45:12 --> URI Class Initialized
DEBUG - 2012-10-09 20:45:12 --> Router Class Initialized
ERROR - 2012-10-09 20:45:12 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 20:45:12 --> Config Class Initialized
DEBUG - 2012-10-09 20:45:12 --> Hooks Class Initialized
DEBUG - 2012-10-09 20:45:12 --> Utf8 Class Initialized
DEBUG - 2012-10-09 20:45:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 20:45:12 --> URI Class Initialized
DEBUG - 2012-10-09 20:45:12 --> Router Class Initialized
ERROR - 2012-10-09 20:45:12 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 21:42:20 --> Config Class Initialized
DEBUG - 2012-10-09 21:42:20 --> Hooks Class Initialized
DEBUG - 2012-10-09 21:42:20 --> Utf8 Class Initialized
DEBUG - 2012-10-09 21:42:20 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 21:42:20 --> URI Class Initialized
DEBUG - 2012-10-09 21:42:20 --> Router Class Initialized
DEBUG - 2012-10-09 21:42:20 --> Output Class Initialized
DEBUG - 2012-10-09 21:42:20 --> Security Class Initialized
DEBUG - 2012-10-09 21:42:20 --> Input Class Initialized
DEBUG - 2012-10-09 21:42:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 21:42:20 --> Language Class Initialized
DEBUG - 2012-10-09 21:42:20 --> Loader Class Initialized
DEBUG - 2012-10-09 21:42:20 --> Helper loaded: url_helper
DEBUG - 2012-10-09 21:42:20 --> Controller Class Initialized
DEBUG - 2012-10-09 21:42:20 --> Model Class Initialized
DEBUG - 2012-10-09 21:42:20 --> Database Driver Class Initialized
DEBUG - 2012-10-09 21:42:20 --> Helper loaded: form_helper
DEBUG - 2012-10-09 21:42:20 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 21:42:20 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-10-09 21:42:20 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 21:42:20 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-10-09 21:42:20 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 21:42:20 --> Final output sent to browser
DEBUG - 2012-10-09 21:42:20 --> Total execution time: 0.0751
DEBUG - 2012-10-09 21:42:22 --> Config Class Initialized
DEBUG - 2012-10-09 21:42:22 --> Hooks Class Initialized
DEBUG - 2012-10-09 21:42:22 --> Utf8 Class Initialized
DEBUG - 2012-10-09 21:42:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 21:42:22 --> URI Class Initialized
DEBUG - 2012-10-09 21:42:22 --> Router Class Initialized
ERROR - 2012-10-09 21:42:22 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 21:42:22 --> Config Class Initialized
DEBUG - 2012-10-09 21:42:22 --> Hooks Class Initialized
DEBUG - 2012-10-09 21:42:22 --> Utf8 Class Initialized
DEBUG - 2012-10-09 21:42:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 21:42:22 --> URI Class Initialized
DEBUG - 2012-10-09 21:42:22 --> Router Class Initialized
ERROR - 2012-10-09 21:42:22 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 21:42:22 --> Config Class Initialized
DEBUG - 2012-10-09 21:42:22 --> Hooks Class Initialized
DEBUG - 2012-10-09 21:42:22 --> Utf8 Class Initialized
DEBUG - 2012-10-09 21:42:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 21:42:22 --> URI Class Initialized
DEBUG - 2012-10-09 21:42:22 --> Router Class Initialized
ERROR - 2012-10-09 21:42:22 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 21:42:27 --> Config Class Initialized
DEBUG - 2012-10-09 21:42:27 --> Hooks Class Initialized
DEBUG - 2012-10-09 21:42:27 --> Utf8 Class Initialized
DEBUG - 2012-10-09 21:42:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 21:42:27 --> URI Class Initialized
DEBUG - 2012-10-09 21:42:27 --> Router Class Initialized
DEBUG - 2012-10-09 21:42:27 --> Output Class Initialized
DEBUG - 2012-10-09 21:42:27 --> Security Class Initialized
DEBUG - 2012-10-09 21:42:27 --> Input Class Initialized
DEBUG - 2012-10-09 21:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-09 21:42:27 --> Language Class Initialized
DEBUG - 2012-10-09 21:42:27 --> Loader Class Initialized
DEBUG - 2012-10-09 21:42:27 --> Helper loaded: url_helper
DEBUG - 2012-10-09 21:42:27 --> Controller Class Initialized
DEBUG - 2012-10-09 21:42:27 --> Model Class Initialized
DEBUG - 2012-10-09 21:42:27 --> Database Driver Class Initialized
DEBUG - 2012-10-09 21:42:27 --> Helper loaded: form_helper
DEBUG - 2012-10-09 21:42:27 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-09 21:42:27 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-09 21:42:27 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-10-09 21:42:27 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-09 21:42:27 --> Final output sent to browser
DEBUG - 2012-10-09 21:42:27 --> Total execution time: 0.0420
DEBUG - 2012-10-09 21:42:29 --> Config Class Initialized
DEBUG - 2012-10-09 21:42:29 --> Hooks Class Initialized
DEBUG - 2012-10-09 21:42:29 --> Utf8 Class Initialized
DEBUG - 2012-10-09 21:42:29 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 21:42:29 --> URI Class Initialized
DEBUG - 2012-10-09 21:42:29 --> Router Class Initialized
ERROR - 2012-10-09 21:42:29 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 21:42:29 --> Config Class Initialized
DEBUG - 2012-10-09 21:42:29 --> Hooks Class Initialized
DEBUG - 2012-10-09 21:42:29 --> Utf8 Class Initialized
DEBUG - 2012-10-09 21:42:29 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 21:42:29 --> URI Class Initialized
DEBUG - 2012-10-09 21:42:29 --> Router Class Initialized
ERROR - 2012-10-09 21:42:29 --> 404 Page Not Found --> css
DEBUG - 2012-10-09 21:42:29 --> Config Class Initialized
DEBUG - 2012-10-09 21:42:29 --> Hooks Class Initialized
DEBUG - 2012-10-09 21:42:29 --> Utf8 Class Initialized
DEBUG - 2012-10-09 21:42:29 --> UTF-8 Support Enabled
DEBUG - 2012-10-09 21:42:29 --> URI Class Initialized
DEBUG - 2012-10-09 21:42:29 --> Router Class Initialized
ERROR - 2012-10-09 21:42:29 --> 404 Page Not Found --> css
