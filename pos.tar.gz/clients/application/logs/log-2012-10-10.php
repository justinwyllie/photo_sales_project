<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-10-10 00:26:45 --> Config Class Initialized
DEBUG - 2012-10-10 00:26:45 --> Hooks Class Initialized
DEBUG - 2012-10-10 00:26:45 --> Utf8 Class Initialized
DEBUG - 2012-10-10 00:26:45 --> UTF-8 Support Enabled
DEBUG - 2012-10-10 00:26:45 --> URI Class Initialized
DEBUG - 2012-10-10 00:26:45 --> Router Class Initialized
DEBUG - 2012-10-10 00:26:45 --> Output Class Initialized
DEBUG - 2012-10-10 00:26:45 --> Security Class Initialized
DEBUG - 2012-10-10 00:26:45 --> Input Class Initialized
DEBUG - 2012-10-10 00:26:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-10 00:26:45 --> Language Class Initialized
DEBUG - 2012-10-10 00:26:45 --> Loader Class Initialized
DEBUG - 2012-10-10 00:26:45 --> Helper loaded: url_helper
DEBUG - 2012-10-10 00:26:45 --> Controller Class Initialized
DEBUG - 2012-10-10 00:26:45 --> Model Class Initialized
DEBUG - 2012-10-10 00:26:45 --> Database Driver Class Initialized
DEBUG - 2012-10-10 00:26:45 --> Helper loaded: form_helper
DEBUG - 2012-10-10 00:26:45 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-10 00:26:45 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-10-10 00:26:45 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-10 00:26:45 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-10-10 00:26:45 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-10 00:26:45 --> Final output sent to browser
DEBUG - 2012-10-10 00:26:45 --> Total execution time: 0.0568
DEBUG - 2012-10-10 00:26:45 --> Config Class Initialized
DEBUG - 2012-10-10 00:26:45 --> Hooks Class Initialized
DEBUG - 2012-10-10 00:26:45 --> Utf8 Class Initialized
DEBUG - 2012-10-10 00:26:45 --> UTF-8 Support Enabled
DEBUG - 2012-10-10 00:26:45 --> URI Class Initialized
DEBUG - 2012-10-10 00:26:45 --> Router Class Initialized
ERROR - 2012-10-10 00:26:45 --> 404 Page Not Found --> css
DEBUG - 2012-10-10 00:26:45 --> Config Class Initialized
DEBUG - 2012-10-10 00:26:45 --> Hooks Class Initialized
DEBUG - 2012-10-10 00:26:45 --> Utf8 Class Initialized
DEBUG - 2012-10-10 00:26:45 --> UTF-8 Support Enabled
DEBUG - 2012-10-10 00:26:45 --> URI Class Initialized
DEBUG - 2012-10-10 00:26:45 --> Router Class Initialized
ERROR - 2012-10-10 00:26:45 --> 404 Page Not Found --> css
DEBUG - 2012-10-10 00:26:45 --> Config Class Initialized
DEBUG - 2012-10-10 00:26:45 --> Hooks Class Initialized
DEBUG - 2012-10-10 00:26:45 --> Utf8 Class Initialized
DEBUG - 2012-10-10 00:26:45 --> UTF-8 Support Enabled
DEBUG - 2012-10-10 00:26:45 --> URI Class Initialized
DEBUG - 2012-10-10 00:26:45 --> Router Class Initialized
ERROR - 2012-10-10 00:26:45 --> 404 Page Not Found --> css
DEBUG - 2012-10-10 00:26:49 --> Config Class Initialized
DEBUG - 2012-10-10 00:26:49 --> Hooks Class Initialized
DEBUG - 2012-10-10 00:26:49 --> Utf8 Class Initialized
DEBUG - 2012-10-10 00:26:49 --> UTF-8 Support Enabled
DEBUG - 2012-10-10 00:26:49 --> URI Class Initialized
DEBUG - 2012-10-10 00:26:49 --> Router Class Initialized
DEBUG - 2012-10-10 00:26:49 --> Output Class Initialized
DEBUG - 2012-10-10 00:26:49 --> Security Class Initialized
DEBUG - 2012-10-10 00:26:49 --> Input Class Initialized
DEBUG - 2012-10-10 00:26:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-10 00:26:49 --> Language Class Initialized
DEBUG - 2012-10-10 00:26:49 --> Loader Class Initialized
DEBUG - 2012-10-10 00:26:49 --> Helper loaded: url_helper
DEBUG - 2012-10-10 00:26:49 --> Controller Class Initialized
DEBUG - 2012-10-10 00:26:49 --> Model Class Initialized
DEBUG - 2012-10-10 00:26:49 --> Database Driver Class Initialized
DEBUG - 2012-10-10 00:26:49 --> Helper loaded: form_helper
DEBUG - 2012-10-10 00:26:49 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-10 00:26:49 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-10 00:26:49 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-10-10 00:26:49 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-10 00:26:49 --> Final output sent to browser
DEBUG - 2012-10-10 00:26:49 --> Total execution time: 0.0456
DEBUG - 2012-10-10 00:36:05 --> Config Class Initialized
DEBUG - 2012-10-10 00:36:05 --> Hooks Class Initialized
DEBUG - 2012-10-10 00:36:05 --> Utf8 Class Initialized
DEBUG - 2012-10-10 00:36:05 --> UTF-8 Support Enabled
DEBUG - 2012-10-10 00:36:05 --> URI Class Initialized
DEBUG - 2012-10-10 00:36:05 --> Router Class Initialized
DEBUG - 2012-10-10 00:36:05 --> Output Class Initialized
DEBUG - 2012-10-10 00:36:05 --> Security Class Initialized
DEBUG - 2012-10-10 00:36:05 --> Input Class Initialized
DEBUG - 2012-10-10 00:36:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-10 00:36:05 --> Language Class Initialized
DEBUG - 2012-10-10 00:36:05 --> Loader Class Initialized
DEBUG - 2012-10-10 00:36:05 --> Helper loaded: url_helper
DEBUG - 2012-10-10 00:36:05 --> Controller Class Initialized
DEBUG - 2012-10-10 00:36:05 --> Model Class Initialized
DEBUG - 2012-10-10 00:36:05 --> Database Driver Class Initialized
DEBUG - 2012-10-10 00:36:05 --> Helper loaded: form_helper
DEBUG - 2012-10-10 00:36:05 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-10 00:36:05 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-10 00:36:05 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-10 00:36:05 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-10 00:36:05 --> Final output sent to browser
DEBUG - 2012-10-10 00:36:05 --> Total execution time: 0.0404
DEBUG - 2012-10-10 00:36:08 --> Config Class Initialized
DEBUG - 2012-10-10 00:36:08 --> Hooks Class Initialized
DEBUG - 2012-10-10 00:36:08 --> Utf8 Class Initialized
DEBUG - 2012-10-10 00:36:08 --> UTF-8 Support Enabled
DEBUG - 2012-10-10 00:36:08 --> URI Class Initialized
DEBUG - 2012-10-10 00:36:08 --> Router Class Initialized
DEBUG - 2012-10-10 00:36:08 --> Output Class Initialized
DEBUG - 2012-10-10 00:36:08 --> Security Class Initialized
DEBUG - 2012-10-10 00:36:08 --> Input Class Initialized
DEBUG - 2012-10-10 00:36:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-10 00:36:08 --> Language Class Initialized
DEBUG - 2012-10-10 00:36:08 --> Loader Class Initialized
DEBUG - 2012-10-10 00:36:08 --> Helper loaded: url_helper
DEBUG - 2012-10-10 00:36:08 --> Controller Class Initialized
DEBUG - 2012-10-10 00:36:08 --> Model Class Initialized
DEBUG - 2012-10-10 00:36:08 --> Database Driver Class Initialized
DEBUG - 2012-10-10 00:36:08 --> Final output sent to browser
DEBUG - 2012-10-10 00:36:08 --> Total execution time: 0.1364
DEBUG - 2012-10-10 00:36:11 --> Config Class Initialized
DEBUG - 2012-10-10 00:36:11 --> Hooks Class Initialized
DEBUG - 2012-10-10 00:36:11 --> Utf8 Class Initialized
DEBUG - 2012-10-10 00:36:11 --> UTF-8 Support Enabled
DEBUG - 2012-10-10 00:36:11 --> URI Class Initialized
DEBUG - 2012-10-10 00:36:11 --> Router Class Initialized
DEBUG - 2012-10-10 00:36:11 --> Output Class Initialized
DEBUG - 2012-10-10 00:36:11 --> Security Class Initialized
DEBUG - 2012-10-10 00:36:11 --> Input Class Initialized
DEBUG - 2012-10-10 00:36:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-10 00:36:11 --> Language Class Initialized
DEBUG - 2012-10-10 00:36:11 --> Loader Class Initialized
DEBUG - 2012-10-10 00:36:11 --> Helper loaded: url_helper
DEBUG - 2012-10-10 00:36:11 --> Controller Class Initialized
DEBUG - 2012-10-10 00:36:11 --> Model Class Initialized
DEBUG - 2012-10-10 00:36:11 --> Database Driver Class Initialized
DEBUG - 2012-10-10 00:36:11 --> Final output sent to browser
DEBUG - 2012-10-10 00:36:11 --> Total execution time: 0.1011
DEBUG - 2012-10-10 00:36:14 --> Config Class Initialized
DEBUG - 2012-10-10 00:36:14 --> Hooks Class Initialized
DEBUG - 2012-10-10 00:36:14 --> Utf8 Class Initialized
DEBUG - 2012-10-10 00:36:14 --> UTF-8 Support Enabled
DEBUG - 2012-10-10 00:36:14 --> URI Class Initialized
DEBUG - 2012-10-10 00:36:14 --> Router Class Initialized
DEBUG - 2012-10-10 00:36:14 --> Output Class Initialized
DEBUG - 2012-10-10 00:36:14 --> Security Class Initialized
DEBUG - 2012-10-10 00:36:14 --> Input Class Initialized
DEBUG - 2012-10-10 00:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-10 00:36:14 --> Language Class Initialized
DEBUG - 2012-10-10 00:36:14 --> Loader Class Initialized
DEBUG - 2012-10-10 00:36:14 --> Helper loaded: url_helper
DEBUG - 2012-10-10 00:36:14 --> Controller Class Initialized
DEBUG - 2012-10-10 00:36:14 --> Model Class Initialized
DEBUG - 2012-10-10 00:36:14 --> Database Driver Class Initialized
DEBUG - 2012-10-10 00:36:14 --> Helper loaded: form_helper
DEBUG - 2012-10-10 00:36:14 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-10 00:36:14 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-10 00:36:14 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-10-10 00:36:14 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-10 00:36:14 --> Final output sent to browser
DEBUG - 2012-10-10 00:36:14 --> Total execution time: 0.2909
DEBUG - 2012-10-10 00:37:59 --> Config Class Initialized
DEBUG - 2012-10-10 00:37:59 --> Hooks Class Initialized
DEBUG - 2012-10-10 00:37:59 --> Utf8 Class Initialized
DEBUG - 2012-10-10 00:37:59 --> UTF-8 Support Enabled
DEBUG - 2012-10-10 00:37:59 --> URI Class Initialized
DEBUG - 2012-10-10 00:37:59 --> Router Class Initialized
DEBUG - 2012-10-10 00:37:59 --> Output Class Initialized
DEBUG - 2012-10-10 00:37:59 --> Security Class Initialized
DEBUG - 2012-10-10 00:37:59 --> Input Class Initialized
DEBUG - 2012-10-10 00:37:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-10 00:37:59 --> Language Class Initialized
DEBUG - 2012-10-10 00:37:59 --> Loader Class Initialized
DEBUG - 2012-10-10 00:37:59 --> Helper loaded: url_helper
DEBUG - 2012-10-10 00:37:59 --> Controller Class Initialized
DEBUG - 2012-10-10 00:37:59 --> Model Class Initialized
DEBUG - 2012-10-10 00:37:59 --> Database Driver Class Initialized
DEBUG - 2012-10-10 00:37:59 --> Helper loaded: form_helper
DEBUG - 2012-10-10 00:37:59 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-10 00:37:59 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-10 00:37:59 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-10-10 00:37:59 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-10 00:37:59 --> Final output sent to browser
DEBUG - 2012-10-10 00:37:59 --> Total execution time: 0.0503
DEBUG - 2012-10-10 19:31:52 --> Config Class Initialized
DEBUG - 2012-10-10 19:31:52 --> Hooks Class Initialized
DEBUG - 2012-10-10 19:31:52 --> Utf8 Class Initialized
DEBUG - 2012-10-10 19:31:52 --> UTF-8 Support Enabled
DEBUG - 2012-10-10 19:31:52 --> URI Class Initialized
DEBUG - 2012-10-10 19:31:52 --> Router Class Initialized
DEBUG - 2012-10-10 19:31:52 --> Output Class Initialized
DEBUG - 2012-10-10 19:31:52 --> Security Class Initialized
DEBUG - 2012-10-10 19:31:52 --> Input Class Initialized
DEBUG - 2012-10-10 19:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-10 19:31:52 --> Language Class Initialized
DEBUG - 2012-10-10 19:31:52 --> Loader Class Initialized
DEBUG - 2012-10-10 19:31:52 --> Helper loaded: url_helper
DEBUG - 2012-10-10 19:31:52 --> Controller Class Initialized
DEBUG - 2012-10-10 19:31:52 --> Model Class Initialized
DEBUG - 2012-10-10 19:31:52 --> Database Driver Class Initialized
DEBUG - 2012-10-10 19:31:52 --> Helper loaded: form_helper
DEBUG - 2012-10-10 19:31:52 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-10 19:31:52 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-10-10 19:31:52 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-10 19:31:52 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-10-10 19:31:52 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-10 19:31:52 --> Final output sent to browser
DEBUG - 2012-10-10 19:31:52 --> Total execution time: 0.5282
DEBUG - 2012-10-10 19:31:53 --> Config Class Initialized
DEBUG - 2012-10-10 19:31:53 --> Hooks Class Initialized
DEBUG - 2012-10-10 19:31:53 --> Utf8 Class Initialized
DEBUG - 2012-10-10 19:31:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-10 19:31:53 --> URI Class Initialized
DEBUG - 2012-10-10 19:31:53 --> Router Class Initialized
ERROR - 2012-10-10 19:31:53 --> 404 Page Not Found --> css
DEBUG - 2012-10-10 19:31:53 --> Config Class Initialized
DEBUG - 2012-10-10 19:31:53 --> Hooks Class Initialized
DEBUG - 2012-10-10 19:31:53 --> Utf8 Class Initialized
DEBUG - 2012-10-10 19:31:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-10 19:31:53 --> URI Class Initialized
DEBUG - 2012-10-10 19:31:53 --> Router Class Initialized
ERROR - 2012-10-10 19:31:53 --> 404 Page Not Found --> css
DEBUG - 2012-10-10 19:31:53 --> Config Class Initialized
DEBUG - 2012-10-10 19:31:53 --> Hooks Class Initialized
DEBUG - 2012-10-10 19:31:53 --> Utf8 Class Initialized
DEBUG - 2012-10-10 19:31:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-10 19:31:53 --> URI Class Initialized
DEBUG - 2012-10-10 19:31:53 --> Router Class Initialized
ERROR - 2012-10-10 19:31:53 --> 404 Page Not Found --> css
DEBUG - 2012-10-10 19:31:56 --> Config Class Initialized
DEBUG - 2012-10-10 19:31:56 --> Hooks Class Initialized
DEBUG - 2012-10-10 19:31:56 --> Utf8 Class Initialized
DEBUG - 2012-10-10 19:31:56 --> UTF-8 Support Enabled
DEBUG - 2012-10-10 19:31:56 --> URI Class Initialized
DEBUG - 2012-10-10 19:31:56 --> Router Class Initialized
DEBUG - 2012-10-10 19:31:56 --> Output Class Initialized
DEBUG - 2012-10-10 19:31:56 --> Security Class Initialized
DEBUG - 2012-10-10 19:31:56 --> Input Class Initialized
DEBUG - 2012-10-10 19:31:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-10 19:31:56 --> Language Class Initialized
DEBUG - 2012-10-10 19:31:56 --> Loader Class Initialized
DEBUG - 2012-10-10 19:31:56 --> Helper loaded: url_helper
DEBUG - 2012-10-10 19:31:56 --> Controller Class Initialized
DEBUG - 2012-10-10 19:31:56 --> Model Class Initialized
DEBUG - 2012-10-10 19:31:56 --> Database Driver Class Initialized
ERROR - 2012-10-10 19:31:56 --> 404 Page Not Found --> pricing/units
DEBUG - 2012-10-10 20:34:24 --> Config Class Initialized
DEBUG - 2012-10-10 20:34:24 --> Hooks Class Initialized
DEBUG - 2012-10-10 20:34:24 --> Utf8 Class Initialized
DEBUG - 2012-10-10 20:34:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-10 20:34:24 --> URI Class Initialized
DEBUG - 2012-10-10 20:34:24 --> Router Class Initialized
DEBUG - 2012-10-10 20:34:24 --> Output Class Initialized
DEBUG - 2012-10-10 20:34:24 --> Security Class Initialized
DEBUG - 2012-10-10 20:34:24 --> Input Class Initialized
DEBUG - 2012-10-10 20:34:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-10 20:34:24 --> Language Class Initialized
DEBUG - 2012-10-10 20:34:24 --> Loader Class Initialized
DEBUG - 2012-10-10 20:34:24 --> Helper loaded: url_helper
DEBUG - 2012-10-10 20:34:24 --> Controller Class Initialized
DEBUG - 2012-10-10 20:34:24 --> Model Class Initialized
DEBUG - 2012-10-10 20:34:24 --> Database Driver Class Initialized
DEBUG - 2012-10-10 20:40:01 --> Config Class Initialized
DEBUG - 2012-10-10 20:40:01 --> Hooks Class Initialized
DEBUG - 2012-10-10 20:40:01 --> Utf8 Class Initialized
DEBUG - 2012-10-10 20:40:01 --> UTF-8 Support Enabled
DEBUG - 2012-10-10 20:40:01 --> URI Class Initialized
DEBUG - 2012-10-10 20:40:01 --> Router Class Initialized
DEBUG - 2012-10-10 20:40:01 --> Output Class Initialized
DEBUG - 2012-10-10 20:40:01 --> Security Class Initialized
DEBUG - 2012-10-10 20:40:01 --> Input Class Initialized
DEBUG - 2012-10-10 20:40:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-10 20:40:01 --> Language Class Initialized
DEBUG - 2012-10-10 20:40:01 --> Loader Class Initialized
DEBUG - 2012-10-10 20:40:01 --> Helper loaded: url_helper
DEBUG - 2012-10-10 20:40:01 --> Controller Class Initialized
DEBUG - 2012-10-10 20:40:01 --> Model Class Initialized
DEBUG - 2012-10-10 20:40:01 --> Database Driver Class Initialized
