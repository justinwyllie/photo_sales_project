<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-10-11 12:28:05 --> Config Class Initialized
DEBUG - 2012-10-11 12:28:05 --> Hooks Class Initialized
DEBUG - 2012-10-11 12:28:05 --> Utf8 Class Initialized
DEBUG - 2012-10-11 12:28:05 --> UTF-8 Support Enabled
DEBUG - 2012-10-11 12:28:05 --> URI Class Initialized
DEBUG - 2012-10-11 12:28:05 --> Router Class Initialized
DEBUG - 2012-10-11 12:28:05 --> Output Class Initialized
DEBUG - 2012-10-11 12:28:05 --> Security Class Initialized
DEBUG - 2012-10-11 12:28:05 --> Input Class Initialized
DEBUG - 2012-10-11 12:28:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-11 12:28:05 --> Language Class Initialized
DEBUG - 2012-10-11 12:28:05 --> Loader Class Initialized
DEBUG - 2012-10-11 12:28:05 --> Helper loaded: url_helper
DEBUG - 2012-10-11 12:28:05 --> Controller Class Initialized
DEBUG - 2012-10-11 12:28:05 --> Model Class Initialized
DEBUG - 2012-10-11 12:28:05 --> Database Driver Class Initialized
DEBUG - 2012-10-11 13:27:45 --> Config Class Initialized
DEBUG - 2012-10-11 13:27:45 --> Hooks Class Initialized
DEBUG - 2012-10-11 13:27:45 --> Utf8 Class Initialized
DEBUG - 2012-10-11 13:27:45 --> UTF-8 Support Enabled
DEBUG - 2012-10-11 13:27:45 --> URI Class Initialized
DEBUG - 2012-10-11 13:27:45 --> Router Class Initialized
DEBUG - 2012-10-11 13:27:45 --> Output Class Initialized
DEBUG - 2012-10-11 13:27:45 --> Security Class Initialized
DEBUG - 2012-10-11 13:27:45 --> Input Class Initialized
DEBUG - 2012-10-11 13:27:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-11 13:27:45 --> Language Class Initialized
DEBUG - 2012-10-11 13:27:45 --> Loader Class Initialized
DEBUG - 2012-10-11 13:27:45 --> Helper loaded: url_helper
DEBUG - 2012-10-11 13:27:45 --> Controller Class Initialized
DEBUG - 2012-10-11 13:27:45 --> Model Class Initialized
DEBUG - 2012-10-11 13:27:45 --> Database Driver Class Initialized
