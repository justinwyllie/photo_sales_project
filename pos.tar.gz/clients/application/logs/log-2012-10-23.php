<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-10-23 14:30:28 --> Config Class Initialized
DEBUG - 2012-10-23 14:30:28 --> Hooks Class Initialized
DEBUG - 2012-10-23 14:30:28 --> Utf8 Class Initialized
DEBUG - 2012-10-23 14:30:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 14:30:28 --> URI Class Initialized
DEBUG - 2012-10-23 14:30:28 --> Router Class Initialized
DEBUG - 2012-10-23 14:30:28 --> Output Class Initialized
DEBUG - 2012-10-23 14:30:28 --> Security Class Initialized
DEBUG - 2012-10-23 14:30:28 --> Input Class Initialized
DEBUG - 2012-10-23 14:30:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 14:30:28 --> Language Class Initialized
DEBUG - 2012-10-23 14:30:28 --> Loader Class Initialized
DEBUG - 2012-10-23 14:30:28 --> Helper loaded: url_helper
DEBUG - 2012-10-23 14:30:28 --> Controller Class Initialized
DEBUG - 2012-10-23 14:30:28 --> Model Class Initialized
DEBUG - 2012-10-23 14:30:28 --> Database Driver Class Initialized
DEBUG - 2012-10-23 14:36:06 --> Config Class Initialized
DEBUG - 2012-10-23 14:36:06 --> Hooks Class Initialized
DEBUG - 2012-10-23 14:36:06 --> Utf8 Class Initialized
DEBUG - 2012-10-23 14:36:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 14:36:06 --> URI Class Initialized
DEBUG - 2012-10-23 14:36:06 --> Router Class Initialized
DEBUG - 2012-10-23 14:36:06 --> Output Class Initialized
DEBUG - 2012-10-23 14:36:06 --> Security Class Initialized
DEBUG - 2012-10-23 14:36:06 --> Input Class Initialized
DEBUG - 2012-10-23 14:36:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 14:36:06 --> Language Class Initialized
DEBUG - 2012-10-23 14:36:06 --> Loader Class Initialized
DEBUG - 2012-10-23 14:36:06 --> Helper loaded: url_helper
DEBUG - 2012-10-23 14:36:06 --> Controller Class Initialized
DEBUG - 2012-10-23 14:36:06 --> Model Class Initialized
DEBUG - 2012-10-23 14:36:06 --> Database Driver Class Initialized
DEBUG - 2012-10-23 14:36:06 --> Helper loaded: form_helper
DEBUG - 2012-10-23 14:36:07 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 14:36:07 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-10-23 14:36:07 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 14:36:07 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-10-23 14:36:07 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 14:36:07 --> Final output sent to browser
DEBUG - 2012-10-23 14:36:07 --> Total execution time: 0.9576
DEBUG - 2012-10-23 14:36:09 --> Config Class Initialized
DEBUG - 2012-10-23 14:36:09 --> Hooks Class Initialized
DEBUG - 2012-10-23 14:36:09 --> Utf8 Class Initialized
DEBUG - 2012-10-23 14:36:09 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 14:36:09 --> URI Class Initialized
DEBUG - 2012-10-23 14:36:09 --> Router Class Initialized
ERROR - 2012-10-23 14:36:09 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 14:36:09 --> Config Class Initialized
DEBUG - 2012-10-23 14:36:09 --> Hooks Class Initialized
DEBUG - 2012-10-23 14:36:09 --> Utf8 Class Initialized
DEBUG - 2012-10-23 14:36:09 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 14:36:09 --> URI Class Initialized
DEBUG - 2012-10-23 14:36:09 --> Router Class Initialized
ERROR - 2012-10-23 14:36:09 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 14:36:09 --> Config Class Initialized
DEBUG - 2012-10-23 14:36:09 --> Hooks Class Initialized
DEBUG - 2012-10-23 14:36:09 --> Utf8 Class Initialized
DEBUG - 2012-10-23 14:36:09 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 14:36:09 --> URI Class Initialized
DEBUG - 2012-10-23 14:36:09 --> Router Class Initialized
ERROR - 2012-10-23 14:36:09 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 14:36:14 --> Config Class Initialized
DEBUG - 2012-10-23 14:36:14 --> Hooks Class Initialized
DEBUG - 2012-10-23 14:36:14 --> Utf8 Class Initialized
DEBUG - 2012-10-23 14:36:14 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 14:36:14 --> URI Class Initialized
DEBUG - 2012-10-23 14:36:14 --> Router Class Initialized
DEBUG - 2012-10-23 14:36:14 --> Output Class Initialized
DEBUG - 2012-10-23 14:36:14 --> Security Class Initialized
DEBUG - 2012-10-23 14:36:14 --> Input Class Initialized
DEBUG - 2012-10-23 14:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 14:36:14 --> Language Class Initialized
DEBUG - 2012-10-23 14:36:14 --> Loader Class Initialized
DEBUG - 2012-10-23 14:36:14 --> Helper loaded: url_helper
DEBUG - 2012-10-23 14:36:14 --> Controller Class Initialized
DEBUG - 2012-10-23 14:36:14 --> Model Class Initialized
DEBUG - 2012-10-23 14:36:14 --> Database Driver Class Initialized
DEBUG - 2012-10-23 14:46:58 --> Config Class Initialized
DEBUG - 2012-10-23 14:46:58 --> Hooks Class Initialized
DEBUG - 2012-10-23 14:46:58 --> Utf8 Class Initialized
DEBUG - 2012-10-23 14:46:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 14:46:58 --> URI Class Initialized
DEBUG - 2012-10-23 14:46:58 --> Router Class Initialized
DEBUG - 2012-10-23 14:46:58 --> Output Class Initialized
DEBUG - 2012-10-23 14:46:58 --> Security Class Initialized
DEBUG - 2012-10-23 14:46:58 --> Input Class Initialized
DEBUG - 2012-10-23 14:46:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 14:46:58 --> Language Class Initialized
DEBUG - 2012-10-23 14:46:58 --> Loader Class Initialized
DEBUG - 2012-10-23 14:46:58 --> Helper loaded: url_helper
DEBUG - 2012-10-23 14:46:58 --> Controller Class Initialized
DEBUG - 2012-10-23 14:46:58 --> Model Class Initialized
DEBUG - 2012-10-23 14:46:58 --> Database Driver Class Initialized
DEBUG - 2012-10-23 14:47:00 --> Config Class Initialized
DEBUG - 2012-10-23 14:47:00 --> Hooks Class Initialized
DEBUG - 2012-10-23 14:47:00 --> Utf8 Class Initialized
DEBUG - 2012-10-23 14:47:00 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 14:47:00 --> URI Class Initialized
DEBUG - 2012-10-23 14:47:00 --> Router Class Initialized
DEBUG - 2012-10-23 14:47:00 --> Output Class Initialized
DEBUG - 2012-10-23 14:47:00 --> Security Class Initialized
DEBUG - 2012-10-23 14:47:00 --> Input Class Initialized
DEBUG - 2012-10-23 14:47:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 14:47:00 --> Language Class Initialized
DEBUG - 2012-10-23 14:47:00 --> Loader Class Initialized
DEBUG - 2012-10-23 14:47:00 --> Helper loaded: url_helper
DEBUG - 2012-10-23 14:47:00 --> Controller Class Initialized
DEBUG - 2012-10-23 14:47:00 --> Model Class Initialized
DEBUG - 2012-10-23 14:47:00 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:07:53 --> Config Class Initialized
DEBUG - 2012-10-23 15:07:53 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:07:53 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:07:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:07:53 --> URI Class Initialized
DEBUG - 2012-10-23 15:07:53 --> Router Class Initialized
DEBUG - 2012-10-23 15:07:53 --> Output Class Initialized
DEBUG - 2012-10-23 15:07:53 --> Security Class Initialized
DEBUG - 2012-10-23 15:07:53 --> Input Class Initialized
DEBUG - 2012-10-23 15:07:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:07:53 --> Language Class Initialized
DEBUG - 2012-10-23 15:07:53 --> Loader Class Initialized
DEBUG - 2012-10-23 15:07:53 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:07:53 --> Controller Class Initialized
DEBUG - 2012-10-23 15:07:53 --> Model Class Initialized
DEBUG - 2012-10-23 15:07:53 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:07:55 --> Config Class Initialized
DEBUG - 2012-10-23 15:07:55 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:07:55 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:07:55 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:07:55 --> URI Class Initialized
DEBUG - 2012-10-23 15:07:55 --> Router Class Initialized
DEBUG - 2012-10-23 15:07:55 --> Output Class Initialized
DEBUG - 2012-10-23 15:07:55 --> Security Class Initialized
DEBUG - 2012-10-23 15:07:55 --> Input Class Initialized
DEBUG - 2012-10-23 15:07:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:07:55 --> Language Class Initialized
DEBUG - 2012-10-23 15:07:55 --> Loader Class Initialized
DEBUG - 2012-10-23 15:07:55 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:07:55 --> Controller Class Initialized
DEBUG - 2012-10-23 15:07:55 --> Model Class Initialized
DEBUG - 2012-10-23 15:07:55 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:10:10 --> Config Class Initialized
DEBUG - 2012-10-23 15:10:10 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:10:10 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:10:10 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:10:10 --> URI Class Initialized
DEBUG - 2012-10-23 15:10:10 --> Router Class Initialized
DEBUG - 2012-10-23 15:10:10 --> Output Class Initialized
DEBUG - 2012-10-23 15:10:10 --> Security Class Initialized
DEBUG - 2012-10-23 15:10:10 --> Input Class Initialized
DEBUG - 2012-10-23 15:10:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:10:10 --> Language Class Initialized
DEBUG - 2012-10-23 15:10:10 --> Loader Class Initialized
DEBUG - 2012-10-23 15:10:10 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:10:10 --> Controller Class Initialized
DEBUG - 2012-10-23 15:10:10 --> Model Class Initialized
DEBUG - 2012-10-23 15:10:10 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:10:11 --> Config Class Initialized
DEBUG - 2012-10-23 15:10:11 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:10:11 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:10:11 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:10:11 --> URI Class Initialized
DEBUG - 2012-10-23 15:10:11 --> Router Class Initialized
DEBUG - 2012-10-23 15:10:11 --> Output Class Initialized
DEBUG - 2012-10-23 15:10:11 --> Security Class Initialized
DEBUG - 2012-10-23 15:10:11 --> Input Class Initialized
DEBUG - 2012-10-23 15:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:10:11 --> Language Class Initialized
DEBUG - 2012-10-23 15:10:11 --> Loader Class Initialized
DEBUG - 2012-10-23 15:10:11 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:10:11 --> Controller Class Initialized
DEBUG - 2012-10-23 15:10:11 --> Model Class Initialized
DEBUG - 2012-10-23 15:10:11 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:10:11 --> Config Class Initialized
DEBUG - 2012-10-23 15:10:11 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:10:11 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:10:11 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:10:11 --> URI Class Initialized
DEBUG - 2012-10-23 15:10:11 --> Router Class Initialized
DEBUG - 2012-10-23 15:10:11 --> Output Class Initialized
DEBUG - 2012-10-23 15:10:12 --> Security Class Initialized
DEBUG - 2012-10-23 15:10:12 --> Input Class Initialized
DEBUG - 2012-10-23 15:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:10:12 --> Language Class Initialized
DEBUG - 2012-10-23 15:10:12 --> Loader Class Initialized
DEBUG - 2012-10-23 15:10:12 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:10:12 --> Controller Class Initialized
DEBUG - 2012-10-23 15:10:12 --> Model Class Initialized
DEBUG - 2012-10-23 15:10:12 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:10:12 --> Config Class Initialized
DEBUG - 2012-10-23 15:10:12 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:10:12 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:10:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:10:12 --> URI Class Initialized
DEBUG - 2012-10-23 15:10:12 --> Router Class Initialized
DEBUG - 2012-10-23 15:10:12 --> Output Class Initialized
DEBUG - 2012-10-23 15:10:12 --> Security Class Initialized
DEBUG - 2012-10-23 15:10:12 --> Input Class Initialized
DEBUG - 2012-10-23 15:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:10:12 --> Language Class Initialized
DEBUG - 2012-10-23 15:10:12 --> Loader Class Initialized
DEBUG - 2012-10-23 15:10:12 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:10:12 --> Controller Class Initialized
DEBUG - 2012-10-23 15:10:12 --> Model Class Initialized
DEBUG - 2012-10-23 15:10:12 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:10:22 --> Config Class Initialized
DEBUG - 2012-10-23 15:10:22 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:10:22 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:10:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:10:22 --> URI Class Initialized
DEBUG - 2012-10-23 15:10:22 --> Router Class Initialized
DEBUG - 2012-10-23 15:10:22 --> Output Class Initialized
DEBUG - 2012-10-23 15:10:22 --> Security Class Initialized
DEBUG - 2012-10-23 15:10:22 --> Input Class Initialized
DEBUG - 2012-10-23 15:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:10:22 --> Language Class Initialized
DEBUG - 2012-10-23 15:10:22 --> Loader Class Initialized
DEBUG - 2012-10-23 15:10:22 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:10:22 --> Controller Class Initialized
DEBUG - 2012-10-23 15:10:22 --> Model Class Initialized
DEBUG - 2012-10-23 15:10:22 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:13:53 --> Config Class Initialized
DEBUG - 2012-10-23 15:13:53 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:13:53 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:13:53 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:13:53 --> URI Class Initialized
DEBUG - 2012-10-23 15:13:53 --> Router Class Initialized
DEBUG - 2012-10-23 15:13:53 --> Output Class Initialized
DEBUG - 2012-10-23 15:13:53 --> Security Class Initialized
DEBUG - 2012-10-23 15:13:53 --> Input Class Initialized
DEBUG - 2012-10-23 15:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:13:53 --> Language Class Initialized
DEBUG - 2012-10-23 15:13:53 --> Loader Class Initialized
DEBUG - 2012-10-23 15:13:53 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:13:53 --> Controller Class Initialized
DEBUG - 2012-10-23 15:13:53 --> Model Class Initialized
DEBUG - 2012-10-23 15:13:53 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:15:35 --> Config Class Initialized
DEBUG - 2012-10-23 15:15:35 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:15:35 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:15:35 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:15:35 --> URI Class Initialized
DEBUG - 2012-10-23 15:15:35 --> Router Class Initialized
DEBUG - 2012-10-23 15:15:35 --> Output Class Initialized
DEBUG - 2012-10-23 15:15:35 --> Security Class Initialized
DEBUG - 2012-10-23 15:15:35 --> Input Class Initialized
DEBUG - 2012-10-23 15:15:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:15:35 --> Language Class Initialized
DEBUG - 2012-10-23 15:15:35 --> Loader Class Initialized
DEBUG - 2012-10-23 15:15:35 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:15:35 --> Controller Class Initialized
DEBUG - 2012-10-23 15:15:35 --> Model Class Initialized
DEBUG - 2012-10-23 15:15:35 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:16:35 --> Config Class Initialized
DEBUG - 2012-10-23 15:16:35 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:16:35 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:16:35 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:16:35 --> URI Class Initialized
DEBUG - 2012-10-23 15:16:35 --> Router Class Initialized
DEBUG - 2012-10-23 15:16:35 --> Output Class Initialized
DEBUG - 2012-10-23 15:16:35 --> Security Class Initialized
DEBUG - 2012-10-23 15:16:35 --> Input Class Initialized
DEBUG - 2012-10-23 15:16:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:16:35 --> Language Class Initialized
DEBUG - 2012-10-23 15:16:35 --> Loader Class Initialized
DEBUG - 2012-10-23 15:16:35 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:16:35 --> Controller Class Initialized
DEBUG - 2012-10-23 15:16:35 --> Model Class Initialized
DEBUG - 2012-10-23 15:16:35 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:16:35 --> DB Transaction Failure
ERROR - 2012-10-23 15:16:35 --> Query error: Unknown column 'unitsid' in 'field list'
DEBUG - 2012-10-23 15:16:35 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-10-23 15:19:21 --> Config Class Initialized
DEBUG - 2012-10-23 15:19:21 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:19:21 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:19:21 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:19:21 --> URI Class Initialized
DEBUG - 2012-10-23 15:19:21 --> Router Class Initialized
DEBUG - 2012-10-23 15:19:21 --> Output Class Initialized
DEBUG - 2012-10-23 15:19:21 --> Security Class Initialized
DEBUG - 2012-10-23 15:19:21 --> Input Class Initialized
DEBUG - 2012-10-23 15:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:19:21 --> Language Class Initialized
DEBUG - 2012-10-23 15:19:21 --> Loader Class Initialized
DEBUG - 2012-10-23 15:19:21 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:19:21 --> Controller Class Initialized
DEBUG - 2012-10-23 15:19:21 --> Model Class Initialized
DEBUG - 2012-10-23 15:19:21 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:19:45 --> Config Class Initialized
DEBUG - 2012-10-23 15:19:45 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:19:45 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:19:45 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:19:45 --> URI Class Initialized
DEBUG - 2012-10-23 15:19:45 --> Router Class Initialized
DEBUG - 2012-10-23 15:19:45 --> Output Class Initialized
DEBUG - 2012-10-23 15:19:45 --> Security Class Initialized
DEBUG - 2012-10-23 15:19:45 --> Input Class Initialized
DEBUG - 2012-10-23 15:19:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:19:45 --> Language Class Initialized
DEBUG - 2012-10-23 15:19:45 --> Loader Class Initialized
DEBUG - 2012-10-23 15:19:45 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:19:45 --> Controller Class Initialized
DEBUG - 2012-10-23 15:19:45 --> Model Class Initialized
DEBUG - 2012-10-23 15:19:45 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:19:47 --> Config Class Initialized
DEBUG - 2012-10-23 15:19:47 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:19:47 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:19:47 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:19:47 --> URI Class Initialized
DEBUG - 2012-10-23 15:19:47 --> Router Class Initialized
DEBUG - 2012-10-23 15:19:47 --> Output Class Initialized
DEBUG - 2012-10-23 15:19:47 --> Security Class Initialized
DEBUG - 2012-10-23 15:19:47 --> Input Class Initialized
DEBUG - 2012-10-23 15:19:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:19:47 --> Language Class Initialized
DEBUG - 2012-10-23 15:19:47 --> Loader Class Initialized
DEBUG - 2012-10-23 15:19:47 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:19:47 --> Controller Class Initialized
DEBUG - 2012-10-23 15:19:47 --> Model Class Initialized
DEBUG - 2012-10-23 15:19:47 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:26:10 --> Config Class Initialized
DEBUG - 2012-10-23 15:26:10 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:26:10 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:26:10 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:26:10 --> URI Class Initialized
DEBUG - 2012-10-23 15:26:10 --> Router Class Initialized
DEBUG - 2012-10-23 15:26:10 --> Output Class Initialized
DEBUG - 2012-10-23 15:26:10 --> Security Class Initialized
DEBUG - 2012-10-23 15:26:10 --> Input Class Initialized
DEBUG - 2012-10-23 15:26:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:26:10 --> Language Class Initialized
DEBUG - 2012-10-23 15:26:10 --> Loader Class Initialized
DEBUG - 2012-10-23 15:26:10 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:26:10 --> Controller Class Initialized
DEBUG - 2012-10-23 15:26:10 --> Model Class Initialized
DEBUG - 2012-10-23 15:26:10 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:26:48 --> Config Class Initialized
DEBUG - 2012-10-23 15:26:48 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:26:48 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:26:48 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:26:48 --> URI Class Initialized
DEBUG - 2012-10-23 15:26:48 --> Router Class Initialized
DEBUG - 2012-10-23 15:26:48 --> Output Class Initialized
DEBUG - 2012-10-23 15:26:48 --> Security Class Initialized
DEBUG - 2012-10-23 15:26:48 --> Input Class Initialized
DEBUG - 2012-10-23 15:26:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:26:48 --> Language Class Initialized
DEBUG - 2012-10-23 15:26:48 --> Loader Class Initialized
DEBUG - 2012-10-23 15:26:48 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:26:48 --> Controller Class Initialized
DEBUG - 2012-10-23 15:26:48 --> Model Class Initialized
DEBUG - 2012-10-23 15:26:48 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:29:40 --> Config Class Initialized
DEBUG - 2012-10-23 15:29:40 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:29:40 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:29:40 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:29:40 --> URI Class Initialized
DEBUG - 2012-10-23 15:29:40 --> Router Class Initialized
DEBUG - 2012-10-23 15:29:40 --> Output Class Initialized
DEBUG - 2012-10-23 15:29:40 --> Security Class Initialized
DEBUG - 2012-10-23 15:29:40 --> Input Class Initialized
DEBUG - 2012-10-23 15:29:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:29:40 --> Language Class Initialized
DEBUG - 2012-10-23 15:29:40 --> Loader Class Initialized
DEBUG - 2012-10-23 15:29:40 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:29:40 --> Controller Class Initialized
DEBUG - 2012-10-23 15:29:40 --> Model Class Initialized
DEBUG - 2012-10-23 15:29:40 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:29:40 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 15:29:40 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 15:30:30 --> Config Class Initialized
DEBUG - 2012-10-23 15:30:30 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:30:30 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:30:30 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:30:30 --> URI Class Initialized
DEBUG - 2012-10-23 15:30:30 --> Router Class Initialized
DEBUG - 2012-10-23 15:30:30 --> Output Class Initialized
DEBUG - 2012-10-23 15:30:30 --> Security Class Initialized
DEBUG - 2012-10-23 15:30:30 --> Input Class Initialized
DEBUG - 2012-10-23 15:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:30:30 --> Language Class Initialized
DEBUG - 2012-10-23 15:30:30 --> Loader Class Initialized
DEBUG - 2012-10-23 15:30:30 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:30:30 --> Controller Class Initialized
DEBUG - 2012-10-23 15:30:30 --> Model Class Initialized
DEBUG - 2012-10-23 15:30:30 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:30:30 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 15:30:30 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 15:31:17 --> Config Class Initialized
DEBUG - 2012-10-23 15:31:17 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:31:17 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:31:17 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:31:17 --> URI Class Initialized
DEBUG - 2012-10-23 15:31:17 --> Router Class Initialized
DEBUG - 2012-10-23 15:31:17 --> Output Class Initialized
DEBUG - 2012-10-23 15:31:17 --> Security Class Initialized
DEBUG - 2012-10-23 15:31:17 --> Input Class Initialized
DEBUG - 2012-10-23 15:31:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:31:17 --> Language Class Initialized
DEBUG - 2012-10-23 15:31:17 --> Loader Class Initialized
DEBUG - 2012-10-23 15:31:17 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:31:17 --> Controller Class Initialized
DEBUG - 2012-10-23 15:31:17 --> Model Class Initialized
DEBUG - 2012-10-23 15:31:17 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:31:17 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 15:31:17 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 15:32:34 --> Config Class Initialized
DEBUG - 2012-10-23 15:32:34 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:32:34 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:32:34 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:32:34 --> URI Class Initialized
DEBUG - 2012-10-23 15:32:34 --> Router Class Initialized
DEBUG - 2012-10-23 15:32:34 --> Output Class Initialized
DEBUG - 2012-10-23 15:32:34 --> Security Class Initialized
DEBUG - 2012-10-23 15:32:34 --> Input Class Initialized
DEBUG - 2012-10-23 15:32:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:32:34 --> Language Class Initialized
DEBUG - 2012-10-23 15:32:34 --> Loader Class Initialized
DEBUG - 2012-10-23 15:32:34 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:32:34 --> Controller Class Initialized
DEBUG - 2012-10-23 15:32:34 --> Model Class Initialized
DEBUG - 2012-10-23 15:32:34 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:32:34 --> Helper loaded: form_helper
DEBUG - 2012-10-23 15:32:34 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 15:32:34 --> File loaded: application/views/admin/templates/left_menu.php
ERROR - 2012-10-23 15:32:34 --> Severity: 4096  --> Object of class stdClass could not be converted to string /home/jwp/www/justinwylliephotography.com/clients/system/helpers/form_helper.php 352
ERROR - 2012-10-23 15:32:34 --> Severity: 4096  --> Object of class stdClass could not be converted to string /home/jwp/www/justinwylliephotography.com/clients/system/helpers/form_helper.php 352
ERROR - 2012-10-23 15:32:34 --> Severity: 4096  --> Object of class stdClass could not be converted to string /home/jwp/www/justinwylliephotography.com/clients/system/helpers/form_helper.php 352
DEBUG - 2012-10-23 15:32:34 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 15:32:34 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 15:32:34 --> Final output sent to browser
DEBUG - 2012-10-23 15:32:34 --> Total execution time: 0.0585
DEBUG - 2012-10-23 15:32:35 --> Config Class Initialized
DEBUG - 2012-10-23 15:32:35 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:32:35 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:32:35 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:32:35 --> URI Class Initialized
DEBUG - 2012-10-23 15:32:35 --> Router Class Initialized
ERROR - 2012-10-23 15:32:35 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 15:32:35 --> Config Class Initialized
DEBUG - 2012-10-23 15:32:35 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:32:35 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:32:35 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:32:35 --> URI Class Initialized
DEBUG - 2012-10-23 15:32:35 --> Router Class Initialized
ERROR - 2012-10-23 15:32:35 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 15:32:35 --> Config Class Initialized
DEBUG - 2012-10-23 15:32:35 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:32:35 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:32:35 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:32:35 --> URI Class Initialized
DEBUG - 2012-10-23 15:32:35 --> Router Class Initialized
ERROR - 2012-10-23 15:32:35 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 15:35:40 --> Config Class Initialized
DEBUG - 2012-10-23 15:35:40 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:35:40 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:35:40 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:35:40 --> URI Class Initialized
DEBUG - 2012-10-23 15:35:40 --> Router Class Initialized
DEBUG - 2012-10-23 15:35:40 --> Output Class Initialized
DEBUG - 2012-10-23 15:35:40 --> Security Class Initialized
DEBUG - 2012-10-23 15:35:40 --> Input Class Initialized
DEBUG - 2012-10-23 15:35:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:35:40 --> Language Class Initialized
DEBUG - 2012-10-23 15:35:40 --> Loader Class Initialized
DEBUG - 2012-10-23 15:35:40 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:35:40 --> Controller Class Initialized
DEBUG - 2012-10-23 15:35:40 --> Model Class Initialized
DEBUG - 2012-10-23 15:35:40 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:35:40 --> Helper loaded: form_helper
DEBUG - 2012-10-23 15:39:19 --> Config Class Initialized
DEBUG - 2012-10-23 15:39:19 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:39:19 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:39:19 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:39:19 --> URI Class Initialized
DEBUG - 2012-10-23 15:39:19 --> Router Class Initialized
DEBUG - 2012-10-23 15:39:19 --> Output Class Initialized
DEBUG - 2012-10-23 15:39:19 --> Security Class Initialized
DEBUG - 2012-10-23 15:39:19 --> Input Class Initialized
DEBUG - 2012-10-23 15:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:39:19 --> Language Class Initialized
DEBUG - 2012-10-23 15:39:19 --> Loader Class Initialized
DEBUG - 2012-10-23 15:39:19 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:39:19 --> Controller Class Initialized
DEBUG - 2012-10-23 15:39:19 --> Model Class Initialized
DEBUG - 2012-10-23 15:39:19 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:39:19 --> Helper loaded: form_helper
DEBUG - 2012-10-23 15:39:34 --> Config Class Initialized
DEBUG - 2012-10-23 15:39:34 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:39:34 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:39:34 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:39:34 --> URI Class Initialized
DEBUG - 2012-10-23 15:39:34 --> Router Class Initialized
DEBUG - 2012-10-23 15:39:34 --> Output Class Initialized
DEBUG - 2012-10-23 15:39:34 --> Security Class Initialized
DEBUG - 2012-10-23 15:39:34 --> Input Class Initialized
DEBUG - 2012-10-23 15:39:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:39:34 --> Language Class Initialized
DEBUG - 2012-10-23 15:39:34 --> Loader Class Initialized
DEBUG - 2012-10-23 15:39:34 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:39:34 --> Controller Class Initialized
DEBUG - 2012-10-23 15:39:34 --> Model Class Initialized
DEBUG - 2012-10-23 15:39:34 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:39:34 --> Helper loaded: form_helper
DEBUG - 2012-10-23 15:39:34 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 15:39:34 --> File loaded: application/views/admin/templates/left_menu.php
ERROR - 2012-10-23 15:39:34 --> Severity: 4096  --> Object of class stdClass could not be converted to string /home/jwp/www/justinwylliephotography.com/clients/system/helpers/form_helper.php 352
DEBUG - 2012-10-23 15:39:34 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 15:39:34 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 15:39:34 --> Final output sent to browser
DEBUG - 2012-10-23 15:39:34 --> Total execution time: 0.0424
DEBUG - 2012-10-23 15:40:02 --> Config Class Initialized
DEBUG - 2012-10-23 15:40:02 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:40:02 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:40:02 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:40:02 --> URI Class Initialized
DEBUG - 2012-10-23 15:40:02 --> Router Class Initialized
DEBUG - 2012-10-23 15:40:02 --> Output Class Initialized
DEBUG - 2012-10-23 15:40:02 --> Security Class Initialized
DEBUG - 2012-10-23 15:40:02 --> Input Class Initialized
DEBUG - 2012-10-23 15:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:40:02 --> Language Class Initialized
DEBUG - 2012-10-23 15:40:02 --> Loader Class Initialized
DEBUG - 2012-10-23 15:40:02 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:40:02 --> Controller Class Initialized
DEBUG - 2012-10-23 15:40:02 --> Model Class Initialized
DEBUG - 2012-10-23 15:40:02 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:40:02 --> Helper loaded: form_helper
DEBUG - 2012-10-23 15:40:02 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 15:40:02 --> File loaded: application/views/admin/templates/left_menu.php
ERROR - 2012-10-23 15:40:02 --> Severity: 4096  --> Object of class stdClass could not be converted to string /home/jwp/www/justinwylliephotography.com/clients/system/helpers/form_helper.php 352
DEBUG - 2012-10-23 15:40:02 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 15:40:02 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 15:40:02 --> Final output sent to browser
DEBUG - 2012-10-23 15:40:02 --> Total execution time: 0.0523
DEBUG - 2012-10-23 15:40:25 --> Config Class Initialized
DEBUG - 2012-10-23 15:40:25 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:40:25 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:40:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:40:25 --> URI Class Initialized
DEBUG - 2012-10-23 15:40:25 --> Router Class Initialized
DEBUG - 2012-10-23 15:40:25 --> Output Class Initialized
DEBUG - 2012-10-23 15:40:25 --> Security Class Initialized
DEBUG - 2012-10-23 15:40:25 --> Input Class Initialized
DEBUG - 2012-10-23 15:40:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:40:25 --> Language Class Initialized
DEBUG - 2012-10-23 15:40:25 --> Loader Class Initialized
DEBUG - 2012-10-23 15:40:25 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:40:25 --> Controller Class Initialized
DEBUG - 2012-10-23 15:40:25 --> Model Class Initialized
DEBUG - 2012-10-23 15:40:25 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:40:25 --> Helper loaded: form_helper
DEBUG - 2012-10-23 15:40:25 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 15:40:25 --> File loaded: application/views/admin/templates/left_menu.php
ERROR - 2012-10-23 15:40:25 --> Severity: 4096  --> Object of class stdClass could not be converted to string /home/jwp/www/justinwylliephotography.com/clients/system/helpers/form_helper.php 352
DEBUG - 2012-10-23 15:40:25 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 15:40:25 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 15:40:25 --> Final output sent to browser
DEBUG - 2012-10-23 15:40:25 --> Total execution time: 0.0421
DEBUG - 2012-10-23 15:41:26 --> Config Class Initialized
DEBUG - 2012-10-23 15:41:26 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:41:26 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:41:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:41:26 --> URI Class Initialized
DEBUG - 2012-10-23 15:41:26 --> Router Class Initialized
DEBUG - 2012-10-23 15:41:26 --> Output Class Initialized
DEBUG - 2012-10-23 15:41:26 --> Security Class Initialized
DEBUG - 2012-10-23 15:41:26 --> Input Class Initialized
DEBUG - 2012-10-23 15:41:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:41:26 --> Language Class Initialized
DEBUG - 2012-10-23 15:41:26 --> Loader Class Initialized
DEBUG - 2012-10-23 15:41:26 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:41:26 --> Controller Class Initialized
DEBUG - 2012-10-23 15:41:26 --> Model Class Initialized
DEBUG - 2012-10-23 15:41:26 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:41:26 --> Helper loaded: form_helper
DEBUG - 2012-10-23 15:44:49 --> Config Class Initialized
DEBUG - 2012-10-23 15:44:49 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:44:49 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:44:49 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:44:49 --> URI Class Initialized
DEBUG - 2012-10-23 15:44:49 --> Router Class Initialized
DEBUG - 2012-10-23 15:44:49 --> Output Class Initialized
DEBUG - 2012-10-23 15:44:49 --> Security Class Initialized
DEBUG - 2012-10-23 15:44:49 --> Input Class Initialized
DEBUG - 2012-10-23 15:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:44:49 --> Language Class Initialized
DEBUG - 2012-10-23 15:44:49 --> Loader Class Initialized
DEBUG - 2012-10-23 15:44:49 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:44:49 --> Controller Class Initialized
DEBUG - 2012-10-23 15:44:49 --> Model Class Initialized
DEBUG - 2012-10-23 15:44:49 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:44:49 --> Helper loaded: form_helper
DEBUG - 2012-10-23 15:45:04 --> Config Class Initialized
DEBUG - 2012-10-23 15:45:04 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:45:04 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:45:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:45:04 --> URI Class Initialized
DEBUG - 2012-10-23 15:45:04 --> Router Class Initialized
DEBUG - 2012-10-23 15:45:04 --> Output Class Initialized
DEBUG - 2012-10-23 15:45:04 --> Security Class Initialized
DEBUG - 2012-10-23 15:45:04 --> Input Class Initialized
DEBUG - 2012-10-23 15:45:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:45:04 --> Language Class Initialized
DEBUG - 2012-10-23 15:45:04 --> Loader Class Initialized
DEBUG - 2012-10-23 15:45:04 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:45:04 --> Controller Class Initialized
DEBUG - 2012-10-23 15:45:04 --> Model Class Initialized
DEBUG - 2012-10-23 15:45:04 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:45:04 --> Helper loaded: form_helper
DEBUG - 2012-10-23 15:45:04 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 15:45:04 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 15:45:04 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 15:45:04 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 15:45:04 --> Final output sent to browser
DEBUG - 2012-10-23 15:45:04 --> Total execution time: 0.0456
DEBUG - 2012-10-23 15:59:40 --> Config Class Initialized
DEBUG - 2012-10-23 15:59:40 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:59:40 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:59:40 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:59:40 --> URI Class Initialized
DEBUG - 2012-10-23 15:59:40 --> Router Class Initialized
DEBUG - 2012-10-23 15:59:40 --> Output Class Initialized
DEBUG - 2012-10-23 15:59:40 --> Security Class Initialized
DEBUG - 2012-10-23 15:59:40 --> Input Class Initialized
DEBUG - 2012-10-23 15:59:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 15:59:40 --> Language Class Initialized
DEBUG - 2012-10-23 15:59:40 --> Loader Class Initialized
DEBUG - 2012-10-23 15:59:40 --> Helper loaded: url_helper
DEBUG - 2012-10-23 15:59:40 --> Controller Class Initialized
DEBUG - 2012-10-23 15:59:40 --> Model Class Initialized
DEBUG - 2012-10-23 15:59:40 --> Database Driver Class Initialized
DEBUG - 2012-10-23 15:59:40 --> Helper loaded: form_helper
DEBUG - 2012-10-23 15:59:40 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 15:59:40 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 15:59:40 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 15:59:40 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 15:59:40 --> Final output sent to browser
DEBUG - 2012-10-23 15:59:40 --> Total execution time: 0.0442
DEBUG - 2012-10-23 15:59:41 --> Config Class Initialized
DEBUG - 2012-10-23 15:59:41 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:59:41 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:59:41 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:59:41 --> URI Class Initialized
DEBUG - 2012-10-23 15:59:41 --> Router Class Initialized
ERROR - 2012-10-23 15:59:41 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 15:59:41 --> Config Class Initialized
DEBUG - 2012-10-23 15:59:41 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:59:41 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:59:41 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:59:41 --> URI Class Initialized
DEBUG - 2012-10-23 15:59:41 --> Router Class Initialized
ERROR - 2012-10-23 15:59:41 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 15:59:41 --> Config Class Initialized
DEBUG - 2012-10-23 15:59:41 --> Hooks Class Initialized
DEBUG - 2012-10-23 15:59:41 --> Utf8 Class Initialized
DEBUG - 2012-10-23 15:59:41 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 15:59:41 --> URI Class Initialized
DEBUG - 2012-10-23 15:59:41 --> Router Class Initialized
ERROR - 2012-10-23 15:59:41 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:00:18 --> Config Class Initialized
DEBUG - 2012-10-23 16:00:18 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:00:18 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:00:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:00:18 --> URI Class Initialized
DEBUG - 2012-10-23 16:00:18 --> Router Class Initialized
DEBUG - 2012-10-23 16:00:18 --> Output Class Initialized
DEBUG - 2012-10-23 16:00:18 --> Security Class Initialized
DEBUG - 2012-10-23 16:00:18 --> Input Class Initialized
DEBUG - 2012-10-23 16:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 16:00:18 --> Language Class Initialized
DEBUG - 2012-10-23 16:00:18 --> Loader Class Initialized
DEBUG - 2012-10-23 16:00:18 --> Helper loaded: url_helper
DEBUG - 2012-10-23 16:00:18 --> Controller Class Initialized
DEBUG - 2012-10-23 16:00:18 --> Model Class Initialized
DEBUG - 2012-10-23 16:00:18 --> Database Driver Class Initialized
DEBUG - 2012-10-23 16:00:18 --> Helper loaded: form_helper
DEBUG - 2012-10-23 16:00:18 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 16:00:18 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 16:00:18 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 16:00:18 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 16:00:18 --> Final output sent to browser
DEBUG - 2012-10-23 16:00:18 --> Total execution time: 0.0414
DEBUG - 2012-10-23 16:00:20 --> Config Class Initialized
DEBUG - 2012-10-23 16:00:20 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:00:20 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:00:20 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:00:20 --> URI Class Initialized
DEBUG - 2012-10-23 16:00:20 --> Router Class Initialized
ERROR - 2012-10-23 16:00:20 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:00:20 --> Config Class Initialized
DEBUG - 2012-10-23 16:00:20 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:00:20 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:00:20 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:00:20 --> URI Class Initialized
DEBUG - 2012-10-23 16:00:20 --> Router Class Initialized
ERROR - 2012-10-23 16:00:20 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:00:20 --> Config Class Initialized
DEBUG - 2012-10-23 16:00:20 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:00:20 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:00:20 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:00:20 --> URI Class Initialized
DEBUG - 2012-10-23 16:00:20 --> Router Class Initialized
ERROR - 2012-10-23 16:00:20 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:02:25 --> Config Class Initialized
DEBUG - 2012-10-23 16:02:25 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:02:25 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:02:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:02:25 --> URI Class Initialized
DEBUG - 2012-10-23 16:02:25 --> Router Class Initialized
DEBUG - 2012-10-23 16:02:25 --> Output Class Initialized
DEBUG - 2012-10-23 16:02:25 --> Security Class Initialized
DEBUG - 2012-10-23 16:02:25 --> Input Class Initialized
DEBUG - 2012-10-23 16:02:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 16:02:25 --> Language Class Initialized
DEBUG - 2012-10-23 16:02:25 --> Loader Class Initialized
DEBUG - 2012-10-23 16:02:25 --> Helper loaded: url_helper
DEBUG - 2012-10-23 16:02:25 --> Controller Class Initialized
DEBUG - 2012-10-23 16:02:25 --> Model Class Initialized
DEBUG - 2012-10-23 16:02:25 --> Database Driver Class Initialized
DEBUG - 2012-10-23 16:02:25 --> Helper loaded: form_helper
DEBUG - 2012-10-23 16:02:25 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 16:02:25 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 16:02:25 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 16:02:25 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 16:02:25 --> Final output sent to browser
DEBUG - 2012-10-23 16:02:25 --> Total execution time: 0.0418
DEBUG - 2012-10-23 16:02:27 --> Config Class Initialized
DEBUG - 2012-10-23 16:02:27 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:02:27 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:02:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:02:27 --> URI Class Initialized
DEBUG - 2012-10-23 16:02:27 --> Router Class Initialized
ERROR - 2012-10-23 16:02:27 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:02:27 --> Config Class Initialized
DEBUG - 2012-10-23 16:02:27 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:02:27 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:02:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:02:27 --> URI Class Initialized
DEBUG - 2012-10-23 16:02:27 --> Router Class Initialized
ERROR - 2012-10-23 16:02:27 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:02:27 --> Config Class Initialized
DEBUG - 2012-10-23 16:02:27 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:02:27 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:02:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:02:27 --> URI Class Initialized
DEBUG - 2012-10-23 16:02:27 --> Router Class Initialized
ERROR - 2012-10-23 16:02:27 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:05:34 --> Config Class Initialized
DEBUG - 2012-10-23 16:05:34 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:05:34 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:05:34 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:05:34 --> URI Class Initialized
DEBUG - 2012-10-23 16:05:34 --> Router Class Initialized
DEBUG - 2012-10-23 16:05:34 --> Output Class Initialized
DEBUG - 2012-10-23 16:05:34 --> Security Class Initialized
DEBUG - 2012-10-23 16:05:34 --> Input Class Initialized
DEBUG - 2012-10-23 16:05:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 16:05:34 --> Language Class Initialized
DEBUG - 2012-10-23 16:05:34 --> Loader Class Initialized
DEBUG - 2012-10-23 16:05:34 --> Helper loaded: url_helper
DEBUG - 2012-10-23 16:05:34 --> Controller Class Initialized
DEBUG - 2012-10-23 16:05:34 --> Model Class Initialized
DEBUG - 2012-10-23 16:05:34 --> Database Driver Class Initialized
DEBUG - 2012-10-23 16:05:34 --> Helper loaded: form_helper
DEBUG - 2012-10-23 16:05:35 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 16:05:35 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 16:05:35 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-23 16:05:35 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 16:05:35 --> Final output sent to browser
DEBUG - 2012-10-23 16:05:35 --> Total execution time: 0.0795
DEBUG - 2012-10-23 16:05:37 --> Config Class Initialized
DEBUG - 2012-10-23 16:05:37 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:05:37 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:05:37 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:05:37 --> URI Class Initialized
DEBUG - 2012-10-23 16:05:37 --> Router Class Initialized
ERROR - 2012-10-23 16:05:37 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:05:37 --> Config Class Initialized
DEBUG - 2012-10-23 16:05:37 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:05:37 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:05:37 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:05:37 --> URI Class Initialized
DEBUG - 2012-10-23 16:05:37 --> Router Class Initialized
ERROR - 2012-10-23 16:05:37 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:05:37 --> Config Class Initialized
DEBUG - 2012-10-23 16:05:37 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:05:37 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:05:37 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:05:37 --> URI Class Initialized
DEBUG - 2012-10-23 16:05:37 --> Router Class Initialized
ERROR - 2012-10-23 16:05:37 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:05:48 --> Config Class Initialized
DEBUG - 2012-10-23 16:05:48 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:05:48 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:05:48 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:05:48 --> URI Class Initialized
DEBUG - 2012-10-23 16:05:48 --> Router Class Initialized
DEBUG - 2012-10-23 16:05:48 --> Output Class Initialized
DEBUG - 2012-10-23 16:05:48 --> Security Class Initialized
DEBUG - 2012-10-23 16:05:48 --> Input Class Initialized
DEBUG - 2012-10-23 16:05:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 16:05:48 --> Language Class Initialized
DEBUG - 2012-10-23 16:05:48 --> Loader Class Initialized
DEBUG - 2012-10-23 16:05:48 --> Helper loaded: url_helper
DEBUG - 2012-10-23 16:05:48 --> Controller Class Initialized
DEBUG - 2012-10-23 16:05:48 --> Model Class Initialized
DEBUG - 2012-10-23 16:05:48 --> Database Driver Class Initialized
DEBUG - 2012-10-23 16:05:48 --> Helper loaded: form_helper
DEBUG - 2012-10-23 16:05:48 --> Helper loaded: language_helper
DEBUG - 2012-10-23 16:05:48 --> Form Validation Class Initialized
DEBUG - 2012-10-23 16:05:48 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-23 16:05:48 --> Upload Class Initialized
DEBUG - 2012-10-23 16:05:48 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-10-23 16:05:48 --> Final output sent to browser
DEBUG - 2012-10-23 16:05:48 --> Total execution time: 0.2759
DEBUG - 2012-10-23 16:05:51 --> Config Class Initialized
DEBUG - 2012-10-23 16:05:51 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:05:51 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:05:51 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:05:51 --> URI Class Initialized
DEBUG - 2012-10-23 16:05:51 --> Router Class Initialized
DEBUG - 2012-10-23 16:05:51 --> Output Class Initialized
DEBUG - 2012-10-23 16:05:51 --> Security Class Initialized
DEBUG - 2012-10-23 16:05:51 --> Input Class Initialized
DEBUG - 2012-10-23 16:05:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 16:05:51 --> Language Class Initialized
DEBUG - 2012-10-23 16:05:51 --> Loader Class Initialized
DEBUG - 2012-10-23 16:05:51 --> Helper loaded: url_helper
DEBUG - 2012-10-23 16:05:51 --> Controller Class Initialized
DEBUG - 2012-10-23 16:05:51 --> Model Class Initialized
DEBUG - 2012-10-23 16:05:51 --> Database Driver Class Initialized
DEBUG - 2012-10-23 16:05:51 --> Helper loaded: language_helper
DEBUG - 2012-10-23 16:05:51 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-23 16:16:17 --> Config Class Initialized
DEBUG - 2012-10-23 16:16:17 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:16:17 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:16:17 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:16:17 --> URI Class Initialized
DEBUG - 2012-10-23 16:16:17 --> Router Class Initialized
DEBUG - 2012-10-23 16:16:17 --> Output Class Initialized
DEBUG - 2012-10-23 16:16:17 --> Security Class Initialized
DEBUG - 2012-10-23 16:16:17 --> Input Class Initialized
DEBUG - 2012-10-23 16:16:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 16:16:17 --> Language Class Initialized
DEBUG - 2012-10-23 16:16:17 --> Loader Class Initialized
DEBUG - 2012-10-23 16:16:17 --> Helper loaded: url_helper
DEBUG - 2012-10-23 16:16:17 --> Controller Class Initialized
DEBUG - 2012-10-23 16:16:17 --> Model Class Initialized
DEBUG - 2012-10-23 16:16:17 --> Database Driver Class Initialized
DEBUG - 2012-10-23 16:16:17 --> Helper loaded: form_helper
DEBUG - 2012-10-23 16:16:17 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 16:16:17 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 16:16:17 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-23 16:16:17 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 16:16:17 --> Final output sent to browser
DEBUG - 2012-10-23 16:16:17 --> Total execution time: 0.0425
DEBUG - 2012-10-23 16:16:19 --> Config Class Initialized
DEBUG - 2012-10-23 16:16:19 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:16:19 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:16:19 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:16:19 --> URI Class Initialized
DEBUG - 2012-10-23 16:16:19 --> Router Class Initialized
ERROR - 2012-10-23 16:16:19 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:16:19 --> Config Class Initialized
DEBUG - 2012-10-23 16:16:19 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:16:19 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:16:19 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:16:19 --> URI Class Initialized
DEBUG - 2012-10-23 16:16:19 --> Router Class Initialized
ERROR - 2012-10-23 16:16:19 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:16:19 --> Config Class Initialized
DEBUG - 2012-10-23 16:16:19 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:16:19 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:16:19 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:16:19 --> URI Class Initialized
DEBUG - 2012-10-23 16:16:19 --> Router Class Initialized
ERROR - 2012-10-23 16:16:19 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:16:22 --> Config Class Initialized
DEBUG - 2012-10-23 16:16:22 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:16:22 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:16:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:16:22 --> URI Class Initialized
DEBUG - 2012-10-23 16:16:22 --> Router Class Initialized
DEBUG - 2012-10-23 16:16:22 --> Output Class Initialized
DEBUG - 2012-10-23 16:16:22 --> Security Class Initialized
DEBUG - 2012-10-23 16:16:22 --> Input Class Initialized
DEBUG - 2012-10-23 16:16:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 16:16:22 --> Language Class Initialized
DEBUG - 2012-10-23 16:16:22 --> Loader Class Initialized
DEBUG - 2012-10-23 16:16:22 --> Helper loaded: url_helper
DEBUG - 2012-10-23 16:16:22 --> Controller Class Initialized
DEBUG - 2012-10-23 16:16:22 --> Model Class Initialized
DEBUG - 2012-10-23 16:16:22 --> Database Driver Class Initialized
DEBUG - 2012-10-23 16:16:22 --> Helper loaded: form_helper
DEBUG - 2012-10-23 16:16:22 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 16:16:22 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 16:16:22 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 16:16:22 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 16:16:22 --> Final output sent to browser
DEBUG - 2012-10-23 16:16:22 --> Total execution time: 0.0413
DEBUG - 2012-10-23 16:16:24 --> Config Class Initialized
DEBUG - 2012-10-23 16:16:24 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:16:24 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:16:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:16:24 --> URI Class Initialized
DEBUG - 2012-10-23 16:16:24 --> Router Class Initialized
ERROR - 2012-10-23 16:16:24 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:16:24 --> Config Class Initialized
DEBUG - 2012-10-23 16:16:24 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:16:24 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:16:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:16:24 --> URI Class Initialized
DEBUG - 2012-10-23 16:16:24 --> Router Class Initialized
ERROR - 2012-10-23 16:16:24 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:16:24 --> Config Class Initialized
DEBUG - 2012-10-23 16:16:24 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:16:24 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:16:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:16:24 --> URI Class Initialized
DEBUG - 2012-10-23 16:16:24 --> Router Class Initialized
ERROR - 2012-10-23 16:16:24 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:17:26 --> Config Class Initialized
DEBUG - 2012-10-23 16:17:26 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:17:26 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:17:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:17:26 --> URI Class Initialized
DEBUG - 2012-10-23 16:17:26 --> Router Class Initialized
DEBUG - 2012-10-23 16:17:26 --> Output Class Initialized
DEBUG - 2012-10-23 16:17:26 --> Security Class Initialized
DEBUG - 2012-10-23 16:17:26 --> Input Class Initialized
DEBUG - 2012-10-23 16:17:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 16:17:26 --> Language Class Initialized
DEBUG - 2012-10-23 16:17:26 --> Loader Class Initialized
DEBUG - 2012-10-23 16:17:26 --> Helper loaded: url_helper
DEBUG - 2012-10-23 16:17:26 --> Controller Class Initialized
DEBUG - 2012-10-23 16:17:26 --> Model Class Initialized
DEBUG - 2012-10-23 16:17:26 --> Database Driver Class Initialized
DEBUG - 2012-10-23 16:17:26 --> Helper loaded: form_helper
DEBUG - 2012-10-23 16:17:26 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 16:17:26 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 16:17:26 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-23 16:17:26 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 16:17:26 --> Final output sent to browser
DEBUG - 2012-10-23 16:17:26 --> Total execution time: 0.0472
DEBUG - 2012-10-23 16:17:28 --> Config Class Initialized
DEBUG - 2012-10-23 16:17:28 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:17:28 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:17:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:17:28 --> URI Class Initialized
DEBUG - 2012-10-23 16:17:28 --> Router Class Initialized
ERROR - 2012-10-23 16:17:28 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:17:28 --> Config Class Initialized
DEBUG - 2012-10-23 16:17:28 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:17:28 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:17:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:17:28 --> URI Class Initialized
DEBUG - 2012-10-23 16:17:28 --> Router Class Initialized
ERROR - 2012-10-23 16:17:28 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:17:28 --> Config Class Initialized
DEBUG - 2012-10-23 16:17:28 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:17:28 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:17:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:17:28 --> URI Class Initialized
DEBUG - 2012-10-23 16:17:28 --> Router Class Initialized
ERROR - 2012-10-23 16:17:28 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:22:19 --> Config Class Initialized
DEBUG - 2012-10-23 16:22:19 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:22:19 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:22:19 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:22:19 --> URI Class Initialized
DEBUG - 2012-10-23 16:22:19 --> Router Class Initialized
DEBUG - 2012-10-23 16:22:19 --> Output Class Initialized
DEBUG - 2012-10-23 16:22:19 --> Security Class Initialized
DEBUG - 2012-10-23 16:22:19 --> Input Class Initialized
DEBUG - 2012-10-23 16:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 16:22:19 --> Language Class Initialized
DEBUG - 2012-10-23 16:22:19 --> Loader Class Initialized
DEBUG - 2012-10-23 16:22:19 --> Helper loaded: url_helper
DEBUG - 2012-10-23 16:22:19 --> Controller Class Initialized
DEBUG - 2012-10-23 16:22:19 --> Model Class Initialized
DEBUG - 2012-10-23 16:22:19 --> Database Driver Class Initialized
DEBUG - 2012-10-23 16:22:19 --> Helper loaded: form_helper
DEBUG - 2012-10-23 16:22:19 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 16:22:19 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 16:22:19 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-10-23 16:22:19 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 16:22:19 --> Final output sent to browser
DEBUG - 2012-10-23 16:22:19 --> Total execution time: 0.0498
DEBUG - 2012-10-23 16:22:21 --> Config Class Initialized
DEBUG - 2012-10-23 16:22:21 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:22:21 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:22:21 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:22:21 --> URI Class Initialized
DEBUG - 2012-10-23 16:22:21 --> Router Class Initialized
ERROR - 2012-10-23 16:22:21 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:22:21 --> Config Class Initialized
DEBUG - 2012-10-23 16:22:21 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:22:21 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:22:21 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:22:21 --> URI Class Initialized
DEBUG - 2012-10-23 16:22:21 --> Router Class Initialized
ERROR - 2012-10-23 16:22:21 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:22:21 --> Config Class Initialized
DEBUG - 2012-10-23 16:22:21 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:22:21 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:22:21 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:22:21 --> URI Class Initialized
DEBUG - 2012-10-23 16:22:21 --> Router Class Initialized
ERROR - 2012-10-23 16:22:21 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:22:26 --> Config Class Initialized
DEBUG - 2012-10-23 16:22:26 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:22:26 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:22:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:22:26 --> URI Class Initialized
DEBUG - 2012-10-23 16:22:26 --> Router Class Initialized
DEBUG - 2012-10-23 16:22:26 --> Output Class Initialized
DEBUG - 2012-10-23 16:22:26 --> Security Class Initialized
DEBUG - 2012-10-23 16:22:26 --> Input Class Initialized
DEBUG - 2012-10-23 16:22:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 16:22:26 --> Language Class Initialized
DEBUG - 2012-10-23 16:22:26 --> Loader Class Initialized
DEBUG - 2012-10-23 16:22:26 --> Helper loaded: url_helper
DEBUG - 2012-10-23 16:22:26 --> Controller Class Initialized
DEBUG - 2012-10-23 16:22:26 --> Model Class Initialized
DEBUG - 2012-10-23 16:22:26 --> Database Driver Class Initialized
DEBUG - 2012-10-23 16:22:26 --> Helper loaded: form_helper
DEBUG - 2012-10-23 16:22:26 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 16:22:26 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 16:22:26 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 16:22:26 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 16:22:26 --> Final output sent to browser
DEBUG - 2012-10-23 16:22:26 --> Total execution time: 0.0461
DEBUG - 2012-10-23 16:22:28 --> Config Class Initialized
DEBUG - 2012-10-23 16:22:28 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:22:28 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:22:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:22:28 --> URI Class Initialized
DEBUG - 2012-10-23 16:22:28 --> Router Class Initialized
ERROR - 2012-10-23 16:22:28 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:22:28 --> Config Class Initialized
DEBUG - 2012-10-23 16:22:28 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:22:28 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:22:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:22:28 --> URI Class Initialized
DEBUG - 2012-10-23 16:22:28 --> Router Class Initialized
ERROR - 2012-10-23 16:22:28 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:22:28 --> Config Class Initialized
DEBUG - 2012-10-23 16:22:28 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:22:28 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:22:28 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:22:28 --> URI Class Initialized
DEBUG - 2012-10-23 16:22:28 --> Router Class Initialized
ERROR - 2012-10-23 16:22:28 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:23:18 --> Config Class Initialized
DEBUG - 2012-10-23 16:23:18 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:23:18 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:23:18 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:23:18 --> URI Class Initialized
DEBUG - 2012-10-23 16:23:18 --> Router Class Initialized
DEBUG - 2012-10-23 16:23:18 --> Output Class Initialized
DEBUG - 2012-10-23 16:23:18 --> Security Class Initialized
DEBUG - 2012-10-23 16:23:18 --> Input Class Initialized
DEBUG - 2012-10-23 16:23:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 16:23:18 --> Language Class Initialized
DEBUG - 2012-10-23 16:23:18 --> Loader Class Initialized
DEBUG - 2012-10-23 16:23:18 --> Helper loaded: url_helper
DEBUG - 2012-10-23 16:23:18 --> Controller Class Initialized
DEBUG - 2012-10-23 16:23:18 --> Model Class Initialized
DEBUG - 2012-10-23 16:23:18 --> Database Driver Class Initialized
DEBUG - 2012-10-23 16:23:18 --> Helper loaded: form_helper
DEBUG - 2012-10-23 16:23:18 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 16:23:18 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 16:23:18 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 16:23:18 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 16:23:18 --> Final output sent to browser
DEBUG - 2012-10-23 16:23:18 --> Total execution time: 0.0500
DEBUG - 2012-10-23 16:23:20 --> Config Class Initialized
DEBUG - 2012-10-23 16:23:20 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:23:20 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:23:20 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:23:20 --> URI Class Initialized
DEBUG - 2012-10-23 16:23:20 --> Router Class Initialized
ERROR - 2012-10-23 16:23:20 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:23:20 --> Config Class Initialized
DEBUG - 2012-10-23 16:23:20 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:23:20 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:23:20 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:23:20 --> URI Class Initialized
DEBUG - 2012-10-23 16:23:20 --> Router Class Initialized
ERROR - 2012-10-23 16:23:20 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 16:23:20 --> Config Class Initialized
DEBUG - 2012-10-23 16:23:20 --> Hooks Class Initialized
DEBUG - 2012-10-23 16:23:20 --> Utf8 Class Initialized
DEBUG - 2012-10-23 16:23:20 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 16:23:20 --> URI Class Initialized
DEBUG - 2012-10-23 16:23:20 --> Router Class Initialized
ERROR - 2012-10-23 16:23:20 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 17:47:59 --> Config Class Initialized
DEBUG - 2012-10-23 17:47:59 --> Hooks Class Initialized
DEBUG - 2012-10-23 17:47:59 --> Utf8 Class Initialized
DEBUG - 2012-10-23 17:47:59 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 17:47:59 --> URI Class Initialized
DEBUG - 2012-10-23 17:47:59 --> Router Class Initialized
DEBUG - 2012-10-23 17:47:59 --> Output Class Initialized
DEBUG - 2012-10-23 17:47:59 --> Security Class Initialized
DEBUG - 2012-10-23 17:47:59 --> Input Class Initialized
DEBUG - 2012-10-23 17:47:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 17:47:59 --> Language Class Initialized
DEBUG - 2012-10-23 17:47:59 --> Loader Class Initialized
DEBUG - 2012-10-23 17:47:59 --> Helper loaded: url_helper
DEBUG - 2012-10-23 17:47:59 --> Controller Class Initialized
DEBUG - 2012-10-23 17:47:59 --> Model Class Initialized
DEBUG - 2012-10-23 17:47:59 --> Database Driver Class Initialized
DEBUG - 2012-10-23 17:47:59 --> Helper loaded: form_helper
DEBUG - 2012-10-23 17:47:59 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 17:47:59 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 17:47:59 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 17:47:59 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 17:47:59 --> Final output sent to browser
DEBUG - 2012-10-23 17:47:59 --> Total execution time: 0.0415
DEBUG - 2012-10-23 17:48:01 --> Config Class Initialized
DEBUG - 2012-10-23 17:48:02 --> Hooks Class Initialized
DEBUG - 2012-10-23 17:48:02 --> Utf8 Class Initialized
DEBUG - 2012-10-23 17:48:02 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 17:48:02 --> URI Class Initialized
DEBUG - 2012-10-23 17:48:02 --> Config Class Initialized
DEBUG - 2012-10-23 17:48:02 --> Hooks Class Initialized
DEBUG - 2012-10-23 17:48:02 --> Router Class Initialized
DEBUG - 2012-10-23 17:48:02 --> Utf8 Class Initialized
DEBUG - 2012-10-23 17:48:02 --> UTF-8 Support Enabled
ERROR - 2012-10-23 17:48:02 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 17:48:02 --> URI Class Initialized
DEBUG - 2012-10-23 17:48:02 --> Router Class Initialized
ERROR - 2012-10-23 17:48:02 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 17:48:02 --> Config Class Initialized
DEBUG - 2012-10-23 17:48:02 --> Hooks Class Initialized
DEBUG - 2012-10-23 17:48:02 --> Utf8 Class Initialized
DEBUG - 2012-10-23 17:48:02 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 17:48:02 --> URI Class Initialized
DEBUG - 2012-10-23 17:48:02 --> Router Class Initialized
ERROR - 2012-10-23 17:48:02 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 17:48:45 --> Config Class Initialized
DEBUG - 2012-10-23 17:48:45 --> Hooks Class Initialized
DEBUG - 2012-10-23 17:48:45 --> Utf8 Class Initialized
DEBUG - 2012-10-23 17:48:45 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 17:48:45 --> URI Class Initialized
DEBUG - 2012-10-23 17:48:45 --> Router Class Initialized
DEBUG - 2012-10-23 17:48:45 --> Output Class Initialized
DEBUG - 2012-10-23 17:48:45 --> Security Class Initialized
DEBUG - 2012-10-23 17:48:45 --> Input Class Initialized
DEBUG - 2012-10-23 17:48:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 17:48:45 --> Language Class Initialized
DEBUG - 2012-10-23 17:48:45 --> Loader Class Initialized
DEBUG - 2012-10-23 17:48:45 --> Helper loaded: url_helper
DEBUG - 2012-10-23 17:48:45 --> Controller Class Initialized
DEBUG - 2012-10-23 17:48:45 --> Model Class Initialized
DEBUG - 2012-10-23 17:48:45 --> Database Driver Class Initialized
DEBUG - 2012-10-23 17:48:45 --> Helper loaded: form_helper
DEBUG - 2012-10-23 17:48:45 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 17:48:45 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 17:48:45 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 17:48:45 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 17:48:45 --> Final output sent to browser
DEBUG - 2012-10-23 17:48:45 --> Total execution time: 0.0436
DEBUG - 2012-10-23 17:48:47 --> Config Class Initialized
DEBUG - 2012-10-23 17:48:47 --> Hooks Class Initialized
DEBUG - 2012-10-23 17:48:47 --> Utf8 Class Initialized
DEBUG - 2012-10-23 17:48:47 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 17:48:47 --> URI Class Initialized
DEBUG - 2012-10-23 17:48:47 --> Router Class Initialized
ERROR - 2012-10-23 17:48:47 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 17:48:47 --> Config Class Initialized
DEBUG - 2012-10-23 17:48:47 --> Hooks Class Initialized
DEBUG - 2012-10-23 17:48:47 --> Utf8 Class Initialized
DEBUG - 2012-10-23 17:48:47 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 17:48:47 --> URI Class Initialized
DEBUG - 2012-10-23 17:48:47 --> Router Class Initialized
ERROR - 2012-10-23 17:48:47 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 17:48:47 --> Config Class Initialized
DEBUG - 2012-10-23 17:48:47 --> Hooks Class Initialized
DEBUG - 2012-10-23 17:48:47 --> Utf8 Class Initialized
DEBUG - 2012-10-23 17:48:47 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 17:48:47 --> URI Class Initialized
DEBUG - 2012-10-23 17:48:47 --> Router Class Initialized
ERROR - 2012-10-23 17:48:47 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 17:49:25 --> Config Class Initialized
DEBUG - 2012-10-23 17:49:25 --> Hooks Class Initialized
DEBUG - 2012-10-23 17:49:25 --> Utf8 Class Initialized
DEBUG - 2012-10-23 17:49:25 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 17:49:25 --> URI Class Initialized
DEBUG - 2012-10-23 17:49:25 --> Router Class Initialized
DEBUG - 2012-10-23 17:49:25 --> Output Class Initialized
DEBUG - 2012-10-23 17:49:25 --> Security Class Initialized
DEBUG - 2012-10-23 17:49:25 --> Input Class Initialized
DEBUG - 2012-10-23 17:49:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 17:49:25 --> Language Class Initialized
DEBUG - 2012-10-23 17:49:25 --> Loader Class Initialized
DEBUG - 2012-10-23 17:49:25 --> Helper loaded: url_helper
DEBUG - 2012-10-23 17:49:25 --> Controller Class Initialized
DEBUG - 2012-10-23 17:49:25 --> Model Class Initialized
DEBUG - 2012-10-23 17:49:25 --> Database Driver Class Initialized
DEBUG - 2012-10-23 17:49:25 --> Helper loaded: form_helper
DEBUG - 2012-10-23 17:49:25 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 17:49:25 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 17:49:25 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 17:49:25 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 17:49:25 --> Final output sent to browser
DEBUG - 2012-10-23 17:49:25 --> Total execution time: 0.0533
DEBUG - 2012-10-23 17:49:27 --> Config Class Initialized
DEBUG - 2012-10-23 17:49:27 --> Hooks Class Initialized
DEBUG - 2012-10-23 17:49:27 --> Utf8 Class Initialized
DEBUG - 2012-10-23 17:49:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 17:49:27 --> URI Class Initialized
DEBUG - 2012-10-23 17:49:27 --> Router Class Initialized
ERROR - 2012-10-23 17:49:27 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 17:49:27 --> Config Class Initialized
DEBUG - 2012-10-23 17:49:27 --> Hooks Class Initialized
DEBUG - 2012-10-23 17:49:27 --> Utf8 Class Initialized
DEBUG - 2012-10-23 17:49:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 17:49:27 --> URI Class Initialized
DEBUG - 2012-10-23 17:49:27 --> Router Class Initialized
ERROR - 2012-10-23 17:49:27 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 17:49:27 --> Config Class Initialized
DEBUG - 2012-10-23 17:49:27 --> Hooks Class Initialized
DEBUG - 2012-10-23 17:49:27 --> Utf8 Class Initialized
DEBUG - 2012-10-23 17:49:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 17:49:27 --> URI Class Initialized
DEBUG - 2012-10-23 17:49:27 --> Router Class Initialized
ERROR - 2012-10-23 17:49:27 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 17:50:31 --> Config Class Initialized
DEBUG - 2012-10-23 17:50:31 --> Hooks Class Initialized
DEBUG - 2012-10-23 17:50:31 --> Utf8 Class Initialized
DEBUG - 2012-10-23 17:50:31 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 17:50:31 --> URI Class Initialized
DEBUG - 2012-10-23 17:50:31 --> Router Class Initialized
DEBUG - 2012-10-23 17:50:31 --> Output Class Initialized
DEBUG - 2012-10-23 17:50:31 --> Security Class Initialized
DEBUG - 2012-10-23 17:50:31 --> Input Class Initialized
DEBUG - 2012-10-23 17:50:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 17:50:31 --> Language Class Initialized
DEBUG - 2012-10-23 17:50:31 --> Loader Class Initialized
DEBUG - 2012-10-23 17:50:31 --> Helper loaded: url_helper
DEBUG - 2012-10-23 17:50:31 --> Controller Class Initialized
DEBUG - 2012-10-23 17:50:31 --> Model Class Initialized
DEBUG - 2012-10-23 17:50:31 --> Database Driver Class Initialized
DEBUG - 2012-10-23 17:50:31 --> Helper loaded: form_helper
DEBUG - 2012-10-23 17:50:31 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 17:50:31 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 17:50:31 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 17:50:31 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 17:50:31 --> Final output sent to browser
DEBUG - 2012-10-23 17:50:31 --> Total execution time: 0.0417
DEBUG - 2012-10-23 17:50:33 --> Config Class Initialized
DEBUG - 2012-10-23 17:50:33 --> Hooks Class Initialized
DEBUG - 2012-10-23 17:50:33 --> Utf8 Class Initialized
DEBUG - 2012-10-23 17:50:33 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 17:50:33 --> URI Class Initialized
DEBUG - 2012-10-23 17:50:33 --> Router Class Initialized
ERROR - 2012-10-23 17:50:33 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 17:50:33 --> Config Class Initialized
DEBUG - 2012-10-23 17:50:33 --> Hooks Class Initialized
DEBUG - 2012-10-23 17:50:33 --> Utf8 Class Initialized
DEBUG - 2012-10-23 17:50:33 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 17:50:33 --> URI Class Initialized
DEBUG - 2012-10-23 17:50:33 --> Router Class Initialized
ERROR - 2012-10-23 17:50:33 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 17:50:33 --> Config Class Initialized
DEBUG - 2012-10-23 17:50:33 --> Hooks Class Initialized
DEBUG - 2012-10-23 17:50:33 --> Utf8 Class Initialized
DEBUG - 2012-10-23 17:50:33 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 17:50:33 --> URI Class Initialized
DEBUG - 2012-10-23 17:50:33 --> Router Class Initialized
ERROR - 2012-10-23 17:50:33 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:25:01 --> Config Class Initialized
DEBUG - 2012-10-23 18:25:01 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:25:01 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:25:01 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:25:01 --> URI Class Initialized
DEBUG - 2012-10-23 18:25:01 --> Router Class Initialized
DEBUG - 2012-10-23 18:25:01 --> Output Class Initialized
DEBUG - 2012-10-23 18:25:01 --> Security Class Initialized
DEBUG - 2012-10-23 18:25:01 --> Input Class Initialized
DEBUG - 2012-10-23 18:25:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:25:01 --> Language Class Initialized
DEBUG - 2012-10-23 18:25:01 --> Loader Class Initialized
DEBUG - 2012-10-23 18:25:01 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:25:01 --> Controller Class Initialized
DEBUG - 2012-10-23 18:25:01 --> Model Class Initialized
DEBUG - 2012-10-23 18:25:02 --> Database Driver Class Initialized
DEBUG - 2012-10-23 18:25:02 --> Helper loaded: form_helper
DEBUG - 2012-10-23 18:25:02 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 18:25:02 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 18:25:02 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 18:25:02 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 18:25:02 --> Final output sent to browser
DEBUG - 2012-10-23 18:25:02 --> Total execution time: 0.0442
DEBUG - 2012-10-23 18:25:03 --> Config Class Initialized
DEBUG - 2012-10-23 18:25:03 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:25:03 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:25:03 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:25:03 --> URI Class Initialized
DEBUG - 2012-10-23 18:25:03 --> Router Class Initialized
ERROR - 2012-10-23 18:25:03 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:25:03 --> Config Class Initialized
DEBUG - 2012-10-23 18:25:03 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:25:03 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:25:03 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:25:03 --> URI Class Initialized
DEBUG - 2012-10-23 18:25:03 --> Router Class Initialized
ERROR - 2012-10-23 18:25:03 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:25:03 --> Config Class Initialized
DEBUG - 2012-10-23 18:25:03 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:25:03 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:25:03 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:25:03 --> URI Class Initialized
DEBUG - 2012-10-23 18:25:03 --> Router Class Initialized
ERROR - 2012-10-23 18:25:03 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:25:24 --> Config Class Initialized
DEBUG - 2012-10-23 18:25:24 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:25:24 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:25:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:25:24 --> URI Class Initialized
DEBUG - 2012-10-23 18:25:24 --> Router Class Initialized
DEBUG - 2012-10-23 18:25:24 --> Output Class Initialized
DEBUG - 2012-10-23 18:25:24 --> Security Class Initialized
DEBUG - 2012-10-23 18:25:24 --> Input Class Initialized
DEBUG - 2012-10-23 18:25:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:25:24 --> Language Class Initialized
DEBUG - 2012-10-23 18:25:24 --> Loader Class Initialized
DEBUG - 2012-10-23 18:25:24 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:25:24 --> Controller Class Initialized
DEBUG - 2012-10-23 18:25:24 --> Model Class Initialized
DEBUG - 2012-10-23 18:25:24 --> Database Driver Class Initialized
ERROR - 2012-10-23 18:25:24 --> 404 Page Not Found --> pricing/admin
DEBUG - 2012-10-23 18:25:57 --> Config Class Initialized
DEBUG - 2012-10-23 18:25:57 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:25:57 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:25:57 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:25:57 --> URI Class Initialized
DEBUG - 2012-10-23 18:25:57 --> Router Class Initialized
DEBUG - 2012-10-23 18:25:57 --> Output Class Initialized
DEBUG - 2012-10-23 18:25:57 --> Security Class Initialized
DEBUG - 2012-10-23 18:25:57 --> Input Class Initialized
DEBUG - 2012-10-23 18:25:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:25:57 --> Language Class Initialized
DEBUG - 2012-10-23 18:25:57 --> Loader Class Initialized
DEBUG - 2012-10-23 18:25:57 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:25:57 --> Controller Class Initialized
DEBUG - 2012-10-23 18:25:57 --> Model Class Initialized
DEBUG - 2012-10-23 18:25:57 --> Database Driver Class Initialized
DEBUG - 2012-10-23 18:25:57 --> Helper loaded: form_helper
DEBUG - 2012-10-23 18:25:57 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 18:25:57 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 18:25:57 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 18:25:57 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 18:25:57 --> Final output sent to browser
DEBUG - 2012-10-23 18:25:57 --> Total execution time: 0.0442
DEBUG - 2012-10-23 18:25:59 --> Config Class Initialized
DEBUG - 2012-10-23 18:25:59 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:25:59 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:25:59 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:25:59 --> URI Class Initialized
DEBUG - 2012-10-23 18:25:59 --> Router Class Initialized
ERROR - 2012-10-23 18:25:59 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:25:59 --> Config Class Initialized
DEBUG - 2012-10-23 18:25:59 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:25:59 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:25:59 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:25:59 --> URI Class Initialized
DEBUG - 2012-10-23 18:25:59 --> Router Class Initialized
ERROR - 2012-10-23 18:25:59 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:25:59 --> Config Class Initialized
DEBUG - 2012-10-23 18:25:59 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:25:59 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:25:59 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:25:59 --> URI Class Initialized
DEBUG - 2012-10-23 18:25:59 --> Router Class Initialized
ERROR - 2012-10-23 18:25:59 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:26:03 --> Config Class Initialized
DEBUG - 2012-10-23 18:26:03 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:26:03 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:26:03 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:26:03 --> URI Class Initialized
DEBUG - 2012-10-23 18:26:03 --> Router Class Initialized
DEBUG - 2012-10-23 18:26:03 --> Output Class Initialized
DEBUG - 2012-10-23 18:26:03 --> Security Class Initialized
DEBUG - 2012-10-23 18:26:03 --> Input Class Initialized
DEBUG - 2012-10-23 18:26:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:26:03 --> Language Class Initialized
DEBUG - 2012-10-23 18:26:03 --> Loader Class Initialized
DEBUG - 2012-10-23 18:26:03 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:26:03 --> Controller Class Initialized
DEBUG - 2012-10-23 18:26:03 --> Model Class Initialized
DEBUG - 2012-10-23 18:26:03 --> Database Driver Class Initialized
ERROR - 2012-10-23 18:26:03 --> 404 Page Not Found --> pricing/admin
DEBUG - 2012-10-23 18:30:16 --> Config Class Initialized
DEBUG - 2012-10-23 18:30:16 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:30:16 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:30:16 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:30:16 --> URI Class Initialized
DEBUG - 2012-10-23 18:30:16 --> Router Class Initialized
DEBUG - 2012-10-23 18:30:16 --> Output Class Initialized
DEBUG - 2012-10-23 18:30:16 --> Security Class Initialized
DEBUG - 2012-10-23 18:30:16 --> Input Class Initialized
DEBUG - 2012-10-23 18:30:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:30:16 --> Language Class Initialized
DEBUG - 2012-10-23 18:30:16 --> Loader Class Initialized
DEBUG - 2012-10-23 18:30:16 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:30:16 --> Controller Class Initialized
DEBUG - 2012-10-23 18:30:16 --> Model Class Initialized
DEBUG - 2012-10-23 18:30:16 --> Database Driver Class Initialized
ERROR - 2012-10-23 18:30:16 --> 404 Page Not Found --> pricing/admin
DEBUG - 2012-10-23 18:31:13 --> Config Class Initialized
DEBUG - 2012-10-23 18:31:13 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:31:13 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:31:13 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:31:13 --> URI Class Initialized
DEBUG - 2012-10-23 18:31:13 --> Router Class Initialized
DEBUG - 2012-10-23 18:31:13 --> Output Class Initialized
DEBUG - 2012-10-23 18:31:13 --> Security Class Initialized
DEBUG - 2012-10-23 18:31:13 --> Input Class Initialized
DEBUG - 2012-10-23 18:31:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:31:13 --> Language Class Initialized
DEBUG - 2012-10-23 18:31:13 --> Loader Class Initialized
DEBUG - 2012-10-23 18:31:13 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:31:13 --> Controller Class Initialized
DEBUG - 2012-10-23 18:31:13 --> Model Class Initialized
DEBUG - 2012-10-23 18:31:13 --> Database Driver Class Initialized
DEBUG - 2012-10-23 18:31:13 --> Helper loaded: form_helper
DEBUG - 2012-10-23 18:31:13 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 18:31:13 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 18:31:13 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 18:31:13 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 18:31:13 --> Final output sent to browser
DEBUG - 2012-10-23 18:31:13 --> Total execution time: 0.0427
DEBUG - 2012-10-23 18:31:15 --> Config Class Initialized
DEBUG - 2012-10-23 18:31:15 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:31:15 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:31:15 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:31:15 --> URI Class Initialized
DEBUG - 2012-10-23 18:31:15 --> Router Class Initialized
ERROR - 2012-10-23 18:31:15 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:31:15 --> Config Class Initialized
DEBUG - 2012-10-23 18:31:15 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:31:15 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:31:15 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:31:15 --> URI Class Initialized
DEBUG - 2012-10-23 18:31:15 --> Router Class Initialized
ERROR - 2012-10-23 18:31:15 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:31:15 --> Config Class Initialized
DEBUG - 2012-10-23 18:31:15 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:31:15 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:31:15 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:31:15 --> URI Class Initialized
DEBUG - 2012-10-23 18:31:15 --> Router Class Initialized
ERROR - 2012-10-23 18:31:15 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:31:37 --> Config Class Initialized
DEBUG - 2012-10-23 18:31:37 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:31:37 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:31:37 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:31:37 --> URI Class Initialized
DEBUG - 2012-10-23 18:31:37 --> Router Class Initialized
DEBUG - 2012-10-23 18:31:37 --> Output Class Initialized
DEBUG - 2012-10-23 18:31:37 --> Security Class Initialized
DEBUG - 2012-10-23 18:31:37 --> Input Class Initialized
DEBUG - 2012-10-23 18:31:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:31:37 --> Language Class Initialized
DEBUG - 2012-10-23 18:31:37 --> Loader Class Initialized
DEBUG - 2012-10-23 18:31:37 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:31:37 --> Controller Class Initialized
DEBUG - 2012-10-23 18:31:37 --> Model Class Initialized
DEBUG - 2012-10-23 18:31:37 --> Database Driver Class Initialized
ERROR - 2012-10-23 18:31:37 --> 404 Page Not Found --> pricing/admin
DEBUG - 2012-10-23 18:32:46 --> Config Class Initialized
DEBUG - 2012-10-23 18:32:46 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:32:46 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:32:46 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:32:46 --> URI Class Initialized
DEBUG - 2012-10-23 18:32:46 --> Router Class Initialized
DEBUG - 2012-10-23 18:32:46 --> Output Class Initialized
DEBUG - 2012-10-23 18:32:46 --> Security Class Initialized
DEBUG - 2012-10-23 18:32:46 --> Input Class Initialized
DEBUG - 2012-10-23 18:32:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:32:46 --> Language Class Initialized
DEBUG - 2012-10-23 18:32:46 --> Loader Class Initialized
DEBUG - 2012-10-23 18:32:46 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:32:46 --> Controller Class Initialized
DEBUG - 2012-10-23 18:32:46 --> Model Class Initialized
DEBUG - 2012-10-23 18:32:46 --> Database Driver Class Initialized
DEBUG - 2012-10-23 18:32:46 --> Helper loaded: form_helper
DEBUG - 2012-10-23 18:32:46 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 18:32:46 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 18:32:46 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 18:32:46 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 18:32:46 --> Final output sent to browser
DEBUG - 2012-10-23 18:32:46 --> Total execution time: 0.0444
DEBUG - 2012-10-23 18:32:48 --> Config Class Initialized
DEBUG - 2012-10-23 18:32:48 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:32:48 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:32:48 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:32:48 --> URI Class Initialized
DEBUG - 2012-10-23 18:32:48 --> Router Class Initialized
ERROR - 2012-10-23 18:32:48 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:32:48 --> Config Class Initialized
DEBUG - 2012-10-23 18:32:48 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:32:48 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:32:48 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:32:48 --> URI Class Initialized
DEBUG - 2012-10-23 18:32:48 --> Router Class Initialized
ERROR - 2012-10-23 18:32:48 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:32:48 --> Config Class Initialized
DEBUG - 2012-10-23 18:32:48 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:32:48 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:32:48 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:32:48 --> URI Class Initialized
DEBUG - 2012-10-23 18:32:48 --> Router Class Initialized
ERROR - 2012-10-23 18:32:48 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:32:54 --> Config Class Initialized
DEBUG - 2012-10-23 18:32:54 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:32:54 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:32:54 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:32:54 --> URI Class Initialized
DEBUG - 2012-10-23 18:32:54 --> Router Class Initialized
DEBUG - 2012-10-23 18:32:54 --> Output Class Initialized
DEBUG - 2012-10-23 18:32:54 --> Security Class Initialized
DEBUG - 2012-10-23 18:32:54 --> Input Class Initialized
DEBUG - 2012-10-23 18:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:32:54 --> Language Class Initialized
DEBUG - 2012-10-23 18:32:54 --> Loader Class Initialized
DEBUG - 2012-10-23 18:32:54 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:32:54 --> Controller Class Initialized
DEBUG - 2012-10-23 18:32:54 --> Model Class Initialized
DEBUG - 2012-10-23 18:32:54 --> Database Driver Class Initialized
ERROR - 2012-10-23 18:32:54 --> 404 Page Not Found --> pricing/admin
DEBUG - 2012-10-23 18:33:04 --> Config Class Initialized
DEBUG - 2012-10-23 18:33:04 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:33:04 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:33:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:33:04 --> URI Class Initialized
DEBUG - 2012-10-23 18:33:04 --> Router Class Initialized
DEBUG - 2012-10-23 18:33:04 --> Output Class Initialized
DEBUG - 2012-10-23 18:33:04 --> Security Class Initialized
DEBUG - 2012-10-23 18:33:04 --> Input Class Initialized
DEBUG - 2012-10-23 18:33:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:33:04 --> Language Class Initialized
DEBUG - 2012-10-23 18:33:04 --> Loader Class Initialized
DEBUG - 2012-10-23 18:33:04 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:33:04 --> Controller Class Initialized
DEBUG - 2012-10-23 18:33:04 --> Model Class Initialized
DEBUG - 2012-10-23 18:33:04 --> Database Driver Class Initialized
DEBUG - 2012-10-23 18:33:04 --> Helper loaded: form_helper
DEBUG - 2012-10-23 18:33:04 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 18:33:04 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 18:33:04 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 18:33:04 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 18:33:04 --> Final output sent to browser
DEBUG - 2012-10-23 18:33:04 --> Total execution time: 0.0463
DEBUG - 2012-10-23 18:33:06 --> Config Class Initialized
DEBUG - 2012-10-23 18:33:06 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:33:06 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:33:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:33:06 --> URI Class Initialized
DEBUG - 2012-10-23 18:33:06 --> Router Class Initialized
ERROR - 2012-10-23 18:33:06 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:33:06 --> Config Class Initialized
DEBUG - 2012-10-23 18:33:06 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:33:06 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:33:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:33:06 --> URI Class Initialized
DEBUG - 2012-10-23 18:33:06 --> Router Class Initialized
ERROR - 2012-10-23 18:33:06 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:33:06 --> Config Class Initialized
DEBUG - 2012-10-23 18:33:06 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:33:06 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:33:06 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:33:06 --> URI Class Initialized
DEBUG - 2012-10-23 18:33:06 --> Router Class Initialized
ERROR - 2012-10-23 18:33:06 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:33:09 --> Config Class Initialized
DEBUG - 2012-10-23 18:33:09 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:33:09 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:33:09 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:33:09 --> URI Class Initialized
DEBUG - 2012-10-23 18:33:09 --> Router Class Initialized
DEBUG - 2012-10-23 18:33:09 --> Output Class Initialized
DEBUG - 2012-10-23 18:33:09 --> Security Class Initialized
DEBUG - 2012-10-23 18:33:09 --> Input Class Initialized
DEBUG - 2012-10-23 18:33:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:33:09 --> Language Class Initialized
DEBUG - 2012-10-23 18:33:09 --> Loader Class Initialized
DEBUG - 2012-10-23 18:33:09 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:33:09 --> Controller Class Initialized
DEBUG - 2012-10-23 18:33:09 --> Model Class Initialized
DEBUG - 2012-10-23 18:33:09 --> Database Driver Class Initialized
ERROR - 2012-10-23 18:33:09 --> 404 Page Not Found --> pricing/admin
DEBUG - 2012-10-23 18:35:10 --> Config Class Initialized
DEBUG - 2012-10-23 18:35:10 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:35:10 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:35:10 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:35:10 --> URI Class Initialized
DEBUG - 2012-10-23 18:35:10 --> Router Class Initialized
DEBUG - 2012-10-23 18:35:10 --> Output Class Initialized
DEBUG - 2012-10-23 18:35:10 --> Security Class Initialized
DEBUG - 2012-10-23 18:35:10 --> Input Class Initialized
DEBUG - 2012-10-23 18:35:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:35:10 --> Language Class Initialized
DEBUG - 2012-10-23 18:35:10 --> Loader Class Initialized
DEBUG - 2012-10-23 18:35:10 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:35:10 --> Controller Class Initialized
DEBUG - 2012-10-23 18:35:10 --> Model Class Initialized
DEBUG - 2012-10-23 18:35:10 --> Database Driver Class Initialized
DEBUG - 2012-10-23 18:35:10 --> Helper loaded: form_helper
DEBUG - 2012-10-23 18:35:10 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 18:35:10 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 18:35:10 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 18:35:10 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 18:35:10 --> Final output sent to browser
DEBUG - 2012-10-23 18:35:10 --> Total execution time: 0.0457
DEBUG - 2012-10-23 18:35:12 --> Config Class Initialized
DEBUG - 2012-10-23 18:35:12 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:35:12 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:35:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:35:12 --> URI Class Initialized
DEBUG - 2012-10-23 18:35:12 --> Router Class Initialized
ERROR - 2012-10-23 18:35:12 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:35:12 --> Config Class Initialized
DEBUG - 2012-10-23 18:35:12 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:35:12 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:35:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:35:12 --> URI Class Initialized
DEBUG - 2012-10-23 18:35:12 --> Router Class Initialized
ERROR - 2012-10-23 18:35:12 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:35:12 --> Config Class Initialized
DEBUG - 2012-10-23 18:35:12 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:35:12 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:35:12 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:35:12 --> URI Class Initialized
DEBUG - 2012-10-23 18:35:12 --> Router Class Initialized
ERROR - 2012-10-23 18:35:12 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:36:20 --> Config Class Initialized
DEBUG - 2012-10-23 18:36:20 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:36:20 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:36:20 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:36:20 --> URI Class Initialized
DEBUG - 2012-10-23 18:36:20 --> Router Class Initialized
DEBUG - 2012-10-23 18:36:20 --> Output Class Initialized
DEBUG - 2012-10-23 18:36:20 --> Security Class Initialized
DEBUG - 2012-10-23 18:36:20 --> Input Class Initialized
DEBUG - 2012-10-23 18:36:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:36:20 --> Language Class Initialized
DEBUG - 2012-10-23 18:36:20 --> Loader Class Initialized
DEBUG - 2012-10-23 18:36:20 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:36:20 --> Controller Class Initialized
DEBUG - 2012-10-23 18:36:20 --> Model Class Initialized
DEBUG - 2012-10-23 18:36:20 --> Database Driver Class Initialized
DEBUG - 2012-10-23 18:36:20 --> Helper loaded: form_helper
DEBUG - 2012-10-23 18:36:20 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 18:36:20 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 18:36:20 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 18:36:20 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 18:36:20 --> Final output sent to browser
DEBUG - 2012-10-23 18:36:20 --> Total execution time: 0.1874
DEBUG - 2012-10-23 18:36:22 --> Config Class Initialized
DEBUG - 2012-10-23 18:36:22 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:36:22 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:36:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:36:22 --> URI Class Initialized
DEBUG - 2012-10-23 18:36:22 --> Router Class Initialized
ERROR - 2012-10-23 18:36:22 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:36:22 --> Config Class Initialized
DEBUG - 2012-10-23 18:36:22 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:36:22 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:36:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:36:22 --> URI Class Initialized
DEBUG - 2012-10-23 18:36:22 --> Router Class Initialized
ERROR - 2012-10-23 18:36:22 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:36:22 --> Config Class Initialized
DEBUG - 2012-10-23 18:36:22 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:36:22 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:36:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:36:22 --> URI Class Initialized
DEBUG - 2012-10-23 18:36:22 --> Router Class Initialized
ERROR - 2012-10-23 18:36:22 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:37:40 --> Config Class Initialized
DEBUG - 2012-10-23 18:37:40 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:37:40 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:37:40 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:37:40 --> URI Class Initialized
DEBUG - 2012-10-23 18:37:40 --> Router Class Initialized
DEBUG - 2012-10-23 18:37:40 --> Output Class Initialized
DEBUG - 2012-10-23 18:37:40 --> Security Class Initialized
DEBUG - 2012-10-23 18:37:40 --> Input Class Initialized
DEBUG - 2012-10-23 18:37:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:37:40 --> Language Class Initialized
DEBUG - 2012-10-23 18:37:40 --> Loader Class Initialized
DEBUG - 2012-10-23 18:37:40 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:37:40 --> Controller Class Initialized
DEBUG - 2012-10-23 18:37:40 --> Model Class Initialized
DEBUG - 2012-10-23 18:37:40 --> Database Driver Class Initialized
DEBUG - 2012-10-23 18:37:40 --> Helper loaded: form_helper
DEBUG - 2012-10-23 18:37:40 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 18:37:40 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 18:37:40 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 18:37:40 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 18:37:40 --> Final output sent to browser
DEBUG - 2012-10-23 18:37:40 --> Total execution time: 0.0440
DEBUG - 2012-10-23 18:37:41 --> Config Class Initialized
DEBUG - 2012-10-23 18:37:41 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:37:41 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:37:41 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:37:41 --> URI Class Initialized
DEBUG - 2012-10-23 18:37:41 --> Router Class Initialized
ERROR - 2012-10-23 18:37:41 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:37:41 --> Config Class Initialized
DEBUG - 2012-10-23 18:37:41 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:37:41 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:37:41 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:37:41 --> URI Class Initialized
DEBUG - 2012-10-23 18:37:41 --> Router Class Initialized
ERROR - 2012-10-23 18:37:41 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:37:41 --> Config Class Initialized
DEBUG - 2012-10-23 18:37:41 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:37:41 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:37:41 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:37:42 --> URI Class Initialized
DEBUG - 2012-10-23 18:37:42 --> Router Class Initialized
ERROR - 2012-10-23 18:37:42 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:37:58 --> Config Class Initialized
DEBUG - 2012-10-23 18:37:58 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:37:58 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:37:58 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:37:58 --> URI Class Initialized
DEBUG - 2012-10-23 18:37:58 --> Router Class Initialized
DEBUG - 2012-10-23 18:37:58 --> Output Class Initialized
DEBUG - 2012-10-23 18:37:58 --> Security Class Initialized
DEBUG - 2012-10-23 18:37:58 --> Input Class Initialized
DEBUG - 2012-10-23 18:37:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:37:58 --> Language Class Initialized
DEBUG - 2012-10-23 18:37:58 --> Loader Class Initialized
DEBUG - 2012-10-23 18:37:58 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:37:58 --> Controller Class Initialized
DEBUG - 2012-10-23 18:37:58 --> Model Class Initialized
DEBUG - 2012-10-23 18:37:58 --> Database Driver Class Initialized
ERROR - 2012-10-23 18:37:58 --> 404 Page Not Found --> pricing/admin
DEBUG - 2012-10-23 18:39:42 --> Config Class Initialized
DEBUG - 2012-10-23 18:39:42 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:39:42 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:39:42 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:39:42 --> URI Class Initialized
DEBUG - 2012-10-23 18:39:42 --> Router Class Initialized
DEBUG - 2012-10-23 18:39:42 --> Output Class Initialized
DEBUG - 2012-10-23 18:39:42 --> Security Class Initialized
DEBUG - 2012-10-23 18:39:42 --> Input Class Initialized
DEBUG - 2012-10-23 18:39:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:39:42 --> Language Class Initialized
DEBUG - 2012-10-23 18:39:42 --> Loader Class Initialized
DEBUG - 2012-10-23 18:39:42 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:39:42 --> Controller Class Initialized
DEBUG - 2012-10-23 18:39:42 --> Model Class Initialized
DEBUG - 2012-10-23 18:39:42 --> Database Driver Class Initialized
DEBUG - 2012-10-23 18:39:42 --> Helper loaded: form_helper
DEBUG - 2012-10-23 18:39:42 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 18:39:42 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 18:39:42 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 18:39:42 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 18:39:42 --> Final output sent to browser
DEBUG - 2012-10-23 18:39:42 --> Total execution time: 0.0429
DEBUG - 2012-10-23 18:39:44 --> Config Class Initialized
DEBUG - 2012-10-23 18:39:44 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:39:44 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:39:44 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:39:44 --> URI Class Initialized
DEBUG - 2012-10-23 18:39:44 --> Router Class Initialized
ERROR - 2012-10-23 18:39:44 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:39:44 --> Config Class Initialized
DEBUG - 2012-10-23 18:39:44 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:39:44 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:39:44 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:39:44 --> URI Class Initialized
DEBUG - 2012-10-23 18:39:44 --> Router Class Initialized
ERROR - 2012-10-23 18:39:44 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:39:44 --> Config Class Initialized
DEBUG - 2012-10-23 18:39:44 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:39:44 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:39:44 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:39:44 --> URI Class Initialized
DEBUG - 2012-10-23 18:39:44 --> Router Class Initialized
ERROR - 2012-10-23 18:39:44 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:39:55 --> Config Class Initialized
DEBUG - 2012-10-23 18:39:55 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:39:55 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:39:55 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:39:55 --> URI Class Initialized
DEBUG - 2012-10-23 18:39:55 --> Router Class Initialized
DEBUG - 2012-10-23 18:39:55 --> Output Class Initialized
DEBUG - 2012-10-23 18:39:55 --> Security Class Initialized
DEBUG - 2012-10-23 18:39:55 --> Input Class Initialized
DEBUG - 2012-10-23 18:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:39:55 --> Language Class Initialized
DEBUG - 2012-10-23 18:39:55 --> Loader Class Initialized
DEBUG - 2012-10-23 18:39:55 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:39:55 --> Controller Class Initialized
DEBUG - 2012-10-23 18:39:55 --> Model Class Initialized
DEBUG - 2012-10-23 18:39:55 --> Database Driver Class Initialized
DEBUG - 2012-10-23 18:39:55 --> Helper loaded: language_helper
DEBUG - 2012-10-23 18:39:55 --> Language file loaded: language/english/message_lang.php
ERROR - 2012-10-23 18:39:55 --> Severity: Notice  --> Undefined property: Pricing::$business_model /home/jwp/www/justinwylliephotography.com/clients/application/controllers/admin/pricing.php 604
DEBUG - 2012-10-23 18:41:21 --> Config Class Initialized
DEBUG - 2012-10-23 18:41:21 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:41:21 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:41:21 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:41:21 --> URI Class Initialized
DEBUG - 2012-10-23 18:41:21 --> Router Class Initialized
DEBUG - 2012-10-23 18:41:21 --> Output Class Initialized
DEBUG - 2012-10-23 18:41:21 --> Security Class Initialized
DEBUG - 2012-10-23 18:41:21 --> Input Class Initialized
DEBUG - 2012-10-23 18:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:41:21 --> Language Class Initialized
DEBUG - 2012-10-23 18:41:21 --> Loader Class Initialized
DEBUG - 2012-10-23 18:41:21 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:41:21 --> Controller Class Initialized
DEBUG - 2012-10-23 18:41:21 --> Model Class Initialized
DEBUG - 2012-10-23 18:41:21 --> Database Driver Class Initialized
DEBUG - 2012-10-23 18:41:21 --> Helper loaded: form_helper
DEBUG - 2012-10-23 18:41:21 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 18:41:21 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 18:41:21 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 18:41:21 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 18:41:21 --> Final output sent to browser
DEBUG - 2012-10-23 18:41:21 --> Total execution time: 0.0441
DEBUG - 2012-10-23 18:41:23 --> Config Class Initialized
DEBUG - 2012-10-23 18:41:23 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:41:23 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:41:23 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:41:23 --> URI Class Initialized
DEBUG - 2012-10-23 18:41:23 --> Router Class Initialized
ERROR - 2012-10-23 18:41:23 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:41:23 --> Config Class Initialized
DEBUG - 2012-10-23 18:41:23 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:41:23 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:41:23 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:41:23 --> URI Class Initialized
DEBUG - 2012-10-23 18:41:23 --> Router Class Initialized
ERROR - 2012-10-23 18:41:23 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:41:23 --> Config Class Initialized
DEBUG - 2012-10-23 18:41:23 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:41:23 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:41:23 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:41:23 --> URI Class Initialized
DEBUG - 2012-10-23 18:41:23 --> Router Class Initialized
ERROR - 2012-10-23 18:41:23 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:41:27 --> Config Class Initialized
DEBUG - 2012-10-23 18:41:27 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:41:27 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:41:27 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:41:27 --> URI Class Initialized
DEBUG - 2012-10-23 18:41:27 --> Router Class Initialized
DEBUG - 2012-10-23 18:41:27 --> Output Class Initialized
DEBUG - 2012-10-23 18:41:27 --> Security Class Initialized
DEBUG - 2012-10-23 18:41:27 --> Input Class Initialized
DEBUG - 2012-10-23 18:41:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:41:27 --> Language Class Initialized
DEBUG - 2012-10-23 18:41:27 --> Loader Class Initialized
DEBUG - 2012-10-23 18:41:27 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:41:27 --> Controller Class Initialized
DEBUG - 2012-10-23 18:41:27 --> Model Class Initialized
DEBUG - 2012-10-23 18:41:27 --> Database Driver Class Initialized
DEBUG - 2012-10-23 18:41:27 --> Helper loaded: language_helper
DEBUG - 2012-10-23 18:41:27 --> Language file loaded: language/english/message_lang.php
ERROR - 2012-10-23 18:41:27 --> Severity: Notice  --> Undefined property: Pricing::$business_model /home/jwp/www/justinwylliephotography.com/clients/application/controllers/admin/pricing.php 605
DEBUG - 2012-10-23 18:42:22 --> Config Class Initialized
DEBUG - 2012-10-23 18:42:22 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:42:22 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:42:22 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:42:22 --> URI Class Initialized
DEBUG - 2012-10-23 18:42:22 --> Router Class Initialized
DEBUG - 2012-10-23 18:42:22 --> Output Class Initialized
DEBUG - 2012-10-23 18:42:22 --> Security Class Initialized
DEBUG - 2012-10-23 18:42:22 --> Input Class Initialized
DEBUG - 2012-10-23 18:42:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:42:22 --> Language Class Initialized
DEBUG - 2012-10-23 18:42:22 --> Loader Class Initialized
DEBUG - 2012-10-23 18:42:22 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:42:22 --> Controller Class Initialized
DEBUG - 2012-10-23 18:42:22 --> Model Class Initialized
DEBUG - 2012-10-23 18:42:22 --> Database Driver Class Initialized
DEBUG - 2012-10-23 18:42:22 --> Helper loaded: language_helper
DEBUG - 2012-10-23 18:42:22 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-23 18:42:22 --> Final output sent to browser
DEBUG - 2012-10-23 18:42:22 --> Total execution time: 0.1157
DEBUG - 2012-10-23 18:42:46 --> Config Class Initialized
DEBUG - 2012-10-23 18:42:46 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:42:46 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:42:46 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:42:46 --> URI Class Initialized
DEBUG - 2012-10-23 18:42:46 --> Router Class Initialized
DEBUG - 2012-10-23 18:42:46 --> Output Class Initialized
DEBUG - 2012-10-23 18:42:46 --> Security Class Initialized
DEBUG - 2012-10-23 18:42:46 --> Input Class Initialized
DEBUG - 2012-10-23 18:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:42:46 --> Language Class Initialized
DEBUG - 2012-10-23 18:42:46 --> Loader Class Initialized
DEBUG - 2012-10-23 18:42:46 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:42:46 --> Controller Class Initialized
DEBUG - 2012-10-23 18:42:46 --> Model Class Initialized
DEBUG - 2012-10-23 18:42:46 --> Database Driver Class Initialized
DEBUG - 2012-10-23 18:42:46 --> Helper loaded: form_helper
ERROR - 2012-10-23 18:42:46 --> Severity: Notice  --> Undefined property: Pricing::$business_model /home/jwp/www/justinwylliephotography.com/clients/application/controllers/admin/pricing.php 81
DEBUG - 2012-10-23 18:44:02 --> Config Class Initialized
DEBUG - 2012-10-23 18:44:02 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:44:02 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:44:02 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:44:02 --> URI Class Initialized
DEBUG - 2012-10-23 18:44:02 --> Router Class Initialized
DEBUG - 2012-10-23 18:44:02 --> Output Class Initialized
DEBUG - 2012-10-23 18:44:02 --> Security Class Initialized
DEBUG - 2012-10-23 18:44:02 --> Input Class Initialized
DEBUG - 2012-10-23 18:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:44:02 --> Language Class Initialized
DEBUG - 2012-10-23 18:44:02 --> Loader Class Initialized
DEBUG - 2012-10-23 18:44:02 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:44:02 --> Controller Class Initialized
DEBUG - 2012-10-23 18:44:02 --> Model Class Initialized
DEBUG - 2012-10-23 18:44:02 --> Database Driver Class Initialized
DEBUG - 2012-10-23 18:44:02 --> Helper loaded: form_helper
DEBUG - 2012-10-23 18:44:02 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 18:44:02 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 18:44:02 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 18:44:02 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 18:44:02 --> Final output sent to browser
DEBUG - 2012-10-23 18:44:02 --> Total execution time: 0.0414
DEBUG - 2012-10-23 18:44:04 --> Config Class Initialized
DEBUG - 2012-10-23 18:44:04 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:44:04 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:44:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:44:04 --> URI Class Initialized
DEBUG - 2012-10-23 18:44:04 --> Router Class Initialized
ERROR - 2012-10-23 18:44:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:44:04 --> Config Class Initialized
DEBUG - 2012-10-23 18:44:04 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:44:04 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:44:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:44:04 --> URI Class Initialized
DEBUG - 2012-10-23 18:44:04 --> Router Class Initialized
ERROR - 2012-10-23 18:44:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:44:04 --> Config Class Initialized
DEBUG - 2012-10-23 18:44:04 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:44:04 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:44:04 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:44:04 --> URI Class Initialized
DEBUG - 2012-10-23 18:44:04 --> Router Class Initialized
ERROR - 2012-10-23 18:44:04 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:44:43 --> Config Class Initialized
DEBUG - 2012-10-23 18:44:43 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:44:43 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:44:43 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:44:43 --> URI Class Initialized
DEBUG - 2012-10-23 18:44:43 --> Router Class Initialized
DEBUG - 2012-10-23 18:44:43 --> Output Class Initialized
DEBUG - 2012-10-23 18:44:43 --> Security Class Initialized
DEBUG - 2012-10-23 18:44:43 --> Input Class Initialized
DEBUG - 2012-10-23 18:44:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:44:43 --> Language Class Initialized
DEBUG - 2012-10-23 18:44:43 --> Loader Class Initialized
DEBUG - 2012-10-23 18:44:43 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:44:43 --> Controller Class Initialized
DEBUG - 2012-10-23 18:44:43 --> Model Class Initialized
DEBUG - 2012-10-23 18:44:43 --> Database Driver Class Initialized
DEBUG - 2012-10-23 18:44:43 --> Helper loaded: form_helper
DEBUG - 2012-10-23 18:44:43 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 18:44:43 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 18:44:43 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 18:44:43 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 18:44:43 --> Final output sent to browser
DEBUG - 2012-10-23 18:44:43 --> Total execution time: 0.0578
DEBUG - 2012-10-23 18:44:45 --> Config Class Initialized
DEBUG - 2012-10-23 18:44:45 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:44:45 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:44:45 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:44:45 --> URI Class Initialized
DEBUG - 2012-10-23 18:44:45 --> Router Class Initialized
ERROR - 2012-10-23 18:44:45 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:44:45 --> Config Class Initialized
DEBUG - 2012-10-23 18:44:45 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:44:45 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:44:45 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:44:45 --> URI Class Initialized
DEBUG - 2012-10-23 18:44:45 --> Router Class Initialized
ERROR - 2012-10-23 18:44:45 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:44:45 --> Config Class Initialized
DEBUG - 2012-10-23 18:44:45 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:44:45 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:44:45 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:44:45 --> URI Class Initialized
DEBUG - 2012-10-23 18:44:45 --> Router Class Initialized
ERROR - 2012-10-23 18:44:45 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:45:48 --> Config Class Initialized
DEBUG - 2012-10-23 18:45:48 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:45:48 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:45:48 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:45:48 --> URI Class Initialized
DEBUG - 2012-10-23 18:45:48 --> Router Class Initialized
DEBUG - 2012-10-23 18:45:48 --> Output Class Initialized
DEBUG - 2012-10-23 18:45:48 --> Security Class Initialized
DEBUG - 2012-10-23 18:45:48 --> Input Class Initialized
DEBUG - 2012-10-23 18:45:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:45:48 --> Language Class Initialized
DEBUG - 2012-10-23 18:45:48 --> Loader Class Initialized
DEBUG - 2012-10-23 18:45:48 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:45:48 --> Controller Class Initialized
DEBUG - 2012-10-23 18:45:48 --> Model Class Initialized
DEBUG - 2012-10-23 18:45:48 --> Database Driver Class Initialized
DEBUG - 2012-10-23 18:45:48 --> Helper loaded: form_helper
DEBUG - 2012-10-23 18:45:48 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 18:45:48 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 18:45:48 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 18:45:48 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 18:45:48 --> Final output sent to browser
DEBUG - 2012-10-23 18:45:48 --> Total execution time: 0.0414
DEBUG - 2012-10-23 18:45:50 --> Config Class Initialized
DEBUG - 2012-10-23 18:45:50 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:45:50 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:45:50 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:45:50 --> URI Class Initialized
DEBUG - 2012-10-23 18:45:50 --> Router Class Initialized
ERROR - 2012-10-23 18:45:50 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:45:50 --> Config Class Initialized
DEBUG - 2012-10-23 18:45:50 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:45:50 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:45:50 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:45:50 --> URI Class Initialized
DEBUG - 2012-10-23 18:45:50 --> Router Class Initialized
ERROR - 2012-10-23 18:45:50 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:45:50 --> Config Class Initialized
DEBUG - 2012-10-23 18:45:50 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:45:50 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:45:50 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:45:50 --> URI Class Initialized
DEBUG - 2012-10-23 18:45:50 --> Router Class Initialized
ERROR - 2012-10-23 18:45:50 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:46:07 --> Config Class Initialized
DEBUG - 2012-10-23 18:46:07 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:46:07 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:46:07 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:46:07 --> URI Class Initialized
DEBUG - 2012-10-23 18:46:07 --> Router Class Initialized
DEBUG - 2012-10-23 18:46:07 --> Output Class Initialized
DEBUG - 2012-10-23 18:46:07 --> Security Class Initialized
DEBUG - 2012-10-23 18:46:07 --> Input Class Initialized
DEBUG - 2012-10-23 18:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:46:07 --> Language Class Initialized
DEBUG - 2012-10-23 18:46:07 --> Loader Class Initialized
DEBUG - 2012-10-23 18:46:07 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:46:07 --> Controller Class Initialized
DEBUG - 2012-10-23 18:46:07 --> Model Class Initialized
DEBUG - 2012-10-23 18:46:07 --> Database Driver Class Initialized
DEBUG - 2012-10-23 18:46:07 --> Helper loaded: language_helper
DEBUG - 2012-10-23 18:46:07 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-23 18:46:07 --> Final output sent to browser
DEBUG - 2012-10-23 18:46:07 --> Total execution time: 0.1251
DEBUG - 2012-10-23 18:46:11 --> Config Class Initialized
DEBUG - 2012-10-23 18:46:11 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:46:11 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:46:11 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:46:11 --> URI Class Initialized
DEBUG - 2012-10-23 18:46:11 --> Router Class Initialized
DEBUG - 2012-10-23 18:46:11 --> Output Class Initialized
DEBUG - 2012-10-23 18:46:11 --> Security Class Initialized
DEBUG - 2012-10-23 18:46:11 --> Input Class Initialized
DEBUG - 2012-10-23 18:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:46:11 --> Language Class Initialized
DEBUG - 2012-10-23 18:46:11 --> Loader Class Initialized
DEBUG - 2012-10-23 18:46:11 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:46:11 --> Controller Class Initialized
DEBUG - 2012-10-23 18:46:11 --> Model Class Initialized
DEBUG - 2012-10-23 18:46:11 --> Database Driver Class Initialized
DEBUG - 2012-10-23 18:46:11 --> Helper loaded: form_helper
DEBUG - 2012-10-23 18:46:11 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 18:46:11 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 18:46:11 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 18:46:11 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 18:46:11 --> Final output sent to browser
DEBUG - 2012-10-23 18:46:11 --> Total execution time: 0.0485
DEBUG - 2012-10-23 18:46:13 --> Config Class Initialized
DEBUG - 2012-10-23 18:46:13 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:46:13 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:46:13 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:46:13 --> URI Class Initialized
DEBUG - 2012-10-23 18:46:13 --> Router Class Initialized
ERROR - 2012-10-23 18:46:13 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:46:13 --> Config Class Initialized
DEBUG - 2012-10-23 18:46:13 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:46:13 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:46:13 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:46:13 --> URI Class Initialized
DEBUG - 2012-10-23 18:46:13 --> Router Class Initialized
ERROR - 2012-10-23 18:46:13 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:46:13 --> Config Class Initialized
DEBUG - 2012-10-23 18:46:13 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:46:13 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:46:13 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:46:13 --> URI Class Initialized
DEBUG - 2012-10-23 18:46:13 --> Router Class Initialized
ERROR - 2012-10-23 18:46:13 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:46:17 --> Config Class Initialized
DEBUG - 2012-10-23 18:46:17 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:46:17 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:46:17 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:46:17 --> URI Class Initialized
DEBUG - 2012-10-23 18:46:17 --> Router Class Initialized
DEBUG - 2012-10-23 18:46:17 --> Output Class Initialized
DEBUG - 2012-10-23 18:46:17 --> Security Class Initialized
DEBUG - 2012-10-23 18:46:17 --> Input Class Initialized
DEBUG - 2012-10-23 18:46:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:46:17 --> Language Class Initialized
DEBUG - 2012-10-23 18:46:17 --> Loader Class Initialized
DEBUG - 2012-10-23 18:46:17 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:46:17 --> Controller Class Initialized
DEBUG - 2012-10-23 18:46:17 --> Model Class Initialized
DEBUG - 2012-10-23 18:46:17 --> Database Driver Class Initialized
DEBUG - 2012-10-23 18:46:17 --> Helper loaded: language_helper
DEBUG - 2012-10-23 18:46:17 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-10-23 18:46:17 --> Final output sent to browser
DEBUG - 2012-10-23 18:46:17 --> Total execution time: 0.0647
DEBUG - 2012-10-23 18:46:24 --> Config Class Initialized
DEBUG - 2012-10-23 18:46:24 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:46:24 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:46:24 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:46:24 --> URI Class Initialized
DEBUG - 2012-10-23 18:46:24 --> Router Class Initialized
DEBUG - 2012-10-23 18:46:24 --> Output Class Initialized
DEBUG - 2012-10-23 18:46:24 --> Security Class Initialized
DEBUG - 2012-10-23 18:46:24 --> Input Class Initialized
DEBUG - 2012-10-23 18:46:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-10-23 18:46:24 --> Language Class Initialized
DEBUG - 2012-10-23 18:46:24 --> Loader Class Initialized
DEBUG - 2012-10-23 18:46:24 --> Helper loaded: url_helper
DEBUG - 2012-10-23 18:46:24 --> Controller Class Initialized
DEBUG - 2012-10-23 18:46:24 --> Model Class Initialized
DEBUG - 2012-10-23 18:46:24 --> Database Driver Class Initialized
DEBUG - 2012-10-23 18:46:24 --> Helper loaded: form_helper
DEBUG - 2012-10-23 18:46:24 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-10-23 18:46:24 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-10-23 18:46:24 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-10-23 18:46:24 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-10-23 18:46:24 --> Final output sent to browser
DEBUG - 2012-10-23 18:46:24 --> Total execution time: 0.0427
DEBUG - 2012-10-23 18:46:26 --> Config Class Initialized
DEBUG - 2012-10-23 18:46:26 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:46:26 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:46:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:46:26 --> URI Class Initialized
DEBUG - 2012-10-23 18:46:26 --> Router Class Initialized
ERROR - 2012-10-23 18:46:26 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:46:26 --> Config Class Initialized
DEBUG - 2012-10-23 18:46:26 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:46:26 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:46:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:46:26 --> URI Class Initialized
DEBUG - 2012-10-23 18:46:26 --> Router Class Initialized
ERROR - 2012-10-23 18:46:26 --> 404 Page Not Found --> css
DEBUG - 2012-10-23 18:46:26 --> Config Class Initialized
DEBUG - 2012-10-23 18:46:26 --> Hooks Class Initialized
DEBUG - 2012-10-23 18:46:26 --> Utf8 Class Initialized
DEBUG - 2012-10-23 18:46:26 --> UTF-8 Support Enabled
DEBUG - 2012-10-23 18:46:26 --> URI Class Initialized
DEBUG - 2012-10-23 18:46:26 --> Router Class Initialized
ERROR - 2012-10-23 18:46:26 --> 404 Page Not Found --> css
