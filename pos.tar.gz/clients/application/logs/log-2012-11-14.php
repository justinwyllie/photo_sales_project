<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-11-14 21:40:29 --> Config Class Initialized
DEBUG - 2012-11-14 21:40:29 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:40:29 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:40:29 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:40:29 --> URI Class Initialized
DEBUG - 2012-11-14 21:40:29 --> Router Class Initialized
DEBUG - 2012-11-14 21:40:29 --> Output Class Initialized
DEBUG - 2012-11-14 21:40:29 --> Security Class Initialized
DEBUG - 2012-11-14 21:40:29 --> Input Class Initialized
DEBUG - 2012-11-14 21:40:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 21:40:29 --> Language Class Initialized
DEBUG - 2012-11-14 21:40:30 --> Loader Class Initialized
DEBUG - 2012-11-14 21:40:30 --> Helper loaded: url_helper
DEBUG - 2012-11-14 21:40:30 --> Controller Class Initialized
DEBUG - 2012-11-14 21:40:30 --> Model Class Initialized
DEBUG - 2012-11-14 21:40:30 --> Database Driver Class Initialized
DEBUG - 2012-11-14 21:40:30 --> Helper loaded: form_helper
DEBUG - 2012-11-14 21:40:30 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-14 21:40:30 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-11-14 21:40:30 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-14 21:40:30 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-11-14 21:40:30 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-14 21:40:30 --> Final output sent to browser
DEBUG - 2012-11-14 21:40:30 --> Total execution time: 0.7517
DEBUG - 2012-11-14 21:40:32 --> Config Class Initialized
DEBUG - 2012-11-14 21:40:32 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:40:32 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:40:32 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:40:32 --> URI Class Initialized
DEBUG - 2012-11-14 21:40:32 --> Router Class Initialized
ERROR - 2012-11-14 21:40:32 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 21:40:32 --> Config Class Initialized
DEBUG - 2012-11-14 21:40:32 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:40:32 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:40:32 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:40:32 --> URI Class Initialized
DEBUG - 2012-11-14 21:40:32 --> Router Class Initialized
ERROR - 2012-11-14 21:40:32 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 21:40:32 --> Config Class Initialized
DEBUG - 2012-11-14 21:40:32 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:40:32 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:40:32 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:40:32 --> URI Class Initialized
DEBUG - 2012-11-14 21:40:32 --> Router Class Initialized
ERROR - 2012-11-14 21:40:32 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 21:43:42 --> Config Class Initialized
DEBUG - 2012-11-14 21:43:42 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:43:42 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:43:42 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:43:42 --> URI Class Initialized
DEBUG - 2012-11-14 21:43:42 --> Router Class Initialized
DEBUG - 2012-11-14 21:43:42 --> Output Class Initialized
DEBUG - 2012-11-14 21:43:42 --> Security Class Initialized
DEBUG - 2012-11-14 21:43:42 --> Input Class Initialized
DEBUG - 2012-11-14 21:43:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 21:43:42 --> Language Class Initialized
DEBUG - 2012-11-14 21:43:42 --> Loader Class Initialized
DEBUG - 2012-11-14 21:43:42 --> Helper loaded: url_helper
DEBUG - 2012-11-14 21:43:42 --> Controller Class Initialized
DEBUG - 2012-11-14 21:43:42 --> Model Class Initialized
DEBUG - 2012-11-14 21:43:42 --> Database Driver Class Initialized
DEBUG - 2012-11-14 21:43:42 --> Helper loaded: form_helper
DEBUG - 2012-11-14 21:43:42 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-14 21:43:42 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-14 21:43:42 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-11-14 21:43:42 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-14 21:43:42 --> Final output sent to browser
DEBUG - 2012-11-14 21:43:42 --> Total execution time: 0.1491
DEBUG - 2012-11-14 21:43:52 --> Config Class Initialized
DEBUG - 2012-11-14 21:43:52 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:43:52 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:43:52 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:43:52 --> URI Class Initialized
DEBUG - 2012-11-14 21:43:52 --> Router Class Initialized
DEBUG - 2012-11-14 21:43:52 --> Output Class Initialized
DEBUG - 2012-11-14 21:43:52 --> Security Class Initialized
DEBUG - 2012-11-14 21:43:52 --> Input Class Initialized
DEBUG - 2012-11-14 21:43:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 21:43:52 --> Language Class Initialized
DEBUG - 2012-11-14 21:43:52 --> Loader Class Initialized
DEBUG - 2012-11-14 21:43:52 --> Helper loaded: url_helper
DEBUG - 2012-11-14 21:43:52 --> Controller Class Initialized
DEBUG - 2012-11-14 21:43:52 --> Model Class Initialized
DEBUG - 2012-11-14 21:43:52 --> Database Driver Class Initialized
DEBUG - 2012-11-14 21:43:52 --> Helper loaded: language_helper
DEBUG - 2012-11-14 21:43:52 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-11-14 21:43:52 --> Final output sent to browser
DEBUG - 2012-11-14 21:43:52 --> Total execution time: 0.0603
DEBUG - 2012-11-14 21:45:03 --> Config Class Initialized
DEBUG - 2012-11-14 21:45:03 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:45:03 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:45:03 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:45:03 --> URI Class Initialized
DEBUG - 2012-11-14 21:45:03 --> Router Class Initialized
DEBUG - 2012-11-14 21:45:03 --> Output Class Initialized
DEBUG - 2012-11-14 21:45:03 --> Security Class Initialized
DEBUG - 2012-11-14 21:45:03 --> Input Class Initialized
DEBUG - 2012-11-14 21:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 21:45:03 --> Language Class Initialized
DEBUG - 2012-11-14 21:45:03 --> Loader Class Initialized
DEBUG - 2012-11-14 21:45:03 --> Helper loaded: url_helper
DEBUG - 2012-11-14 21:45:03 --> Controller Class Initialized
DEBUG - 2012-11-14 21:45:03 --> Model Class Initialized
DEBUG - 2012-11-14 21:45:03 --> Database Driver Class Initialized
DEBUG - 2012-11-14 21:45:03 --> Helper loaded: form_helper
DEBUG - 2012-11-14 21:45:03 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-14 21:45:03 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-14 21:45:03 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-11-14 21:45:03 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-14 21:45:03 --> Final output sent to browser
DEBUG - 2012-11-14 21:45:03 --> Total execution time: 0.0650
DEBUG - 2012-11-14 21:45:08 --> Config Class Initialized
DEBUG - 2012-11-14 21:45:08 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:45:08 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:45:08 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:45:08 --> URI Class Initialized
DEBUG - 2012-11-14 21:45:08 --> Router Class Initialized
DEBUG - 2012-11-14 21:45:08 --> Output Class Initialized
DEBUG - 2012-11-14 21:45:08 --> Security Class Initialized
DEBUG - 2012-11-14 21:45:08 --> Input Class Initialized
DEBUG - 2012-11-14 21:45:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 21:45:08 --> Language Class Initialized
DEBUG - 2012-11-14 21:45:08 --> Loader Class Initialized
DEBUG - 2012-11-14 21:45:08 --> Helper loaded: url_helper
DEBUG - 2012-11-14 21:45:08 --> Controller Class Initialized
DEBUG - 2012-11-14 21:45:08 --> Model Class Initialized
DEBUG - 2012-11-14 21:45:08 --> Database Driver Class Initialized
DEBUG - 2012-11-14 21:45:08 --> Helper loaded: form_helper
DEBUG - 2012-11-14 21:45:08 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-14 21:45:08 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-14 21:45:08 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-11-14 21:45:08 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-14 21:45:08 --> Final output sent to browser
DEBUG - 2012-11-14 21:45:08 --> Total execution time: 0.0537
DEBUG - 2012-11-14 21:45:13 --> Config Class Initialized
DEBUG - 2012-11-14 21:45:13 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:45:13 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:45:13 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:45:13 --> URI Class Initialized
DEBUG - 2012-11-14 21:45:13 --> Router Class Initialized
DEBUG - 2012-11-14 21:45:13 --> Output Class Initialized
DEBUG - 2012-11-14 21:45:13 --> Security Class Initialized
DEBUG - 2012-11-14 21:45:13 --> Input Class Initialized
DEBUG - 2012-11-14 21:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 21:45:13 --> Language Class Initialized
DEBUG - 2012-11-14 21:45:13 --> Loader Class Initialized
DEBUG - 2012-11-14 21:45:13 --> Helper loaded: url_helper
DEBUG - 2012-11-14 21:45:13 --> Controller Class Initialized
DEBUG - 2012-11-14 21:45:13 --> Model Class Initialized
DEBUG - 2012-11-14 21:45:13 --> Database Driver Class Initialized
DEBUG - 2012-11-14 21:45:13 --> Final output sent to browser
DEBUG - 2012-11-14 21:45:13 --> Total execution time: 0.1048
DEBUG - 2012-11-14 21:45:22 --> Config Class Initialized
DEBUG - 2012-11-14 21:45:22 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:45:22 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:45:22 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:45:22 --> URI Class Initialized
DEBUG - 2012-11-14 21:45:22 --> Router Class Initialized
DEBUG - 2012-11-14 21:45:22 --> Output Class Initialized
DEBUG - 2012-11-14 21:45:22 --> Security Class Initialized
DEBUG - 2012-11-14 21:45:22 --> Input Class Initialized
DEBUG - 2012-11-14 21:45:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 21:45:22 --> Language Class Initialized
DEBUG - 2012-11-14 21:45:22 --> Loader Class Initialized
DEBUG - 2012-11-14 21:45:22 --> Helper loaded: url_helper
DEBUG - 2012-11-14 21:45:22 --> Controller Class Initialized
DEBUG - 2012-11-14 21:45:22 --> Model Class Initialized
DEBUG - 2012-11-14 21:45:22 --> Database Driver Class Initialized
DEBUG - 2012-11-14 21:45:22 --> Helper loaded: form_helper
DEBUG - 2012-11-14 21:45:22 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-14 21:45:22 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-14 21:45:22 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-14 21:45:22 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-14 21:45:22 --> Final output sent to browser
DEBUG - 2012-11-14 21:45:22 --> Total execution time: 0.1893
DEBUG - 2012-11-14 21:46:36 --> Config Class Initialized
DEBUG - 2012-11-14 21:46:36 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:46:36 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:46:36 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:46:36 --> URI Class Initialized
DEBUG - 2012-11-14 21:46:36 --> Router Class Initialized
DEBUG - 2012-11-14 21:46:36 --> Output Class Initialized
DEBUG - 2012-11-14 21:46:36 --> Security Class Initialized
DEBUG - 2012-11-14 21:46:36 --> Input Class Initialized
DEBUG - 2012-11-14 21:46:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 21:46:36 --> Language Class Initialized
DEBUG - 2012-11-14 21:46:36 --> Loader Class Initialized
DEBUG - 2012-11-14 21:46:36 --> Helper loaded: url_helper
DEBUG - 2012-11-14 21:46:36 --> Controller Class Initialized
DEBUG - 2012-11-14 21:46:36 --> Model Class Initialized
DEBUG - 2012-11-14 21:46:36 --> Database Driver Class Initialized
DEBUG - 2012-11-14 21:46:36 --> Helper loaded: form_helper
DEBUG - 2012-11-14 21:46:36 --> Form Validation Class Initialized
ERROR - 2012-11-14 21:46:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/libraries/Prices.php 25
DEBUG - 2012-11-14 21:46:36 --> Final output sent to browser
DEBUG - 2012-11-14 21:46:36 --> Total execution time: 0.0605
DEBUG - 2012-11-14 21:46:50 --> Config Class Initialized
DEBUG - 2012-11-14 21:46:50 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:46:50 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:46:50 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:46:50 --> URI Class Initialized
DEBUG - 2012-11-14 21:46:50 --> Router Class Initialized
DEBUG - 2012-11-14 21:46:50 --> Output Class Initialized
DEBUG - 2012-11-14 21:46:50 --> Security Class Initialized
DEBUG - 2012-11-14 21:46:50 --> Input Class Initialized
DEBUG - 2012-11-14 21:46:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 21:46:50 --> Language Class Initialized
DEBUG - 2012-11-14 21:46:50 --> Loader Class Initialized
DEBUG - 2012-11-14 21:46:50 --> Helper loaded: url_helper
DEBUG - 2012-11-14 21:46:50 --> Controller Class Initialized
DEBUG - 2012-11-14 21:46:50 --> Model Class Initialized
DEBUG - 2012-11-14 21:46:50 --> Database Driver Class Initialized
DEBUG - 2012-11-14 21:46:50 --> Helper loaded: form_helper
DEBUG - 2012-11-14 21:46:50 --> Form Validation Class Initialized
ERROR - 2012-11-14 21:46:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/libraries/Prices.php 25
DEBUG - 2012-11-14 21:46:50 --> Final output sent to browser
DEBUG - 2012-11-14 21:46:50 --> Total execution time: 0.0404
DEBUG - 2012-11-14 21:50:32 --> Config Class Initialized
DEBUG - 2012-11-14 21:50:32 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:50:32 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:50:32 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:50:32 --> URI Class Initialized
DEBUG - 2012-11-14 21:50:32 --> Router Class Initialized
DEBUG - 2012-11-14 21:50:32 --> Output Class Initialized
DEBUG - 2012-11-14 21:50:32 --> Security Class Initialized
DEBUG - 2012-11-14 21:50:32 --> Input Class Initialized
DEBUG - 2012-11-14 21:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 21:50:32 --> Language Class Initialized
DEBUG - 2012-11-14 21:50:32 --> Loader Class Initialized
DEBUG - 2012-11-14 21:50:32 --> Helper loaded: url_helper
DEBUG - 2012-11-14 21:50:32 --> Controller Class Initialized
DEBUG - 2012-11-14 21:50:32 --> Model Class Initialized
DEBUG - 2012-11-14 21:50:32 --> Database Driver Class Initialized
DEBUG - 2012-11-14 21:50:32 --> Helper loaded: form_helper
DEBUG - 2012-11-14 21:51:37 --> Config Class Initialized
DEBUG - 2012-11-14 21:51:37 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:51:37 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:51:37 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:51:37 --> URI Class Initialized
DEBUG - 2012-11-14 21:51:37 --> Router Class Initialized
DEBUG - 2012-11-14 21:51:37 --> Output Class Initialized
DEBUG - 2012-11-14 21:51:37 --> Security Class Initialized
DEBUG - 2012-11-14 21:51:37 --> Input Class Initialized
DEBUG - 2012-11-14 21:51:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 21:51:37 --> Language Class Initialized
DEBUG - 2012-11-14 21:51:37 --> Loader Class Initialized
DEBUG - 2012-11-14 21:51:37 --> Helper loaded: url_helper
DEBUG - 2012-11-14 21:51:37 --> Controller Class Initialized
DEBUG - 2012-11-14 21:51:37 --> Model Class Initialized
DEBUG - 2012-11-14 21:51:37 --> Database Driver Class Initialized
DEBUG - 2012-11-14 21:51:37 --> Helper loaded: form_helper
DEBUG - 2012-11-14 21:52:19 --> Config Class Initialized
DEBUG - 2012-11-14 21:52:19 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:52:19 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:52:19 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:52:19 --> URI Class Initialized
DEBUG - 2012-11-14 21:52:19 --> Router Class Initialized
DEBUG - 2012-11-14 21:52:19 --> Output Class Initialized
DEBUG - 2012-11-14 21:52:19 --> Security Class Initialized
DEBUG - 2012-11-14 21:52:19 --> Input Class Initialized
DEBUG - 2012-11-14 21:52:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 21:52:19 --> Language Class Initialized
DEBUG - 2012-11-14 21:52:19 --> Loader Class Initialized
DEBUG - 2012-11-14 21:52:19 --> Helper loaded: url_helper
DEBUG - 2012-11-14 21:52:19 --> Controller Class Initialized
DEBUG - 2012-11-14 21:52:19 --> Model Class Initialized
DEBUG - 2012-11-14 21:52:19 --> Database Driver Class Initialized
DEBUG - 2012-11-14 21:52:19 --> Helper loaded: form_helper
DEBUG - 2012-11-14 21:53:51 --> Config Class Initialized
DEBUG - 2012-11-14 21:53:51 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:53:51 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:53:51 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:53:51 --> URI Class Initialized
DEBUG - 2012-11-14 21:53:51 --> Router Class Initialized
DEBUG - 2012-11-14 21:53:51 --> Output Class Initialized
DEBUG - 2012-11-14 21:53:51 --> Security Class Initialized
DEBUG - 2012-11-14 21:53:51 --> Input Class Initialized
DEBUG - 2012-11-14 21:53:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 21:53:51 --> Language Class Initialized
DEBUG - 2012-11-14 21:53:51 --> Loader Class Initialized
DEBUG - 2012-11-14 21:53:51 --> Helper loaded: url_helper
DEBUG - 2012-11-14 21:53:51 --> Controller Class Initialized
DEBUG - 2012-11-14 21:53:51 --> Model Class Initialized
DEBUG - 2012-11-14 21:53:51 --> Database Driver Class Initialized
DEBUG - 2012-11-14 21:53:51 --> Helper loaded: form_helper
DEBUG - 2012-11-14 21:55:59 --> Config Class Initialized
DEBUG - 2012-11-14 21:55:59 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:55:59 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:55:59 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:55:59 --> URI Class Initialized
DEBUG - 2012-11-14 21:56:00 --> Router Class Initialized
DEBUG - 2012-11-14 21:56:00 --> Output Class Initialized
DEBUG - 2012-11-14 21:56:00 --> Security Class Initialized
DEBUG - 2012-11-14 21:56:00 --> Input Class Initialized
DEBUG - 2012-11-14 21:56:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 21:56:00 --> Language Class Initialized
DEBUG - 2012-11-14 21:56:00 --> Loader Class Initialized
DEBUG - 2012-11-14 21:56:00 --> Helper loaded: url_helper
DEBUG - 2012-11-14 21:56:00 --> Controller Class Initialized
DEBUG - 2012-11-14 21:56:00 --> Model Class Initialized
DEBUG - 2012-11-14 21:56:00 --> Database Driver Class Initialized
DEBUG - 2012-11-14 21:56:00 --> Helper loaded: form_helper
DEBUG - 2012-11-14 21:56:00 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-14 21:56:00 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-14 21:56:00 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-14 21:56:00 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-14 21:56:00 --> Final output sent to browser
DEBUG - 2012-11-14 21:56:00 --> Total execution time: 0.0502
DEBUG - 2012-11-14 21:56:02 --> Config Class Initialized
DEBUG - 2012-11-14 21:56:02 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:56:02 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:56:02 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:56:02 --> URI Class Initialized
DEBUG - 2012-11-14 21:56:02 --> Router Class Initialized
ERROR - 2012-11-14 21:56:02 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 21:56:02 --> Config Class Initialized
DEBUG - 2012-11-14 21:56:02 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:56:02 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:56:02 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:56:02 --> URI Class Initialized
DEBUG - 2012-11-14 21:56:02 --> Router Class Initialized
ERROR - 2012-11-14 21:56:02 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 21:56:02 --> Config Class Initialized
DEBUG - 2012-11-14 21:56:02 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:56:02 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:56:02 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:56:02 --> URI Class Initialized
DEBUG - 2012-11-14 21:56:02 --> Router Class Initialized
ERROR - 2012-11-14 21:56:02 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 21:56:46 --> Config Class Initialized
DEBUG - 2012-11-14 21:56:46 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:56:46 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:56:46 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:56:46 --> URI Class Initialized
DEBUG - 2012-11-14 21:56:46 --> Router Class Initialized
DEBUG - 2012-11-14 21:56:46 --> Output Class Initialized
DEBUG - 2012-11-14 21:56:46 --> Security Class Initialized
DEBUG - 2012-11-14 21:56:46 --> Input Class Initialized
DEBUG - 2012-11-14 21:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 21:56:46 --> Language Class Initialized
DEBUG - 2012-11-14 21:56:46 --> Loader Class Initialized
DEBUG - 2012-11-14 21:56:46 --> Helper loaded: url_helper
DEBUG - 2012-11-14 21:56:46 --> Controller Class Initialized
DEBUG - 2012-11-14 21:56:46 --> Model Class Initialized
DEBUG - 2012-11-14 21:56:46 --> Database Driver Class Initialized
DEBUG - 2012-11-14 21:56:46 --> Helper loaded: form_helper
DEBUG - 2012-11-14 21:56:46 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-14 21:56:46 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-14 21:56:46 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-14 21:56:46 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-14 21:56:46 --> Final output sent to browser
DEBUG - 2012-11-14 21:56:46 --> Total execution time: 0.0445
DEBUG - 2012-11-14 21:56:49 --> Config Class Initialized
DEBUG - 2012-11-14 21:56:49 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:56:49 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:56:49 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:56:49 --> URI Class Initialized
DEBUG - 2012-11-14 21:56:49 --> Router Class Initialized
ERROR - 2012-11-14 21:56:49 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 21:56:49 --> Config Class Initialized
DEBUG - 2012-11-14 21:56:49 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:56:49 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:56:49 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:56:49 --> URI Class Initialized
DEBUG - 2012-11-14 21:56:49 --> Router Class Initialized
ERROR - 2012-11-14 21:56:49 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 21:56:49 --> Config Class Initialized
DEBUG - 2012-11-14 21:56:49 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:56:49 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:56:49 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:56:49 --> URI Class Initialized
DEBUG - 2012-11-14 21:56:49 --> Router Class Initialized
ERROR - 2012-11-14 21:56:49 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 21:57:37 --> Config Class Initialized
DEBUG - 2012-11-14 21:57:37 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:57:37 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:57:37 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:57:37 --> URI Class Initialized
DEBUG - 2012-11-14 21:57:37 --> Router Class Initialized
DEBUG - 2012-11-14 21:57:37 --> Output Class Initialized
DEBUG - 2012-11-14 21:57:37 --> Security Class Initialized
DEBUG - 2012-11-14 21:57:37 --> Input Class Initialized
DEBUG - 2012-11-14 21:57:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 21:57:37 --> Language Class Initialized
DEBUG - 2012-11-14 21:57:37 --> Loader Class Initialized
DEBUG - 2012-11-14 21:57:37 --> Helper loaded: url_helper
DEBUG - 2012-11-14 21:57:37 --> Controller Class Initialized
DEBUG - 2012-11-14 21:57:37 --> Model Class Initialized
DEBUG - 2012-11-14 21:57:37 --> Database Driver Class Initialized
DEBUG - 2012-11-14 21:57:37 --> Helper loaded: form_helper
DEBUG - 2012-11-14 21:57:37 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-14 21:57:37 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-14 21:57:37 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-14 21:57:37 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-14 21:57:37 --> Final output sent to browser
DEBUG - 2012-11-14 21:57:37 --> Total execution time: 0.0433
DEBUG - 2012-11-14 21:57:40 --> Config Class Initialized
DEBUG - 2012-11-14 21:57:40 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:57:40 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:57:40 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:57:40 --> URI Class Initialized
DEBUG - 2012-11-14 21:57:40 --> Router Class Initialized
ERROR - 2012-11-14 21:57:40 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 21:57:40 --> Config Class Initialized
DEBUG - 2012-11-14 21:57:40 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:57:40 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:57:40 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:57:40 --> URI Class Initialized
DEBUG - 2012-11-14 21:57:40 --> Router Class Initialized
ERROR - 2012-11-14 21:57:40 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 21:57:40 --> Config Class Initialized
DEBUG - 2012-11-14 21:57:40 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:57:40 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:57:40 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:57:40 --> URI Class Initialized
DEBUG - 2012-11-14 21:57:40 --> Router Class Initialized
ERROR - 2012-11-14 21:57:40 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 21:57:42 --> Config Class Initialized
DEBUG - 2012-11-14 21:57:42 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:57:42 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:57:42 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:57:42 --> URI Class Initialized
DEBUG - 2012-11-14 21:57:42 --> Router Class Initialized
DEBUG - 2012-11-14 21:57:42 --> Output Class Initialized
DEBUG - 2012-11-14 21:57:42 --> Security Class Initialized
DEBUG - 2012-11-14 21:57:42 --> Input Class Initialized
DEBUG - 2012-11-14 21:57:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 21:57:42 --> Language Class Initialized
DEBUG - 2012-11-14 21:57:42 --> Loader Class Initialized
DEBUG - 2012-11-14 21:57:42 --> Helper loaded: url_helper
DEBUG - 2012-11-14 21:57:42 --> Controller Class Initialized
DEBUG - 2012-11-14 21:57:42 --> Model Class Initialized
DEBUG - 2012-11-14 21:57:42 --> Database Driver Class Initialized
DEBUG - 2012-11-14 21:57:42 --> Helper loaded: form_helper
DEBUG - 2012-11-14 21:57:42 --> Form Validation Class Initialized
ERROR - 2012-11-14 21:57:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/libraries/Prices.php 25
DEBUG - 2012-11-14 21:57:42 --> Final output sent to browser
DEBUG - 2012-11-14 21:57:42 --> Total execution time: 0.0469
DEBUG - 2012-11-14 21:57:51 --> Config Class Initialized
DEBUG - 2012-11-14 21:57:51 --> Hooks Class Initialized
DEBUG - 2012-11-14 21:57:51 --> Utf8 Class Initialized
DEBUG - 2012-11-14 21:57:51 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 21:57:51 --> URI Class Initialized
DEBUG - 2012-11-14 21:57:51 --> Router Class Initialized
DEBUG - 2012-11-14 21:57:51 --> Output Class Initialized
DEBUG - 2012-11-14 21:57:51 --> Security Class Initialized
DEBUG - 2012-11-14 21:57:51 --> Input Class Initialized
DEBUG - 2012-11-14 21:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 21:57:51 --> Language Class Initialized
DEBUG - 2012-11-14 21:57:51 --> Loader Class Initialized
DEBUG - 2012-11-14 21:57:51 --> Helper loaded: url_helper
DEBUG - 2012-11-14 21:57:51 --> Controller Class Initialized
DEBUG - 2012-11-14 21:57:51 --> Model Class Initialized
DEBUG - 2012-11-14 21:57:51 --> Database Driver Class Initialized
DEBUG - 2012-11-14 21:57:51 --> Helper loaded: form_helper
DEBUG - 2012-11-14 21:57:51 --> Form Validation Class Initialized
ERROR - 2012-11-14 21:57:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/jwp/www/justinwylliephotography.com/clients/application/libraries/Prices.php 25
DEBUG - 2012-11-14 21:57:51 --> Final output sent to browser
DEBUG - 2012-11-14 21:57:51 --> Total execution time: 0.0399
DEBUG - 2012-11-14 22:02:19 --> Config Class Initialized
DEBUG - 2012-11-14 22:02:19 --> Hooks Class Initialized
DEBUG - 2012-11-14 22:02:19 --> Utf8 Class Initialized
DEBUG - 2012-11-14 22:02:19 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 22:02:19 --> URI Class Initialized
DEBUG - 2012-11-14 22:02:19 --> Router Class Initialized
DEBUG - 2012-11-14 22:02:19 --> Output Class Initialized
DEBUG - 2012-11-14 22:02:19 --> Security Class Initialized
DEBUG - 2012-11-14 22:02:19 --> Input Class Initialized
DEBUG - 2012-11-14 22:02:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 22:02:19 --> Language Class Initialized
DEBUG - 2012-11-14 22:02:19 --> Loader Class Initialized
DEBUG - 2012-11-14 22:02:19 --> Helper loaded: url_helper
DEBUG - 2012-11-14 22:02:19 --> Controller Class Initialized
DEBUG - 2012-11-14 22:02:19 --> Model Class Initialized
DEBUG - 2012-11-14 22:02:19 --> Database Driver Class Initialized
DEBUG - 2012-11-14 22:02:19 --> Helper loaded: form_helper
DEBUG - 2012-11-14 22:02:19 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-14 22:02:19 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-14 22:02:19 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-11-14 22:02:19 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-14 22:02:19 --> Final output sent to browser
DEBUG - 2012-11-14 22:02:19 --> Total execution time: 0.0443
DEBUG - 2012-11-14 22:02:23 --> Config Class Initialized
DEBUG - 2012-11-14 22:02:23 --> Hooks Class Initialized
DEBUG - 2012-11-14 22:02:23 --> Utf8 Class Initialized
DEBUG - 2012-11-14 22:02:23 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 22:02:23 --> URI Class Initialized
DEBUG - 2012-11-14 22:02:23 --> Router Class Initialized
ERROR - 2012-11-14 22:02:23 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 22:02:23 --> Config Class Initialized
DEBUG - 2012-11-14 22:02:23 --> Hooks Class Initialized
DEBUG - 2012-11-14 22:02:23 --> Utf8 Class Initialized
DEBUG - 2012-11-14 22:02:23 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 22:02:23 --> URI Class Initialized
DEBUG - 2012-11-14 22:02:23 --> Router Class Initialized
ERROR - 2012-11-14 22:02:23 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 22:02:23 --> Config Class Initialized
DEBUG - 2012-11-14 22:02:23 --> Hooks Class Initialized
DEBUG - 2012-11-14 22:02:23 --> Utf8 Class Initialized
DEBUG - 2012-11-14 22:02:23 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 22:02:23 --> URI Class Initialized
DEBUG - 2012-11-14 22:02:23 --> Router Class Initialized
ERROR - 2012-11-14 22:02:23 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 22:02:49 --> Config Class Initialized
DEBUG - 2012-11-14 22:02:49 --> Hooks Class Initialized
DEBUG - 2012-11-14 22:02:49 --> Utf8 Class Initialized
DEBUG - 2012-11-14 22:02:49 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 22:02:49 --> URI Class Initialized
DEBUG - 2012-11-14 22:02:49 --> Router Class Initialized
DEBUG - 2012-11-14 22:02:49 --> Output Class Initialized
DEBUG - 2012-11-14 22:02:49 --> Security Class Initialized
DEBUG - 2012-11-14 22:02:49 --> Input Class Initialized
DEBUG - 2012-11-14 22:02:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 22:02:49 --> Language Class Initialized
DEBUG - 2012-11-14 22:02:49 --> Loader Class Initialized
DEBUG - 2012-11-14 22:02:49 --> Helper loaded: url_helper
DEBUG - 2012-11-14 22:02:49 --> Controller Class Initialized
DEBUG - 2012-11-14 22:02:49 --> Model Class Initialized
DEBUG - 2012-11-14 22:02:49 --> Database Driver Class Initialized
DEBUG - 2012-11-14 22:02:49 --> Helper loaded: form_helper
DEBUG - 2012-11-14 22:02:49 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-14 22:02:49 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-14 22:02:49 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-14 22:02:49 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-14 22:02:49 --> Final output sent to browser
DEBUG - 2012-11-14 22:02:49 --> Total execution time: 0.0437
DEBUG - 2012-11-14 22:02:53 --> Config Class Initialized
DEBUG - 2012-11-14 22:02:53 --> Hooks Class Initialized
DEBUG - 2012-11-14 22:02:53 --> Utf8 Class Initialized
DEBUG - 2012-11-14 22:02:53 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 22:02:53 --> URI Class Initialized
DEBUG - 2012-11-14 22:02:53 --> Router Class Initialized
ERROR - 2012-11-14 22:02:53 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 22:02:53 --> Config Class Initialized
DEBUG - 2012-11-14 22:02:53 --> Hooks Class Initialized
DEBUG - 2012-11-14 22:02:53 --> Utf8 Class Initialized
DEBUG - 2012-11-14 22:02:53 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 22:02:53 --> URI Class Initialized
DEBUG - 2012-11-14 22:02:53 --> Router Class Initialized
DEBUG - 2012-11-14 22:02:53 --> Config Class Initialized
DEBUG - 2012-11-14 22:02:53 --> Hooks Class Initialized
DEBUG - 2012-11-14 22:02:53 --> Utf8 Class Initialized
DEBUG - 2012-11-14 22:02:53 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 22:02:53 --> URI Class Initialized
DEBUG - 2012-11-14 22:02:53 --> Router Class Initialized
ERROR - 2012-11-14 22:02:53 --> 404 Page Not Found --> css
ERROR - 2012-11-14 22:02:53 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 22:04:24 --> Config Class Initialized
DEBUG - 2012-11-14 22:04:24 --> Hooks Class Initialized
DEBUG - 2012-11-14 22:04:24 --> Utf8 Class Initialized
DEBUG - 2012-11-14 22:04:24 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 22:04:24 --> URI Class Initialized
DEBUG - 2012-11-14 22:04:24 --> Router Class Initialized
DEBUG - 2012-11-14 22:04:24 --> Output Class Initialized
DEBUG - 2012-11-14 22:04:24 --> Security Class Initialized
DEBUG - 2012-11-14 22:04:24 --> Input Class Initialized
DEBUG - 2012-11-14 22:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 22:04:24 --> Language Class Initialized
DEBUG - 2012-11-14 22:04:24 --> Loader Class Initialized
DEBUG - 2012-11-14 22:04:24 --> Helper loaded: url_helper
DEBUG - 2012-11-14 22:04:24 --> Controller Class Initialized
DEBUG - 2012-11-14 22:04:24 --> Model Class Initialized
DEBUG - 2012-11-14 22:04:24 --> Database Driver Class Initialized
DEBUG - 2012-11-14 22:04:24 --> Helper loaded: form_helper
DEBUG - 2012-11-14 22:04:24 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-14 22:04:24 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-14 22:04:24 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-11-14 22:04:24 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-14 22:04:24 --> Final output sent to browser
DEBUG - 2012-11-14 22:04:24 --> Total execution time: 0.0495
DEBUG - 2012-11-14 22:04:29 --> Config Class Initialized
DEBUG - 2012-11-14 22:04:29 --> Hooks Class Initialized
DEBUG - 2012-11-14 22:04:29 --> Utf8 Class Initialized
DEBUG - 2012-11-14 22:04:29 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 22:04:29 --> URI Class Initialized
DEBUG - 2012-11-14 22:04:29 --> Router Class Initialized
ERROR - 2012-11-14 22:04:29 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 22:04:29 --> Config Class Initialized
DEBUG - 2012-11-14 22:04:29 --> Hooks Class Initialized
DEBUG - 2012-11-14 22:04:29 --> Utf8 Class Initialized
DEBUG - 2012-11-14 22:04:29 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 22:04:29 --> URI Class Initialized
DEBUG - 2012-11-14 22:04:29 --> Router Class Initialized
ERROR - 2012-11-14 22:04:29 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 22:04:29 --> Config Class Initialized
DEBUG - 2012-11-14 22:04:29 --> Hooks Class Initialized
DEBUG - 2012-11-14 22:04:29 --> Utf8 Class Initialized
DEBUG - 2012-11-14 22:04:29 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 22:04:29 --> URI Class Initialized
DEBUG - 2012-11-14 22:04:29 --> Router Class Initialized
ERROR - 2012-11-14 22:04:29 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 22:11:02 --> Config Class Initialized
DEBUG - 2012-11-14 22:11:02 --> Hooks Class Initialized
DEBUG - 2012-11-14 22:11:02 --> Utf8 Class Initialized
DEBUG - 2012-11-14 22:11:02 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 22:11:02 --> URI Class Initialized
DEBUG - 2012-11-14 22:11:02 --> Router Class Initialized
DEBUG - 2012-11-14 22:11:02 --> Output Class Initialized
DEBUG - 2012-11-14 22:11:02 --> Security Class Initialized
DEBUG - 2012-11-14 22:11:02 --> Input Class Initialized
DEBUG - 2012-11-14 22:11:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 22:11:02 --> Language Class Initialized
DEBUG - 2012-11-14 22:11:02 --> Loader Class Initialized
DEBUG - 2012-11-14 22:11:02 --> Helper loaded: url_helper
DEBUG - 2012-11-14 22:11:02 --> Controller Class Initialized
DEBUG - 2012-11-14 22:11:02 --> Model Class Initialized
DEBUG - 2012-11-14 22:11:02 --> Database Driver Class Initialized
DEBUG - 2012-11-14 22:11:02 --> Helper loaded: form_helper
DEBUG - 2012-11-14 22:11:02 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-14 22:11:02 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-14 22:11:02 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-14 22:11:02 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-14 22:11:02 --> Final output sent to browser
DEBUG - 2012-11-14 22:11:02 --> Total execution time: 0.0453
DEBUG - 2012-11-14 22:11:04 --> Config Class Initialized
DEBUG - 2012-11-14 22:11:04 --> Hooks Class Initialized
DEBUG - 2012-11-14 22:11:04 --> Utf8 Class Initialized
DEBUG - 2012-11-14 22:11:04 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 22:11:04 --> URI Class Initialized
DEBUG - 2012-11-14 22:11:04 --> Router Class Initialized
ERROR - 2012-11-14 22:11:04 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 22:11:04 --> Config Class Initialized
DEBUG - 2012-11-14 22:11:04 --> Hooks Class Initialized
DEBUG - 2012-11-14 22:11:04 --> Utf8 Class Initialized
DEBUG - 2012-11-14 22:11:04 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 22:11:04 --> URI Class Initialized
DEBUG - 2012-11-14 22:11:04 --> Router Class Initialized
ERROR - 2012-11-14 22:11:04 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 22:11:04 --> Config Class Initialized
DEBUG - 2012-11-14 22:11:04 --> Hooks Class Initialized
DEBUG - 2012-11-14 22:11:04 --> Utf8 Class Initialized
DEBUG - 2012-11-14 22:11:04 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 22:11:04 --> URI Class Initialized
DEBUG - 2012-11-14 22:11:04 --> Router Class Initialized
ERROR - 2012-11-14 22:11:04 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 22:11:29 --> Config Class Initialized
DEBUG - 2012-11-14 22:11:29 --> Hooks Class Initialized
DEBUG - 2012-11-14 22:11:29 --> Utf8 Class Initialized
DEBUG - 2012-11-14 22:11:29 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 22:11:29 --> URI Class Initialized
DEBUG - 2012-11-14 22:11:29 --> Router Class Initialized
DEBUG - 2012-11-14 22:11:29 --> Output Class Initialized
DEBUG - 2012-11-14 22:11:29 --> Security Class Initialized
DEBUG - 2012-11-14 22:11:29 --> Input Class Initialized
DEBUG - 2012-11-14 22:11:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 22:11:29 --> Language Class Initialized
DEBUG - 2012-11-14 22:11:29 --> Loader Class Initialized
DEBUG - 2012-11-14 22:11:29 --> Helper loaded: url_helper
DEBUG - 2012-11-14 22:11:29 --> Controller Class Initialized
DEBUG - 2012-11-14 22:11:29 --> Model Class Initialized
DEBUG - 2012-11-14 22:11:29 --> Database Driver Class Initialized
DEBUG - 2012-11-14 22:11:30 --> Final output sent to browser
DEBUG - 2012-11-14 22:11:30 --> Total execution time: 0.1516
DEBUG - 2012-11-14 23:00:55 --> Config Class Initialized
DEBUG - 2012-11-14 23:00:55 --> Hooks Class Initialized
DEBUG - 2012-11-14 23:00:55 --> Utf8 Class Initialized
DEBUG - 2012-11-14 23:00:55 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 23:00:55 --> URI Class Initialized
DEBUG - 2012-11-14 23:00:55 --> Router Class Initialized
DEBUG - 2012-11-14 23:00:55 --> Output Class Initialized
DEBUG - 2012-11-14 23:00:55 --> Security Class Initialized
DEBUG - 2012-11-14 23:00:55 --> Input Class Initialized
DEBUG - 2012-11-14 23:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 23:00:55 --> Language Class Initialized
DEBUG - 2012-11-14 23:00:55 --> Loader Class Initialized
DEBUG - 2012-11-14 23:00:55 --> Helper loaded: url_helper
DEBUG - 2012-11-14 23:00:55 --> Controller Class Initialized
DEBUG - 2012-11-14 23:00:55 --> Model Class Initialized
DEBUG - 2012-11-14 23:00:55 --> Database Driver Class Initialized
DEBUG - 2012-11-14 23:00:55 --> Helper loaded: form_helper
DEBUG - 2012-11-14 23:00:55 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-14 23:00:55 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-14 23:00:55 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-14 23:00:55 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-14 23:00:55 --> Final output sent to browser
DEBUG - 2012-11-14 23:00:55 --> Total execution time: 0.0442
DEBUG - 2012-11-14 23:00:57 --> Config Class Initialized
DEBUG - 2012-11-14 23:00:57 --> Hooks Class Initialized
DEBUG - 2012-11-14 23:00:57 --> Utf8 Class Initialized
DEBUG - 2012-11-14 23:00:57 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 23:00:57 --> URI Class Initialized
DEBUG - 2012-11-14 23:00:57 --> Router Class Initialized
ERROR - 2012-11-14 23:00:57 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 23:00:57 --> Config Class Initialized
DEBUG - 2012-11-14 23:00:57 --> Hooks Class Initialized
DEBUG - 2012-11-14 23:00:57 --> Utf8 Class Initialized
DEBUG - 2012-11-14 23:00:57 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 23:00:57 --> URI Class Initialized
DEBUG - 2012-11-14 23:00:57 --> Router Class Initialized
ERROR - 2012-11-14 23:00:57 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 23:00:57 --> Config Class Initialized
DEBUG - 2012-11-14 23:00:57 --> Hooks Class Initialized
DEBUG - 2012-11-14 23:00:57 --> Utf8 Class Initialized
DEBUG - 2012-11-14 23:00:57 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 23:00:57 --> URI Class Initialized
DEBUG - 2012-11-14 23:00:57 --> Router Class Initialized
ERROR - 2012-11-14 23:00:57 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 23:02:04 --> Config Class Initialized
DEBUG - 2012-11-14 23:02:04 --> Hooks Class Initialized
DEBUG - 2012-11-14 23:02:04 --> Utf8 Class Initialized
DEBUG - 2012-11-14 23:02:04 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 23:02:04 --> URI Class Initialized
DEBUG - 2012-11-14 23:02:04 --> Router Class Initialized
DEBUG - 2012-11-14 23:02:04 --> Output Class Initialized
DEBUG - 2012-11-14 23:02:04 --> Security Class Initialized
DEBUG - 2012-11-14 23:02:04 --> Input Class Initialized
DEBUG - 2012-11-14 23:02:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-14 23:02:04 --> Language Class Initialized
DEBUG - 2012-11-14 23:02:04 --> Loader Class Initialized
DEBUG - 2012-11-14 23:02:04 --> Helper loaded: url_helper
DEBUG - 2012-11-14 23:02:04 --> Controller Class Initialized
DEBUG - 2012-11-14 23:02:04 --> Model Class Initialized
DEBUG - 2012-11-14 23:02:04 --> Database Driver Class Initialized
DEBUG - 2012-11-14 23:02:04 --> Helper loaded: form_helper
DEBUG - 2012-11-14 23:02:04 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-14 23:02:04 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-14 23:02:04 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-14 23:02:04 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-14 23:02:04 --> Final output sent to browser
DEBUG - 2012-11-14 23:02:04 --> Total execution time: 0.0482
DEBUG - 2012-11-14 23:02:06 --> Config Class Initialized
DEBUG - 2012-11-14 23:02:06 --> Hooks Class Initialized
DEBUG - 2012-11-14 23:02:06 --> Utf8 Class Initialized
DEBUG - 2012-11-14 23:02:06 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 23:02:06 --> URI Class Initialized
DEBUG - 2012-11-14 23:02:06 --> Router Class Initialized
ERROR - 2012-11-14 23:02:06 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 23:02:06 --> Config Class Initialized
DEBUG - 2012-11-14 23:02:06 --> Hooks Class Initialized
DEBUG - 2012-11-14 23:02:06 --> Utf8 Class Initialized
DEBUG - 2012-11-14 23:02:06 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 23:02:06 --> URI Class Initialized
DEBUG - 2012-11-14 23:02:06 --> Router Class Initialized
ERROR - 2012-11-14 23:02:06 --> 404 Page Not Found --> css
DEBUG - 2012-11-14 23:02:06 --> Config Class Initialized
DEBUG - 2012-11-14 23:02:06 --> Hooks Class Initialized
DEBUG - 2012-11-14 23:02:06 --> Utf8 Class Initialized
DEBUG - 2012-11-14 23:02:06 --> UTF-8 Support Enabled
DEBUG - 2012-11-14 23:02:06 --> URI Class Initialized
DEBUG - 2012-11-14 23:02:06 --> Router Class Initialized
ERROR - 2012-11-14 23:02:06 --> 404 Page Not Found --> css
