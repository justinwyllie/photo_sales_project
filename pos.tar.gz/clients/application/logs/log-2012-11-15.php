<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-11-15 00:34:45 --> Config Class Initialized
DEBUG - 2012-11-15 00:34:45 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:34:45 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:34:45 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:34:45 --> URI Class Initialized
DEBUG - 2012-11-15 00:34:45 --> Router Class Initialized
DEBUG - 2012-11-15 00:34:45 --> Output Class Initialized
DEBUG - 2012-11-15 00:34:45 --> Security Class Initialized
DEBUG - 2012-11-15 00:34:45 --> Input Class Initialized
DEBUG - 2012-11-15 00:34:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 00:34:45 --> Language Class Initialized
DEBUG - 2012-11-15 00:34:45 --> Loader Class Initialized
DEBUG - 2012-11-15 00:34:45 --> Helper loaded: url_helper
DEBUG - 2012-11-15 00:34:45 --> Controller Class Initialized
DEBUG - 2012-11-15 00:34:45 --> Model Class Initialized
DEBUG - 2012-11-15 00:34:46 --> Database Driver Class Initialized
DEBUG - 2012-11-15 00:34:46 --> Helper loaded: form_helper
DEBUG - 2012-11-15 00:34:46 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 00:34:46 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 00:34:46 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-11-15 00:34:46 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 00:34:46 --> Final output sent to browser
DEBUG - 2012-11-15 00:34:46 --> Total execution time: 0.0497
DEBUG - 2012-11-15 00:34:47 --> Config Class Initialized
DEBUG - 2012-11-15 00:34:47 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:34:47 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:34:47 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:34:47 --> URI Class Initialized
DEBUG - 2012-11-15 00:34:47 --> Router Class Initialized
ERROR - 2012-11-15 00:34:47 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:34:47 --> Config Class Initialized
DEBUG - 2012-11-15 00:34:47 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:34:47 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:34:47 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:34:47 --> URI Class Initialized
DEBUG - 2012-11-15 00:34:47 --> Router Class Initialized
ERROR - 2012-11-15 00:34:47 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:34:48 --> Config Class Initialized
DEBUG - 2012-11-15 00:34:48 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:34:48 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:34:48 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:34:48 --> URI Class Initialized
DEBUG - 2012-11-15 00:34:48 --> Router Class Initialized
ERROR - 2012-11-15 00:34:48 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:36:55 --> Config Class Initialized
DEBUG - 2012-11-15 00:36:55 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:36:55 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:36:55 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:36:55 --> URI Class Initialized
DEBUG - 2012-11-15 00:36:55 --> Router Class Initialized
DEBUG - 2012-11-15 00:36:55 --> Output Class Initialized
DEBUG - 2012-11-15 00:36:55 --> Security Class Initialized
DEBUG - 2012-11-15 00:36:55 --> Input Class Initialized
DEBUG - 2012-11-15 00:36:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 00:36:55 --> Language Class Initialized
DEBUG - 2012-11-15 00:36:55 --> Loader Class Initialized
DEBUG - 2012-11-15 00:36:55 --> Helper loaded: url_helper
DEBUG - 2012-11-15 00:36:55 --> Controller Class Initialized
DEBUG - 2012-11-15 00:36:55 --> Model Class Initialized
DEBUG - 2012-11-15 00:36:55 --> Database Driver Class Initialized
DEBUG - 2012-11-15 00:36:55 --> Helper loaded: form_helper
DEBUG - 2012-11-15 00:36:55 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 00:36:55 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 00:36:55 --> File loaded: application/views/admin/pages/pricing/mount_types.php
DEBUG - 2012-11-15 00:36:55 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 00:36:55 --> Final output sent to browser
DEBUG - 2012-11-15 00:36:55 --> Total execution time: 0.0448
DEBUG - 2012-11-15 00:36:57 --> Config Class Initialized
DEBUG - 2012-11-15 00:36:57 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:36:57 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:36:57 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:36:57 --> URI Class Initialized
DEBUG - 2012-11-15 00:36:57 --> Router Class Initialized
ERROR - 2012-11-15 00:36:57 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:36:57 --> Config Class Initialized
DEBUG - 2012-11-15 00:36:57 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:36:57 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:36:57 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:36:57 --> URI Class Initialized
DEBUG - 2012-11-15 00:36:57 --> Router Class Initialized
ERROR - 2012-11-15 00:36:57 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:36:57 --> Config Class Initialized
DEBUG - 2012-11-15 00:36:57 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:36:57 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:36:57 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:36:57 --> URI Class Initialized
DEBUG - 2012-11-15 00:36:57 --> Router Class Initialized
ERROR - 2012-11-15 00:36:57 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:37:04 --> Config Class Initialized
DEBUG - 2012-11-15 00:37:04 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:37:04 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:37:04 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:37:04 --> URI Class Initialized
DEBUG - 2012-11-15 00:37:04 --> Router Class Initialized
DEBUG - 2012-11-15 00:37:04 --> Output Class Initialized
DEBUG - 2012-11-15 00:37:04 --> Security Class Initialized
DEBUG - 2012-11-15 00:37:04 --> Input Class Initialized
DEBUG - 2012-11-15 00:37:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 00:37:04 --> Language Class Initialized
DEBUG - 2012-11-15 00:37:04 --> Loader Class Initialized
DEBUG - 2012-11-15 00:37:04 --> Helper loaded: url_helper
DEBUG - 2012-11-15 00:37:04 --> Controller Class Initialized
DEBUG - 2012-11-15 00:37:04 --> Model Class Initialized
DEBUG - 2012-11-15 00:37:04 --> Database Driver Class Initialized
DEBUG - 2012-11-15 00:37:04 --> Helper loaded: form_helper
DEBUG - 2012-11-15 00:37:04 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 00:37:04 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 00:37:04 --> File loaded: application/views/admin/pages/pricing/units.php
DEBUG - 2012-11-15 00:37:04 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 00:37:04 --> Final output sent to browser
DEBUG - 2012-11-15 00:37:04 --> Total execution time: 0.0971
DEBUG - 2012-11-15 00:37:06 --> Config Class Initialized
DEBUG - 2012-11-15 00:37:06 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:37:06 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:37:06 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:37:06 --> URI Class Initialized
DEBUG - 2012-11-15 00:37:06 --> Router Class Initialized
ERROR - 2012-11-15 00:37:06 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:37:06 --> Config Class Initialized
DEBUG - 2012-11-15 00:37:06 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:37:06 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:37:06 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:37:06 --> URI Class Initialized
DEBUG - 2012-11-15 00:37:06 --> Router Class Initialized
ERROR - 2012-11-15 00:37:06 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:37:06 --> Config Class Initialized
DEBUG - 2012-11-15 00:37:06 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:37:06 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:37:06 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:37:06 --> URI Class Initialized
DEBUG - 2012-11-15 00:37:06 --> Router Class Initialized
ERROR - 2012-11-15 00:37:06 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:37:10 --> Config Class Initialized
DEBUG - 2012-11-15 00:37:10 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:37:10 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:37:10 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:37:10 --> URI Class Initialized
DEBUG - 2012-11-15 00:37:10 --> Router Class Initialized
DEBUG - 2012-11-15 00:37:10 --> Output Class Initialized
DEBUG - 2012-11-15 00:37:10 --> Security Class Initialized
DEBUG - 2012-11-15 00:37:10 --> Input Class Initialized
DEBUG - 2012-11-15 00:37:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 00:37:10 --> Language Class Initialized
DEBUG - 2012-11-15 00:37:11 --> Loader Class Initialized
DEBUG - 2012-11-15 00:37:11 --> Helper loaded: url_helper
DEBUG - 2012-11-15 00:37:11 --> Controller Class Initialized
DEBUG - 2012-11-15 00:37:11 --> Model Class Initialized
DEBUG - 2012-11-15 00:37:11 --> Database Driver Class Initialized
DEBUG - 2012-11-15 00:37:11 --> Helper loaded: form_helper
DEBUG - 2012-11-15 00:37:11 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 00:37:11 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 00:37:11 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 00:37:11 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 00:37:11 --> Final output sent to browser
DEBUG - 2012-11-15 00:37:11 --> Total execution time: 0.0482
DEBUG - 2012-11-15 00:37:13 --> Config Class Initialized
DEBUG - 2012-11-15 00:37:13 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:37:13 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:37:13 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:37:13 --> URI Class Initialized
DEBUG - 2012-11-15 00:37:13 --> Router Class Initialized
ERROR - 2012-11-15 00:37:13 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:37:13 --> Config Class Initialized
DEBUG - 2012-11-15 00:37:13 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:37:13 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:37:13 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:37:13 --> URI Class Initialized
DEBUG - 2012-11-15 00:37:13 --> Router Class Initialized
ERROR - 2012-11-15 00:37:13 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:37:13 --> Config Class Initialized
DEBUG - 2012-11-15 00:37:13 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:37:13 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:37:13 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:37:13 --> URI Class Initialized
DEBUG - 2012-11-15 00:37:13 --> Router Class Initialized
ERROR - 2012-11-15 00:37:13 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:38:25 --> Config Class Initialized
DEBUG - 2012-11-15 00:38:25 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:38:25 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:38:25 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:38:25 --> URI Class Initialized
DEBUG - 2012-11-15 00:38:25 --> Router Class Initialized
DEBUG - 2012-11-15 00:38:25 --> Output Class Initialized
DEBUG - 2012-11-15 00:38:25 --> Security Class Initialized
DEBUG - 2012-11-15 00:38:25 --> Input Class Initialized
DEBUG - 2012-11-15 00:38:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 00:38:25 --> Language Class Initialized
DEBUG - 2012-11-15 00:38:26 --> Loader Class Initialized
DEBUG - 2012-11-15 00:38:26 --> Helper loaded: url_helper
DEBUG - 2012-11-15 00:38:26 --> Controller Class Initialized
DEBUG - 2012-11-15 00:38:26 --> Model Class Initialized
DEBUG - 2012-11-15 00:38:26 --> Database Driver Class Initialized
DEBUG - 2012-11-15 00:38:26 --> Helper loaded: form_helper
DEBUG - 2012-11-15 00:38:26 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 00:38:26 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 00:38:26 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 00:38:26 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 00:38:26 --> Final output sent to browser
DEBUG - 2012-11-15 00:38:26 --> Total execution time: 0.0439
DEBUG - 2012-11-15 00:38:27 --> Config Class Initialized
DEBUG - 2012-11-15 00:38:27 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:38:27 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:38:27 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:38:27 --> URI Class Initialized
DEBUG - 2012-11-15 00:38:27 --> Router Class Initialized
ERROR - 2012-11-15 00:38:27 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:38:27 --> Config Class Initialized
DEBUG - 2012-11-15 00:38:27 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:38:27 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:38:27 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:38:27 --> URI Class Initialized
DEBUG - 2012-11-15 00:38:27 --> Router Class Initialized
ERROR - 2012-11-15 00:38:27 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:38:28 --> Config Class Initialized
DEBUG - 2012-11-15 00:38:28 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:38:28 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:38:28 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:38:28 --> URI Class Initialized
DEBUG - 2012-11-15 00:38:28 --> Router Class Initialized
ERROR - 2012-11-15 00:38:28 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:48:27 --> Config Class Initialized
DEBUG - 2012-11-15 00:48:27 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:48:27 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:48:27 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:48:27 --> URI Class Initialized
DEBUG - 2012-11-15 00:48:27 --> Router Class Initialized
DEBUG - 2012-11-15 00:48:27 --> Output Class Initialized
DEBUG - 2012-11-15 00:48:27 --> Security Class Initialized
DEBUG - 2012-11-15 00:48:27 --> Input Class Initialized
DEBUG - 2012-11-15 00:48:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 00:48:27 --> Language Class Initialized
DEBUG - 2012-11-15 00:48:27 --> Loader Class Initialized
DEBUG - 2012-11-15 00:48:27 --> Helper loaded: url_helper
DEBUG - 2012-11-15 00:48:27 --> Controller Class Initialized
DEBUG - 2012-11-15 00:48:27 --> Model Class Initialized
DEBUG - 2012-11-15 00:48:27 --> Database Driver Class Initialized
DEBUG - 2012-11-15 00:48:27 --> Helper loaded: form_helper
DEBUG - 2012-11-15 00:48:27 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 00:48:27 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 00:48:27 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 00:48:27 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 00:48:27 --> Final output sent to browser
DEBUG - 2012-11-15 00:48:27 --> Total execution time: 0.0473
DEBUG - 2012-11-15 00:48:29 --> Config Class Initialized
DEBUG - 2012-11-15 00:48:29 --> Config Class Initialized
DEBUG - 2012-11-15 00:48:29 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:48:29 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:48:29 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:48:29 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:48:29 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:48:29 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:48:29 --> URI Class Initialized
DEBUG - 2012-11-15 00:48:29 --> Config Class Initialized
DEBUG - 2012-11-15 00:48:29 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:48:29 --> URI Class Initialized
DEBUG - 2012-11-15 00:48:29 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:48:29 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:48:29 --> Router Class Initialized
DEBUG - 2012-11-15 00:48:29 --> Router Class Initialized
ERROR - 2012-11-15 00:48:29 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:48:29 --> URI Class Initialized
ERROR - 2012-11-15 00:48:29 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:48:29 --> Router Class Initialized
ERROR - 2012-11-15 00:48:29 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:57:00 --> Config Class Initialized
DEBUG - 2012-11-15 00:57:00 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:57:00 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:57:00 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:57:00 --> URI Class Initialized
DEBUG - 2012-11-15 00:57:00 --> Router Class Initialized
DEBUG - 2012-11-15 00:57:00 --> Output Class Initialized
DEBUG - 2012-11-15 00:57:00 --> Security Class Initialized
DEBUG - 2012-11-15 00:57:00 --> Input Class Initialized
DEBUG - 2012-11-15 00:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 00:57:00 --> Language Class Initialized
DEBUG - 2012-11-15 00:57:00 --> Loader Class Initialized
DEBUG - 2012-11-15 00:57:00 --> Helper loaded: url_helper
DEBUG - 2012-11-15 00:57:00 --> Controller Class Initialized
DEBUG - 2012-11-15 00:57:00 --> Model Class Initialized
DEBUG - 2012-11-15 00:57:00 --> Database Driver Class Initialized
DEBUG - 2012-11-15 00:57:00 --> Helper loaded: form_helper
DEBUG - 2012-11-15 00:57:00 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 00:57:00 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 00:57:00 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 00:57:00 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 00:57:00 --> Final output sent to browser
DEBUG - 2012-11-15 00:57:00 --> Total execution time: 0.0495
DEBUG - 2012-11-15 00:57:02 --> Config Class Initialized
DEBUG - 2012-11-15 00:57:02 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:57:02 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:57:02 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:57:02 --> URI Class Initialized
DEBUG - 2012-11-15 00:57:02 --> Router Class Initialized
ERROR - 2012-11-15 00:57:02 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:57:02 --> Config Class Initialized
DEBUG - 2012-11-15 00:57:02 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:57:02 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:57:02 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:57:02 --> URI Class Initialized
DEBUG - 2012-11-15 00:57:02 --> Router Class Initialized
ERROR - 2012-11-15 00:57:02 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:57:02 --> Config Class Initialized
DEBUG - 2012-11-15 00:57:02 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:57:02 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:57:02 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:57:02 --> URI Class Initialized
DEBUG - 2012-11-15 00:57:02 --> Router Class Initialized
ERROR - 2012-11-15 00:57:02 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:57:47 --> Config Class Initialized
DEBUG - 2012-11-15 00:57:47 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:57:47 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:57:47 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:57:47 --> URI Class Initialized
DEBUG - 2012-11-15 00:57:47 --> Router Class Initialized
DEBUG - 2012-11-15 00:57:47 --> Output Class Initialized
DEBUG - 2012-11-15 00:57:47 --> Security Class Initialized
DEBUG - 2012-11-15 00:57:47 --> Input Class Initialized
DEBUG - 2012-11-15 00:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 00:57:47 --> Language Class Initialized
DEBUG - 2012-11-15 00:57:47 --> Loader Class Initialized
DEBUG - 2012-11-15 00:57:47 --> Helper loaded: url_helper
DEBUG - 2012-11-15 00:57:47 --> Controller Class Initialized
DEBUG - 2012-11-15 00:57:47 --> Model Class Initialized
DEBUG - 2012-11-15 00:57:47 --> Database Driver Class Initialized
DEBUG - 2012-11-15 00:57:47 --> Helper loaded: form_helper
DEBUG - 2012-11-15 00:57:47 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 00:57:47 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 00:57:47 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 00:57:47 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 00:57:47 --> Final output sent to browser
DEBUG - 2012-11-15 00:57:47 --> Total execution time: 0.0447
DEBUG - 2012-11-15 00:57:49 --> Config Class Initialized
DEBUG - 2012-11-15 00:57:49 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:57:49 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:57:49 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:57:49 --> URI Class Initialized
DEBUG - 2012-11-15 00:57:49 --> Router Class Initialized
ERROR - 2012-11-15 00:57:49 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:57:49 --> Config Class Initialized
DEBUG - 2012-11-15 00:57:49 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:57:49 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:57:49 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:57:49 --> URI Class Initialized
DEBUG - 2012-11-15 00:57:49 --> Router Class Initialized
ERROR - 2012-11-15 00:57:49 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:57:49 --> Config Class Initialized
DEBUG - 2012-11-15 00:57:49 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:57:49 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:57:49 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:57:49 --> URI Class Initialized
DEBUG - 2012-11-15 00:57:49 --> Router Class Initialized
ERROR - 2012-11-15 00:57:49 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:58:39 --> Config Class Initialized
DEBUG - 2012-11-15 00:58:39 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:58:39 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:58:39 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:58:39 --> URI Class Initialized
DEBUG - 2012-11-15 00:58:39 --> Router Class Initialized
DEBUG - 2012-11-15 00:58:39 --> Output Class Initialized
DEBUG - 2012-11-15 00:58:39 --> Security Class Initialized
DEBUG - 2012-11-15 00:58:39 --> Input Class Initialized
DEBUG - 2012-11-15 00:58:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 00:58:39 --> Language Class Initialized
DEBUG - 2012-11-15 00:58:39 --> Loader Class Initialized
DEBUG - 2012-11-15 00:58:39 --> Helper loaded: url_helper
DEBUG - 2012-11-15 00:58:39 --> Controller Class Initialized
DEBUG - 2012-11-15 00:58:39 --> Model Class Initialized
DEBUG - 2012-11-15 00:58:39 --> Database Driver Class Initialized
DEBUG - 2012-11-15 00:58:39 --> Helper loaded: form_helper
DEBUG - 2012-11-15 00:58:39 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 00:58:39 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 00:58:39 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 00:58:39 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 00:58:39 --> Final output sent to browser
DEBUG - 2012-11-15 00:58:39 --> Total execution time: 0.0513
DEBUG - 2012-11-15 00:58:41 --> Config Class Initialized
DEBUG - 2012-11-15 00:58:41 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:58:41 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:58:41 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:58:41 --> URI Class Initialized
DEBUG - 2012-11-15 00:58:41 --> Router Class Initialized
ERROR - 2012-11-15 00:58:41 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:58:41 --> Config Class Initialized
DEBUG - 2012-11-15 00:58:41 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:58:41 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:58:41 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:58:41 --> URI Class Initialized
DEBUG - 2012-11-15 00:58:41 --> Router Class Initialized
ERROR - 2012-11-15 00:58:41 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 00:58:41 --> Config Class Initialized
DEBUG - 2012-11-15 00:58:41 --> Hooks Class Initialized
DEBUG - 2012-11-15 00:58:41 --> Utf8 Class Initialized
DEBUG - 2012-11-15 00:58:41 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 00:58:41 --> URI Class Initialized
DEBUG - 2012-11-15 00:58:41 --> Router Class Initialized
ERROR - 2012-11-15 00:58:41 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:03:42 --> Config Class Initialized
DEBUG - 2012-11-15 01:03:42 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:03:42 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:03:42 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:03:42 --> URI Class Initialized
DEBUG - 2012-11-15 01:03:42 --> Router Class Initialized
DEBUG - 2012-11-15 01:03:42 --> Output Class Initialized
DEBUG - 2012-11-15 01:03:42 --> Security Class Initialized
DEBUG - 2012-11-15 01:03:42 --> Input Class Initialized
DEBUG - 2012-11-15 01:03:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:03:42 --> Language Class Initialized
DEBUG - 2012-11-15 01:03:42 --> Loader Class Initialized
DEBUG - 2012-11-15 01:03:42 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:03:42 --> Controller Class Initialized
DEBUG - 2012-11-15 01:03:42 --> Model Class Initialized
DEBUG - 2012-11-15 01:03:42 --> Database Driver Class Initialized
DEBUG - 2012-11-15 01:03:42 --> Helper loaded: form_helper
DEBUG - 2012-11-15 01:03:42 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 01:03:42 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 01:03:42 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 01:03:42 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 01:03:43 --> Final output sent to browser
DEBUG - 2012-11-15 01:03:43 --> Total execution time: 0.0585
DEBUG - 2012-11-15 01:03:44 --> Config Class Initialized
DEBUG - 2012-11-15 01:03:44 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:03:44 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:03:44 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:03:44 --> URI Class Initialized
DEBUG - 2012-11-15 01:03:44 --> Router Class Initialized
ERROR - 2012-11-15 01:03:44 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:03:44 --> Config Class Initialized
DEBUG - 2012-11-15 01:03:44 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:03:44 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:03:44 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:03:44 --> URI Class Initialized
DEBUG - 2012-11-15 01:03:45 --> Router Class Initialized
ERROR - 2012-11-15 01:03:45 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:03:45 --> Config Class Initialized
DEBUG - 2012-11-15 01:03:45 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:03:45 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:03:45 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:03:45 --> URI Class Initialized
DEBUG - 2012-11-15 01:03:45 --> Router Class Initialized
ERROR - 2012-11-15 01:03:45 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:04:47 --> Config Class Initialized
DEBUG - 2012-11-15 01:04:47 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:04:47 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:04:47 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:04:47 --> URI Class Initialized
DEBUG - 2012-11-15 01:04:47 --> Router Class Initialized
DEBUG - 2012-11-15 01:04:47 --> Output Class Initialized
DEBUG - 2012-11-15 01:04:47 --> Security Class Initialized
DEBUG - 2012-11-15 01:04:47 --> Input Class Initialized
DEBUG - 2012-11-15 01:04:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:04:47 --> Language Class Initialized
DEBUG - 2012-11-15 01:04:47 --> Loader Class Initialized
DEBUG - 2012-11-15 01:04:47 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:04:47 --> Controller Class Initialized
DEBUG - 2012-11-15 01:04:47 --> Model Class Initialized
DEBUG - 2012-11-15 01:04:47 --> Database Driver Class Initialized
DEBUG - 2012-11-15 01:04:47 --> Helper loaded: form_helper
DEBUG - 2012-11-15 01:04:47 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 01:04:47 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 01:04:47 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 01:04:47 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 01:04:47 --> Final output sent to browser
DEBUG - 2012-11-15 01:04:47 --> Total execution time: 0.0528
DEBUG - 2012-11-15 01:04:49 --> Config Class Initialized
DEBUG - 2012-11-15 01:04:49 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:04:49 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:04:49 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:04:49 --> URI Class Initialized
DEBUG - 2012-11-15 01:04:49 --> Router Class Initialized
ERROR - 2012-11-15 01:04:49 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:04:49 --> Config Class Initialized
DEBUG - 2012-11-15 01:04:49 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:04:49 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:04:49 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:04:49 --> URI Class Initialized
DEBUG - 2012-11-15 01:04:49 --> Router Class Initialized
ERROR - 2012-11-15 01:04:49 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:04:49 --> Config Class Initialized
DEBUG - 2012-11-15 01:04:49 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:04:49 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:04:49 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:04:49 --> URI Class Initialized
DEBUG - 2012-11-15 01:04:49 --> Router Class Initialized
ERROR - 2012-11-15 01:04:49 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:07:38 --> Config Class Initialized
DEBUG - 2012-11-15 01:07:38 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:07:38 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:07:38 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:07:38 --> URI Class Initialized
DEBUG - 2012-11-15 01:07:38 --> Router Class Initialized
DEBUG - 2012-11-15 01:07:38 --> Output Class Initialized
DEBUG - 2012-11-15 01:07:38 --> Security Class Initialized
DEBUG - 2012-11-15 01:07:38 --> Input Class Initialized
DEBUG - 2012-11-15 01:07:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:07:38 --> Language Class Initialized
DEBUG - 2012-11-15 01:07:38 --> Loader Class Initialized
DEBUG - 2012-11-15 01:07:38 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:07:38 --> Controller Class Initialized
DEBUG - 2012-11-15 01:07:38 --> Model Class Initialized
DEBUG - 2012-11-15 01:07:38 --> Database Driver Class Initialized
DEBUG - 2012-11-15 01:07:38 --> Helper loaded: form_helper
DEBUG - 2012-11-15 01:07:38 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 01:07:38 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 01:07:38 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 01:07:38 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 01:07:38 --> Final output sent to browser
DEBUG - 2012-11-15 01:07:38 --> Total execution time: 0.0482
DEBUG - 2012-11-15 01:07:40 --> Config Class Initialized
DEBUG - 2012-11-15 01:07:40 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:07:40 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:07:40 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:07:40 --> Config Class Initialized
DEBUG - 2012-11-15 01:07:40 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:07:40 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:07:40 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:07:40 --> URI Class Initialized
DEBUG - 2012-11-15 01:07:40 --> Router Class Initialized
ERROR - 2012-11-15 01:07:40 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:07:40 --> URI Class Initialized
DEBUG - 2012-11-15 01:07:40 --> Router Class Initialized
ERROR - 2012-11-15 01:07:40 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:07:40 --> Config Class Initialized
DEBUG - 2012-11-15 01:07:40 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:07:40 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:07:40 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:07:40 --> URI Class Initialized
DEBUG - 2012-11-15 01:07:40 --> Router Class Initialized
ERROR - 2012-11-15 01:07:40 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:07:54 --> Config Class Initialized
DEBUG - 2012-11-15 01:07:54 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:07:54 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:07:54 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:07:54 --> URI Class Initialized
DEBUG - 2012-11-15 01:07:54 --> Router Class Initialized
DEBUG - 2012-11-15 01:07:54 --> Output Class Initialized
DEBUG - 2012-11-15 01:07:54 --> Security Class Initialized
DEBUG - 2012-11-15 01:07:54 --> Input Class Initialized
DEBUG - 2012-11-15 01:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:07:54 --> Language Class Initialized
DEBUG - 2012-11-15 01:07:54 --> Loader Class Initialized
DEBUG - 2012-11-15 01:07:54 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:07:54 --> Controller Class Initialized
DEBUG - 2012-11-15 01:07:54 --> Model Class Initialized
DEBUG - 2012-11-15 01:07:54 --> Database Driver Class Initialized
DEBUG - 2012-11-15 01:07:54 --> Helper loaded: form_helper
DEBUG - 2012-11-15 01:07:54 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 01:07:54 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 01:07:54 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 01:07:54 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 01:07:55 --> Final output sent to browser
DEBUG - 2012-11-15 01:07:55 --> Total execution time: 0.0478
DEBUG - 2012-11-15 01:07:56 --> Config Class Initialized
DEBUG - 2012-11-15 01:07:56 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:07:56 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:07:56 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:07:56 --> URI Class Initialized
DEBUG - 2012-11-15 01:07:56 --> Router Class Initialized
ERROR - 2012-11-15 01:07:56 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:07:57 --> Config Class Initialized
DEBUG - 2012-11-15 01:07:57 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:07:57 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:07:57 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:07:57 --> URI Class Initialized
DEBUG - 2012-11-15 01:07:57 --> Router Class Initialized
ERROR - 2012-11-15 01:07:57 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:07:57 --> Config Class Initialized
DEBUG - 2012-11-15 01:07:57 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:07:57 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:07:57 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:07:57 --> URI Class Initialized
DEBUG - 2012-11-15 01:07:57 --> Router Class Initialized
ERROR - 2012-11-15 01:07:57 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:14:42 --> Config Class Initialized
DEBUG - 2012-11-15 01:14:42 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:14:42 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:14:42 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:14:42 --> URI Class Initialized
DEBUG - 2012-11-15 01:14:42 --> Router Class Initialized
DEBUG - 2012-11-15 01:14:42 --> Output Class Initialized
DEBUG - 2012-11-15 01:14:42 --> Security Class Initialized
DEBUG - 2012-11-15 01:14:42 --> Input Class Initialized
DEBUG - 2012-11-15 01:14:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:14:42 --> Language Class Initialized
DEBUG - 2012-11-15 01:14:42 --> Loader Class Initialized
DEBUG - 2012-11-15 01:14:42 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:14:42 --> Controller Class Initialized
DEBUG - 2012-11-15 01:14:42 --> Model Class Initialized
DEBUG - 2012-11-15 01:14:42 --> Database Driver Class Initialized
DEBUG - 2012-11-15 01:14:42 --> Helper loaded: form_helper
DEBUG - 2012-11-15 01:14:42 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 01:14:42 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 01:14:42 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 01:14:42 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 01:14:42 --> Final output sent to browser
DEBUG - 2012-11-15 01:14:42 --> Total execution time: 0.0446
DEBUG - 2012-11-15 01:14:50 --> Config Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:14:50 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:14:50 --> URI Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Router Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Output Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Security Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Input Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:14:50 --> Language Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Loader Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:14:50 --> Controller Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Model Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Database Driver Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Helper loaded: form_helper
DEBUG - 2012-11-15 01:14:50 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 01:14:50 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 01:14:50 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 01:14:50 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 01:14:50 --> Config Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:14:50 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:14:50 --> URI Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Router Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Output Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Security Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Input Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:14:50 --> Language Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Loader Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:14:50 --> Controller Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Model Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Database Driver Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Helper loaded: form_helper
DEBUG - 2012-11-15 01:14:50 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 01:14:50 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 01:14:50 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 01:14:50 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 01:14:50 --> Config Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:14:50 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:14:50 --> URI Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Router Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Output Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Security Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Input Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:14:50 --> Language Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Loader Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:14:50 --> Controller Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Model Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Database Driver Class Initialized
DEBUG - 2012-11-15 01:14:50 --> Helper loaded: form_helper
DEBUG - 2012-11-15 01:14:50 --> Final output sent to browser
DEBUG - 2012-11-15 01:14:50 --> Total execution time: 0.0526
DEBUG - 2012-11-15 01:14:50 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 01:14:50 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 01:14:50 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 01:14:50 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 01:14:50 --> Final output sent to browser
DEBUG - 2012-11-15 01:14:50 --> Total execution time: 0.0500
DEBUG - 2012-11-15 01:14:52 --> Config Class Initialized
DEBUG - 2012-11-15 01:14:52 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:14:52 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:14:52 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:14:52 --> URI Class Initialized
DEBUG - 2012-11-15 01:14:52 --> Router Class Initialized
ERROR - 2012-11-15 01:14:52 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:14:52 --> Config Class Initialized
DEBUG - 2012-11-15 01:14:52 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:14:52 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:14:52 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:14:52 --> URI Class Initialized
DEBUG - 2012-11-15 01:14:52 --> Router Class Initialized
ERROR - 2012-11-15 01:14:52 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:14:52 --> Config Class Initialized
DEBUG - 2012-11-15 01:14:52 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:14:52 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:14:52 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:14:52 --> URI Class Initialized
DEBUG - 2012-11-15 01:14:52 --> Router Class Initialized
ERROR - 2012-11-15 01:14:52 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:17:38 --> Config Class Initialized
DEBUG - 2012-11-15 01:17:38 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:17:38 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:17:38 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:17:38 --> URI Class Initialized
DEBUG - 2012-11-15 01:17:38 --> Router Class Initialized
DEBUG - 2012-11-15 01:17:38 --> Output Class Initialized
DEBUG - 2012-11-15 01:17:38 --> Security Class Initialized
DEBUG - 2012-11-15 01:17:38 --> Input Class Initialized
DEBUG - 2012-11-15 01:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:17:38 --> Language Class Initialized
DEBUG - 2012-11-15 01:17:38 --> Loader Class Initialized
DEBUG - 2012-11-15 01:17:38 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:17:38 --> Controller Class Initialized
DEBUG - 2012-11-15 01:17:38 --> Model Class Initialized
DEBUG - 2012-11-15 01:17:38 --> Database Driver Class Initialized
DEBUG - 2012-11-15 01:17:38 --> Helper loaded: form_helper
DEBUG - 2012-11-15 01:17:38 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 01:17:38 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 01:17:38 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 01:17:38 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 01:17:38 --> Final output sent to browser
DEBUG - 2012-11-15 01:17:38 --> Total execution time: 0.0438
DEBUG - 2012-11-15 01:17:40 --> Config Class Initialized
DEBUG - 2012-11-15 01:17:40 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:17:40 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:17:40 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:17:40 --> URI Class Initialized
DEBUG - 2012-11-15 01:17:40 --> Router Class Initialized
ERROR - 2012-11-15 01:17:40 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:17:40 --> Config Class Initialized
DEBUG - 2012-11-15 01:17:40 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:17:40 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:17:40 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:17:40 --> URI Class Initialized
DEBUG - 2012-11-15 01:17:40 --> Router Class Initialized
ERROR - 2012-11-15 01:17:40 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:17:40 --> Config Class Initialized
DEBUG - 2012-11-15 01:17:40 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:17:40 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:17:40 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:17:40 --> URI Class Initialized
DEBUG - 2012-11-15 01:17:40 --> Router Class Initialized
ERROR - 2012-11-15 01:17:40 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:17:47 --> Config Class Initialized
DEBUG - 2012-11-15 01:17:47 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:17:47 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:17:47 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:17:47 --> URI Class Initialized
DEBUG - 2012-11-15 01:17:47 --> Router Class Initialized
DEBUG - 2012-11-15 01:17:47 --> Output Class Initialized
DEBUG - 2012-11-15 01:17:47 --> Security Class Initialized
DEBUG - 2012-11-15 01:17:47 --> Input Class Initialized
DEBUG - 2012-11-15 01:17:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:17:47 --> Language Class Initialized
DEBUG - 2012-11-15 01:17:47 --> Loader Class Initialized
DEBUG - 2012-11-15 01:17:47 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:17:47 --> Controller Class Initialized
DEBUG - 2012-11-15 01:17:47 --> Model Class Initialized
DEBUG - 2012-11-15 01:17:47 --> Database Driver Class Initialized
ERROR - 2012-11-15 01:17:47 --> 404 Page Not Found --> pricing/ajax_print_configure
DEBUG - 2012-11-15 01:18:22 --> Config Class Initialized
DEBUG - 2012-11-15 01:18:22 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:18:22 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:18:22 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:18:22 --> URI Class Initialized
DEBUG - 2012-11-15 01:18:22 --> Router Class Initialized
DEBUG - 2012-11-15 01:18:22 --> Output Class Initialized
DEBUG - 2012-11-15 01:18:22 --> Security Class Initialized
DEBUG - 2012-11-15 01:18:22 --> Input Class Initialized
DEBUG - 2012-11-15 01:18:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:18:22 --> Language Class Initialized
DEBUG - 2012-11-15 01:18:22 --> Loader Class Initialized
DEBUG - 2012-11-15 01:18:22 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:18:22 --> Controller Class Initialized
DEBUG - 2012-11-15 01:18:22 --> Model Class Initialized
DEBUG - 2012-11-15 01:18:22 --> Database Driver Class Initialized
ERROR - 2012-11-15 01:18:22 --> 404 Page Not Found --> pricing/ajax_print_configure
DEBUG - 2012-11-15 01:18:24 --> Config Class Initialized
DEBUG - 2012-11-15 01:18:24 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:18:24 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:18:24 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:18:24 --> URI Class Initialized
DEBUG - 2012-11-15 01:18:24 --> Router Class Initialized
DEBUG - 2012-11-15 01:18:24 --> Output Class Initialized
DEBUG - 2012-11-15 01:18:24 --> Security Class Initialized
DEBUG - 2012-11-15 01:18:24 --> Input Class Initialized
DEBUG - 2012-11-15 01:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:18:24 --> Language Class Initialized
DEBUG - 2012-11-15 01:18:24 --> Loader Class Initialized
DEBUG - 2012-11-15 01:18:24 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:18:24 --> Controller Class Initialized
DEBUG - 2012-11-15 01:18:24 --> Model Class Initialized
DEBUG - 2012-11-15 01:18:24 --> Database Driver Class Initialized
ERROR - 2012-11-15 01:18:24 --> 404 Page Not Found --> pricing/ajax_print_configure
DEBUG - 2012-11-15 01:18:26 --> Config Class Initialized
DEBUG - 2012-11-15 01:18:26 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:18:26 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:18:26 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:18:26 --> URI Class Initialized
DEBUG - 2012-11-15 01:18:26 --> Router Class Initialized
DEBUG - 2012-11-15 01:18:26 --> Output Class Initialized
DEBUG - 2012-11-15 01:18:26 --> Security Class Initialized
DEBUG - 2012-11-15 01:18:26 --> Input Class Initialized
DEBUG - 2012-11-15 01:18:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:18:26 --> Language Class Initialized
DEBUG - 2012-11-15 01:18:26 --> Loader Class Initialized
DEBUG - 2012-11-15 01:18:26 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:18:26 --> Controller Class Initialized
DEBUG - 2012-11-15 01:18:26 --> Model Class Initialized
DEBUG - 2012-11-15 01:18:26 --> Database Driver Class Initialized
ERROR - 2012-11-15 01:18:26 --> 404 Page Not Found --> pricing/ajax_print_configure
DEBUG - 2012-11-15 01:18:27 --> Config Class Initialized
DEBUG - 2012-11-15 01:18:27 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:18:27 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:18:27 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:18:27 --> URI Class Initialized
DEBUG - 2012-11-15 01:18:27 --> Router Class Initialized
DEBUG - 2012-11-15 01:18:27 --> Output Class Initialized
DEBUG - 2012-11-15 01:18:27 --> Security Class Initialized
DEBUG - 2012-11-15 01:18:27 --> Input Class Initialized
DEBUG - 2012-11-15 01:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:18:27 --> Language Class Initialized
DEBUG - 2012-11-15 01:18:27 --> Loader Class Initialized
DEBUG - 2012-11-15 01:18:27 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:18:27 --> Controller Class Initialized
DEBUG - 2012-11-15 01:18:27 --> Model Class Initialized
DEBUG - 2012-11-15 01:18:27 --> Database Driver Class Initialized
ERROR - 2012-11-15 01:18:28 --> 404 Page Not Found --> pricing/ajax_print_configure
DEBUG - 2012-11-15 01:18:28 --> Config Class Initialized
DEBUG - 2012-11-15 01:18:28 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:18:28 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:18:28 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:18:28 --> URI Class Initialized
DEBUG - 2012-11-15 01:18:28 --> Router Class Initialized
DEBUG - 2012-11-15 01:18:28 --> Output Class Initialized
DEBUG - 2012-11-15 01:18:28 --> Security Class Initialized
DEBUG - 2012-11-15 01:18:28 --> Input Class Initialized
DEBUG - 2012-11-15 01:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:18:28 --> Language Class Initialized
DEBUG - 2012-11-15 01:18:28 --> Loader Class Initialized
DEBUG - 2012-11-15 01:18:28 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:18:28 --> Controller Class Initialized
DEBUG - 2012-11-15 01:18:28 --> Model Class Initialized
DEBUG - 2012-11-15 01:18:28 --> Database Driver Class Initialized
ERROR - 2012-11-15 01:18:28 --> 404 Page Not Found --> pricing/ajax_print_configure
DEBUG - 2012-11-15 01:19:49 --> Config Class Initialized
DEBUG - 2012-11-15 01:19:49 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:19:49 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:19:49 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:19:49 --> URI Class Initialized
DEBUG - 2012-11-15 01:19:49 --> Router Class Initialized
DEBUG - 2012-11-15 01:19:49 --> Output Class Initialized
DEBUG - 2012-11-15 01:19:49 --> Security Class Initialized
DEBUG - 2012-11-15 01:19:49 --> Input Class Initialized
DEBUG - 2012-11-15 01:19:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:19:49 --> Language Class Initialized
DEBUG - 2012-11-15 01:19:49 --> Loader Class Initialized
DEBUG - 2012-11-15 01:19:49 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:19:49 --> Controller Class Initialized
DEBUG - 2012-11-15 01:19:49 --> Model Class Initialized
DEBUG - 2012-11-15 01:19:49 --> Database Driver Class Initialized
DEBUG - 2012-11-15 01:19:49 --> Helper loaded: form_helper
DEBUG - 2012-11-15 01:19:49 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 01:19:49 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 01:19:49 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 01:19:49 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 01:19:50 --> Final output sent to browser
DEBUG - 2012-11-15 01:19:50 --> Total execution time: 0.0449
DEBUG - 2012-11-15 01:19:51 --> Config Class Initialized
DEBUG - 2012-11-15 01:19:51 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:19:52 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:19:52 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:19:52 --> URI Class Initialized
DEBUG - 2012-11-15 01:19:52 --> Router Class Initialized
ERROR - 2012-11-15 01:19:52 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:19:52 --> Config Class Initialized
DEBUG - 2012-11-15 01:19:52 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:19:52 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:19:52 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:19:52 --> URI Class Initialized
DEBUG - 2012-11-15 01:19:52 --> Router Class Initialized
ERROR - 2012-11-15 01:19:52 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:19:52 --> Config Class Initialized
DEBUG - 2012-11-15 01:19:52 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:19:52 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:19:52 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:19:52 --> URI Class Initialized
DEBUG - 2012-11-15 01:19:52 --> Router Class Initialized
ERROR - 2012-11-15 01:19:52 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:20:30 --> Config Class Initialized
DEBUG - 2012-11-15 01:20:30 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:20:30 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:20:30 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:20:30 --> URI Class Initialized
DEBUG - 2012-11-15 01:20:30 --> Router Class Initialized
DEBUG - 2012-11-15 01:20:30 --> Output Class Initialized
DEBUG - 2012-11-15 01:20:30 --> Security Class Initialized
DEBUG - 2012-11-15 01:20:30 --> Input Class Initialized
DEBUG - 2012-11-15 01:20:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:20:30 --> Language Class Initialized
DEBUG - 2012-11-15 01:20:30 --> Loader Class Initialized
DEBUG - 2012-11-15 01:20:30 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:20:30 --> Controller Class Initialized
DEBUG - 2012-11-15 01:20:30 --> Model Class Initialized
DEBUG - 2012-11-15 01:20:30 --> Database Driver Class Initialized
DEBUG - 2012-11-15 01:20:30 --> Helper loaded: form_helper
DEBUG - 2012-11-15 01:20:30 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 01:20:30 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 01:20:30 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 01:20:30 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 01:20:30 --> Final output sent to browser
DEBUG - 2012-11-15 01:20:30 --> Total execution time: 0.0439
DEBUG - 2012-11-15 01:20:32 --> Config Class Initialized
DEBUG - 2012-11-15 01:20:32 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:20:32 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:20:32 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:20:32 --> URI Class Initialized
DEBUG - 2012-11-15 01:20:32 --> Router Class Initialized
ERROR - 2012-11-15 01:20:32 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:20:32 --> Config Class Initialized
DEBUG - 2012-11-15 01:20:32 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:20:32 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:20:32 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:20:32 --> URI Class Initialized
DEBUG - 2012-11-15 01:20:32 --> Router Class Initialized
DEBUG - 2012-11-15 01:20:32 --> Config Class Initialized
DEBUG - 2012-11-15 01:20:32 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:20:32 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:20:32 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:20:32 --> URI Class Initialized
DEBUG - 2012-11-15 01:20:32 --> Router Class Initialized
ERROR - 2012-11-15 01:20:32 --> 404 Page Not Found --> css
ERROR - 2012-11-15 01:20:32 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:20:37 --> Config Class Initialized
DEBUG - 2012-11-15 01:20:37 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:20:37 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:20:37 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:20:37 --> URI Class Initialized
DEBUG - 2012-11-15 01:20:37 --> Router Class Initialized
DEBUG - 2012-11-15 01:20:37 --> Output Class Initialized
DEBUG - 2012-11-15 01:20:37 --> Security Class Initialized
DEBUG - 2012-11-15 01:20:37 --> Input Class Initialized
DEBUG - 2012-11-15 01:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:20:37 --> Language Class Initialized
DEBUG - 2012-11-15 01:20:37 --> Loader Class Initialized
DEBUG - 2012-11-15 01:20:37 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:20:37 --> Controller Class Initialized
DEBUG - 2012-11-15 01:20:37 --> Model Class Initialized
DEBUG - 2012-11-15 01:20:37 --> Database Driver Class Initialized
ERROR - 2012-11-15 01:20:37 --> 404 Page Not Found --> pricing/ajax_print_configure
DEBUG - 2012-11-15 01:20:40 --> Config Class Initialized
DEBUG - 2012-11-15 01:20:40 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:20:40 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:20:40 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:20:40 --> URI Class Initialized
DEBUG - 2012-11-15 01:20:40 --> Router Class Initialized
DEBUG - 2012-11-15 01:20:40 --> Output Class Initialized
DEBUG - 2012-11-15 01:20:40 --> Security Class Initialized
DEBUG - 2012-11-15 01:20:40 --> Input Class Initialized
DEBUG - 2012-11-15 01:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:20:40 --> Language Class Initialized
DEBUG - 2012-11-15 01:20:40 --> Loader Class Initialized
DEBUG - 2012-11-15 01:20:40 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:20:40 --> Controller Class Initialized
DEBUG - 2012-11-15 01:20:40 --> Model Class Initialized
DEBUG - 2012-11-15 01:20:40 --> Database Driver Class Initialized
ERROR - 2012-11-15 01:20:40 --> 404 Page Not Found --> pricing/ajax_print_configure
DEBUG - 2012-11-15 01:20:45 --> Config Class Initialized
DEBUG - 2012-11-15 01:20:45 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:20:45 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:20:45 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:20:45 --> URI Class Initialized
DEBUG - 2012-11-15 01:20:45 --> Router Class Initialized
DEBUG - 2012-11-15 01:20:45 --> Output Class Initialized
DEBUG - 2012-11-15 01:20:45 --> Security Class Initialized
DEBUG - 2012-11-15 01:20:45 --> Input Class Initialized
DEBUG - 2012-11-15 01:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:20:45 --> Language Class Initialized
DEBUG - 2012-11-15 01:20:45 --> Loader Class Initialized
DEBUG - 2012-11-15 01:20:45 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:20:45 --> Controller Class Initialized
DEBUG - 2012-11-15 01:20:45 --> Model Class Initialized
DEBUG - 2012-11-15 01:20:45 --> Database Driver Class Initialized
ERROR - 2012-11-15 01:20:45 --> 404 Page Not Found --> pricing/ajax_print_configure
DEBUG - 2012-11-15 01:21:58 --> Config Class Initialized
DEBUG - 2012-11-15 01:21:58 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:21:58 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:21:58 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:21:58 --> URI Class Initialized
DEBUG - 2012-11-15 01:21:58 --> Router Class Initialized
DEBUG - 2012-11-15 01:21:58 --> Output Class Initialized
DEBUG - 2012-11-15 01:21:58 --> Security Class Initialized
DEBUG - 2012-11-15 01:21:58 --> Input Class Initialized
DEBUG - 2012-11-15 01:21:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:21:58 --> Language Class Initialized
DEBUG - 2012-11-15 01:21:58 --> Loader Class Initialized
DEBUG - 2012-11-15 01:21:58 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:21:58 --> Controller Class Initialized
DEBUG - 2012-11-15 01:21:58 --> Model Class Initialized
DEBUG - 2012-11-15 01:21:58 --> Database Driver Class Initialized
DEBUG - 2012-11-15 01:21:58 --> Helper loaded: form_helper
DEBUG - 2012-11-15 01:21:58 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 01:21:58 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 01:21:58 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 01:21:58 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 01:21:59 --> Final output sent to browser
DEBUG - 2012-11-15 01:21:59 --> Total execution time: 0.0440
DEBUG - 2012-11-15 01:22:00 --> Config Class Initialized
DEBUG - 2012-11-15 01:22:00 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:22:00 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:22:00 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:22:00 --> URI Class Initialized
DEBUG - 2012-11-15 01:22:00 --> Router Class Initialized
ERROR - 2012-11-15 01:22:00 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:22:00 --> Config Class Initialized
DEBUG - 2012-11-15 01:22:00 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:22:00 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:22:00 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:22:00 --> URI Class Initialized
DEBUG - 2012-11-15 01:22:00 --> Router Class Initialized
ERROR - 2012-11-15 01:22:00 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:22:00 --> Config Class Initialized
DEBUG - 2012-11-15 01:22:00 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:22:00 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:22:00 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:22:00 --> URI Class Initialized
DEBUG - 2012-11-15 01:22:00 --> Router Class Initialized
ERROR - 2012-11-15 01:22:00 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:22:06 --> Config Class Initialized
DEBUG - 2012-11-15 01:22:06 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:22:06 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:22:06 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:22:06 --> URI Class Initialized
DEBUG - 2012-11-15 01:22:06 --> Router Class Initialized
DEBUG - 2012-11-15 01:22:06 --> Output Class Initialized
DEBUG - 2012-11-15 01:22:06 --> Security Class Initialized
DEBUG - 2012-11-15 01:22:06 --> Input Class Initialized
DEBUG - 2012-11-15 01:22:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:22:06 --> Language Class Initialized
DEBUG - 2012-11-15 01:22:06 --> Loader Class Initialized
DEBUG - 2012-11-15 01:22:06 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:22:06 --> Controller Class Initialized
DEBUG - 2012-11-15 01:22:06 --> Model Class Initialized
DEBUG - 2012-11-15 01:22:06 --> Database Driver Class Initialized
ERROR - 2012-11-15 01:22:06 --> 404 Page Not Found --> pricing/ajax_print_configure
DEBUG - 2012-11-15 01:22:56 --> Config Class Initialized
DEBUG - 2012-11-15 01:22:56 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:22:56 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:22:56 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:22:56 --> URI Class Initialized
DEBUG - 2012-11-15 01:22:56 --> Router Class Initialized
DEBUG - 2012-11-15 01:22:56 --> Output Class Initialized
DEBUG - 2012-11-15 01:22:56 --> Security Class Initialized
DEBUG - 2012-11-15 01:22:56 --> Input Class Initialized
DEBUG - 2012-11-15 01:22:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:22:56 --> Language Class Initialized
DEBUG - 2012-11-15 01:22:56 --> Loader Class Initialized
DEBUG - 2012-11-15 01:22:56 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:22:56 --> Controller Class Initialized
DEBUG - 2012-11-15 01:22:56 --> Model Class Initialized
DEBUG - 2012-11-15 01:22:56 --> Database Driver Class Initialized
DEBUG - 2012-11-15 01:22:56 --> Helper loaded: form_helper
DEBUG - 2012-11-15 01:22:56 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 01:22:56 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 01:22:56 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 01:22:56 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 01:22:56 --> Final output sent to browser
DEBUG - 2012-11-15 01:22:56 --> Total execution time: 0.0438
DEBUG - 2012-11-15 01:22:58 --> Config Class Initialized
DEBUG - 2012-11-15 01:22:58 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:22:58 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:22:58 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:22:58 --> URI Class Initialized
DEBUG - 2012-11-15 01:22:58 --> Router Class Initialized
ERROR - 2012-11-15 01:22:58 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:22:58 --> Config Class Initialized
DEBUG - 2012-11-15 01:22:58 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:22:58 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:22:58 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:22:58 --> URI Class Initialized
DEBUG - 2012-11-15 01:22:58 --> Router Class Initialized
ERROR - 2012-11-15 01:22:58 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:22:58 --> Config Class Initialized
DEBUG - 2012-11-15 01:22:58 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:22:58 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:22:58 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:22:58 --> URI Class Initialized
DEBUG - 2012-11-15 01:22:58 --> Router Class Initialized
ERROR - 2012-11-15 01:22:58 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:23:02 --> Config Class Initialized
DEBUG - 2012-11-15 01:23:02 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:23:02 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:23:02 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:23:02 --> URI Class Initialized
DEBUG - 2012-11-15 01:23:02 --> Router Class Initialized
DEBUG - 2012-11-15 01:23:02 --> Output Class Initialized
DEBUG - 2012-11-15 01:23:02 --> Security Class Initialized
DEBUG - 2012-11-15 01:23:02 --> Input Class Initialized
DEBUG - 2012-11-15 01:23:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:23:02 --> Language Class Initialized
DEBUG - 2012-11-15 01:23:02 --> Loader Class Initialized
DEBUG - 2012-11-15 01:23:02 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:23:02 --> Controller Class Initialized
DEBUG - 2012-11-15 01:23:02 --> Model Class Initialized
DEBUG - 2012-11-15 01:23:02 --> Database Driver Class Initialized
ERROR - 2012-11-15 01:23:02 --> 404 Page Not Found --> pricing/ajax_print_configure
DEBUG - 2012-11-15 01:23:33 --> Config Class Initialized
DEBUG - 2012-11-15 01:23:33 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:23:33 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:23:33 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:23:33 --> URI Class Initialized
DEBUG - 2012-11-15 01:23:33 --> Router Class Initialized
DEBUG - 2012-11-15 01:23:33 --> Output Class Initialized
DEBUG - 2012-11-15 01:23:33 --> Security Class Initialized
DEBUG - 2012-11-15 01:23:33 --> Input Class Initialized
DEBUG - 2012-11-15 01:23:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:23:33 --> Language Class Initialized
DEBUG - 2012-11-15 01:23:33 --> Loader Class Initialized
DEBUG - 2012-11-15 01:23:33 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:23:33 --> Controller Class Initialized
DEBUG - 2012-11-15 01:23:33 --> Model Class Initialized
DEBUG - 2012-11-15 01:23:33 --> Database Driver Class Initialized
ERROR - 2012-11-15 01:23:33 --> 404 Page Not Found --> pricing/ajax_print_configure
DEBUG - 2012-11-15 01:26:45 --> Config Class Initialized
DEBUG - 2012-11-15 01:26:45 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:26:45 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:26:45 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:26:45 --> URI Class Initialized
DEBUG - 2012-11-15 01:26:45 --> Router Class Initialized
DEBUG - 2012-11-15 01:26:45 --> Output Class Initialized
DEBUG - 2012-11-15 01:26:45 --> Security Class Initialized
DEBUG - 2012-11-15 01:26:45 --> Input Class Initialized
DEBUG - 2012-11-15 01:26:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:26:45 --> Language Class Initialized
DEBUG - 2012-11-15 01:26:45 --> Loader Class Initialized
DEBUG - 2012-11-15 01:26:45 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:26:45 --> Controller Class Initialized
DEBUG - 2012-11-15 01:26:45 --> Model Class Initialized
DEBUG - 2012-11-15 01:26:45 --> Database Driver Class Initialized
DEBUG - 2012-11-15 01:26:45 --> Helper loaded: form_helper
DEBUG - 2012-11-15 01:26:45 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 01:26:45 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 01:26:45 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 01:26:45 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 01:26:45 --> Final output sent to browser
DEBUG - 2012-11-15 01:26:45 --> Total execution time: 0.0485
DEBUG - 2012-11-15 01:26:47 --> Config Class Initialized
DEBUG - 2012-11-15 01:26:47 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:26:47 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:26:47 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:26:47 --> URI Class Initialized
DEBUG - 2012-11-15 01:26:47 --> Router Class Initialized
ERROR - 2012-11-15 01:26:47 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:26:47 --> Config Class Initialized
DEBUG - 2012-11-15 01:26:47 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:26:47 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:26:47 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:26:47 --> URI Class Initialized
DEBUG - 2012-11-15 01:26:47 --> Router Class Initialized
ERROR - 2012-11-15 01:26:47 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:26:47 --> Config Class Initialized
DEBUG - 2012-11-15 01:26:47 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:26:47 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:26:47 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:26:47 --> URI Class Initialized
DEBUG - 2012-11-15 01:26:47 --> Router Class Initialized
ERROR - 2012-11-15 01:26:47 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:26:52 --> Config Class Initialized
DEBUG - 2012-11-15 01:26:52 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:26:52 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:26:52 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:26:52 --> URI Class Initialized
DEBUG - 2012-11-15 01:26:52 --> Router Class Initialized
DEBUG - 2012-11-15 01:26:52 --> Output Class Initialized
DEBUG - 2012-11-15 01:26:52 --> Security Class Initialized
DEBUG - 2012-11-15 01:26:52 --> Input Class Initialized
DEBUG - 2012-11-15 01:26:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:26:52 --> Language Class Initialized
DEBUG - 2012-11-15 01:26:52 --> Loader Class Initialized
DEBUG - 2012-11-15 01:26:52 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:26:52 --> Controller Class Initialized
DEBUG - 2012-11-15 01:26:52 --> Model Class Initialized
DEBUG - 2012-11-15 01:26:52 --> Database Driver Class Initialized
ERROR - 2012-11-15 01:26:52 --> 404 Page Not Found --> pricing/ajax_print_configure
DEBUG - 2012-11-15 01:27:27 --> Config Class Initialized
DEBUG - 2012-11-15 01:27:27 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:27:27 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:27:27 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:27:27 --> URI Class Initialized
DEBUG - 2012-11-15 01:27:27 --> Router Class Initialized
DEBUG - 2012-11-15 01:27:27 --> Output Class Initialized
DEBUG - 2012-11-15 01:27:27 --> Security Class Initialized
DEBUG - 2012-11-15 01:27:27 --> Input Class Initialized
DEBUG - 2012-11-15 01:27:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:27:27 --> Language Class Initialized
DEBUG - 2012-11-15 01:27:27 --> Loader Class Initialized
DEBUG - 2012-11-15 01:27:27 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:27:27 --> Controller Class Initialized
DEBUG - 2012-11-15 01:27:27 --> Model Class Initialized
DEBUG - 2012-11-15 01:27:27 --> Database Driver Class Initialized
DEBUG - 2012-11-15 01:27:27 --> Helper loaded: form_helper
DEBUG - 2012-11-15 01:27:27 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 01:27:27 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 01:27:27 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 01:27:27 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 01:27:27 --> Final output sent to browser
DEBUG - 2012-11-15 01:27:27 --> Total execution time: 0.0439
DEBUG - 2012-11-15 01:27:29 --> Config Class Initialized
DEBUG - 2012-11-15 01:27:29 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:27:29 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:27:29 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:27:29 --> URI Class Initialized
DEBUG - 2012-11-15 01:27:29 --> Router Class Initialized
ERROR - 2012-11-15 01:27:29 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:27:29 --> Config Class Initialized
DEBUG - 2012-11-15 01:27:29 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:27:29 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:27:29 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:27:29 --> URI Class Initialized
DEBUG - 2012-11-15 01:27:29 --> Router Class Initialized
ERROR - 2012-11-15 01:27:29 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:27:29 --> Config Class Initialized
DEBUG - 2012-11-15 01:27:29 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:27:29 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:27:29 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:27:29 --> URI Class Initialized
DEBUG - 2012-11-15 01:27:29 --> Router Class Initialized
ERROR - 2012-11-15 01:27:29 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:28:33 --> Config Class Initialized
DEBUG - 2012-11-15 01:28:33 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:28:33 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:28:33 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:28:33 --> URI Class Initialized
DEBUG - 2012-11-15 01:28:33 --> Router Class Initialized
DEBUG - 2012-11-15 01:28:33 --> Output Class Initialized
DEBUG - 2012-11-15 01:28:33 --> Security Class Initialized
DEBUG - 2012-11-15 01:28:33 --> Input Class Initialized
DEBUG - 2012-11-15 01:28:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:28:33 --> Language Class Initialized
DEBUG - 2012-11-15 01:28:33 --> Loader Class Initialized
DEBUG - 2012-11-15 01:28:33 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:28:33 --> Controller Class Initialized
DEBUG - 2012-11-15 01:28:33 --> Model Class Initialized
DEBUG - 2012-11-15 01:28:33 --> Database Driver Class Initialized
DEBUG - 2012-11-15 01:28:33 --> Helper loaded: form_helper
DEBUG - 2012-11-15 01:28:33 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 01:28:33 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 01:28:33 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 01:28:33 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 01:28:33 --> Final output sent to browser
DEBUG - 2012-11-15 01:28:33 --> Total execution time: 0.0526
DEBUG - 2012-11-15 01:28:35 --> Config Class Initialized
DEBUG - 2012-11-15 01:28:35 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:28:35 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:28:35 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:28:35 --> URI Class Initialized
DEBUG - 2012-11-15 01:28:35 --> Router Class Initialized
ERROR - 2012-11-15 01:28:35 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:28:35 --> Config Class Initialized
DEBUG - 2012-11-15 01:28:35 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:28:35 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:28:35 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:28:35 --> URI Class Initialized
DEBUG - 2012-11-15 01:28:35 --> Router Class Initialized
ERROR - 2012-11-15 01:28:35 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:28:35 --> Config Class Initialized
DEBUG - 2012-11-15 01:28:35 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:28:35 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:28:35 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:28:35 --> URI Class Initialized
DEBUG - 2012-11-15 01:28:35 --> Router Class Initialized
ERROR - 2012-11-15 01:28:35 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:33:13 --> Config Class Initialized
DEBUG - 2012-11-15 01:33:13 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:33:13 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:33:13 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:33:13 --> URI Class Initialized
DEBUG - 2012-11-15 01:33:13 --> Router Class Initialized
DEBUG - 2012-11-15 01:33:13 --> Output Class Initialized
DEBUG - 2012-11-15 01:33:13 --> Security Class Initialized
DEBUG - 2012-11-15 01:33:13 --> Input Class Initialized
DEBUG - 2012-11-15 01:33:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:33:13 --> Language Class Initialized
DEBUG - 2012-11-15 01:33:13 --> Loader Class Initialized
DEBUG - 2012-11-15 01:33:13 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:33:13 --> Controller Class Initialized
DEBUG - 2012-11-15 01:33:13 --> Model Class Initialized
DEBUG - 2012-11-15 01:33:13 --> Database Driver Class Initialized
DEBUG - 2012-11-15 01:33:13 --> Helper loaded: form_helper
DEBUG - 2012-11-15 01:33:13 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 01:33:13 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 01:33:13 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 01:33:13 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 01:33:14 --> Final output sent to browser
DEBUG - 2012-11-15 01:33:14 --> Total execution time: 0.0640
DEBUG - 2012-11-15 01:33:15 --> Config Class Initialized
DEBUG - 2012-11-15 01:33:15 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:33:15 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:33:15 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:33:15 --> URI Class Initialized
DEBUG - 2012-11-15 01:33:15 --> Router Class Initialized
ERROR - 2012-11-15 01:33:15 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:33:15 --> Config Class Initialized
DEBUG - 2012-11-15 01:33:15 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:33:15 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:33:15 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:33:15 --> URI Class Initialized
DEBUG - 2012-11-15 01:33:15 --> Router Class Initialized
ERROR - 2012-11-15 01:33:15 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:33:15 --> Config Class Initialized
DEBUG - 2012-11-15 01:33:15 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:33:15 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:33:15 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:33:15 --> URI Class Initialized
DEBUG - 2012-11-15 01:33:15 --> Router Class Initialized
ERROR - 2012-11-15 01:33:15 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:33:26 --> Config Class Initialized
DEBUG - 2012-11-15 01:33:26 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:33:26 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:33:26 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:33:26 --> URI Class Initialized
DEBUG - 2012-11-15 01:33:27 --> Router Class Initialized
DEBUG - 2012-11-15 01:33:27 --> Output Class Initialized
DEBUG - 2012-11-15 01:33:27 --> Security Class Initialized
DEBUG - 2012-11-15 01:33:27 --> Input Class Initialized
DEBUG - 2012-11-15 01:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:33:27 --> Language Class Initialized
DEBUG - 2012-11-15 01:33:27 --> Loader Class Initialized
DEBUG - 2012-11-15 01:33:27 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:33:27 --> Controller Class Initialized
DEBUG - 2012-11-15 01:33:27 --> Model Class Initialized
DEBUG - 2012-11-15 01:33:27 --> Database Driver Class Initialized
DEBUG - 2012-11-15 01:33:27 --> Helper loaded: form_helper
DEBUG - 2012-11-15 01:33:27 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 01:33:27 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 01:33:27 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 01:33:27 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 01:33:27 --> Final output sent to browser
DEBUG - 2012-11-15 01:33:27 --> Total execution time: 0.0507
DEBUG - 2012-11-15 01:33:29 --> Config Class Initialized
DEBUG - 2012-11-15 01:33:29 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:33:29 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:33:29 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:33:29 --> URI Class Initialized
DEBUG - 2012-11-15 01:33:29 --> Router Class Initialized
ERROR - 2012-11-15 01:33:29 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:33:29 --> Config Class Initialized
DEBUG - 2012-11-15 01:33:29 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:33:29 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:33:29 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:33:29 --> URI Class Initialized
DEBUG - 2012-11-15 01:33:29 --> Router Class Initialized
ERROR - 2012-11-15 01:33:29 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:33:29 --> Config Class Initialized
DEBUG - 2012-11-15 01:33:29 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:33:29 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:33:29 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:33:29 --> URI Class Initialized
DEBUG - 2012-11-15 01:33:29 --> Router Class Initialized
ERROR - 2012-11-15 01:33:29 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:35:00 --> Config Class Initialized
DEBUG - 2012-11-15 01:35:00 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:35:00 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:35:00 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:35:00 --> URI Class Initialized
DEBUG - 2012-11-15 01:35:00 --> Router Class Initialized
DEBUG - 2012-11-15 01:35:00 --> Output Class Initialized
DEBUG - 2012-11-15 01:35:00 --> Security Class Initialized
DEBUG - 2012-11-15 01:35:00 --> Input Class Initialized
DEBUG - 2012-11-15 01:35:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:35:00 --> Language Class Initialized
DEBUG - 2012-11-15 01:35:00 --> Loader Class Initialized
DEBUG - 2012-11-15 01:35:00 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:35:00 --> Controller Class Initialized
DEBUG - 2012-11-15 01:35:00 --> Model Class Initialized
DEBUG - 2012-11-15 01:35:00 --> Database Driver Class Initialized
DEBUG - 2012-11-15 01:35:00 --> Helper loaded: form_helper
DEBUG - 2012-11-15 01:35:00 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 01:35:00 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 01:35:00 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 01:35:00 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 01:35:00 --> Final output sent to browser
DEBUG - 2012-11-15 01:35:00 --> Total execution time: 0.0542
DEBUG - 2012-11-15 01:35:02 --> Config Class Initialized
DEBUG - 2012-11-15 01:35:02 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:35:02 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:35:02 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:35:02 --> URI Class Initialized
DEBUG - 2012-11-15 01:35:02 --> Router Class Initialized
ERROR - 2012-11-15 01:35:02 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:35:02 --> Config Class Initialized
DEBUG - 2012-11-15 01:35:02 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:35:02 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:35:02 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:35:02 --> URI Class Initialized
DEBUG - 2012-11-15 01:35:02 --> Router Class Initialized
ERROR - 2012-11-15 01:35:02 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:35:02 --> Config Class Initialized
DEBUG - 2012-11-15 01:35:02 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:35:02 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:35:02 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:35:02 --> URI Class Initialized
DEBUG - 2012-11-15 01:35:02 --> Router Class Initialized
ERROR - 2012-11-15 01:35:02 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:35:24 --> Config Class Initialized
DEBUG - 2012-11-15 01:35:24 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:35:24 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:35:24 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:35:24 --> URI Class Initialized
DEBUG - 2012-11-15 01:35:24 --> Router Class Initialized
DEBUG - 2012-11-15 01:35:24 --> Output Class Initialized
DEBUG - 2012-11-15 01:35:24 --> Security Class Initialized
DEBUG - 2012-11-15 01:35:24 --> Input Class Initialized
DEBUG - 2012-11-15 01:35:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:35:24 --> Language Class Initialized
DEBUG - 2012-11-15 01:35:24 --> Loader Class Initialized
DEBUG - 2012-11-15 01:35:24 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:35:24 --> Controller Class Initialized
DEBUG - 2012-11-15 01:35:24 --> Model Class Initialized
DEBUG - 2012-11-15 01:35:24 --> Database Driver Class Initialized
ERROR - 2012-11-15 01:35:24 --> 404 Page Not Found --> pricing/ajax_print_configure
DEBUG - 2012-11-15 01:35:26 --> Config Class Initialized
DEBUG - 2012-11-15 01:35:26 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:35:26 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:35:26 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:35:26 --> URI Class Initialized
DEBUG - 2012-11-15 01:35:26 --> Router Class Initialized
DEBUG - 2012-11-15 01:35:26 --> Output Class Initialized
DEBUG - 2012-11-15 01:35:26 --> Security Class Initialized
DEBUG - 2012-11-15 01:35:26 --> Input Class Initialized
DEBUG - 2012-11-15 01:35:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:35:26 --> Language Class Initialized
DEBUG - 2012-11-15 01:35:26 --> Loader Class Initialized
DEBUG - 2012-11-15 01:35:26 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:35:26 --> Controller Class Initialized
DEBUG - 2012-11-15 01:35:26 --> Model Class Initialized
DEBUG - 2012-11-15 01:35:26 --> Database Driver Class Initialized
ERROR - 2012-11-15 01:35:26 --> 404 Page Not Found --> pricing/ajax_print_configure
DEBUG - 2012-11-15 01:35:26 --> Config Class Initialized
DEBUG - 2012-11-15 01:35:26 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:35:26 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:35:26 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:35:26 --> URI Class Initialized
DEBUG - 2012-11-15 01:35:26 --> Router Class Initialized
DEBUG - 2012-11-15 01:35:26 --> Output Class Initialized
DEBUG - 2012-11-15 01:35:26 --> Security Class Initialized
DEBUG - 2012-11-15 01:35:26 --> Input Class Initialized
DEBUG - 2012-11-15 01:35:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:35:26 --> Language Class Initialized
DEBUG - 2012-11-15 01:35:26 --> Loader Class Initialized
DEBUG - 2012-11-15 01:35:26 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:35:26 --> Controller Class Initialized
DEBUG - 2012-11-15 01:35:26 --> Model Class Initialized
DEBUG - 2012-11-15 01:35:26 --> Database Driver Class Initialized
ERROR - 2012-11-15 01:35:26 --> 404 Page Not Found --> pricing/ajax_print_configure
DEBUG - 2012-11-15 01:35:27 --> Config Class Initialized
DEBUG - 2012-11-15 01:35:27 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:35:27 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:35:27 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:35:27 --> URI Class Initialized
DEBUG - 2012-11-15 01:35:27 --> Router Class Initialized
DEBUG - 2012-11-15 01:35:27 --> Output Class Initialized
DEBUG - 2012-11-15 01:35:27 --> Security Class Initialized
DEBUG - 2012-11-15 01:35:27 --> Input Class Initialized
DEBUG - 2012-11-15 01:35:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:35:27 --> Language Class Initialized
DEBUG - 2012-11-15 01:35:27 --> Loader Class Initialized
DEBUG - 2012-11-15 01:35:27 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:35:27 --> Controller Class Initialized
DEBUG - 2012-11-15 01:35:27 --> Model Class Initialized
DEBUG - 2012-11-15 01:35:27 --> Database Driver Class Initialized
ERROR - 2012-11-15 01:35:27 --> 404 Page Not Found --> pricing/ajax_print_configure
DEBUG - 2012-11-15 01:35:41 --> Config Class Initialized
DEBUG - 2012-11-15 01:35:41 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:35:41 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:35:41 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:35:41 --> URI Class Initialized
DEBUG - 2012-11-15 01:35:41 --> Router Class Initialized
DEBUG - 2012-11-15 01:35:41 --> Output Class Initialized
DEBUG - 2012-11-15 01:35:41 --> Security Class Initialized
DEBUG - 2012-11-15 01:35:41 --> Input Class Initialized
DEBUG - 2012-11-15 01:35:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 01:35:41 --> Language Class Initialized
DEBUG - 2012-11-15 01:35:41 --> Loader Class Initialized
DEBUG - 2012-11-15 01:35:41 --> Helper loaded: url_helper
DEBUG - 2012-11-15 01:35:41 --> Controller Class Initialized
DEBUG - 2012-11-15 01:35:41 --> Model Class Initialized
DEBUG - 2012-11-15 01:35:41 --> Database Driver Class Initialized
DEBUG - 2012-11-15 01:35:41 --> Helper loaded: form_helper
DEBUG - 2012-11-15 01:35:41 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 01:35:41 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 01:35:41 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 01:35:41 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 01:35:42 --> Final output sent to browser
DEBUG - 2012-11-15 01:35:42 --> Total execution time: 0.0525
DEBUG - 2012-11-15 01:35:43 --> Config Class Initialized
DEBUG - 2012-11-15 01:35:43 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:35:43 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:35:43 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:35:43 --> URI Class Initialized
DEBUG - 2012-11-15 01:35:43 --> Router Class Initialized
ERROR - 2012-11-15 01:35:43 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:35:43 --> Config Class Initialized
DEBUG - 2012-11-15 01:35:43 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:35:43 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:35:43 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:35:43 --> URI Class Initialized
DEBUG - 2012-11-15 01:35:43 --> Router Class Initialized
ERROR - 2012-11-15 01:35:43 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 01:35:43 --> Config Class Initialized
DEBUG - 2012-11-15 01:35:43 --> Hooks Class Initialized
DEBUG - 2012-11-15 01:35:43 --> Utf8 Class Initialized
DEBUG - 2012-11-15 01:35:43 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 01:35:43 --> URI Class Initialized
DEBUG - 2012-11-15 01:35:43 --> Router Class Initialized
ERROR - 2012-11-15 01:35:43 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 04:07:13 --> Config Class Initialized
DEBUG - 2012-11-15 04:07:13 --> Hooks Class Initialized
DEBUG - 2012-11-15 04:07:13 --> Utf8 Class Initialized
DEBUG - 2012-11-15 04:07:13 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 04:07:13 --> URI Class Initialized
DEBUG - 2012-11-15 04:07:13 --> Router Class Initialized
DEBUG - 2012-11-15 04:07:13 --> Output Class Initialized
DEBUG - 2012-11-15 04:07:13 --> Security Class Initialized
DEBUG - 2012-11-15 04:07:13 --> Input Class Initialized
DEBUG - 2012-11-15 04:07:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-15 04:07:13 --> Language Class Initialized
DEBUG - 2012-11-15 04:07:13 --> Loader Class Initialized
DEBUG - 2012-11-15 04:07:13 --> Helper loaded: url_helper
DEBUG - 2012-11-15 04:07:13 --> Controller Class Initialized
DEBUG - 2012-11-15 04:07:13 --> Model Class Initialized
DEBUG - 2012-11-15 04:07:13 --> Database Driver Class Initialized
DEBUG - 2012-11-15 04:07:13 --> Helper loaded: form_helper
DEBUG - 2012-11-15 04:07:13 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-15 04:07:13 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-15 04:07:13 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-15 04:07:13 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-15 04:07:13 --> Final output sent to browser
DEBUG - 2012-11-15 04:07:13 --> Total execution time: 0.0444
DEBUG - 2012-11-15 04:07:15 --> Config Class Initialized
DEBUG - 2012-11-15 04:07:15 --> Hooks Class Initialized
DEBUG - 2012-11-15 04:07:15 --> Utf8 Class Initialized
DEBUG - 2012-11-15 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 04:07:15 --> URI Class Initialized
DEBUG - 2012-11-15 04:07:15 --> Router Class Initialized
ERROR - 2012-11-15 04:07:15 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 04:07:15 --> Config Class Initialized
DEBUG - 2012-11-15 04:07:15 --> Hooks Class Initialized
DEBUG - 2012-11-15 04:07:15 --> Utf8 Class Initialized
DEBUG - 2012-11-15 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 04:07:15 --> URI Class Initialized
DEBUG - 2012-11-15 04:07:15 --> Router Class Initialized
ERROR - 2012-11-15 04:07:15 --> 404 Page Not Found --> css
DEBUG - 2012-11-15 04:07:15 --> Config Class Initialized
DEBUG - 2012-11-15 04:07:15 --> Hooks Class Initialized
DEBUG - 2012-11-15 04:07:15 --> Utf8 Class Initialized
DEBUG - 2012-11-15 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2012-11-15 04:07:15 --> URI Class Initialized
DEBUG - 2012-11-15 04:07:15 --> Router Class Initialized
ERROR - 2012-11-15 04:07:15 --> 404 Page Not Found --> css
