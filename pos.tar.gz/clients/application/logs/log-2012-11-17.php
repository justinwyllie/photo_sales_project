<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-11-17 00:36:59 --> Config Class Initialized
DEBUG - 2012-11-17 00:36:59 --> Hooks Class Initialized
DEBUG - 2012-11-17 00:36:59 --> Utf8 Class Initialized
DEBUG - 2012-11-17 00:36:59 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 00:36:59 --> URI Class Initialized
DEBUG - 2012-11-17 00:36:59 --> Router Class Initialized
DEBUG - 2012-11-17 00:36:59 --> Output Class Initialized
DEBUG - 2012-11-17 00:36:59 --> Security Class Initialized
DEBUG - 2012-11-17 00:36:59 --> Input Class Initialized
DEBUG - 2012-11-17 00:36:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 00:36:59 --> Language Class Initialized
DEBUG - 2012-11-17 00:36:59 --> Loader Class Initialized
DEBUG - 2012-11-17 00:36:59 --> Helper loaded: url_helper
DEBUG - 2012-11-17 00:36:59 --> Controller Class Initialized
DEBUG - 2012-11-17 00:36:59 --> Model Class Initialized
DEBUG - 2012-11-17 00:37:00 --> Database Driver Class Initialized
DEBUG - 2012-11-17 00:37:00 --> Helper loaded: form_helper
DEBUG - 2012-11-17 00:37:00 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 00:37:00 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 00:40:29 --> Config Class Initialized
DEBUG - 2012-11-17 00:40:29 --> Hooks Class Initialized
DEBUG - 2012-11-17 00:40:29 --> Utf8 Class Initialized
DEBUG - 2012-11-17 00:40:29 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 00:40:29 --> URI Class Initialized
DEBUG - 2012-11-17 00:40:29 --> Router Class Initialized
DEBUG - 2012-11-17 00:40:29 --> Output Class Initialized
DEBUG - 2012-11-17 00:40:29 --> Security Class Initialized
DEBUG - 2012-11-17 00:40:29 --> Input Class Initialized
DEBUG - 2012-11-17 00:40:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 00:40:29 --> Language Class Initialized
DEBUG - 2012-11-17 00:40:29 --> Loader Class Initialized
DEBUG - 2012-11-17 00:40:29 --> Helper loaded: url_helper
DEBUG - 2012-11-17 00:40:29 --> Controller Class Initialized
DEBUG - 2012-11-17 00:40:29 --> Model Class Initialized
DEBUG - 2012-11-17 00:40:29 --> Database Driver Class Initialized
DEBUG - 2012-11-17 00:40:29 --> Helper loaded: form_helper
DEBUG - 2012-11-17 00:40:29 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 00:40:29 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 00:40:31 --> Config Class Initialized
DEBUG - 2012-11-17 00:40:31 --> Hooks Class Initialized
DEBUG - 2012-11-17 00:40:31 --> Utf8 Class Initialized
DEBUG - 2012-11-17 00:40:31 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 00:40:31 --> URI Class Initialized
DEBUG - 2012-11-17 00:40:31 --> Router Class Initialized
DEBUG - 2012-11-17 00:40:31 --> Output Class Initialized
DEBUG - 2012-11-17 00:40:31 --> Security Class Initialized
DEBUG - 2012-11-17 00:40:31 --> Input Class Initialized
DEBUG - 2012-11-17 00:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 00:40:31 --> Language Class Initialized
DEBUG - 2012-11-17 00:40:31 --> Loader Class Initialized
DEBUG - 2012-11-17 00:40:31 --> Helper loaded: url_helper
DEBUG - 2012-11-17 00:40:31 --> Controller Class Initialized
DEBUG - 2012-11-17 00:40:31 --> Model Class Initialized
DEBUG - 2012-11-17 00:40:31 --> Database Driver Class Initialized
DEBUG - 2012-11-17 00:40:31 --> Helper loaded: form_helper
DEBUG - 2012-11-17 00:40:31 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 00:40:31 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 00:40:48 --> Config Class Initialized
DEBUG - 2012-11-17 00:40:48 --> Hooks Class Initialized
DEBUG - 2012-11-17 00:40:48 --> Utf8 Class Initialized
DEBUG - 2012-11-17 00:40:48 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 00:40:48 --> URI Class Initialized
DEBUG - 2012-11-17 00:40:48 --> Router Class Initialized
DEBUG - 2012-11-17 00:40:48 --> Output Class Initialized
DEBUG - 2012-11-17 00:40:48 --> Security Class Initialized
DEBUG - 2012-11-17 00:40:48 --> Input Class Initialized
DEBUG - 2012-11-17 00:40:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 00:40:48 --> Language Class Initialized
DEBUG - 2012-11-17 00:40:48 --> Loader Class Initialized
DEBUG - 2012-11-17 00:40:48 --> Helper loaded: url_helper
DEBUG - 2012-11-17 00:40:48 --> Controller Class Initialized
DEBUG - 2012-11-17 00:40:48 --> Model Class Initialized
DEBUG - 2012-11-17 00:40:48 --> Database Driver Class Initialized
DEBUG - 2012-11-17 00:40:48 --> Helper loaded: form_helper
DEBUG - 2012-11-17 00:40:48 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 00:40:48 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 00:43:19 --> Config Class Initialized
DEBUG - 2012-11-17 00:43:19 --> Hooks Class Initialized
DEBUG - 2012-11-17 00:43:19 --> Utf8 Class Initialized
DEBUG - 2012-11-17 00:43:19 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 00:43:19 --> URI Class Initialized
DEBUG - 2012-11-17 00:43:19 --> Router Class Initialized
DEBUG - 2012-11-17 00:43:19 --> Output Class Initialized
DEBUG - 2012-11-17 00:43:19 --> Security Class Initialized
DEBUG - 2012-11-17 00:43:19 --> Input Class Initialized
DEBUG - 2012-11-17 00:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 00:43:19 --> Language Class Initialized
DEBUG - 2012-11-17 00:43:19 --> Loader Class Initialized
DEBUG - 2012-11-17 00:43:19 --> Helper loaded: url_helper
DEBUG - 2012-11-17 00:43:19 --> Controller Class Initialized
DEBUG - 2012-11-17 00:43:19 --> Model Class Initialized
DEBUG - 2012-11-17 00:43:19 --> Database Driver Class Initialized
DEBUG - 2012-11-17 00:43:19 --> Helper loaded: form_helper
DEBUG - 2012-11-17 00:43:19 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 00:43:19 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 00:44:22 --> Config Class Initialized
DEBUG - 2012-11-17 00:44:22 --> Hooks Class Initialized
DEBUG - 2012-11-17 00:44:22 --> Utf8 Class Initialized
DEBUG - 2012-11-17 00:44:22 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 00:44:22 --> URI Class Initialized
DEBUG - 2012-11-17 00:44:22 --> Router Class Initialized
DEBUG - 2012-11-17 00:44:22 --> Output Class Initialized
DEBUG - 2012-11-17 00:44:22 --> Security Class Initialized
DEBUG - 2012-11-17 00:44:22 --> Input Class Initialized
DEBUG - 2012-11-17 00:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 00:44:22 --> Language Class Initialized
DEBUG - 2012-11-17 00:44:22 --> Loader Class Initialized
DEBUG - 2012-11-17 00:44:22 --> Helper loaded: url_helper
DEBUG - 2012-11-17 00:44:22 --> Controller Class Initialized
DEBUG - 2012-11-17 00:44:22 --> Model Class Initialized
DEBUG - 2012-11-17 00:44:22 --> Database Driver Class Initialized
DEBUG - 2012-11-17 00:44:22 --> Helper loaded: form_helper
DEBUG - 2012-11-17 00:44:22 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 00:44:22 --> File loaded: application/views/admin/templates/left_menu.php
ERROR - 2012-11-17 00:44:22 --> Severity: Notice  --> Undefined variable: print /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/prints.php 80
ERROR - 2012-11-17 00:44:22 --> Severity: Notice  --> Trying to get property of non-object /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/prints.php 80
ERROR - 2012-11-17 00:44:22 --> Severity: Notice  --> Undefined variable: print /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/prints.php 80
ERROR - 2012-11-17 00:44:22 --> Severity: Notice  --> Trying to get property of non-object /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/prints.php 80
ERROR - 2012-11-17 00:44:22 --> Severity: Notice  --> Undefined variable: print /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/prints.php 80
ERROR - 2012-11-17 00:44:22 --> Severity: Notice  --> Trying to get property of non-object /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/prints.php 80
ERROR - 2012-11-17 00:44:22 --> Severity: Notice  --> Use of undefined constant unit_symbol - assumed 'unit_symbol' /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/prints.php 80
ERROR - 2012-11-17 00:44:22 --> Severity: Notice  --> Undefined variable: print /home/jwp/www/justinwylliephotography.com/clients/application/views/admin/pages/pricing/prints.php 80
DEBUG - 2012-11-17 00:44:22 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 00:44:22 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 00:44:22 --> Final output sent to browser
DEBUG - 2012-11-17 00:44:22 --> Total execution time: 0.0890
DEBUG - 2012-11-17 00:44:24 --> Config Class Initialized
DEBUG - 2012-11-17 00:44:24 --> Hooks Class Initialized
DEBUG - 2012-11-17 00:44:24 --> Utf8 Class Initialized
DEBUG - 2012-11-17 00:44:24 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 00:44:24 --> URI Class Initialized
DEBUG - 2012-11-17 00:44:24 --> Router Class Initialized
ERROR - 2012-11-17 00:44:24 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 00:44:24 --> Config Class Initialized
DEBUG - 2012-11-17 00:44:24 --> Hooks Class Initialized
DEBUG - 2012-11-17 00:44:24 --> Utf8 Class Initialized
DEBUG - 2012-11-17 00:44:24 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 00:44:24 --> URI Class Initialized
DEBUG - 2012-11-17 00:44:24 --> Router Class Initialized
ERROR - 2012-11-17 00:44:24 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 00:52:52 --> Config Class Initialized
DEBUG - 2012-11-17 00:52:52 --> Hooks Class Initialized
DEBUG - 2012-11-17 00:52:52 --> Utf8 Class Initialized
DEBUG - 2012-11-17 00:52:52 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 00:52:52 --> URI Class Initialized
DEBUG - 2012-11-17 00:52:52 --> Router Class Initialized
DEBUG - 2012-11-17 00:52:53 --> Output Class Initialized
DEBUG - 2012-11-17 00:52:53 --> Security Class Initialized
DEBUG - 2012-11-17 00:52:53 --> Input Class Initialized
DEBUG - 2012-11-17 00:52:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 00:52:53 --> Language Class Initialized
DEBUG - 2012-11-17 00:52:53 --> Loader Class Initialized
DEBUG - 2012-11-17 00:52:53 --> Helper loaded: url_helper
DEBUG - 2012-11-17 00:52:53 --> Controller Class Initialized
DEBUG - 2012-11-17 00:52:53 --> Model Class Initialized
DEBUG - 2012-11-17 00:52:53 --> Database Driver Class Initialized
DEBUG - 2012-11-17 00:52:53 --> Helper loaded: form_helper
DEBUG - 2012-11-17 00:52:53 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 00:52:53 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 00:52:53 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 00:52:53 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 00:52:53 --> Final output sent to browser
DEBUG - 2012-11-17 00:52:53 --> Total execution time: 0.0486
DEBUG - 2012-11-17 00:52:55 --> Config Class Initialized
DEBUG - 2012-11-17 00:52:55 --> Hooks Class Initialized
DEBUG - 2012-11-17 00:52:55 --> Utf8 Class Initialized
DEBUG - 2012-11-17 00:52:55 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 00:52:55 --> URI Class Initialized
DEBUG - 2012-11-17 00:52:55 --> Router Class Initialized
ERROR - 2012-11-17 00:52:55 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 00:52:55 --> Config Class Initialized
DEBUG - 2012-11-17 00:52:55 --> Hooks Class Initialized
DEBUG - 2012-11-17 00:52:55 --> Utf8 Class Initialized
DEBUG - 2012-11-17 00:52:55 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 00:52:55 --> URI Class Initialized
DEBUG - 2012-11-17 00:52:55 --> Router Class Initialized
ERROR - 2012-11-17 00:52:55 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 00:52:55 --> Config Class Initialized
DEBUG - 2012-11-17 00:52:55 --> Hooks Class Initialized
DEBUG - 2012-11-17 00:52:55 --> Utf8 Class Initialized
DEBUG - 2012-11-17 00:52:55 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 00:52:55 --> URI Class Initialized
DEBUG - 2012-11-17 00:52:55 --> Router Class Initialized
ERROR - 2012-11-17 00:52:55 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 01:42:50 --> Config Class Initialized
DEBUG - 2012-11-17 01:42:50 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:42:50 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:42:50 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:42:50 --> URI Class Initialized
DEBUG - 2012-11-17 01:42:50 --> Router Class Initialized
DEBUG - 2012-11-17 01:42:50 --> Output Class Initialized
DEBUG - 2012-11-17 01:42:50 --> Security Class Initialized
DEBUG - 2012-11-17 01:42:50 --> Input Class Initialized
DEBUG - 2012-11-17 01:42:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 01:42:50 --> Language Class Initialized
DEBUG - 2012-11-17 01:42:50 --> Loader Class Initialized
DEBUG - 2012-11-17 01:42:50 --> Helper loaded: url_helper
DEBUG - 2012-11-17 01:42:50 --> Controller Class Initialized
DEBUG - 2012-11-17 01:42:50 --> Model Class Initialized
DEBUG - 2012-11-17 01:42:50 --> Database Driver Class Initialized
DEBUG - 2012-11-17 01:42:50 --> Helper loaded: form_helper
DEBUG - 2012-11-17 01:42:50 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 01:42:50 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 01:42:50 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 01:42:50 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 01:42:50 --> Final output sent to browser
DEBUG - 2012-11-17 01:42:50 --> Total execution time: 0.0485
DEBUG - 2012-11-17 01:42:52 --> Config Class Initialized
DEBUG - 2012-11-17 01:42:52 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:42:52 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:42:52 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:42:52 --> URI Class Initialized
DEBUG - 2012-11-17 01:42:52 --> Router Class Initialized
ERROR - 2012-11-17 01:42:52 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 01:42:52 --> Config Class Initialized
DEBUG - 2012-11-17 01:42:52 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:42:52 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:42:52 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:42:52 --> URI Class Initialized
DEBUG - 2012-11-17 01:42:52 --> Router Class Initialized
ERROR - 2012-11-17 01:42:52 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 01:42:52 --> Config Class Initialized
DEBUG - 2012-11-17 01:42:52 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:42:52 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:42:52 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:42:52 --> URI Class Initialized
DEBUG - 2012-11-17 01:42:52 --> Router Class Initialized
ERROR - 2012-11-17 01:42:52 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 01:45:11 --> Config Class Initialized
DEBUG - 2012-11-17 01:45:11 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:45:11 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:45:11 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:45:11 --> URI Class Initialized
DEBUG - 2012-11-17 01:45:11 --> Router Class Initialized
DEBUG - 2012-11-17 01:45:11 --> Output Class Initialized
DEBUG - 2012-11-17 01:45:11 --> Security Class Initialized
DEBUG - 2012-11-17 01:45:11 --> Input Class Initialized
DEBUG - 2012-11-17 01:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 01:45:11 --> Language Class Initialized
DEBUG - 2012-11-17 01:45:11 --> Loader Class Initialized
DEBUG - 2012-11-17 01:45:11 --> Helper loaded: url_helper
DEBUG - 2012-11-17 01:45:11 --> Controller Class Initialized
DEBUG - 2012-11-17 01:45:11 --> Model Class Initialized
DEBUG - 2012-11-17 01:45:11 --> Database Driver Class Initialized
DEBUG - 2012-11-17 01:45:11 --> Helper loaded: form_helper
DEBUG - 2012-11-17 01:45:11 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 01:45:11 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 01:45:11 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 01:45:11 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 01:45:11 --> Final output sent to browser
DEBUG - 2012-11-17 01:45:11 --> Total execution time: 0.0546
DEBUG - 2012-11-17 01:45:13 --> Config Class Initialized
DEBUG - 2012-11-17 01:45:13 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:45:13 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:45:13 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:45:13 --> URI Class Initialized
DEBUG - 2012-11-17 01:45:13 --> Router Class Initialized
ERROR - 2012-11-17 01:45:13 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 01:45:13 --> Config Class Initialized
DEBUG - 2012-11-17 01:45:13 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:45:13 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:45:13 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:45:13 --> URI Class Initialized
DEBUG - 2012-11-17 01:45:13 --> Router Class Initialized
ERROR - 2012-11-17 01:45:13 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 01:45:13 --> Config Class Initialized
DEBUG - 2012-11-17 01:45:13 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:45:13 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:45:13 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:45:13 --> URI Class Initialized
DEBUG - 2012-11-17 01:45:13 --> Router Class Initialized
ERROR - 2012-11-17 01:45:13 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 01:45:16 --> Config Class Initialized
DEBUG - 2012-11-17 01:45:16 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:45:16 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:45:16 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:45:16 --> URI Class Initialized
DEBUG - 2012-11-17 01:45:16 --> Router Class Initialized
DEBUG - 2012-11-17 01:45:16 --> Output Class Initialized
DEBUG - 2012-11-17 01:45:16 --> Security Class Initialized
DEBUG - 2012-11-17 01:45:16 --> Input Class Initialized
DEBUG - 2012-11-17 01:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 01:45:16 --> Language Class Initialized
DEBUG - 2012-11-17 01:45:16 --> Loader Class Initialized
DEBUG - 2012-11-17 01:45:16 --> Helper loaded: url_helper
DEBUG - 2012-11-17 01:45:16 --> Controller Class Initialized
DEBUG - 2012-11-17 01:45:16 --> Model Class Initialized
DEBUG - 2012-11-17 01:45:16 --> Database Driver Class Initialized
DEBUG - 2012-11-17 01:45:16 --> Helper loaded: form_helper
DEBUG - 2012-11-17 01:45:16 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 01:45:16 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 01:45:16 --> File loaded: application/views/admin/pages/pricing/frame_types.php
DEBUG - 2012-11-17 01:45:16 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 01:45:16 --> Final output sent to browser
DEBUG - 2012-11-17 01:45:16 --> Total execution time: 0.1207
DEBUG - 2012-11-17 01:45:18 --> Config Class Initialized
DEBUG - 2012-11-17 01:45:18 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:45:18 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:45:18 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:45:18 --> URI Class Initialized
DEBUG - 2012-11-17 01:45:18 --> Router Class Initialized
ERROR - 2012-11-17 01:45:18 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 01:45:18 --> Config Class Initialized
DEBUG - 2012-11-17 01:45:18 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:45:18 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:45:18 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:45:18 --> URI Class Initialized
DEBUG - 2012-11-17 01:45:18 --> Router Class Initialized
ERROR - 2012-11-17 01:45:18 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 01:45:18 --> Config Class Initialized
DEBUG - 2012-11-17 01:45:18 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:45:18 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:45:18 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:45:18 --> URI Class Initialized
DEBUG - 2012-11-17 01:45:18 --> Router Class Initialized
ERROR - 2012-11-17 01:45:18 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 01:45:20 --> Config Class Initialized
DEBUG - 2012-11-17 01:45:20 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:45:20 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:45:20 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:45:20 --> URI Class Initialized
DEBUG - 2012-11-17 01:45:20 --> Router Class Initialized
DEBUG - 2012-11-17 01:45:20 --> Output Class Initialized
DEBUG - 2012-11-17 01:45:20 --> Security Class Initialized
DEBUG - 2012-11-17 01:45:20 --> Input Class Initialized
DEBUG - 2012-11-17 01:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 01:45:20 --> Language Class Initialized
DEBUG - 2012-11-17 01:45:20 --> Loader Class Initialized
DEBUG - 2012-11-17 01:45:20 --> Helper loaded: url_helper
DEBUG - 2012-11-17 01:45:20 --> Controller Class Initialized
DEBUG - 2012-11-17 01:45:20 --> Model Class Initialized
DEBUG - 2012-11-17 01:45:20 --> Database Driver Class Initialized
DEBUG - 2012-11-17 01:45:20 --> Helper loaded: language_helper
DEBUG - 2012-11-17 01:45:20 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-11-17 01:45:26 --> Config Class Initialized
DEBUG - 2012-11-17 01:45:26 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:45:26 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:45:26 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:45:26 --> URI Class Initialized
DEBUG - 2012-11-17 01:45:26 --> Router Class Initialized
DEBUG - 2012-11-17 01:45:26 --> Output Class Initialized
DEBUG - 2012-11-17 01:45:26 --> Security Class Initialized
DEBUG - 2012-11-17 01:45:26 --> Input Class Initialized
DEBUG - 2012-11-17 01:45:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 01:45:26 --> Language Class Initialized
DEBUG - 2012-11-17 01:45:26 --> Loader Class Initialized
DEBUG - 2012-11-17 01:45:26 --> Helper loaded: url_helper
DEBUG - 2012-11-17 01:45:26 --> Controller Class Initialized
DEBUG - 2012-11-17 01:45:26 --> Model Class Initialized
DEBUG - 2012-11-17 01:45:26 --> Database Driver Class Initialized
DEBUG - 2012-11-17 01:45:26 --> Helper loaded: form_helper
DEBUG - 2012-11-17 01:45:26 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 01:45:26 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 01:45:26 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 01:45:26 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 01:45:27 --> Final output sent to browser
DEBUG - 2012-11-17 01:45:27 --> Total execution time: 0.0536
DEBUG - 2012-11-17 01:45:29 --> Config Class Initialized
DEBUG - 2012-11-17 01:45:29 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:45:29 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:45:29 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:45:29 --> URI Class Initialized
DEBUG - 2012-11-17 01:45:29 --> Router Class Initialized
ERROR - 2012-11-17 01:45:29 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 01:45:29 --> Config Class Initialized
DEBUG - 2012-11-17 01:45:29 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:45:29 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:45:29 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:45:29 --> URI Class Initialized
DEBUG - 2012-11-17 01:45:29 --> Router Class Initialized
ERROR - 2012-11-17 01:45:29 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 01:45:29 --> Config Class Initialized
DEBUG - 2012-11-17 01:45:29 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:45:29 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:45:29 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:45:29 --> URI Class Initialized
DEBUG - 2012-11-17 01:45:29 --> Router Class Initialized
ERROR - 2012-11-17 01:45:29 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 01:48:45 --> Config Class Initialized
DEBUG - 2012-11-17 01:48:45 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:48:45 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:48:45 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:48:45 --> URI Class Initialized
DEBUG - 2012-11-17 01:48:45 --> Router Class Initialized
DEBUG - 2012-11-17 01:48:45 --> Output Class Initialized
DEBUG - 2012-11-17 01:48:45 --> Security Class Initialized
DEBUG - 2012-11-17 01:48:45 --> Input Class Initialized
DEBUG - 2012-11-17 01:48:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 01:48:45 --> Language Class Initialized
DEBUG - 2012-11-17 01:48:45 --> Loader Class Initialized
DEBUG - 2012-11-17 01:48:45 --> Helper loaded: url_helper
DEBUG - 2012-11-17 01:48:45 --> Controller Class Initialized
DEBUG - 2012-11-17 01:48:45 --> Model Class Initialized
DEBUG - 2012-11-17 01:48:45 --> Database Driver Class Initialized
DEBUG - 2012-11-17 01:48:45 --> Helper loaded: form_helper
DEBUG - 2012-11-17 01:48:45 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 01:48:45 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 01:48:45 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 01:48:45 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 01:48:45 --> Final output sent to browser
DEBUG - 2012-11-17 01:48:45 --> Total execution time: 0.0486
DEBUG - 2012-11-17 01:48:47 --> Config Class Initialized
DEBUG - 2012-11-17 01:48:47 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:48:47 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:48:47 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:48:47 --> URI Class Initialized
DEBUG - 2012-11-17 01:48:47 --> Router Class Initialized
ERROR - 2012-11-17 01:48:47 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 01:48:47 --> Config Class Initialized
DEBUG - 2012-11-17 01:48:47 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:48:47 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:48:47 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:48:47 --> URI Class Initialized
DEBUG - 2012-11-17 01:48:47 --> Router Class Initialized
ERROR - 2012-11-17 01:48:47 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 01:48:47 --> Config Class Initialized
DEBUG - 2012-11-17 01:48:47 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:48:47 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:48:47 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:48:47 --> URI Class Initialized
DEBUG - 2012-11-17 01:48:47 --> Router Class Initialized
ERROR - 2012-11-17 01:48:47 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 01:50:19 --> Config Class Initialized
DEBUG - 2012-11-17 01:50:19 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:50:19 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:50:19 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:50:19 --> URI Class Initialized
DEBUG - 2012-11-17 01:50:19 --> Router Class Initialized
DEBUG - 2012-11-17 01:50:19 --> Output Class Initialized
DEBUG - 2012-11-17 01:50:19 --> Security Class Initialized
DEBUG - 2012-11-17 01:50:19 --> Input Class Initialized
DEBUG - 2012-11-17 01:50:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 01:50:19 --> Language Class Initialized
DEBUG - 2012-11-17 01:50:19 --> Loader Class Initialized
DEBUG - 2012-11-17 01:50:19 --> Helper loaded: url_helper
DEBUG - 2012-11-17 01:50:19 --> Controller Class Initialized
DEBUG - 2012-11-17 01:50:19 --> Model Class Initialized
DEBUG - 2012-11-17 01:50:19 --> Database Driver Class Initialized
DEBUG - 2012-11-17 01:50:20 --> Helper loaded: form_helper
DEBUG - 2012-11-17 01:50:20 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 01:50:20 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 01:50:20 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 01:50:20 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 01:50:20 --> Final output sent to browser
DEBUG - 2012-11-17 01:50:20 --> Total execution time: 0.0480
DEBUG - 2012-11-17 01:50:22 --> Config Class Initialized
DEBUG - 2012-11-17 01:50:22 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:50:22 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:50:22 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:50:22 --> URI Class Initialized
DEBUG - 2012-11-17 01:50:22 --> Router Class Initialized
ERROR - 2012-11-17 01:50:22 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 01:50:22 --> Config Class Initialized
DEBUG - 2012-11-17 01:50:22 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:50:22 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:50:22 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:50:22 --> URI Class Initialized
DEBUG - 2012-11-17 01:50:22 --> Router Class Initialized
ERROR - 2012-11-17 01:50:22 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 01:50:22 --> Config Class Initialized
DEBUG - 2012-11-17 01:50:22 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:50:22 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:50:22 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:50:22 --> URI Class Initialized
DEBUG - 2012-11-17 01:50:22 --> Router Class Initialized
ERROR - 2012-11-17 01:50:22 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 01:52:01 --> Config Class Initialized
DEBUG - 2012-11-17 01:52:01 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:52:01 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:52:01 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:52:01 --> URI Class Initialized
DEBUG - 2012-11-17 01:52:01 --> Router Class Initialized
DEBUG - 2012-11-17 01:52:01 --> Output Class Initialized
DEBUG - 2012-11-17 01:52:01 --> Security Class Initialized
DEBUG - 2012-11-17 01:52:01 --> Input Class Initialized
DEBUG - 2012-11-17 01:52:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 01:52:01 --> Language Class Initialized
DEBUG - 2012-11-17 01:52:01 --> Loader Class Initialized
DEBUG - 2012-11-17 01:52:01 --> Helper loaded: url_helper
DEBUG - 2012-11-17 01:52:01 --> Controller Class Initialized
DEBUG - 2012-11-17 01:52:01 --> Model Class Initialized
DEBUG - 2012-11-17 01:52:01 --> Database Driver Class Initialized
DEBUG - 2012-11-17 01:52:01 --> Helper loaded: form_helper
DEBUG - 2012-11-17 01:52:01 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 01:52:01 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 01:52:01 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 01:52:01 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 01:52:01 --> Final output sent to browser
DEBUG - 2012-11-17 01:52:01 --> Total execution time: 0.0551
DEBUG - 2012-11-17 01:52:03 --> Config Class Initialized
DEBUG - 2012-11-17 01:52:03 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:52:03 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:52:03 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:52:03 --> URI Class Initialized
DEBUG - 2012-11-17 01:52:03 --> Router Class Initialized
ERROR - 2012-11-17 01:52:03 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 01:52:03 --> Config Class Initialized
DEBUG - 2012-11-17 01:52:03 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:52:03 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:52:03 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:52:03 --> URI Class Initialized
DEBUG - 2012-11-17 01:52:03 --> Router Class Initialized
ERROR - 2012-11-17 01:52:03 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 01:52:03 --> Config Class Initialized
DEBUG - 2012-11-17 01:52:03 --> Hooks Class Initialized
DEBUG - 2012-11-17 01:52:03 --> Utf8 Class Initialized
DEBUG - 2012-11-17 01:52:03 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 01:52:03 --> URI Class Initialized
DEBUG - 2012-11-17 01:52:03 --> Router Class Initialized
ERROR - 2012-11-17 01:52:03 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:00:10 --> Config Class Initialized
DEBUG - 2012-11-17 02:00:10 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:00:10 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:00:10 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:00:10 --> URI Class Initialized
DEBUG - 2012-11-17 02:00:10 --> Router Class Initialized
DEBUG - 2012-11-17 02:00:10 --> Output Class Initialized
DEBUG - 2012-11-17 02:00:10 --> Security Class Initialized
DEBUG - 2012-11-17 02:00:10 --> Input Class Initialized
DEBUG - 2012-11-17 02:00:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:00:10 --> Language Class Initialized
DEBUG - 2012-11-17 02:00:10 --> Loader Class Initialized
DEBUG - 2012-11-17 02:00:10 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:00:10 --> Controller Class Initialized
DEBUG - 2012-11-17 02:00:10 --> Model Class Initialized
DEBUG - 2012-11-17 02:00:10 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:00:10 --> Helper loaded: form_helper
DEBUG - 2012-11-17 02:00:10 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 02:00:10 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 02:00:10 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 02:00:10 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 02:00:10 --> Final output sent to browser
DEBUG - 2012-11-17 02:00:10 --> Total execution time: 0.0561
DEBUG - 2012-11-17 02:00:12 --> Config Class Initialized
DEBUG - 2012-11-17 02:00:12 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:00:12 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:00:12 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:00:12 --> URI Class Initialized
DEBUG - 2012-11-17 02:00:12 --> Router Class Initialized
ERROR - 2012-11-17 02:00:12 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:00:12 --> Config Class Initialized
DEBUG - 2012-11-17 02:00:12 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:00:12 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:00:12 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:00:12 --> URI Class Initialized
DEBUG - 2012-11-17 02:00:12 --> Router Class Initialized
ERROR - 2012-11-17 02:00:12 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:00:12 --> Config Class Initialized
DEBUG - 2012-11-17 02:00:12 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:00:12 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:00:12 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:00:12 --> URI Class Initialized
DEBUG - 2012-11-17 02:00:12 --> Router Class Initialized
ERROR - 2012-11-17 02:00:12 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:10:23 --> Config Class Initialized
DEBUG - 2012-11-17 02:10:23 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:10:23 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:10:23 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:10:23 --> URI Class Initialized
DEBUG - 2012-11-17 02:10:23 --> Router Class Initialized
DEBUG - 2012-11-17 02:10:23 --> Output Class Initialized
DEBUG - 2012-11-17 02:10:23 --> Security Class Initialized
DEBUG - 2012-11-17 02:10:23 --> Input Class Initialized
DEBUG - 2012-11-17 02:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:10:23 --> Language Class Initialized
DEBUG - 2012-11-17 02:10:23 --> Loader Class Initialized
DEBUG - 2012-11-17 02:10:23 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:10:23 --> Controller Class Initialized
DEBUG - 2012-11-17 02:10:23 --> Model Class Initialized
DEBUG - 2012-11-17 02:10:23 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:10:23 --> Helper loaded: form_helper
DEBUG - 2012-11-17 02:10:23 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 02:10:23 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 02:10:23 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 02:10:23 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 02:10:23 --> Final output sent to browser
DEBUG - 2012-11-17 02:10:23 --> Total execution time: 0.0431
DEBUG - 2012-11-17 02:10:25 --> Config Class Initialized
DEBUG - 2012-11-17 02:10:25 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:10:25 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:10:25 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:10:25 --> URI Class Initialized
DEBUG - 2012-11-17 02:10:25 --> Router Class Initialized
ERROR - 2012-11-17 02:10:25 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:10:25 --> Config Class Initialized
DEBUG - 2012-11-17 02:10:25 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:10:25 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:10:25 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:10:25 --> URI Class Initialized
DEBUG - 2012-11-17 02:10:25 --> Router Class Initialized
ERROR - 2012-11-17 02:10:25 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:10:25 --> Config Class Initialized
DEBUG - 2012-11-17 02:10:25 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:10:25 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:10:25 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:10:25 --> URI Class Initialized
DEBUG - 2012-11-17 02:10:25 --> Router Class Initialized
ERROR - 2012-11-17 02:10:25 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:10:48 --> Config Class Initialized
DEBUG - 2012-11-17 02:10:48 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:10:48 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:10:48 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:10:48 --> URI Class Initialized
DEBUG - 2012-11-17 02:10:48 --> Router Class Initialized
DEBUG - 2012-11-17 02:10:48 --> Output Class Initialized
DEBUG - 2012-11-17 02:10:48 --> Security Class Initialized
DEBUG - 2012-11-17 02:10:48 --> Input Class Initialized
DEBUG - 2012-11-17 02:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:10:48 --> Language Class Initialized
DEBUG - 2012-11-17 02:10:48 --> Loader Class Initialized
DEBUG - 2012-11-17 02:10:48 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:10:48 --> Controller Class Initialized
DEBUG - 2012-11-17 02:10:48 --> Model Class Initialized
DEBUG - 2012-11-17 02:10:48 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:10:48 --> Helper loaded: form_helper
DEBUG - 2012-11-17 02:10:48 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 02:10:48 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 02:10:48 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 02:10:48 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 02:10:48 --> Final output sent to browser
DEBUG - 2012-11-17 02:10:48 --> Total execution time: 0.0475
DEBUG - 2012-11-17 02:10:50 --> Config Class Initialized
DEBUG - 2012-11-17 02:10:50 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:10:50 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:10:50 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:10:50 --> URI Class Initialized
DEBUG - 2012-11-17 02:10:50 --> Router Class Initialized
ERROR - 2012-11-17 02:10:50 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:10:50 --> Config Class Initialized
DEBUG - 2012-11-17 02:10:50 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:10:50 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:10:50 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:10:50 --> URI Class Initialized
DEBUG - 2012-11-17 02:10:50 --> Router Class Initialized
ERROR - 2012-11-17 02:10:50 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:10:50 --> Config Class Initialized
DEBUG - 2012-11-17 02:10:50 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:10:50 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:10:50 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:10:50 --> URI Class Initialized
DEBUG - 2012-11-17 02:10:50 --> Router Class Initialized
ERROR - 2012-11-17 02:10:50 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:10:53 --> Config Class Initialized
DEBUG - 2012-11-17 02:10:53 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:10:53 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:10:53 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:10:53 --> URI Class Initialized
DEBUG - 2012-11-17 02:10:53 --> Router Class Initialized
DEBUG - 2012-11-17 02:10:53 --> Output Class Initialized
DEBUG - 2012-11-17 02:10:53 --> Security Class Initialized
DEBUG - 2012-11-17 02:10:53 --> Input Class Initialized
DEBUG - 2012-11-17 02:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:10:53 --> Language Class Initialized
DEBUG - 2012-11-17 02:10:53 --> Loader Class Initialized
DEBUG - 2012-11-17 02:10:53 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:10:53 --> Controller Class Initialized
DEBUG - 2012-11-17 02:10:53 --> Model Class Initialized
DEBUG - 2012-11-17 02:10:53 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:10:53 --> Final output sent to browser
DEBUG - 2012-11-17 02:10:53 --> Total execution time: 0.0327
DEBUG - 2012-11-17 02:27:07 --> Config Class Initialized
DEBUG - 2012-11-17 02:27:07 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:27:07 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:27:07 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:27:07 --> URI Class Initialized
DEBUG - 2012-11-17 02:27:07 --> Router Class Initialized
DEBUG - 2012-11-17 02:27:07 --> Output Class Initialized
DEBUG - 2012-11-17 02:27:07 --> Security Class Initialized
DEBUG - 2012-11-17 02:27:07 --> Input Class Initialized
DEBUG - 2012-11-17 02:27:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:27:07 --> Language Class Initialized
DEBUG - 2012-11-17 02:27:07 --> Loader Class Initialized
DEBUG - 2012-11-17 02:27:07 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:27:07 --> Controller Class Initialized
DEBUG - 2012-11-17 02:27:07 --> Model Class Initialized
DEBUG - 2012-11-17 02:27:07 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:27:54 --> Config Class Initialized
DEBUG - 2012-11-17 02:27:54 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:27:54 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:27:54 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:27:54 --> URI Class Initialized
DEBUG - 2012-11-17 02:27:54 --> Router Class Initialized
DEBUG - 2012-11-17 02:27:54 --> Output Class Initialized
DEBUG - 2012-11-17 02:27:54 --> Security Class Initialized
DEBUG - 2012-11-17 02:27:54 --> Input Class Initialized
DEBUG - 2012-11-17 02:27:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:27:54 --> Language Class Initialized
DEBUG - 2012-11-17 02:27:54 --> Loader Class Initialized
DEBUG - 2012-11-17 02:27:54 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:27:54 --> Controller Class Initialized
DEBUG - 2012-11-17 02:27:54 --> Model Class Initialized
DEBUG - 2012-11-17 02:27:54 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:27:54 --> Helper loaded: form_helper
DEBUG - 2012-11-17 02:27:54 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 02:27:54 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 02:27:54 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 02:27:54 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 02:27:54 --> Final output sent to browser
DEBUG - 2012-11-17 02:27:54 --> Total execution time: 0.0535
DEBUG - 2012-11-17 02:27:56 --> Config Class Initialized
DEBUG - 2012-11-17 02:27:56 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:27:56 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:27:56 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:27:56 --> URI Class Initialized
DEBUG - 2012-11-17 02:27:56 --> Router Class Initialized
DEBUG - 2012-11-17 02:27:56 --> Config Class Initialized
DEBUG - 2012-11-17 02:27:56 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:27:56 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:27:56 --> UTF-8 Support Enabled
ERROR - 2012-11-17 02:27:56 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:27:56 --> URI Class Initialized
DEBUG - 2012-11-17 02:27:56 --> Router Class Initialized
ERROR - 2012-11-17 02:27:56 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:27:57 --> Config Class Initialized
DEBUG - 2012-11-17 02:27:57 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:27:57 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:27:57 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:27:57 --> URI Class Initialized
DEBUG - 2012-11-17 02:27:57 --> Router Class Initialized
DEBUG - 2012-11-17 02:27:57 --> Output Class Initialized
DEBUG - 2012-11-17 02:27:57 --> Security Class Initialized
DEBUG - 2012-11-17 02:27:57 --> Input Class Initialized
DEBUG - 2012-11-17 02:27:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:27:57 --> Language Class Initialized
DEBUG - 2012-11-17 02:27:57 --> Loader Class Initialized
DEBUG - 2012-11-17 02:27:57 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:27:57 --> Controller Class Initialized
DEBUG - 2012-11-17 02:27:57 --> Model Class Initialized
DEBUG - 2012-11-17 02:27:57 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:30:47 --> Config Class Initialized
DEBUG - 2012-11-17 02:30:47 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:30:47 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:30:47 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:30:47 --> URI Class Initialized
DEBUG - 2012-11-17 02:30:47 --> Router Class Initialized
DEBUG - 2012-11-17 02:30:47 --> Output Class Initialized
DEBUG - 2012-11-17 02:30:47 --> Security Class Initialized
DEBUG - 2012-11-17 02:30:47 --> Input Class Initialized
DEBUG - 2012-11-17 02:30:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:30:47 --> Language Class Initialized
DEBUG - 2012-11-17 02:30:47 --> Loader Class Initialized
DEBUG - 2012-11-17 02:30:47 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:30:47 --> Controller Class Initialized
DEBUG - 2012-11-17 02:30:47 --> Model Class Initialized
DEBUG - 2012-11-17 02:30:47 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:30:47 --> Helper loaded: form_helper
DEBUG - 2012-11-17 02:30:47 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 02:30:47 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 02:30:47 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 02:30:47 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 02:30:48 --> Final output sent to browser
DEBUG - 2012-11-17 02:30:48 --> Total execution time: 0.0550
DEBUG - 2012-11-17 02:30:50 --> Config Class Initialized
DEBUG - 2012-11-17 02:30:50 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:30:50 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:30:50 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:30:50 --> URI Class Initialized
DEBUG - 2012-11-17 02:30:50 --> Router Class Initialized
ERROR - 2012-11-17 02:30:50 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:30:50 --> Config Class Initialized
DEBUG - 2012-11-17 02:30:50 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:30:50 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:30:50 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:30:50 --> URI Class Initialized
DEBUG - 2012-11-17 02:30:50 --> Router Class Initialized
ERROR - 2012-11-17 02:30:50 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:30:50 --> Config Class Initialized
DEBUG - 2012-11-17 02:30:50 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:30:50 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:30:50 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:30:50 --> URI Class Initialized
DEBUG - 2012-11-17 02:30:50 --> Router Class Initialized
ERROR - 2012-11-17 02:30:50 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:30:50 --> Config Class Initialized
DEBUG - 2012-11-17 02:30:50 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:30:50 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:30:50 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:30:50 --> URI Class Initialized
DEBUG - 2012-11-17 02:30:50 --> Router Class Initialized
DEBUG - 2012-11-17 02:30:50 --> Output Class Initialized
DEBUG - 2012-11-17 02:30:50 --> Security Class Initialized
DEBUG - 2012-11-17 02:30:50 --> Input Class Initialized
DEBUG - 2012-11-17 02:30:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:30:50 --> Language Class Initialized
DEBUG - 2012-11-17 02:30:50 --> Loader Class Initialized
DEBUG - 2012-11-17 02:30:50 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:30:50 --> Controller Class Initialized
DEBUG - 2012-11-17 02:30:50 --> Model Class Initialized
DEBUG - 2012-11-17 02:30:50 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:31:38 --> Config Class Initialized
DEBUG - 2012-11-17 02:31:38 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:31:38 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:31:38 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:31:38 --> URI Class Initialized
DEBUG - 2012-11-17 02:31:38 --> Router Class Initialized
DEBUG - 2012-11-17 02:31:38 --> Output Class Initialized
DEBUG - 2012-11-17 02:31:38 --> Security Class Initialized
DEBUG - 2012-11-17 02:31:38 --> Input Class Initialized
DEBUG - 2012-11-17 02:31:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:31:38 --> Language Class Initialized
DEBUG - 2012-11-17 02:31:38 --> Loader Class Initialized
DEBUG - 2012-11-17 02:31:38 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:31:38 --> Controller Class Initialized
DEBUG - 2012-11-17 02:31:38 --> Model Class Initialized
DEBUG - 2012-11-17 02:31:38 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:31:38 --> Helper loaded: form_helper
DEBUG - 2012-11-17 02:31:38 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 02:31:38 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 02:31:38 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 02:31:38 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 02:31:38 --> Final output sent to browser
DEBUG - 2012-11-17 02:31:38 --> Total execution time: 0.0430
DEBUG - 2012-11-17 02:31:40 --> Config Class Initialized
DEBUG - 2012-11-17 02:31:40 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:31:40 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:31:40 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:31:40 --> URI Class Initialized
DEBUG - 2012-11-17 02:31:40 --> Router Class Initialized
ERROR - 2012-11-17 02:31:40 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:31:40 --> Config Class Initialized
DEBUG - 2012-11-17 02:31:40 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:31:40 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:31:40 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:31:40 --> URI Class Initialized
DEBUG - 2012-11-17 02:31:40 --> Router Class Initialized
ERROR - 2012-11-17 02:31:40 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:31:40 --> Config Class Initialized
DEBUG - 2012-11-17 02:31:40 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:31:40 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:31:40 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:31:40 --> URI Class Initialized
DEBUG - 2012-11-17 02:31:40 --> Router Class Initialized
ERROR - 2012-11-17 02:31:40 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:31:41 --> Config Class Initialized
DEBUG - 2012-11-17 02:31:41 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:31:41 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:31:41 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:31:41 --> URI Class Initialized
DEBUG - 2012-11-17 02:31:41 --> Router Class Initialized
DEBUG - 2012-11-17 02:31:41 --> Output Class Initialized
DEBUG - 2012-11-17 02:31:41 --> Security Class Initialized
DEBUG - 2012-11-17 02:31:41 --> Input Class Initialized
DEBUG - 2012-11-17 02:31:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:31:41 --> Language Class Initialized
DEBUG - 2012-11-17 02:31:41 --> Loader Class Initialized
DEBUG - 2012-11-17 02:31:41 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:31:41 --> Controller Class Initialized
DEBUG - 2012-11-17 02:31:41 --> Model Class Initialized
DEBUG - 2012-11-17 02:31:41 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:34:31 --> Config Class Initialized
DEBUG - 2012-11-17 02:34:31 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:34:31 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:34:31 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:34:31 --> URI Class Initialized
DEBUG - 2012-11-17 02:34:31 --> Router Class Initialized
DEBUG - 2012-11-17 02:34:31 --> Output Class Initialized
DEBUG - 2012-11-17 02:34:31 --> Security Class Initialized
DEBUG - 2012-11-17 02:34:31 --> Input Class Initialized
DEBUG - 2012-11-17 02:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:34:31 --> Language Class Initialized
DEBUG - 2012-11-17 02:34:31 --> Loader Class Initialized
DEBUG - 2012-11-17 02:34:31 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:34:31 --> Controller Class Initialized
DEBUG - 2012-11-17 02:34:31 --> Model Class Initialized
DEBUG - 2012-11-17 02:34:31 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:34:49 --> Config Class Initialized
DEBUG - 2012-11-17 02:34:49 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:34:49 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:34:49 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:34:49 --> URI Class Initialized
DEBUG - 2012-11-17 02:34:49 --> Router Class Initialized
DEBUG - 2012-11-17 02:34:49 --> Output Class Initialized
DEBUG - 2012-11-17 02:34:49 --> Security Class Initialized
DEBUG - 2012-11-17 02:34:49 --> Input Class Initialized
DEBUG - 2012-11-17 02:34:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:34:49 --> Language Class Initialized
DEBUG - 2012-11-17 02:34:49 --> Loader Class Initialized
DEBUG - 2012-11-17 02:34:49 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:34:49 --> Controller Class Initialized
DEBUG - 2012-11-17 02:34:49 --> Model Class Initialized
DEBUG - 2012-11-17 02:34:49 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:34:51 --> Config Class Initialized
DEBUG - 2012-11-17 02:34:51 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:34:51 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:34:51 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:34:51 --> URI Class Initialized
DEBUG - 2012-11-17 02:34:51 --> Router Class Initialized
DEBUG - 2012-11-17 02:34:51 --> Output Class Initialized
DEBUG - 2012-11-17 02:34:51 --> Security Class Initialized
DEBUG - 2012-11-17 02:34:51 --> Input Class Initialized
DEBUG - 2012-11-17 02:34:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:34:51 --> Language Class Initialized
DEBUG - 2012-11-17 02:34:51 --> Loader Class Initialized
DEBUG - 2012-11-17 02:34:51 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:34:51 --> Controller Class Initialized
DEBUG - 2012-11-17 02:34:51 --> Model Class Initialized
DEBUG - 2012-11-17 02:34:51 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:35:39 --> Config Class Initialized
DEBUG - 2012-11-17 02:35:39 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:35:39 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:35:39 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:35:39 --> URI Class Initialized
DEBUG - 2012-11-17 02:35:39 --> Router Class Initialized
DEBUG - 2012-11-17 02:35:39 --> Output Class Initialized
DEBUG - 2012-11-17 02:35:39 --> Security Class Initialized
DEBUG - 2012-11-17 02:35:39 --> Input Class Initialized
DEBUG - 2012-11-17 02:35:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:35:39 --> Language Class Initialized
DEBUG - 2012-11-17 02:35:39 --> Loader Class Initialized
DEBUG - 2012-11-17 02:35:39 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:35:39 --> Controller Class Initialized
DEBUG - 2012-11-17 02:35:39 --> Model Class Initialized
DEBUG - 2012-11-17 02:35:39 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:35:39 --> Helper loaded: form_helper
DEBUG - 2012-11-17 02:35:39 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 02:35:39 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 02:35:39 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 02:35:39 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 02:35:39 --> Final output sent to browser
DEBUG - 2012-11-17 02:35:39 --> Total execution time: 0.0437
DEBUG - 2012-11-17 02:35:41 --> Config Class Initialized
DEBUG - 2012-11-17 02:35:41 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:35:41 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:35:41 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:35:41 --> URI Class Initialized
DEBUG - 2012-11-17 02:35:41 --> Router Class Initialized
ERROR - 2012-11-17 02:35:41 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:35:41 --> Config Class Initialized
DEBUG - 2012-11-17 02:35:41 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:35:41 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:35:41 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:35:41 --> URI Class Initialized
DEBUG - 2012-11-17 02:35:41 --> Router Class Initialized
ERROR - 2012-11-17 02:35:41 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:35:41 --> Config Class Initialized
DEBUG - 2012-11-17 02:35:41 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:35:41 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:35:41 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:35:41 --> URI Class Initialized
DEBUG - 2012-11-17 02:35:41 --> Router Class Initialized
ERROR - 2012-11-17 02:35:41 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:35:42 --> Config Class Initialized
DEBUG - 2012-11-17 02:35:42 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:35:42 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:35:42 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:35:42 --> URI Class Initialized
DEBUG - 2012-11-17 02:35:42 --> Router Class Initialized
DEBUG - 2012-11-17 02:35:42 --> Output Class Initialized
DEBUG - 2012-11-17 02:35:42 --> Security Class Initialized
DEBUG - 2012-11-17 02:35:42 --> Input Class Initialized
DEBUG - 2012-11-17 02:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:35:42 --> Language Class Initialized
DEBUG - 2012-11-17 02:35:42 --> Loader Class Initialized
DEBUG - 2012-11-17 02:35:42 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:35:42 --> Controller Class Initialized
DEBUG - 2012-11-17 02:35:42 --> Model Class Initialized
DEBUG - 2012-11-17 02:35:42 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:35:42 --> Final output sent to browser
DEBUG - 2012-11-17 02:35:42 --> Total execution time: 0.0345
DEBUG - 2012-11-17 02:47:58 --> Config Class Initialized
DEBUG - 2012-11-17 02:47:58 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:47:58 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:47:58 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:47:58 --> URI Class Initialized
DEBUG - 2012-11-17 02:47:58 --> Router Class Initialized
DEBUG - 2012-11-17 02:47:58 --> Output Class Initialized
DEBUG - 2012-11-17 02:47:58 --> Security Class Initialized
DEBUG - 2012-11-17 02:47:58 --> Input Class Initialized
DEBUG - 2012-11-17 02:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:47:58 --> Language Class Initialized
DEBUG - 2012-11-17 02:47:58 --> Loader Class Initialized
DEBUG - 2012-11-17 02:47:58 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:47:58 --> Controller Class Initialized
DEBUG - 2012-11-17 02:47:58 --> Model Class Initialized
DEBUG - 2012-11-17 02:47:58 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:47:58 --> Helper loaded: form_helper
DEBUG - 2012-11-17 02:47:58 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 02:47:58 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 02:47:58 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 02:47:58 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 02:47:59 --> Final output sent to browser
DEBUG - 2012-11-17 02:47:59 --> Total execution time: 0.0439
DEBUG - 2012-11-17 02:48:01 --> Config Class Initialized
DEBUG - 2012-11-17 02:48:01 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:48:01 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:48:01 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:48:01 --> URI Class Initialized
DEBUG - 2012-11-17 02:48:01 --> Router Class Initialized
ERROR - 2012-11-17 02:48:01 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:48:01 --> Config Class Initialized
DEBUG - 2012-11-17 02:48:01 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:48:01 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:48:01 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:48:01 --> URI Class Initialized
DEBUG - 2012-11-17 02:48:01 --> Router Class Initialized
ERROR - 2012-11-17 02:48:01 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:48:01 --> Config Class Initialized
DEBUG - 2012-11-17 02:48:01 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:48:01 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:48:01 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:48:01 --> URI Class Initialized
DEBUG - 2012-11-17 02:48:01 --> Router Class Initialized
ERROR - 2012-11-17 02:48:01 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:48:02 --> Config Class Initialized
DEBUG - 2012-11-17 02:48:02 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:48:02 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:48:02 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:48:02 --> URI Class Initialized
DEBUG - 2012-11-17 02:48:02 --> Router Class Initialized
DEBUG - 2012-11-17 02:48:02 --> Output Class Initialized
DEBUG - 2012-11-17 02:48:02 --> Security Class Initialized
DEBUG - 2012-11-17 02:48:02 --> Input Class Initialized
DEBUG - 2012-11-17 02:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:48:02 --> Language Class Initialized
DEBUG - 2012-11-17 02:48:02 --> Loader Class Initialized
DEBUG - 2012-11-17 02:48:02 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:48:02 --> Controller Class Initialized
DEBUG - 2012-11-17 02:48:02 --> Model Class Initialized
DEBUG - 2012-11-17 02:48:02 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:48:02 --> Helper loaded: language_helper
DEBUG - 2012-11-17 02:48:02 --> Language file loaded: language/english/message_lang.php
ERROR - 2012-11-17 02:48:02 --> Could not find the language line "print_deleted"
DEBUG - 2012-11-17 02:51:09 --> Config Class Initialized
DEBUG - 2012-11-17 02:51:09 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:51:09 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:51:09 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:51:09 --> URI Class Initialized
DEBUG - 2012-11-17 02:51:09 --> Router Class Initialized
DEBUG - 2012-11-17 02:51:09 --> Output Class Initialized
DEBUG - 2012-11-17 02:51:09 --> Security Class Initialized
DEBUG - 2012-11-17 02:51:09 --> Input Class Initialized
DEBUG - 2012-11-17 02:51:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:51:09 --> Language Class Initialized
DEBUG - 2012-11-17 02:51:09 --> Loader Class Initialized
DEBUG - 2012-11-17 02:51:09 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:51:09 --> Controller Class Initialized
DEBUG - 2012-11-17 02:51:09 --> Model Class Initialized
DEBUG - 2012-11-17 02:51:09 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:51:09 --> Helper loaded: form_helper
DEBUG - 2012-11-17 02:51:09 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 02:51:09 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 02:51:09 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 02:51:09 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 02:51:09 --> Final output sent to browser
DEBUG - 2012-11-17 02:51:09 --> Total execution time: 0.0435
DEBUG - 2012-11-17 02:51:11 --> Config Class Initialized
DEBUG - 2012-11-17 02:51:11 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:51:11 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:51:11 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:51:11 --> URI Class Initialized
DEBUG - 2012-11-17 02:51:11 --> Router Class Initialized
ERROR - 2012-11-17 02:51:11 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:51:11 --> Config Class Initialized
DEBUG - 2012-11-17 02:51:11 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:51:11 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:51:11 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:51:11 --> URI Class Initialized
DEBUG - 2012-11-17 02:51:11 --> Router Class Initialized
ERROR - 2012-11-17 02:51:11 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:51:11 --> Config Class Initialized
DEBUG - 2012-11-17 02:51:11 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:51:11 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:51:11 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:51:11 --> URI Class Initialized
DEBUG - 2012-11-17 02:51:11 --> Router Class Initialized
ERROR - 2012-11-17 02:51:11 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:51:12 --> Config Class Initialized
DEBUG - 2012-11-17 02:51:12 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:51:12 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:51:12 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:51:12 --> URI Class Initialized
DEBUG - 2012-11-17 02:51:12 --> Router Class Initialized
DEBUG - 2012-11-17 02:51:12 --> Output Class Initialized
DEBUG - 2012-11-17 02:51:12 --> Security Class Initialized
DEBUG - 2012-11-17 02:51:12 --> Input Class Initialized
DEBUG - 2012-11-17 02:51:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:51:12 --> Language Class Initialized
DEBUG - 2012-11-17 02:51:12 --> Loader Class Initialized
DEBUG - 2012-11-17 02:51:12 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:51:12 --> Controller Class Initialized
DEBUG - 2012-11-17 02:51:12 --> Model Class Initialized
DEBUG - 2012-11-17 02:51:12 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:51:12 --> Helper loaded: language_helper
DEBUG - 2012-11-17 02:51:12 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-11-17 02:51:56 --> Config Class Initialized
DEBUG - 2012-11-17 02:51:56 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:51:56 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:51:56 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:51:56 --> URI Class Initialized
DEBUG - 2012-11-17 02:51:56 --> Router Class Initialized
DEBUG - 2012-11-17 02:51:56 --> Output Class Initialized
DEBUG - 2012-11-17 02:51:56 --> Security Class Initialized
DEBUG - 2012-11-17 02:51:56 --> Input Class Initialized
DEBUG - 2012-11-17 02:51:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:51:56 --> Language Class Initialized
DEBUG - 2012-11-17 02:51:56 --> Loader Class Initialized
DEBUG - 2012-11-17 02:51:56 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:51:56 --> Controller Class Initialized
DEBUG - 2012-11-17 02:51:56 --> Model Class Initialized
DEBUG - 2012-11-17 02:51:56 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:51:56 --> Helper loaded: form_helper
DEBUG - 2012-11-17 02:51:56 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 02:51:56 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 02:51:56 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 02:51:56 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 02:51:57 --> Final output sent to browser
DEBUG - 2012-11-17 02:51:57 --> Total execution time: 0.0435
DEBUG - 2012-11-17 02:51:58 --> Config Class Initialized
DEBUG - 2012-11-17 02:51:58 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:51:58 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:51:58 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:51:58 --> URI Class Initialized
DEBUG - 2012-11-17 02:51:58 --> Router Class Initialized
ERROR - 2012-11-17 02:51:58 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:51:58 --> Config Class Initialized
DEBUG - 2012-11-17 02:51:58 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:51:58 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:51:58 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:51:58 --> URI Class Initialized
DEBUG - 2012-11-17 02:51:58 --> Router Class Initialized
ERROR - 2012-11-17 02:51:58 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:51:59 --> Config Class Initialized
DEBUG - 2012-11-17 02:51:59 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:51:59 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:51:59 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:51:59 --> URI Class Initialized
DEBUG - 2012-11-17 02:51:59 --> Router Class Initialized
ERROR - 2012-11-17 02:51:59 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:52:00 --> Config Class Initialized
DEBUG - 2012-11-17 02:52:01 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:52:01 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:52:01 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:52:01 --> URI Class Initialized
DEBUG - 2012-11-17 02:52:01 --> Router Class Initialized
DEBUG - 2012-11-17 02:52:01 --> Output Class Initialized
DEBUG - 2012-11-17 02:52:01 --> Security Class Initialized
DEBUG - 2012-11-17 02:52:01 --> Input Class Initialized
DEBUG - 2012-11-17 02:52:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:52:01 --> Language Class Initialized
DEBUG - 2012-11-17 02:52:01 --> Loader Class Initialized
DEBUG - 2012-11-17 02:52:01 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:52:01 --> Controller Class Initialized
DEBUG - 2012-11-17 02:52:01 --> Model Class Initialized
DEBUG - 2012-11-17 02:52:01 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:52:01 --> Helper loaded: language_helper
DEBUG - 2012-11-17 02:52:01 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-11-17 02:53:27 --> Config Class Initialized
DEBUG - 2012-11-17 02:53:27 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:53:27 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:53:27 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:53:27 --> URI Class Initialized
DEBUG - 2012-11-17 02:53:27 --> Router Class Initialized
DEBUG - 2012-11-17 02:53:27 --> Output Class Initialized
DEBUG - 2012-11-17 02:53:27 --> Security Class Initialized
DEBUG - 2012-11-17 02:53:27 --> Input Class Initialized
DEBUG - 2012-11-17 02:53:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:53:27 --> Language Class Initialized
DEBUG - 2012-11-17 02:53:27 --> Loader Class Initialized
DEBUG - 2012-11-17 02:53:27 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:53:27 --> Controller Class Initialized
DEBUG - 2012-11-17 02:53:27 --> Model Class Initialized
DEBUG - 2012-11-17 02:53:27 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:53:27 --> Helper loaded: form_helper
DEBUG - 2012-11-17 02:53:27 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 02:53:27 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 02:53:27 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 02:53:27 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 02:53:27 --> Final output sent to browser
DEBUG - 2012-11-17 02:53:27 --> Total execution time: 0.0567
DEBUG - 2012-11-17 02:53:29 --> Config Class Initialized
DEBUG - 2012-11-17 02:53:29 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:53:29 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:53:29 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:53:29 --> URI Class Initialized
DEBUG - 2012-11-17 02:53:29 --> Router Class Initialized
ERROR - 2012-11-17 02:53:29 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:53:29 --> Config Class Initialized
DEBUG - 2012-11-17 02:53:29 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:53:29 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:53:29 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:53:29 --> URI Class Initialized
DEBUG - 2012-11-17 02:53:29 --> Router Class Initialized
ERROR - 2012-11-17 02:53:29 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:53:29 --> Config Class Initialized
DEBUG - 2012-11-17 02:53:29 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:53:29 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:53:29 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:53:29 --> URI Class Initialized
DEBUG - 2012-11-17 02:53:29 --> Router Class Initialized
ERROR - 2012-11-17 02:53:29 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:53:54 --> Config Class Initialized
DEBUG - 2012-11-17 02:53:54 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:53:54 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:53:54 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:53:54 --> URI Class Initialized
DEBUG - 2012-11-17 02:53:54 --> Router Class Initialized
DEBUG - 2012-11-17 02:53:54 --> Output Class Initialized
DEBUG - 2012-11-17 02:53:54 --> Security Class Initialized
DEBUG - 2012-11-17 02:53:54 --> Input Class Initialized
DEBUG - 2012-11-17 02:53:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:53:54 --> Language Class Initialized
DEBUG - 2012-11-17 02:53:54 --> Loader Class Initialized
DEBUG - 2012-11-17 02:53:54 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:53:54 --> Controller Class Initialized
DEBUG - 2012-11-17 02:53:54 --> Model Class Initialized
DEBUG - 2012-11-17 02:53:54 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:53:54 --> Helper loaded: language_helper
DEBUG - 2012-11-17 02:53:54 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-11-17 02:54:04 --> Config Class Initialized
DEBUG - 2012-11-17 02:54:04 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:54:04 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:54:04 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:54:04 --> URI Class Initialized
DEBUG - 2012-11-17 02:54:04 --> Router Class Initialized
DEBUG - 2012-11-17 02:54:04 --> Output Class Initialized
DEBUG - 2012-11-17 02:54:04 --> Security Class Initialized
DEBUG - 2012-11-17 02:54:04 --> Input Class Initialized
DEBUG - 2012-11-17 02:54:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:54:04 --> Language Class Initialized
DEBUG - 2012-11-17 02:54:04 --> Loader Class Initialized
DEBUG - 2012-11-17 02:54:04 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:54:04 --> Controller Class Initialized
DEBUG - 2012-11-17 02:54:04 --> Model Class Initialized
DEBUG - 2012-11-17 02:54:04 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:54:04 --> Helper loaded: form_helper
DEBUG - 2012-11-17 02:54:04 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 02:54:04 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 02:54:04 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 02:54:04 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 02:54:04 --> Final output sent to browser
DEBUG - 2012-11-17 02:54:04 --> Total execution time: 0.0440
DEBUG - 2012-11-17 02:54:06 --> Config Class Initialized
DEBUG - 2012-11-17 02:54:06 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:54:06 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:54:06 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:54:06 --> URI Class Initialized
DEBUG - 2012-11-17 02:54:06 --> Router Class Initialized
ERROR - 2012-11-17 02:54:06 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:54:06 --> Config Class Initialized
DEBUG - 2012-11-17 02:54:06 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:54:06 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:54:06 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:54:06 --> URI Class Initialized
DEBUG - 2012-11-17 02:54:06 --> Router Class Initialized
ERROR - 2012-11-17 02:54:06 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:54:06 --> Config Class Initialized
DEBUG - 2012-11-17 02:54:06 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:54:06 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:54:06 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:54:06 --> URI Class Initialized
DEBUG - 2012-11-17 02:54:06 --> Router Class Initialized
ERROR - 2012-11-17 02:54:06 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:54:07 --> Config Class Initialized
DEBUG - 2012-11-17 02:54:07 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:54:07 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:54:07 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:54:07 --> URI Class Initialized
DEBUG - 2012-11-17 02:54:07 --> Router Class Initialized
DEBUG - 2012-11-17 02:54:07 --> Output Class Initialized
DEBUG - 2012-11-17 02:54:07 --> Security Class Initialized
DEBUG - 2012-11-17 02:54:07 --> Input Class Initialized
DEBUG - 2012-11-17 02:54:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:54:07 --> Language Class Initialized
DEBUG - 2012-11-17 02:54:07 --> Loader Class Initialized
DEBUG - 2012-11-17 02:54:07 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:54:07 --> Controller Class Initialized
DEBUG - 2012-11-17 02:54:07 --> Model Class Initialized
DEBUG - 2012-11-17 02:54:07 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:54:07 --> Helper loaded: language_helper
DEBUG - 2012-11-17 02:54:07 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-11-17 02:54:13 --> Config Class Initialized
DEBUG - 2012-11-17 02:54:13 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:54:13 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:54:13 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:54:13 --> URI Class Initialized
DEBUG - 2012-11-17 02:54:13 --> Router Class Initialized
DEBUG - 2012-11-17 02:54:13 --> Output Class Initialized
DEBUG - 2012-11-17 02:54:13 --> Security Class Initialized
DEBUG - 2012-11-17 02:54:13 --> Input Class Initialized
DEBUG - 2012-11-17 02:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:54:13 --> Language Class Initialized
DEBUG - 2012-11-17 02:54:13 --> Loader Class Initialized
DEBUG - 2012-11-17 02:54:13 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:54:13 --> Controller Class Initialized
DEBUG - 2012-11-17 02:54:13 --> Model Class Initialized
DEBUG - 2012-11-17 02:54:13 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:54:13 --> Helper loaded: language_helper
DEBUG - 2012-11-17 02:54:13 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-11-17 02:55:14 --> Config Class Initialized
DEBUG - 2012-11-17 02:55:14 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:55:14 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:55:14 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:55:14 --> URI Class Initialized
DEBUG - 2012-11-17 02:55:14 --> Router Class Initialized
DEBUG - 2012-11-17 02:55:14 --> Output Class Initialized
DEBUG - 2012-11-17 02:55:14 --> Security Class Initialized
DEBUG - 2012-11-17 02:55:14 --> Input Class Initialized
DEBUG - 2012-11-17 02:55:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:55:14 --> Language Class Initialized
DEBUG - 2012-11-17 02:55:14 --> Loader Class Initialized
DEBUG - 2012-11-17 02:55:14 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:55:14 --> Controller Class Initialized
DEBUG - 2012-11-17 02:55:14 --> Model Class Initialized
DEBUG - 2012-11-17 02:55:14 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:55:14 --> Helper loaded: language_helper
DEBUG - 2012-11-17 02:55:14 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-11-17 02:55:50 --> Config Class Initialized
DEBUG - 2012-11-17 02:55:50 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:55:50 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:55:50 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:55:50 --> URI Class Initialized
DEBUG - 2012-11-17 02:55:50 --> Router Class Initialized
DEBUG - 2012-11-17 02:55:50 --> Output Class Initialized
DEBUG - 2012-11-17 02:55:50 --> Security Class Initialized
DEBUG - 2012-11-17 02:55:50 --> Input Class Initialized
DEBUG - 2012-11-17 02:55:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:55:50 --> Language Class Initialized
DEBUG - 2012-11-17 02:55:50 --> Loader Class Initialized
DEBUG - 2012-11-17 02:55:50 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:55:50 --> Controller Class Initialized
DEBUG - 2012-11-17 02:55:50 --> Model Class Initialized
DEBUG - 2012-11-17 02:55:50 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:55:50 --> Helper loaded: form_helper
DEBUG - 2012-11-17 02:55:50 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 02:55:50 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 02:55:50 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 02:55:50 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 02:55:51 --> Final output sent to browser
DEBUG - 2012-11-17 02:55:51 --> Total execution time: 0.0585
DEBUG - 2012-11-17 02:55:52 --> Config Class Initialized
DEBUG - 2012-11-17 02:55:52 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:55:52 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:55:52 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:55:52 --> URI Class Initialized
DEBUG - 2012-11-17 02:55:52 --> Router Class Initialized
ERROR - 2012-11-17 02:55:52 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:55:52 --> Config Class Initialized
DEBUG - 2012-11-17 02:55:52 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:55:52 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:55:52 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:55:52 --> URI Class Initialized
DEBUG - 2012-11-17 02:55:52 --> Router Class Initialized
ERROR - 2012-11-17 02:55:52 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:55:52 --> Config Class Initialized
DEBUG - 2012-11-17 02:55:52 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:55:52 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:55:52 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:55:52 --> URI Class Initialized
DEBUG - 2012-11-17 02:55:52 --> Router Class Initialized
ERROR - 2012-11-17 02:55:52 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:55:53 --> Config Class Initialized
DEBUG - 2012-11-17 02:55:53 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:55:53 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:55:53 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:55:53 --> URI Class Initialized
DEBUG - 2012-11-17 02:55:53 --> Router Class Initialized
DEBUG - 2012-11-17 02:55:53 --> Output Class Initialized
DEBUG - 2012-11-17 02:55:53 --> Security Class Initialized
DEBUG - 2012-11-17 02:55:53 --> Input Class Initialized
DEBUG - 2012-11-17 02:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:55:53 --> Language Class Initialized
DEBUG - 2012-11-17 02:55:53 --> Loader Class Initialized
DEBUG - 2012-11-17 02:55:53 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:55:53 --> Controller Class Initialized
DEBUG - 2012-11-17 02:55:53 --> Model Class Initialized
DEBUG - 2012-11-17 02:55:53 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:55:53 --> Helper loaded: language_helper
DEBUG - 2012-11-17 02:55:53 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-11-17 02:56:00 --> Config Class Initialized
DEBUG - 2012-11-17 02:56:00 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:56:00 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:56:00 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:56:00 --> URI Class Initialized
DEBUG - 2012-11-17 02:56:00 --> Router Class Initialized
DEBUG - 2012-11-17 02:56:00 --> Output Class Initialized
DEBUG - 2012-11-17 02:56:00 --> Security Class Initialized
DEBUG - 2012-11-17 02:56:00 --> Input Class Initialized
DEBUG - 2012-11-17 02:56:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:56:00 --> Language Class Initialized
DEBUG - 2012-11-17 02:56:00 --> Loader Class Initialized
DEBUG - 2012-11-17 02:56:00 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:56:00 --> Controller Class Initialized
DEBUG - 2012-11-17 02:56:00 --> Model Class Initialized
DEBUG - 2012-11-17 02:56:00 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:56:00 --> Helper loaded: language_helper
DEBUG - 2012-11-17 02:56:00 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-11-17 02:56:22 --> Config Class Initialized
DEBUG - 2012-11-17 02:56:22 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:56:22 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:56:22 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:56:22 --> URI Class Initialized
DEBUG - 2012-11-17 02:56:22 --> Router Class Initialized
DEBUG - 2012-11-17 02:56:22 --> Output Class Initialized
DEBUG - 2012-11-17 02:56:22 --> Security Class Initialized
DEBUG - 2012-11-17 02:56:22 --> Input Class Initialized
DEBUG - 2012-11-17 02:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:56:22 --> Language Class Initialized
DEBUG - 2012-11-17 02:56:22 --> Loader Class Initialized
DEBUG - 2012-11-17 02:56:22 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:56:22 --> Controller Class Initialized
DEBUG - 2012-11-17 02:56:22 --> Model Class Initialized
DEBUG - 2012-11-17 02:56:22 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:56:22 --> Helper loaded: form_helper
DEBUG - 2012-11-17 02:56:22 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 02:56:22 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 02:56:22 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 02:56:22 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 02:56:22 --> Final output sent to browser
DEBUG - 2012-11-17 02:56:22 --> Total execution time: 0.0516
DEBUG - 2012-11-17 02:56:24 --> Config Class Initialized
DEBUG - 2012-11-17 02:56:24 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:56:24 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:56:24 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:56:24 --> URI Class Initialized
DEBUG - 2012-11-17 02:56:24 --> Router Class Initialized
ERROR - 2012-11-17 02:56:24 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:56:24 --> Config Class Initialized
DEBUG - 2012-11-17 02:56:24 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:56:24 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:56:24 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:56:24 --> URI Class Initialized
DEBUG - 2012-11-17 02:56:24 --> Router Class Initialized
ERROR - 2012-11-17 02:56:24 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:56:24 --> Config Class Initialized
DEBUG - 2012-11-17 02:56:24 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:56:24 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:56:24 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:56:24 --> URI Class Initialized
DEBUG - 2012-11-17 02:56:24 --> Router Class Initialized
ERROR - 2012-11-17 02:56:24 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 02:56:25 --> Config Class Initialized
DEBUG - 2012-11-17 02:56:25 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:56:25 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:56:25 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:56:25 --> URI Class Initialized
DEBUG - 2012-11-17 02:56:25 --> Router Class Initialized
DEBUG - 2012-11-17 02:56:25 --> Output Class Initialized
DEBUG - 2012-11-17 02:56:25 --> Security Class Initialized
DEBUG - 2012-11-17 02:56:25 --> Input Class Initialized
DEBUG - 2012-11-17 02:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:56:25 --> Language Class Initialized
DEBUG - 2012-11-17 02:56:25 --> Loader Class Initialized
DEBUG - 2012-11-17 02:56:25 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:56:25 --> Controller Class Initialized
DEBUG - 2012-11-17 02:56:25 --> Model Class Initialized
DEBUG - 2012-11-17 02:56:25 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:56:25 --> Helper loaded: language_helper
DEBUG - 2012-11-17 02:56:25 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-11-17 02:56:30 --> Config Class Initialized
DEBUG - 2012-11-17 02:56:30 --> Hooks Class Initialized
DEBUG - 2012-11-17 02:56:30 --> Utf8 Class Initialized
DEBUG - 2012-11-17 02:56:30 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 02:56:30 --> URI Class Initialized
DEBUG - 2012-11-17 02:56:30 --> Router Class Initialized
DEBUG - 2012-11-17 02:56:30 --> Output Class Initialized
DEBUG - 2012-11-17 02:56:30 --> Security Class Initialized
DEBUG - 2012-11-17 02:56:30 --> Input Class Initialized
DEBUG - 2012-11-17 02:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 02:56:30 --> Language Class Initialized
DEBUG - 2012-11-17 02:56:30 --> Loader Class Initialized
DEBUG - 2012-11-17 02:56:30 --> Helper loaded: url_helper
DEBUG - 2012-11-17 02:56:30 --> Controller Class Initialized
DEBUG - 2012-11-17 02:56:30 --> Model Class Initialized
DEBUG - 2012-11-17 02:56:30 --> Database Driver Class Initialized
DEBUG - 2012-11-17 02:56:30 --> Helper loaded: language_helper
DEBUG - 2012-11-17 02:56:30 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-11-17 03:03:54 --> Config Class Initialized
DEBUG - 2012-11-17 03:03:54 --> Hooks Class Initialized
DEBUG - 2012-11-17 03:03:54 --> Utf8 Class Initialized
DEBUG - 2012-11-17 03:03:54 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 03:03:54 --> URI Class Initialized
DEBUG - 2012-11-17 03:03:54 --> Router Class Initialized
DEBUG - 2012-11-17 03:03:54 --> Output Class Initialized
DEBUG - 2012-11-17 03:03:54 --> Security Class Initialized
DEBUG - 2012-11-17 03:03:54 --> Input Class Initialized
DEBUG - 2012-11-17 03:03:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 03:03:54 --> Language Class Initialized
DEBUG - 2012-11-17 03:03:54 --> Loader Class Initialized
DEBUG - 2012-11-17 03:03:54 --> Helper loaded: url_helper
DEBUG - 2012-11-17 03:03:54 --> Controller Class Initialized
DEBUG - 2012-11-17 03:03:54 --> Model Class Initialized
DEBUG - 2012-11-17 03:03:54 --> Database Driver Class Initialized
DEBUG - 2012-11-17 03:03:54 --> Helper loaded: form_helper
DEBUG - 2012-11-17 03:03:54 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 03:03:54 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 03:03:54 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 03:03:54 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 03:03:54 --> Final output sent to browser
DEBUG - 2012-11-17 03:03:54 --> Total execution time: 0.0502
DEBUG - 2012-11-17 03:03:56 --> Config Class Initialized
DEBUG - 2012-11-17 03:03:56 --> Hooks Class Initialized
DEBUG - 2012-11-17 03:03:56 --> Utf8 Class Initialized
DEBUG - 2012-11-17 03:03:56 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 03:03:56 --> URI Class Initialized
DEBUG - 2012-11-17 03:03:56 --> Router Class Initialized
ERROR - 2012-11-17 03:03:56 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 03:03:56 --> Config Class Initialized
DEBUG - 2012-11-17 03:03:56 --> Hooks Class Initialized
DEBUG - 2012-11-17 03:03:56 --> Utf8 Class Initialized
DEBUG - 2012-11-17 03:03:56 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 03:03:56 --> URI Class Initialized
DEBUG - 2012-11-17 03:03:56 --> Router Class Initialized
ERROR - 2012-11-17 03:03:56 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 03:03:56 --> Config Class Initialized
DEBUG - 2012-11-17 03:03:56 --> Hooks Class Initialized
DEBUG - 2012-11-17 03:03:56 --> Utf8 Class Initialized
DEBUG - 2012-11-17 03:03:56 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 03:03:56 --> URI Class Initialized
DEBUG - 2012-11-17 03:03:56 --> Router Class Initialized
ERROR - 2012-11-17 03:03:56 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 03:03:57 --> Config Class Initialized
DEBUG - 2012-11-17 03:03:57 --> Hooks Class Initialized
DEBUG - 2012-11-17 03:03:57 --> Utf8 Class Initialized
DEBUG - 2012-11-17 03:03:57 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 03:03:57 --> URI Class Initialized
DEBUG - 2012-11-17 03:03:57 --> Router Class Initialized
DEBUG - 2012-11-17 03:03:57 --> Output Class Initialized
DEBUG - 2012-11-17 03:03:57 --> Security Class Initialized
DEBUG - 2012-11-17 03:03:57 --> Input Class Initialized
DEBUG - 2012-11-17 03:03:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 03:03:57 --> Language Class Initialized
DEBUG - 2012-11-17 03:03:57 --> Loader Class Initialized
DEBUG - 2012-11-17 03:03:57 --> Helper loaded: url_helper
DEBUG - 2012-11-17 03:03:57 --> Controller Class Initialized
DEBUG - 2012-11-17 03:03:57 --> Model Class Initialized
DEBUG - 2012-11-17 03:03:57 --> Database Driver Class Initialized
DEBUG - 2012-11-17 03:03:57 --> Helper loaded: language_helper
DEBUG - 2012-11-17 03:03:57 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-11-17 03:04:15 --> Config Class Initialized
DEBUG - 2012-11-17 03:04:15 --> Hooks Class Initialized
DEBUG - 2012-11-17 03:04:15 --> Utf8 Class Initialized
DEBUG - 2012-11-17 03:04:15 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 03:04:15 --> URI Class Initialized
DEBUG - 2012-11-17 03:04:15 --> Router Class Initialized
DEBUG - 2012-11-17 03:04:15 --> Output Class Initialized
DEBUG - 2012-11-17 03:04:15 --> Security Class Initialized
DEBUG - 2012-11-17 03:04:15 --> Input Class Initialized
DEBUG - 2012-11-17 03:04:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 03:04:15 --> Language Class Initialized
DEBUG - 2012-11-17 03:04:15 --> Loader Class Initialized
DEBUG - 2012-11-17 03:04:15 --> Helper loaded: url_helper
DEBUG - 2012-11-17 03:04:15 --> Controller Class Initialized
DEBUG - 2012-11-17 03:04:15 --> Model Class Initialized
DEBUG - 2012-11-17 03:04:15 --> Database Driver Class Initialized
DEBUG - 2012-11-17 03:04:15 --> Helper loaded: language_helper
DEBUG - 2012-11-17 03:04:15 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-11-17 03:04:15 --> Final output sent to browser
DEBUG - 2012-11-17 03:04:15 --> Total execution time: 0.0355
DEBUG - 2012-11-17 03:10:40 --> Config Class Initialized
DEBUG - 2012-11-17 03:10:40 --> Hooks Class Initialized
DEBUG - 2012-11-17 03:10:40 --> Utf8 Class Initialized
DEBUG - 2012-11-17 03:10:40 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 03:10:40 --> URI Class Initialized
DEBUG - 2012-11-17 03:10:40 --> Router Class Initialized
DEBUG - 2012-11-17 03:10:40 --> Output Class Initialized
DEBUG - 2012-11-17 03:10:40 --> Security Class Initialized
DEBUG - 2012-11-17 03:10:40 --> Input Class Initialized
DEBUG - 2012-11-17 03:10:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 03:10:40 --> Language Class Initialized
DEBUG - 2012-11-17 03:10:40 --> Loader Class Initialized
DEBUG - 2012-11-17 03:10:40 --> Helper loaded: url_helper
DEBUG - 2012-11-17 03:10:40 --> Controller Class Initialized
DEBUG - 2012-11-17 03:10:40 --> Model Class Initialized
DEBUG - 2012-11-17 03:10:40 --> Database Driver Class Initialized
DEBUG - 2012-11-17 03:10:40 --> Helper loaded: language_helper
DEBUG - 2012-11-17 03:10:40 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-11-17 03:10:40 --> Final output sent to browser
DEBUG - 2012-11-17 03:10:40 --> Total execution time: 0.0370
DEBUG - 2012-11-17 03:16:05 --> Config Class Initialized
DEBUG - 2012-11-17 03:16:05 --> Hooks Class Initialized
DEBUG - 2012-11-17 03:16:05 --> Utf8 Class Initialized
DEBUG - 2012-11-17 03:16:05 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 03:16:05 --> URI Class Initialized
DEBUG - 2012-11-17 03:16:05 --> Router Class Initialized
DEBUG - 2012-11-17 03:16:05 --> Output Class Initialized
DEBUG - 2012-11-17 03:16:05 --> Security Class Initialized
DEBUG - 2012-11-17 03:16:05 --> Input Class Initialized
DEBUG - 2012-11-17 03:16:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 03:16:05 --> Language Class Initialized
DEBUG - 2012-11-17 03:16:05 --> Loader Class Initialized
DEBUG - 2012-11-17 03:16:05 --> Helper loaded: url_helper
DEBUG - 2012-11-17 03:16:05 --> Controller Class Initialized
DEBUG - 2012-11-17 03:16:05 --> Model Class Initialized
DEBUG - 2012-11-17 03:16:05 --> Database Driver Class Initialized
DEBUG - 2012-11-17 03:16:05 --> Helper loaded: form_helper
DEBUG - 2012-11-17 03:16:05 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 03:16:05 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 03:16:05 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 03:16:05 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 03:16:05 --> Final output sent to browser
DEBUG - 2012-11-17 03:16:05 --> Total execution time: 0.0542
DEBUG - 2012-11-17 03:16:07 --> Config Class Initialized
DEBUG - 2012-11-17 03:16:07 --> Hooks Class Initialized
DEBUG - 2012-11-17 03:16:07 --> Utf8 Class Initialized
DEBUG - 2012-11-17 03:16:07 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 03:16:07 --> URI Class Initialized
DEBUG - 2012-11-17 03:16:07 --> Router Class Initialized
ERROR - 2012-11-17 03:16:07 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 03:16:07 --> Config Class Initialized
DEBUG - 2012-11-17 03:16:07 --> Hooks Class Initialized
DEBUG - 2012-11-17 03:16:07 --> Utf8 Class Initialized
DEBUG - 2012-11-17 03:16:07 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 03:16:07 --> URI Class Initialized
DEBUG - 2012-11-17 03:16:07 --> Router Class Initialized
ERROR - 2012-11-17 03:16:07 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 03:16:07 --> Config Class Initialized
DEBUG - 2012-11-17 03:16:07 --> Hooks Class Initialized
DEBUG - 2012-11-17 03:16:07 --> Utf8 Class Initialized
DEBUG - 2012-11-17 03:16:07 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 03:16:07 --> URI Class Initialized
DEBUG - 2012-11-17 03:16:07 --> Router Class Initialized
ERROR - 2012-11-17 03:16:07 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 03:16:10 --> Config Class Initialized
DEBUG - 2012-11-17 03:16:10 --> Hooks Class Initialized
DEBUG - 2012-11-17 03:16:10 --> Utf8 Class Initialized
DEBUG - 2012-11-17 03:16:10 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 03:16:10 --> URI Class Initialized
DEBUG - 2012-11-17 03:16:10 --> Router Class Initialized
DEBUG - 2012-11-17 03:16:10 --> Output Class Initialized
DEBUG - 2012-11-17 03:16:10 --> Security Class Initialized
DEBUG - 2012-11-17 03:16:10 --> Input Class Initialized
DEBUG - 2012-11-17 03:16:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 03:16:10 --> Language Class Initialized
DEBUG - 2012-11-17 03:16:10 --> Loader Class Initialized
DEBUG - 2012-11-17 03:16:10 --> Helper loaded: url_helper
DEBUG - 2012-11-17 03:16:10 --> Controller Class Initialized
DEBUG - 2012-11-17 03:16:10 --> Model Class Initialized
DEBUG - 2012-11-17 03:16:10 --> Database Driver Class Initialized
DEBUG - 2012-11-17 03:16:10 --> Helper loaded: language_helper
DEBUG - 2012-11-17 03:16:10 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-11-17 03:16:10 --> Final output sent to browser
DEBUG - 2012-11-17 03:16:10 --> Total execution time: 0.0351
DEBUG - 2012-11-17 03:17:03 --> Config Class Initialized
DEBUG - 2012-11-17 03:17:03 --> Hooks Class Initialized
DEBUG - 2012-11-17 03:17:03 --> Utf8 Class Initialized
DEBUG - 2012-11-17 03:17:03 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 03:17:03 --> URI Class Initialized
DEBUG - 2012-11-17 03:17:03 --> Router Class Initialized
DEBUG - 2012-11-17 03:17:03 --> Output Class Initialized
DEBUG - 2012-11-17 03:17:03 --> Security Class Initialized
DEBUG - 2012-11-17 03:17:03 --> Input Class Initialized
DEBUG - 2012-11-17 03:17:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 03:17:03 --> Language Class Initialized
DEBUG - 2012-11-17 03:17:03 --> Loader Class Initialized
DEBUG - 2012-11-17 03:17:03 --> Helper loaded: url_helper
DEBUG - 2012-11-17 03:17:03 --> Controller Class Initialized
DEBUG - 2012-11-17 03:17:03 --> Model Class Initialized
DEBUG - 2012-11-17 03:17:03 --> Database Driver Class Initialized
DEBUG - 2012-11-17 03:17:03 --> Helper loaded: form_helper
DEBUG - 2012-11-17 03:17:03 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-11-17 03:17:03 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-11-17 03:17:03 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-11-17 03:17:03 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-11-17 03:17:03 --> Final output sent to browser
DEBUG - 2012-11-17 03:17:03 --> Total execution time: 0.0434
DEBUG - 2012-11-17 03:17:05 --> Config Class Initialized
DEBUG - 2012-11-17 03:17:05 --> Hooks Class Initialized
DEBUG - 2012-11-17 03:17:05 --> Utf8 Class Initialized
DEBUG - 2012-11-17 03:17:05 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 03:17:05 --> URI Class Initialized
DEBUG - 2012-11-17 03:17:05 --> Router Class Initialized
ERROR - 2012-11-17 03:17:05 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 03:17:05 --> Config Class Initialized
DEBUG - 2012-11-17 03:17:05 --> Hooks Class Initialized
DEBUG - 2012-11-17 03:17:05 --> Utf8 Class Initialized
DEBUG - 2012-11-17 03:17:05 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 03:17:05 --> URI Class Initialized
DEBUG - 2012-11-17 03:17:05 --> Router Class Initialized
ERROR - 2012-11-17 03:17:05 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 03:17:05 --> Config Class Initialized
DEBUG - 2012-11-17 03:17:05 --> Hooks Class Initialized
DEBUG - 2012-11-17 03:17:05 --> Utf8 Class Initialized
DEBUG - 2012-11-17 03:17:05 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 03:17:05 --> URI Class Initialized
DEBUG - 2012-11-17 03:17:05 --> Router Class Initialized
ERROR - 2012-11-17 03:17:05 --> 404 Page Not Found --> css
DEBUG - 2012-11-17 03:17:06 --> Config Class Initialized
DEBUG - 2012-11-17 03:17:06 --> Hooks Class Initialized
DEBUG - 2012-11-17 03:17:06 --> Utf8 Class Initialized
DEBUG - 2012-11-17 03:17:06 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 03:17:06 --> URI Class Initialized
DEBUG - 2012-11-17 03:17:06 --> Router Class Initialized
DEBUG - 2012-11-17 03:17:06 --> Output Class Initialized
DEBUG - 2012-11-17 03:17:06 --> Security Class Initialized
DEBUG - 2012-11-17 03:17:06 --> Input Class Initialized
DEBUG - 2012-11-17 03:17:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 03:17:06 --> Language Class Initialized
DEBUG - 2012-11-17 03:17:06 --> Loader Class Initialized
DEBUG - 2012-11-17 03:17:06 --> Helper loaded: url_helper
DEBUG - 2012-11-17 03:17:06 --> Controller Class Initialized
DEBUG - 2012-11-17 03:17:06 --> Model Class Initialized
DEBUG - 2012-11-17 03:17:06 --> Database Driver Class Initialized
DEBUG - 2012-11-17 03:17:06 --> Helper loaded: language_helper
DEBUG - 2012-11-17 03:17:06 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-11-17 03:17:06 --> Final output sent to browser
DEBUG - 2012-11-17 03:17:06 --> Total execution time: 0.0363
DEBUG - 2012-11-17 03:22:42 --> Config Class Initialized
DEBUG - 2012-11-17 03:22:42 --> Hooks Class Initialized
DEBUG - 2012-11-17 03:22:42 --> Utf8 Class Initialized
DEBUG - 2012-11-17 03:22:42 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 03:22:42 --> URI Class Initialized
DEBUG - 2012-11-17 03:22:42 --> Router Class Initialized
DEBUG - 2012-11-17 03:22:42 --> Output Class Initialized
DEBUG - 2012-11-17 03:22:42 --> Security Class Initialized
DEBUG - 2012-11-17 03:22:42 --> Input Class Initialized
DEBUG - 2012-11-17 03:22:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 03:22:42 --> Language Class Initialized
DEBUG - 2012-11-17 03:22:42 --> Loader Class Initialized
DEBUG - 2012-11-17 03:22:42 --> Helper loaded: url_helper
DEBUG - 2012-11-17 03:22:42 --> Controller Class Initialized
DEBUG - 2012-11-17 03:22:42 --> Model Class Initialized
DEBUG - 2012-11-17 03:22:42 --> Database Driver Class Initialized
DEBUG - 2012-11-17 03:22:42 --> Helper loaded: language_helper
DEBUG - 2012-11-17 03:22:42 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-11-17 03:22:42 --> Final output sent to browser
DEBUG - 2012-11-17 03:22:42 --> Total execution time: 0.0368
