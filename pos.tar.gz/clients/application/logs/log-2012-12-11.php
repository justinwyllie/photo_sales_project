<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-12-11 14:01:12 --> Config Class Initialized
DEBUG - 2012-12-11 14:01:12 --> Hooks Class Initialized
DEBUG - 2012-12-11 14:01:12 --> Utf8 Class Initialized
DEBUG - 2012-12-11 14:01:12 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 14:01:12 --> URI Class Initialized
DEBUG - 2012-12-11 14:01:12 --> Router Class Initialized
ERROR - 2012-12-11 14:01:12 --> 404 Page Not Found --> business
DEBUG - 2012-12-11 14:01:24 --> Config Class Initialized
DEBUG - 2012-12-11 14:01:24 --> Hooks Class Initialized
DEBUG - 2012-12-11 14:01:24 --> Utf8 Class Initialized
DEBUG - 2012-12-11 14:01:24 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 14:01:24 --> URI Class Initialized
DEBUG - 2012-12-11 14:01:24 --> Router Class Initialized
DEBUG - 2012-12-11 14:01:24 --> No URI present. Default controller set.
DEBUG - 2012-12-11 14:01:24 --> Output Class Initialized
DEBUG - 2012-12-11 14:01:24 --> Security Class Initialized
DEBUG - 2012-12-11 14:01:24 --> Input Class Initialized
DEBUG - 2012-12-11 14:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 14:01:24 --> Language Class Initialized
DEBUG - 2012-12-11 14:01:24 --> Loader Class Initialized
DEBUG - 2012-12-11 14:01:24 --> Helper loaded: url_helper
DEBUG - 2012-12-11 14:01:24 --> Controller Class Initialized
DEBUG - 2012-12-11 14:01:24 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-12-11 14:01:24 --> Final output sent to browser
DEBUG - 2012-12-11 14:01:24 --> Total execution time: 0.1491
DEBUG - 2012-12-11 14:01:33 --> Config Class Initialized
DEBUG - 2012-12-11 14:01:33 --> Hooks Class Initialized
DEBUG - 2012-12-11 14:01:33 --> Utf8 Class Initialized
DEBUG - 2012-12-11 14:01:33 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 14:01:33 --> URI Class Initialized
DEBUG - 2012-12-11 14:01:33 --> Router Class Initialized
DEBUG - 2012-12-11 14:01:33 --> Output Class Initialized
DEBUG - 2012-12-11 14:01:33 --> Security Class Initialized
DEBUG - 2012-12-11 14:01:33 --> Input Class Initialized
DEBUG - 2012-12-11 14:01:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 14:01:33 --> Language Class Initialized
DEBUG - 2012-12-11 14:01:33 --> Loader Class Initialized
DEBUG - 2012-12-11 14:01:33 --> Helper loaded: url_helper
DEBUG - 2012-12-11 14:01:33 --> Controller Class Initialized
DEBUG - 2012-12-11 14:01:33 --> Model Class Initialized
DEBUG - 2012-12-11 14:01:33 --> Database Driver Class Initialized
DEBUG - 2012-12-11 14:01:33 --> Helper loaded: form_helper
DEBUG - 2012-12-11 14:01:34 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-11 14:01:34 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-12-11 14:01:34 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-11 14:01:34 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-12-11 14:01:34 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-11 14:01:34 --> Final output sent to browser
DEBUG - 2012-12-11 14:01:34 --> Total execution time: 1.8370
DEBUG - 2012-12-11 14:01:37 --> Config Class Initialized
DEBUG - 2012-12-11 14:01:37 --> Hooks Class Initialized
DEBUG - 2012-12-11 14:01:37 --> Utf8 Class Initialized
DEBUG - 2012-12-11 14:01:37 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 14:01:37 --> URI Class Initialized
DEBUG - 2012-12-11 14:01:37 --> Router Class Initialized
ERROR - 2012-12-11 14:01:37 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 14:01:37 --> Config Class Initialized
DEBUG - 2012-12-11 14:01:37 --> Hooks Class Initialized
DEBUG - 2012-12-11 14:01:37 --> Utf8 Class Initialized
DEBUG - 2012-12-11 14:01:37 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 14:01:37 --> URI Class Initialized
DEBUG - 2012-12-11 14:01:37 --> Config Class Initialized
DEBUG - 2012-12-11 14:01:37 --> Hooks Class Initialized
DEBUG - 2012-12-11 14:01:37 --> Utf8 Class Initialized
DEBUG - 2012-12-11 14:01:37 --> Router Class Initialized
DEBUG - 2012-12-11 14:01:37 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 14:01:37 --> URI Class Initialized
ERROR - 2012-12-11 14:01:37 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 14:01:37 --> Router Class Initialized
ERROR - 2012-12-11 14:01:37 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 14:06:11 --> Config Class Initialized
DEBUG - 2012-12-11 14:06:11 --> Hooks Class Initialized
DEBUG - 2012-12-11 14:06:11 --> Utf8 Class Initialized
DEBUG - 2012-12-11 14:06:11 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 14:06:11 --> URI Class Initialized
DEBUG - 2012-12-11 14:06:11 --> Router Class Initialized
DEBUG - 2012-12-11 14:06:11 --> Output Class Initialized
DEBUG - 2012-12-11 14:06:11 --> Security Class Initialized
DEBUG - 2012-12-11 14:06:11 --> Input Class Initialized
DEBUG - 2012-12-11 14:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 14:06:11 --> Language Class Initialized
DEBUG - 2012-12-11 14:06:11 --> Loader Class Initialized
DEBUG - 2012-12-11 14:06:11 --> Helper loaded: url_helper
DEBUG - 2012-12-11 14:06:11 --> Controller Class Initialized
DEBUG - 2012-12-11 14:06:11 --> Model Class Initialized
DEBUG - 2012-12-11 14:06:11 --> Database Driver Class Initialized
DEBUG - 2012-12-11 14:06:11 --> Helper loaded: form_helper
DEBUG - 2012-12-11 14:06:11 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-11 14:06:11 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-11 14:06:11 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-11 14:06:11 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-11 14:06:11 --> Final output sent to browser
DEBUG - 2012-12-11 14:06:11 --> Total execution time: 0.1163
DEBUG - 2012-12-11 14:11:04 --> Config Class Initialized
DEBUG - 2012-12-11 14:11:04 --> Hooks Class Initialized
DEBUG - 2012-12-11 14:11:04 --> Utf8 Class Initialized
DEBUG - 2012-12-11 14:11:04 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 14:11:04 --> URI Class Initialized
DEBUG - 2012-12-11 14:11:04 --> Router Class Initialized
DEBUG - 2012-12-11 14:11:04 --> Output Class Initialized
DEBUG - 2012-12-11 14:11:04 --> Security Class Initialized
DEBUG - 2012-12-11 14:11:04 --> Input Class Initialized
DEBUG - 2012-12-11 14:11:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 14:11:04 --> Language Class Initialized
DEBUG - 2012-12-11 14:11:04 --> Loader Class Initialized
DEBUG - 2012-12-11 14:11:04 --> Helper loaded: url_helper
DEBUG - 2012-12-11 14:11:04 --> Controller Class Initialized
DEBUG - 2012-12-11 14:11:04 --> Model Class Initialized
DEBUG - 2012-12-11 14:11:04 --> Database Driver Class Initialized
DEBUG - 2012-12-11 14:11:04 --> Helper loaded: language_helper
DEBUG - 2012-12-11 14:11:05 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 14:11:05 --> Final output sent to browser
DEBUG - 2012-12-11 14:11:05 --> Total execution time: 0.3708
DEBUG - 2012-12-11 14:13:59 --> Config Class Initialized
DEBUG - 2012-12-11 14:13:59 --> Hooks Class Initialized
DEBUG - 2012-12-11 14:13:59 --> Utf8 Class Initialized
DEBUG - 2012-12-11 14:13:59 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 14:13:59 --> URI Class Initialized
DEBUG - 2012-12-11 14:13:59 --> Router Class Initialized
DEBUG - 2012-12-11 14:13:59 --> Output Class Initialized
DEBUG - 2012-12-11 14:13:59 --> Security Class Initialized
DEBUG - 2012-12-11 14:13:59 --> Input Class Initialized
DEBUG - 2012-12-11 14:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 14:13:59 --> Language Class Initialized
DEBUG - 2012-12-11 14:13:59 --> Loader Class Initialized
DEBUG - 2012-12-11 14:13:59 --> Helper loaded: url_helper
DEBUG - 2012-12-11 14:13:59 --> Controller Class Initialized
DEBUG - 2012-12-11 14:13:59 --> Model Class Initialized
DEBUG - 2012-12-11 14:13:59 --> Database Driver Class Initialized
DEBUG - 2012-12-11 14:13:59 --> Helper loaded: language_helper
DEBUG - 2012-12-11 14:13:59 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 14:13:59 --> Final output sent to browser
DEBUG - 2012-12-11 14:13:59 --> Total execution time: 0.0399
DEBUG - 2012-12-11 14:17:07 --> Config Class Initialized
DEBUG - 2012-12-11 14:17:07 --> Hooks Class Initialized
DEBUG - 2012-12-11 14:17:07 --> Utf8 Class Initialized
DEBUG - 2012-12-11 14:17:07 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 14:17:07 --> URI Class Initialized
DEBUG - 2012-12-11 14:17:07 --> Router Class Initialized
DEBUG - 2012-12-11 14:17:07 --> Output Class Initialized
DEBUG - 2012-12-11 14:17:07 --> Security Class Initialized
DEBUG - 2012-12-11 14:17:07 --> Input Class Initialized
DEBUG - 2012-12-11 14:17:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 14:17:07 --> Language Class Initialized
DEBUG - 2012-12-11 14:17:07 --> Loader Class Initialized
DEBUG - 2012-12-11 14:17:07 --> Helper loaded: url_helper
DEBUG - 2012-12-11 14:17:07 --> Controller Class Initialized
DEBUG - 2012-12-11 14:17:07 --> Model Class Initialized
DEBUG - 2012-12-11 14:17:07 --> Database Driver Class Initialized
DEBUG - 2012-12-11 14:17:07 --> Helper loaded: language_helper
DEBUG - 2012-12-11 14:17:07 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 14:17:07 --> Final output sent to browser
DEBUG - 2012-12-11 14:17:07 --> Total execution time: 0.0411
DEBUG - 2012-12-11 14:36:17 --> Config Class Initialized
DEBUG - 2012-12-11 14:36:17 --> Hooks Class Initialized
DEBUG - 2012-12-11 14:36:17 --> Utf8 Class Initialized
DEBUG - 2012-12-11 14:36:17 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 14:36:17 --> URI Class Initialized
DEBUG - 2012-12-11 14:36:17 --> Router Class Initialized
DEBUG - 2012-12-11 14:36:17 --> Output Class Initialized
DEBUG - 2012-12-11 14:36:17 --> Security Class Initialized
DEBUG - 2012-12-11 14:36:17 --> Input Class Initialized
DEBUG - 2012-12-11 14:36:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 14:36:17 --> Language Class Initialized
DEBUG - 2012-12-11 14:36:17 --> Loader Class Initialized
DEBUG - 2012-12-11 14:36:17 --> Helper loaded: url_helper
DEBUG - 2012-12-11 14:36:17 --> Controller Class Initialized
DEBUG - 2012-12-11 14:36:17 --> Model Class Initialized
DEBUG - 2012-12-11 14:36:17 --> Database Driver Class Initialized
DEBUG - 2012-12-11 14:36:17 --> Helper loaded: form_helper
DEBUG - 2012-12-11 14:36:17 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-11 14:36:17 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-11 14:36:17 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-11 14:36:17 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-11 14:36:17 --> Final output sent to browser
DEBUG - 2012-12-11 14:36:17 --> Total execution time: 0.0479
DEBUG - 2012-12-11 14:36:22 --> Config Class Initialized
DEBUG - 2012-12-11 14:36:22 --> Hooks Class Initialized
DEBUG - 2012-12-11 14:36:22 --> Utf8 Class Initialized
DEBUG - 2012-12-11 14:36:22 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 14:36:22 --> URI Class Initialized
DEBUG - 2012-12-11 14:36:22 --> Router Class Initialized
DEBUG - 2012-12-11 14:36:22 --> Output Class Initialized
DEBUG - 2012-12-11 14:36:22 --> Security Class Initialized
DEBUG - 2012-12-11 14:36:22 --> Input Class Initialized
DEBUG - 2012-12-11 14:36:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 14:36:22 --> Language Class Initialized
DEBUG - 2012-12-11 14:36:22 --> Loader Class Initialized
DEBUG - 2012-12-11 14:36:22 --> Helper loaded: url_helper
DEBUG - 2012-12-11 14:36:22 --> Controller Class Initialized
DEBUG - 2012-12-11 14:36:22 --> Model Class Initialized
DEBUG - 2012-12-11 14:36:22 --> Database Driver Class Initialized
DEBUG - 2012-12-11 14:36:22 --> Helper loaded: language_helper
DEBUG - 2012-12-11 14:36:22 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 14:36:22 --> Final output sent to browser
DEBUG - 2012-12-11 14:36:22 --> Total execution time: 0.0381
DEBUG - 2012-12-11 15:19:59 --> Config Class Initialized
DEBUG - 2012-12-11 15:19:59 --> Hooks Class Initialized
DEBUG - 2012-12-11 15:19:59 --> Utf8 Class Initialized
DEBUG - 2012-12-11 15:19:59 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 15:19:59 --> URI Class Initialized
DEBUG - 2012-12-11 15:19:59 --> Router Class Initialized
DEBUG - 2012-12-11 15:19:59 --> Output Class Initialized
DEBUG - 2012-12-11 15:19:59 --> Security Class Initialized
DEBUG - 2012-12-11 15:19:59 --> Input Class Initialized
DEBUG - 2012-12-11 15:19:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 15:19:59 --> Language Class Initialized
DEBUG - 2012-12-11 15:19:59 --> Loader Class Initialized
DEBUG - 2012-12-11 15:19:59 --> Helper loaded: url_helper
DEBUG - 2012-12-11 15:19:59 --> Controller Class Initialized
DEBUG - 2012-12-11 15:19:59 --> Model Class Initialized
DEBUG - 2012-12-11 15:19:59 --> Database Driver Class Initialized
DEBUG - 2012-12-11 15:19:59 --> Helper loaded: language_helper
DEBUG - 2012-12-11 15:19:59 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 15:23:56 --> Config Class Initialized
DEBUG - 2012-12-11 15:23:56 --> Hooks Class Initialized
DEBUG - 2012-12-11 15:23:56 --> Utf8 Class Initialized
DEBUG - 2012-12-11 15:23:56 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 15:23:56 --> URI Class Initialized
DEBUG - 2012-12-11 15:23:56 --> Router Class Initialized
DEBUG - 2012-12-11 15:23:56 --> Output Class Initialized
DEBUG - 2012-12-11 15:23:56 --> Security Class Initialized
DEBUG - 2012-12-11 15:23:56 --> Input Class Initialized
DEBUG - 2012-12-11 15:23:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 15:23:56 --> Language Class Initialized
DEBUG - 2012-12-11 15:23:56 --> Loader Class Initialized
DEBUG - 2012-12-11 15:23:56 --> Helper loaded: url_helper
DEBUG - 2012-12-11 15:23:56 --> Controller Class Initialized
DEBUG - 2012-12-11 15:23:56 --> Model Class Initialized
DEBUG - 2012-12-11 15:23:56 --> Database Driver Class Initialized
DEBUG - 2012-12-11 15:23:56 --> Helper loaded: language_helper
DEBUG - 2012-12-11 15:23:56 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 15:25:48 --> Config Class Initialized
DEBUG - 2012-12-11 15:25:48 --> Hooks Class Initialized
DEBUG - 2012-12-11 15:25:48 --> Utf8 Class Initialized
DEBUG - 2012-12-11 15:25:48 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 15:25:48 --> URI Class Initialized
DEBUG - 2012-12-11 15:25:48 --> Router Class Initialized
DEBUG - 2012-12-11 15:25:48 --> Output Class Initialized
DEBUG - 2012-12-11 15:25:48 --> Security Class Initialized
DEBUG - 2012-12-11 15:25:48 --> Input Class Initialized
DEBUG - 2012-12-11 15:25:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 15:25:48 --> Language Class Initialized
DEBUG - 2012-12-11 15:25:48 --> Loader Class Initialized
DEBUG - 2012-12-11 15:25:48 --> Helper loaded: url_helper
DEBUG - 2012-12-11 15:25:48 --> Controller Class Initialized
DEBUG - 2012-12-11 15:25:48 --> Model Class Initialized
DEBUG - 2012-12-11 15:25:48 --> Database Driver Class Initialized
DEBUG - 2012-12-11 15:25:48 --> Helper loaded: language_helper
DEBUG - 2012-12-11 15:25:48 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 15:25:48 --> Final output sent to browser
DEBUG - 2012-12-11 15:25:48 --> Total execution time: 0.0380
DEBUG - 2012-12-11 15:26:21 --> Config Class Initialized
DEBUG - 2012-12-11 15:26:21 --> Hooks Class Initialized
DEBUG - 2012-12-11 15:26:21 --> Utf8 Class Initialized
DEBUG - 2012-12-11 15:26:21 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 15:26:21 --> URI Class Initialized
DEBUG - 2012-12-11 15:26:21 --> Router Class Initialized
DEBUG - 2012-12-11 15:26:21 --> Output Class Initialized
DEBUG - 2012-12-11 15:26:21 --> Security Class Initialized
DEBUG - 2012-12-11 15:26:21 --> Input Class Initialized
DEBUG - 2012-12-11 15:26:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 15:26:21 --> Language Class Initialized
DEBUG - 2012-12-11 15:26:21 --> Loader Class Initialized
DEBUG - 2012-12-11 15:26:21 --> Helper loaded: url_helper
DEBUG - 2012-12-11 15:26:21 --> Controller Class Initialized
DEBUG - 2012-12-11 15:26:21 --> Model Class Initialized
DEBUG - 2012-12-11 15:26:21 --> Database Driver Class Initialized
DEBUG - 2012-12-11 15:26:21 --> Helper loaded: language_helper
DEBUG - 2012-12-11 15:26:21 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 15:26:21 --> Final output sent to browser
DEBUG - 2012-12-11 15:26:21 --> Total execution time: 0.0451
DEBUG - 2012-12-11 15:55:28 --> Config Class Initialized
DEBUG - 2012-12-11 15:55:28 --> Hooks Class Initialized
DEBUG - 2012-12-11 15:55:28 --> Utf8 Class Initialized
DEBUG - 2012-12-11 15:55:28 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 15:55:28 --> URI Class Initialized
DEBUG - 2012-12-11 15:55:28 --> Router Class Initialized
DEBUG - 2012-12-11 15:55:28 --> Output Class Initialized
DEBUG - 2012-12-11 15:55:28 --> Security Class Initialized
DEBUG - 2012-12-11 15:55:28 --> Input Class Initialized
DEBUG - 2012-12-11 15:55:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 15:55:28 --> Language Class Initialized
DEBUG - 2012-12-11 15:55:28 --> Loader Class Initialized
DEBUG - 2012-12-11 15:55:28 --> Helper loaded: url_helper
DEBUG - 2012-12-11 15:55:28 --> Controller Class Initialized
DEBUG - 2012-12-11 15:55:28 --> Model Class Initialized
DEBUG - 2012-12-11 15:55:28 --> Database Driver Class Initialized
DEBUG - 2012-12-11 15:55:45 --> Config Class Initialized
DEBUG - 2012-12-11 15:55:45 --> Hooks Class Initialized
DEBUG - 2012-12-11 15:55:45 --> Utf8 Class Initialized
DEBUG - 2012-12-11 15:55:45 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 15:55:45 --> URI Class Initialized
DEBUG - 2012-12-11 15:55:45 --> Router Class Initialized
DEBUG - 2012-12-11 15:55:45 --> Output Class Initialized
DEBUG - 2012-12-11 15:55:45 --> Security Class Initialized
DEBUG - 2012-12-11 15:55:45 --> Input Class Initialized
DEBUG - 2012-12-11 15:55:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 15:55:45 --> Language Class Initialized
DEBUG - 2012-12-11 15:55:45 --> Loader Class Initialized
DEBUG - 2012-12-11 15:55:45 --> Helper loaded: url_helper
DEBUG - 2012-12-11 15:55:45 --> Controller Class Initialized
DEBUG - 2012-12-11 15:55:45 --> Model Class Initialized
DEBUG - 2012-12-11 15:55:45 --> Database Driver Class Initialized
DEBUG - 2012-12-11 15:55:45 --> Helper loaded: form_helper
DEBUG - 2012-12-11 15:55:45 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-11 15:55:45 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-12-11 15:55:45 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-11 15:55:45 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-12-11 15:55:45 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-11 15:55:45 --> Final output sent to browser
DEBUG - 2012-12-11 15:55:45 --> Total execution time: 0.5661
DEBUG - 2012-12-11 15:55:46 --> Config Class Initialized
DEBUG - 2012-12-11 15:55:46 --> Hooks Class Initialized
DEBUG - 2012-12-11 15:55:46 --> Utf8 Class Initialized
DEBUG - 2012-12-11 15:55:46 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 15:55:46 --> URI Class Initialized
DEBUG - 2012-12-11 15:55:46 --> Router Class Initialized
DEBUG - 2012-12-11 15:55:46 --> Config Class Initialized
DEBUG - 2012-12-11 15:55:46 --> Hooks Class Initialized
DEBUG - 2012-12-11 15:55:46 --> Utf8 Class Initialized
DEBUG - 2012-12-11 15:55:46 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 15:55:46 --> URI Class Initialized
DEBUG - 2012-12-11 15:55:46 --> Router Class Initialized
DEBUG - 2012-12-11 15:55:46 --> Config Class Initialized
DEBUG - 2012-12-11 15:55:46 --> Hooks Class Initialized
DEBUG - 2012-12-11 15:55:46 --> Utf8 Class Initialized
DEBUG - 2012-12-11 15:55:46 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 15:55:46 --> URI Class Initialized
DEBUG - 2012-12-11 15:55:46 --> Router Class Initialized
ERROR - 2012-12-11 15:55:46 --> 404 Page Not Found --> css
ERROR - 2012-12-11 15:55:46 --> 404 Page Not Found --> css
ERROR - 2012-12-11 15:55:46 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 15:55:50 --> Config Class Initialized
DEBUG - 2012-12-11 15:55:50 --> Hooks Class Initialized
DEBUG - 2012-12-11 15:55:50 --> Utf8 Class Initialized
DEBUG - 2012-12-11 15:55:50 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 15:55:50 --> URI Class Initialized
DEBUG - 2012-12-11 15:55:50 --> Router Class Initialized
DEBUG - 2012-12-11 15:55:50 --> Output Class Initialized
DEBUG - 2012-12-11 15:55:50 --> Security Class Initialized
DEBUG - 2012-12-11 15:55:50 --> Input Class Initialized
DEBUG - 2012-12-11 15:55:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 15:55:50 --> Language Class Initialized
DEBUG - 2012-12-11 15:55:50 --> Loader Class Initialized
DEBUG - 2012-12-11 15:55:50 --> Helper loaded: url_helper
DEBUG - 2012-12-11 15:55:50 --> Controller Class Initialized
DEBUG - 2012-12-11 15:55:50 --> Model Class Initialized
DEBUG - 2012-12-11 15:55:50 --> Database Driver Class Initialized
DEBUG - 2012-12-11 15:57:25 --> Config Class Initialized
DEBUG - 2012-12-11 15:57:25 --> Hooks Class Initialized
DEBUG - 2012-12-11 15:57:25 --> Utf8 Class Initialized
DEBUG - 2012-12-11 15:57:25 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 15:57:25 --> URI Class Initialized
DEBUG - 2012-12-11 15:57:25 --> Router Class Initialized
DEBUG - 2012-12-11 15:57:25 --> Output Class Initialized
DEBUG - 2012-12-11 15:57:25 --> Security Class Initialized
DEBUG - 2012-12-11 15:57:25 --> Input Class Initialized
DEBUG - 2012-12-11 15:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 15:57:25 --> Language Class Initialized
DEBUG - 2012-12-11 15:57:25 --> Loader Class Initialized
DEBUG - 2012-12-11 15:57:25 --> Helper loaded: url_helper
DEBUG - 2012-12-11 15:57:25 --> Controller Class Initialized
DEBUG - 2012-12-11 15:57:25 --> Model Class Initialized
DEBUG - 2012-12-11 15:57:25 --> Database Driver Class Initialized
DEBUG - 2012-12-11 15:57:25 --> Helper loaded: form_helper
DEBUG - 2012-12-11 15:57:25 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-11 15:57:25 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-11 15:57:25 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-11 15:57:25 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-11 15:57:25 --> Final output sent to browser
DEBUG - 2012-12-11 15:57:25 --> Total execution time: 0.0904
DEBUG - 2012-12-11 15:57:32 --> Config Class Initialized
DEBUG - 2012-12-11 15:57:32 --> Hooks Class Initialized
DEBUG - 2012-12-11 15:57:32 --> Utf8 Class Initialized
DEBUG - 2012-12-11 15:57:32 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 15:57:32 --> URI Class Initialized
DEBUG - 2012-12-11 15:57:32 --> Router Class Initialized
DEBUG - 2012-12-11 15:57:32 --> Output Class Initialized
DEBUG - 2012-12-11 15:57:32 --> Security Class Initialized
DEBUG - 2012-12-11 15:57:32 --> Input Class Initialized
DEBUG - 2012-12-11 15:57:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 15:57:32 --> Language Class Initialized
DEBUG - 2012-12-11 15:57:32 --> Loader Class Initialized
DEBUG - 2012-12-11 15:57:32 --> Helper loaded: url_helper
DEBUG - 2012-12-11 15:57:32 --> Controller Class Initialized
DEBUG - 2012-12-11 15:57:32 --> Model Class Initialized
DEBUG - 2012-12-11 15:57:32 --> Database Driver Class Initialized
DEBUG - 2012-12-11 15:57:32 --> Helper loaded: language_helper
DEBUG - 2012-12-11 15:57:32 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 15:57:32 --> Final output sent to browser
DEBUG - 2012-12-11 15:57:32 --> Total execution time: 0.0695
DEBUG - 2012-12-11 16:01:09 --> Config Class Initialized
DEBUG - 2012-12-11 16:01:09 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:01:09 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:01:09 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:01:09 --> URI Class Initialized
DEBUG - 2012-12-11 16:01:09 --> Router Class Initialized
DEBUG - 2012-12-11 16:01:09 --> Output Class Initialized
DEBUG - 2012-12-11 16:01:09 --> Security Class Initialized
DEBUG - 2012-12-11 16:01:09 --> Input Class Initialized
DEBUG - 2012-12-11 16:01:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:01:09 --> Language Class Initialized
DEBUG - 2012-12-11 16:01:09 --> Loader Class Initialized
DEBUG - 2012-12-11 16:01:09 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:01:09 --> Controller Class Initialized
DEBUG - 2012-12-11 16:01:09 --> Model Class Initialized
DEBUG - 2012-12-11 16:01:09 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:01:09 --> Helper loaded: language_helper
DEBUG - 2012-12-11 16:01:09 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 16:01:09 --> Final output sent to browser
DEBUG - 2012-12-11 16:01:09 --> Total execution time: 0.0832
DEBUG - 2012-12-11 16:03:07 --> Config Class Initialized
DEBUG - 2012-12-11 16:03:07 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:03:07 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:03:07 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:03:07 --> URI Class Initialized
DEBUG - 2012-12-11 16:03:07 --> Router Class Initialized
DEBUG - 2012-12-11 16:03:07 --> Output Class Initialized
DEBUG - 2012-12-11 16:03:07 --> Security Class Initialized
DEBUG - 2012-12-11 16:03:07 --> Input Class Initialized
DEBUG - 2012-12-11 16:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:03:07 --> Language Class Initialized
DEBUG - 2012-12-11 16:03:07 --> Loader Class Initialized
DEBUG - 2012-12-11 16:03:07 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:03:07 --> Controller Class Initialized
DEBUG - 2012-12-11 16:03:07 --> Model Class Initialized
DEBUG - 2012-12-11 16:03:07 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:03:07 --> Helper loaded: form_helper
DEBUG - 2012-12-11 16:03:07 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-11 16:03:07 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-11 16:03:07 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-11 16:03:07 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-11 16:03:08 --> Final output sent to browser
DEBUG - 2012-12-11 16:03:08 --> Total execution time: 0.0457
DEBUG - 2012-12-11 16:03:34 --> Config Class Initialized
DEBUG - 2012-12-11 16:03:34 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:03:34 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:03:34 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:03:34 --> URI Class Initialized
DEBUG - 2012-12-11 16:03:34 --> Router Class Initialized
DEBUG - 2012-12-11 16:03:34 --> Output Class Initialized
DEBUG - 2012-12-11 16:03:34 --> Security Class Initialized
DEBUG - 2012-12-11 16:03:34 --> Input Class Initialized
DEBUG - 2012-12-11 16:03:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:03:34 --> Language Class Initialized
DEBUG - 2012-12-11 16:03:34 --> Loader Class Initialized
DEBUG - 2012-12-11 16:03:34 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:03:34 --> Controller Class Initialized
DEBUG - 2012-12-11 16:03:34 --> Model Class Initialized
DEBUG - 2012-12-11 16:03:34 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:03:34 --> Helper loaded: language_helper
DEBUG - 2012-12-11 16:03:34 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 16:03:34 --> Final output sent to browser
DEBUG - 2012-12-11 16:03:34 --> Total execution time: 0.0398
DEBUG - 2012-12-11 16:03:58 --> Config Class Initialized
DEBUG - 2012-12-11 16:03:58 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:03:58 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:03:58 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:03:58 --> URI Class Initialized
DEBUG - 2012-12-11 16:03:58 --> Router Class Initialized
DEBUG - 2012-12-11 16:03:58 --> Output Class Initialized
DEBUG - 2012-12-11 16:03:58 --> Security Class Initialized
DEBUG - 2012-12-11 16:03:58 --> Input Class Initialized
DEBUG - 2012-12-11 16:03:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:03:58 --> Language Class Initialized
DEBUG - 2012-12-11 16:03:58 --> Loader Class Initialized
DEBUG - 2012-12-11 16:03:58 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:03:58 --> Controller Class Initialized
DEBUG - 2012-12-11 16:03:58 --> Model Class Initialized
DEBUG - 2012-12-11 16:03:58 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:03:58 --> Helper loaded: form_helper
DEBUG - 2012-12-11 16:03:58 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-11 16:03:58 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-11 16:03:58 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-11 16:03:58 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-11 16:03:58 --> Final output sent to browser
DEBUG - 2012-12-11 16:03:58 --> Total execution time: 0.0530
DEBUG - 2012-12-11 16:04:02 --> Config Class Initialized
DEBUG - 2012-12-11 16:04:02 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:04:02 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:04:02 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:04:02 --> URI Class Initialized
DEBUG - 2012-12-11 16:04:02 --> Router Class Initialized
ERROR - 2012-12-11 16:04:02 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:04:02 --> Config Class Initialized
DEBUG - 2012-12-11 16:04:02 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:04:02 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:04:02 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:04:02 --> URI Class Initialized
DEBUG - 2012-12-11 16:04:02 --> Router Class Initialized
ERROR - 2012-12-11 16:04:02 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:04:02 --> Config Class Initialized
DEBUG - 2012-12-11 16:04:02 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:04:02 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:04:02 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:04:02 --> URI Class Initialized
DEBUG - 2012-12-11 16:04:02 --> Router Class Initialized
ERROR - 2012-12-11 16:04:02 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:04:04 --> Config Class Initialized
DEBUG - 2012-12-11 16:04:04 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:04:04 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:04:04 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:04:04 --> URI Class Initialized
DEBUG - 2012-12-11 16:04:04 --> Router Class Initialized
DEBUG - 2012-12-11 16:04:04 --> Output Class Initialized
DEBUG - 2012-12-11 16:04:04 --> Security Class Initialized
DEBUG - 2012-12-11 16:04:04 --> Input Class Initialized
DEBUG - 2012-12-11 16:04:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:04:04 --> Language Class Initialized
DEBUG - 2012-12-11 16:04:04 --> Loader Class Initialized
DEBUG - 2012-12-11 16:04:04 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:04:04 --> Controller Class Initialized
DEBUG - 2012-12-11 16:04:04 --> Model Class Initialized
DEBUG - 2012-12-11 16:04:04 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:04:04 --> Helper loaded: language_helper
DEBUG - 2012-12-11 16:04:04 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 16:04:04 --> Final output sent to browser
DEBUG - 2012-12-11 16:04:04 --> Total execution time: 0.0424
DEBUG - 2012-12-11 16:04:58 --> Config Class Initialized
DEBUG - 2012-12-11 16:04:58 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:04:58 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:04:58 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:04:58 --> URI Class Initialized
DEBUG - 2012-12-11 16:04:58 --> Router Class Initialized
DEBUG - 2012-12-11 16:04:58 --> Output Class Initialized
DEBUG - 2012-12-11 16:04:58 --> Security Class Initialized
DEBUG - 2012-12-11 16:04:59 --> Input Class Initialized
DEBUG - 2012-12-11 16:04:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:04:59 --> Language Class Initialized
DEBUG - 2012-12-11 16:04:59 --> Loader Class Initialized
DEBUG - 2012-12-11 16:04:59 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:04:59 --> Controller Class Initialized
DEBUG - 2012-12-11 16:04:59 --> Model Class Initialized
DEBUG - 2012-12-11 16:04:59 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:04:59 --> Helper loaded: form_helper
DEBUG - 2012-12-11 16:04:59 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-11 16:04:59 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-11 16:04:59 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-11 16:04:59 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-11 16:04:59 --> Final output sent to browser
DEBUG - 2012-12-11 16:04:59 --> Total execution time: 0.0458
DEBUG - 2012-12-11 16:05:04 --> Config Class Initialized
DEBUG - 2012-12-11 16:05:04 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:05:04 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:05:04 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:05:04 --> URI Class Initialized
DEBUG - 2012-12-11 16:05:04 --> Router Class Initialized
ERROR - 2012-12-11 16:05:04 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:05:04 --> Config Class Initialized
DEBUG - 2012-12-11 16:05:04 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:05:04 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:05:04 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:05:04 --> URI Class Initialized
DEBUG - 2012-12-11 16:05:04 --> Router Class Initialized
ERROR - 2012-12-11 16:05:04 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:05:04 --> Config Class Initialized
DEBUG - 2012-12-11 16:05:04 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:05:04 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:05:04 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:05:04 --> URI Class Initialized
DEBUG - 2012-12-11 16:05:04 --> Router Class Initialized
ERROR - 2012-12-11 16:05:04 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:05:08 --> Config Class Initialized
DEBUG - 2012-12-11 16:05:08 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:05:08 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:05:08 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:05:08 --> URI Class Initialized
DEBUG - 2012-12-11 16:05:08 --> Router Class Initialized
DEBUG - 2012-12-11 16:05:08 --> Output Class Initialized
DEBUG - 2012-12-11 16:05:08 --> Security Class Initialized
DEBUG - 2012-12-11 16:05:08 --> Input Class Initialized
DEBUG - 2012-12-11 16:05:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:05:08 --> Language Class Initialized
DEBUG - 2012-12-11 16:05:08 --> Loader Class Initialized
DEBUG - 2012-12-11 16:05:08 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:05:08 --> Controller Class Initialized
DEBUG - 2012-12-11 16:05:08 --> Model Class Initialized
DEBUG - 2012-12-11 16:05:08 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:05:08 --> Helper loaded: language_helper
DEBUG - 2012-12-11 16:05:08 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 16:05:08 --> Final output sent to browser
DEBUG - 2012-12-11 16:05:08 --> Total execution time: 0.0377
DEBUG - 2012-12-11 16:05:28 --> Config Class Initialized
DEBUG - 2012-12-11 16:05:28 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:05:28 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:05:28 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:05:28 --> URI Class Initialized
DEBUG - 2012-12-11 16:05:28 --> Router Class Initialized
DEBUG - 2012-12-11 16:05:28 --> Output Class Initialized
DEBUG - 2012-12-11 16:05:28 --> Security Class Initialized
DEBUG - 2012-12-11 16:05:28 --> Input Class Initialized
DEBUG - 2012-12-11 16:05:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:05:28 --> Language Class Initialized
DEBUG - 2012-12-11 16:05:28 --> Loader Class Initialized
DEBUG - 2012-12-11 16:05:28 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:05:28 --> Controller Class Initialized
DEBUG - 2012-12-11 16:05:28 --> Model Class Initialized
DEBUG - 2012-12-11 16:05:28 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:05:28 --> Helper loaded: form_helper
DEBUG - 2012-12-11 16:05:28 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-11 16:05:28 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-11 16:05:28 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-11 16:05:28 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-11 16:05:29 --> Final output sent to browser
DEBUG - 2012-12-11 16:05:29 --> Total execution time: 0.0452
DEBUG - 2012-12-11 16:05:33 --> Config Class Initialized
DEBUG - 2012-12-11 16:05:33 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:05:33 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:05:33 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:05:33 --> URI Class Initialized
DEBUG - 2012-12-11 16:05:33 --> Router Class Initialized
ERROR - 2012-12-11 16:05:33 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:05:33 --> Config Class Initialized
DEBUG - 2012-12-11 16:05:33 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:05:33 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:05:33 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:05:33 --> URI Class Initialized
DEBUG - 2012-12-11 16:05:33 --> Router Class Initialized
ERROR - 2012-12-11 16:05:33 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:05:33 --> Config Class Initialized
DEBUG - 2012-12-11 16:05:33 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:05:33 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:05:33 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:05:33 --> URI Class Initialized
DEBUG - 2012-12-11 16:05:33 --> Router Class Initialized
ERROR - 2012-12-11 16:05:33 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:06:10 --> Config Class Initialized
DEBUG - 2012-12-11 16:06:10 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:06:10 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:06:10 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:06:10 --> URI Class Initialized
DEBUG - 2012-12-11 16:06:10 --> Router Class Initialized
DEBUG - 2012-12-11 16:06:10 --> Output Class Initialized
DEBUG - 2012-12-11 16:06:10 --> Security Class Initialized
DEBUG - 2012-12-11 16:06:10 --> Input Class Initialized
DEBUG - 2012-12-11 16:06:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:06:10 --> Language Class Initialized
DEBUG - 2012-12-11 16:06:10 --> Loader Class Initialized
DEBUG - 2012-12-11 16:06:10 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:06:10 --> Controller Class Initialized
DEBUG - 2012-12-11 16:06:10 --> Model Class Initialized
DEBUG - 2012-12-11 16:06:10 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:06:10 --> Helper loaded: language_helper
DEBUG - 2012-12-11 16:06:10 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 16:06:10 --> Final output sent to browser
DEBUG - 2012-12-11 16:06:10 --> Total execution time: 0.0372
DEBUG - 2012-12-11 16:06:18 --> Config Class Initialized
DEBUG - 2012-12-11 16:06:18 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:06:18 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:06:18 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:06:18 --> URI Class Initialized
DEBUG - 2012-12-11 16:06:18 --> Router Class Initialized
DEBUG - 2012-12-11 16:06:18 --> Output Class Initialized
DEBUG - 2012-12-11 16:06:18 --> Security Class Initialized
DEBUG - 2012-12-11 16:06:18 --> Input Class Initialized
DEBUG - 2012-12-11 16:06:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:06:18 --> Language Class Initialized
DEBUG - 2012-12-11 16:06:18 --> Loader Class Initialized
DEBUG - 2012-12-11 16:06:18 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:06:18 --> Controller Class Initialized
DEBUG - 2012-12-11 16:06:18 --> Model Class Initialized
DEBUG - 2012-12-11 16:06:18 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:06:18 --> Helper loaded: language_helper
DEBUG - 2012-12-11 16:06:18 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 16:06:18 --> Final output sent to browser
DEBUG - 2012-12-11 16:06:18 --> Total execution time: 0.0367
DEBUG - 2012-12-11 16:07:15 --> Config Class Initialized
DEBUG - 2012-12-11 16:07:15 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:07:15 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:07:15 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:07:15 --> URI Class Initialized
DEBUG - 2012-12-11 16:07:15 --> Router Class Initialized
DEBUG - 2012-12-11 16:07:15 --> Output Class Initialized
DEBUG - 2012-12-11 16:07:15 --> Security Class Initialized
DEBUG - 2012-12-11 16:07:15 --> Input Class Initialized
DEBUG - 2012-12-11 16:07:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:07:15 --> Language Class Initialized
DEBUG - 2012-12-11 16:07:15 --> Loader Class Initialized
DEBUG - 2012-12-11 16:07:15 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:07:15 --> Controller Class Initialized
DEBUG - 2012-12-11 16:07:15 --> Model Class Initialized
DEBUG - 2012-12-11 16:07:15 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:07:15 --> Helper loaded: form_helper
DEBUG - 2012-12-11 16:07:15 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-11 16:07:15 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-11 16:07:15 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-11 16:07:15 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-11 16:07:15 --> Final output sent to browser
DEBUG - 2012-12-11 16:07:15 --> Total execution time: 0.0485
DEBUG - 2012-12-11 16:07:20 --> Config Class Initialized
DEBUG - 2012-12-11 16:07:20 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:07:20 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:07:20 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:07:20 --> URI Class Initialized
DEBUG - 2012-12-11 16:07:20 --> Router Class Initialized
ERROR - 2012-12-11 16:07:20 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:07:20 --> Config Class Initialized
DEBUG - 2012-12-11 16:07:20 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:07:20 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:07:20 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:07:20 --> URI Class Initialized
DEBUG - 2012-12-11 16:07:20 --> Router Class Initialized
ERROR - 2012-12-11 16:07:20 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:07:20 --> Config Class Initialized
DEBUG - 2012-12-11 16:07:20 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:07:20 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:07:20 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:07:20 --> URI Class Initialized
DEBUG - 2012-12-11 16:07:20 --> Router Class Initialized
ERROR - 2012-12-11 16:07:20 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:07:22 --> Config Class Initialized
DEBUG - 2012-12-11 16:07:22 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:07:22 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:07:22 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:07:22 --> URI Class Initialized
DEBUG - 2012-12-11 16:07:22 --> Router Class Initialized
DEBUG - 2012-12-11 16:07:22 --> Output Class Initialized
DEBUG - 2012-12-11 16:07:22 --> Security Class Initialized
DEBUG - 2012-12-11 16:07:22 --> Input Class Initialized
DEBUG - 2012-12-11 16:07:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:07:22 --> Language Class Initialized
DEBUG - 2012-12-11 16:07:22 --> Loader Class Initialized
DEBUG - 2012-12-11 16:07:22 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:07:22 --> Controller Class Initialized
DEBUG - 2012-12-11 16:07:22 --> Model Class Initialized
DEBUG - 2012-12-11 16:07:22 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:07:22 --> Helper loaded: language_helper
DEBUG - 2012-12-11 16:07:22 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 16:07:22 --> Final output sent to browser
DEBUG - 2012-12-11 16:07:22 --> Total execution time: 0.0420
DEBUG - 2012-12-11 16:07:56 --> Config Class Initialized
DEBUG - 2012-12-11 16:07:56 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:07:56 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:07:56 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:07:56 --> URI Class Initialized
DEBUG - 2012-12-11 16:07:56 --> Router Class Initialized
DEBUG - 2012-12-11 16:07:56 --> Output Class Initialized
DEBUG - 2012-12-11 16:07:56 --> Security Class Initialized
DEBUG - 2012-12-11 16:07:56 --> Input Class Initialized
DEBUG - 2012-12-11 16:07:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:07:56 --> Language Class Initialized
DEBUG - 2012-12-11 16:07:56 --> Loader Class Initialized
DEBUG - 2012-12-11 16:07:56 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:07:56 --> Controller Class Initialized
DEBUG - 2012-12-11 16:07:56 --> Model Class Initialized
DEBUG - 2012-12-11 16:07:56 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:07:56 --> Helper loaded: form_helper
DEBUG - 2012-12-11 16:07:56 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-11 16:07:56 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-11 16:07:56 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-11 16:07:56 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-11 16:07:57 --> Final output sent to browser
DEBUG - 2012-12-11 16:07:57 --> Total execution time: 0.0443
DEBUG - 2012-12-11 16:08:03 --> Config Class Initialized
DEBUG - 2012-12-11 16:08:03 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:08:03 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:08:03 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:08:03 --> URI Class Initialized
DEBUG - 2012-12-11 16:08:03 --> Router Class Initialized
ERROR - 2012-12-11 16:08:03 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:08:03 --> Config Class Initialized
DEBUG - 2012-12-11 16:08:03 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:08:03 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:08:03 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:08:03 --> URI Class Initialized
DEBUG - 2012-12-11 16:08:03 --> Router Class Initialized
ERROR - 2012-12-11 16:08:03 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:08:03 --> Config Class Initialized
DEBUG - 2012-12-11 16:08:03 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:08:03 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:08:03 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:08:03 --> URI Class Initialized
DEBUG - 2012-12-11 16:08:03 --> Router Class Initialized
ERROR - 2012-12-11 16:08:03 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:08:05 --> Config Class Initialized
DEBUG - 2012-12-11 16:08:05 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:08:05 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:08:05 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:08:05 --> URI Class Initialized
DEBUG - 2012-12-11 16:08:05 --> Router Class Initialized
DEBUG - 2012-12-11 16:08:05 --> Output Class Initialized
DEBUG - 2012-12-11 16:08:05 --> Security Class Initialized
DEBUG - 2012-12-11 16:08:05 --> Input Class Initialized
DEBUG - 2012-12-11 16:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:08:05 --> Language Class Initialized
DEBUG - 2012-12-11 16:08:05 --> Loader Class Initialized
DEBUG - 2012-12-11 16:08:05 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:08:05 --> Controller Class Initialized
DEBUG - 2012-12-11 16:08:05 --> Model Class Initialized
DEBUG - 2012-12-11 16:08:05 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:08:05 --> Helper loaded: language_helper
DEBUG - 2012-12-11 16:08:05 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 16:08:05 --> Final output sent to browser
DEBUG - 2012-12-11 16:08:05 --> Total execution time: 0.0472
DEBUG - 2012-12-11 16:09:34 --> Config Class Initialized
DEBUG - 2012-12-11 16:09:34 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:09:34 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:09:34 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:09:34 --> URI Class Initialized
DEBUG - 2012-12-11 16:09:34 --> Router Class Initialized
DEBUG - 2012-12-11 16:09:34 --> Output Class Initialized
DEBUG - 2012-12-11 16:09:34 --> Security Class Initialized
DEBUG - 2012-12-11 16:09:34 --> Input Class Initialized
DEBUG - 2012-12-11 16:09:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:09:34 --> Language Class Initialized
DEBUG - 2012-12-11 16:09:34 --> Loader Class Initialized
DEBUG - 2012-12-11 16:09:34 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:09:34 --> Controller Class Initialized
DEBUG - 2012-12-11 16:09:34 --> Model Class Initialized
DEBUG - 2012-12-11 16:09:34 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:09:34 --> Helper loaded: form_helper
DEBUG - 2012-12-11 16:09:34 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-11 16:09:34 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-11 16:09:34 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-11 16:09:34 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-11 16:09:34 --> Final output sent to browser
DEBUG - 2012-12-11 16:09:34 --> Total execution time: 0.0437
DEBUG - 2012-12-11 16:09:40 --> Config Class Initialized
DEBUG - 2012-12-11 16:09:40 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:09:40 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:09:40 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:09:40 --> URI Class Initialized
DEBUG - 2012-12-11 16:09:40 --> Router Class Initialized
ERROR - 2012-12-11 16:09:40 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:09:40 --> Config Class Initialized
DEBUG - 2012-12-11 16:09:40 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:09:40 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:09:40 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:09:40 --> URI Class Initialized
DEBUG - 2012-12-11 16:09:40 --> Router Class Initialized
ERROR - 2012-12-11 16:09:40 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:09:40 --> Config Class Initialized
DEBUG - 2012-12-11 16:09:40 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:09:40 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:09:40 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:09:40 --> URI Class Initialized
DEBUG - 2012-12-11 16:09:40 --> Router Class Initialized
ERROR - 2012-12-11 16:09:40 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:10:27 --> Config Class Initialized
DEBUG - 2012-12-11 16:10:27 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:10:27 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:10:27 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:10:27 --> URI Class Initialized
DEBUG - 2012-12-11 16:10:27 --> Router Class Initialized
DEBUG - 2012-12-11 16:10:27 --> Output Class Initialized
DEBUG - 2012-12-11 16:10:27 --> Security Class Initialized
DEBUG - 2012-12-11 16:10:27 --> Input Class Initialized
DEBUG - 2012-12-11 16:10:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:10:27 --> Language Class Initialized
DEBUG - 2012-12-11 16:10:27 --> Loader Class Initialized
DEBUG - 2012-12-11 16:10:27 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:10:27 --> Controller Class Initialized
DEBUG - 2012-12-11 16:10:27 --> Model Class Initialized
DEBUG - 2012-12-11 16:10:27 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:10:27 --> Helper loaded: language_helper
DEBUG - 2012-12-11 16:10:27 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 16:10:27 --> Final output sent to browser
DEBUG - 2012-12-11 16:10:27 --> Total execution time: 0.0413
DEBUG - 2012-12-11 16:11:14 --> Config Class Initialized
DEBUG - 2012-12-11 16:11:14 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:11:14 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:11:14 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:11:14 --> URI Class Initialized
DEBUG - 2012-12-11 16:11:14 --> Router Class Initialized
DEBUG - 2012-12-11 16:11:14 --> Output Class Initialized
DEBUG - 2012-12-11 16:11:14 --> Security Class Initialized
DEBUG - 2012-12-11 16:11:14 --> Input Class Initialized
DEBUG - 2012-12-11 16:11:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:11:14 --> Language Class Initialized
DEBUG - 2012-12-11 16:11:14 --> Loader Class Initialized
DEBUG - 2012-12-11 16:11:14 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:11:14 --> Controller Class Initialized
DEBUG - 2012-12-11 16:11:14 --> Model Class Initialized
DEBUG - 2012-12-11 16:11:14 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:11:14 --> Helper loaded: form_helper
DEBUG - 2012-12-11 16:11:14 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-11 16:11:14 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-11 16:11:14 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-11 16:11:14 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-11 16:11:14 --> Final output sent to browser
DEBUG - 2012-12-11 16:11:14 --> Total execution time: 0.0479
DEBUG - 2012-12-11 16:11:19 --> Config Class Initialized
DEBUG - 2012-12-11 16:11:19 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:11:19 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:11:19 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:11:19 --> URI Class Initialized
DEBUG - 2012-12-11 16:11:19 --> Router Class Initialized
ERROR - 2012-12-11 16:11:19 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:11:19 --> Config Class Initialized
DEBUG - 2012-12-11 16:11:19 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:11:19 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:11:19 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:11:19 --> URI Class Initialized
DEBUG - 2012-12-11 16:11:19 --> Router Class Initialized
ERROR - 2012-12-11 16:11:19 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:11:19 --> Config Class Initialized
DEBUG - 2012-12-11 16:11:19 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:11:19 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:11:19 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:11:19 --> URI Class Initialized
DEBUG - 2012-12-11 16:11:19 --> Router Class Initialized
ERROR - 2012-12-11 16:11:19 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:11:21 --> Config Class Initialized
DEBUG - 2012-12-11 16:11:21 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:11:21 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:11:21 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:11:21 --> URI Class Initialized
DEBUG - 2012-12-11 16:11:21 --> Router Class Initialized
DEBUG - 2012-12-11 16:11:21 --> Output Class Initialized
DEBUG - 2012-12-11 16:11:21 --> Security Class Initialized
DEBUG - 2012-12-11 16:11:21 --> Input Class Initialized
DEBUG - 2012-12-11 16:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:11:21 --> Language Class Initialized
DEBUG - 2012-12-11 16:11:21 --> Loader Class Initialized
DEBUG - 2012-12-11 16:11:21 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:11:21 --> Controller Class Initialized
DEBUG - 2012-12-11 16:11:21 --> Model Class Initialized
DEBUG - 2012-12-11 16:11:21 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:11:21 --> Helper loaded: language_helper
DEBUG - 2012-12-11 16:11:21 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 16:11:21 --> Final output sent to browser
DEBUG - 2012-12-11 16:11:21 --> Total execution time: 0.0380
DEBUG - 2012-12-11 16:26:03 --> Config Class Initialized
DEBUG - 2012-12-11 16:26:03 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:26:03 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:26:03 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:26:03 --> URI Class Initialized
DEBUG - 2012-12-11 16:26:03 --> Router Class Initialized
DEBUG - 2012-12-11 16:26:03 --> Output Class Initialized
DEBUG - 2012-12-11 16:26:03 --> Security Class Initialized
DEBUG - 2012-12-11 16:26:03 --> Input Class Initialized
DEBUG - 2012-12-11 16:26:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:26:03 --> Language Class Initialized
DEBUG - 2012-12-11 16:26:03 --> Loader Class Initialized
DEBUG - 2012-12-11 16:26:03 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:26:03 --> Controller Class Initialized
DEBUG - 2012-12-11 16:26:03 --> Model Class Initialized
DEBUG - 2012-12-11 16:26:03 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:26:03 --> Helper loaded: language_helper
DEBUG - 2012-12-11 16:26:03 --> Language file loaded: language/english/message_lang.php
ERROR - 2012-12-11 16:26:03 --> Severity: Notice  --> Undefined property: Pricing::$business_model /home/jwp/www/justinwylliephotography.com/clients/application/controllers/admin/pricing.php 144
DEBUG - 2012-12-11 16:28:22 --> Config Class Initialized
DEBUG - 2012-12-11 16:28:22 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:28:22 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:28:22 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:28:22 --> URI Class Initialized
DEBUG - 2012-12-11 16:28:22 --> Router Class Initialized
DEBUG - 2012-12-11 16:28:22 --> Output Class Initialized
DEBUG - 2012-12-11 16:28:22 --> Security Class Initialized
DEBUG - 2012-12-11 16:28:22 --> Input Class Initialized
DEBUG - 2012-12-11 16:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:28:22 --> Language Class Initialized
DEBUG - 2012-12-11 16:28:22 --> Loader Class Initialized
DEBUG - 2012-12-11 16:28:22 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:28:22 --> Controller Class Initialized
DEBUG - 2012-12-11 16:28:22 --> Model Class Initialized
DEBUG - 2012-12-11 16:28:22 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:28:22 --> Helper loaded: form_helper
DEBUG - 2012-12-11 16:28:22 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-11 16:28:22 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-11 16:28:22 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-11 16:28:22 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-11 16:28:23 --> Final output sent to browser
DEBUG - 2012-12-11 16:28:23 --> Total execution time: 0.0441
DEBUG - 2012-12-11 16:28:29 --> Config Class Initialized
DEBUG - 2012-12-11 16:28:29 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:28:29 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:28:29 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:28:29 --> URI Class Initialized
DEBUG - 2012-12-11 16:28:29 --> Router Class Initialized
ERROR - 2012-12-11 16:28:29 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:28:29 --> Config Class Initialized
DEBUG - 2012-12-11 16:28:29 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:28:29 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:28:29 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:28:29 --> URI Class Initialized
DEBUG - 2012-12-11 16:28:29 --> Router Class Initialized
ERROR - 2012-12-11 16:28:29 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:28:29 --> Config Class Initialized
DEBUG - 2012-12-11 16:28:29 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:28:29 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:28:29 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:28:29 --> URI Class Initialized
DEBUG - 2012-12-11 16:28:29 --> Router Class Initialized
ERROR - 2012-12-11 16:28:29 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:28:31 --> Config Class Initialized
DEBUG - 2012-12-11 16:28:31 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:28:31 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:28:31 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:28:31 --> URI Class Initialized
DEBUG - 2012-12-11 16:28:31 --> Router Class Initialized
DEBUG - 2012-12-11 16:28:31 --> Output Class Initialized
DEBUG - 2012-12-11 16:28:31 --> Security Class Initialized
DEBUG - 2012-12-11 16:28:31 --> Input Class Initialized
DEBUG - 2012-12-11 16:28:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:28:31 --> Language Class Initialized
DEBUG - 2012-12-11 16:28:31 --> Loader Class Initialized
DEBUG - 2012-12-11 16:28:31 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:28:31 --> Controller Class Initialized
DEBUG - 2012-12-11 16:28:31 --> Model Class Initialized
DEBUG - 2012-12-11 16:28:32 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:28:32 --> Helper loaded: language_helper
DEBUG - 2012-12-11 16:28:32 --> Language file loaded: language/english/message_lang.php
ERROR - 2012-12-11 16:28:32 --> Severity: Notice  --> Trying to get property of non-object /home/jwp/www/justinwylliephotography.com/clients/application/controllers/admin/pricing.php 148
DEBUG - 2012-12-11 16:28:32 --> Final output sent to browser
DEBUG - 2012-12-11 16:28:32 --> Total execution time: 0.0820
DEBUG - 2012-12-11 16:29:47 --> Config Class Initialized
DEBUG - 2012-12-11 16:29:47 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:29:47 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:29:47 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:29:47 --> URI Class Initialized
DEBUG - 2012-12-11 16:29:47 --> Router Class Initialized
DEBUG - 2012-12-11 16:29:47 --> Output Class Initialized
DEBUG - 2012-12-11 16:29:47 --> Security Class Initialized
DEBUG - 2012-12-11 16:29:47 --> Input Class Initialized
DEBUG - 2012-12-11 16:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:29:47 --> Language Class Initialized
DEBUG - 2012-12-11 16:29:47 --> Loader Class Initialized
DEBUG - 2012-12-11 16:29:47 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:29:47 --> Controller Class Initialized
DEBUG - 2012-12-11 16:29:47 --> Model Class Initialized
DEBUG - 2012-12-11 16:29:47 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:29:47 --> Helper loaded: language_helper
DEBUG - 2012-12-11 16:29:47 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 16:32:02 --> Config Class Initialized
DEBUG - 2012-12-11 16:32:02 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:32:02 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:32:02 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:32:02 --> URI Class Initialized
DEBUG - 2012-12-11 16:32:02 --> Router Class Initialized
DEBUG - 2012-12-11 16:32:02 --> Output Class Initialized
DEBUG - 2012-12-11 16:32:02 --> Security Class Initialized
DEBUG - 2012-12-11 16:32:02 --> Input Class Initialized
DEBUG - 2012-12-11 16:32:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:32:02 --> Language Class Initialized
DEBUG - 2012-12-11 16:32:02 --> Loader Class Initialized
DEBUG - 2012-12-11 16:32:02 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:32:02 --> Controller Class Initialized
DEBUG - 2012-12-11 16:32:02 --> Model Class Initialized
DEBUG - 2012-12-11 16:32:02 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:32:02 --> Helper loaded: form_helper
DEBUG - 2012-12-11 16:32:02 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-11 16:32:02 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-11 16:32:02 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-11 16:32:02 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-11 16:32:03 --> Final output sent to browser
DEBUG - 2012-12-11 16:32:03 --> Total execution time: 0.2797
DEBUG - 2012-12-11 16:32:10 --> Config Class Initialized
DEBUG - 2012-12-11 16:32:10 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:32:10 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:32:10 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:32:10 --> URI Class Initialized
DEBUG - 2012-12-11 16:32:10 --> Router Class Initialized
DEBUG - 2012-12-11 16:32:10 --> Config Class Initialized
DEBUG - 2012-12-11 16:32:10 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:32:10 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:32:10 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:32:10 --> URI Class Initialized
DEBUG - 2012-12-11 16:32:10 --> Router Class Initialized
ERROR - 2012-12-11 16:32:10 --> 404 Page Not Found --> css
ERROR - 2012-12-11 16:32:10 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:32:10 --> Config Class Initialized
DEBUG - 2012-12-11 16:32:10 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:32:10 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:32:10 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:32:10 --> URI Class Initialized
DEBUG - 2012-12-11 16:32:10 --> Router Class Initialized
ERROR - 2012-12-11 16:32:10 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:32:13 --> Config Class Initialized
DEBUG - 2012-12-11 16:32:13 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:32:13 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:32:13 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:32:13 --> URI Class Initialized
DEBUG - 2012-12-11 16:32:13 --> Router Class Initialized
DEBUG - 2012-12-11 16:32:13 --> Output Class Initialized
DEBUG - 2012-12-11 16:32:13 --> Security Class Initialized
DEBUG - 2012-12-11 16:32:13 --> Input Class Initialized
DEBUG - 2012-12-11 16:32:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:32:13 --> Language Class Initialized
DEBUG - 2012-12-11 16:32:13 --> Loader Class Initialized
DEBUG - 2012-12-11 16:32:13 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:32:13 --> Controller Class Initialized
DEBUG - 2012-12-11 16:32:13 --> Model Class Initialized
DEBUG - 2012-12-11 16:32:13 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:32:13 --> Helper loaded: language_helper
DEBUG - 2012-12-11 16:32:13 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 16:35:35 --> Config Class Initialized
DEBUG - 2012-12-11 16:35:35 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:35:35 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:35:35 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:35:35 --> URI Class Initialized
DEBUG - 2012-12-11 16:35:35 --> Router Class Initialized
DEBUG - 2012-12-11 16:35:35 --> Output Class Initialized
DEBUG - 2012-12-11 16:35:35 --> Security Class Initialized
DEBUG - 2012-12-11 16:35:35 --> Input Class Initialized
DEBUG - 2012-12-11 16:35:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:35:35 --> Language Class Initialized
DEBUG - 2012-12-11 16:35:35 --> Loader Class Initialized
DEBUG - 2012-12-11 16:35:35 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:35:35 --> Controller Class Initialized
DEBUG - 2012-12-11 16:35:35 --> Model Class Initialized
DEBUG - 2012-12-11 16:35:35 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:35:35 --> Helper loaded: language_helper
DEBUG - 2012-12-11 16:35:35 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 16:39:21 --> Config Class Initialized
DEBUG - 2012-12-11 16:39:21 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:39:21 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:39:21 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:39:21 --> URI Class Initialized
DEBUG - 2012-12-11 16:39:21 --> Router Class Initialized
DEBUG - 2012-12-11 16:39:21 --> Output Class Initialized
DEBUG - 2012-12-11 16:39:21 --> Security Class Initialized
DEBUG - 2012-12-11 16:39:21 --> Input Class Initialized
DEBUG - 2012-12-11 16:39:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:39:21 --> Language Class Initialized
DEBUG - 2012-12-11 16:39:21 --> Loader Class Initialized
DEBUG - 2012-12-11 16:39:21 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:39:21 --> Controller Class Initialized
DEBUG - 2012-12-11 16:39:21 --> Model Class Initialized
DEBUG - 2012-12-11 16:39:21 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:39:21 --> Helper loaded: form_helper
DEBUG - 2012-12-11 16:39:54 --> Config Class Initialized
DEBUG - 2012-12-11 16:39:54 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:39:54 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:39:54 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:39:54 --> URI Class Initialized
DEBUG - 2012-12-11 16:39:54 --> Router Class Initialized
DEBUG - 2012-12-11 16:39:54 --> Output Class Initialized
DEBUG - 2012-12-11 16:39:54 --> Security Class Initialized
DEBUG - 2012-12-11 16:39:54 --> Input Class Initialized
DEBUG - 2012-12-11 16:39:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:39:54 --> Language Class Initialized
DEBUG - 2012-12-11 16:39:54 --> Loader Class Initialized
DEBUG - 2012-12-11 16:39:54 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:39:54 --> Controller Class Initialized
DEBUG - 2012-12-11 16:39:54 --> Model Class Initialized
DEBUG - 2012-12-11 16:39:54 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:39:54 --> Helper loaded: form_helper
DEBUG - 2012-12-11 16:41:01 --> Config Class Initialized
DEBUG - 2012-12-11 16:41:01 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:41:01 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:41:01 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:41:01 --> URI Class Initialized
DEBUG - 2012-12-11 16:41:01 --> Router Class Initialized
DEBUG - 2012-12-11 16:41:01 --> Output Class Initialized
DEBUG - 2012-12-11 16:41:01 --> Security Class Initialized
DEBUG - 2012-12-11 16:41:01 --> Input Class Initialized
DEBUG - 2012-12-11 16:41:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:41:01 --> Language Class Initialized
DEBUG - 2012-12-11 16:41:01 --> Loader Class Initialized
DEBUG - 2012-12-11 16:41:01 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:41:01 --> Controller Class Initialized
DEBUG - 2012-12-11 16:41:01 --> Model Class Initialized
DEBUG - 2012-12-11 16:41:01 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:41:01 --> Helper loaded: form_helper
DEBUG - 2012-12-11 16:41:01 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-11 16:41:01 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-11 16:41:01 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-11 16:41:01 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-11 16:41:01 --> Final output sent to browser
DEBUG - 2012-12-11 16:41:01 --> Total execution time: 0.0596
DEBUG - 2012-12-11 16:41:05 --> Config Class Initialized
DEBUG - 2012-12-11 16:41:05 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:41:05 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:41:05 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:41:05 --> URI Class Initialized
DEBUG - 2012-12-11 16:41:05 --> Router Class Initialized
ERROR - 2012-12-11 16:41:05 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:41:05 --> Config Class Initialized
DEBUG - 2012-12-11 16:41:05 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:41:05 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:41:05 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:41:05 --> URI Class Initialized
DEBUG - 2012-12-11 16:41:05 --> Router Class Initialized
ERROR - 2012-12-11 16:41:05 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:41:05 --> Config Class Initialized
DEBUG - 2012-12-11 16:41:05 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:41:05 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:41:05 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:41:05 --> URI Class Initialized
DEBUG - 2012-12-11 16:41:05 --> Router Class Initialized
ERROR - 2012-12-11 16:41:05 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:41:07 --> Config Class Initialized
DEBUG - 2012-12-11 16:41:07 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:41:07 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:41:07 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:41:07 --> URI Class Initialized
DEBUG - 2012-12-11 16:41:07 --> Router Class Initialized
DEBUG - 2012-12-11 16:41:07 --> Output Class Initialized
DEBUG - 2012-12-11 16:41:07 --> Security Class Initialized
DEBUG - 2012-12-11 16:41:07 --> Input Class Initialized
DEBUG - 2012-12-11 16:41:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:41:07 --> Language Class Initialized
DEBUG - 2012-12-11 16:41:07 --> Loader Class Initialized
DEBUG - 2012-12-11 16:41:07 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:41:07 --> Controller Class Initialized
DEBUG - 2012-12-11 16:41:07 --> Model Class Initialized
DEBUG - 2012-12-11 16:41:07 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:41:07 --> Helper loaded: language_helper
DEBUG - 2012-12-11 16:41:07 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 16:41:07 --> Final output sent to browser
DEBUG - 2012-12-11 16:41:07 --> Total execution time: 0.0885
DEBUG - 2012-12-11 16:43:46 --> Config Class Initialized
DEBUG - 2012-12-11 16:43:46 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:43:46 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:43:46 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:43:46 --> URI Class Initialized
DEBUG - 2012-12-11 16:43:46 --> Router Class Initialized
DEBUG - 2012-12-11 16:43:46 --> Output Class Initialized
DEBUG - 2012-12-11 16:43:46 --> Security Class Initialized
DEBUG - 2012-12-11 16:43:46 --> Input Class Initialized
DEBUG - 2012-12-11 16:43:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:43:46 --> Language Class Initialized
DEBUG - 2012-12-11 16:43:46 --> Loader Class Initialized
DEBUG - 2012-12-11 16:43:46 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:43:46 --> Controller Class Initialized
DEBUG - 2012-12-11 16:43:46 --> Model Class Initialized
DEBUG - 2012-12-11 16:43:46 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:43:46 --> Helper loaded: language_helper
DEBUG - 2012-12-11 16:43:46 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 16:43:46 --> Final output sent to browser
DEBUG - 2012-12-11 16:43:46 --> Total execution time: 0.1339
DEBUG - 2012-12-11 16:45:19 --> Config Class Initialized
DEBUG - 2012-12-11 16:45:19 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:45:19 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:45:19 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:45:19 --> URI Class Initialized
DEBUG - 2012-12-11 16:45:19 --> Router Class Initialized
DEBUG - 2012-12-11 16:45:19 --> Output Class Initialized
DEBUG - 2012-12-11 16:45:19 --> Security Class Initialized
DEBUG - 2012-12-11 16:45:19 --> Input Class Initialized
DEBUG - 2012-12-11 16:45:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:45:19 --> Language Class Initialized
DEBUG - 2012-12-11 16:45:19 --> Loader Class Initialized
DEBUG - 2012-12-11 16:45:19 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:45:19 --> Controller Class Initialized
DEBUG - 2012-12-11 16:45:19 --> Model Class Initialized
DEBUG - 2012-12-11 16:45:19 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:45:19 --> Helper loaded: form_helper
DEBUG - 2012-12-11 16:45:19 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-11 16:45:19 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-11 16:45:19 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-11 16:45:19 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-11 16:45:20 --> Final output sent to browser
DEBUG - 2012-12-11 16:45:20 --> Total execution time: 0.0487
DEBUG - 2012-12-11 16:45:24 --> Config Class Initialized
DEBUG - 2012-12-11 16:45:24 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:45:24 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:45:24 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:45:24 --> URI Class Initialized
DEBUG - 2012-12-11 16:45:24 --> Router Class Initialized
ERROR - 2012-12-11 16:45:24 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:45:24 --> Config Class Initialized
DEBUG - 2012-12-11 16:45:24 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:45:24 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:45:24 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:45:24 --> URI Class Initialized
DEBUG - 2012-12-11 16:45:24 --> Router Class Initialized
ERROR - 2012-12-11 16:45:24 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:45:24 --> Config Class Initialized
DEBUG - 2012-12-11 16:45:24 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:45:24 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:45:24 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:45:24 --> URI Class Initialized
DEBUG - 2012-12-11 16:45:24 --> Router Class Initialized
ERROR - 2012-12-11 16:45:24 --> 404 Page Not Found --> css
DEBUG - 2012-12-11 16:45:26 --> Config Class Initialized
DEBUG - 2012-12-11 16:45:26 --> Hooks Class Initialized
DEBUG - 2012-12-11 16:45:26 --> Utf8 Class Initialized
DEBUG - 2012-12-11 16:45:26 --> UTF-8 Support Enabled
DEBUG - 2012-12-11 16:45:26 --> URI Class Initialized
DEBUG - 2012-12-11 16:45:27 --> Router Class Initialized
DEBUG - 2012-12-11 16:45:27 --> Output Class Initialized
DEBUG - 2012-12-11 16:45:27 --> Security Class Initialized
DEBUG - 2012-12-11 16:45:27 --> Input Class Initialized
DEBUG - 2012-12-11 16:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-11 16:45:27 --> Language Class Initialized
DEBUG - 2012-12-11 16:45:27 --> Loader Class Initialized
DEBUG - 2012-12-11 16:45:27 --> Helper loaded: url_helper
DEBUG - 2012-12-11 16:45:27 --> Controller Class Initialized
DEBUG - 2012-12-11 16:45:27 --> Model Class Initialized
DEBUG - 2012-12-11 16:45:27 --> Database Driver Class Initialized
DEBUG - 2012-12-11 16:45:27 --> Helper loaded: language_helper
DEBUG - 2012-12-11 16:45:27 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-11 16:45:27 --> Final output sent to browser
DEBUG - 2012-12-11 16:45:27 --> Total execution time: 0.0403
