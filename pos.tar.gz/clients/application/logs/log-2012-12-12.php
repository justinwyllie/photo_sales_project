<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-12-12 16:37:19 --> Config Class Initialized
DEBUG - 2012-12-12 16:37:19 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:37:19 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:37:19 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:37:19 --> URI Class Initialized
DEBUG - 2012-12-12 16:37:19 --> Router Class Initialized
DEBUG - 2012-12-12 16:37:19 --> Output Class Initialized
DEBUG - 2012-12-12 16:37:19 --> Security Class Initialized
DEBUG - 2012-12-12 16:37:19 --> Input Class Initialized
DEBUG - 2012-12-12 16:37:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 16:37:19 --> Language Class Initialized
DEBUG - 2012-12-12 16:37:19 --> Loader Class Initialized
DEBUG - 2012-12-12 16:37:19 --> Helper loaded: url_helper
DEBUG - 2012-12-12 16:37:19 --> Controller Class Initialized
DEBUG - 2012-12-12 16:37:19 --> Model Class Initialized
DEBUG - 2012-12-12 16:37:19 --> Database Driver Class Initialized
DEBUG - 2012-12-12 16:37:19 --> Helper loaded: form_helper
DEBUG - 2012-12-12 16:37:19 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 16:37:19 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-12-12 16:37:19 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 16:37:19 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-12-12 16:37:19 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 16:37:19 --> Final output sent to browser
DEBUG - 2012-12-12 16:37:19 --> Total execution time: 0.6057
DEBUG - 2012-12-12 16:37:21 --> Config Class Initialized
DEBUG - 2012-12-12 16:37:21 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:37:21 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:37:21 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:37:21 --> URI Class Initialized
DEBUG - 2012-12-12 16:37:21 --> Router Class Initialized
ERROR - 2012-12-12 16:37:21 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 16:37:21 --> Config Class Initialized
DEBUG - 2012-12-12 16:37:21 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:37:21 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:37:21 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:37:21 --> URI Class Initialized
DEBUG - 2012-12-12 16:37:21 --> Router Class Initialized
ERROR - 2012-12-12 16:37:21 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 16:37:21 --> Config Class Initialized
DEBUG - 2012-12-12 16:37:21 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:37:21 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:37:21 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:37:21 --> URI Class Initialized
DEBUG - 2012-12-12 16:37:21 --> Router Class Initialized
ERROR - 2012-12-12 16:37:21 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 16:37:26 --> Config Class Initialized
DEBUG - 2012-12-12 16:37:26 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:37:26 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:37:26 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:37:26 --> URI Class Initialized
DEBUG - 2012-12-12 16:37:26 --> Router Class Initialized
DEBUG - 2012-12-12 16:37:26 --> Output Class Initialized
DEBUG - 2012-12-12 16:37:26 --> Security Class Initialized
DEBUG - 2012-12-12 16:37:26 --> Input Class Initialized
DEBUG - 2012-12-12 16:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 16:37:26 --> Language Class Initialized
DEBUG - 2012-12-12 16:37:26 --> Loader Class Initialized
DEBUG - 2012-12-12 16:37:26 --> Helper loaded: url_helper
DEBUG - 2012-12-12 16:37:26 --> Controller Class Initialized
DEBUG - 2012-12-12 16:37:26 --> Model Class Initialized
DEBUG - 2012-12-12 16:37:26 --> Database Driver Class Initialized
DEBUG - 2012-12-12 16:37:26 --> Helper loaded: form_helper
DEBUG - 2012-12-12 16:37:27 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 16:37:27 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 16:37:27 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 16:37:27 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 16:37:27 --> Final output sent to browser
DEBUG - 2012-12-12 16:37:27 --> Total execution time: 0.1248
DEBUG - 2012-12-12 16:37:29 --> Config Class Initialized
DEBUG - 2012-12-12 16:37:29 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:37:29 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:37:29 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:37:29 --> URI Class Initialized
DEBUG - 2012-12-12 16:37:29 --> Router Class Initialized
DEBUG - 2012-12-12 16:37:29 --> Output Class Initialized
DEBUG - 2012-12-12 16:37:29 --> Security Class Initialized
DEBUG - 2012-12-12 16:37:29 --> Input Class Initialized
DEBUG - 2012-12-12 16:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 16:37:29 --> Language Class Initialized
DEBUG - 2012-12-12 16:37:29 --> Loader Class Initialized
DEBUG - 2012-12-12 16:37:29 --> Helper loaded: url_helper
DEBUG - 2012-12-12 16:37:29 --> Controller Class Initialized
DEBUG - 2012-12-12 16:37:29 --> Model Class Initialized
DEBUG - 2012-12-12 16:37:29 --> Database Driver Class Initialized
DEBUG - 2012-12-12 16:37:29 --> Helper loaded: language_helper
DEBUG - 2012-12-12 16:37:29 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 16:37:29 --> Final output sent to browser
DEBUG - 2012-12-12 16:37:29 --> Total execution time: 0.0824
DEBUG - 2012-12-12 16:39:16 --> Config Class Initialized
DEBUG - 2012-12-12 16:39:16 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:39:16 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:39:16 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:39:16 --> URI Class Initialized
DEBUG - 2012-12-12 16:39:16 --> Router Class Initialized
DEBUG - 2012-12-12 16:39:16 --> Output Class Initialized
DEBUG - 2012-12-12 16:39:16 --> Security Class Initialized
DEBUG - 2012-12-12 16:39:16 --> Input Class Initialized
DEBUG - 2012-12-12 16:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 16:39:16 --> Language Class Initialized
DEBUG - 2012-12-12 16:39:16 --> Loader Class Initialized
DEBUG - 2012-12-12 16:39:16 --> Helper loaded: url_helper
DEBUG - 2012-12-12 16:39:16 --> Controller Class Initialized
DEBUG - 2012-12-12 16:39:16 --> Model Class Initialized
DEBUG - 2012-12-12 16:39:16 --> Database Driver Class Initialized
DEBUG - 2012-12-12 16:39:16 --> Helper loaded: form_helper
DEBUG - 2012-12-12 16:39:16 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 16:39:16 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 16:39:16 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 16:39:16 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 16:39:16 --> Final output sent to browser
DEBUG - 2012-12-12 16:39:16 --> Total execution time: 0.0493
DEBUG - 2012-12-12 16:39:24 --> Config Class Initialized
DEBUG - 2012-12-12 16:39:24 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:39:24 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:39:24 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:39:24 --> URI Class Initialized
DEBUG - 2012-12-12 16:39:24 --> Router Class Initialized
ERROR - 2012-12-12 16:39:24 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 16:39:24 --> Config Class Initialized
DEBUG - 2012-12-12 16:39:24 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:39:24 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:39:24 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:39:24 --> URI Class Initialized
DEBUG - 2012-12-12 16:39:24 --> Router Class Initialized
ERROR - 2012-12-12 16:39:24 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 16:39:24 --> Config Class Initialized
DEBUG - 2012-12-12 16:39:24 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:39:24 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:39:24 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:39:24 --> URI Class Initialized
DEBUG - 2012-12-12 16:39:24 --> Router Class Initialized
ERROR - 2012-12-12 16:39:24 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 16:39:25 --> Config Class Initialized
DEBUG - 2012-12-12 16:39:25 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:39:25 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:39:25 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:39:25 --> URI Class Initialized
DEBUG - 2012-12-12 16:39:25 --> Router Class Initialized
DEBUG - 2012-12-12 16:39:25 --> Output Class Initialized
DEBUG - 2012-12-12 16:39:25 --> Security Class Initialized
DEBUG - 2012-12-12 16:39:25 --> Input Class Initialized
DEBUG - 2012-12-12 16:39:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 16:39:25 --> Language Class Initialized
DEBUG - 2012-12-12 16:39:25 --> Loader Class Initialized
DEBUG - 2012-12-12 16:39:25 --> Helper loaded: url_helper
DEBUG - 2012-12-12 16:39:25 --> Controller Class Initialized
DEBUG - 2012-12-12 16:39:25 --> Model Class Initialized
DEBUG - 2012-12-12 16:39:25 --> Database Driver Class Initialized
DEBUG - 2012-12-12 16:39:25 --> Helper loaded: language_helper
DEBUG - 2012-12-12 16:39:25 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 16:39:25 --> Final output sent to browser
DEBUG - 2012-12-12 16:39:25 --> Total execution time: 0.0482
DEBUG - 2012-12-12 16:42:31 --> Config Class Initialized
DEBUG - 2012-12-12 16:42:31 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:42:31 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:42:31 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:42:31 --> URI Class Initialized
DEBUG - 2012-12-12 16:42:31 --> Router Class Initialized
DEBUG - 2012-12-12 16:42:31 --> Output Class Initialized
DEBUG - 2012-12-12 16:42:31 --> Security Class Initialized
DEBUG - 2012-12-12 16:42:31 --> Input Class Initialized
DEBUG - 2012-12-12 16:42:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 16:42:31 --> Language Class Initialized
DEBUG - 2012-12-12 16:42:31 --> Loader Class Initialized
DEBUG - 2012-12-12 16:42:31 --> Helper loaded: url_helper
DEBUG - 2012-12-12 16:42:31 --> Controller Class Initialized
DEBUG - 2012-12-12 16:42:31 --> Model Class Initialized
DEBUG - 2012-12-12 16:42:31 --> Database Driver Class Initialized
DEBUG - 2012-12-12 16:42:31 --> Helper loaded: language_helper
DEBUG - 2012-12-12 16:42:31 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 16:42:31 --> Final output sent to browser
DEBUG - 2012-12-12 16:42:31 --> Total execution time: 0.0541
DEBUG - 2012-12-12 16:50:30 --> Config Class Initialized
DEBUG - 2012-12-12 16:50:30 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:50:30 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:50:30 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:50:30 --> URI Class Initialized
DEBUG - 2012-12-12 16:50:30 --> Router Class Initialized
DEBUG - 2012-12-12 16:50:30 --> Output Class Initialized
DEBUG - 2012-12-12 16:50:30 --> Security Class Initialized
DEBUG - 2012-12-12 16:50:30 --> Input Class Initialized
DEBUG - 2012-12-12 16:50:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 16:50:30 --> Language Class Initialized
DEBUG - 2012-12-12 16:50:30 --> Loader Class Initialized
DEBUG - 2012-12-12 16:50:30 --> Helper loaded: url_helper
DEBUG - 2012-12-12 16:50:30 --> Controller Class Initialized
DEBUG - 2012-12-12 16:50:30 --> Model Class Initialized
DEBUG - 2012-12-12 16:50:30 --> Database Driver Class Initialized
DEBUG - 2012-12-12 16:50:30 --> Helper loaded: language_helper
DEBUG - 2012-12-12 16:50:30 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 16:50:30 --> Final output sent to browser
DEBUG - 2012-12-12 16:50:30 --> Total execution time: 0.0395
DEBUG - 2012-12-12 16:52:39 --> Config Class Initialized
DEBUG - 2012-12-12 16:52:39 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:52:40 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:52:40 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:52:40 --> URI Class Initialized
DEBUG - 2012-12-12 16:52:40 --> Router Class Initialized
DEBUG - 2012-12-12 16:52:40 --> Output Class Initialized
DEBUG - 2012-12-12 16:52:40 --> Security Class Initialized
DEBUG - 2012-12-12 16:52:40 --> Input Class Initialized
DEBUG - 2012-12-12 16:52:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 16:52:40 --> Language Class Initialized
DEBUG - 2012-12-12 16:52:40 --> Loader Class Initialized
DEBUG - 2012-12-12 16:52:40 --> Helper loaded: url_helper
DEBUG - 2012-12-12 16:52:40 --> Controller Class Initialized
DEBUG - 2012-12-12 16:52:40 --> Model Class Initialized
DEBUG - 2012-12-12 16:52:40 --> Database Driver Class Initialized
DEBUG - 2012-12-12 16:52:40 --> Helper loaded: language_helper
DEBUG - 2012-12-12 16:52:40 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 16:52:40 --> Final output sent to browser
DEBUG - 2012-12-12 16:52:40 --> Total execution time: 0.0504
DEBUG - 2012-12-12 16:54:38 --> Config Class Initialized
DEBUG - 2012-12-12 16:54:38 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:54:38 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:54:38 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:54:38 --> URI Class Initialized
DEBUG - 2012-12-12 16:54:38 --> Router Class Initialized
DEBUG - 2012-12-12 16:54:38 --> Output Class Initialized
DEBUG - 2012-12-12 16:54:38 --> Security Class Initialized
DEBUG - 2012-12-12 16:54:38 --> Input Class Initialized
DEBUG - 2012-12-12 16:54:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 16:54:38 --> Language Class Initialized
DEBUG - 2012-12-12 16:54:38 --> Loader Class Initialized
DEBUG - 2012-12-12 16:54:38 --> Helper loaded: url_helper
DEBUG - 2012-12-12 16:54:38 --> Controller Class Initialized
DEBUG - 2012-12-12 16:54:38 --> Model Class Initialized
DEBUG - 2012-12-12 16:54:38 --> Database Driver Class Initialized
DEBUG - 2012-12-12 16:54:38 --> Helper loaded: form_helper
DEBUG - 2012-12-12 16:54:38 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 16:54:38 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 16:54:38 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 16:54:38 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 16:54:38 --> Final output sent to browser
DEBUG - 2012-12-12 16:54:38 --> Total execution time: 0.0490
DEBUG - 2012-12-12 16:54:47 --> Config Class Initialized
DEBUG - 2012-12-12 16:54:47 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:54:47 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:54:47 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:54:47 --> URI Class Initialized
DEBUG - 2012-12-12 16:54:47 --> Router Class Initialized
ERROR - 2012-12-12 16:54:47 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 16:54:47 --> Config Class Initialized
DEBUG - 2012-12-12 16:54:47 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:54:47 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:54:47 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:54:47 --> URI Class Initialized
DEBUG - 2012-12-12 16:54:47 --> Router Class Initialized
ERROR - 2012-12-12 16:54:47 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 16:54:47 --> Config Class Initialized
DEBUG - 2012-12-12 16:54:47 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:54:47 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:54:47 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:54:47 --> URI Class Initialized
DEBUG - 2012-12-12 16:54:47 --> Router Class Initialized
ERROR - 2012-12-12 16:54:47 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 16:54:49 --> Config Class Initialized
DEBUG - 2012-12-12 16:54:49 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:54:49 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:54:49 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:54:49 --> URI Class Initialized
DEBUG - 2012-12-12 16:54:49 --> Router Class Initialized
DEBUG - 2012-12-12 16:54:49 --> Output Class Initialized
DEBUG - 2012-12-12 16:54:49 --> Security Class Initialized
DEBUG - 2012-12-12 16:54:49 --> Input Class Initialized
DEBUG - 2012-12-12 16:54:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 16:54:49 --> Language Class Initialized
DEBUG - 2012-12-12 16:54:49 --> Loader Class Initialized
DEBUG - 2012-12-12 16:54:49 --> Helper loaded: url_helper
DEBUG - 2012-12-12 16:54:49 --> Controller Class Initialized
DEBUG - 2012-12-12 16:54:49 --> Model Class Initialized
DEBUG - 2012-12-12 16:54:49 --> Database Driver Class Initialized
DEBUG - 2012-12-12 16:54:49 --> Helper loaded: language_helper
DEBUG - 2012-12-12 16:54:49 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 16:54:49 --> Final output sent to browser
DEBUG - 2012-12-12 16:54:49 --> Total execution time: 0.0433
DEBUG - 2012-12-12 16:56:02 --> Config Class Initialized
DEBUG - 2012-12-12 16:56:02 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:56:02 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:56:02 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:56:02 --> URI Class Initialized
DEBUG - 2012-12-12 16:56:02 --> Router Class Initialized
DEBUG - 2012-12-12 16:56:02 --> Output Class Initialized
DEBUG - 2012-12-12 16:56:02 --> Security Class Initialized
DEBUG - 2012-12-12 16:56:02 --> Input Class Initialized
DEBUG - 2012-12-12 16:56:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 16:56:02 --> Language Class Initialized
DEBUG - 2012-12-12 16:56:02 --> Loader Class Initialized
DEBUG - 2012-12-12 16:56:02 --> Helper loaded: url_helper
DEBUG - 2012-12-12 16:56:02 --> Controller Class Initialized
DEBUG - 2012-12-12 16:56:02 --> Model Class Initialized
DEBUG - 2012-12-12 16:56:02 --> Database Driver Class Initialized
DEBUG - 2012-12-12 16:56:02 --> Helper loaded: form_helper
DEBUG - 2012-12-12 16:56:02 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 16:56:02 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 16:56:02 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 16:56:02 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 16:56:02 --> Final output sent to browser
DEBUG - 2012-12-12 16:56:02 --> Total execution time: 0.0439
DEBUG - 2012-12-12 16:56:14 --> Config Class Initialized
DEBUG - 2012-12-12 16:56:14 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:56:14 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:56:14 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:56:14 --> URI Class Initialized
DEBUG - 2012-12-12 16:56:14 --> Router Class Initialized
ERROR - 2012-12-12 16:56:14 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 16:56:14 --> Config Class Initialized
DEBUG - 2012-12-12 16:56:14 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:56:14 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:56:14 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:56:14 --> URI Class Initialized
DEBUG - 2012-12-12 16:56:14 --> Router Class Initialized
ERROR - 2012-12-12 16:56:14 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 16:56:14 --> Config Class Initialized
DEBUG - 2012-12-12 16:56:14 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:56:14 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:56:14 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:56:14 --> URI Class Initialized
DEBUG - 2012-12-12 16:56:14 --> Router Class Initialized
ERROR - 2012-12-12 16:56:14 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 16:56:16 --> Config Class Initialized
DEBUG - 2012-12-12 16:56:16 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:56:16 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:56:16 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:56:16 --> URI Class Initialized
DEBUG - 2012-12-12 16:56:16 --> Router Class Initialized
DEBUG - 2012-12-12 16:56:16 --> Output Class Initialized
DEBUG - 2012-12-12 16:56:16 --> Security Class Initialized
DEBUG - 2012-12-12 16:56:16 --> Input Class Initialized
DEBUG - 2012-12-12 16:56:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 16:56:16 --> Language Class Initialized
DEBUG - 2012-12-12 16:56:16 --> Loader Class Initialized
DEBUG - 2012-12-12 16:56:16 --> Helper loaded: url_helper
DEBUG - 2012-12-12 16:56:16 --> Controller Class Initialized
DEBUG - 2012-12-12 16:56:16 --> Model Class Initialized
DEBUG - 2012-12-12 16:56:16 --> Database Driver Class Initialized
DEBUG - 2012-12-12 16:56:16 --> Helper loaded: language_helper
DEBUG - 2012-12-12 16:56:16 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 16:56:16 --> Final output sent to browser
DEBUG - 2012-12-12 16:56:16 --> Total execution time: 0.0438
DEBUG - 2012-12-12 16:59:07 --> Config Class Initialized
DEBUG - 2012-12-12 16:59:07 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:59:07 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:59:07 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:59:07 --> URI Class Initialized
DEBUG - 2012-12-12 16:59:07 --> Router Class Initialized
DEBUG - 2012-12-12 16:59:07 --> Output Class Initialized
DEBUG - 2012-12-12 16:59:07 --> Security Class Initialized
DEBUG - 2012-12-12 16:59:07 --> Input Class Initialized
DEBUG - 2012-12-12 16:59:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 16:59:07 --> Language Class Initialized
DEBUG - 2012-12-12 16:59:07 --> Loader Class Initialized
DEBUG - 2012-12-12 16:59:07 --> Helper loaded: url_helper
DEBUG - 2012-12-12 16:59:07 --> Controller Class Initialized
DEBUG - 2012-12-12 16:59:07 --> Model Class Initialized
DEBUG - 2012-12-12 16:59:07 --> Database Driver Class Initialized
DEBUG - 2012-12-12 16:59:07 --> Helper loaded: form_helper
DEBUG - 2012-12-12 16:59:07 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 16:59:07 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 16:59:07 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 16:59:07 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 16:59:08 --> Final output sent to browser
DEBUG - 2012-12-12 16:59:08 --> Total execution time: 0.0490
DEBUG - 2012-12-12 16:59:14 --> Config Class Initialized
DEBUG - 2012-12-12 16:59:14 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:59:14 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:59:14 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:59:14 --> URI Class Initialized
DEBUG - 2012-12-12 16:59:14 --> Router Class Initialized
ERROR - 2012-12-12 16:59:14 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 16:59:14 --> Config Class Initialized
DEBUG - 2012-12-12 16:59:14 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:59:14 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:59:14 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:59:14 --> URI Class Initialized
DEBUG - 2012-12-12 16:59:14 --> Router Class Initialized
ERROR - 2012-12-12 16:59:14 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 16:59:14 --> Config Class Initialized
DEBUG - 2012-12-12 16:59:14 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:59:14 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:59:14 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:59:14 --> URI Class Initialized
DEBUG - 2012-12-12 16:59:14 --> Router Class Initialized
ERROR - 2012-12-12 16:59:14 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 16:59:15 --> Config Class Initialized
DEBUG - 2012-12-12 16:59:15 --> Hooks Class Initialized
DEBUG - 2012-12-12 16:59:15 --> Utf8 Class Initialized
DEBUG - 2012-12-12 16:59:15 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 16:59:15 --> URI Class Initialized
DEBUG - 2012-12-12 16:59:15 --> Router Class Initialized
DEBUG - 2012-12-12 16:59:15 --> Output Class Initialized
DEBUG - 2012-12-12 16:59:15 --> Security Class Initialized
DEBUG - 2012-12-12 16:59:15 --> Input Class Initialized
DEBUG - 2012-12-12 16:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 16:59:15 --> Language Class Initialized
DEBUG - 2012-12-12 16:59:15 --> Loader Class Initialized
DEBUG - 2012-12-12 16:59:15 --> Helper loaded: url_helper
DEBUG - 2012-12-12 16:59:15 --> Controller Class Initialized
DEBUG - 2012-12-12 16:59:15 --> Model Class Initialized
DEBUG - 2012-12-12 16:59:15 --> Database Driver Class Initialized
DEBUG - 2012-12-12 16:59:15 --> Helper loaded: language_helper
DEBUG - 2012-12-12 16:59:15 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 16:59:15 --> Final output sent to browser
DEBUG - 2012-12-12 16:59:15 --> Total execution time: 0.0397
DEBUG - 2012-12-12 17:03:37 --> Config Class Initialized
DEBUG - 2012-12-12 17:03:37 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:03:37 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:03:37 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:03:37 --> URI Class Initialized
DEBUG - 2012-12-12 17:03:37 --> Router Class Initialized
DEBUG - 2012-12-12 17:03:37 --> Output Class Initialized
DEBUG - 2012-12-12 17:03:37 --> Security Class Initialized
DEBUG - 2012-12-12 17:03:37 --> Input Class Initialized
DEBUG - 2012-12-12 17:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:03:37 --> Language Class Initialized
DEBUG - 2012-12-12 17:03:37 --> Loader Class Initialized
DEBUG - 2012-12-12 17:03:37 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:03:37 --> Controller Class Initialized
DEBUG - 2012-12-12 17:03:37 --> Model Class Initialized
DEBUG - 2012-12-12 17:03:37 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:03:37 --> Helper loaded: form_helper
DEBUG - 2012-12-12 17:03:37 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 17:03:37 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 17:03:37 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 17:03:37 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 17:03:38 --> Final output sent to browser
DEBUG - 2012-12-12 17:03:38 --> Total execution time: 0.0449
DEBUG - 2012-12-12 17:03:45 --> Config Class Initialized
DEBUG - 2012-12-12 17:03:45 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:03:45 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:03:45 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:03:45 --> URI Class Initialized
DEBUG - 2012-12-12 17:03:45 --> Router Class Initialized
ERROR - 2012-12-12 17:03:45 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:03:45 --> Config Class Initialized
DEBUG - 2012-12-12 17:03:45 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:03:45 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:03:45 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:03:45 --> URI Class Initialized
DEBUG - 2012-12-12 17:03:45 --> Router Class Initialized
ERROR - 2012-12-12 17:03:45 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:03:45 --> Config Class Initialized
DEBUG - 2012-12-12 17:03:45 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:03:45 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:03:45 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:03:45 --> URI Class Initialized
DEBUG - 2012-12-12 17:03:45 --> Router Class Initialized
ERROR - 2012-12-12 17:03:45 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:04:41 --> Config Class Initialized
DEBUG - 2012-12-12 17:04:41 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:04:41 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:04:41 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:04:41 --> URI Class Initialized
DEBUG - 2012-12-12 17:04:41 --> Router Class Initialized
DEBUG - 2012-12-12 17:04:41 --> Output Class Initialized
DEBUG - 2012-12-12 17:04:41 --> Security Class Initialized
DEBUG - 2012-12-12 17:04:41 --> Input Class Initialized
DEBUG - 2012-12-12 17:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:04:41 --> Language Class Initialized
DEBUG - 2012-12-12 17:04:41 --> Loader Class Initialized
DEBUG - 2012-12-12 17:04:41 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:04:41 --> Controller Class Initialized
DEBUG - 2012-12-12 17:04:41 --> Model Class Initialized
DEBUG - 2012-12-12 17:04:41 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:04:41 --> Helper loaded: form_helper
DEBUG - 2012-12-12 17:04:41 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 17:04:41 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 17:04:41 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 17:04:41 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 17:04:41 --> Final output sent to browser
DEBUG - 2012-12-12 17:04:41 --> Total execution time: 0.0519
DEBUG - 2012-12-12 17:04:47 --> Config Class Initialized
DEBUG - 2012-12-12 17:04:47 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:04:47 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:04:47 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:04:47 --> URI Class Initialized
DEBUG - 2012-12-12 17:04:47 --> Router Class Initialized
ERROR - 2012-12-12 17:04:47 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:04:47 --> Config Class Initialized
DEBUG - 2012-12-12 17:04:47 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:04:47 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:04:47 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:04:47 --> URI Class Initialized
DEBUG - 2012-12-12 17:04:47 --> Router Class Initialized
ERROR - 2012-12-12 17:04:47 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:04:47 --> Config Class Initialized
DEBUG - 2012-12-12 17:04:47 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:04:47 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:04:47 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:04:47 --> URI Class Initialized
DEBUG - 2012-12-12 17:04:47 --> Router Class Initialized
ERROR - 2012-12-12 17:04:47 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:04:49 --> Config Class Initialized
DEBUG - 2012-12-12 17:04:49 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:04:49 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:04:49 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:04:49 --> URI Class Initialized
DEBUG - 2012-12-12 17:04:49 --> Router Class Initialized
DEBUG - 2012-12-12 17:04:49 --> Output Class Initialized
DEBUG - 2012-12-12 17:04:49 --> Security Class Initialized
DEBUG - 2012-12-12 17:04:49 --> Input Class Initialized
DEBUG - 2012-12-12 17:04:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:04:49 --> Language Class Initialized
DEBUG - 2012-12-12 17:04:49 --> Loader Class Initialized
DEBUG - 2012-12-12 17:04:49 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:04:49 --> Controller Class Initialized
DEBUG - 2012-12-12 17:04:49 --> Model Class Initialized
DEBUG - 2012-12-12 17:04:49 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:04:49 --> Helper loaded: language_helper
DEBUG - 2012-12-12 17:04:49 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 17:04:49 --> Final output sent to browser
DEBUG - 2012-12-12 17:04:49 --> Total execution time: 0.0396
DEBUG - 2012-12-12 17:19:18 --> Config Class Initialized
DEBUG - 2012-12-12 17:19:18 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:19:18 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:19:18 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:19:18 --> URI Class Initialized
DEBUG - 2012-12-12 17:19:18 --> Router Class Initialized
DEBUG - 2012-12-12 17:19:18 --> Output Class Initialized
DEBUG - 2012-12-12 17:19:18 --> Security Class Initialized
DEBUG - 2012-12-12 17:19:18 --> Input Class Initialized
DEBUG - 2012-12-12 17:19:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:19:18 --> Language Class Initialized
DEBUG - 2012-12-12 17:19:18 --> Loader Class Initialized
DEBUG - 2012-12-12 17:19:18 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:19:18 --> Controller Class Initialized
DEBUG - 2012-12-12 17:19:18 --> Model Class Initialized
DEBUG - 2012-12-12 17:19:18 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:19:18 --> Helper loaded: form_helper
DEBUG - 2012-12-12 17:19:18 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 17:19:18 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 17:19:18 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 17:19:18 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 17:19:18 --> Final output sent to browser
DEBUG - 2012-12-12 17:19:18 --> Total execution time: 0.0483
DEBUG - 2012-12-12 17:19:22 --> Config Class Initialized
DEBUG - 2012-12-12 17:19:22 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:19:22 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:19:22 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:19:22 --> URI Class Initialized
DEBUG - 2012-12-12 17:19:22 --> Router Class Initialized
ERROR - 2012-12-12 17:19:22 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:19:22 --> Config Class Initialized
DEBUG - 2012-12-12 17:19:22 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:19:22 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:19:22 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:19:22 --> URI Class Initialized
DEBUG - 2012-12-12 17:19:22 --> Router Class Initialized
ERROR - 2012-12-12 17:19:22 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:19:22 --> Config Class Initialized
DEBUG - 2012-12-12 17:19:22 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:19:22 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:19:22 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:19:22 --> URI Class Initialized
DEBUG - 2012-12-12 17:19:22 --> Router Class Initialized
ERROR - 2012-12-12 17:19:22 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:19:25 --> Config Class Initialized
DEBUG - 2012-12-12 17:19:25 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:19:25 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:19:25 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:19:25 --> URI Class Initialized
DEBUG - 2012-12-12 17:19:25 --> Router Class Initialized
DEBUG - 2012-12-12 17:19:25 --> Output Class Initialized
DEBUG - 2012-12-12 17:19:25 --> Security Class Initialized
DEBUG - 2012-12-12 17:19:25 --> Input Class Initialized
DEBUG - 2012-12-12 17:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:19:25 --> Language Class Initialized
DEBUG - 2012-12-12 17:19:25 --> Loader Class Initialized
DEBUG - 2012-12-12 17:19:25 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:19:25 --> Controller Class Initialized
DEBUG - 2012-12-12 17:19:25 --> Model Class Initialized
DEBUG - 2012-12-12 17:19:25 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:19:25 --> Helper loaded: language_helper
DEBUG - 2012-12-12 17:19:25 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 17:19:25 --> Final output sent to browser
DEBUG - 2012-12-12 17:19:25 --> Total execution time: 0.0437
DEBUG - 2012-12-12 17:22:18 --> Config Class Initialized
DEBUG - 2012-12-12 17:22:18 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:22:18 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:22:18 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:22:18 --> URI Class Initialized
DEBUG - 2012-12-12 17:22:18 --> Router Class Initialized
DEBUG - 2012-12-12 17:22:18 --> Output Class Initialized
DEBUG - 2012-12-12 17:22:18 --> Security Class Initialized
DEBUG - 2012-12-12 17:22:18 --> Input Class Initialized
DEBUG - 2012-12-12 17:22:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:22:18 --> Language Class Initialized
DEBUG - 2012-12-12 17:22:18 --> Loader Class Initialized
DEBUG - 2012-12-12 17:22:18 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:22:18 --> Controller Class Initialized
DEBUG - 2012-12-12 17:22:18 --> Model Class Initialized
DEBUG - 2012-12-12 17:22:18 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:22:18 --> Helper loaded: form_helper
DEBUG - 2012-12-12 17:22:18 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 17:22:18 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 17:22:18 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 17:22:18 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 17:22:19 --> Final output sent to browser
DEBUG - 2012-12-12 17:22:19 --> Total execution time: 0.0480
DEBUG - 2012-12-12 17:22:23 --> Config Class Initialized
DEBUG - 2012-12-12 17:22:23 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:22:23 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:22:23 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:22:23 --> URI Class Initialized
DEBUG - 2012-12-12 17:22:23 --> Router Class Initialized
ERROR - 2012-12-12 17:22:23 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:22:23 --> Config Class Initialized
DEBUG - 2012-12-12 17:22:23 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:22:23 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:22:23 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:22:23 --> URI Class Initialized
DEBUG - 2012-12-12 17:22:23 --> Router Class Initialized
ERROR - 2012-12-12 17:22:23 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:22:23 --> Config Class Initialized
DEBUG - 2012-12-12 17:22:23 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:22:23 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:22:23 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:22:23 --> URI Class Initialized
DEBUG - 2012-12-12 17:22:23 --> Router Class Initialized
ERROR - 2012-12-12 17:22:23 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:23:15 --> Config Class Initialized
DEBUG - 2012-12-12 17:23:15 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:23:15 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:23:15 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:23:15 --> URI Class Initialized
DEBUG - 2012-12-12 17:23:15 --> Router Class Initialized
DEBUG - 2012-12-12 17:23:15 --> Output Class Initialized
DEBUG - 2012-12-12 17:23:15 --> Security Class Initialized
DEBUG - 2012-12-12 17:23:15 --> Input Class Initialized
DEBUG - 2012-12-12 17:23:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:23:15 --> Language Class Initialized
DEBUG - 2012-12-12 17:23:15 --> Loader Class Initialized
DEBUG - 2012-12-12 17:23:15 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:23:15 --> Controller Class Initialized
DEBUG - 2012-12-12 17:23:15 --> Model Class Initialized
DEBUG - 2012-12-12 17:23:15 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:23:15 --> Helper loaded: form_helper
DEBUG - 2012-12-12 17:23:15 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 17:23:15 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 17:23:15 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 17:23:15 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 17:23:15 --> Final output sent to browser
DEBUG - 2012-12-12 17:23:15 --> Total execution time: 0.0491
DEBUG - 2012-12-12 17:23:20 --> Config Class Initialized
DEBUG - 2012-12-12 17:23:20 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:23:20 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:23:20 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:23:20 --> URI Class Initialized
DEBUG - 2012-12-12 17:23:20 --> Router Class Initialized
ERROR - 2012-12-12 17:23:20 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:23:20 --> Config Class Initialized
DEBUG - 2012-12-12 17:23:20 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:23:20 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:23:20 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:23:20 --> URI Class Initialized
DEBUG - 2012-12-12 17:23:20 --> Router Class Initialized
ERROR - 2012-12-12 17:23:20 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:23:20 --> Config Class Initialized
DEBUG - 2012-12-12 17:23:20 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:23:20 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:23:20 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:23:20 --> URI Class Initialized
DEBUG - 2012-12-12 17:23:20 --> Router Class Initialized
ERROR - 2012-12-12 17:23:20 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:23:22 --> Config Class Initialized
DEBUG - 2012-12-12 17:23:22 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:23:22 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:23:22 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:23:22 --> URI Class Initialized
DEBUG - 2012-12-12 17:23:22 --> Router Class Initialized
DEBUG - 2012-12-12 17:23:22 --> Output Class Initialized
DEBUG - 2012-12-12 17:23:22 --> Security Class Initialized
DEBUG - 2012-12-12 17:23:22 --> Input Class Initialized
DEBUG - 2012-12-12 17:23:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:23:22 --> Language Class Initialized
DEBUG - 2012-12-12 17:23:22 --> Loader Class Initialized
DEBUG - 2012-12-12 17:23:22 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:23:22 --> Controller Class Initialized
DEBUG - 2012-12-12 17:23:22 --> Model Class Initialized
DEBUG - 2012-12-12 17:23:22 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:23:22 --> Helper loaded: language_helper
DEBUG - 2012-12-12 17:23:22 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 17:23:22 --> Final output sent to browser
DEBUG - 2012-12-12 17:23:22 --> Total execution time: 0.0537
DEBUG - 2012-12-12 17:24:14 --> Config Class Initialized
DEBUG - 2012-12-12 17:24:14 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:24:14 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:24:14 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:24:14 --> URI Class Initialized
DEBUG - 2012-12-12 17:24:14 --> Router Class Initialized
DEBUG - 2012-12-12 17:24:14 --> Output Class Initialized
DEBUG - 2012-12-12 17:24:14 --> Security Class Initialized
DEBUG - 2012-12-12 17:24:14 --> Input Class Initialized
DEBUG - 2012-12-12 17:24:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:24:14 --> Language Class Initialized
DEBUG - 2012-12-12 17:24:14 --> Loader Class Initialized
DEBUG - 2012-12-12 17:24:14 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:24:14 --> Controller Class Initialized
DEBUG - 2012-12-12 17:24:14 --> Model Class Initialized
DEBUG - 2012-12-12 17:24:14 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:24:14 --> Helper loaded: form_helper
DEBUG - 2012-12-12 17:24:14 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 17:24:14 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 17:24:14 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 17:24:14 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 17:24:15 --> Final output sent to browser
DEBUG - 2012-12-12 17:24:15 --> Total execution time: 0.0616
DEBUG - 2012-12-12 17:24:20 --> Config Class Initialized
DEBUG - 2012-12-12 17:24:20 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:24:20 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:24:20 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:24:20 --> URI Class Initialized
DEBUG - 2012-12-12 17:24:20 --> Router Class Initialized
ERROR - 2012-12-12 17:24:20 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:24:20 --> Config Class Initialized
DEBUG - 2012-12-12 17:24:20 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:24:20 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:24:20 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:24:20 --> URI Class Initialized
DEBUG - 2012-12-12 17:24:20 --> Router Class Initialized
ERROR - 2012-12-12 17:24:20 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:24:20 --> Config Class Initialized
DEBUG - 2012-12-12 17:24:20 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:24:20 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:24:20 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:24:20 --> URI Class Initialized
DEBUG - 2012-12-12 17:24:20 --> Router Class Initialized
ERROR - 2012-12-12 17:24:20 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:24:22 --> Config Class Initialized
DEBUG - 2012-12-12 17:24:22 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:24:22 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:24:22 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:24:22 --> URI Class Initialized
DEBUG - 2012-12-12 17:24:22 --> Router Class Initialized
DEBUG - 2012-12-12 17:24:22 --> Output Class Initialized
DEBUG - 2012-12-12 17:24:22 --> Security Class Initialized
DEBUG - 2012-12-12 17:24:22 --> Input Class Initialized
DEBUG - 2012-12-12 17:24:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:24:22 --> Language Class Initialized
DEBUG - 2012-12-12 17:24:22 --> Loader Class Initialized
DEBUG - 2012-12-12 17:24:22 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:24:22 --> Controller Class Initialized
DEBUG - 2012-12-12 17:24:22 --> Model Class Initialized
DEBUG - 2012-12-12 17:24:22 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:24:22 --> Helper loaded: language_helper
DEBUG - 2012-12-12 17:24:22 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 17:24:22 --> Final output sent to browser
DEBUG - 2012-12-12 17:24:22 --> Total execution time: 0.0463
DEBUG - 2012-12-12 17:26:31 --> Config Class Initialized
DEBUG - 2012-12-12 17:26:31 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:26:31 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:26:31 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:26:31 --> URI Class Initialized
DEBUG - 2012-12-12 17:26:31 --> Router Class Initialized
DEBUG - 2012-12-12 17:26:31 --> Output Class Initialized
DEBUG - 2012-12-12 17:26:31 --> Security Class Initialized
DEBUG - 2012-12-12 17:26:31 --> Input Class Initialized
DEBUG - 2012-12-12 17:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:26:31 --> Language Class Initialized
DEBUG - 2012-12-12 17:26:31 --> Loader Class Initialized
DEBUG - 2012-12-12 17:26:31 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:26:31 --> Controller Class Initialized
DEBUG - 2012-12-12 17:26:31 --> Model Class Initialized
DEBUG - 2012-12-12 17:26:31 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:26:31 --> Helper loaded: form_helper
DEBUG - 2012-12-12 17:26:31 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 17:26:31 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 17:26:31 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 17:26:31 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 17:26:31 --> Final output sent to browser
DEBUG - 2012-12-12 17:26:31 --> Total execution time: 0.0486
DEBUG - 2012-12-12 17:26:36 --> Config Class Initialized
DEBUG - 2012-12-12 17:26:36 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:26:36 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:26:36 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:26:36 --> URI Class Initialized
DEBUG - 2012-12-12 17:26:36 --> Router Class Initialized
ERROR - 2012-12-12 17:26:36 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:26:36 --> Config Class Initialized
DEBUG - 2012-12-12 17:26:36 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:26:36 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:26:36 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:26:36 --> URI Class Initialized
DEBUG - 2012-12-12 17:26:36 --> Router Class Initialized
ERROR - 2012-12-12 17:26:36 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:26:36 --> Config Class Initialized
DEBUG - 2012-12-12 17:26:36 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:26:36 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:26:36 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:26:36 --> URI Class Initialized
DEBUG - 2012-12-12 17:26:36 --> Router Class Initialized
ERROR - 2012-12-12 17:26:36 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:26:38 --> Config Class Initialized
DEBUG - 2012-12-12 17:26:38 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:26:38 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:26:38 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:26:38 --> URI Class Initialized
DEBUG - 2012-12-12 17:26:38 --> Router Class Initialized
DEBUG - 2012-12-12 17:26:38 --> Output Class Initialized
DEBUG - 2012-12-12 17:26:38 --> Security Class Initialized
DEBUG - 2012-12-12 17:26:38 --> Input Class Initialized
DEBUG - 2012-12-12 17:26:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:26:38 --> Language Class Initialized
DEBUG - 2012-12-12 17:26:38 --> Loader Class Initialized
DEBUG - 2012-12-12 17:26:38 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:26:38 --> Controller Class Initialized
DEBUG - 2012-12-12 17:26:38 --> Model Class Initialized
DEBUG - 2012-12-12 17:26:38 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:26:38 --> Helper loaded: language_helper
DEBUG - 2012-12-12 17:26:38 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 17:26:38 --> Final output sent to browser
DEBUG - 2012-12-12 17:26:38 --> Total execution time: 0.0393
DEBUG - 2012-12-12 17:28:43 --> Config Class Initialized
DEBUG - 2012-12-12 17:28:43 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:28:43 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:28:43 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:28:43 --> URI Class Initialized
DEBUG - 2012-12-12 17:28:43 --> Router Class Initialized
DEBUG - 2012-12-12 17:28:43 --> Output Class Initialized
DEBUG - 2012-12-12 17:28:43 --> Security Class Initialized
DEBUG - 2012-12-12 17:28:43 --> Input Class Initialized
DEBUG - 2012-12-12 17:28:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:28:43 --> Language Class Initialized
DEBUG - 2012-12-12 17:28:43 --> Loader Class Initialized
DEBUG - 2012-12-12 17:28:43 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:28:43 --> Controller Class Initialized
DEBUG - 2012-12-12 17:28:43 --> Model Class Initialized
DEBUG - 2012-12-12 17:28:43 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:28:43 --> Helper loaded: form_helper
DEBUG - 2012-12-12 17:28:43 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 17:28:43 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 17:28:43 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 17:28:43 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 17:28:43 --> Final output sent to browser
DEBUG - 2012-12-12 17:28:43 --> Total execution time: 0.0483
DEBUG - 2012-12-12 17:28:49 --> Config Class Initialized
DEBUG - 2012-12-12 17:28:49 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:28:49 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:28:49 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:28:49 --> URI Class Initialized
DEBUG - 2012-12-12 17:28:49 --> Router Class Initialized
ERROR - 2012-12-12 17:28:49 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:28:49 --> Config Class Initialized
DEBUG - 2012-12-12 17:28:49 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:28:49 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:28:49 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:28:49 --> URI Class Initialized
DEBUG - 2012-12-12 17:28:49 --> Router Class Initialized
ERROR - 2012-12-12 17:28:49 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:28:49 --> Config Class Initialized
DEBUG - 2012-12-12 17:28:49 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:28:49 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:28:49 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:28:49 --> URI Class Initialized
DEBUG - 2012-12-12 17:28:49 --> Router Class Initialized
ERROR - 2012-12-12 17:28:49 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:29:04 --> Config Class Initialized
DEBUG - 2012-12-12 17:29:04 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:29:04 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:29:04 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:29:04 --> URI Class Initialized
DEBUG - 2012-12-12 17:29:04 --> Router Class Initialized
DEBUG - 2012-12-12 17:29:04 --> Output Class Initialized
DEBUG - 2012-12-12 17:29:04 --> Security Class Initialized
DEBUG - 2012-12-12 17:29:04 --> Input Class Initialized
DEBUG - 2012-12-12 17:29:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:29:04 --> Language Class Initialized
DEBUG - 2012-12-12 17:29:04 --> Loader Class Initialized
DEBUG - 2012-12-12 17:29:04 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:29:04 --> Controller Class Initialized
DEBUG - 2012-12-12 17:29:04 --> Model Class Initialized
DEBUG - 2012-12-12 17:29:04 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:29:04 --> Helper loaded: language_helper
DEBUG - 2012-12-12 17:29:04 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 17:29:04 --> Final output sent to browser
DEBUG - 2012-12-12 17:29:04 --> Total execution time: 0.0400
DEBUG - 2012-12-12 17:38:55 --> Config Class Initialized
DEBUG - 2012-12-12 17:38:55 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:38:55 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:38:55 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:38:55 --> URI Class Initialized
DEBUG - 2012-12-12 17:38:55 --> Router Class Initialized
DEBUG - 2012-12-12 17:38:55 --> Output Class Initialized
DEBUG - 2012-12-12 17:38:55 --> Security Class Initialized
DEBUG - 2012-12-12 17:38:55 --> Input Class Initialized
DEBUG - 2012-12-12 17:38:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:38:55 --> Language Class Initialized
DEBUG - 2012-12-12 17:38:55 --> Loader Class Initialized
DEBUG - 2012-12-12 17:38:55 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:38:55 --> Controller Class Initialized
DEBUG - 2012-12-12 17:38:55 --> Model Class Initialized
DEBUG - 2012-12-12 17:38:55 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:38:55 --> Helper loaded: form_helper
DEBUG - 2012-12-12 17:38:55 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 17:38:55 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 17:38:55 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 17:38:55 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 17:38:55 --> Final output sent to browser
DEBUG - 2012-12-12 17:38:55 --> Total execution time: 0.0443
DEBUG - 2012-12-12 17:39:00 --> Config Class Initialized
DEBUG - 2012-12-12 17:39:00 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:39:00 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:39:00 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:39:00 --> URI Class Initialized
DEBUG - 2012-12-12 17:39:00 --> Router Class Initialized
ERROR - 2012-12-12 17:39:00 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:39:00 --> Config Class Initialized
DEBUG - 2012-12-12 17:39:00 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:39:00 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:39:00 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:39:00 --> URI Class Initialized
DEBUG - 2012-12-12 17:39:00 --> Router Class Initialized
ERROR - 2012-12-12 17:39:00 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:39:00 --> Config Class Initialized
DEBUG - 2012-12-12 17:39:00 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:39:00 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:39:00 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:39:00 --> URI Class Initialized
DEBUG - 2012-12-12 17:39:00 --> Router Class Initialized
ERROR - 2012-12-12 17:39:00 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:39:01 --> Config Class Initialized
DEBUG - 2012-12-12 17:39:01 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:39:01 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:39:01 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:39:01 --> URI Class Initialized
DEBUG - 2012-12-12 17:39:01 --> Router Class Initialized
DEBUG - 2012-12-12 17:39:01 --> Output Class Initialized
DEBUG - 2012-12-12 17:39:01 --> Security Class Initialized
DEBUG - 2012-12-12 17:39:01 --> Input Class Initialized
DEBUG - 2012-12-12 17:39:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:39:01 --> Language Class Initialized
DEBUG - 2012-12-12 17:39:01 --> Loader Class Initialized
DEBUG - 2012-12-12 17:39:01 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:39:01 --> Controller Class Initialized
DEBUG - 2012-12-12 17:39:01 --> Model Class Initialized
DEBUG - 2012-12-12 17:39:01 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:39:01 --> Helper loaded: language_helper
DEBUG - 2012-12-12 17:39:01 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 17:39:01 --> Final output sent to browser
DEBUG - 2012-12-12 17:39:01 --> Total execution time: 0.0408
DEBUG - 2012-12-12 17:39:50 --> Config Class Initialized
DEBUG - 2012-12-12 17:39:50 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:39:50 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:39:50 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:39:50 --> URI Class Initialized
DEBUG - 2012-12-12 17:39:50 --> Router Class Initialized
DEBUG - 2012-12-12 17:39:50 --> Output Class Initialized
DEBUG - 2012-12-12 17:39:50 --> Security Class Initialized
DEBUG - 2012-12-12 17:39:50 --> Input Class Initialized
DEBUG - 2012-12-12 17:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:39:50 --> Language Class Initialized
DEBUG - 2012-12-12 17:39:50 --> Loader Class Initialized
DEBUG - 2012-12-12 17:39:50 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:39:50 --> Controller Class Initialized
DEBUG - 2012-12-12 17:39:50 --> Model Class Initialized
DEBUG - 2012-12-12 17:39:50 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:39:50 --> Helper loaded: form_helper
DEBUG - 2012-12-12 17:39:50 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 17:39:50 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 17:39:50 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 17:39:50 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 17:39:51 --> Final output sent to browser
DEBUG - 2012-12-12 17:39:51 --> Total execution time: 0.0607
DEBUG - 2012-12-12 17:39:55 --> Config Class Initialized
DEBUG - 2012-12-12 17:39:55 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:39:55 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:39:55 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:39:55 --> URI Class Initialized
DEBUG - 2012-12-12 17:39:55 --> Router Class Initialized
ERROR - 2012-12-12 17:39:55 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:39:55 --> Config Class Initialized
DEBUG - 2012-12-12 17:39:55 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:39:55 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:39:55 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:39:55 --> URI Class Initialized
DEBUG - 2012-12-12 17:39:55 --> Router Class Initialized
ERROR - 2012-12-12 17:39:55 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:39:55 --> Config Class Initialized
DEBUG - 2012-12-12 17:39:55 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:39:55 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:39:55 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:39:55 --> URI Class Initialized
DEBUG - 2012-12-12 17:39:55 --> Router Class Initialized
ERROR - 2012-12-12 17:39:55 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:39:57 --> Config Class Initialized
DEBUG - 2012-12-12 17:39:57 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:39:57 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:39:57 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:39:57 --> URI Class Initialized
DEBUG - 2012-12-12 17:39:57 --> Router Class Initialized
DEBUG - 2012-12-12 17:39:57 --> Output Class Initialized
DEBUG - 2012-12-12 17:39:57 --> Security Class Initialized
DEBUG - 2012-12-12 17:39:57 --> Input Class Initialized
DEBUG - 2012-12-12 17:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:39:57 --> Language Class Initialized
DEBUG - 2012-12-12 17:39:57 --> Loader Class Initialized
DEBUG - 2012-12-12 17:39:57 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:39:57 --> Controller Class Initialized
DEBUG - 2012-12-12 17:39:57 --> Model Class Initialized
DEBUG - 2012-12-12 17:39:57 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:39:57 --> Helper loaded: language_helper
DEBUG - 2012-12-12 17:39:57 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 17:39:57 --> Final output sent to browser
DEBUG - 2012-12-12 17:39:57 --> Total execution time: 0.0460
DEBUG - 2012-12-12 17:40:30 --> Config Class Initialized
DEBUG - 2012-12-12 17:40:30 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:40:30 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:40:30 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:40:30 --> URI Class Initialized
DEBUG - 2012-12-12 17:40:30 --> Router Class Initialized
DEBUG - 2012-12-12 17:40:30 --> Output Class Initialized
DEBUG - 2012-12-12 17:40:30 --> Security Class Initialized
DEBUG - 2012-12-12 17:40:30 --> Input Class Initialized
DEBUG - 2012-12-12 17:40:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:40:30 --> Language Class Initialized
DEBUG - 2012-12-12 17:40:30 --> Loader Class Initialized
DEBUG - 2012-12-12 17:40:30 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:40:30 --> Controller Class Initialized
DEBUG - 2012-12-12 17:40:30 --> Model Class Initialized
DEBUG - 2012-12-12 17:40:30 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:40:30 --> Helper loaded: form_helper
DEBUG - 2012-12-12 17:40:30 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 17:40:30 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 17:40:30 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 17:40:30 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 17:40:30 --> Final output sent to browser
DEBUG - 2012-12-12 17:40:30 --> Total execution time: 0.0660
DEBUG - 2012-12-12 17:40:34 --> Config Class Initialized
DEBUG - 2012-12-12 17:40:34 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:40:34 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:40:34 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:40:34 --> URI Class Initialized
DEBUG - 2012-12-12 17:40:34 --> Router Class Initialized
ERROR - 2012-12-12 17:40:34 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:40:34 --> Config Class Initialized
DEBUG - 2012-12-12 17:40:34 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:40:34 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:40:34 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:40:34 --> URI Class Initialized
DEBUG - 2012-12-12 17:40:34 --> Router Class Initialized
ERROR - 2012-12-12 17:40:34 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:40:34 --> Config Class Initialized
DEBUG - 2012-12-12 17:40:34 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:40:34 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:40:34 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:40:34 --> URI Class Initialized
DEBUG - 2012-12-12 17:40:35 --> Router Class Initialized
ERROR - 2012-12-12 17:40:35 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:40:36 --> Config Class Initialized
DEBUG - 2012-12-12 17:40:36 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:40:36 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:40:36 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:40:36 --> URI Class Initialized
DEBUG - 2012-12-12 17:40:36 --> Router Class Initialized
DEBUG - 2012-12-12 17:40:36 --> Output Class Initialized
DEBUG - 2012-12-12 17:40:36 --> Security Class Initialized
DEBUG - 2012-12-12 17:40:36 --> Input Class Initialized
DEBUG - 2012-12-12 17:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:40:36 --> Language Class Initialized
DEBUG - 2012-12-12 17:40:36 --> Loader Class Initialized
DEBUG - 2012-12-12 17:40:36 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:40:36 --> Controller Class Initialized
DEBUG - 2012-12-12 17:40:36 --> Model Class Initialized
DEBUG - 2012-12-12 17:40:36 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:40:36 --> Helper loaded: language_helper
DEBUG - 2012-12-12 17:40:36 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 17:40:36 --> Final output sent to browser
DEBUG - 2012-12-12 17:40:36 --> Total execution time: 0.0436
DEBUG - 2012-12-12 17:42:27 --> Config Class Initialized
DEBUG - 2012-12-12 17:42:27 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:42:27 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:42:27 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:42:27 --> URI Class Initialized
DEBUG - 2012-12-12 17:42:27 --> Router Class Initialized
DEBUG - 2012-12-12 17:42:27 --> Output Class Initialized
DEBUG - 2012-12-12 17:42:27 --> Security Class Initialized
DEBUG - 2012-12-12 17:42:27 --> Input Class Initialized
DEBUG - 2012-12-12 17:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:42:27 --> Language Class Initialized
DEBUG - 2012-12-12 17:42:27 --> Loader Class Initialized
DEBUG - 2012-12-12 17:42:27 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:42:27 --> Controller Class Initialized
DEBUG - 2012-12-12 17:42:27 --> Model Class Initialized
DEBUG - 2012-12-12 17:42:27 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:42:27 --> Helper loaded: form_helper
DEBUG - 2012-12-12 17:42:27 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 17:42:27 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 17:42:27 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 17:42:27 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 17:42:27 --> Final output sent to browser
DEBUG - 2012-12-12 17:42:27 --> Total execution time: 0.0538
DEBUG - 2012-12-12 17:42:32 --> Config Class Initialized
DEBUG - 2012-12-12 17:42:32 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:42:32 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:42:32 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:42:32 --> URI Class Initialized
DEBUG - 2012-12-12 17:42:32 --> Router Class Initialized
ERROR - 2012-12-12 17:42:32 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:42:32 --> Config Class Initialized
DEBUG - 2012-12-12 17:42:32 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:42:32 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:42:32 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:42:32 --> URI Class Initialized
DEBUG - 2012-12-12 17:42:32 --> Router Class Initialized
ERROR - 2012-12-12 17:42:32 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:42:32 --> Config Class Initialized
DEBUG - 2012-12-12 17:42:32 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:42:32 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:42:32 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:42:32 --> URI Class Initialized
DEBUG - 2012-12-12 17:42:32 --> Router Class Initialized
ERROR - 2012-12-12 17:42:32 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:42:37 --> Config Class Initialized
DEBUG - 2012-12-12 17:42:37 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:42:37 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:42:37 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:42:37 --> URI Class Initialized
DEBUG - 2012-12-12 17:42:37 --> Router Class Initialized
DEBUG - 2012-12-12 17:42:37 --> Output Class Initialized
DEBUG - 2012-12-12 17:42:37 --> Security Class Initialized
DEBUG - 2012-12-12 17:42:37 --> Input Class Initialized
DEBUG - 2012-12-12 17:42:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:42:37 --> Language Class Initialized
DEBUG - 2012-12-12 17:42:37 --> Loader Class Initialized
DEBUG - 2012-12-12 17:42:37 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:42:37 --> Controller Class Initialized
DEBUG - 2012-12-12 17:42:37 --> Model Class Initialized
DEBUG - 2012-12-12 17:42:37 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:42:37 --> Helper loaded: language_helper
DEBUG - 2012-12-12 17:42:37 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 17:42:37 --> Final output sent to browser
DEBUG - 2012-12-12 17:42:37 --> Total execution time: 0.0403
DEBUG - 2012-12-12 17:43:16 --> Config Class Initialized
DEBUG - 2012-12-12 17:43:16 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:43:16 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:43:16 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:43:16 --> URI Class Initialized
DEBUG - 2012-12-12 17:43:16 --> Router Class Initialized
DEBUG - 2012-12-12 17:43:16 --> Output Class Initialized
DEBUG - 2012-12-12 17:43:16 --> Security Class Initialized
DEBUG - 2012-12-12 17:43:16 --> Input Class Initialized
DEBUG - 2012-12-12 17:43:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:43:16 --> Language Class Initialized
DEBUG - 2012-12-12 17:43:16 --> Loader Class Initialized
DEBUG - 2012-12-12 17:43:16 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:43:16 --> Controller Class Initialized
DEBUG - 2012-12-12 17:43:16 --> Model Class Initialized
DEBUG - 2012-12-12 17:43:16 --> Database Driver Class Initialized
ERROR - 2012-12-12 17:43:16 --> 404 Page Not Found --> pricing/ajax_print_configure_update
DEBUG - 2012-12-12 17:44:45 --> Config Class Initialized
DEBUG - 2012-12-12 17:44:45 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:44:45 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:44:45 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:44:45 --> URI Class Initialized
DEBUG - 2012-12-12 17:44:45 --> Router Class Initialized
DEBUG - 2012-12-12 17:44:45 --> Output Class Initialized
DEBUG - 2012-12-12 17:44:45 --> Security Class Initialized
DEBUG - 2012-12-12 17:44:45 --> Input Class Initialized
DEBUG - 2012-12-12 17:44:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:44:45 --> Language Class Initialized
DEBUG - 2012-12-12 17:44:45 --> Loader Class Initialized
DEBUG - 2012-12-12 17:44:45 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:44:45 --> Controller Class Initialized
DEBUG - 2012-12-12 17:44:45 --> Model Class Initialized
DEBUG - 2012-12-12 17:44:45 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:44:45 --> Helper loaded: form_helper
DEBUG - 2012-12-12 17:44:45 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 17:44:45 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 17:44:45 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 17:44:45 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 17:44:46 --> Final output sent to browser
DEBUG - 2012-12-12 17:44:46 --> Total execution time: 0.0445
DEBUG - 2012-12-12 17:44:51 --> Config Class Initialized
DEBUG - 2012-12-12 17:44:51 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:44:51 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:44:51 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:44:51 --> URI Class Initialized
DEBUG - 2012-12-12 17:44:51 --> Router Class Initialized
ERROR - 2012-12-12 17:44:51 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:44:51 --> Config Class Initialized
DEBUG - 2012-12-12 17:44:51 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:44:51 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:44:51 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:44:51 --> URI Class Initialized
DEBUG - 2012-12-12 17:44:51 --> Router Class Initialized
ERROR - 2012-12-12 17:44:51 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:44:51 --> Config Class Initialized
DEBUG - 2012-12-12 17:44:51 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:44:51 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:44:51 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:44:51 --> URI Class Initialized
DEBUG - 2012-12-12 17:44:51 --> Router Class Initialized
ERROR - 2012-12-12 17:44:51 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:44:58 --> Config Class Initialized
DEBUG - 2012-12-12 17:44:58 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:44:58 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:44:58 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:44:58 --> URI Class Initialized
DEBUG - 2012-12-12 17:44:58 --> Router Class Initialized
DEBUG - 2012-12-12 17:44:58 --> Output Class Initialized
DEBUG - 2012-12-12 17:44:58 --> Security Class Initialized
DEBUG - 2012-12-12 17:44:58 --> Input Class Initialized
DEBUG - 2012-12-12 17:44:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:44:58 --> Language Class Initialized
DEBUG - 2012-12-12 17:44:58 --> Loader Class Initialized
DEBUG - 2012-12-12 17:44:58 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:44:58 --> Controller Class Initialized
DEBUG - 2012-12-12 17:44:58 --> Model Class Initialized
DEBUG - 2012-12-12 17:44:58 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:44:58 --> Helper loaded: language_helper
DEBUG - 2012-12-12 17:44:58 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 17:44:58 --> Final output sent to browser
DEBUG - 2012-12-12 17:44:58 --> Total execution time: 0.0429
DEBUG - 2012-12-12 17:48:31 --> Config Class Initialized
DEBUG - 2012-12-12 17:48:31 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:48:31 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:48:31 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:48:31 --> URI Class Initialized
DEBUG - 2012-12-12 17:48:31 --> Router Class Initialized
DEBUG - 2012-12-12 17:48:31 --> Output Class Initialized
DEBUG - 2012-12-12 17:48:31 --> Security Class Initialized
DEBUG - 2012-12-12 17:48:31 --> Input Class Initialized
DEBUG - 2012-12-12 17:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:48:31 --> Language Class Initialized
DEBUG - 2012-12-12 17:48:31 --> Loader Class Initialized
DEBUG - 2012-12-12 17:48:31 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:48:31 --> Controller Class Initialized
DEBUG - 2012-12-12 17:48:31 --> Model Class Initialized
DEBUG - 2012-12-12 17:48:31 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:48:31 --> Helper loaded: language_helper
DEBUG - 2012-12-12 17:48:31 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 17:48:31 --> Final output sent to browser
DEBUG - 2012-12-12 17:48:31 --> Total execution time: 0.0521
DEBUG - 2012-12-12 17:49:02 --> Config Class Initialized
DEBUG - 2012-12-12 17:49:02 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:49:02 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:49:02 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:49:02 --> URI Class Initialized
DEBUG - 2012-12-12 17:49:02 --> Router Class Initialized
DEBUG - 2012-12-12 17:49:02 --> Output Class Initialized
DEBUG - 2012-12-12 17:49:02 --> Security Class Initialized
DEBUG - 2012-12-12 17:49:02 --> Input Class Initialized
DEBUG - 2012-12-12 17:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:49:02 --> Language Class Initialized
DEBUG - 2012-12-12 17:49:02 --> Loader Class Initialized
DEBUG - 2012-12-12 17:49:02 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:49:02 --> Controller Class Initialized
DEBUG - 2012-12-12 17:49:02 --> Model Class Initialized
DEBUG - 2012-12-12 17:49:02 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:49:02 --> Helper loaded: form_helper
DEBUG - 2012-12-12 17:49:02 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 17:49:02 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 17:49:02 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 17:49:02 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 17:49:02 --> Final output sent to browser
DEBUG - 2012-12-12 17:49:02 --> Total execution time: 0.0583
DEBUG - 2012-12-12 17:49:07 --> Config Class Initialized
DEBUG - 2012-12-12 17:49:07 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:49:07 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:49:07 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:49:07 --> URI Class Initialized
DEBUG - 2012-12-12 17:49:07 --> Router Class Initialized
ERROR - 2012-12-12 17:49:07 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:49:07 --> Config Class Initialized
DEBUG - 2012-12-12 17:49:07 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:49:07 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:49:07 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:49:07 --> URI Class Initialized
DEBUG - 2012-12-12 17:49:07 --> Router Class Initialized
ERROR - 2012-12-12 17:49:07 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:49:07 --> Config Class Initialized
DEBUG - 2012-12-12 17:49:07 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:49:07 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:49:07 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:49:07 --> URI Class Initialized
DEBUG - 2012-12-12 17:49:07 --> Router Class Initialized
ERROR - 2012-12-12 17:49:07 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:49:09 --> Config Class Initialized
DEBUG - 2012-12-12 17:49:09 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:49:09 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:49:09 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:49:09 --> URI Class Initialized
DEBUG - 2012-12-12 17:49:09 --> Router Class Initialized
DEBUG - 2012-12-12 17:49:09 --> Output Class Initialized
DEBUG - 2012-12-12 17:49:09 --> Security Class Initialized
DEBUG - 2012-12-12 17:49:09 --> Input Class Initialized
DEBUG - 2012-12-12 17:49:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:49:09 --> Language Class Initialized
DEBUG - 2012-12-12 17:49:09 --> Loader Class Initialized
DEBUG - 2012-12-12 17:49:09 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:49:09 --> Controller Class Initialized
DEBUG - 2012-12-12 17:49:09 --> Model Class Initialized
DEBUG - 2012-12-12 17:49:09 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:49:09 --> Helper loaded: language_helper
DEBUG - 2012-12-12 17:49:09 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 17:49:09 --> Final output sent to browser
DEBUG - 2012-12-12 17:49:09 --> Total execution time: 0.0396
DEBUG - 2012-12-12 17:53:37 --> Config Class Initialized
DEBUG - 2012-12-12 17:53:37 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:53:37 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:53:37 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:53:37 --> URI Class Initialized
DEBUG - 2012-12-12 17:53:37 --> Router Class Initialized
DEBUG - 2012-12-12 17:53:37 --> Output Class Initialized
DEBUG - 2012-12-12 17:53:37 --> Security Class Initialized
DEBUG - 2012-12-12 17:53:37 --> Input Class Initialized
DEBUG - 2012-12-12 17:53:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:53:37 --> Language Class Initialized
DEBUG - 2012-12-12 17:53:37 --> Loader Class Initialized
DEBUG - 2012-12-12 17:53:37 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:53:37 --> Controller Class Initialized
DEBUG - 2012-12-12 17:53:37 --> Model Class Initialized
DEBUG - 2012-12-12 17:53:37 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:53:37 --> Helper loaded: form_helper
DEBUG - 2012-12-12 17:53:37 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 17:53:37 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 17:53:37 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 17:53:37 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 17:53:37 --> Final output sent to browser
DEBUG - 2012-12-12 17:53:37 --> Total execution time: 0.0519
DEBUG - 2012-12-12 17:53:42 --> Config Class Initialized
DEBUG - 2012-12-12 17:53:42 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:53:42 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:53:42 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:53:42 --> URI Class Initialized
DEBUG - 2012-12-12 17:53:42 --> Router Class Initialized
ERROR - 2012-12-12 17:53:42 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:53:42 --> Config Class Initialized
DEBUG - 2012-12-12 17:53:42 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:53:42 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:53:42 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:53:42 --> URI Class Initialized
DEBUG - 2012-12-12 17:53:42 --> Router Class Initialized
ERROR - 2012-12-12 17:53:42 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:53:42 --> Config Class Initialized
DEBUG - 2012-12-12 17:53:42 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:53:42 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:53:42 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:53:42 --> URI Class Initialized
DEBUG - 2012-12-12 17:53:42 --> Router Class Initialized
ERROR - 2012-12-12 17:53:42 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:53:44 --> Config Class Initialized
DEBUG - 2012-12-12 17:53:44 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:53:44 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:53:44 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:53:44 --> URI Class Initialized
DEBUG - 2012-12-12 17:53:44 --> Router Class Initialized
DEBUG - 2012-12-12 17:53:44 --> Output Class Initialized
DEBUG - 2012-12-12 17:53:44 --> Security Class Initialized
DEBUG - 2012-12-12 17:53:44 --> Input Class Initialized
DEBUG - 2012-12-12 17:53:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:53:44 --> Language Class Initialized
DEBUG - 2012-12-12 17:53:44 --> Loader Class Initialized
DEBUG - 2012-12-12 17:53:44 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:53:44 --> Controller Class Initialized
DEBUG - 2012-12-12 17:53:44 --> Model Class Initialized
DEBUG - 2012-12-12 17:53:44 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:53:44 --> Helper loaded: language_helper
DEBUG - 2012-12-12 17:53:44 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 17:53:44 --> Final output sent to browser
DEBUG - 2012-12-12 17:53:44 --> Total execution time: 0.0464
DEBUG - 2012-12-12 17:54:16 --> Config Class Initialized
DEBUG - 2012-12-12 17:54:16 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:54:16 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:54:16 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:54:16 --> URI Class Initialized
DEBUG - 2012-12-12 17:54:16 --> Router Class Initialized
DEBUG - 2012-12-12 17:54:16 --> Output Class Initialized
DEBUG - 2012-12-12 17:54:16 --> Security Class Initialized
DEBUG - 2012-12-12 17:54:16 --> Input Class Initialized
DEBUG - 2012-12-12 17:54:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:54:16 --> Language Class Initialized
DEBUG - 2012-12-12 17:54:16 --> Loader Class Initialized
DEBUG - 2012-12-12 17:54:16 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:54:16 --> Controller Class Initialized
DEBUG - 2012-12-12 17:54:16 --> Model Class Initialized
DEBUG - 2012-12-12 17:54:16 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:54:16 --> Helper loaded: form_helper
DEBUG - 2012-12-12 17:54:16 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 17:54:16 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 17:54:16 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 17:54:16 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 17:54:16 --> Final output sent to browser
DEBUG - 2012-12-12 17:54:16 --> Total execution time: 0.0537
DEBUG - 2012-12-12 17:54:21 --> Config Class Initialized
DEBUG - 2012-12-12 17:54:21 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:54:21 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:54:21 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:54:21 --> URI Class Initialized
DEBUG - 2012-12-12 17:54:21 --> Router Class Initialized
ERROR - 2012-12-12 17:54:21 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:54:21 --> Config Class Initialized
DEBUG - 2012-12-12 17:54:21 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:54:21 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:54:21 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:54:21 --> URI Class Initialized
DEBUG - 2012-12-12 17:54:21 --> Router Class Initialized
ERROR - 2012-12-12 17:54:21 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:54:21 --> Config Class Initialized
DEBUG - 2012-12-12 17:54:21 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:54:21 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:54:21 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:54:21 --> URI Class Initialized
DEBUG - 2012-12-12 17:54:21 --> Router Class Initialized
ERROR - 2012-12-12 17:54:21 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 17:54:23 --> Config Class Initialized
DEBUG - 2012-12-12 17:54:23 --> Hooks Class Initialized
DEBUG - 2012-12-12 17:54:23 --> Utf8 Class Initialized
DEBUG - 2012-12-12 17:54:23 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 17:54:23 --> URI Class Initialized
DEBUG - 2012-12-12 17:54:23 --> Router Class Initialized
DEBUG - 2012-12-12 17:54:23 --> Output Class Initialized
DEBUG - 2012-12-12 17:54:23 --> Security Class Initialized
DEBUG - 2012-12-12 17:54:23 --> Input Class Initialized
DEBUG - 2012-12-12 17:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 17:54:23 --> Language Class Initialized
DEBUG - 2012-12-12 17:54:23 --> Loader Class Initialized
DEBUG - 2012-12-12 17:54:23 --> Helper loaded: url_helper
DEBUG - 2012-12-12 17:54:23 --> Controller Class Initialized
DEBUG - 2012-12-12 17:54:23 --> Model Class Initialized
DEBUG - 2012-12-12 17:54:23 --> Database Driver Class Initialized
DEBUG - 2012-12-12 17:54:23 --> Helper loaded: language_helper
DEBUG - 2012-12-12 17:54:23 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 17:54:23 --> Final output sent to browser
DEBUG - 2012-12-12 17:54:23 --> Total execution time: 0.0409
DEBUG - 2012-12-12 19:27:03 --> Config Class Initialized
DEBUG - 2012-12-12 19:27:03 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:27:03 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:27:03 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:27:03 --> URI Class Initialized
DEBUG - 2012-12-12 19:27:03 --> Router Class Initialized
DEBUG - 2012-12-12 19:27:03 --> Output Class Initialized
DEBUG - 2012-12-12 19:27:03 --> Security Class Initialized
DEBUG - 2012-12-12 19:27:03 --> Input Class Initialized
DEBUG - 2012-12-12 19:27:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 19:27:03 --> Language Class Initialized
DEBUG - 2012-12-12 19:27:03 --> Loader Class Initialized
DEBUG - 2012-12-12 19:27:03 --> Helper loaded: url_helper
DEBUG - 2012-12-12 19:27:03 --> Controller Class Initialized
DEBUG - 2012-12-12 19:27:03 --> Model Class Initialized
DEBUG - 2012-12-12 19:27:03 --> Database Driver Class Initialized
DEBUG - 2012-12-12 19:27:03 --> Helper loaded: form_helper
DEBUG - 2012-12-12 19:27:03 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 19:27:03 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-12-12 19:27:03 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 19:27:03 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-12-12 19:27:03 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 19:27:03 --> Final output sent to browser
DEBUG - 2012-12-12 19:27:03 --> Total execution time: 0.0508
DEBUG - 2012-12-12 19:27:07 --> Config Class Initialized
DEBUG - 2012-12-12 19:27:07 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:27:07 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:27:07 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:27:07 --> URI Class Initialized
DEBUG - 2012-12-12 19:27:07 --> Router Class Initialized
ERROR - 2012-12-12 19:27:07 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 19:27:07 --> Config Class Initialized
DEBUG - 2012-12-12 19:27:07 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:27:07 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:27:07 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:27:07 --> URI Class Initialized
DEBUG - 2012-12-12 19:27:07 --> Router Class Initialized
ERROR - 2012-12-12 19:27:07 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 19:27:07 --> Config Class Initialized
DEBUG - 2012-12-12 19:27:07 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:27:07 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:27:07 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:27:07 --> URI Class Initialized
DEBUG - 2012-12-12 19:27:07 --> Router Class Initialized
ERROR - 2012-12-12 19:27:07 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 19:27:10 --> Config Class Initialized
DEBUG - 2012-12-12 19:27:10 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:27:10 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:27:10 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:27:10 --> URI Class Initialized
DEBUG - 2012-12-12 19:27:10 --> Router Class Initialized
DEBUG - 2012-12-12 19:27:10 --> Output Class Initialized
DEBUG - 2012-12-12 19:27:10 --> Security Class Initialized
DEBUG - 2012-12-12 19:27:10 --> Input Class Initialized
DEBUG - 2012-12-12 19:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 19:27:10 --> Language Class Initialized
DEBUG - 2012-12-12 19:27:10 --> Loader Class Initialized
DEBUG - 2012-12-12 19:27:10 --> Helper loaded: url_helper
DEBUG - 2012-12-12 19:27:10 --> Controller Class Initialized
DEBUG - 2012-12-12 19:27:10 --> Model Class Initialized
DEBUG - 2012-12-12 19:27:10 --> Database Driver Class Initialized
DEBUG - 2012-12-12 19:27:10 --> Helper loaded: form_helper
DEBUG - 2012-12-12 19:27:10 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 19:27:10 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 19:27:10 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 19:27:10 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 19:27:10 --> Final output sent to browser
DEBUG - 2012-12-12 19:27:10 --> Total execution time: 0.0488
DEBUG - 2012-12-12 19:27:13 --> Config Class Initialized
DEBUG - 2012-12-12 19:27:13 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:27:13 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:27:13 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:27:13 --> URI Class Initialized
DEBUG - 2012-12-12 19:27:13 --> Router Class Initialized
DEBUG - 2012-12-12 19:27:13 --> Output Class Initialized
DEBUG - 2012-12-12 19:27:13 --> Security Class Initialized
DEBUG - 2012-12-12 19:27:13 --> Input Class Initialized
DEBUG - 2012-12-12 19:27:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 19:27:13 --> Language Class Initialized
DEBUG - 2012-12-12 19:27:13 --> Loader Class Initialized
DEBUG - 2012-12-12 19:27:13 --> Helper loaded: url_helper
DEBUG - 2012-12-12 19:27:13 --> Controller Class Initialized
DEBUG - 2012-12-12 19:27:13 --> Model Class Initialized
DEBUG - 2012-12-12 19:27:13 --> Database Driver Class Initialized
DEBUG - 2012-12-12 19:27:13 --> Helper loaded: language_helper
DEBUG - 2012-12-12 19:27:13 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 19:27:13 --> Final output sent to browser
DEBUG - 2012-12-12 19:27:13 --> Total execution time: 0.0453
DEBUG - 2012-12-12 19:27:25 --> Config Class Initialized
DEBUG - 2012-12-12 19:27:25 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:27:25 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:27:25 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:27:25 --> URI Class Initialized
DEBUG - 2012-12-12 19:27:25 --> Router Class Initialized
DEBUG - 2012-12-12 19:27:25 --> Output Class Initialized
DEBUG - 2012-12-12 19:27:25 --> Security Class Initialized
DEBUG - 2012-12-12 19:27:25 --> Input Class Initialized
DEBUG - 2012-12-12 19:27:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 19:27:25 --> Language Class Initialized
DEBUG - 2012-12-12 19:27:25 --> Loader Class Initialized
DEBUG - 2012-12-12 19:27:25 --> Helper loaded: url_helper
DEBUG - 2012-12-12 19:27:25 --> Controller Class Initialized
DEBUG - 2012-12-12 19:27:25 --> Model Class Initialized
DEBUG - 2012-12-12 19:27:25 --> Database Driver Class Initialized
DEBUG - 2012-12-12 19:27:25 --> Helper loaded: language_helper
DEBUG - 2012-12-12 19:27:25 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 19:27:25 --> Final output sent to browser
DEBUG - 2012-12-12 19:27:25 --> Total execution time: 0.0394
DEBUG - 2012-12-12 19:28:46 --> Config Class Initialized
DEBUG - 2012-12-12 19:28:46 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:28:46 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:28:46 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:28:46 --> URI Class Initialized
DEBUG - 2012-12-12 19:28:46 --> Router Class Initialized
DEBUG - 2012-12-12 19:28:46 --> Output Class Initialized
DEBUG - 2012-12-12 19:28:46 --> Security Class Initialized
DEBUG - 2012-12-12 19:28:46 --> Input Class Initialized
DEBUG - 2012-12-12 19:28:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 19:28:46 --> Language Class Initialized
DEBUG - 2012-12-12 19:28:46 --> Loader Class Initialized
DEBUG - 2012-12-12 19:28:46 --> Helper loaded: url_helper
DEBUG - 2012-12-12 19:28:46 --> Controller Class Initialized
DEBUG - 2012-12-12 19:28:46 --> Model Class Initialized
DEBUG - 2012-12-12 19:28:46 --> Database Driver Class Initialized
DEBUG - 2012-12-12 19:28:46 --> Helper loaded: language_helper
DEBUG - 2012-12-12 19:28:46 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 19:28:46 --> Final output sent to browser
DEBUG - 2012-12-12 19:28:46 --> Total execution time: 0.0448
DEBUG - 2012-12-12 19:28:54 --> Config Class Initialized
DEBUG - 2012-12-12 19:28:54 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:28:54 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:28:54 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:28:54 --> URI Class Initialized
DEBUG - 2012-12-12 19:28:54 --> Router Class Initialized
DEBUG - 2012-12-12 19:28:54 --> Output Class Initialized
DEBUG - 2012-12-12 19:28:54 --> Security Class Initialized
DEBUG - 2012-12-12 19:28:54 --> Input Class Initialized
DEBUG - 2012-12-12 19:28:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 19:28:54 --> Language Class Initialized
DEBUG - 2012-12-12 19:28:54 --> Loader Class Initialized
DEBUG - 2012-12-12 19:28:54 --> Helper loaded: url_helper
DEBUG - 2012-12-12 19:28:54 --> Controller Class Initialized
DEBUG - 2012-12-12 19:28:54 --> Model Class Initialized
DEBUG - 2012-12-12 19:28:54 --> Database Driver Class Initialized
DEBUG - 2012-12-12 19:28:54 --> Helper loaded: language_helper
DEBUG - 2012-12-12 19:28:54 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 19:28:54 --> Final output sent to browser
DEBUG - 2012-12-12 19:28:54 --> Total execution time: 0.0438
DEBUG - 2012-12-12 19:37:32 --> Config Class Initialized
DEBUG - 2012-12-12 19:37:32 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:37:32 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:37:32 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:37:32 --> URI Class Initialized
DEBUG - 2012-12-12 19:37:32 --> Router Class Initialized
DEBUG - 2012-12-12 19:37:32 --> Output Class Initialized
DEBUG - 2012-12-12 19:37:32 --> Security Class Initialized
DEBUG - 2012-12-12 19:37:32 --> Input Class Initialized
DEBUG - 2012-12-12 19:37:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 19:37:32 --> Language Class Initialized
DEBUG - 2012-12-12 19:37:32 --> Loader Class Initialized
DEBUG - 2012-12-12 19:37:32 --> Helper loaded: url_helper
DEBUG - 2012-12-12 19:37:32 --> Controller Class Initialized
DEBUG - 2012-12-12 19:37:32 --> Model Class Initialized
DEBUG - 2012-12-12 19:37:32 --> Database Driver Class Initialized
DEBUG - 2012-12-12 19:37:32 --> Helper loaded: language_helper
DEBUG - 2012-12-12 19:37:32 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 19:37:32 --> Final output sent to browser
DEBUG - 2012-12-12 19:37:32 --> Total execution time: 0.0393
DEBUG - 2012-12-12 19:41:23 --> Config Class Initialized
DEBUG - 2012-12-12 19:41:23 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:41:23 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:41:23 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:41:23 --> URI Class Initialized
DEBUG - 2012-12-12 19:41:23 --> Router Class Initialized
DEBUG - 2012-12-12 19:41:23 --> Output Class Initialized
DEBUG - 2012-12-12 19:41:23 --> Security Class Initialized
DEBUG - 2012-12-12 19:41:23 --> Input Class Initialized
DEBUG - 2012-12-12 19:41:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 19:41:23 --> Language Class Initialized
DEBUG - 2012-12-12 19:41:23 --> Loader Class Initialized
DEBUG - 2012-12-12 19:41:23 --> Helper loaded: url_helper
DEBUG - 2012-12-12 19:41:23 --> Controller Class Initialized
DEBUG - 2012-12-12 19:41:23 --> Model Class Initialized
DEBUG - 2012-12-12 19:41:23 --> Database Driver Class Initialized
DEBUG - 2012-12-12 19:41:23 --> Helper loaded: form_helper
DEBUG - 2012-12-12 19:41:23 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 19:41:23 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 19:41:23 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 19:41:23 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 19:41:23 --> Final output sent to browser
DEBUG - 2012-12-12 19:41:23 --> Total execution time: 0.0441
DEBUG - 2012-12-12 19:41:25 --> Config Class Initialized
DEBUG - 2012-12-12 19:41:25 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:41:25 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:41:25 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:41:25 --> URI Class Initialized
DEBUG - 2012-12-12 19:41:25 --> Router Class Initialized
DEBUG - 2012-12-12 19:41:25 --> Output Class Initialized
DEBUG - 2012-12-12 19:41:25 --> Security Class Initialized
DEBUG - 2012-12-12 19:41:25 --> Input Class Initialized
DEBUG - 2012-12-12 19:41:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 19:41:25 --> Language Class Initialized
DEBUG - 2012-12-12 19:41:25 --> Loader Class Initialized
DEBUG - 2012-12-12 19:41:25 --> Helper loaded: url_helper
DEBUG - 2012-12-12 19:41:25 --> Controller Class Initialized
DEBUG - 2012-12-12 19:41:25 --> Model Class Initialized
DEBUG - 2012-12-12 19:41:25 --> Database Driver Class Initialized
DEBUG - 2012-12-12 19:41:25 --> Helper loaded: language_helper
DEBUG - 2012-12-12 19:41:25 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 19:41:25 --> Final output sent to browser
DEBUG - 2012-12-12 19:41:25 --> Total execution time: 0.0395
DEBUG - 2012-12-12 19:53:03 --> Config Class Initialized
DEBUG - 2012-12-12 19:53:03 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:53:03 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:53:03 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:53:03 --> URI Class Initialized
DEBUG - 2012-12-12 19:53:03 --> Router Class Initialized
DEBUG - 2012-12-12 19:53:03 --> Output Class Initialized
DEBUG - 2012-12-12 19:53:03 --> Security Class Initialized
DEBUG - 2012-12-12 19:53:03 --> Input Class Initialized
DEBUG - 2012-12-12 19:53:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 19:53:03 --> Language Class Initialized
DEBUG - 2012-12-12 19:53:03 --> Loader Class Initialized
DEBUG - 2012-12-12 19:53:03 --> Helper loaded: url_helper
DEBUG - 2012-12-12 19:53:03 --> Controller Class Initialized
DEBUG - 2012-12-12 19:53:03 --> Model Class Initialized
DEBUG - 2012-12-12 19:53:03 --> Database Driver Class Initialized
DEBUG - 2012-12-12 19:53:03 --> Helper loaded: form_helper
DEBUG - 2012-12-12 19:53:03 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 19:53:03 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 19:53:03 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 19:53:03 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 19:53:03 --> Final output sent to browser
DEBUG - 2012-12-12 19:53:03 --> Total execution time: 0.0442
DEBUG - 2012-12-12 19:53:04 --> Config Class Initialized
DEBUG - 2012-12-12 19:53:04 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:53:04 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:53:04 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:53:04 --> URI Class Initialized
DEBUG - 2012-12-12 19:53:04 --> Router Class Initialized
ERROR - 2012-12-12 19:53:04 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 19:53:04 --> Config Class Initialized
DEBUG - 2012-12-12 19:53:04 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:53:04 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:53:04 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:53:04 --> URI Class Initialized
DEBUG - 2012-12-12 19:53:04 --> Router Class Initialized
ERROR - 2012-12-12 19:53:04 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 19:53:04 --> Config Class Initialized
DEBUG - 2012-12-12 19:53:04 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:53:04 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:53:04 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:53:04 --> URI Class Initialized
DEBUG - 2012-12-12 19:53:04 --> Router Class Initialized
ERROR - 2012-12-12 19:53:04 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 19:53:05 --> Config Class Initialized
DEBUG - 2012-12-12 19:53:05 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:53:05 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:53:05 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:53:05 --> URI Class Initialized
DEBUG - 2012-12-12 19:53:05 --> Router Class Initialized
DEBUG - 2012-12-12 19:53:05 --> Output Class Initialized
DEBUG - 2012-12-12 19:53:05 --> Security Class Initialized
DEBUG - 2012-12-12 19:53:05 --> Input Class Initialized
DEBUG - 2012-12-12 19:53:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 19:53:05 --> Language Class Initialized
DEBUG - 2012-12-12 19:53:05 --> Loader Class Initialized
DEBUG - 2012-12-12 19:53:05 --> Helper loaded: url_helper
DEBUG - 2012-12-12 19:53:05 --> Controller Class Initialized
DEBUG - 2012-12-12 19:53:05 --> Model Class Initialized
DEBUG - 2012-12-12 19:53:05 --> Database Driver Class Initialized
DEBUG - 2012-12-12 19:53:05 --> Helper loaded: language_helper
DEBUG - 2012-12-12 19:53:05 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 19:53:05 --> Final output sent to browser
DEBUG - 2012-12-12 19:53:05 --> Total execution time: 0.0398
DEBUG - 2012-12-12 19:53:41 --> Config Class Initialized
DEBUG - 2012-12-12 19:53:41 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:53:41 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:53:41 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:53:41 --> URI Class Initialized
DEBUG - 2012-12-12 19:53:41 --> Router Class Initialized
DEBUG - 2012-12-12 19:53:41 --> Output Class Initialized
DEBUG - 2012-12-12 19:53:41 --> Security Class Initialized
DEBUG - 2012-12-12 19:53:41 --> Input Class Initialized
DEBUG - 2012-12-12 19:53:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 19:53:41 --> Language Class Initialized
DEBUG - 2012-12-12 19:53:41 --> Loader Class Initialized
DEBUG - 2012-12-12 19:53:41 --> Helper loaded: url_helper
DEBUG - 2012-12-12 19:53:41 --> Controller Class Initialized
DEBUG - 2012-12-12 19:53:41 --> Model Class Initialized
DEBUG - 2012-12-12 19:53:41 --> Database Driver Class Initialized
DEBUG - 2012-12-12 19:53:41 --> Helper loaded: form_helper
DEBUG - 2012-12-12 19:53:41 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 19:53:41 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 19:53:41 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 19:53:41 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 19:53:41 --> Final output sent to browser
DEBUG - 2012-12-12 19:53:41 --> Total execution time: 0.0444
DEBUG - 2012-12-12 19:53:43 --> Config Class Initialized
DEBUG - 2012-12-12 19:53:43 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:53:43 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:53:43 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:53:43 --> URI Class Initialized
DEBUG - 2012-12-12 19:53:43 --> Router Class Initialized
ERROR - 2012-12-12 19:53:43 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 19:53:43 --> Config Class Initialized
DEBUG - 2012-12-12 19:53:43 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:53:43 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:53:43 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:53:43 --> URI Class Initialized
DEBUG - 2012-12-12 19:53:43 --> Router Class Initialized
ERROR - 2012-12-12 19:53:43 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 19:53:43 --> Config Class Initialized
DEBUG - 2012-12-12 19:53:43 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:53:43 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:53:43 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:53:43 --> URI Class Initialized
DEBUG - 2012-12-12 19:53:43 --> Router Class Initialized
ERROR - 2012-12-12 19:53:43 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 19:53:45 --> Config Class Initialized
DEBUG - 2012-12-12 19:53:45 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:53:45 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:53:45 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:53:45 --> URI Class Initialized
DEBUG - 2012-12-12 19:53:45 --> Router Class Initialized
DEBUG - 2012-12-12 19:53:45 --> Output Class Initialized
DEBUG - 2012-12-12 19:53:45 --> Security Class Initialized
DEBUG - 2012-12-12 19:53:45 --> Input Class Initialized
DEBUG - 2012-12-12 19:53:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 19:53:45 --> Language Class Initialized
DEBUG - 2012-12-12 19:53:45 --> Loader Class Initialized
DEBUG - 2012-12-12 19:53:45 --> Helper loaded: url_helper
DEBUG - 2012-12-12 19:53:45 --> Controller Class Initialized
DEBUG - 2012-12-12 19:53:45 --> Model Class Initialized
DEBUG - 2012-12-12 19:53:45 --> Database Driver Class Initialized
DEBUG - 2012-12-12 19:53:45 --> Helper loaded: language_helper
DEBUG - 2012-12-12 19:53:45 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 19:53:45 --> Final output sent to browser
DEBUG - 2012-12-12 19:53:45 --> Total execution time: 0.0407
DEBUG - 2012-12-12 19:55:57 --> Config Class Initialized
DEBUG - 2012-12-12 19:55:57 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:55:57 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:55:57 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:55:57 --> URI Class Initialized
DEBUG - 2012-12-12 19:55:57 --> Router Class Initialized
DEBUG - 2012-12-12 19:55:57 --> Output Class Initialized
DEBUG - 2012-12-12 19:55:57 --> Security Class Initialized
DEBUG - 2012-12-12 19:55:57 --> Input Class Initialized
DEBUG - 2012-12-12 19:55:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 19:55:57 --> Language Class Initialized
DEBUG - 2012-12-12 19:55:57 --> Loader Class Initialized
DEBUG - 2012-12-12 19:55:57 --> Helper loaded: url_helper
DEBUG - 2012-12-12 19:55:57 --> Controller Class Initialized
DEBUG - 2012-12-12 19:55:57 --> Model Class Initialized
DEBUG - 2012-12-12 19:55:57 --> Database Driver Class Initialized
DEBUG - 2012-12-12 19:55:57 --> Helper loaded: form_helper
DEBUG - 2012-12-12 19:55:57 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 19:55:57 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 19:55:57 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 19:55:57 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 19:55:57 --> Final output sent to browser
DEBUG - 2012-12-12 19:55:57 --> Total execution time: 0.1231
DEBUG - 2012-12-12 19:56:00 --> Config Class Initialized
DEBUG - 2012-12-12 19:56:00 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:56:00 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:56:00 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:56:00 --> URI Class Initialized
DEBUG - 2012-12-12 19:56:00 --> Router Class Initialized
ERROR - 2012-12-12 19:56:00 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 19:56:00 --> Config Class Initialized
DEBUG - 2012-12-12 19:56:00 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:56:00 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:56:00 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:56:00 --> URI Class Initialized
DEBUG - 2012-12-12 19:56:00 --> Router Class Initialized
ERROR - 2012-12-12 19:56:00 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 19:56:00 --> Config Class Initialized
DEBUG - 2012-12-12 19:56:00 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:56:00 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:56:00 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:56:00 --> URI Class Initialized
DEBUG - 2012-12-12 19:56:00 --> Router Class Initialized
ERROR - 2012-12-12 19:56:00 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 19:56:01 --> Config Class Initialized
DEBUG - 2012-12-12 19:56:01 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:56:01 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:56:01 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:56:01 --> URI Class Initialized
DEBUG - 2012-12-12 19:56:01 --> Router Class Initialized
DEBUG - 2012-12-12 19:56:01 --> Output Class Initialized
DEBUG - 2012-12-12 19:56:01 --> Security Class Initialized
DEBUG - 2012-12-12 19:56:01 --> Input Class Initialized
DEBUG - 2012-12-12 19:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 19:56:01 --> Language Class Initialized
DEBUG - 2012-12-12 19:56:01 --> Loader Class Initialized
DEBUG - 2012-12-12 19:56:01 --> Helper loaded: url_helper
DEBUG - 2012-12-12 19:56:01 --> Controller Class Initialized
DEBUG - 2012-12-12 19:56:01 --> Model Class Initialized
DEBUG - 2012-12-12 19:56:01 --> Database Driver Class Initialized
DEBUG - 2012-12-12 19:56:01 --> Helper loaded: language_helper
DEBUG - 2012-12-12 19:56:01 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 19:56:01 --> Final output sent to browser
DEBUG - 2012-12-12 19:56:01 --> Total execution time: 0.0977
DEBUG - 2012-12-12 19:57:11 --> Config Class Initialized
DEBUG - 2012-12-12 19:57:11 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:57:11 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:57:11 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:57:11 --> URI Class Initialized
DEBUG - 2012-12-12 19:57:11 --> Router Class Initialized
DEBUG - 2012-12-12 19:57:11 --> Output Class Initialized
DEBUG - 2012-12-12 19:57:11 --> Security Class Initialized
DEBUG - 2012-12-12 19:57:11 --> Input Class Initialized
DEBUG - 2012-12-12 19:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 19:57:11 --> Language Class Initialized
DEBUG - 2012-12-12 19:57:11 --> Loader Class Initialized
DEBUG - 2012-12-12 19:57:11 --> Helper loaded: url_helper
DEBUG - 2012-12-12 19:57:11 --> Controller Class Initialized
DEBUG - 2012-12-12 19:57:11 --> Model Class Initialized
DEBUG - 2012-12-12 19:57:11 --> Database Driver Class Initialized
DEBUG - 2012-12-12 19:57:11 --> Helper loaded: form_helper
DEBUG - 2012-12-12 19:57:11 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 19:57:11 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 19:57:11 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 19:57:11 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 19:57:11 --> Final output sent to browser
DEBUG - 2012-12-12 19:57:11 --> Total execution time: 0.0446
DEBUG - 2012-12-12 19:57:16 --> Config Class Initialized
DEBUG - 2012-12-12 19:57:16 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:57:16 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:57:16 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:57:16 --> URI Class Initialized
DEBUG - 2012-12-12 19:57:16 --> Router Class Initialized
ERROR - 2012-12-12 19:57:16 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 19:57:16 --> Config Class Initialized
DEBUG - 2012-12-12 19:57:16 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:57:16 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:57:16 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:57:16 --> URI Class Initialized
DEBUG - 2012-12-12 19:57:16 --> Router Class Initialized
ERROR - 2012-12-12 19:57:16 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 19:57:16 --> Config Class Initialized
DEBUG - 2012-12-12 19:57:16 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:57:16 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:57:16 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:57:16 --> URI Class Initialized
DEBUG - 2012-12-12 19:57:16 --> Router Class Initialized
ERROR - 2012-12-12 19:57:16 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 19:57:17 --> Config Class Initialized
DEBUG - 2012-12-12 19:57:17 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:57:17 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:57:17 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:57:17 --> URI Class Initialized
DEBUG - 2012-12-12 19:57:17 --> Router Class Initialized
DEBUG - 2012-12-12 19:57:17 --> Output Class Initialized
DEBUG - 2012-12-12 19:57:17 --> Security Class Initialized
DEBUG - 2012-12-12 19:57:17 --> Input Class Initialized
DEBUG - 2012-12-12 19:57:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 19:57:17 --> Language Class Initialized
DEBUG - 2012-12-12 19:57:17 --> Loader Class Initialized
DEBUG - 2012-12-12 19:57:17 --> Helper loaded: url_helper
DEBUG - 2012-12-12 19:57:17 --> Controller Class Initialized
DEBUG - 2012-12-12 19:57:17 --> Model Class Initialized
DEBUG - 2012-12-12 19:57:17 --> Database Driver Class Initialized
DEBUG - 2012-12-12 19:57:17 --> Helper loaded: language_helper
DEBUG - 2012-12-12 19:57:17 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 19:57:17 --> Final output sent to browser
DEBUG - 2012-12-12 19:57:17 --> Total execution time: 0.0404
DEBUG - 2012-12-12 19:57:50 --> Config Class Initialized
DEBUG - 2012-12-12 19:57:50 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:57:50 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:57:50 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:57:50 --> URI Class Initialized
DEBUG - 2012-12-12 19:57:50 --> Router Class Initialized
DEBUG - 2012-12-12 19:57:50 --> Output Class Initialized
DEBUG - 2012-12-12 19:57:50 --> Security Class Initialized
DEBUG - 2012-12-12 19:57:50 --> Input Class Initialized
DEBUG - 2012-12-12 19:57:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 19:57:50 --> Language Class Initialized
DEBUG - 2012-12-12 19:57:50 --> Loader Class Initialized
DEBUG - 2012-12-12 19:57:50 --> Helper loaded: url_helper
DEBUG - 2012-12-12 19:57:50 --> Controller Class Initialized
DEBUG - 2012-12-12 19:57:50 --> Model Class Initialized
DEBUG - 2012-12-12 19:57:50 --> Database Driver Class Initialized
DEBUG - 2012-12-12 19:57:50 --> Helper loaded: form_helper
DEBUG - 2012-12-12 19:57:50 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 19:57:50 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 19:57:50 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 19:57:50 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 19:57:50 --> Final output sent to browser
DEBUG - 2012-12-12 19:57:50 --> Total execution time: 0.0611
DEBUG - 2012-12-12 19:57:52 --> Config Class Initialized
DEBUG - 2012-12-12 19:57:52 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:57:52 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:57:52 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:57:52 --> URI Class Initialized
DEBUG - 2012-12-12 19:57:52 --> Router Class Initialized
ERROR - 2012-12-12 19:57:52 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 19:57:52 --> Config Class Initialized
DEBUG - 2012-12-12 19:57:52 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:57:52 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:57:52 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:57:52 --> URI Class Initialized
DEBUG - 2012-12-12 19:57:52 --> Router Class Initialized
DEBUG - 2012-12-12 19:57:52 --> Config Class Initialized
ERROR - 2012-12-12 19:57:52 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 19:57:52 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:57:52 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:57:52 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:57:52 --> URI Class Initialized
DEBUG - 2012-12-12 19:57:52 --> Router Class Initialized
ERROR - 2012-12-12 19:57:52 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 19:58:44 --> Config Class Initialized
DEBUG - 2012-12-12 19:58:44 --> Hooks Class Initialized
DEBUG - 2012-12-12 19:58:44 --> Utf8 Class Initialized
DEBUG - 2012-12-12 19:58:44 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 19:58:44 --> URI Class Initialized
DEBUG - 2012-12-12 19:58:44 --> Router Class Initialized
DEBUG - 2012-12-12 19:58:44 --> Output Class Initialized
DEBUG - 2012-12-12 19:58:44 --> Security Class Initialized
DEBUG - 2012-12-12 19:58:44 --> Input Class Initialized
DEBUG - 2012-12-12 19:58:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 19:58:44 --> Language Class Initialized
DEBUG - 2012-12-12 19:58:44 --> Loader Class Initialized
DEBUG - 2012-12-12 19:58:44 --> Helper loaded: url_helper
DEBUG - 2012-12-12 19:58:44 --> Controller Class Initialized
DEBUG - 2012-12-12 19:58:44 --> Model Class Initialized
DEBUG - 2012-12-12 19:58:44 --> Database Driver Class Initialized
DEBUG - 2012-12-12 19:58:44 --> Helper loaded: language_helper
DEBUG - 2012-12-12 19:58:44 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 19:58:44 --> Final output sent to browser
DEBUG - 2012-12-12 19:58:44 --> Total execution time: 0.0404
DEBUG - 2012-12-12 20:01:51 --> Config Class Initialized
DEBUG - 2012-12-12 20:01:51 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:01:51 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:01:51 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:01:51 --> URI Class Initialized
DEBUG - 2012-12-12 20:01:51 --> Router Class Initialized
DEBUG - 2012-12-12 20:01:51 --> Output Class Initialized
DEBUG - 2012-12-12 20:01:51 --> Security Class Initialized
DEBUG - 2012-12-12 20:01:51 --> Input Class Initialized
DEBUG - 2012-12-12 20:01:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:01:51 --> Language Class Initialized
DEBUG - 2012-12-12 20:01:51 --> Loader Class Initialized
DEBUG - 2012-12-12 20:01:51 --> Helper loaded: url_helper
DEBUG - 2012-12-12 20:01:51 --> Controller Class Initialized
DEBUG - 2012-12-12 20:01:51 --> Model Class Initialized
DEBUG - 2012-12-12 20:01:51 --> Database Driver Class Initialized
DEBUG - 2012-12-12 20:01:51 --> Helper loaded: form_helper
DEBUG - 2012-12-12 20:01:51 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 20:01:51 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 20:01:51 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 20:01:51 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 20:01:51 --> Final output sent to browser
DEBUG - 2012-12-12 20:01:51 --> Total execution time: 0.0461
DEBUG - 2012-12-12 20:01:53 --> Config Class Initialized
DEBUG - 2012-12-12 20:01:53 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:01:53 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:01:53 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:01:53 --> URI Class Initialized
DEBUG - 2012-12-12 20:01:53 --> Router Class Initialized
ERROR - 2012-12-12 20:01:53 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:01:53 --> Config Class Initialized
DEBUG - 2012-12-12 20:01:53 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:01:53 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:01:53 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:01:53 --> URI Class Initialized
DEBUG - 2012-12-12 20:01:53 --> Router Class Initialized
ERROR - 2012-12-12 20:01:53 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:01:53 --> Config Class Initialized
DEBUG - 2012-12-12 20:01:53 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:01:53 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:01:53 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:01:53 --> URI Class Initialized
DEBUG - 2012-12-12 20:01:53 --> Router Class Initialized
ERROR - 2012-12-12 20:01:53 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:01:55 --> Config Class Initialized
DEBUG - 2012-12-12 20:01:55 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:01:55 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:01:55 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:01:55 --> URI Class Initialized
DEBUG - 2012-12-12 20:01:55 --> Router Class Initialized
DEBUG - 2012-12-12 20:01:55 --> Output Class Initialized
DEBUG - 2012-12-12 20:01:55 --> Security Class Initialized
DEBUG - 2012-12-12 20:01:55 --> Input Class Initialized
DEBUG - 2012-12-12 20:01:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:01:55 --> Language Class Initialized
DEBUG - 2012-12-12 20:01:55 --> Loader Class Initialized
DEBUG - 2012-12-12 20:01:55 --> Helper loaded: url_helper
DEBUG - 2012-12-12 20:01:55 --> Controller Class Initialized
DEBUG - 2012-12-12 20:01:55 --> Model Class Initialized
DEBUG - 2012-12-12 20:01:55 --> Database Driver Class Initialized
DEBUG - 2012-12-12 20:01:55 --> Helper loaded: language_helper
DEBUG - 2012-12-12 20:01:55 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 20:01:55 --> Final output sent to browser
DEBUG - 2012-12-12 20:01:55 --> Total execution time: 0.0391
DEBUG - 2012-12-12 20:02:25 --> Config Class Initialized
DEBUG - 2012-12-12 20:02:25 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:02:25 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:02:25 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:02:25 --> URI Class Initialized
DEBUG - 2012-12-12 20:02:25 --> Router Class Initialized
DEBUG - 2012-12-12 20:02:25 --> Output Class Initialized
DEBUG - 2012-12-12 20:02:25 --> Security Class Initialized
DEBUG - 2012-12-12 20:02:25 --> Input Class Initialized
DEBUG - 2012-12-12 20:02:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:02:25 --> Language Class Initialized
DEBUG - 2012-12-12 20:02:25 --> Loader Class Initialized
DEBUG - 2012-12-12 20:02:25 --> Helper loaded: url_helper
DEBUG - 2012-12-12 20:02:25 --> Controller Class Initialized
DEBUG - 2012-12-12 20:02:25 --> Model Class Initialized
DEBUG - 2012-12-12 20:02:25 --> Database Driver Class Initialized
DEBUG - 2012-12-12 20:02:25 --> Helper loaded: form_helper
DEBUG - 2012-12-12 20:02:25 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 20:02:25 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 20:02:25 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 20:02:25 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 20:02:25 --> Final output sent to browser
DEBUG - 2012-12-12 20:02:25 --> Total execution time: 0.0443
DEBUG - 2012-12-12 20:02:30 --> Config Class Initialized
DEBUG - 2012-12-12 20:02:30 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:02:30 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:02:30 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:02:30 --> URI Class Initialized
DEBUG - 2012-12-12 20:02:30 --> Router Class Initialized
ERROR - 2012-12-12 20:02:30 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:02:30 --> Config Class Initialized
DEBUG - 2012-12-12 20:02:30 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:02:30 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:02:30 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:02:30 --> URI Class Initialized
DEBUG - 2012-12-12 20:02:30 --> Router Class Initialized
ERROR - 2012-12-12 20:02:30 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:02:30 --> Config Class Initialized
DEBUG - 2012-12-12 20:02:30 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:02:30 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:02:30 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:02:30 --> URI Class Initialized
DEBUG - 2012-12-12 20:02:30 --> Router Class Initialized
ERROR - 2012-12-12 20:02:30 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:02:31 --> Config Class Initialized
DEBUG - 2012-12-12 20:02:31 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:02:31 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:02:31 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:02:31 --> URI Class Initialized
DEBUG - 2012-12-12 20:02:31 --> Router Class Initialized
DEBUG - 2012-12-12 20:02:31 --> Output Class Initialized
DEBUG - 2012-12-12 20:02:31 --> Security Class Initialized
DEBUG - 2012-12-12 20:02:31 --> Input Class Initialized
DEBUG - 2012-12-12 20:02:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:02:31 --> Language Class Initialized
DEBUG - 2012-12-12 20:02:31 --> Loader Class Initialized
DEBUG - 2012-12-12 20:02:31 --> Helper loaded: url_helper
DEBUG - 2012-12-12 20:02:31 --> Controller Class Initialized
DEBUG - 2012-12-12 20:02:31 --> Model Class Initialized
DEBUG - 2012-12-12 20:02:31 --> Database Driver Class Initialized
DEBUG - 2012-12-12 20:02:31 --> Helper loaded: language_helper
DEBUG - 2012-12-12 20:02:31 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 20:02:31 --> Final output sent to browser
DEBUG - 2012-12-12 20:02:31 --> Total execution time: 0.0411
DEBUG - 2012-12-12 20:05:10 --> Config Class Initialized
DEBUG - 2012-12-12 20:05:10 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:05:10 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:05:10 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:05:10 --> URI Class Initialized
DEBUG - 2012-12-12 20:05:10 --> Router Class Initialized
DEBUG - 2012-12-12 20:05:10 --> Output Class Initialized
DEBUG - 2012-12-12 20:05:10 --> Security Class Initialized
DEBUG - 2012-12-12 20:05:10 --> Input Class Initialized
DEBUG - 2012-12-12 20:05:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:05:10 --> Language Class Initialized
DEBUG - 2012-12-12 20:05:10 --> Loader Class Initialized
DEBUG - 2012-12-12 20:05:10 --> Helper loaded: url_helper
DEBUG - 2012-12-12 20:05:10 --> Controller Class Initialized
DEBUG - 2012-12-12 20:05:10 --> Model Class Initialized
DEBUG - 2012-12-12 20:05:10 --> Database Driver Class Initialized
DEBUG - 2012-12-12 20:05:10 --> Helper loaded: form_helper
DEBUG - 2012-12-12 20:05:10 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 20:05:10 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 20:05:10 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 20:05:10 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 20:05:10 --> Final output sent to browser
DEBUG - 2012-12-12 20:05:10 --> Total execution time: 0.0460
DEBUG - 2012-12-12 20:05:14 --> Config Class Initialized
DEBUG - 2012-12-12 20:05:14 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:05:14 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:05:14 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:05:14 --> URI Class Initialized
DEBUG - 2012-12-12 20:05:14 --> Router Class Initialized
ERROR - 2012-12-12 20:05:14 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:05:14 --> Config Class Initialized
DEBUG - 2012-12-12 20:05:14 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:05:14 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:05:14 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:05:14 --> URI Class Initialized
DEBUG - 2012-12-12 20:05:14 --> Router Class Initialized
ERROR - 2012-12-12 20:05:14 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:05:14 --> Config Class Initialized
DEBUG - 2012-12-12 20:05:14 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:05:14 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:05:14 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:05:14 --> URI Class Initialized
DEBUG - 2012-12-12 20:05:14 --> Router Class Initialized
ERROR - 2012-12-12 20:05:14 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:05:15 --> Config Class Initialized
DEBUG - 2012-12-12 20:05:15 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:05:15 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:05:15 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:05:15 --> URI Class Initialized
DEBUG - 2012-12-12 20:05:15 --> Router Class Initialized
DEBUG - 2012-12-12 20:05:15 --> Output Class Initialized
DEBUG - 2012-12-12 20:05:15 --> Security Class Initialized
DEBUG - 2012-12-12 20:05:15 --> Input Class Initialized
DEBUG - 2012-12-12 20:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:05:15 --> Language Class Initialized
DEBUG - 2012-12-12 20:05:15 --> Loader Class Initialized
DEBUG - 2012-12-12 20:05:15 --> Helper loaded: url_helper
DEBUG - 2012-12-12 20:05:15 --> Controller Class Initialized
DEBUG - 2012-12-12 20:05:15 --> Model Class Initialized
DEBUG - 2012-12-12 20:05:15 --> Database Driver Class Initialized
DEBUG - 2012-12-12 20:05:15 --> Helper loaded: language_helper
DEBUG - 2012-12-12 20:05:15 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 20:05:15 --> Final output sent to browser
DEBUG - 2012-12-12 20:05:15 --> Total execution time: 0.0420
DEBUG - 2012-12-12 20:05:36 --> Config Class Initialized
DEBUG - 2012-12-12 20:05:36 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:05:36 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:05:36 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:05:36 --> URI Class Initialized
DEBUG - 2012-12-12 20:05:36 --> Router Class Initialized
DEBUG - 2012-12-12 20:05:36 --> Output Class Initialized
DEBUG - 2012-12-12 20:05:36 --> Security Class Initialized
DEBUG - 2012-12-12 20:05:36 --> Input Class Initialized
DEBUG - 2012-12-12 20:05:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:05:36 --> Language Class Initialized
DEBUG - 2012-12-12 20:05:36 --> Loader Class Initialized
DEBUG - 2012-12-12 20:05:36 --> Helper loaded: url_helper
DEBUG - 2012-12-12 20:05:36 --> Controller Class Initialized
DEBUG - 2012-12-12 20:05:36 --> Model Class Initialized
DEBUG - 2012-12-12 20:05:36 --> Database Driver Class Initialized
DEBUG - 2012-12-12 20:05:36 --> Helper loaded: form_helper
DEBUG - 2012-12-12 20:05:36 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 20:05:36 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 20:05:36 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 20:05:36 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 20:05:36 --> Final output sent to browser
DEBUG - 2012-12-12 20:05:36 --> Total execution time: 0.0534
DEBUG - 2012-12-12 20:05:38 --> Config Class Initialized
DEBUG - 2012-12-12 20:05:38 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:05:38 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:05:38 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:05:38 --> URI Class Initialized
DEBUG - 2012-12-12 20:05:38 --> Router Class Initialized
ERROR - 2012-12-12 20:05:38 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:05:38 --> Config Class Initialized
DEBUG - 2012-12-12 20:05:38 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:05:38 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:05:38 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:05:38 --> URI Class Initialized
DEBUG - 2012-12-12 20:05:38 --> Router Class Initialized
ERROR - 2012-12-12 20:05:38 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:05:38 --> Config Class Initialized
DEBUG - 2012-12-12 20:05:38 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:05:38 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:05:38 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:05:38 --> URI Class Initialized
DEBUG - 2012-12-12 20:05:38 --> Router Class Initialized
ERROR - 2012-12-12 20:05:38 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:05:39 --> Config Class Initialized
DEBUG - 2012-12-12 20:05:39 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:05:39 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:05:39 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:05:39 --> URI Class Initialized
DEBUG - 2012-12-12 20:05:39 --> Router Class Initialized
DEBUG - 2012-12-12 20:05:39 --> Output Class Initialized
DEBUG - 2012-12-12 20:05:39 --> Security Class Initialized
DEBUG - 2012-12-12 20:05:39 --> Input Class Initialized
DEBUG - 2012-12-12 20:05:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:05:39 --> Language Class Initialized
DEBUG - 2012-12-12 20:05:39 --> Loader Class Initialized
DEBUG - 2012-12-12 20:05:39 --> Helper loaded: url_helper
DEBUG - 2012-12-12 20:05:39 --> Controller Class Initialized
DEBUG - 2012-12-12 20:05:39 --> Model Class Initialized
DEBUG - 2012-12-12 20:05:39 --> Database Driver Class Initialized
DEBUG - 2012-12-12 20:05:39 --> Helper loaded: language_helper
DEBUG - 2012-12-12 20:05:39 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 20:05:39 --> Final output sent to browser
DEBUG - 2012-12-12 20:05:39 --> Total execution time: 0.0418
DEBUG - 2012-12-12 20:06:18 --> Config Class Initialized
DEBUG - 2012-12-12 20:06:18 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:06:18 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:06:18 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:06:18 --> URI Class Initialized
DEBUG - 2012-12-12 20:06:18 --> Router Class Initialized
DEBUG - 2012-12-12 20:06:18 --> Output Class Initialized
DEBUG - 2012-12-12 20:06:18 --> Security Class Initialized
DEBUG - 2012-12-12 20:06:18 --> Input Class Initialized
DEBUG - 2012-12-12 20:06:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:06:18 --> Language Class Initialized
DEBUG - 2012-12-12 20:06:18 --> Loader Class Initialized
DEBUG - 2012-12-12 20:06:18 --> Helper loaded: url_helper
DEBUG - 2012-12-12 20:06:18 --> Controller Class Initialized
DEBUG - 2012-12-12 20:06:18 --> Model Class Initialized
DEBUG - 2012-12-12 20:06:18 --> Database Driver Class Initialized
DEBUG - 2012-12-12 20:06:18 --> Helper loaded: form_helper
DEBUG - 2012-12-12 20:06:18 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 20:06:18 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 20:06:18 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 20:06:18 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 20:06:18 --> Final output sent to browser
DEBUG - 2012-12-12 20:06:18 --> Total execution time: 0.0443
DEBUG - 2012-12-12 20:06:20 --> Config Class Initialized
DEBUG - 2012-12-12 20:06:20 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:06:20 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:06:20 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:06:20 --> URI Class Initialized
DEBUG - 2012-12-12 20:06:20 --> Router Class Initialized
ERROR - 2012-12-12 20:06:20 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:06:20 --> Config Class Initialized
DEBUG - 2012-12-12 20:06:20 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:06:20 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:06:20 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:06:20 --> URI Class Initialized
DEBUG - 2012-12-12 20:06:20 --> Router Class Initialized
ERROR - 2012-12-12 20:06:20 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:06:20 --> Config Class Initialized
DEBUG - 2012-12-12 20:06:20 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:06:20 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:06:20 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:06:20 --> URI Class Initialized
DEBUG - 2012-12-12 20:06:20 --> Router Class Initialized
ERROR - 2012-12-12 20:06:20 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:06:21 --> Config Class Initialized
DEBUG - 2012-12-12 20:06:21 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:06:21 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:06:21 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:06:21 --> URI Class Initialized
DEBUG - 2012-12-12 20:06:21 --> Router Class Initialized
DEBUG - 2012-12-12 20:06:21 --> Output Class Initialized
DEBUG - 2012-12-12 20:06:21 --> Security Class Initialized
DEBUG - 2012-12-12 20:06:21 --> Input Class Initialized
DEBUG - 2012-12-12 20:06:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:06:21 --> Language Class Initialized
DEBUG - 2012-12-12 20:06:21 --> Loader Class Initialized
DEBUG - 2012-12-12 20:06:21 --> Helper loaded: url_helper
DEBUG - 2012-12-12 20:06:21 --> Controller Class Initialized
DEBUG - 2012-12-12 20:06:21 --> Model Class Initialized
DEBUG - 2012-12-12 20:06:21 --> Database Driver Class Initialized
DEBUG - 2012-12-12 20:06:21 --> Helper loaded: language_helper
DEBUG - 2012-12-12 20:06:21 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 20:06:21 --> Final output sent to browser
DEBUG - 2012-12-12 20:06:21 --> Total execution time: 0.0408
DEBUG - 2012-12-12 20:07:23 --> Config Class Initialized
DEBUG - 2012-12-12 20:07:23 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:07:23 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:07:23 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:07:23 --> URI Class Initialized
DEBUG - 2012-12-12 20:07:23 --> Router Class Initialized
DEBUG - 2012-12-12 20:07:23 --> Output Class Initialized
DEBUG - 2012-12-12 20:07:23 --> Security Class Initialized
DEBUG - 2012-12-12 20:07:23 --> Input Class Initialized
DEBUG - 2012-12-12 20:07:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:07:23 --> Language Class Initialized
DEBUG - 2012-12-12 20:07:23 --> Loader Class Initialized
DEBUG - 2012-12-12 20:07:23 --> Helper loaded: url_helper
DEBUG - 2012-12-12 20:07:23 --> Controller Class Initialized
DEBUG - 2012-12-12 20:07:23 --> Model Class Initialized
DEBUG - 2012-12-12 20:07:23 --> Database Driver Class Initialized
DEBUG - 2012-12-12 20:07:23 --> Helper loaded: form_helper
DEBUG - 2012-12-12 20:07:23 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 20:07:23 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 20:07:23 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 20:07:23 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 20:07:23 --> Final output sent to browser
DEBUG - 2012-12-12 20:07:23 --> Total execution time: 0.0455
DEBUG - 2012-12-12 20:07:27 --> Config Class Initialized
DEBUG - 2012-12-12 20:07:27 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:07:27 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:07:27 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:07:27 --> URI Class Initialized
DEBUG - 2012-12-12 20:07:27 --> Router Class Initialized
ERROR - 2012-12-12 20:07:27 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:07:27 --> Config Class Initialized
DEBUG - 2012-12-12 20:07:27 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:07:27 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:07:27 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:07:27 --> URI Class Initialized
DEBUG - 2012-12-12 20:07:27 --> Router Class Initialized
ERROR - 2012-12-12 20:07:27 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:07:27 --> Config Class Initialized
DEBUG - 2012-12-12 20:07:27 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:07:27 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:07:27 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:07:27 --> URI Class Initialized
DEBUG - 2012-12-12 20:07:27 --> Router Class Initialized
ERROR - 2012-12-12 20:07:27 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:07:28 --> Config Class Initialized
DEBUG - 2012-12-12 20:07:28 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:07:28 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:07:28 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:07:28 --> URI Class Initialized
DEBUG - 2012-12-12 20:07:28 --> Router Class Initialized
DEBUG - 2012-12-12 20:07:28 --> Output Class Initialized
DEBUG - 2012-12-12 20:07:28 --> Security Class Initialized
DEBUG - 2012-12-12 20:07:28 --> Input Class Initialized
DEBUG - 2012-12-12 20:07:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:07:28 --> Language Class Initialized
DEBUG - 2012-12-12 20:07:28 --> Loader Class Initialized
DEBUG - 2012-12-12 20:07:28 --> Helper loaded: url_helper
DEBUG - 2012-12-12 20:07:28 --> Controller Class Initialized
DEBUG - 2012-12-12 20:07:28 --> Model Class Initialized
DEBUG - 2012-12-12 20:07:28 --> Database Driver Class Initialized
DEBUG - 2012-12-12 20:07:28 --> Helper loaded: language_helper
DEBUG - 2012-12-12 20:07:28 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 20:07:28 --> Final output sent to browser
DEBUG - 2012-12-12 20:07:28 --> Total execution time: 0.0439
DEBUG - 2012-12-12 20:08:24 --> Config Class Initialized
DEBUG - 2012-12-12 20:08:24 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:08:24 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:08:24 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:08:24 --> URI Class Initialized
DEBUG - 2012-12-12 20:08:24 --> Router Class Initialized
DEBUG - 2012-12-12 20:08:24 --> Output Class Initialized
DEBUG - 2012-12-12 20:08:24 --> Security Class Initialized
DEBUG - 2012-12-12 20:08:24 --> Input Class Initialized
DEBUG - 2012-12-12 20:08:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:08:24 --> Language Class Initialized
DEBUG - 2012-12-12 20:08:24 --> Loader Class Initialized
DEBUG - 2012-12-12 20:08:24 --> Helper loaded: url_helper
DEBUG - 2012-12-12 20:08:24 --> Controller Class Initialized
DEBUG - 2012-12-12 20:08:24 --> Model Class Initialized
DEBUG - 2012-12-12 20:08:24 --> Database Driver Class Initialized
DEBUG - 2012-12-12 20:08:24 --> Helper loaded: form_helper
DEBUG - 2012-12-12 20:08:24 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 20:08:24 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 20:08:24 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 20:08:24 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 20:08:24 --> Final output sent to browser
DEBUG - 2012-12-12 20:08:24 --> Total execution time: 0.0447
DEBUG - 2012-12-12 20:08:26 --> Config Class Initialized
DEBUG - 2012-12-12 20:08:26 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:08:26 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:08:26 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:08:26 --> URI Class Initialized
DEBUG - 2012-12-12 20:08:26 --> Router Class Initialized
ERROR - 2012-12-12 20:08:26 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:08:26 --> Config Class Initialized
DEBUG - 2012-12-12 20:08:26 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:08:26 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:08:26 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:08:26 --> URI Class Initialized
DEBUG - 2012-12-12 20:08:26 --> Router Class Initialized
ERROR - 2012-12-12 20:08:26 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:08:26 --> Config Class Initialized
DEBUG - 2012-12-12 20:08:26 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:08:26 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:08:26 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:08:26 --> URI Class Initialized
DEBUG - 2012-12-12 20:08:26 --> Router Class Initialized
ERROR - 2012-12-12 20:08:26 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:08:27 --> Config Class Initialized
DEBUG - 2012-12-12 20:08:27 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:08:27 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:08:27 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:08:27 --> URI Class Initialized
DEBUG - 2012-12-12 20:08:27 --> Router Class Initialized
DEBUG - 2012-12-12 20:08:27 --> Output Class Initialized
DEBUG - 2012-12-12 20:08:27 --> Security Class Initialized
DEBUG - 2012-12-12 20:08:27 --> Input Class Initialized
DEBUG - 2012-12-12 20:08:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:08:27 --> Language Class Initialized
DEBUG - 2012-12-12 20:08:27 --> Loader Class Initialized
DEBUG - 2012-12-12 20:08:27 --> Helper loaded: url_helper
DEBUG - 2012-12-12 20:08:27 --> Controller Class Initialized
DEBUG - 2012-12-12 20:08:27 --> Model Class Initialized
DEBUG - 2012-12-12 20:08:27 --> Database Driver Class Initialized
DEBUG - 2012-12-12 20:08:27 --> Helper loaded: language_helper
DEBUG - 2012-12-12 20:08:27 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 20:08:27 --> Final output sent to browser
DEBUG - 2012-12-12 20:08:27 --> Total execution time: 0.0418
DEBUG - 2012-12-12 20:20:06 --> Config Class Initialized
DEBUG - 2012-12-12 20:20:06 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:20:06 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:20:06 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:20:06 --> URI Class Initialized
DEBUG - 2012-12-12 20:20:06 --> Router Class Initialized
DEBUG - 2012-12-12 20:20:06 --> Output Class Initialized
DEBUG - 2012-12-12 20:20:06 --> Security Class Initialized
DEBUG - 2012-12-12 20:20:06 --> Input Class Initialized
DEBUG - 2012-12-12 20:20:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:20:06 --> Language Class Initialized
DEBUG - 2012-12-12 20:20:06 --> Loader Class Initialized
DEBUG - 2012-12-12 20:20:06 --> Helper loaded: url_helper
DEBUG - 2012-12-12 20:20:06 --> Controller Class Initialized
DEBUG - 2012-12-12 20:20:06 --> Model Class Initialized
DEBUG - 2012-12-12 20:20:06 --> Database Driver Class Initialized
DEBUG - 2012-12-12 20:20:06 --> Helper loaded: form_helper
DEBUG - 2012-12-12 20:20:06 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 20:20:06 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 20:20:06 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 20:20:06 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 20:20:07 --> Final output sent to browser
DEBUG - 2012-12-12 20:20:07 --> Total execution time: 0.0540
DEBUG - 2012-12-12 20:20:10 --> Config Class Initialized
DEBUG - 2012-12-12 20:20:10 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:20:10 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:20:10 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:20:10 --> URI Class Initialized
DEBUG - 2012-12-12 20:20:10 --> Router Class Initialized
ERROR - 2012-12-12 20:20:10 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:20:10 --> Config Class Initialized
DEBUG - 2012-12-12 20:20:10 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:20:10 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:20:10 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:20:10 --> URI Class Initialized
DEBUG - 2012-12-12 20:20:10 --> Router Class Initialized
ERROR - 2012-12-12 20:20:10 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:20:10 --> Config Class Initialized
DEBUG - 2012-12-12 20:20:10 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:20:10 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:20:10 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:20:10 --> URI Class Initialized
DEBUG - 2012-12-12 20:20:10 --> Router Class Initialized
ERROR - 2012-12-12 20:20:10 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:20:12 --> Config Class Initialized
DEBUG - 2012-12-12 20:20:12 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:20:12 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:20:12 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:20:12 --> URI Class Initialized
DEBUG - 2012-12-12 20:20:12 --> Router Class Initialized
DEBUG - 2012-12-12 20:20:12 --> Output Class Initialized
DEBUG - 2012-12-12 20:20:12 --> Security Class Initialized
DEBUG - 2012-12-12 20:20:12 --> Input Class Initialized
DEBUG - 2012-12-12 20:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:20:12 --> Language Class Initialized
DEBUG - 2012-12-12 20:20:12 --> Loader Class Initialized
DEBUG - 2012-12-12 20:20:12 --> Helper loaded: url_helper
DEBUG - 2012-12-12 20:20:12 --> Controller Class Initialized
DEBUG - 2012-12-12 20:20:12 --> Model Class Initialized
DEBUG - 2012-12-12 20:20:12 --> Database Driver Class Initialized
DEBUG - 2012-12-12 20:20:12 --> Helper loaded: language_helper
DEBUG - 2012-12-12 20:20:12 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 20:20:12 --> Final output sent to browser
DEBUG - 2012-12-12 20:20:12 --> Total execution time: 0.0396
DEBUG - 2012-12-12 20:25:26 --> Config Class Initialized
DEBUG - 2012-12-12 20:25:26 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:25:26 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:25:26 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:25:26 --> URI Class Initialized
DEBUG - 2012-12-12 20:25:26 --> Router Class Initialized
DEBUG - 2012-12-12 20:25:26 --> Output Class Initialized
DEBUG - 2012-12-12 20:25:26 --> Security Class Initialized
DEBUG - 2012-12-12 20:25:26 --> Input Class Initialized
DEBUG - 2012-12-12 20:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:25:26 --> Language Class Initialized
DEBUG - 2012-12-12 20:25:51 --> Config Class Initialized
DEBUG - 2012-12-12 20:25:51 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:25:51 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:25:51 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:25:51 --> URI Class Initialized
DEBUG - 2012-12-12 20:25:51 --> Router Class Initialized
DEBUG - 2012-12-12 20:25:51 --> Output Class Initialized
DEBUG - 2012-12-12 20:25:51 --> Security Class Initialized
DEBUG - 2012-12-12 20:25:51 --> Input Class Initialized
DEBUG - 2012-12-12 20:25:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:25:51 --> Language Class Initialized
DEBUG - 2012-12-12 20:25:51 --> Loader Class Initialized
DEBUG - 2012-12-12 20:25:51 --> Helper loaded: url_helper
DEBUG - 2012-12-12 20:25:51 --> Controller Class Initialized
DEBUG - 2012-12-12 20:25:51 --> Model Class Initialized
DEBUG - 2012-12-12 20:25:51 --> Database Driver Class Initialized
DEBUG - 2012-12-12 20:25:51 --> Helper loaded: form_helper
DEBUG - 2012-12-12 20:25:51 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 20:25:51 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 20:25:51 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 20:25:51 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 20:25:51 --> Final output sent to browser
DEBUG - 2012-12-12 20:25:51 --> Total execution time: 0.0435
DEBUG - 2012-12-12 20:25:53 --> Config Class Initialized
DEBUG - 2012-12-12 20:25:53 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:25:53 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:25:53 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:25:53 --> URI Class Initialized
DEBUG - 2012-12-12 20:25:53 --> Router Class Initialized
ERROR - 2012-12-12 20:25:53 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:25:53 --> Config Class Initialized
DEBUG - 2012-12-12 20:25:53 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:25:53 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:25:53 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:25:53 --> URI Class Initialized
DEBUG - 2012-12-12 20:25:53 --> Router Class Initialized
ERROR - 2012-12-12 20:25:53 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:26:53 --> Config Class Initialized
DEBUG - 2012-12-12 20:26:53 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:26:53 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:26:53 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:26:53 --> URI Class Initialized
DEBUG - 2012-12-12 20:26:53 --> Router Class Initialized
DEBUG - 2012-12-12 20:26:53 --> Output Class Initialized
DEBUG - 2012-12-12 20:26:53 --> Security Class Initialized
DEBUG - 2012-12-12 20:26:53 --> Input Class Initialized
DEBUG - 2012-12-12 20:26:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:26:53 --> Language Class Initialized
DEBUG - 2012-12-12 20:26:57 --> Config Class Initialized
DEBUG - 2012-12-12 20:26:57 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:26:57 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:26:57 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:26:57 --> URI Class Initialized
DEBUG - 2012-12-12 20:26:57 --> Router Class Initialized
DEBUG - 2012-12-12 20:26:57 --> Output Class Initialized
DEBUG - 2012-12-12 20:26:57 --> Security Class Initialized
DEBUG - 2012-12-12 20:26:57 --> Input Class Initialized
DEBUG - 2012-12-12 20:26:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:26:57 --> Language Class Initialized
DEBUG - 2012-12-12 20:27:13 --> Config Class Initialized
DEBUG - 2012-12-12 20:27:13 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:27:13 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:27:13 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:27:13 --> URI Class Initialized
DEBUG - 2012-12-12 20:27:13 --> Router Class Initialized
DEBUG - 2012-12-12 20:27:13 --> Output Class Initialized
DEBUG - 2012-12-12 20:27:13 --> Security Class Initialized
DEBUG - 2012-12-12 20:27:13 --> Input Class Initialized
DEBUG - 2012-12-12 20:27:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:27:13 --> Language Class Initialized
DEBUG - 2012-12-12 20:27:15 --> Config Class Initialized
DEBUG - 2012-12-12 20:27:15 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:27:15 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:27:15 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:27:15 --> URI Class Initialized
DEBUG - 2012-12-12 20:27:15 --> Router Class Initialized
DEBUG - 2012-12-12 20:27:15 --> Output Class Initialized
DEBUG - 2012-12-12 20:27:15 --> Security Class Initialized
DEBUG - 2012-12-12 20:27:15 --> Input Class Initialized
DEBUG - 2012-12-12 20:27:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:27:15 --> Language Class Initialized
DEBUG - 2012-12-12 20:27:55 --> Config Class Initialized
DEBUG - 2012-12-12 20:27:55 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:27:55 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:27:55 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:27:55 --> URI Class Initialized
DEBUG - 2012-12-12 20:27:55 --> Router Class Initialized
DEBUG - 2012-12-12 20:27:55 --> Output Class Initialized
DEBUG - 2012-12-12 20:27:55 --> Security Class Initialized
DEBUG - 2012-12-12 20:27:55 --> Input Class Initialized
DEBUG - 2012-12-12 20:27:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:27:55 --> Language Class Initialized
DEBUG - 2012-12-12 20:27:55 --> Loader Class Initialized
DEBUG - 2012-12-12 20:27:55 --> Helper loaded: url_helper
DEBUG - 2012-12-12 20:27:55 --> Controller Class Initialized
DEBUG - 2012-12-12 20:27:55 --> Model Class Initialized
DEBUG - 2012-12-12 20:27:55 --> Database Driver Class Initialized
DEBUG - 2012-12-12 20:27:55 --> Helper loaded: form_helper
DEBUG - 2012-12-12 20:27:55 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-12 20:27:55 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-12 20:27:55 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-12 20:27:55 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-12 20:27:56 --> Final output sent to browser
DEBUG - 2012-12-12 20:27:56 --> Total execution time: 0.0532
DEBUG - 2012-12-12 20:27:59 --> Config Class Initialized
DEBUG - 2012-12-12 20:27:59 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:27:59 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:27:59 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:27:59 --> URI Class Initialized
DEBUG - 2012-12-12 20:27:59 --> Router Class Initialized
ERROR - 2012-12-12 20:27:59 --> 404 Page Not Found --> css
DEBUG - 2012-12-12 20:28:00 --> Config Class Initialized
DEBUG - 2012-12-12 20:28:00 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:28:00 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:28:00 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:28:00 --> URI Class Initialized
DEBUG - 2012-12-12 20:28:00 --> Router Class Initialized
DEBUG - 2012-12-12 20:28:00 --> Output Class Initialized
DEBUG - 2012-12-12 20:28:00 --> Security Class Initialized
DEBUG - 2012-12-12 20:28:00 --> Input Class Initialized
DEBUG - 2012-12-12 20:28:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:28:00 --> Language Class Initialized
DEBUG - 2012-12-12 20:28:00 --> Loader Class Initialized
DEBUG - 2012-12-12 20:28:00 --> Helper loaded: url_helper
DEBUG - 2012-12-12 20:28:00 --> Controller Class Initialized
DEBUG - 2012-12-12 20:28:00 --> Model Class Initialized
DEBUG - 2012-12-12 20:28:00 --> Database Driver Class Initialized
DEBUG - 2012-12-12 20:28:00 --> Helper loaded: language_helper
DEBUG - 2012-12-12 20:28:00 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-12 20:28:00 --> Final output sent to browser
DEBUG - 2012-12-12 20:28:00 --> Total execution time: 0.0397
DEBUG - 2012-12-12 20:28:03 --> Config Class Initialized
DEBUG - 2012-12-12 20:28:03 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:28:03 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:28:03 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:28:03 --> URI Class Initialized
DEBUG - 2012-12-12 20:28:03 --> Router Class Initialized
DEBUG - 2012-12-12 20:28:03 --> Output Class Initialized
DEBUG - 2012-12-12 20:28:03 --> Security Class Initialized
DEBUG - 2012-12-12 20:28:03 --> Input Class Initialized
DEBUG - 2012-12-12 20:28:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:28:03 --> Language Class Initialized
DEBUG - 2012-12-12 20:28:03 --> Loader Class Initialized
DEBUG - 2012-12-12 20:28:03 --> Helper loaded: url_helper
DEBUG - 2012-12-12 20:28:03 --> Controller Class Initialized
DEBUG - 2012-12-12 20:28:03 --> Model Class Initialized
DEBUG - 2012-12-12 20:28:03 --> Database Driver Class Initialized
ERROR - 2012-12-12 20:28:03 --> 404 Page Not Found --> pricing/ajax_print_configure_update
DEBUG - 2012-12-12 20:37:12 --> Config Class Initialized
DEBUG - 2012-12-12 20:37:12 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:37:12 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:37:12 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:37:12 --> URI Class Initialized
DEBUG - 2012-12-12 20:37:12 --> Router Class Initialized
DEBUG - 2012-12-12 20:37:12 --> Output Class Initialized
DEBUG - 2012-12-12 20:37:12 --> Security Class Initialized
DEBUG - 2012-12-12 20:37:12 --> Input Class Initialized
DEBUG - 2012-12-12 20:37:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:37:12 --> Language Class Initialized
DEBUG - 2012-12-12 20:41:29 --> Config Class Initialized
DEBUG - 2012-12-12 20:41:29 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:41:29 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:41:29 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:41:29 --> URI Class Initialized
DEBUG - 2012-12-12 20:41:29 --> Router Class Initialized
DEBUG - 2012-12-12 20:41:29 --> Output Class Initialized
DEBUG - 2012-12-12 20:41:29 --> Security Class Initialized
DEBUG - 2012-12-12 20:41:29 --> Input Class Initialized
DEBUG - 2012-12-12 20:41:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:41:29 --> Language Class Initialized
DEBUG - 2012-12-12 20:42:13 --> Config Class Initialized
DEBUG - 2012-12-12 20:42:13 --> Hooks Class Initialized
DEBUG - 2012-12-12 20:42:13 --> Utf8 Class Initialized
DEBUG - 2012-12-12 20:42:13 --> UTF-8 Support Enabled
DEBUG - 2012-12-12 20:42:13 --> URI Class Initialized
DEBUG - 2012-12-12 20:42:13 --> Router Class Initialized
DEBUG - 2012-12-12 20:42:13 --> Output Class Initialized
DEBUG - 2012-12-12 20:42:13 --> Security Class Initialized
DEBUG - 2012-12-12 20:42:13 --> Input Class Initialized
DEBUG - 2012-12-12 20:42:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-12 20:42:13 --> Language Class Initialized
DEBUG - 2012-12-12 20:42:13 --> Loader Class Initialized
DEBUG - 2012-12-12 20:42:13 --> Helper loaded: url_helper
DEBUG - 2012-12-12 20:42:13 --> Controller Class Initialized
DEBUG - 2012-12-12 20:42:13 --> Model Class Initialized
DEBUG - 2012-12-12 20:42:13 --> Database Driver Class Initialized
DEBUG - 2012-12-12 20:42:13 --> Helper loaded: form_helper
DEBUG - 2012-12-12 20:42:13 --> Form Validation Class Initialized
