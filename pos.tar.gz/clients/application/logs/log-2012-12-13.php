<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-12-13 17:04:17 --> Config Class Initialized
DEBUG - 2012-12-13 17:04:17 --> Hooks Class Initialized
DEBUG - 2012-12-13 17:04:17 --> Utf8 Class Initialized
DEBUG - 2012-12-13 17:04:17 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 17:04:17 --> URI Class Initialized
DEBUG - 2012-12-13 17:04:17 --> Router Class Initialized
DEBUG - 2012-12-13 17:04:17 --> Output Class Initialized
DEBUG - 2012-12-13 17:04:17 --> Security Class Initialized
DEBUG - 2012-12-13 17:04:17 --> Input Class Initialized
DEBUG - 2012-12-13 17:04:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 17:04:17 --> Language Class Initialized
DEBUG - 2012-12-13 17:04:17 --> Loader Class Initialized
DEBUG - 2012-12-13 17:04:17 --> Helper loaded: url_helper
DEBUG - 2012-12-13 17:04:17 --> Controller Class Initialized
DEBUG - 2012-12-13 17:04:17 --> Model Class Initialized
DEBUG - 2012-12-13 17:04:17 --> Database Driver Class Initialized
DEBUG - 2012-12-13 17:04:17 --> Helper loaded: form_helper
DEBUG - 2012-12-13 17:04:17 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-13 17:04:17 --> File loaded: application/views/admin/templates/top_menu.php
DEBUG - 2012-12-13 17:04:17 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-13 17:04:17 --> File loaded: application/views/admin/pages/business/business.php
DEBUG - 2012-12-13 17:04:17 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-13 17:04:17 --> Final output sent to browser
DEBUG - 2012-12-13 17:04:17 --> Total execution time: 0.1507
DEBUG - 2012-12-13 17:04:18 --> Config Class Initialized
DEBUG - 2012-12-13 17:04:18 --> Hooks Class Initialized
DEBUG - 2012-12-13 17:04:18 --> Utf8 Class Initialized
DEBUG - 2012-12-13 17:04:18 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 17:04:18 --> URI Class Initialized
DEBUG - 2012-12-13 17:04:18 --> Router Class Initialized
ERROR - 2012-12-13 17:04:18 --> 404 Page Not Found --> css
DEBUG - 2012-12-13 17:04:18 --> Config Class Initialized
DEBUG - 2012-12-13 17:04:18 --> Hooks Class Initialized
DEBUG - 2012-12-13 17:04:18 --> Utf8 Class Initialized
DEBUG - 2012-12-13 17:04:18 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 17:04:18 --> URI Class Initialized
DEBUG - 2012-12-13 17:04:18 --> Router Class Initialized
ERROR - 2012-12-13 17:04:18 --> 404 Page Not Found --> css
DEBUG - 2012-12-13 17:04:18 --> Config Class Initialized
DEBUG - 2012-12-13 17:04:18 --> Hooks Class Initialized
DEBUG - 2012-12-13 17:04:18 --> Utf8 Class Initialized
DEBUG - 2012-12-13 17:04:18 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 17:04:18 --> URI Class Initialized
DEBUG - 2012-12-13 17:04:18 --> Router Class Initialized
ERROR - 2012-12-13 17:04:18 --> 404 Page Not Found --> css
DEBUG - 2012-12-13 17:04:22 --> Config Class Initialized
DEBUG - 2012-12-13 17:04:22 --> Hooks Class Initialized
DEBUG - 2012-12-13 17:04:22 --> Utf8 Class Initialized
DEBUG - 2012-12-13 17:04:22 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 17:04:22 --> URI Class Initialized
DEBUG - 2012-12-13 17:04:22 --> Router Class Initialized
DEBUG - 2012-12-13 17:04:22 --> Output Class Initialized
DEBUG - 2012-12-13 17:04:22 --> Security Class Initialized
DEBUG - 2012-12-13 17:04:22 --> Input Class Initialized
DEBUG - 2012-12-13 17:04:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 17:04:22 --> Language Class Initialized
DEBUG - 2012-12-13 17:04:22 --> Loader Class Initialized
DEBUG - 2012-12-13 17:04:22 --> Helper loaded: url_helper
DEBUG - 2012-12-13 17:04:22 --> Controller Class Initialized
DEBUG - 2012-12-13 17:04:22 --> Model Class Initialized
DEBUG - 2012-12-13 17:04:22 --> Database Driver Class Initialized
DEBUG - 2012-12-13 17:04:22 --> Helper loaded: form_helper
DEBUG - 2012-12-13 17:04:22 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-13 17:04:22 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-13 17:04:22 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-13 17:04:22 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-13 17:04:22 --> Final output sent to browser
DEBUG - 2012-12-13 17:04:22 --> Total execution time: 0.0482
DEBUG - 2012-12-13 17:04:24 --> Config Class Initialized
DEBUG - 2012-12-13 17:04:24 --> Hooks Class Initialized
DEBUG - 2012-12-13 17:04:24 --> Utf8 Class Initialized
DEBUG - 2012-12-13 17:04:24 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 17:04:24 --> URI Class Initialized
DEBUG - 2012-12-13 17:04:24 --> Router Class Initialized
DEBUG - 2012-12-13 17:04:24 --> Output Class Initialized
DEBUG - 2012-12-13 17:04:24 --> Security Class Initialized
DEBUG - 2012-12-13 17:04:24 --> Input Class Initialized
DEBUG - 2012-12-13 17:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 17:04:24 --> Language Class Initialized
DEBUG - 2012-12-13 17:04:24 --> Loader Class Initialized
DEBUG - 2012-12-13 17:04:24 --> Helper loaded: url_helper
DEBUG - 2012-12-13 17:04:24 --> Controller Class Initialized
DEBUG - 2012-12-13 17:04:24 --> Model Class Initialized
DEBUG - 2012-12-13 17:04:24 --> Database Driver Class Initialized
DEBUG - 2012-12-13 17:04:24 --> Helper loaded: language_helper
DEBUG - 2012-12-13 17:04:24 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-13 17:04:24 --> Final output sent to browser
DEBUG - 2012-12-13 17:04:24 --> Total execution time: 0.0435
DEBUG - 2012-12-13 17:04:55 --> Config Class Initialized
DEBUG - 2012-12-13 17:04:55 --> Hooks Class Initialized
DEBUG - 2012-12-13 17:04:55 --> Utf8 Class Initialized
DEBUG - 2012-12-13 17:04:55 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 17:04:55 --> URI Class Initialized
DEBUG - 2012-12-13 17:04:55 --> Router Class Initialized
DEBUG - 2012-12-13 17:04:55 --> Output Class Initialized
DEBUG - 2012-12-13 17:04:55 --> Security Class Initialized
DEBUG - 2012-12-13 17:04:55 --> Input Class Initialized
DEBUG - 2012-12-13 17:04:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 17:04:55 --> Language Class Initialized
DEBUG - 2012-12-13 17:04:55 --> Loader Class Initialized
DEBUG - 2012-12-13 17:04:55 --> Helper loaded: url_helper
DEBUG - 2012-12-13 17:04:55 --> Controller Class Initialized
DEBUG - 2012-12-13 17:04:55 --> Model Class Initialized
DEBUG - 2012-12-13 17:04:55 --> Database Driver Class Initialized
DEBUG - 2012-12-13 17:04:55 --> Helper loaded: form_helper
DEBUG - 2012-12-13 17:04:55 --> Form Validation Class Initialized
DEBUG - 2012-12-13 17:09:05 --> Config Class Initialized
DEBUG - 2012-12-13 17:09:05 --> Hooks Class Initialized
DEBUG - 2012-12-13 17:09:05 --> Utf8 Class Initialized
DEBUG - 2012-12-13 17:09:05 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 17:09:05 --> URI Class Initialized
DEBUG - 2012-12-13 17:09:05 --> Router Class Initialized
DEBUG - 2012-12-13 17:09:05 --> Output Class Initialized
DEBUG - 2012-12-13 17:09:05 --> Security Class Initialized
DEBUG - 2012-12-13 17:09:05 --> Input Class Initialized
DEBUG - 2012-12-13 17:09:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 17:09:05 --> Language Class Initialized
DEBUG - 2012-12-13 17:09:05 --> Loader Class Initialized
DEBUG - 2012-12-13 17:09:05 --> Helper loaded: url_helper
DEBUG - 2012-12-13 17:09:05 --> Controller Class Initialized
DEBUG - 2012-12-13 17:09:05 --> Model Class Initialized
DEBUG - 2012-12-13 17:09:05 --> Database Driver Class Initialized
DEBUG - 2012-12-13 17:09:05 --> Helper loaded: language_helper
DEBUG - 2012-12-13 17:09:05 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-13 17:09:05 --> Final output sent to browser
DEBUG - 2012-12-13 17:09:05 --> Total execution time: 0.0604
DEBUG - 2012-12-13 17:09:32 --> Config Class Initialized
DEBUG - 2012-12-13 17:09:32 --> Hooks Class Initialized
DEBUG - 2012-12-13 17:09:32 --> Utf8 Class Initialized
DEBUG - 2012-12-13 17:09:32 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 17:09:32 --> URI Class Initialized
DEBUG - 2012-12-13 17:09:32 --> Router Class Initialized
DEBUG - 2012-12-13 17:09:32 --> Output Class Initialized
DEBUG - 2012-12-13 17:09:32 --> Security Class Initialized
DEBUG - 2012-12-13 17:09:32 --> Input Class Initialized
DEBUG - 2012-12-13 17:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 17:09:32 --> Language Class Initialized
DEBUG - 2012-12-13 17:09:32 --> Loader Class Initialized
DEBUG - 2012-12-13 17:09:32 --> Helper loaded: url_helper
DEBUG - 2012-12-13 17:09:32 --> Controller Class Initialized
DEBUG - 2012-12-13 17:09:32 --> Model Class Initialized
DEBUG - 2012-12-13 17:09:32 --> Database Driver Class Initialized
DEBUG - 2012-12-13 17:09:32 --> Helper loaded: form_helper
DEBUG - 2012-12-13 17:09:32 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-13 17:09:32 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-13 17:09:32 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-13 17:09:32 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-13 17:09:33 --> Final output sent to browser
DEBUG - 2012-12-13 17:09:33 --> Total execution time: 0.0688
DEBUG - 2012-12-13 17:09:34 --> Config Class Initialized
DEBUG - 2012-12-13 17:09:34 --> Hooks Class Initialized
DEBUG - 2012-12-13 17:09:34 --> Utf8 Class Initialized
DEBUG - 2012-12-13 17:09:34 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 17:09:34 --> URI Class Initialized
DEBUG - 2012-12-13 17:09:34 --> Router Class Initialized
ERROR - 2012-12-13 17:09:34 --> 404 Page Not Found --> css
DEBUG - 2012-12-13 17:09:34 --> Config Class Initialized
DEBUG - 2012-12-13 17:09:34 --> Hooks Class Initialized
DEBUG - 2012-12-13 17:09:34 --> Utf8 Class Initialized
DEBUG - 2012-12-13 17:09:34 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 17:09:34 --> URI Class Initialized
DEBUG - 2012-12-13 17:09:34 --> Router Class Initialized
ERROR - 2012-12-13 17:09:34 --> 404 Page Not Found --> css
DEBUG - 2012-12-13 17:09:34 --> Config Class Initialized
DEBUG - 2012-12-13 17:09:34 --> Hooks Class Initialized
DEBUG - 2012-12-13 17:09:34 --> Utf8 Class Initialized
DEBUG - 2012-12-13 17:09:34 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 17:09:34 --> URI Class Initialized
DEBUG - 2012-12-13 17:09:34 --> Router Class Initialized
ERROR - 2012-12-13 17:09:34 --> 404 Page Not Found --> css
DEBUG - 2012-12-13 17:09:40 --> Config Class Initialized
DEBUG - 2012-12-13 17:09:40 --> Hooks Class Initialized
DEBUG - 2012-12-13 17:09:40 --> Utf8 Class Initialized
DEBUG - 2012-12-13 17:09:40 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 17:09:40 --> URI Class Initialized
DEBUG - 2012-12-13 17:09:40 --> Router Class Initialized
DEBUG - 2012-12-13 17:09:40 --> Output Class Initialized
DEBUG - 2012-12-13 17:09:40 --> Security Class Initialized
DEBUG - 2012-12-13 17:09:40 --> Input Class Initialized
DEBUG - 2012-12-13 17:09:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 17:09:40 --> Language Class Initialized
DEBUG - 2012-12-13 17:09:40 --> Loader Class Initialized
DEBUG - 2012-12-13 17:09:40 --> Helper loaded: url_helper
DEBUG - 2012-12-13 17:09:40 --> Controller Class Initialized
DEBUG - 2012-12-13 17:09:40 --> Model Class Initialized
DEBUG - 2012-12-13 17:09:40 --> Database Driver Class Initialized
DEBUG - 2012-12-13 17:09:40 --> Helper loaded: language_helper
DEBUG - 2012-12-13 17:09:40 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-13 17:09:40 --> Final output sent to browser
DEBUG - 2012-12-13 17:09:40 --> Total execution time: 0.0482
DEBUG - 2012-12-13 17:09:44 --> Config Class Initialized
DEBUG - 2012-12-13 17:09:44 --> Hooks Class Initialized
DEBUG - 2012-12-13 17:09:44 --> Utf8 Class Initialized
DEBUG - 2012-12-13 17:09:44 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 17:09:44 --> URI Class Initialized
DEBUG - 2012-12-13 17:09:44 --> Router Class Initialized
DEBUG - 2012-12-13 17:09:44 --> Output Class Initialized
DEBUG - 2012-12-13 17:09:44 --> Security Class Initialized
DEBUG - 2012-12-13 17:09:44 --> Input Class Initialized
DEBUG - 2012-12-13 17:09:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 17:09:44 --> Language Class Initialized
DEBUG - 2012-12-13 17:09:44 --> Loader Class Initialized
DEBUG - 2012-12-13 17:09:44 --> Helper loaded: url_helper
DEBUG - 2012-12-13 17:09:44 --> Controller Class Initialized
DEBUG - 2012-12-13 17:09:44 --> Model Class Initialized
DEBUG - 2012-12-13 17:09:44 --> Database Driver Class Initialized
DEBUG - 2012-12-13 17:09:44 --> Helper loaded: form_helper
DEBUG - 2012-12-13 17:09:44 --> Form Validation Class Initialized
DEBUG - 2012-12-13 22:52:07 --> Config Class Initialized
DEBUG - 2012-12-13 22:52:07 --> Hooks Class Initialized
DEBUG - 2012-12-13 22:52:07 --> Utf8 Class Initialized
DEBUG - 2012-12-13 22:52:07 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 22:52:07 --> URI Class Initialized
DEBUG - 2012-12-13 22:52:07 --> Router Class Initialized
DEBUG - 2012-12-13 22:52:07 --> Output Class Initialized
DEBUG - 2012-12-13 22:52:07 --> Security Class Initialized
DEBUG - 2012-12-13 22:52:07 --> Input Class Initialized
DEBUG - 2012-12-13 22:52:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 22:52:07 --> Language Class Initialized
DEBUG - 2012-12-13 22:52:07 --> Loader Class Initialized
DEBUG - 2012-12-13 22:52:07 --> Helper loaded: url_helper
DEBUG - 2012-12-13 22:52:07 --> Controller Class Initialized
DEBUG - 2012-12-13 22:52:07 --> Model Class Initialized
DEBUG - 2012-12-13 22:52:07 --> Database Driver Class Initialized
DEBUG - 2012-12-13 22:52:07 --> Helper loaded: form_helper
DEBUG - 2012-12-13 22:52:07 --> Form Validation Class Initialized
DEBUG - 2012-12-13 23:19:09 --> Config Class Initialized
DEBUG - 2012-12-13 23:19:09 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:19:09 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:19:09 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:19:09 --> URI Class Initialized
DEBUG - 2012-12-13 23:19:09 --> Router Class Initialized
DEBUG - 2012-12-13 23:19:09 --> Output Class Initialized
DEBUG - 2012-12-13 23:19:09 --> Security Class Initialized
DEBUG - 2012-12-13 23:19:09 --> Input Class Initialized
DEBUG - 2012-12-13 23:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:19:09 --> Language Class Initialized
DEBUG - 2012-12-13 23:19:09 --> Loader Class Initialized
DEBUG - 2012-12-13 23:19:09 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:19:09 --> Controller Class Initialized
DEBUG - 2012-12-13 23:19:09 --> Model Class Initialized
DEBUG - 2012-12-13 23:19:09 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:20:58 --> Config Class Initialized
DEBUG - 2012-12-13 23:20:58 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:20:58 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:20:58 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:20:58 --> URI Class Initialized
DEBUG - 2012-12-13 23:20:58 --> Router Class Initialized
DEBUG - 2012-12-13 23:20:58 --> Output Class Initialized
DEBUG - 2012-12-13 23:20:58 --> Security Class Initialized
DEBUG - 2012-12-13 23:20:58 --> Input Class Initialized
DEBUG - 2012-12-13 23:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:20:58 --> Language Class Initialized
DEBUG - 2012-12-13 23:20:58 --> Loader Class Initialized
DEBUG - 2012-12-13 23:20:58 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:20:58 --> Controller Class Initialized
DEBUG - 2012-12-13 23:20:58 --> Model Class Initialized
DEBUG - 2012-12-13 23:20:58 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:20:58 --> Helper loaded: form_helper
DEBUG - 2012-12-13 23:20:58 --> Form Validation Class Initialized
DEBUG - 2012-12-13 23:22:28 --> Config Class Initialized
DEBUG - 2012-12-13 23:22:28 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:22:28 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:22:28 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:22:28 --> URI Class Initialized
DEBUG - 2012-12-13 23:22:28 --> Router Class Initialized
DEBUG - 2012-12-13 23:22:28 --> Output Class Initialized
DEBUG - 2012-12-13 23:22:28 --> Security Class Initialized
DEBUG - 2012-12-13 23:22:28 --> Input Class Initialized
DEBUG - 2012-12-13 23:22:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:22:28 --> Language Class Initialized
DEBUG - 2012-12-13 23:22:28 --> Loader Class Initialized
DEBUG - 2012-12-13 23:22:28 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:22:28 --> Controller Class Initialized
DEBUG - 2012-12-13 23:22:28 --> Model Class Initialized
DEBUG - 2012-12-13 23:22:28 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:22:28 --> Helper loaded: form_helper
DEBUG - 2012-12-13 23:22:28 --> Form Validation Class Initialized
ERROR - 2012-12-13 23:22:28 --> Severity: Notice  --> Use of undefined constant exxit - assumed 'exxit' /home/jwp/www/justinwylliephotography.com/clients/application/models/pricing_model.php 303
DEBUG - 2012-12-13 23:23:51 --> Config Class Initialized
DEBUG - 2012-12-13 23:23:51 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:23:51 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:23:51 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:23:51 --> URI Class Initialized
DEBUG - 2012-12-13 23:23:51 --> Router Class Initialized
DEBUG - 2012-12-13 23:23:51 --> Output Class Initialized
DEBUG - 2012-12-13 23:23:51 --> Security Class Initialized
DEBUG - 2012-12-13 23:23:51 --> Input Class Initialized
DEBUG - 2012-12-13 23:23:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:23:51 --> Language Class Initialized
DEBUG - 2012-12-13 23:23:51 --> Loader Class Initialized
DEBUG - 2012-12-13 23:23:51 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:23:51 --> Controller Class Initialized
DEBUG - 2012-12-13 23:23:51 --> Model Class Initialized
DEBUG - 2012-12-13 23:23:51 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:23:51 --> Helper loaded: language_helper
DEBUG - 2012-12-13 23:23:51 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-13 23:23:51 --> Final output sent to browser
DEBUG - 2012-12-13 23:23:51 --> Total execution time: 0.0404
DEBUG - 2012-12-13 23:23:56 --> Config Class Initialized
DEBUG - 2012-12-13 23:23:56 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:23:56 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:23:56 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:23:56 --> URI Class Initialized
DEBUG - 2012-12-13 23:23:56 --> Router Class Initialized
DEBUG - 2012-12-13 23:23:56 --> Output Class Initialized
DEBUG - 2012-12-13 23:23:56 --> Security Class Initialized
DEBUG - 2012-12-13 23:23:56 --> Input Class Initialized
DEBUG - 2012-12-13 23:23:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:23:56 --> Language Class Initialized
DEBUG - 2012-12-13 23:23:56 --> Loader Class Initialized
DEBUG - 2012-12-13 23:23:56 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:23:56 --> Controller Class Initialized
DEBUG - 2012-12-13 23:23:56 --> Model Class Initialized
DEBUG - 2012-12-13 23:23:56 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:23:56 --> Helper loaded: form_helper
DEBUG - 2012-12-13 23:23:56 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-13 23:23:56 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-13 23:23:56 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-13 23:23:56 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-13 23:23:56 --> Final output sent to browser
DEBUG - 2012-12-13 23:23:56 --> Total execution time: 0.0439
DEBUG - 2012-12-13 23:23:58 --> Config Class Initialized
DEBUG - 2012-12-13 23:23:58 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:23:58 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:23:58 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:23:58 --> URI Class Initialized
DEBUG - 2012-12-13 23:23:58 --> Router Class Initialized
ERROR - 2012-12-13 23:23:58 --> 404 Page Not Found --> css
DEBUG - 2012-12-13 23:23:58 --> Config Class Initialized
DEBUG - 2012-12-13 23:23:58 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:23:58 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:23:58 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:23:58 --> URI Class Initialized
DEBUG - 2012-12-13 23:23:58 --> Router Class Initialized
ERROR - 2012-12-13 23:23:58 --> 404 Page Not Found --> css
DEBUG - 2012-12-13 23:23:58 --> Config Class Initialized
DEBUG - 2012-12-13 23:23:58 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:23:58 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:23:58 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:23:58 --> URI Class Initialized
DEBUG - 2012-12-13 23:23:58 --> Router Class Initialized
ERROR - 2012-12-13 23:23:58 --> 404 Page Not Found --> css
DEBUG - 2012-12-13 23:24:17 --> Config Class Initialized
DEBUG - 2012-12-13 23:24:17 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:24:17 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:24:17 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:24:17 --> URI Class Initialized
DEBUG - 2012-12-13 23:24:17 --> Router Class Initialized
DEBUG - 2012-12-13 23:24:17 --> Output Class Initialized
DEBUG - 2012-12-13 23:24:17 --> Security Class Initialized
DEBUG - 2012-12-13 23:24:17 --> Input Class Initialized
DEBUG - 2012-12-13 23:24:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:24:17 --> Language Class Initialized
DEBUG - 2012-12-13 23:24:17 --> Loader Class Initialized
DEBUG - 2012-12-13 23:24:17 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:24:17 --> Controller Class Initialized
DEBUG - 2012-12-13 23:24:17 --> Model Class Initialized
DEBUG - 2012-12-13 23:24:17 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:24:17 --> Helper loaded: language_helper
DEBUG - 2012-12-13 23:24:17 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-13 23:24:17 --> Final output sent to browser
DEBUG - 2012-12-13 23:24:17 --> Total execution time: 0.0445
DEBUG - 2012-12-13 23:24:25 --> Config Class Initialized
DEBUG - 2012-12-13 23:24:25 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:24:25 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:24:25 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:24:25 --> URI Class Initialized
DEBUG - 2012-12-13 23:24:25 --> Router Class Initialized
DEBUG - 2012-12-13 23:24:25 --> Output Class Initialized
DEBUG - 2012-12-13 23:24:25 --> Security Class Initialized
DEBUG - 2012-12-13 23:24:25 --> Input Class Initialized
DEBUG - 2012-12-13 23:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:24:25 --> Language Class Initialized
DEBUG - 2012-12-13 23:24:25 --> Loader Class Initialized
DEBUG - 2012-12-13 23:24:25 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:24:25 --> Controller Class Initialized
DEBUG - 2012-12-13 23:24:25 --> Model Class Initialized
DEBUG - 2012-12-13 23:24:25 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:24:25 --> Helper loaded: form_helper
DEBUG - 2012-12-13 23:24:25 --> Form Validation Class Initialized
DEBUG - 2012-12-13 23:24:48 --> Config Class Initialized
DEBUG - 2012-12-13 23:24:48 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:24:48 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:24:48 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:24:48 --> URI Class Initialized
DEBUG - 2012-12-13 23:24:48 --> Router Class Initialized
DEBUG - 2012-12-13 23:24:48 --> Output Class Initialized
DEBUG - 2012-12-13 23:24:48 --> Security Class Initialized
DEBUG - 2012-12-13 23:24:48 --> Input Class Initialized
DEBUG - 2012-12-13 23:24:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:24:48 --> Language Class Initialized
DEBUG - 2012-12-13 23:24:48 --> Loader Class Initialized
DEBUG - 2012-12-13 23:24:48 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:24:48 --> Controller Class Initialized
DEBUG - 2012-12-13 23:24:48 --> Model Class Initialized
DEBUG - 2012-12-13 23:24:48 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:24:48 --> Helper loaded: form_helper
DEBUG - 2012-12-13 23:24:48 --> Form Validation Class Initialized
DEBUG - 2012-12-13 23:26:55 --> Config Class Initialized
DEBUG - 2012-12-13 23:26:55 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:26:55 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:26:55 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:26:55 --> URI Class Initialized
DEBUG - 2012-12-13 23:26:55 --> Router Class Initialized
DEBUG - 2012-12-13 23:26:55 --> Output Class Initialized
DEBUG - 2012-12-13 23:26:55 --> Security Class Initialized
DEBUG - 2012-12-13 23:26:55 --> Input Class Initialized
DEBUG - 2012-12-13 23:26:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:26:55 --> Language Class Initialized
DEBUG - 2012-12-13 23:26:55 --> Loader Class Initialized
DEBUG - 2012-12-13 23:26:55 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:26:55 --> Controller Class Initialized
DEBUG - 2012-12-13 23:26:55 --> Model Class Initialized
DEBUG - 2012-12-13 23:26:55 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:26:55 --> Helper loaded: form_helper
DEBUG - 2012-12-13 23:26:55 --> Form Validation Class Initialized
DEBUG - 2012-12-13 23:29:24 --> Config Class Initialized
DEBUG - 2012-12-13 23:29:24 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:29:24 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:29:24 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:29:24 --> URI Class Initialized
DEBUG - 2012-12-13 23:29:24 --> Router Class Initialized
DEBUG - 2012-12-13 23:29:24 --> Output Class Initialized
DEBUG - 2012-12-13 23:29:24 --> Security Class Initialized
DEBUG - 2012-12-13 23:29:24 --> Input Class Initialized
DEBUG - 2012-12-13 23:29:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:29:24 --> Language Class Initialized
DEBUG - 2012-12-13 23:29:24 --> Loader Class Initialized
DEBUG - 2012-12-13 23:29:24 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:29:24 --> Controller Class Initialized
DEBUG - 2012-12-13 23:29:24 --> Model Class Initialized
DEBUG - 2012-12-13 23:29:24 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:29:24 --> Helper loaded: form_helper
DEBUG - 2012-12-13 23:29:24 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-13 23:29:24 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-13 23:29:24 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-13 23:29:24 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-13 23:29:24 --> Final output sent to browser
DEBUG - 2012-12-13 23:29:24 --> Total execution time: 0.0444
DEBUG - 2012-12-13 23:29:26 --> Config Class Initialized
DEBUG - 2012-12-13 23:29:26 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:29:26 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:29:26 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:29:26 --> URI Class Initialized
DEBUG - 2012-12-13 23:29:26 --> Router Class Initialized
ERROR - 2012-12-13 23:29:26 --> 404 Page Not Found --> css
DEBUG - 2012-12-13 23:29:26 --> Config Class Initialized
DEBUG - 2012-12-13 23:29:26 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:29:26 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:29:26 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:29:26 --> URI Class Initialized
DEBUG - 2012-12-13 23:29:26 --> Router Class Initialized
ERROR - 2012-12-13 23:29:26 --> 404 Page Not Found --> css
DEBUG - 2012-12-13 23:29:26 --> Config Class Initialized
DEBUG - 2012-12-13 23:29:26 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:29:26 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:29:26 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:29:26 --> URI Class Initialized
DEBUG - 2012-12-13 23:29:26 --> Router Class Initialized
ERROR - 2012-12-13 23:29:26 --> 404 Page Not Found --> css
DEBUG - 2012-12-13 23:29:27 --> Config Class Initialized
DEBUG - 2012-12-13 23:29:27 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:29:27 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:29:27 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:29:27 --> URI Class Initialized
DEBUG - 2012-12-13 23:29:27 --> Router Class Initialized
DEBUG - 2012-12-13 23:29:27 --> Output Class Initialized
DEBUG - 2012-12-13 23:29:27 --> Security Class Initialized
DEBUG - 2012-12-13 23:29:27 --> Input Class Initialized
DEBUG - 2012-12-13 23:29:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:29:27 --> Language Class Initialized
DEBUG - 2012-12-13 23:29:27 --> Loader Class Initialized
DEBUG - 2012-12-13 23:29:27 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:29:27 --> Controller Class Initialized
DEBUG - 2012-12-13 23:29:27 --> Model Class Initialized
DEBUG - 2012-12-13 23:29:27 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:29:27 --> Helper loaded: language_helper
DEBUG - 2012-12-13 23:29:27 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-13 23:29:27 --> Final output sent to browser
DEBUG - 2012-12-13 23:29:27 --> Total execution time: 0.0636
DEBUG - 2012-12-13 23:29:30 --> Config Class Initialized
DEBUG - 2012-12-13 23:29:30 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:29:30 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:29:30 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:29:30 --> URI Class Initialized
DEBUG - 2012-12-13 23:29:30 --> Router Class Initialized
DEBUG - 2012-12-13 23:29:30 --> Output Class Initialized
DEBUG - 2012-12-13 23:29:30 --> Security Class Initialized
DEBUG - 2012-12-13 23:29:30 --> Input Class Initialized
DEBUG - 2012-12-13 23:29:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:29:30 --> Language Class Initialized
DEBUG - 2012-12-13 23:29:30 --> Loader Class Initialized
DEBUG - 2012-12-13 23:29:30 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:29:30 --> Controller Class Initialized
DEBUG - 2012-12-13 23:29:30 --> Model Class Initialized
DEBUG - 2012-12-13 23:29:30 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:29:30 --> Helper loaded: language_helper
DEBUG - 2012-12-13 23:29:30 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-13 23:29:30 --> Final output sent to browser
DEBUG - 2012-12-13 23:29:30 --> Total execution time: 0.0438
DEBUG - 2012-12-13 23:29:38 --> Config Class Initialized
DEBUG - 2012-12-13 23:29:38 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:29:38 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:29:38 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:29:38 --> URI Class Initialized
DEBUG - 2012-12-13 23:29:38 --> Router Class Initialized
DEBUG - 2012-12-13 23:29:38 --> Output Class Initialized
DEBUG - 2012-12-13 23:29:38 --> Security Class Initialized
DEBUG - 2012-12-13 23:29:38 --> Input Class Initialized
DEBUG - 2012-12-13 23:29:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:29:38 --> Language Class Initialized
DEBUG - 2012-12-13 23:29:38 --> Loader Class Initialized
DEBUG - 2012-12-13 23:29:38 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:29:38 --> Controller Class Initialized
DEBUG - 2012-12-13 23:29:38 --> Model Class Initialized
DEBUG - 2012-12-13 23:29:38 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:29:38 --> Helper loaded: form_helper
DEBUG - 2012-12-13 23:29:38 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-13 23:29:38 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-13 23:29:38 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-13 23:29:38 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-13 23:29:38 --> Final output sent to browser
DEBUG - 2012-12-13 23:29:38 --> Total execution time: 0.0443
DEBUG - 2012-12-13 23:29:40 --> Config Class Initialized
DEBUG - 2012-12-13 23:29:40 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:29:40 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:29:40 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:29:40 --> URI Class Initialized
DEBUG - 2012-12-13 23:29:40 --> Router Class Initialized
ERROR - 2012-12-13 23:29:40 --> 404 Page Not Found --> css
DEBUG - 2012-12-13 23:29:40 --> Config Class Initialized
DEBUG - 2012-12-13 23:29:40 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:29:40 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:29:40 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:29:40 --> URI Class Initialized
DEBUG - 2012-12-13 23:29:40 --> Router Class Initialized
ERROR - 2012-12-13 23:29:40 --> 404 Page Not Found --> css
DEBUG - 2012-12-13 23:29:40 --> Config Class Initialized
DEBUG - 2012-12-13 23:29:40 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:29:40 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:29:40 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:29:40 --> URI Class Initialized
DEBUG - 2012-12-13 23:29:40 --> Router Class Initialized
ERROR - 2012-12-13 23:29:40 --> 404 Page Not Found --> css
DEBUG - 2012-12-13 23:29:42 --> Config Class Initialized
DEBUG - 2012-12-13 23:29:42 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:29:42 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:29:42 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:29:42 --> URI Class Initialized
DEBUG - 2012-12-13 23:29:42 --> Router Class Initialized
DEBUG - 2012-12-13 23:29:42 --> Output Class Initialized
DEBUG - 2012-12-13 23:29:42 --> Security Class Initialized
DEBUG - 2012-12-13 23:29:42 --> Input Class Initialized
DEBUG - 2012-12-13 23:29:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:29:42 --> Language Class Initialized
DEBUG - 2012-12-13 23:29:42 --> Loader Class Initialized
DEBUG - 2012-12-13 23:29:42 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:29:42 --> Controller Class Initialized
DEBUG - 2012-12-13 23:29:42 --> Model Class Initialized
DEBUG - 2012-12-13 23:29:42 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:29:42 --> Helper loaded: language_helper
DEBUG - 2012-12-13 23:29:42 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-13 23:29:42 --> Final output sent to browser
DEBUG - 2012-12-13 23:29:42 --> Total execution time: 0.0416
DEBUG - 2012-12-13 23:30:00 --> Config Class Initialized
DEBUG - 2012-12-13 23:30:00 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:30:00 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:30:00 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:30:00 --> URI Class Initialized
DEBUG - 2012-12-13 23:30:00 --> Router Class Initialized
DEBUG - 2012-12-13 23:30:00 --> Output Class Initialized
DEBUG - 2012-12-13 23:30:00 --> Security Class Initialized
DEBUG - 2012-12-13 23:30:00 --> Input Class Initialized
DEBUG - 2012-12-13 23:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:30:00 --> Language Class Initialized
DEBUG - 2012-12-13 23:30:00 --> Loader Class Initialized
DEBUG - 2012-12-13 23:30:00 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:30:00 --> Controller Class Initialized
DEBUG - 2012-12-13 23:30:00 --> Model Class Initialized
DEBUG - 2012-12-13 23:30:00 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:30:00 --> Helper loaded: form_helper
DEBUG - 2012-12-13 23:30:00 --> Form Validation Class Initialized
DEBUG - 2012-12-13 23:30:52 --> Config Class Initialized
DEBUG - 2012-12-13 23:30:52 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:30:52 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:30:52 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:30:52 --> URI Class Initialized
DEBUG - 2012-12-13 23:30:52 --> Router Class Initialized
DEBUG - 2012-12-13 23:30:52 --> Output Class Initialized
DEBUG - 2012-12-13 23:30:52 --> Security Class Initialized
DEBUG - 2012-12-13 23:30:52 --> Input Class Initialized
DEBUG - 2012-12-13 23:30:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:30:52 --> Language Class Initialized
DEBUG - 2012-12-13 23:30:52 --> Loader Class Initialized
DEBUG - 2012-12-13 23:30:52 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:30:52 --> Controller Class Initialized
DEBUG - 2012-12-13 23:30:52 --> Model Class Initialized
DEBUG - 2012-12-13 23:30:52 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:30:52 --> Helper loaded: form_helper
DEBUG - 2012-12-13 23:30:52 --> Form Validation Class Initialized
DEBUG - 2012-12-13 23:33:44 --> Config Class Initialized
DEBUG - 2012-12-13 23:33:44 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:33:44 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:33:44 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:33:44 --> URI Class Initialized
DEBUG - 2012-12-13 23:33:44 --> Router Class Initialized
DEBUG - 2012-12-13 23:33:44 --> Output Class Initialized
DEBUG - 2012-12-13 23:33:44 --> Security Class Initialized
DEBUG - 2012-12-13 23:33:44 --> Input Class Initialized
DEBUG - 2012-12-13 23:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:33:44 --> Language Class Initialized
DEBUG - 2012-12-13 23:33:44 --> Loader Class Initialized
DEBUG - 2012-12-13 23:33:44 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:33:44 --> Controller Class Initialized
DEBUG - 2012-12-13 23:33:44 --> Model Class Initialized
DEBUG - 2012-12-13 23:33:44 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:33:44 --> Helper loaded: form_helper
DEBUG - 2012-12-13 23:33:44 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-13 23:33:44 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-13 23:33:44 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-13 23:33:44 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-13 23:33:44 --> Final output sent to browser
DEBUG - 2012-12-13 23:33:44 --> Total execution time: 0.0448
DEBUG - 2012-12-13 23:33:46 --> Config Class Initialized
DEBUG - 2012-12-13 23:33:46 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:33:46 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:33:46 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:33:46 --> URI Class Initialized
DEBUG - 2012-12-13 23:33:46 --> Router Class Initialized
ERROR - 2012-12-13 23:33:46 --> 404 Page Not Found --> css
DEBUG - 2012-12-13 23:33:46 --> Config Class Initialized
DEBUG - 2012-12-13 23:33:46 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:33:46 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:33:46 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:33:46 --> URI Class Initialized
DEBUG - 2012-12-13 23:33:46 --> Router Class Initialized
ERROR - 2012-12-13 23:33:46 --> 404 Page Not Found --> css
DEBUG - 2012-12-13 23:33:46 --> Config Class Initialized
DEBUG - 2012-12-13 23:33:46 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:33:46 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:33:46 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:33:46 --> URI Class Initialized
DEBUG - 2012-12-13 23:33:46 --> Router Class Initialized
ERROR - 2012-12-13 23:33:46 --> 404 Page Not Found --> css
DEBUG - 2012-12-13 23:33:47 --> Config Class Initialized
DEBUG - 2012-12-13 23:33:47 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:33:47 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:33:47 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:33:47 --> URI Class Initialized
DEBUG - 2012-12-13 23:33:47 --> Router Class Initialized
DEBUG - 2012-12-13 23:33:47 --> Output Class Initialized
DEBUG - 2012-12-13 23:33:47 --> Security Class Initialized
DEBUG - 2012-12-13 23:33:47 --> Input Class Initialized
DEBUG - 2012-12-13 23:33:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:33:47 --> Language Class Initialized
DEBUG - 2012-12-13 23:33:47 --> Loader Class Initialized
DEBUG - 2012-12-13 23:33:47 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:33:47 --> Controller Class Initialized
DEBUG - 2012-12-13 23:33:47 --> Model Class Initialized
DEBUG - 2012-12-13 23:33:47 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:33:47 --> Helper loaded: language_helper
DEBUG - 2012-12-13 23:33:47 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-13 23:33:47 --> Final output sent to browser
DEBUG - 2012-12-13 23:33:47 --> Total execution time: 0.0458
DEBUG - 2012-12-13 23:33:50 --> Config Class Initialized
DEBUG - 2012-12-13 23:33:50 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:33:50 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:33:50 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:33:50 --> URI Class Initialized
DEBUG - 2012-12-13 23:33:50 --> Router Class Initialized
DEBUG - 2012-12-13 23:33:50 --> Output Class Initialized
DEBUG - 2012-12-13 23:33:50 --> Security Class Initialized
DEBUG - 2012-12-13 23:33:50 --> Input Class Initialized
DEBUG - 2012-12-13 23:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:33:50 --> Language Class Initialized
DEBUG - 2012-12-13 23:33:50 --> Loader Class Initialized
DEBUG - 2012-12-13 23:33:50 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:33:50 --> Controller Class Initialized
DEBUG - 2012-12-13 23:33:50 --> Model Class Initialized
DEBUG - 2012-12-13 23:33:50 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:33:50 --> Helper loaded: form_helper
DEBUG - 2012-12-13 23:33:50 --> File loaded: application/views/admin/templates/header.php
DEBUG - 2012-12-13 23:33:50 --> File loaded: application/views/admin/templates/left_menu.php
DEBUG - 2012-12-13 23:33:50 --> File loaded: application/views/admin/pages/pricing/prints.php
DEBUG - 2012-12-13 23:33:50 --> File loaded: application/views/admin/templates/footer.php
DEBUG - 2012-12-13 23:33:50 --> Final output sent to browser
DEBUG - 2012-12-13 23:33:50 --> Total execution time: 0.0457
DEBUG - 2012-12-13 23:33:52 --> Config Class Initialized
DEBUG - 2012-12-13 23:33:52 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:33:52 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:33:52 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:33:52 --> URI Class Initialized
DEBUG - 2012-12-13 23:33:52 --> Router Class Initialized
ERROR - 2012-12-13 23:33:52 --> 404 Page Not Found --> css
DEBUG - 2012-12-13 23:33:52 --> Config Class Initialized
DEBUG - 2012-12-13 23:33:52 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:33:52 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:33:52 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:33:52 --> URI Class Initialized
DEBUG - 2012-12-13 23:33:52 --> Router Class Initialized
ERROR - 2012-12-13 23:33:52 --> 404 Page Not Found --> css
DEBUG - 2012-12-13 23:33:52 --> Config Class Initialized
DEBUG - 2012-12-13 23:33:52 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:33:52 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:33:52 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:33:52 --> URI Class Initialized
DEBUG - 2012-12-13 23:33:52 --> Router Class Initialized
ERROR - 2012-12-13 23:33:52 --> 404 Page Not Found --> css
DEBUG - 2012-12-13 23:33:54 --> Config Class Initialized
DEBUG - 2012-12-13 23:33:54 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:33:54 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:33:54 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:33:54 --> URI Class Initialized
DEBUG - 2012-12-13 23:33:54 --> Router Class Initialized
DEBUG - 2012-12-13 23:33:54 --> Output Class Initialized
DEBUG - 2012-12-13 23:33:54 --> Security Class Initialized
DEBUG - 2012-12-13 23:33:54 --> Input Class Initialized
DEBUG - 2012-12-13 23:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:33:54 --> Language Class Initialized
DEBUG - 2012-12-13 23:33:54 --> Loader Class Initialized
DEBUG - 2012-12-13 23:33:54 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:33:54 --> Controller Class Initialized
DEBUG - 2012-12-13 23:33:54 --> Model Class Initialized
DEBUG - 2012-12-13 23:33:54 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:33:54 --> Helper loaded: language_helper
DEBUG - 2012-12-13 23:33:54 --> Language file loaded: language/english/message_lang.php
DEBUG - 2012-12-13 23:33:54 --> Final output sent to browser
DEBUG - 2012-12-13 23:33:54 --> Total execution time: 0.0400
DEBUG - 2012-12-13 23:34:11 --> Config Class Initialized
DEBUG - 2012-12-13 23:34:11 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:34:11 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:34:11 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:34:11 --> URI Class Initialized
DEBUG - 2012-12-13 23:34:11 --> Router Class Initialized
DEBUG - 2012-12-13 23:34:11 --> Output Class Initialized
DEBUG - 2012-12-13 23:34:11 --> Security Class Initialized
DEBUG - 2012-12-13 23:34:11 --> Input Class Initialized
DEBUG - 2012-12-13 23:34:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:34:11 --> Language Class Initialized
DEBUG - 2012-12-13 23:34:11 --> Loader Class Initialized
DEBUG - 2012-12-13 23:34:11 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:34:11 --> Controller Class Initialized
DEBUG - 2012-12-13 23:34:11 --> Model Class Initialized
DEBUG - 2012-12-13 23:34:11 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:34:11 --> Helper loaded: form_helper
DEBUG - 2012-12-13 23:34:11 --> Form Validation Class Initialized
DEBUG - 2012-12-13 23:34:38 --> Config Class Initialized
DEBUG - 2012-12-13 23:34:38 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:34:38 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:34:38 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:34:38 --> URI Class Initialized
DEBUG - 2012-12-13 23:34:38 --> Router Class Initialized
DEBUG - 2012-12-13 23:34:38 --> Output Class Initialized
DEBUG - 2012-12-13 23:34:38 --> Security Class Initialized
DEBUG - 2012-12-13 23:34:38 --> Input Class Initialized
DEBUG - 2012-12-13 23:34:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:34:38 --> Language Class Initialized
DEBUG - 2012-12-13 23:34:38 --> Loader Class Initialized
DEBUG - 2012-12-13 23:34:38 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:34:38 --> Controller Class Initialized
DEBUG - 2012-12-13 23:34:38 --> Model Class Initialized
DEBUG - 2012-12-13 23:34:38 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:34:38 --> Helper loaded: form_helper
DEBUG - 2012-12-13 23:34:38 --> Form Validation Class Initialized
DEBUG - 2012-12-13 23:41:20 --> Config Class Initialized
DEBUG - 2012-12-13 23:41:20 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:41:20 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:41:20 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:41:20 --> URI Class Initialized
DEBUG - 2012-12-13 23:41:20 --> Router Class Initialized
DEBUG - 2012-12-13 23:41:20 --> Output Class Initialized
DEBUG - 2012-12-13 23:41:20 --> Security Class Initialized
DEBUG - 2012-12-13 23:41:20 --> Input Class Initialized
DEBUG - 2012-12-13 23:41:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:41:20 --> Language Class Initialized
DEBUG - 2012-12-13 23:41:20 --> Loader Class Initialized
DEBUG - 2012-12-13 23:41:20 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:41:20 --> Controller Class Initialized
DEBUG - 2012-12-13 23:41:20 --> Model Class Initialized
DEBUG - 2012-12-13 23:41:20 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:41:20 --> Helper loaded: form_helper
DEBUG - 2012-12-13 23:41:20 --> Form Validation Class Initialized
DEBUG - 2012-12-13 23:41:36 --> Config Class Initialized
DEBUG - 2012-12-13 23:41:36 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:41:36 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:41:36 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:41:36 --> URI Class Initialized
DEBUG - 2012-12-13 23:41:36 --> Router Class Initialized
DEBUG - 2012-12-13 23:41:36 --> Output Class Initialized
DEBUG - 2012-12-13 23:41:36 --> Security Class Initialized
DEBUG - 2012-12-13 23:41:36 --> Input Class Initialized
DEBUG - 2012-12-13 23:41:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:41:36 --> Language Class Initialized
DEBUG - 2012-12-13 23:41:36 --> Loader Class Initialized
DEBUG - 2012-12-13 23:41:36 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:41:36 --> Controller Class Initialized
DEBUG - 2012-12-13 23:41:36 --> Model Class Initialized
DEBUG - 2012-12-13 23:41:36 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:41:36 --> Helper loaded: form_helper
DEBUG - 2012-12-13 23:41:36 --> Form Validation Class Initialized
DEBUG - 2012-12-13 23:42:16 --> Config Class Initialized
DEBUG - 2012-12-13 23:42:16 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:42:16 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:42:16 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:42:16 --> URI Class Initialized
DEBUG - 2012-12-13 23:42:16 --> Router Class Initialized
DEBUG - 2012-12-13 23:42:16 --> Output Class Initialized
DEBUG - 2012-12-13 23:42:16 --> Security Class Initialized
DEBUG - 2012-12-13 23:42:16 --> Input Class Initialized
DEBUG - 2012-12-13 23:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:42:16 --> Language Class Initialized
DEBUG - 2012-12-13 23:42:16 --> Loader Class Initialized
DEBUG - 2012-12-13 23:42:16 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:42:16 --> Controller Class Initialized
DEBUG - 2012-12-13 23:42:16 --> Model Class Initialized
DEBUG - 2012-12-13 23:42:16 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:42:16 --> Helper loaded: form_helper
DEBUG - 2012-12-13 23:42:16 --> Form Validation Class Initialized
DEBUG - 2012-12-13 23:42:57 --> Config Class Initialized
DEBUG - 2012-12-13 23:42:57 --> Hooks Class Initialized
DEBUG - 2012-12-13 23:42:57 --> Utf8 Class Initialized
DEBUG - 2012-12-13 23:42:57 --> UTF-8 Support Enabled
DEBUG - 2012-12-13 23:42:57 --> URI Class Initialized
DEBUG - 2012-12-13 23:42:57 --> Router Class Initialized
DEBUG - 2012-12-13 23:42:57 --> Output Class Initialized
DEBUG - 2012-12-13 23:42:57 --> Security Class Initialized
DEBUG - 2012-12-13 23:42:57 --> Input Class Initialized
DEBUG - 2012-12-13 23:42:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-13 23:42:57 --> Language Class Initialized
DEBUG - 2012-12-13 23:42:57 --> Loader Class Initialized
DEBUG - 2012-12-13 23:42:58 --> Helper loaded: url_helper
DEBUG - 2012-12-13 23:42:58 --> Controller Class Initialized
DEBUG - 2012-12-13 23:42:58 --> Model Class Initialized
DEBUG - 2012-12-13 23:42:58 --> Database Driver Class Initialized
DEBUG - 2012-12-13 23:42:58 --> Helper loaded: form_helper
DEBUG - 2012-12-13 23:42:58 --> Form Validation Class Initialized
