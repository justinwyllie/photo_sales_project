<?php

class Admin_model extends CI_Model {

	public function __construct()
	{
		//this should get database connection with mysqli
		$this->load->database();
	}



	public function left_menu()
	{
		$menuItems = array(
                        array('name'=>'Business details', 'link'=>base_url() . 'admin/business')
		);
		
		return $menuItems; 	

	}

	

	/**
	* Return the items in the nav menu
	*
	*
	*/
	public function nav_menu()
	{

	
		$query = $this->db->get('nav_menu');
                return $query->result();	
	}


	/**
	* Gets and returns the site menu from the database
	*
	*/
//TODO this method and the next one should really be put into a generic menu method 
	public function site_menu()
	{


		$this->db->order_by("site_menu_id", "asc");	
		$query = $this->db->get('site_menu');
		$site_menu = array();
		$results = $query->result();	
		
		foreach ($results as $row)
		{
			if (is_null($row->parent))
			{
				$site_menu[$row->site_menu_id] = array('name'=>$row->name, 'link'=>$row->link, 'id'=>$row->site_menu_id, 'submenu'=>array());
			}	

		}

		foreach ($results as $row)
		{
			if (! is_null($row->parent))
			{
				$site_menu[$row->parent]['submenu'][] = array('name'=>$row->name, 'link'=>$row->link);
			}

		}
		

		return $site_menu;
	}

	/**
	* Gets and returns the client menu from the database
	*
	*/
	public function client_menu()
	{
		$client_menu = array();
		$this->db->order_by("client_menu_id", "asc");	
		$query = $this->db->get('client_menu');
		$results = $query->result();	
		
		foreach ($results as $row)
		{
			if (is_null($row->parent))
			{
				$client_menu[$row->client_menu_id] = array('name'=>$row->name, 'link'=>$row->link, 'id'=>$row->client_menu_id, 'submenu'=>array());
			}	

		}

		foreach ($results as $row)
		{
			if (! is_null($row->parent))
			{
				$client_menu[$row->parent]['submenu'][] = array('name'=>$row->name, 'link'=>$row->link);
			}

		}


		return $client_menu;

	}


	/*
	* Returns the available salutations 
	*
	*/
	public function salutations()
	{
		$query = $this->db->get('salutations');
                return $query->result();	
	}

	/*
	* Returns the available  currencies 
	*
	*/
	public function currencies()
	{
		$query = $this->db->get('currencies');
                return $query->result();	
	}




}





?>
