<?php



/*
* Data operations on the site_owner table
*
*/
class Business_model extends CI_Model {


	private $site_owner_id = null;
	private $salt = 'y6TR7El';

	public function __construct()
	{
		$this->load->database();
	}

	/*
	* Call the insert or update statement 
	*
	* Works out whether this is an update or insert. The site_owner table only ever has one record.
	*/	

	public function set_site_owner()
	{

		$data = array(
			'first_name' => $this->input->post('first_name'),
			'last_name' => $this->input->post('last_name'),
			'salutation' => $this->input->post('salutation'),
			'email' => $this->input->post('email'),
			'tel' => $this->input->post('tel'),
			'mobile' => $this->input->post('mobile'),
			'business_name' => $this->input->post('business_name'),
			'description' => $this->input->post('description'),
			'paypal_email' => $this->input->post('paypal_email'),
			'currencies_id' => $this->input->post('currency')
		);

		return $this->update_site_owner($data);
		
	
	}	

	public function get_site_owner()
	{

		$query = $this->db->get('site_owner', 1);
		$arr =  $query->result();
		return $arr[0]; 
	}

	/**
	* Get the set currency symbol and paypal word 
	* return object|null
	*/

	public function get_current_currency()
	{
		$site_owner_id = $this->_get_site_owner_id();	
		$this->db->where('site_owner_id', $site_owner_id);
		$this->db->select('currency_symbol, currency_paypal');
		$this->db->from('site_owner');
		$this->db->join('currencies', 'site_owner.currencies_id = currencies.currencies_id', 'inner');
		$query =  $this->db->get();
		$arr = $query->result();
		if (empty($arr))
		{
			return null;
		}
		else
		{
			return $arr[0];
		}
	}



	/**
	* Update the  customer logo 
	* return Booelan 
	*
	*/
	public function update_own_logo($file_name)
	{
		$site_owner_id = $this->_get_site_owner_id();
		$data = array('own_logo'=>$file_name);
		$result = $this->db->update('site_owner', $data, array('site_owner_id'=>$site_owner_id));	
		return $result;
			
	}

	/**

	/**
	* Update the  password 
	* return Booelan 
	*
	*/
	public function update_password()
	{
		$password  = md5($this->salt.$this->input->post('password1'));
		$site_owner_id = $this->_get_site_owner_id();
		$data = array('password'=>$password);
		return $this->db->update('site_owner', $data, array('site_owner_id'=>$site_owner_id));	
			
	}

	/**
	* update site_owner table
	* @param array $data the data
	* return bool 
	*/  

	public function update_site_owner($data)
	{
		$site_owner_id = $this->_get_site_owner_id();	
		return $this->db->update('site_owner', $data, array('site_owner_id'=>$site_owner_id));	

	}

	/**
	* update user
	* return bool 
	*/  

	public function update_user()
	{
		$site_owner_id = $this->_get_site_owner_id();	
		$data = array('user'=>$this->input->post('user'));
		$result =  $this->db->update('site_owner', $data, array('site_owner_id'=>$site_owner_id));	
		return $result;

	}



	/**
	* create the  site_owner user and password. ONLY CALLED BY INSTALL
	* @param array $data the data
	* return bool
	*/  
	public function insert_account()
	{
		$data = array('user'=>$this->input->post('user'), 'password'=>md5($this->salt.$this->input->post('password')) );
		return $this->db->insert('site_owner', $data);	

	}

	/**
	* Return the id of the site_owner in the table
	*
	* return int 
	*/

	private function _get_site_owner_id()
	{
		if (! is_null($this->site_owner_id) )
		{
			return $this->site_owner_id;
		}
		else
		{
			$query = $this->db->get('site_owner', 1);
			$site_owner = $query->result();
			$site_owner_id = $site_owner[0]->site_owner_id;
			$this->site_owner_id = $site_owner_id;
			return $site_owner_id;
		}
	}


	/**
        * Set  the  unit
        *
        * return boolean 
        */

        public function set_unit()
        {

		$site_owner_id = $this->_get_site_owner_id();	
		$data = array('unitsid'=> $this->input->post('unitsid'));
		return $this->db->update('site_owner', $data, array('site_owner_id'=>$site_owner_id));	
        }

        /**
        * Get  the  unit
	*
	* Get the set unit and its name and symbol
        *
        * return object
        */

        public function get_set_unit()
        {

		$site_owner_id = $this->_get_site_owner_id();	
		$this->db->where('site_owner_id', $site_owner_id);
		$this->db->from('site_owner');
		$this->db->select('units.unitsid, name, symbol');
		$this->db->join('units', 'units.unitsid = site_owner.unitsid');
                $query = $this->db->get();
                $arr =  $query->result();
                return $arr[0];
        }


        /**
        * Get  the  set unit
	*
	* Get the set unit id only 
        *
        * return null|integer
        */

        public function get_set_unit_id()
        {

		$site_owner_id = $this->_get_site_owner_id();	
		$this->db->where('site_owner_id', $site_owner_id);
		$this->db->from('site_owner');
		$this->db->select('unitsid');
                $query = $this->db->get();
                $arr =  $query->result();
                return $arr[0]->unitsid;
        }

}





?>
