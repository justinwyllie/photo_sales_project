<?php



/*
* Data operations on the site_owner table
*
*/
class Pricing_model extends CI_Model {


	private $site_owner_id = null;

	public function __construct()
	{
		$this->load->database();
	}


	/**
	* Get the current print sizes and prices 
	*
	* return array of objects
	*/

	public function get_print_sizes()
	{
		$query = $this->db->get('site_print_sizes');
                $arr =  $query->result();
		foreach ($arr as &$row)
		{
			$row->size_w = htmlspecialchars($row->size_w); 
			$row->size_h = htmlspecialchars($row->size_h); 
		}
		return $arr;
	}

	/**
	* Get the current print size for a given print 
	*
	* Also returns prices
	*
	* @return object|null 
	*/

	public function get_print_size()
	{
	//TODO apply discount
		$print_id = $this->input->get('print_id');
		//var_dump($print_id);exit;
		$this->db->select('size_w, size_h, price_print, price_mounted');
		$query = $this->db->get_where('site_print_sizes', array('site_print_sizes_id'=>$print_id));
                $arr =  $query->result();
		if (! empty($arr) )
		{
			$result = $arr[0];	
		}
		else
		{
			$result = null;
		}
		return $result;
	}


	/**
	* Get all the frames and prices for unmounted print
	* 
	* @return null|array of records (objects)
	**/
	public function get_print_frames_and_prices_unmounted()
	{
		$print_id = $this->input->get('print_id');
		$this->db->select('site_framing_types.site_framing_types_id, frame_type_name, price');
                $this->db->from('site_framing_types');
                $this->db->join('site_framing_sizes_unmounted',
			 'site_framing_types.site_framing_types_id = site_framing_sizes_unmounted.site_framing_types_id', 'left');
                $query =  $this->db->get();
                $arr = $query->result();
                if (empty($arr))
                {
                        return null;
                }
                else
                {
                        return $arr;
                }


	}

	/**
	* Get all the frames and prices for mounted print
	* 
	* @return null|array of records (objects)
	**/
	public function get_print_frames_and_prices_mounted()
	{
		$print_id = $this->input->get('print_id');
		$this->db->select('site_framing_types.site_framing_types_id, frame_type_name, price');
                $this->db->from('site_framing_types');
                $this->db->join('site_framing_sizes_mounted',
			 'site_framing_types.site_framing_types_id = site_framing_sizes_mounted.site_framing_types_id', 'left');
                $query =  $this->db->get();
                $arr = $query->result();
                if (empty($arr))
                {
                        return null;
                }
                else
                {
                        return $arr;
                }


	}

	/**
	* Get the current print prices for a given print 
	*
	* @return object|null 
	*/

	public function get_print_prices()
	{
//TODO apply discount
		$print_id = $this->input->get('print_id');
		//var_dump($print_id);exit;
		$this->db->select('size_w, size_h');
		$query = $this->db->get_where('site_print_sizes', array('site_print_sizes_id'=>$print_id));
                $arr =  $query->result();
		if (! empty($arr) )
		{
			$result = $arr[0];	
		}
		else
		{
			$result = null;
		}
		return $result;
	}

	/**
	* Get the current  mount types 
	*
	* return array of objects
	*/

	public function get_mount_types()
	{
		$query = $this->db->get('site_mounting_types');
                $arr =  $query->result();
		return $arr;
	}

	/**
	* Get the current  frame  types 
	*
	* return array of objects
	*/

	public function get_frame_types()
	{
		$query = $this->db->get('site_framing_types');
                $arr =  $query->result();
		return $arr;
	}

	/**
	* Get the available units 
	*
	* return array of objects
	*/

	public function get_units()
	{
		$query = $this->db->get('units');
                $arr =  $query->result();
		return $arr;
	}

	/**
	* Get the available units 
	*
	* Get the available units name only (not symbol) 
	*
	* @return assoc array 
	*/

	public function get_units_name()
	{
		$this->db->select('unitsid, name');
		$query = $this->db->get('units');
                $arr =  $query->result();
		$units = array();
		foreach ($arr as $key => $record)
		{
			$units[$record->unitsid] = $record->name;	
		}
		return $units;
	}

	/**
	* Get the current  frame  type 
	*
	* return false|object record
	*/

	public function get_frame_type()
	{
		$pk = $this->input->get('site_framing_types_id');
		$query = $this->db->get_where('site_framing_types', array('site_framing_types_id' => $pk));
		$db_error = $this->db->_error_message();
		if (empty($db_error))
		{
			$arr = $query->result();
			if (empty($arr))
			{
				return false;
			}
			else
			{
				return $arr[0];
			}
		}
		else
		{
			return false; 
		}
	}



	/** 
	* Update Print Configuration
	* 
	* Updates all print pricing options in a transaction
	* 
	* return bool
	*
	*/ 
	public function update_print_configuration()
	{

		$print_id = $this->input->post("print_id");
		$price_print = $this->input->post("price_print");
		$price_mounted = $this->input->post("price_mounted");
		$frames_unmounted = $this->input->post("frames_unmounted");
		$frames_mounted = $this->input->post("frames_mounted");


		$this->db->trans_start();
		
			$this->db->where('site_print_sizes_id', $print_id);
			$this->db->update('site_print_sizes', array('price_print'=>$price_print, 'price_mounted'=>$price_mounted));

			foreach ($frames_unmounted as $frame_option )
			{
				//subtle point. it will be 'null' if it was not set when sent to the browser as mysql/php null
				//gets returned by the browser as "null" 
				//it will be empty string if the field is explicitly cleared by the user
				//you could argue that delete in 'null' case is unnecessary but we chose to overwite
				//what another use may have done (and remove the one added by the 'other user')
				//so the point of this is to make sure we remove any print-frame-price records that this user wants to delete
				if ($frame_option['price'] == "null" || $frame_option['price'] == "")
				{
					$this->db->where('site_print_sizes_id', $print_id);
					$this->db->where('site_framing_types_id', $frame_option['site_framing_types_id']);
					$this->db->delete('site_framing_sizes_unmounted');
				}
				else
				{

					$this->db->where('site_print_sizes_id', $print_id);
					$this->db->where('site_framing_types_id', $frame_option['site_framing_types_id']);
					if ($this->db->count_all_results('site_framing_sizes_unmounted') == 0) {

      						$this->db->insert('site_framing_sizes_unmounted', 
							array('site_framing_types_id'=>$frame_option['site_framing_types_id'],
								'site_print_sizes_id' => $print_id,
								'price'=>$frame_option['price'])
							);

    					}
					else
					{

						$this->db->where('site_print_sizes_id', $print_id);
						$this->db->where('site_framing_types_id', $frame_option['site_framing_types_id']);
      						$this->db->update('site_framing_sizes_unmounted', 
								array('price'=>$frame_option['price'] )
							);

    					}
					
		
				}

			}	
	


		$this->db->trans_complete();
exit;
		if ($this->db->trans_status() === FALSE)
		{
   			 // generate an error... or use the log_message() function to log your error
			return false;
		}			
		return true;
	}
 

	/**
	* Set Print sizes and prices
	*
	* @param $update array of rows to update 
	* return bool 
	*/ 
	public function update_print_sizes($update)
	{

		/* notes on CI issues 
		*
		* if there is an error this appears unpredictably to sometimes throw an
		* error page even when debug is off. e.g. by using the wrong column name. 
		* ok. error in the naming of the key field produces an error page
		* error in the naming of a field name produces an error strinbg but no error page
		* and as expected if there is an error in the first batch of 100 but not in the second the final setting of _error_message 
		* shows no error.
		* http://codeigniter.com/forums/viewthread/221410/	
		*/


		$this->db->trans_start();
		$this->db->update_batch('site_print_sizes', $update, 'site_print_sizes_id');	
		$this->db->trans_complete();
		if ($this->db->trans_status() === FALSE)
		{
			return false;	
		}
		else
		{
			return true; 
		}


	}

	/**
	* Delete a Print sizes and prices entry
	*
	* return  bool 
	*/ 
	public function delete_print_sizes()
	{
		$pk = $this->input->post('site_print_sizes_id');
		$this->db->delete('site_print_sizes', array('site_print_sizes_id'=>$pk));
		$db_error = $this->db->_error_message();
		if (empty($db_error))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	
	/**
	* Insert Print sizes and prices
	*
	* return null|int 
	*/ 
	public function insert_print_sizes()
	{
		$site_w = $this->input->post('site_w');
		$site_h = $this->input->post('site_h');
		$price = $this->input->post('price');
	
		$data = array('size_w'=>$site_w, 'size_h'=>$site_h, 'price'=>$price);
		$this->db->insert('site_print_sizes', $data);	

		$db_error = $this->db->_error_message();
		if (empty($db_error))
		{
			return $this->db->insert_id();
		}
		else
		{
			return null;
		}
		
	}

	/**
	* Insert Mount Type 
	*
	* return null|int 
	*/ 
	public function insert_mount_type()
	{
		$name = $this->input->post('mount_type_name');
	
		$data = array('mount_type_name'=>$name);
		$this->db->insert('site_mounting_types', $data);	

		$db_error = $this->db->_error_message();
		if (empty($db_error))
		{
			return $this->db->insert_id();
		}
		else
		{
			return null;
		}
		
	}


	/**
	* Delete a Mount Type 
	*
	* return  bool 
	*/ 
	public function delete_mount_type()
	{
		$pk = $this->input->post('site_mounting_types_id');
		$this->db->delete('site_mounting_types', array('site_mounting_types_id'=>$pk));
		$db_error = $this->db->_error_message();
		if (empty($db_error))
		{
			return true;
		}
		else
		{
			return false;
		}
	}


	/**
	* Set Mount types 
	*
	* @param $update array of rows to update 
	* return bool 
	*/ 
	public function update_mount_types($update)
	{
		$this->db->trans_start();
		$this->db->update_batch('site_mounting_types', $update, 'site_mounting_types_id');	
		$this->db->trans_complete();
		if ($this->db->trans_status() === FALSE)
		{
			return false;	
		}
		else
		{
			return true; 
		}
	}


	/**
	* Insert Frame  Type 
	*
	* @param $filename string|null name of file to put into db
	* return null|int 
	*/ 
	public function insert_frame_type($filename)
	{
		$name = $this->input->post('frame_type_name');
		$description = $this->input->post('description');	
	
		$data = array('frame_type_name'=>$name, 'description'=>$description, 'filename'=>$filename);
		$this->db->insert('site_framing_types', $data);	

		$db_error = $this->db->_error_message();
		if (empty($db_error))
		{
			return $this->db->insert_id();
		}
		else
		{
			return null;
		}
		
	}

	/**
	* Update  Frame  Type 
	*
	* @param $filename string|null name of file to put into db
	* return boolean  
	*/ 
	public function update_frame_type($filename)
	{
		$name = $this->input->post('frame_type_name');
		$description = $this->input->post('description');	
		$site_framing_types_id = $this->input->post('site_framing_types_id');


		//attempt to delete the old image
		if (! is_null($filename) )
		{
			$query = $this->db->get_where('site_framing_types', array('site_framing_types_id' => $site_framing_types_id));
			$arr = $query->result();
			$old_filename = $arr[0]->filename;
			if (! is_null($old_filename))
			{
				@unlink('./uploads/'.$old_filename);
			}
		}
	
		$data = array('frame_type_name'=>$name, 'description'=>$description);
		if (! is_null($filename))
		{
			$data['filename']=$filename;
		}
		$this->db->where('site_framing_types_id', $site_framing_types_id);
		$this->db->update('site_framing_types', $data);	

		$db_error = $this->db->_error_message();
		if (empty($db_error))
		{
			return true; 
		}
		else
		{
			return false;
		}
		
	}

	/**
	* Delete a Frame  Type 
	* 
	* Delete a frame type. Also tries to delete an image if there is one
	*
	* return  bool 
	*/ 
	public function delete_frame_type()
	{
		$pk = $this->input->post('site_framing_types_id');
		$query = $this->db->get_where('site_framing_types', array('site_framing_types_id' => $pk));
		$arr = $query->result();

		$filename = $arr[0]->filename;
		if (! is_null($filename))
		{
			$path = './uploads/'.$filename;
			@unlink($path);			
			$path2 = './uploads/thumbs/'.$filename;
			@unlink($path2);			
		}	
	
		$this->db->delete('site_framing_types', array('site_framing_types_id'=>$pk));
		$db_error = $this->db->_error_message();
		if (empty($db_error))
		{
			return true;
		}
		else
		{
			return false;
		}
	}


	/**
	* Set Frame types 
	*
	* @param $update array of rows to update 
	* return bool 
	*/ 
	public function update_frame_types($update)
	{
		$this->db->trans_start();
		$this->db->update_batch('site_framing_types', $update, 'site_framing_types_id');	
		$this->db->trans_complete();
		if ($this->db->trans_status() === FALSE)
		{
			return false;	
		}
		else
		{
			return true; 
		}
	}
}





?>
