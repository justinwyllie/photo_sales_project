<div class="content_area">
	<h2>Edit your account</h2>



		<h4>User name</h4>
		<div class="ajax_form">
			<div class="alert success"> <span class="icon"></span><strong>Success</strong> Username Updated </div>
			<div class="alert error"> <span class="icon"></span><strong>Error</strong> Please correct the form and try again</div>
			<div class="alert system_error"> <span class="icon"></span><strong>System Error</strong></div>
			<div class="alert warning"> <span class="icon"></span><strong>Warning</strong> </div>

		
			<?php echo form_open('admin/business/ajax_account_name') ?>
				<div>help icon ?</div>

			

				<label class="form_label"  for="user">User. Must be between 5 and 12 alpha-numeric characters only. </label> 
				<input class="form_field"  type="text" name="user" value="<?php echo $siteOwner->user ?>"/>
				<br class="form_breaker">
				<input class="submit_button" type="submit" name="submit" value="Update User" /> 
			</form>
		</div>

		<hr>

		<h4>Change Password</h4>

		<div class="ajax_form">
			<div class="alert success"> <span class="icon"></span><strong>Success</strong> Password Updated </div>
			<div class="alert error"> <span class="icon"></span><strong>Error</strong> Please correct the form and try again</div>
			<div class="alert warning"> <span class="icon"></span><strong>Warning</strong> </div>

			<?php echo form_open('admin/business/ajax_account_password') ?>
				<div>help icon ?</div>
				<label class="form_label"  for="password1">Password. Must be between 5 and 12 alpha-numeric characters only.</label> 
				<input class="form_field"  type="password" name="password1" value="<?php echo $siteOwner->password ?>"/>
				<br class="form_breaker">
				<label class="form_label"  for="password2">Repeat Password</label> 
				<input class="form_field"  type="password" name="password2" value="<?php echo $siteOwner->password ?>"/>
				<br class="form_breaker">
				<input class="submit_button" type="submit" name="submit" value="Change Password" /> 
			</form>
		</div>

		<hr>





</div>






