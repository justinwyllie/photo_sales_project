<div class="content_area">
	<h2>Edit your business details</h2>

	<div class="ajax_form">

	<div class="alert success"> <span class="icon"></span><strong>Success</strong> Username Updated </div>
        <div class="alert error"> <span class="icon"></span><strong>Error</strong> Please correct the form and try again</div>
	<div class="alert system_error"> <span class="icon"></span><strong>System Error</strong></div>
        <div class="alert warning"> <span class="icon"></span><strong>Warning</strong> </div>

		<?php echo form_open('admin/business/ajax_business') ?>
			<div >Fields marked <span class="required">*</span> are required.</div><br>
	
			<input name="site_owner_id" type="hidden" value="<?php echo is_null($siteOwner) ? "" : $siteOwner->site_owner_id ?>" >
	

			<label class="field_label form_label"  for="salutation">Title</label> 
			<select name="salutation" id="salutation" class="normal_select form_field">
				<option value=".."  <?php echo (  is_null($siteOwner->salutation) ) ? 'selected' : "" ?>>Select..</option>
				<?php foreach ($salutations as $salutation): ?>
					<option value="<?= $salutation->salutations_id ?>"														 <?php echo ($salutation->salutations_id == $siteOwner->salutation) ? 'selected' : "" ?>>
						<?=$salutation->salutation ?></option> 	
				<?php endforeach; ?>	
			</select>

			<br class="form_breaker">
			<label class=" form_label"  for="first_name">First Name <span class="required">*</span></label> 
			<input class="form_field"  type="input" name="first_name" value="<?php echo is_null($siteOwner) ? "" :  $siteOwner->first_name?>"/>

			<br class="form_breaker">
			<label class="form_label"  for="last_name">Last Name <span class="required">*</span></label> 
			<input class="form_field"  type="input" name="last_name" value="<?php echo is_null($siteOwner) ? "" : $siteOwner->last_name?>"/>
			<br class="form_breaker">

			<label class=" form_label"  for="email">Email <span class="required">*</span></label> 
			<input class="form_field"  type="email" name="email" value="<?php echo is_null($siteOwner) ? "" : $siteOwner->email ?>"/>
			<br class="form_breaker">


			<label class="form_label"  for="tel">Tel</label> 
			<input class="form_field"  type="input" name="tel" value="<?php echo is_null($siteOwner) ? "" : $siteOwner->tel ?>"/>
			<br class="form_breaker">



			<label class="form_label"  for="mobile">Mobile</label> 
			<input class="form_field"  type="input" name="mobile" value="<?php echo is_null($siteOwner) ? "" : $siteOwner->mobile ?>"/>
			<br class="form_breaker">


			<label class="form_label"  for="mobile">Business Name <span class="required">*</span></label> 
			<input class="form_field"  type="input" name="business_name"
				 value="<?php echo is_null($siteOwner) ? "" : $siteOwner->business_name ?>"/>
			<br class="form_breaker">

			<label class="form_label"  for="description">Description <span class="required">*</span></label> 
			<textarea class="form_field"   name="description"><?php echo is_null($siteOwner) ? "" : $siteOwner->description ?></textarea>
			<br class="form_breaker">




			<label class="form_label"  for="paypal_email">Your Business PayPal Email (required to accept online payment)</label> 
			<input class="input_label form_field"  type="email" name="paypal_email" 
				value="<?php echo is_null($siteOwner) ? "" : $siteOwner->paypal_email ?>"/>

			<br class="form_breaker">
	

			<label class="form_label"  for="currency">Currency <span class="required">*</span></label> 
			<select name="currency" id="currency" class="normal_select form_field">
				<option value=".."  <?php echo (  is_null($siteOwner->currencies_id) ) ? 'selected' : "" ?>>Select..</option>
				<?php foreach ($currencies as $currency): ?>
					<option value="<?= $currency->currencies_id ?>" 
						<?php echo ($currency->currencies_id == $siteOwner->currencies_id) ? 'selected' : "" ?>  >
						<?=$currency->currency_word ?> (<?=$currency->currency_symbol?>)</option> 	
				<?php endforeach; ?>	
			</select>

	
			<br class="form_breaker">



			<br>
			<input class="submit_button" type="submit" name="submit" value="Update" /> 

	</form>

	</div>


</div>






