<div class="content_area">
	<h2>Upload your logo</h2>


		<h4>Upload your logo</h4>


		<div class="alert <?=$msg['class']?>"><?=$msg['text']?></div>

		<?php echo form_open_multipart('admin/business/post_account_logo', array('class'=>'post')) ?>
			<div>help icon ?</div>
			<?php
				if (! is_null($logo) ):
			?>
				<? echo img($logo) ?>

			<?php
				endif;
			?>
				

			<label class="form_label"  for="logo">Logo 120px x 90px (max 200k)</label> 
			<input class="form_field"  type="file" name="logo" />
			<br class="form_breaker">
			<input class="submit_button" type="submit" name="submit" value="Set your logo" /> 
		</form>



</div>






