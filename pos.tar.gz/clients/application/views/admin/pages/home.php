
<div class="content_area">
	<h2>Welcome to the Admin System for PrintOrderingSystem.</h2>
</div>


