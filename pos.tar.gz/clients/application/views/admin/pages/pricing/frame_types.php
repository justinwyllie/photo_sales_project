<div class="content_area">
	<h2>Set the frame types you offer  </h2>

<div class="help">help icon</div>

	<div class="ajax_form">

        	<div class="alert success"> <span class="icon"></span><strong>Success</strong> Frame types updated </div>
        	<div class="alert error"> <span class="icon"></span><strong>Error</strong> Please correct the form and try again</div>
   		<div class="alert system_error"> <span class="icon"></span><strong>System Error</strong></div>
   		<div class="alert warning"> <span class="icon"></span><strong>Warning</strong> </div>


		<div id="frame_type" class="virtual_form">

			<button id="add_frame_type_row" name="insert">Add new frame type</button><br>
			<div  class="form_label">Name</div>
			<div  class="form_label">Description</div>
			<div  class="form_label">Image (max 200px x 200px)</div>


			<br class="form_breaker">
			<div class="rows">
					<?php foreach ($frame_types as $frame): ?>
						<div class="frame_row form_breaker" data-id="<?=$frame->site_framing_types_id?>">	
							<div class="frame_name virtual_form_field"><?= $frame->frame_type_name ?> </div> 
							<div class="frame_description virtual_form_textarea" ><?= $frame->description ?></div> 
							<div class="inline_form_pic">	
								<?php if (! is_null($frame->filename)) : ?>
									<img src="<?=base_url()?>uploads/thumbs/<?= $frame->filename ?>"
										 alt="<?=$frame->filename?>">
										  
								<?php endif; ?>
							</div>
							<button id="frame_type_<?= $frame->site_framing_types_id ?>" 
								class="event_frame_update inline_button" 
								data-id="<?= $frame->site_framing_types_id?>">Edit</button>	
							 <div class="delete_icon event_frame_type_delete pointer frame_type_delete"
                                                	data-action="<?=base_url() ?>admin/pricing/ajax_frame_types_delete"
                                                	data-id="<?=$frame->site_framing_types_id?>" ></div>
						</div>	
					<?php endforeach; ?>
			</div>
			<br class="form_breaker">


		</div>

	</div>


</div>

<!-- the html for the add record dialog-->
<!-- TODO undertsand this css and move to admin.css -->
	<style>
		.ui-dialog .ui-state-error { padding: .3em; }
	</style>
<div id="dialog-form-frame-types" title="Add New Frame Type" class="dialog_form_content" data-delete_url="<?=base_url()?>admin/pricing/ajax_frame_types_delete" data-action="<?=base_url()?>admin/pricing/ajax_frame_types_insert" data-thumb_path="<?=base_url()?>uploads/thumbs/" >
	<p>Fields marked <span class="required">*</span> are required.</p>

	<div class="ajax_form">
       		<div class="alert error"> <span class="icon"></span><strong>Error</strong> Please correct the form and try again</div>
   		<div class="alert system_error"> <span class="icon"></span><strong>System Error</strong></div>
		<form id="frame_type_form_insert" method="POST"    enctype="multipart/form-data" action="<?=base_url()?>admin/pricing/post_new_frame_type" >
		<fieldset>
			<label for="frame_type_name" >Name <span class="required">*</span></label>
			<br>
			<input type="text" name="frame_type_name" id="frame_type_name" class="text ui-widget-content ui-corner-all form_field_dialog" />
			<br>
			<label for="description" >Description</label>
			<br>
			<textarea name="description" class="small_text_area ui-widget-content ui-corner-all form_textarea_dialog" id="frame_type_description"></textarea>
			<br>
			<progress id="new_frame_progress"></progress>
			<br>	
			<label for="frame_image">Image (max 200px x 200px) </label><br>
			<input type="file" name="frame_image" class="form_file_field_dialog">
			


		</fieldset>
		</form>
	</div>

</div>

<div id="dialog-form-frame-edit" title="Edit Frame Type" class="dialog_form_content" data-get_edit_url="<?=base_url()?>admin/pricing/ajax_frame_type_get" data-save_edit_url="<?=base_url()?>admin/pricing/ajax_frame_type_save_edit" data-thumb_path="<?=base_url()?>uploads/thumbs/" >
	<p>Fields marked <span class="required">*</span> are required.</p>

	<div class="ajax_form">
       		<div class="alert error"> <span class="icon"></span><strong>Error</strong> Please correct the form and try again</div>
   		<div class="alert system_error"> <span class="icon"></span><strong>System Error</strong></div>
		<form id="frame_type_form_edit" method="POST"    enctype="multipart/form-data" action="<?=base_url()?>admin/pricing/post_new_frame_type" >
		<input type="hidden" name="site_framing_types_id" id="pk" value="" >
		<fieldset>
			<label for="frame_type_name" >Name <span class="required">*</span></label>
			<br>
			<input type="text" name="frame_type_name" id="frame_type_name" class="text ui-widget-content ui-corner-all form_field_dialog" />
			<br>
			<label for="description" >Description</label>
			<br>
			<textarea name="description" class="small_text_area ui-widget-content ui-corner-all form_textarea_dialog" id="frame_type_description"></textarea>
			<br>
			<br>	
			<div class="inline_form_pic">	
			</div>
			<br class="form_breaker">
			<progress id="edit_frame_progress"></progress>
			<br>
			<label for="frame_image">Change Image (max 200px x 200px) </label><br>
			<input type="file" name="frame_image" class="form_file_field_dialog">
		</fieldset>
		</form>
	</div>

</div>


<div id="dialog-confirm-frame-delete" title="Are you sure you want to delete this frame type?">
	<p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>This frame type will be deleted. Are you sure?</p>
</div>







