<div class="content_area">
	<h2>Edit your business details</h2>


	<?php echo form_open('admin/business/ajax_business') ?>

		<input name="site_owner_id" type="hidden" value="<?php echo is_null($siteOwner) ? "" : $siteOwner->site_owner_id ?>" >


		<label class="field_label form_label"  for="salutation">Title</label> 
		<select name="salutation" id="salutation" class="normal_select form_field">
			<option value=".."  <?php echo (  is_null($siteOwner->salutation) ) ? 'selected' : "" ?>>Select..</option>
			<?php foreach ($salutations as $salutation): ?>
				<option value="<?= $salutation->salutations_id ?>" <?php echo ($salutation->salutations_id == $siteOwner->salutation) ? 'selected' : "" ?>><?=$salutation->salutation ?></option> 	
			<?php endforeach; ?>	
		</select>

		<br class="form_breaker">
		<label class=" form_label"  for="first_name">First Name</label> 
		<input class="form_field"  type="input" name="first_name" value="<?php echo is_null($siteOwner) ? "" :  $siteOwner->first_name?>"/>

		<br class="form_breaker">
		<label class="form_label"  for="last_name">Last Name</label> 
		<input class="form_field"  type="input" name="last_name" value="<?php echo is_null($siteOwner) ? "" : $siteOwner->last_name?>"/>
		<br class="form_breaker">

		<label class=" form_label"  for="email">Email</label> 
		<input class="form_field"  type="input" name="email" value="<?php echo is_null($siteOwner) ? "" : $siteOwner->email ?>"/>
		<br class="form_breaker">


		<label class="form_label"  for="tel">Tel</label> 
		<input class="form_field"  type="input" name="tel" value="<?php echo is_null($siteOwner) ? "" : $siteOwner->tel ?>"/>
		<br class="form_breaker">



		<label class="form_label"  for="mobile">Mobile</label> 
		<input class="form_field"  type="input" name="mobile" value="<?php echo is_null($siteOwner) ? "" : $siteOwner->mobile ?>"/>
		<br class="form_breaker">


		<label class="form_label"  for="mobile">Business Name</label> 
		<input class="form_field"  type="input" name="business_name" value="<?php echo is_null($siteOwner) ? "" : $siteOwner->business_name ?>"/>
		<br class="form_breaker">

		<label class="form_label"  for="description">Description</label> 
		<textarea class="form_field"   name="description"><?php echo is_null($siteOwner) ? "" : $siteOwner->description ?></textarea>
		<br class="form_breaker">




		<label class="form_label"  for="paypal_email">Business PayPal Email</label> 
		<input class="input_label form_field"  type="input" name="paypal_email" value="<?php echo is_null($siteOwner) ? "" : $siteOwner->paypal_email ?>"/>

		<br class="form_breaker">


		<label class="form_label"  for="currency">Currency</label> 
		<select name="currency" id="currency" class="normal_select form_field">
			<option value=".."  <?php echo (  is_null($siteOwner->currency) ) ? 'selected' : "" ?>>Select..</option>
			<?php foreach ($currencies as $currency): ?>
				<option value="<?= $currency->currencies_id ?>" <?php echo ($currency->currencies_id == $siteOwner->currency) ? 'selected' : "" ?>  ><?=$currency->currency_word ?> (<?=$currency->currency_symbol?>)</option> 	
			<?php endforeach; ?>	
		</select>

	
		<br class="form_breaker">



		<br>
		<input class="submit_button" type="submit" name="submit" value="Update" /> 

	</form>




</div>






