<div class="content_area">
	<h2>Set the mount types you offer  </h2>

<div class="help">help icon</div>

	<div class="ajax_form">

        	<div class="alert success"> <span class="icon"></span><strong>Success</strong> Mount types updated </div>
        	<div class="alert error"> <span class="icon"></span><strong>Error</strong> Please correct the form and try again</div>
   		<div class="alert system_error"> <span class="icon"></span><strong>System Error</strong></div>
   		<div class="alert warning"> <span class="icon"></span><strong>Warning</strong> </div>


		<?php echo form_open('admin/pricing/ajax_mount_update', array('id'=>'mount_type_form')) ?>

			<input type="button" id="add_mount_type_row" name="insert"  value="Insert Row" /><br>
			<div class="form_breaker">Name</div>

					<?php foreach ($mount_types as $mount): ?>
						<div class="mount_row form_breaker" data-id="<?=$mount->site_mounting_types_id?>">	
							<input type="text" name="mount_type_name_<?= $mount->site_mounting_types_id ?>" 
								value="<?= $mount->mount_type_name ?>" class="mount_type_input" />
							 <div class="delete_icon event_mount_type_delete pointer mount_type_delete"
                                                	data-action="<?=base_url() ?>admin/pricing/ajax_mount_types_delete"
                                                	data-id="<?=$mount->site_mounting_types_id?>" ></div>
						</div>	
					<?php endforeach; ?>
			<br class="form_breaker">

			<input class="submit_button" type="submit" name="submit" value="Update" /> 



		</form>

	</div>


</div>

<!-- the html for the add record dialog-->
<!-- TODO undertsand this css and move to admin.css -->
	<style>
		.ui-dialog .ui-state-error { padding: .3em; }
		.validateTips { border: 1px solid transparent; padding: 0.3em; }
	</style>
<div id="dialog-form-mount-types" title="Create New Mount Type" class="dialog_form_content" data-delete_url="<?=base_url()?>admin/pricing/ajax_mount_types_delete" data-action="<?=base_url()?>admin/pricing/ajax_mount_types_insert" >
	<p class="validateTips">All form fields are required.</p>

	<div class="ajax_form">
       		<div class="alert error"> <span class="icon"></span><strong>Error</strong> Please correct the form and try again</div>
		<form id="mount_type_form_insert">
		<fieldset>
			<label for="size_w">Name</label>
			<input type="text" name="mount_type_name" id="mount_type_name" class="text ui-widget-content ui-corner-all" />
		</fieldset>
		</form>
	</div>
</div>






