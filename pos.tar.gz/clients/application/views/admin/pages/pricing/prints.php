<div class="content_area">
	<h2>Set The print sizes you offer and their prices  </h2>

<div class="help">help icon</div>

	<div class="ajax_form">

        	<div class="alert success"> <span class="icon"></span><strong>Success</strong> Print sizes/prices updated </div>
        	<div class="alert error"> <span class="icon"></span><strong>Error</strong> Please correct the form and try again</div>
   		<div class="alert system_error"> <span class="icon"></span><strong>System Error</strong></div>
   		<div class="alert warning"> <span class="icon"></span><strong>Warning</strong> </div>

		<div class="virtual_form" id="prints">	


			<button id="add_print_row" >Add new print</button><br>

			<?php if (is_null($currency) ): ?>
				<div class="alert warning">	
					The currency for pricing has not yet been set up in the database. You are advised to <a href="<?=base_url()?>admin/business/index" title="Set up Business Details" >do that now</a> 
				</div>
			<?php endif; ?>




					<h3 class="small_form_label">Width <?=$unit->symbol ?></h3>
					<h3 class="small_form_label">Height <?=$unit->symbol ?></h3>

					<?php foreach ($print_prices as $unit): ?>

						<div class="frame_row form_breaker" data-id="<?=$unit->site_print_sizes_id?>">	
							<div class="small_virtual_form_field"><?=$unit->size_w ?> </div> 
							<div class="small_virtual_form_field"><?=$unit->size_h ?> </div> 
							<button  class="event_load_print_configure pointer inline_button" 
								data-id="<?=$unit->site_print_sizes_id?>">Set options and pricing</button>	
							 <div class="delete_icon event_print_delete pointer print_type_delete" 	
								data-action="<?=base_url()?>admin/pricing/ajaz_prints_delete" 
								data-id="<?=$unit->site_print_sizes_id?>"></div>
						</div>


					<?php endforeach; ?>

		</div><!-- end virtual form -->


	</div><!-- end ajax form -->


</div>

<!-- the html for the add record dialog-->
<!-- TODO undertsand this css and move to admin.css -->
	<style>
		.ui-dialog .ui-state-error { padding: .3em; }
		.validateTips { border: 1px solid transparent; padding: 0.3em; }
	</style>
<div id="dialog-form-prints" title="Create New Print Size" class="dialog_form_content" data-delete_url="<?=base_url()?>admin/pricing/ajax_prints_delete" data-action="<?=base_url()?>admin/pricing/ajax_prints_insert" >
	<p class="validateTips">All form fields are required.</p>
<!-- TODO general tood here - do we use fieldsets at all? is form ok with no action -->
	<form>
	<fieldset>
		<label for="size_w">Size - width</label>
		<input type="text" name="size_w" id="size_w" class="text ui-widget-content ui-corner-all" />
		<br><label for="size_h">Size - height</label>
		<input type="text" name="size_h" id="size_h" class="text ui-widget-content ui-corner-all" />
<!--TODO i think curreny will also be set to something cos of the wizard -->
		<br><label for="price">Price  (<?php echo (is_null($currency)) ? "" : $currency->currency_symbol ?>) </label>
		<input type="text" name="price" id="price" class="text ui-widget-content ui-corner-all" />
	</fieldset>
	</form>
</div>





<div id="dialog-form-print-configure" title="Configure print options and prices" class="dialog_form_content" data-action="<?=base_url()?>admin/pricing/ajax_print_configure_update" data-get_configure_data="<?=base_url()?>admin/pricing/ajax_print_configure" >


	<div class="help">
		Set the prices for this print. You can set the price for the print only. For the print, mounted. If you have set up
		frame types you can also set the prices for the print framed with or without mount for each frame type. To do this
		just choose the frame type in the select box and enter the price for that frame type. Then press ENTER. For any option that you do not
		wish to provide just leave the field completely blank. (Press ENTER on a blank field to remove the price setting for that option). 
	</div>


	<div id="print_details" ><span class="bold">Print</span>: <span id="print_width"></span> <span class="print_unit"></span> x <span id="print_height"></span>
		<span class="print_unit"></span>
		<span class="bold">Currency</span>: <span id="currency"></span>
	</div>


	<div class="ajax_form">
		<div class="alert error"> <span class="icon"></span><strong>Error</strong> Please correct the form and try again</div>
        	<div class="alert system_error"> <span class="icon"></span><strong>System Error</strong></div>

		<form id="print_configure_form">
			<fieldset>
	
				<label class="form_label" for="print_price">Print only price</label>
				<span class="currency_symbol"></span>
				<input type="text" name="print_price" id="print_price" class="form_field_numeric text ui-widget-content ui-corner-all" />

				<br>
				<label class="form_label" for="print_mounted_price">Print mounted price</label>
				<span class="currency_symbol"></span><input type="text" name="print_mounted_price" 
				id="print_mounted_price" class="text ui-widget-content ui-corner-all form_field_numeric" />

				<br>
				<label class="form_label_long" for="print_framed_only_price">Print Framed (no mount) price</label>
				<select id="print_framed_no_mount" class="select_form" name="print_framed_no_mount">
				</select>	
				<input type="text" name="print_framed_no_mount_price" id="print_framed_no_mount_price" 
				class="text ui-corner-all ui-widget-content form_field_numeric" />
				<span class="messsage_set">set</span>

				<br>
				<label class="form_label_long" for="print_framed_and_mounted_price">Print Framed and Mounted price</label>
				<select id="print_framed_mounted" class="select_form" name="print_framed_mounted">
				</select>	
				<input  type="text" name="print_framed_mounted_price" id="print_framed_mounted_price"
					 class="text ui-corner-all ui-widget-content form_field_numeric" />
				<span class="messsage_set">set</span>


			</fieldset>
		</form>
	</div>
</div>

