<div class="content_area">
	<h2>Set the unit in which you sell prints  </h2>

<div class="help">help icon</div>

	<div class="ajax_form">

        	<div class="alert success"> <span class="icon"></span><strong>Success</strong> Unit updated </div>
        	<div class="alert error"> <span class="icon"></span><strong>Error</strong> Please correct the form and try again</div>
   		<div class="alert system_error"> <span class="icon"></span><strong>System Error</strong></div>
   		<div class="alert warning"> <span class="icon"></span><strong>Warning</strong> </div>

		<div id="unit_form" class="virtual_form units_form">
			<?php echo form_dropdown('units', $units, $set_unit); ?>

			<br class="form_breaker">


			<button id="set_unit" class="event_set_unit"  >Set Unit</button><br>

		</div>

	</div>



</div><!-- end content_area -->


<div id="dialog-prompt-set-unit" title="Set Unit">
    <p><span class="ui-icon ui-icon-alert" style="float: left; margin: 0 7px 20px 0;"></span>
You must choose a Unit</p>
</div>

<div id="dialog-confirm-set-unit" title="Set Unit" data-action="<?= base_url()?>admin/pricing/ajax_unit_set">
    <p><span class="ui-icon ui-icon-alert" style="float: left; margin: 0 7px 20px 0;"></span>
<span class="bold">Caution!</span> This will change the units for all pricing records but will not convert existing values. <br><br>For example a 10" x 8" print will now be marked as a 10cm x 8cm print or vice versa. Only proceed if you are sure. </p>
</div>


