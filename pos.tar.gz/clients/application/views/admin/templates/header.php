<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="<?php echo base_url();?>css/jquery.ui.all.css" type="text/css" media="screen" />
<link rel="stylesheet" href="<?php echo base_url();?>css/admin_styles.css" type="text/css" media="screen" />
<link rel="stylesheet" href="<?php echo base_url();?>css/wip.css" type="text/css" media="screen" />

<script type="text/javascript" src="<?php echo base_url();?>js/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/jquery-ui-1.8.22.custom.js"></script>

<script type="text/javascript" src="<?php echo base_url();?>js/admin.js"></script>
                   
<title><?=$c_title?></title>  
</head>

<body>
<div class="main">

	<!-- Header Start -->          
	<div class="header"></div>

	<div class="h_divider"></div>

	<div class="help_button"></div>

	<div class="d_div"></div>
	<!-- Header Finish -->
