<div class="top_menu">
	<?php foreach($navItems as $navItem): ?>

		<a class="navItem" title="<?=$navItem->name ?>" href="<?=base_url().$navItem->link ?>" ><?= $navItem->name ?></a>
	<?php endforeach; ?>	
</div>
<div class="divider"></div>
