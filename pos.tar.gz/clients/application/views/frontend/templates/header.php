<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="<?php echo base_url();?>css/styles.css" type="text/css" media="screen" />
	<title><?=$c_title?></title>
</head>
<body>
