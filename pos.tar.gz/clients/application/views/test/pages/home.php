
<div class="content_area">
	<h2>Welcome to the Admin System for PrintOrderingSystem.</h2>
  <p>This is the Home page! What does a home page say?</p>
</div>


