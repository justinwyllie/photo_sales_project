<!-- Footer Start -->
<div class="d_div"></div>
<div class="footer">
	<div class="copyright"></div>
</div>


<!-- end main div-->
</div>
<!-- Footer Finish -->
</body>
</html>
