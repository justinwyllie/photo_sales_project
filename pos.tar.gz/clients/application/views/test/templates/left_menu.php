<!-- Left Menu Start --> 
<div class="left_menu">
  




  <div id="accordion1" class="accordionMenu">
    <?php foreach ($site_menu as $menuItem): ?>
      <h3 class="menuSectionHead" ><a href="#"  ><?= $menuItem['name'] ?></a></h3>
	<div class="menuItem">
        <?php foreach ($menuItem['submenu'] as $submenu_item): ?>
      		<a class="menu" href="<?= base_url().$submenu_item['link'] ?>" title="<?=$submenu_item['name']?>" ><?=$submenu_item['name']?></a><br>
    	<?php endforeach ?>
	</div>
    <?php endforeach ?>
  </div><!-- end accrodion1 -->
  






</div>
<!-- Left Menu Finish -->
