<div class="top_menu">
	<a href="<?php echo base_url() ?>#">Link 1</a>
  <a href="<?php echo base_url() ?>#">Link 2</a>
  <a href="<?php echo base_url() ?>#">Link 3</a>
  <a href="<?php echo base_url() ?>#">Link 4</a>
  <a href="<?php echo base_url() ?>#">Link 5</a>
</div>
<div class="divider"></div>
