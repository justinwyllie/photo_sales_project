$(function() {

$.ajaxSetup({
  cache: false 
});
/* lib */

//TODO global Ajax settings


/*

			type: "POST",
			url: url,
			data: data,
			cache: false,
*/


//TODO contsnats - inject from the backend

var systemError = "System Errror. Please try again later";

/* functions to show alerts on forms */

/*
* Error
* @param form form is html form element
* @param errorText string from CI about fields with errors 
*/

function formError(form,   errorText) {

	clearAlerts(form);
	$(form).parent('div.ajax_form').find('div.alert.error').fadeIn('slow');	
	if (typeof errorText != "undefined") { 
		$(form).before($('<div>').addClass('form_errors').html(errorText));
	}
}

/*
* System Error
* called when the AJAX call fails either a 500 or not json returned or a timeout
*
* @param form
*/

function formSystemError(form, errorText) {

	clearAlerts(form);
	$(form).parent('div.ajax_form').find('div.alert.system_error').fadeIn('slow');	
	if (typeof errorText != "undefined") { 
		$(form).before($('<div>').addClass('form_errors').html(errorText));
	}
}

/*
* Success 
* @param form is form element
*/

function formSuccess(form) {
	
	clearAlerts(form);
	$(form).parent('div.ajax_form').find('div.alert.success').fadeIn('slow');	

}

/*
* Warnings 
* @param form is form element
*/

function formWarning(form) {
	clearAlerts(form);
	$(form).parent('div.ajax_form').find('div.alert.warning').fadeIn('slow');	
}

function clearAlerts(form)
{
	$(form).parent('div.ajax_form').find('div.alert').hide();	
	$(form).parent('div.ajax_form').find('div.form_errors').remove();	
}



/* all page events */


	
/*

	$('form:not(.post)').submit(function(evt) { 
		var form = evt.target;

		var data = {};
		$(form).find('input,  textarea, select').each(function() {
			var vName = $(this).attr('name');
			var vVal = $(this).val();
			data[vName] = vVal;
		});

		url = $(form).attr('action');

		$.ajax({
			url: url,
			dataType: "json",
			type: "POST",
			data: data		


		}).done(function(result) {
			if (result.result) {
				formSuccess(form );
			} else 
			{
				formError(form, result.errors); 
			}
		}).fail(function() {
			//TODO 
			formSystemError(form); 
		});
		

		//evt.preventDefault(); 
		return false; 
		}
	)

*/

	//Accordion menus
	$( ".accordionMenu" ).accordion();	


/* pricing section events */


	$('table#prints').on('click', '.event_print_size_delete', function() {
		var pk = $(this).data('id');
		var url = $(this).data('action');
		var data = {'site_print_sizes_id': pk};
		var form = $(this).closest('form').get(0);
		
		$.ajax({
			url: url,
			dataType: "json",
			type: "POST",
			data: data		

		}).done(function(result) {
			if (result.result) {
				//delete row
				$('table#prints').find('tr[data-id="'+pk+'"]').remove();
				clearAlerts(form);
			} else 
			{
				formSystemError(form);
			}
		}).fail(function() {
			formSystemError(form);
		});

	});


		$( "#dialog-form-prints" ).dialog({

			autoOpen: false,
			height: 300,
			width: 350,
			modal: true,
			draggable: true,
			buttons: [
				{ 
				text:	"Create a new print size",
				click:  function() {
				var url = $(this).data('action');
				var delete_url = $(this).data('delete_url');
					//ajax call to insert

						var site_w = $('#dialog-form-prints').find('input#size_w').val();
						var site_h = $('#dialog-form-prints').find('input#size_h').val();
						var price = $('#dialog-form-prints').find('input#price').val();
						data = {"site_w" : site_w, "site_h" : site_h, "price" : price  };	
						$.ajax({
						url: url,
						dataType: "json",
						type: "POST",
						data: data		

						}).done(function(result) {
							if (result.result) {
								var pk = result.site_print_sizes_id;
							
					                	var newRow = '<tr data-id="'+pk+'"  ><td><input name="printsize_w_'+pk+ 
									'" value="'+site_w+'" /></td><td><input name="printsize_h_'+pk+
									'" value="'+site_h+'" /></td> <td><input name="printprice_'+pk+
									'" value="'+price+'" /></td> <td><div class="delete_icon pointer event_print_size_delete"'+
									' data-action="'+delete_url+'" data-id="'+pk+'"></div></td></tr>';

								$('table#prints').find('tr').filter(':last').after(newRow);

								$('#dialog-form-prints' ).dialog( "close" );
								var form = $('#print_form').get(0);
								clearAlerts(form);
							} else 
							{
								
								var form = $('#print_form').get(0);
								formSystemError(form);
							}
						}).fail(function() {
								
							var form = $('#print_form').get(0);
							formSystemError(form);
						});
				
					//end ajax call to insert				

					}
				},
				{
				text:	"Cancel",
				click:  function() {
					$( this ).dialog( "close" );
					}
				}
			],
			close: function() {

				var form = $('#print_form').get(0);
				clearAlerts(form);
				
			}
		});





		$( "#dialog-form-mount-types" ).dialog({

			autoOpen: false,
			height: 300,
			width: 350,
			modal: true,
			draggable: true,
			buttons: [
				{ 
				text:	"Create a new mount type",
				click:  function() {
				var url = $(this).data('action');
				var delete_url = $(this).data('delete_url');
					//ajax call to insert

						var name = $('#dialog-form-mount-types').find('input#mount_type_name').val();
						data = {"mount_type_name" : name  };	
						$.ajax({
						url: url,
						dataType: "json",
						type: "POST",
						data: data		

						}).done(function(result) {
							if (result.result) {
								var pk = result.site_mounting_types_id;
								var newRow =   '<div data-id="'+pk+'" class="mount_row form_breaker">' + 
								' <input type="text" name="mount_type_name_' + pk + '"' +  
								' value="' + name + '" class="mount_type_input"/>' +
                                                 '<div class="delete_icon event_mount_type_delete pointer mount_type_delete"' + 
                                                ' data-action="' + delete_url + '"' +
                                                ' data-id="' + pk + '"></div>' + 
                                                ' </div>';

								$('form#mount_type_form').find('div.mount_row').filter(':last').after(newRow);

								$('#dialog-form-mount-types' ).dialog( "close" );
								var form = $('#mount_type_form').get(0);
								clearAlerts(form);
							} else 
							{
								
								var form = $('#mount_type_form_insert').get(0);
								formError(form, result.errors);
							}
						}).fail(function() {
								
							var form = $('#mount_type_form').get(0);
							formSystemError(form);
						});
				
					//end ajax call to insert				

					}
				},
				{
				text:	"Cancel",
				click:  function() {
					$( this ).dialog( "close" );
					}
				}
			],
			close: function() {
				var form = $('#mount_type_form_insert').get(0);
				clearAlerts(form);
				
			}
		});



		$( "#dialog-form-print-configure" ).dialog({

			autoOpen: false,
			height: 500,
			width: 590,
			modal: true,
			draggable: true,
			buttons: [
				{ 
					text:	"Set print options",
					click:  function() {
						var url = $(this).data('action');
						//ajax call to update print options wrapped in submit to get html5 validation
							var data ={};
							data.print_id = $(this).data("print_id");
							//TODO validation
							data.price_print = $(this).find('div.ajax_form input#print_price').val(); 
							data.price_mounted = $(this).find('div.ajax_form input#print_mounted_price').val();
							data.frames_unmounted = new Array();
							data.frames_mounted = new Array();
								
							$(this).find('div.ajax_form #print_framed_no_mount > option').each(
								function(idx, opt) {
									var priceRecord = {};
									priceRecord.site_framing_types_id = $(opt).val();
									priceRecord.price = $(opt).data("price");
									data.frames_unmounted.push(priceRecord);
								}
							);

							$(this).find('div.ajax_form #print_framed_mounted > option').each(
								function(idx, opt) {
									var priceRecord = {};
									priceRecord.site_framing_types_id = $(opt).val();
									priceRecord.price = $(opt).data("price");
									data.frames_mounted.push(priceRecord);
								}
							);


							$.ajax({
							url: url,
							dataType: "json",
							type: "POST",
							data: data		

							}).done(function(result) {
								alert(JSON.stringify(result));	
								if (result.result) {
									alert("SAVED"); 
								} else 
								{
									var form = $('#print_configure_form').get(0);
									if (result.system_error) {
										formSystemError(form, result.errors);
									}
									else {
										formError(form, result.errors);
									}
								}
							}).fail(function() {
								
								var form = $('#print_configure_form').get(0);
								formSystemError(form);
							});
				
						//end ajax call to insert				

					} //end click
				},
				{
				text:	"Cancel",
				click:  function() {
					$( this ).dialog( "close" );
					}
				}
			],
			close: function() {
				var form = $('#print_configure_form').get(0);
				clearAlerts(form);
				
			},
			open: function() {
				var url = $(this).data('get_configure_data');
				var print_id = $(this).data("print_id");
				var data = {"print_id" : print_id };
				var dialog = $(this);
				$.ajax({
					url: url,
					dataType: "json",
					type: "GET",
					data: data		

					}).done(function(result) {
						if (result.result) {

								alert(JSON.stringify(result));	
							dialog.find('div#print_details > span#currency').html(result.currency_symbol);
							dialog.find('div#print_details > span.print_unit').html(result.unit);
							dialog.find('div#print_details > span#print_width').html(result.print.size_w);
							dialog.find('div#print_details > span#print_height').html(result.print.size_h);
							dialog.find('div.ajax_form  input#print_price').val(result.print.price_print);
							dialog.find('div.ajax_form  input#print_mounted_price').val(result.print.price_mounted);
							$.each(result.frames_unmounted, function(idx, prt) 
								{
									var opt = $('<option></option>');
									opt.val(prt.site_framing_types_id);
									opt.text(prt.frame_type_name);
									opt.data("price", prt.price);
									dialog.find('div.ajax_form #print_framed_no_mount').
										append( opt );	
								});

							$.each(result.frames_mounted, function(idx, prt) 
								{
									var opt = $('<option></option>');
									opt.val(prt.site_framing_types_id);
									opt.text(prt.frame_type_name);
									opt.data("price", prt.price);
									dialog.find('div.ajax_form #print_framed_mounted').
										append( opt );	
								});

							dialog.find('div.ajax_form #print_framed_no_mount').change();
							dialog.find('div.ajax_form #print_framed_mounted').change();
							
						} else 
						{
							var form = $('#print_configure_form').get(0);
							if (result.system_error) {
								formSystemError(form, result.errors);
							}
							else {
								formError(form, result.errors);
							}
						
						}
					}).fail(function() {
								
						var form = $('#print_configure_form').get(0);
						formSystemError(form);
					});

			}//end open
		});

		$( "#dialog-form-frame-edit" ).dialog({
			open: function() {
				var dialog = this;
				$(dialog).find('#frame_type_form_edit').get(0).reset();
				var pk = $(dialog).data('id');
				var getEditUrl = $(dialog).data('get_edit_url');
				var thumbPath = $(dialog).data('thumb_path'); 
				$.get(getEditUrl, {'site_framing_types_id': pk},  function(result) {
					if (result.result) {
						$(dialog).find('#frame_type_form_edit input#frame_type_name').val(result.data.frame_type_name);
						$(dialog).find('#frame_type_form_edit textarea#frame_type_description').val(result.data.description);
						$(dialog).find('#frame_type_form_edit input#pk').val(pk);
							if (result.data.filename !== null) {
								$(dialog).find('form#frame_type_form_edit div.inline_form_pic')
									.append('<img class="update" src="' + 
									thumbPath + result.data.filename +'" alt="' + result.data.filename + '">');
							}
					}	
					 else {
						var form = $('#frame_type_form_edit').get(0);
							if (result.system_error) {
								formSystemError(form, result.errors);
							}
							else {
								formError(form, result.errors);
							}
					}
					
				}).error( function() {
					var form = $('#frame_type_form_edit').get(0);
					formSystemError(form);

				});	

			}, 
			autoOpen: false,
			height: 340,
			width: 350,
			modal: true,
			draggable: true,
			buttons: [{
				text:	"Update  frame type",
				click:  function() {
				var thumbPath = $(this).data('thumb_path'); 
				var saveEditUrl = $(this).data('save_edit_url');
						
						function progressHandlingFunction(e){
						    if(e.lengthComputable){
      							  $('#edit_frame_progress').attr({value:e.loaded,max:e.total});
  						  }
						};	
						var pk = $(this).data('id');
						//these two may be used by IE9 form post
						var name = $('#frame_type_form_edit').find('input#frame_type_name').val();
						var description = $('#frame_type_form_edit').find('textarea#frame_type_description').val();
						var data = {"frame_type_name" : name , "description" : description };	

						//IE9 PROBLEM FormData API and progress element
						var formData = new FormData($('#frame_type_form_edit').get(0));
						$.ajax({
						url: saveEditUrl,
						type: "POST",
						xhr: function() {  // custom xhr
           						var  myXhr = $.ajaxSettings.xhr();
           						if(myXhr.upload){ // check if upload property exists
              					 		myXhr.upload.addEventListener('progress',progressHandlingFunction, false); 
            						}
          						return myXhr;
      						},
						cache: false,
						contentType: false,
						processData: false,
						dataType: "json",
						data: formData		

						}).done(function(result) {
							if (result.result) {
								//update page
								$('div#frame_type').
									find('div.rows > div.frame_row[data-id="'+ pk +'"] > div.frame_name').
									html(name);

								$('div#frame_type').
									find('div.rows > div.frame_row[data-id="'+ pk +'"] > div.frame_description').
									html(description);
								if (result.data.filename !== null) {
									var imageSlot = 
									$('div#frame_type').
										find('div.rows > div.frame_row[data-id="'+ pk +
										'"] > div.inline_form_pic > img');
									if (imageSlot.length) {
										imageSlot
										.attr('src', thumbPath +  result.data.filename)
										.attr('alt', result.data.filename);
									} else {
										$('div#frame_type').
										find('div.rows > div.frame_row[data-id="'+ pk +
										'"] > div.inline_form_pic')
										.append('<img src="'+thumbPath+result.data.filename+'" alt="' +
										result.data.filename + '">');
									}
								}


								$('#dialog-form-frame-edit' ).dialog( "close" );
								var form = $('#frame_type_form_edit').get(0);
								clearAlerts(form);
							} else 
							{
								
								var form = $('#frame_type_form_edit').get(0);
								if (result.system_error) {
									formSystemError(form, result.errors);
								}
								else {
									formError(form, result.errors);
								}
							}
						}).fail(function() {
								
							var form = $('#frame_type_form_edit').get(0);
							formSystemError(form);
						});
				
					//end ajax call to save edit				

					}
				},
				{
				text:	"Cancel",
				click:  function() {
					$( this ).dialog( "close" );
					}
				}
			],
			close: function() {
				var form = $('#frame_type_form_edit').get(0);
				clearAlerts(form);
			} 
		});




		$( "#dialog-form-frame-types" ).dialog({

			autoOpen: false,
			height: 340,
			width: 350,
			modal: true,
			draggable: true,
			buttons: [
				{ 
				text:	"Add a new frame type",
				clickX: function() {
					//	$('#frame_type_form_insert').get(0).submit();	
				},
				click:  function() {
				var url = $(this).data('action');
				var thumbPath = $(this).data('thumb_path'); 
				var delete_url = $(this).data('delete_url');
					//ajax call to insert
						
						function progressHandlingFunction(e){
						    if(e.lengthComputable){
      							  $('#new_frame_progress').attr({value:e.loaded,max:e.total});
  						  }
						}	

						var name = $('#frame_type_form_insert').find('input#frame_type_name').val();
						var description = $('#frame_type_form_insert').find('textarea#frame_type_description').val();

						var data = {"frame_type_name" : name , "description" : description };	
						//IE9 PROBLEM FormData API and progress element
						var formData = new FormData($('#frame_type_form_insert').get(0));
						$.ajax({
						url: url,
						type: "POST",
						xhr: function() {  // custom xhr
           						var  myXhr = $.ajaxSettings.xhr();
           						if(myXhr.upload){ // check if upload property exists
              					 		myXhr.upload.addEventListener('progress',progressHandlingFunction, false); 
            						}
          						return myXhr;
      						},
						cache: false,
						contentType: false,
						processData: false,
						dataType: "json",
						data: formData		

						}).done(function(result) {
							if (result.result) {
								var imageThumb = "";
								if (result.filename != null) {
									imageThumb = '<img alt="' + result.filename + '" src="'+thumbPath + result.filename + '">';
								
								}
								var pk = result.site_framing_types_id;
								var newRow =   '<div data-id="'+pk+'" class="frame_row form_breaker">' + 
								 '<div class="virtual_form_field frame_name">' + name + '</div>' + 
								 '<div class="virtual_form_textarea frame_description">' + description + '</div>' + 
								'<div class="inline_form_pic">' + imageThumb + '</div>' +	
							'<button data-id="' + pk +'" id="frame_type_'+pk+'" class="event_frame_update inline_button">Update</button>' +
						 '<div class="delete_icon event_frame_type_delete pointer frame_type_delete"' + 
                                                ' data-action="' + delete_url + '"' +
                                                ' data-id="' + pk + '"></div>' + 
                                                ' </div>';

								$('div#frame_type').find('div.rows').append(newRow);

								$('#dialog-form-frame-types' ).dialog( "close" );
								var form = $('#frame_type_form').get(0);
								clearAlerts(form);
							} else 
							{
								
								var form = $('#frame_type_form_insert').get(0);
								if (result.system_error) {
									formSystemError(form, result.errors);
								}
								else {
									formError(form, result.errors);
								}
							}
						}).fail(function() {
								
							var form = $('#frame_type_form_insert').get(0);
							formSystemError(form);
						});
				
					//end ajax call to insert				

					}
				},
				{
				text:	"Cancel",
				click:  function() {
					$( this ).dialog( "close" );
					}
				}
			],
			open: function() {
				$(this).find('#frame_type_form_insert').get(0).reset();
			},
			close: function() {
				var form = $('#frame_type_form_insert').get(0);
				clearAlerts(form);
			}
		});

		$( "#dialog-confirm-frame-delete" ).dialog({
			autoOpen: false,
			resizable: false,
			height:160,
			modal: true,
			buttons: {
				"Delete frame type": function() {
					$( this ).dialog( "close" );

					var pk = $(this).data('id');
					var url = $(this).data('action');
					var data = {'site_framing_types_id': pk};
					var form = $(this).closest('.virtual_form').get(0);
		
					$.ajax({
						url: url,
						dataType: "json",
						type: "POST",
						data: data		

					}).done(function(result) {
						if (result.result) {
							//delete row
							$('div#frame_type').find('div.frame_row[data-id="'+pk+'"]').remove();
							clearAlerts(form);
						} else 
						{
							formSystemError(form);
						}
					}).fail(function() {
						formSystemError(form);
					});
							},
				Cancel: function() {
					$( this ).dialog( "close" );
				}
			}
		})

	$('#mount_type_form').on('click', '.event_mount_type_delete', function() {
		var pk = $(this).data('id');
		var url = $(this).data('action');
		var data = {'site_mounting_types_id': pk};
		var form = $(this).closest('form').get(0);
		
		$.ajax({
			url: url,
			dataType: "json",
			type: "POST",
			data: data		

		}).done(function(result) {
			if (result.result) {
				//delete row
				$('form#mount_type_form').find('div.mount_row[data-id="'+pk+'"]').remove();
				clearAlerts(form);
			} else 
			{
				formSystemError(form);
			}
		}).fail(function() {
			formSystemError(form);
		});

	});

	 $( "#dialog-prompt-set-unit" ).dialog({
			autoOpen: false,
       			resizable: false,
       			height:140,
       			modal: true,
       			buttons: {
               			"OK": function() {
                			$( this ).dialog( "close" );
                			}
       			 }
     	   });		

	 $( "#dialog-confirm-set-unit" ).dialog({
			autoOpen: false,
       			resizable: false,
       			height:240,
       			modal: true,
       			buttons: {
               			"OK": function() {
                			$( this ).dialog( "close" );
					var url = $(this).data('action');
					var form = $('#unit_form').get(0);
					var unit = $('select[name="units"]').val();
					if (unit == "..") {
						return;
					}
					var data = {"unitsid" : unit};	

					$.ajax({
						url: url,
						dataType: "json",
						type: "POST",
						data: data		

						}).done(function(result) {
							if (result.result) {
								formSuccess(form);	
							} else 
							{
								formError(form, result.errors);
							}
						}).fail(function() {
								formSystemError(form);
						});



                			},

				"Cancel": function() {
                			$( this ).dialog( "close" );
				}
       			 }
     	   });		






	$('div#frame_type').on('click', '.event_frame_type_delete', function() {
		var pk = $(this).data('id');
		var url = $(this).data('action');
		$('#dialog-confirm-frame-delete').data('id', pk);
		$('#dialog-confirm-frame-delete').data('action', url);
		$( "#dialog-confirm-frame-delete" ).dialog( "open" );
	});

	$('div#frame_type').on('click', 'button.event_frame_update', function() {
		var pk = $(this).data('id');
		$('#dialog-form-frame-edit').data('id', pk);
		$( "#dialog-form-frame-edit" ).dialog( "open" );
	});

	$('div#prints').on('click', 'button.event_load_print_configure', function() {
		var print_id  = $(this).data('id');
		$('#dialog-form-print-configure').data('print_id', print_id);
		$( "#dialog-form-print-configure" ).dialog( "open" );
	});

	$( "#add_print_row" )
			.click(function() {
				$( "#dialog-form-prints" ).dialog( "open" );
			});

	$( "#add_mount_type_row" )
			.click(function() {
				$( "#dialog-form-mount-types" ).dialog( "open" );
			});

	$( "#add_frame_type_row" )
			.click(function() {
				$( "#dialog-form-frame-types" ).dialog( "open" );
	});

	$( "#set_unit" )
			.click(function() {

			var sel = $('select[name="units"]').val();
			if (sel == "..") {
				$('#dialog-prompt-set-unit').dialog("open");
			} else
			{
				$('#dialog-confirm-set-unit').dialog("open");
			}

	});


//PAGE SPECIFIC EVENTS

//admin/pricing/prints
//events for the print configure dialog form

$('div#dialog-form-print-configure div.ajax_form #print_framed_no_mount').
	change(function() {
		var price = $(this).find('option:selected').data('price');
		$('div#dialog-form-print-configure div.ajax_form #print_framed_no_mount_price').val(price);
	});

$('div#dialog-form-print-configure div.ajax_form #print_framed_mounted').
	change(function() {
		var price = $(this).find('option:selected').data('price');
		$('div#dialog-form-print-configure div.ajax_form #print_framed_mounted_price').val(price);
	});


$('div#dialog-form-print-configure div.ajax_form #print_framed_no_mount_price').on("keypress", function(evt) {
	var key = evt.keyCode;
	if (key == 13) {
		var newPrice = $(this).val();
		//TODO validation?
		$('div#dialog-form-print-configure div.ajax_form #print_framed_no_mount > option:selected').data('price', newPrice);
		$('div#dialog-form-print-configure div.ajax_form #print_framed_no_mount_price').next(). 
			fadeIn("slow", function() { 
				$(this).fadeOut();
			});
		
	}
});

$('div#dialog-form-print-configure div.ajax_form #print_framed_mounted_price').on("keypress", function(evt) {
	var key = evt.keyCode;
	if (key == 13) {
		var newPrice = $(this).val();
		//TODO validation?
		$('div#dialog-form-print-configure div.ajax_form #print_framed_mounted > option:selected').data('price', newPrice);
		$('div#dialog-form-print-configure div.ajax_form #print_framed_mounted_price').next(). 
			fadeIn("slow", function() { 
				$(this).fadeOut();
			});
	}
});


});
